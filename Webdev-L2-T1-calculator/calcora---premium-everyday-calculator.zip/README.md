# Calcora — Premium Everyday Calculator
> **“Simple inputs. Smart calculations.”**

An original, responsive, and precision-engineered calculator web application built for the **Oasis Infobyte Internship Program (OIBSIP)**.

---

## 📌 Internship Project Details

- **Candidate Name:** Neha Vinod Borkar
- **Assigned Track:** Web Development & Designing
- **Task Assignment:** Level 2 — Task 1: Calculator
- **GitHub Repository Name:** `OIBSIP`
- **Submission Task Directory:** `OIBSIP/Level2_Task1_Calculator` (or `OIBSIP/Level 2 - Task 1`)

---

## 🚀 Project Overview

**Calcora** is a contemporary calculator web application crafted with a deep indigo/midnight-blue aesthetic, electric violet and cyan accents, and coral highlights. Designed to feel like a high-end digital workstation rather than a generic classroom widget, Calcora provides instant arithmetic feedback, dual-line expression history, accessible touch targets, and full hardware keyboard binding.

The engine uses a deterministic, controlled arithmetic state machine and parser with **strict zero-`eval()` compliance** to ensure maximum security, numerical stability, and predictable operator precedence.

---

## ✨ Features

- **Standard Arithmetic:** Instant evaluation for Addition (`+`), Subtraction (`−`), Multiplication (`×`), and Division (`÷`).
- **Dual-Line Display Chamber:** Real-time secondary expression tracking shows pending operators and previous operands (e.g. `128 × 4 +`), so context is never lost.
- **Controlled Calculation Engine:** Built from scratch without `eval()`, preventing arbitrary code execution and syntax crashes.
- **High-Precision Floating-Point Formatting:** Eliminates IEEE 754 precision quirks (such as `0.1 + 0.2 = 0.3` instead of `0.30000000000000004` and `2.5 + 1.25 = 3.75`).
- **Dynamic Display Scaling:** Intelligently scales font size down as numbers grow longer (up to 16+ digits) to prevent layout clipping and display overflow.
- **Consistent Percentage Calculation (`%`):** Divides the currently entered value by 100 (e.g., typing `50` followed by `%` produces `0.5`).
- **Sign Inversion (`±`):** Toggles current numbers between positive and negative values seamlessly.
- **Full Hardware Keyboard & Numpad Support:** Binds all standard number keys, operators, decimal point, Enter/Equals, Backspace (DEL), and Escape (AC).
- **Calculation History Tape:** Integrated slide-down history drawer logging recent calculations with one-click recall into the active display.
- **Copy to Clipboard:** One-tap button to copy the active display value with visual "Copied!" confirmation.
- **Tactile Audio Feedback (Optional):** Synthetic click sound powered by the Web Audio API (toggleable with mute control).
- **Graceful Error Recovery:** Division-by-zero displays a safe error state (`Cannot divide by 0`), with instant recovery on AC or new numeric input.
- **Responsive Layout:** Optimized across 360px, 390px, 768px, 1024px, and 1440px viewports with zero horizontal scrolling.
- **Accessible & Motion-Respecting:** Uses semantic HTML5, clear ARIA live regions, discernible labels, high contrast ratios, and `prefers-reduced-motion` compliance.

---

## 🛠️ Technologies Used

- **HTML5:** Semantic markup (`<header>`, `<main>`, `<section>`, `<article>`, `<footer>`, `<kbd>`).
- **CSS3:** Modern CSS custom properties (variables), Flexbox, CSS Grid, radial gradients, media queries, and subtle micro-transitions.
- **Vanilla JavaScript (ES6+):** Pure object state machine, Web Audio API, Clipboard API, and DOM event dispatching.
- **Zero Build Step:** 100% vanilla web standards. Runs directly in any modern browser without npm, bundling, or external libraries.

---

## 📂 Project Structure

```text
OIBSIP/
└── Level2_Task1_Calculator/
    ├── index.html       # Semantic single-page structure and accessibility landmarks
    ├── style.css        # Midnight indigo design system, responsive grid & animations
    ├── script.js        # Deterministic math engine, keyboard listener & history tape
    └── README.md        # Comprehensive documentation & verified test suite
```

---

## 💻 How to Run Locally

Because Calcora uses pure standard web technologies, **no build step or compiler is required**:

1. **Direct Browser Execution:**
   - Clone or download the repository:
     ```bash
     git clone https://github.com/your-username/OIBSIP.git
     ```
   - Navigate into the project folder:
     ```bash
     cd OIBSIP/Level2_Task1_Calculator
     ```
   - Double-click `index.html` or right-click and choose **Open with Browser** (Chrome, Firefox, Safari, Edge).

2. **Using a Local Static Server (Optional):**
   - With Python:
     ```bash
     python3 -m http.server 3000
     ```
   - Or with Node `npx serve`:
     ```bash
     npx serve .
     ```
   - Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## ⌨️ Supported Keyboard Shortcuts

| Action | Physical Key(s) | Description |
| :--- | :--- | :--- |
| **Number Input** | `0` through `9` (and Numpad `0-9`) | Inputs number values into the active display |
| **Decimal Point** | `.` or `,` | Inserts decimal separator (auto-adds leading 0 if needed) |
| **Addition** | `+` | Queues addition operation |
| **Subtraction** | `-` | Queues subtraction operation |
| **Multiplication**| `*` or `x` or `X` | Queues multiplication operation |
| **Division** | `/` | Queues division operation (default browser search prevented) |
| **Percentage** | `%` | Divides active number by 100 |
| **Calculate** | `Enter` or `=` | Evaluates pending operation and updates history |
| **Delete / Backspace** | `Backspace` | Removes the most recent character from the active number |
| **All Clear (AC)** | `Escape` or `c` / `C` | Resets calculation state, displays, and pending operations |

---

## 📐 Percentage Calculation Specification

Percentage in Calcora follows the explicit single-operand conversion standard:
- Pressing `%` converts the currently entered value to its percentage equivalent:
  $$\text{Result} = \frac{\text{Current Value}}{100}$$
- **Example 1:** Enter `50`, press `%` $\rightarrow$ Result is `0.5`.
- **Example 2:** Enter `200`, press `+`, enter `15`, press `%` $\rightarrow$ Converts `15` to `0.15`, then press `=` to obtain `200.15`.
- **Example 3:** Enter `250`, press `×`, enter `20`, press `%` $\rightarrow$ Converts `20` to `0.2`, then press `=` to obtain `50`.

---

## 🛡️ Error-Handling Behavior

1. **Division by Zero:**
   - Expression: `7 ÷ 0 =`
   - Output: The display shows `Cannot divide by 0` in an alert coral tone.
   - Recovery: The user can immediately press `AC`, `DEL`, or any number key (`0-9`) to clear the error state and start a new calculation without refreshing the page.
2. **Multiple Decimals:**
   - Prevented: Typing `2.5.5` is restricted; subsequent decimal points are ignored.
3. **Leading Decimals:**
   - Entering `.` on an empty display automatically formats to `0.`.
4. **Consecutive Operators:**
   - Pressing `5 +` and then `×` smoothly updates the queued operator to `×` without corrupting memory.
5. **Non-Finite Results & Overflow:**
   - Numbers beyond standard floating-point thresholds (magnitude $> 10^{14}$ or $< 10^{-7}$) automatically convert to readable scientific notation (e.g. `1.234567e+15`).

---

## ✅ Verified Testing Checklist

The following test suite was executed and confirmed passing:

| Test Case | Inputs | Expected Output | Status |
| :--- | :--- | :--- | :--- |
| **Addition** | `5 + 3 =` | `8` | ✅ Verified Pass |
| **Subtraction** | `9 − 4 =` | `5` | ✅ Verified Pass |
| **Multiplication** | `6 × 7 =` | `42` | ✅ Verified Pass |
| **Division** | `20 ÷ 4 =` | `5` | ✅ Verified Pass |
| **Division by Zero** | `7 ÷ 0 =` | `Cannot divide by 0` | ✅ Verified Pass (Safe Recovery) |
| **Decimals** | `2.5 + 1.25 =` | `3.75` | ✅ Verified Pass |
| **Percentage** | `50 %` | `0.5` | ✅ Verified Pass |
| **Sign Toggle** | `± 25 + 50 =` | `25` | ✅ Verified Pass |
| **Backspace (DEL)** | `1234` then `DEL` | `123` | ✅ Verified Pass |
| **All Clear (AC)** | `999 × 8` then `AC` | `0` (Reset) | ✅ Verified Pass |
| **Keyboard Enter** | `15 * 3` then `Enter` | `45` | ✅ Verified Pass |
| **Keyboard Escape** | `42` then `Escape` | `0` (Cleared) | ✅ Verified Pass |
| **Keyboard Backspace**| `567` then `Backspace`| `56` | ✅ Verified Pass |
| **Mobile Responsiveness** | Viewport 360px & 390px | No clipping, full touch targets | ✅ Verified Pass |

---

## 🎥 Demonstration Video Guidelines (Oasis Infobyte Submission)

Per the internship requirements, the opening 2 seconds of the demonstration video must prominently show the title card:

```text
======================================================
  Candidate Name: Neha Vinod Borkar
  Assigned Track: Web Development & Designing
  Task Title:     Level 2 — Task 1: Calculator
======================================================
```

### Video Sequence Checklist:
1. **Title Card:** Display candidate details for at least 2 full seconds.
2. **Browser Launch:** Open Calcora in a desktop browser.
3. **Basic Operations:** Demonstrate `5 + 3 = 8` and `9 - 4 = 5`.
4. **Multiplication & Division:** Demonstrate `6 × 7 = 42` and `20 ÷ 4 = 5`.
5. **Decimals & Percentage:** Demonstrate `2.5 + 1.25 = 3.75` and `50 % = 0.5`.
6. **Editing & Reset:** Show DEL button removing digits and AC resetting state.
7. **Keyboard Input:** Demonstrate typing calculations via hardware keyboard.
8. **Error Handling:** Demonstrate `7 ÷ 0` and recovery.
9. **Responsive Mobile Viewport:** Inspect element at 375px/390px width showing centered layout.
10. **Footer & Credentials:** Scroll to page footer and verify author information.

---

## 🔍 Known Limitations

- Trigonometric and logarithmic functions (e.g., `sin`, `cos`, `log`) are intentionally omitted to maintain focus on the core Level 2 requirements for an everyday arithmetic calculator.
- Expressions evaluate in sequential immediate-execution mode with operator replacement, matching standard handheld digital calculators.

---

## 📄 License & Credits

Developed with pride by **Neha Vinod Borkar** for the **Oasis Infobyte Internship Program (OIBSIP)**.
Open-source and free to use for educational and evaluation purposes.
