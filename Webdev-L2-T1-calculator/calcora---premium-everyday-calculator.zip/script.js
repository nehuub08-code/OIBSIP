/**
 * CALCORA — Premium Everyday Calculator
 * Oasis Infobyte Internship (OIBSIP) — Level 2 Task 1: Calculator
 * Candidate: Neha Vinod Borkar
 *
 * Pure Vanilla JavaScript Implementation
 * Features:
 * - Deterministic Arithmetic State Machine (Strictly NO eval())
 * - High-Precision Floating-Point Formatting
 * - Dual-line Expression & History Management
 * - Full Hardware Keyboard & Numpad Integration
 * - Division-by-Zero & Overflow Error Recovery
 * - Web Audio API Synthetic Tactile Click (Toggleable)
 * - Clipboard Copying with Visual Feedback
 */

(function () {
  'use strict';

  // --- Calculator State ---
  const state = {
    currentOperand: '0',
    previousOperand: '',
    operation: null,
    expressionHistory: '',
    isError: false,
    justCalculated: false,
    soundEnabled: true,
    history: []
  };

  // --- DOM Elements ---
  const displayMain = document.getElementById('calc-display');
  const displayExp = document.getElementById('calc-expression');
  const displayStatusMsg = document.getElementById('calc-status-message');
  const keypad = document.querySelector('.calc-keypad');
  const historyPanel = document.getElementById('calc-history-panel');
  const historyList = document.getElementById('history-list');
  const historyToggleBtn = document.getElementById('btn-history-toggle');
  const clearHistoryBtn = document.getElementById('btn-clear-history');
  const copyBtn = document.getElementById('btn-copy-result');
  const copyText = document.getElementById('copy-text');
  const audioToggleBtn = document.getElementById('btn-audio-toggle');
  const audioIconOn = document.getElementById('audio-icon-on');
  const audioIconOff = document.getElementById('audio-icon-off');
  const audioStatusLabel = document.getElementById('audio-status-label');

  // --- Web Audio Context for Tactile Feedback ---
  let audioCtx = null;

  function playKeyClickSound(frequency = 600, duration = 0.035) {
    if (!state.soundEnabled) return;
    try {
      if (!audioCtx) {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (AudioContextClass) {
          audioCtx = new AudioContextClass();
        }
      }
      if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume();
      }
      if (!audioCtx) return;

      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(frequency, audioCtx.currentTime);

      gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch {
      // Audio autoplay policy or unavailable — safe to silently ignore
    }
  }

  // --- Math Engine & Formatting Helpers ---

  /**
   * Formats a floating-point number to avoid IEEE 754 precision artifacts.
   * e.g., 0.1 + 0.2 => 0.3 instead of 0.30000000000000004
   */
  function formatResult(num) {
    if (typeof num !== 'number' || !Number.isFinite(num)) {
      return 'Error';
    }

    // Very large or very tiny magnitudes use scientific notation
    const absVal = Math.abs(num);
    if ((absVal >= 1e14 || (absVal < 1e-7 && absVal > 0)) && absVal !== 0) {
      return num.toExponential(6).replace(/\.?0+e/, 'e');
    }

    // Round to 12 decimal places to remove binary floating point inaccuracies
    const rounded = parseFloat(num.toPrecision(12));
    return rounded.toString();
  }

  /**
   * Safely calculates a single binary arithmetic operation without eval().
   */
  function compute(prevStr, currStr, op) {
    const prev = parseFloat(prevStr);
    const curr = parseFloat(currStr);

    if (isNaN(prev) || isNaN(curr)) {
      return { success: false, message: 'Invalid Input' };
    }

    let result = 0;

    switch (op) {
      case '+':
        result = prev + curr;
        break;
      case '−':
      case '-':
        result = prev - curr;
        break;
      case '×':
      case '*':
        result = prev * curr;
        break;
      case '÷':
      case '/':
        if (curr === 0) {
          return { success: false, message: 'Cannot divide by 0' };
        }
        result = prev / curr;
        break;
      default:
        return { success: false, message: 'Unknown Operator' };
    }

    if (!Number.isFinite(result)) {
      return { success: false, message: 'Overflow' };
    }

    return { success: true, value: formatResult(result) };
  }

  // --- Display & UI Updates ---

  function updateDisplay() {
    if (state.isError) {
      displayMain.textContent = state.currentOperand;
      displayMain.classList.add('error-state');
      displayExp.textContent = state.expressionHistory || '';
      displayStatusMsg.textContent = 'ERROR';
      displayStatusMsg.style.color = 'var(--coral-light)';
      adjustDisplayFontSize();
      return;
    }

    displayMain.classList.remove('error-state');
    displayMain.textContent = state.currentOperand || '0';
    displayExp.textContent = state.expressionHistory || '';

    if (state.justCalculated) {
      displayStatusMsg.textContent = 'COMPUTED';
      displayStatusMsg.style.color = 'var(--cyan-light)';
    } else if (state.operation) {
      displayStatusMsg.textContent = 'ACTIVE';
      displayStatusMsg.style.color = 'var(--violet-primary)';
    } else {
      displayStatusMsg.textContent = 'READY';
      displayStatusMsg.style.color = 'var(--text-faint)';
    }

    highlightActiveOperator();
    adjustDisplayFontSize();
  }

  function adjustDisplayFontSize() {
    const len = displayMain.textContent.length;
    displayMain.classList.remove('text-lg', 'text-md', 'text-sm');

    if (len > 18) {
      displayMain.classList.add('text-sm');
    } else if (len > 13) {
      displayMain.classList.add('text-md');
    } else if (len > 9) {
      displayMain.classList.add('text-lg');
    }
  }

  function highlightActiveOperator() {
    const operatorBtns = document.querySelectorAll('.calc-btn.btn-operator');
    operatorBtns.forEach((btn) => {
      const val = btn.getAttribute('data-value');
      if (state.operation && val === state.operation && !state.justCalculated) {
        btn.classList.add('op-active');
      } else {
        btn.classList.remove('op-active');
      }
    });
  }

  // --- Calculation State Machine Actions ---

  function clearAll() {
    state.currentOperand = '0';
    state.previousOperand = '';
    state.operation = null;
    state.expressionHistory = '';
    state.isError = false;
    state.justCalculated = false;
    updateDisplay();
  }

  function deleteLastChar() {
    if (state.isError) {
      clearAll();
      return;
    }

    if (state.justCalculated) {
      // If we just got a calculated result, DEL acts as clear to allow fresh input
      state.expressionHistory = '';
      state.currentOperand = '0';
      state.justCalculated = false;
      updateDisplay();
      return;
    }

    if (state.currentOperand.length <= 1 || state.currentOperand === '-0') {
      state.currentOperand = '0';
    } else {
      state.currentOperand = state.currentOperand.slice(0, -1);
      if (state.currentOperand === '-' || state.currentOperand === '') {
        state.currentOperand = '0';
      }
    }
    updateDisplay();
  }

  function appendNumber(numStr) {
    if (state.isError) {
      clearAll();
    }

    if (state.justCalculated) {
      // Start a fresh calculation if user inputs digits right after equals
      state.currentOperand = numStr;
      state.expressionHistory = '';
      state.justCalculated = false;
      updateDisplay();
      return;
    }

    if (state.currentOperand === '0') {
      state.currentOperand = numStr;
    } else if (state.currentOperand === '-0') {
      state.currentOperand = '-' + numStr;
    } else {
      // Limit input length to 16 digits to prevent display over-stretching
      if (state.currentOperand.replace(/[-.]/g, '').length >= 16) {
        return;
      }
      state.currentOperand += numStr;
    }
    updateDisplay();
  }

  function appendDecimal() {
    if (state.isError || state.justCalculated) {
      clearAll();
      state.currentOperand = '0.';
      updateDisplay();
      return;
    }

    if (state.currentOperand.includes('.')) {
      return; // Only one decimal point allowed per number
    }

    if (!state.currentOperand) {
      state.currentOperand = '0.';
    } else {
      state.currentOperand += '.';
    }
    updateDisplay();
  }

  function toggleSign() {
    if (state.isError) {
      clearAll();
      return;
    }

    if (state.currentOperand === '0' || state.currentOperand === '') {
      return;
    }

    if (state.currentOperand.startsWith('-')) {
      state.currentOperand = state.currentOperand.slice(1);
    } else {
      state.currentOperand = '-' + state.currentOperand;
    }

    state.justCalculated = false;
    updateDisplay();
  }

  function applyPercentage() {
    if (state.isError) {
      clearAll();
      return;
    }

    const currentNum = parseFloat(state.currentOperand);
    if (isNaN(currentNum)) return;

    // Defined percentage behavior: converts active number to value divided by 100
    // Example: 50% => 0.5
    const pctValue = currentNum / 100;
    const formatted = formatResult(pctValue);

    state.currentOperand = formatted;
    state.justCalculated = false;
    updateDisplay();
  }

  function setOperator(op) {
    if (state.isError) {
      clearAll();
    }

    // Normalizing display operator symbols
    let cleanOp = op;
    if (op === '/') cleanOp = '÷';
    if (op === '*') cleanOp = '×';
    if (op === '-') cleanOp = '−';

    if (state.operation !== null && !state.justCalculated) {
      // Chain calculation: if we already have a pending operation and a new number
      if (state.currentOperand !== '' && state.previousOperand !== '') {
        const result = compute(state.previousOperand, state.currentOperand, state.operation);
        if (!result.success) {
          state.isError = true;
          state.currentOperand = result.message;
          updateDisplay();
          return;
        }
        state.previousOperand = result.value;
        state.currentOperand = '';
        state.operation = cleanOp;
        state.expressionHistory = `${result.value} ${cleanOp}`;
        updateDisplay();
        return;
      } else {
        // Just switching the active operator without changing the operand
        state.operation = cleanOp;
        state.expressionHistory = `${state.previousOperand} ${cleanOp}`;
        updateDisplay();
        return;
      }
    }

    state.previousOperand = state.currentOperand;
    state.operation = cleanOp;
    state.expressionHistory = `${state.currentOperand} ${cleanOp}`;
    state.currentOperand = '';
    state.justCalculated = false;
    updateDisplay();
  }

  function calculateEquals() {
    if (state.isError) {
      clearAll();
      return;
    }

    if (!state.operation || state.previousOperand === '') {
      // Nothing to calculate; treat as current display confirmation
      state.justCalculated = true;
      updateDisplay();
      return;
    }

    const secondOperand = state.currentOperand === '' ? state.previousOperand : state.currentOperand;
    const fullExpr = `${state.previousOperand} ${state.operation} ${secondOperand}`;

    const result = compute(state.previousOperand, secondOperand, state.operation);

    if (!result.success) {
      state.isError = true;
      state.currentOperand = result.message;
      state.expressionHistory = `${fullExpr} =`;
      updateDisplay();
      return;
    }

    // Record in history tape
    addHistoryRecord(fullExpr, result.value);

    state.currentOperand = result.value;
    state.expressionHistory = `${fullExpr} =`;
    state.previousOperand = '';
    state.operation = null;
    state.justCalculated = true;
    updateDisplay();
  }

  // --- History Tape Manager ---

  function addHistoryRecord(expression, result) {
    state.history.unshift({ expression, result, id: Date.now() });
    if (state.history.length > 25) {
      state.history.pop();
    }
    renderHistory();
  }

  function renderHistory() {
    if (!historyList) return;

    if (state.history.length === 0) {
      historyList.innerHTML = '<li class="history-empty">No calculations yet. Enter an expression to begin.</li>';
      return;
    }

    historyList.innerHTML = '';
    state.history.forEach((item) => {
      const li = document.createElement('li');
      li.className = 'history-item';
      li.tabIndex = 0;
      li.setAttribute('role', 'button');
      li.setAttribute('aria-label', `Recall calculation ${item.expression} equals ${item.result}`);

      li.innerHTML = `
        <span class="history-item-exp">${escapeHtml(item.expression)} =</span>
        <span class="history-item-res">${escapeHtml(item.result)}</span>
      `;

      li.addEventListener('click', () => {
        state.currentOperand = item.result;
        state.expressionHistory = `Recall: ${item.expression}`;
        state.operation = null;
        state.previousOperand = '';
        state.justCalculated = true;
        state.isError = false;
        updateDisplay();
        toggleHistory(false);
      });

      li.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          li.click();
        }
      });

      historyList.appendChild(li);
    });
  }

  function toggleHistory(forceState) {
    if (!historyPanel || !historyToggleBtn) return;
    const shouldOpen = typeof forceState === 'boolean' ? forceState : historyPanel.classList.contains('hidden');

    if (shouldOpen) {
      historyPanel.classList.remove('hidden');
      historyToggleBtn.classList.add('active');
      historyToggleBtn.setAttribute('aria-expanded', 'true');
      historyPanel.setAttribute('aria-hidden', 'false');
    } else {
      historyPanel.classList.add('hidden');
      historyToggleBtn.classList.remove('active');
      historyToggleBtn.setAttribute('aria-expanded', 'false');
      historyPanel.setAttribute('aria-hidden', 'true');
    }
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // --- Copy to Clipboard ---

  async function copyDisplayValue() {
    if (state.isError) return;
    const valueToCopy = state.currentOperand || '0';

    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(valueToCopy);
      } else {
        // Fallback for older or unsecured contexts
        const textarea = document.createElement('textarea');
        textarea.value = valueToCopy;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }

      if (copyText) {
        const originalText = copyText.textContent;
        copyText.textContent = 'Copied!';
        copyText.style.color = 'var(--cyan-light)';
        setTimeout(() => {
          copyText.textContent = originalText;
          copyText.style.color = '';
        }, 1500);
      }
    } catch {
      // Clipboard write failed or blocked
    }
  }

  // --- Button & Key Press Animations ---

  function pulseButtonVisual(buttonElement) {
    if (!buttonElement) return;
    buttonElement.classList.add('is-pressed');
    setTimeout(() => {
      buttonElement.classList.remove('is-pressed');
    }, 120);
  }

  // --- Event Dispatcher ---

  function handleAction(action, value, sourceBtn = null) {
    playKeyClickSound(action === 'equals' ? 820 : action === 'clear' ? 380 : 580);
    if (sourceBtn) {
      pulseButtonVisual(sourceBtn);
    }

    switch (action) {
      case 'number':
        appendNumber(value);
        break;
      case 'decimal':
        appendDecimal();
        break;
      case 'operator':
        setOperator(value);
        break;
      case 'equals':
        calculateEquals();
        break;
      case 'clear':
        clearAll();
        break;
      case 'delete':
        deleteLastChar();
        break;
      case 'toggle-sign':
        toggleSign();
        break;
      case 'percentage':
        applyPercentage();
        break;
    }
  }

  // --- Event Listeners Setup ---

  function initKeypadListeners() {
    if (!keypad) return;

    keypad.addEventListener('click', (e) => {
      const btn = e.target.closest('.calc-btn');
      if (!btn) return;

      const action = btn.getAttribute('data-action');
      const value = btn.getAttribute('data-value') || '';
      handleAction(action, value, btn);
    });
  }

  function initKeyboardListeners() {
    window.addEventListener('keydown', (e) => {
      // Ignore if user is typing inside an input or textarea
      if (['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)) {
        return;
      }

      const key = e.key;
      let handled = false;

      // Digits 0-9
      if (/^[0-9]$/.test(key)) {
        const btn = document.querySelector(`.calc-btn[data-action="number"][data-value="${key}"]`);
        handleAction('number', key, btn);
        handled = true;
      }
      // Decimal point
      else if (key === '.' || key === ',') {
        const btn = document.querySelector('.calc-btn[data-action="decimal"]');
        handleAction('decimal', '.', btn);
        handled = true;
      }
      // Basic Operators
      else if (key === '+') {
        const btn = document.querySelector('.calc-btn[data-action="operator"][data-value="+"]');
        handleAction('operator', '+', btn);
        handled = true;
      } else if (key === '-') {
        const btn = document.querySelector('.calc-btn[data-action="operator"][data-value="−"]');
        handleAction('operator', '−', btn);
        handled = true;
      } else if (key === '*' || key === 'x' || key === 'X') {
        const btn = document.querySelector('.calc-btn[data-action="operator"][data-value="×"]');
        handleAction('operator', '×', btn);
        handled = true;
      } else if (key === '/') {
        // Prevent default browser search trigger on /
        e.preventDefault();
        const btn = document.querySelector('.calc-btn[data-action="operator"][data-value="÷"]');
        handleAction('operator', '÷', btn);
        handled = true;
      }
      // Percentage
      else if (key === '%') {
        const btn = document.querySelector('.calc-btn[data-action="percentage"]');
        handleAction('percentage', '%', btn);
        handled = true;
      }
      // Equals / Enter
      else if (key === 'Enter' || key === '=') {
        e.preventDefault();
        const btn = document.querySelector('.calc-btn[data-action="equals"]');
        handleAction('equals', '=', btn);
        handled = true;
      }
      // Backspace
      else if (key === 'Backspace') {
        const btn = document.querySelector('.calc-btn[data-action="delete"]');
        handleAction('delete', 'DEL', btn);
        handled = true;
      }
      // Escape or 'c' / 'C'
      else if (key === 'Escape' || key.toLowerCase() === 'c') {
        const btn = document.querySelector('.calc-btn[data-action="clear"]');
        handleAction('clear', 'AC', btn);
        handled = true;
      }

      if (handled) {
        // Avoid accidental scrolling or standard shortcuts during calculation
      }
    });
  }

  function initUtilityListeners() {
    // History Toggle
    if (historyToggleBtn) {
      historyToggleBtn.addEventListener('click', () => {
        toggleHistory();
      });
    }

    // Clear History
    if (clearHistoryBtn) {
      clearHistoryBtn.addEventListener('click', () => {
        state.history = [];
        renderHistory();
      });
    }

    // Copy to Clipboard
    if (copyBtn) {
      copyBtn.addEventListener('click', copyDisplayValue);
    }

    // Audio Toggle
    if (audioToggleBtn) {
      audioToggleBtn.addEventListener('click', () => {
        state.soundEnabled = !state.soundEnabled;
        if (state.soundEnabled) {
          audioIconOn.classList.remove('hidden');
          audioIconOff.classList.add('hidden');
          audioStatusLabel.textContent = 'Sound';
          playKeyClickSound(750);
        } else {
          audioIconOn.classList.add('hidden');
          audioIconOff.classList.remove('hidden');
          audioStatusLabel.textContent = 'Muted';
        }
      });
    }

    // Interactive Verified Test Suite Buttons
    const testButtons = document.querySelectorAll('.btn-run-test');
    testButtons.forEach((btn) => {
      btn.addEventListener('click', () => {
        const testSequence = btn.getAttribute('data-test');
        if (!testSequence) return;

        // Smoothly scroll calculator into focus
        const calcSection = document.getElementById('calculator');
        if (calcSection) {
          calcSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }

        // Execute test sequence in Calcora
        clearAll();
        runTestSequence(testSequence);
      });
    });
  }

  /**
   * Helper to execute a sequence of keys for demo and test verification.
   */
  function runTestSequence(sequence) {
    let index = 0;
    const tokens = [];

    // Parse tokens from string like "2.5+1.25=" or "50%" or "25±+50="
    for (let i = 0; i < sequence.length; i++) {
      tokens.push(sequence[i]);
    }

    const interval = setInterval(() => {
      if (index >= tokens.length) {
        clearInterval(interval);
        return;
      }

      const token = tokens[index];
      if (/[0-9]/.test(token)) {
        appendNumber(token);
      } else if (token === '.') {
        appendDecimal();
      } else if (token === '+') {
        setOperator('+');
      } else if (token === '-') {
        setOperator('−');
      } else if (token === '*') {
        setOperator('×');
      } else if (token === '/') {
        setOperator('÷');
      } else if (token === '%') {
        applyPercentage();
      } else if (token === '±') {
        toggleSign();
      } else if (token === '=') {
        calculateEquals();
      }

      playKeyClickSound(600, 0.02);
      index++;
    }, 120);
  }

  // --- Initialize Application ---
  function init() {
    initKeypadListeners();
    initKeyboardListeners();
    initUtilityListeners();
    updateDisplay();
    renderHistory();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
