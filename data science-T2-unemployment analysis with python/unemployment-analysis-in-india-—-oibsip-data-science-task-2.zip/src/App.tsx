import React, { useState } from 'react';
import { Header } from './components/Header';
import { HeroMetrics } from './components/HeroMetrics';
import { VisualizationsView } from './components/VisualizationsView';
import { NotebookView } from './components/NotebookView';
import { DataExplorerView } from './components/DataExplorerView';
import { CovidComparisonView } from './components/CovidComparisonView';
import { ChecklistView } from './components/ChecklistView';
import { Footer } from './components/Footer';
import {
  BarChart3,
  BookOpen,
  Database,
  GitCompare,
  CheckSquare,
  ArrowRight,
  Download,
  AlertCircle,
  TrendingUp,
  FileCode,
} from 'lucide-react';
import datasetJson from './data/unemploymentData.json';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');

  const { summary, regionStats, monthlyStats } = datasetJson;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-blue-100 selection:text-blue-900">
      {/* Top Bar Contract Navigation */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Persistent or Overview Hero */}
        {activeTab === 'overview' && (
          <HeroMetrics
            onExploreData={() => setActiveTab('explorer')}
            onViewNotebook={() => setActiveTab('notebook')}
          />
        )}

        {/* View Router */}
        {activeTab === 'overview' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
            {/* Research Questions & Objectives */}
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs">
              <div className="max-w-3xl">
                <span className="text-xs font-semibold uppercase tracking-wider text-blue-600">
                  Econometric Inquiry
                </span>
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 mt-1">
                  Core Research Questions & Empirical Answers
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-relaxed">
                  Conducted on 740 monthly records from May 2019 to June 2020 across 28 states and union territories.
                </p>
              </div>

              <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {/* Q1 */}
                <div className="p-5 bg-slate-50/70 border border-slate-200/80 rounded-xl">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900 mb-2">
                    <span className="flex items-center justify-center w-5 h-5 rounded-full bg-blue-100 text-blue-700 text-[11px] font-mono">
                      1
                    </span>
                    <span>Regional Variation</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Unemployment ranged widely from <strong>4.80%</strong> in Meghalaya and <strong>5.66%</strong> in Odisha 
                    to <strong>28.35%</strong> in Tripura and <strong>26.28%</strong> in Haryana, reflecting divergent state-level economic structures.
                  </p>
                </div>

                {/* Q2 */}
                <div className="p-5 bg-slate-50/70 border border-slate-200/80 rounded-xl">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900 mb-2">
                    <span className="flex items-center justify-center w-5 h-5 rounded-full bg-blue-100 text-blue-700 text-[11px] font-mono">
                      2
                    </span>
                    <span>Temporal Trajectory</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    A steady baseline (~9.5%) throughout 2019 was interrupted by the lockdown, which peaked at 
                    <strong> 23.64% in April</strong> and <strong>24.88% in May 2020</strong>, before rebounding sharply to <strong>11.90%</strong> in June 2020.
                  </p>
                </div>

                {/* Q3 */}
                <div className="p-5 bg-slate-50/70 border border-slate-200/80 rounded-xl">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900 mb-2">
                    <span className="flex items-center justify-center w-5 h-5 rounded-full bg-blue-100 text-blue-700 text-[11px] font-mono">
                      3
                    </span>
                    <span>State Hotspots</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    The top 5 states by average rate were <strong>Tripura (28.35%)</strong>, <strong>Haryana (26.28%)</strong>, 
                    <strong> Jharkhand (20.58%)</strong>, <strong>Bihar (18.92%)</strong>, and <strong>Himachal Pradesh (18.54%)</strong>.
                  </p>
                </div>

                {/* Q4 */}
                <div className="p-5 bg-slate-50/70 border border-slate-200/80 rounded-xl">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900 mb-2">
                    <span className="flex items-center justify-center w-5 h-5 rounded-full bg-blue-100 text-blue-700 text-[11px] font-mono">
                      4
                    </span>
                    <span>Variable Correlation</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Unemployment rate correlates moderately negatively with employed headcount (<strong>r = -0.223</strong>), 
                    but shows near-zero correlation with labor force participation (<strong>r = +0.003</strong>).
                  </p>
                </div>

                {/* Q5 */}
                <div className="p-5 bg-slate-50/70 border border-slate-200/80 rounded-xl">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900 mb-2">
                    <span className="flex items-center justify-center w-5 h-5 rounded-full bg-blue-100 text-blue-700 text-[11px] font-mono">
                      5
                    </span>
                    <span>COVID-19 Shift</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    The average rate rose from <strong>9.51%</strong> pre-COVID (before March 1, 2020) to <strong>17.77%</strong> post-COVID, 
                    an absolute surge of <strong>+8.26 percentage points</strong> (+86.91% jump).
                  </p>
                </div>

                {/* Observational Note */}
                <div className="p-5 bg-amber-50/60 border border-amber-200/70 rounded-xl">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-900 mb-2">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Observational Discipline</span>
                  </div>
                  <p className="text-xs text-amber-800 leading-relaxed">
                    Correlation and temporal co-occurrence do not constitute proof of single-variable causation. 
                    Macroeconomic trends, monsoon harvests, and collection methods operate alongside containment policies.
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Visual Navigator Preview */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold text-slate-900">
                    Core Project Artifacts & Visuals
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Click any module to inspect the full data, code, or charts.
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('visualizations')}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-800 transition-colors cursor-pointer"
                >
                  <span>View All 4 Figures</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Card 1 */}
                <div
                  onClick={() => setActiveTab('visualizations')}
                  className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-xs transition-all cursor-pointer group flex flex-col justify-between"
                >
                  <div>
                    <div className="overflow-hidden rounded-lg bg-slate-100 aspect-16/10 mb-3">
                      <img
                        src="/outputs/unemployment_trends.png"
                        alt="Unemployment Trends"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600">
                      Figure 1
                    </span>
                    <h4 className="text-sm font-bold text-slate-900 mt-0.5">
                      Multi-State Time Series
                    </h4>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                      Monthly progression of Haryana, Bihar, Maharashtra, and Tamil Nadu.
                    </p>
                  </div>
                  <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span>outputs/unemployment_trends.png</span>
                  </div>
                </div>

                {/* Card 2 */}
                <div
                  onClick={() => setActiveTab('visualizations')}
                  className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-xs transition-all cursor-pointer group flex flex-col justify-between"
                >
                  <div>
                    <div className="overflow-hidden rounded-lg bg-slate-100 aspect-16/10 mb-3">
                      <img
                        src="/outputs/top_10_states.png"
                        alt="Top 10 States"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600">
                      Figure 2
                    </span>
                    <h4 className="text-sm font-bold text-slate-900 mt-0.5">
                      Top 10 States by Rate
                    </h4>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                      Tripura (28.35%), Haryana (26.28%), and Jharkhand (20.58%) lead averages.
                    </p>
                  </div>
                  <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span>outputs/top_10_states.png</span>
                  </div>
                </div>

                {/* Card 3 */}
                <div
                  onClick={() => setActiveTab('visualizations')}
                  className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-xs transition-all cursor-pointer group flex flex-col justify-between"
                >
                  <div>
                    <div className="overflow-hidden rounded-lg bg-slate-100 aspect-16/10 mb-3">
                      <img
                        src="/outputs/correlation_heatmap.png"
                        alt="Correlation Heatmap"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600">
                      Figure 3
                    </span>
                    <h4 className="text-sm font-bold text-slate-900 mt-0.5">
                      Correlation Heatmap
                    </h4>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                      Pearson r values among unemployment, headcount, and labor participation.
                    </p>
                  </div>
                  <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span>outputs/correlation_heatmap.png</span>
                  </div>
                </div>

                {/* Card 4 */}
                <div
                  onClick={() => setActiveTab('visualizations')}
                  className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-xs transition-all cursor-pointer group flex flex-col justify-between"
                >
                  <div>
                    <div className="overflow-hidden rounded-lg bg-slate-100 aspect-16/10 mb-3">
                      <img
                        src="/outputs/pre_post_covid_comparison.png"
                        alt="Pre vs Post COVID"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600">
                      Figure 4
                    </span>
                    <h4 className="text-sm font-bold text-slate-900 mt-0.5">
                      Pre vs Post COVID Shift
                    </h4>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                      National +8.26 pp jump alongside state-level surge rankings.
                    </p>
                  </div>
                  <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span>outputs/pre_post_covid_comparison.png</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Project Folder Architecture */}
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
                <div>
                  <h3 className="text-lg font-bold text-slate-900">
                    Repository Architecture & Artifact Structure
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Conforms precisely to the Oasis Infobyte Data Science Task 2 directory standard.
                  </p>
                </div>
                <a
                  href="/notebooks/Unemployment_Analysis.ipynb"
                  download="Unemployment_Analysis.ipynb"
                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Notebook (.ipynb)</span>
                </a>
              </div>

              <div className="mt-6 bg-slate-900 text-slate-200 p-5 rounded-xl font-mono text-xs leading-relaxed overflow-x-auto">
                <pre>{`OIBSIP/
└── DataScience/
    └── Task2_Unemployment_Analysis/
        ├── Unemployment_Analysis.ipynb         # [Verified] Executed 30-cell Jupyter notebook
        ├── README.md                           # [Verified] Comprehensive GitHub documentation
        ├── requirements.txt                    # [Verified] pandas, numpy, matplotlib, seaborn, jupyter
        ├── data/
        │   ├── Unemployment in India.csv       # [Verified] Cleaned 740 CMIE observations
        │   └── README.md                       # [Verified] Dataset provenance & download instructions
        ├── outputs/
        │   ├── unemployment_trends.png         # [Verified] 300 DPI Time-series line chart
        │   ├── top_10_states.png               # [Verified] 300 DPI Top 10 states horizontal bar chart
        │   ├── correlation_heatmap.png         # [Verified] 300 DPI Pearson correlation heatmap
        │   └── pre_post_covid_comparison.png   # [Verified] 300 DPI Pre vs. post COVID comparison
        └── screenshots/
            └── README.md                       # [Verified] Notebook execution evidence guide`}</pre>
              </div>
            </div>
          </div>
        )}

        {/* Tab 1: Visualizations */}
        {activeTab === 'visualizations' && <VisualizationsView />}

        {/* Tab 2: Jupyter Notebook */}
        {activeTab === 'notebook' && <NotebookView />}

        {/* Tab 3: Data Explorer */}
        {activeTab === 'explorer' && <DataExplorerView />}

        {/* Tab 4: Pre vs Post COVID Shift */}
        {activeTab === 'comparison' && <CovidComparisonView />}

        {/* Tab 5: Internship Task Checklist */}
        {activeTab === 'checklist' && <ChecklistView />}
      </main>

      {/* Footer */}
      <Footer setActiveTab={setActiveTab} />
    </div>
  );
}
