import React, { useState } from 'react';
import { CheckCircle2, Circle, Copy, Check, Terminal, FolderTree, FileCheck } from 'lucide-react';

interface ChecklistItem {
  id: string;
  label: string;
  section: string;
  description: string;
}

export const ChecklistView: React.FC = () => {
  const defaultItems: ChecklistItem[] = [
    {
      id: 'item-1',
      label: 'Dataset obtained from a suitable source',
      section: 'Section 3 & data/README.md',
      description: 'Sourced from Kaggle (Gokul Raj Kuppan / CMIE) with complete provenance and schema documented.',
    },
    {
      id: 'item-2',
      label: 'Data loaded and shape inspected',
      section: 'Notebook Section 2',
      description: 'Initial dimensions 768 rows x 7 columns verified, head displayed, data types inspected.',
    },
    {
      id: 'item-3',
      label: 'Missing values checked and types converted',
      section: 'Notebook Section 2 & 3',
      description: '28 trailing all-blank rows dropped; Date converted to datetime; numeric columns parsed safely.',
    },
    {
      id: 'item-4',
      label: 'Region-wise averages calculated',
      section: 'Notebook Section 4A',
      description: 'Mean, standard deviation, and count calculated across all 28 states/UTs with horizontal bar chart.',
    },
    {
      id: 'item-5',
      label: 'Month-wise trends calculated',
      section: 'Notebook Section 4B',
      description: 'Datetime Year-Month aggregation tracking May 2019 baseline through April-May 2020 peaks.',
    },
    {
      id: 'item-6',
      label: 'Time-series chart for at least three regions created',
      section: 'Notebook Section 5',
      description: 'Haryana, Bihar, Maharashtra, and Tamil Nadu plotted with COVID-19 March 2020 cutoff.',
    },
    {
      id: 'item-7',
      label: 'Top 10 states/regions chart created',
      section: 'Notebook Section 4C',
      description: 'High-res horizontal bar chart with exact percentage annotations saved to outputs/top_10_states.png.',
    },
    {
      id: 'item-8',
      label: 'Correlation heatmap created using available valid variables',
      section: 'Notebook Section 6',
      description: 'Seaborn heatmap of Unemployment Rate, Employed Count, and Labour Participation saved to outputs/correlation_heatmap.png.',
    },
    {
      id: 'item-9',
      label: 'Pre-COVID and post-COVID means compared',
      section: 'Notebook Section 7',
      description: 'Pre (9.51%) vs Post (17.77%), +8.26 pp increase (+86.91%) saved to outputs/pre_post_covid_comparison.png.',
    },
    {
      id: 'item-10',
      label: 'Markdown observations included after charts',
      section: 'Notebook Sections 4, 5, 6, 7 & 8',
      description: 'Rigorous 4-part structure (Description, Observed Values, Implication, Limitation) after every visual.',
    },
    {
      id: 'item-11',
      label: 'Notebook clean and commented',
      section: 'Unemployment_Analysis.ipynb',
      description: 'PEP 8 formatted, beginner-friendly comments designed for a 2nd year engineering student review.',
    },
    {
      id: 'item-12',
      label: 'README and requirements completed',
      section: 'README.md & requirements.txt',
      description: 'Comprehensive documentation, reproduction steps, research question answers, and dependencies.',
    },
    {
      id: 'item-13',
      label: 'Charts saved in the outputs folder',
      section: 'outputs/ directory',
      description: 'All 4 publication figures generated at 300 DPI in OIBSIP/DataScience/Task2_Unemployment_Analysis/outputs/.',
    },
    {
      id: 'item-14',
      label: 'Notebook executed successfully from beginning to end',
      section: 'Execution Verification',
      description: 'All 30 cells executed sequentially with authentic outputs, zero errors, and clean execution counts.',
    },
  ];

  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>(
    defaultItems.reduce((acc, item) => ({ ...acc, [item.id]: true }), {})
  );

  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const toggleItem = (id: string) => {
    setCheckedItems((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const completedCount = Object.values(checkedItems).filter(Boolean).length;
  const progressPct = Math.round((completedCount / defaultItems.length) * 100);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const localRunCode = `# 1. Navigate to task folder
cd OIBSIP/DataScience/Task2_Unemployment_Analysis/

# 2. Setup virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\\Scripts\\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Launch Jupyter Notebook
jupyter notebook Unemployment_Analysis.ipynb`;

  const gitCommands = `# Stage all task 2 files
git add OIBSIP/DataScience/Task2_Unemployment_Analysis/

# Commit with structured internship message
git commit -m "feat(oibsip-task2): complete unemployment analysis notebook, eda charts, and documentation"

# Note: Do not push without supervisor authorization`;

  return (
    <div className="py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="pb-6 border-b border-slate-200">
          <p className="text-xs font-semibold uppercase tracking-wider text-blue-600">
            Evaluation & Compliance
          </p>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 mt-1">
            Final Internship Task Checklist
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Verification mapping against the Oasis Infobyte Data Science Internship Task 2 master brief.
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mt-6 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs font-semibold mb-2">
            <span className="text-slate-700">Internship Deliverables Compliance</span>
            <span className="font-mono text-emerald-700">
              {completedCount} of {defaultItems.length} Complete ({progressPct}%)
            </span>
          </div>
          <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
            <div
              style={{ width: `${progressPct}%` }}
              className="h-full bg-emerald-600 transition-all duration-500 rounded-full"
            />
          </div>
        </div>

        {/* Checklist Items */}
        <div className="mt-8 space-y-3">
          {defaultItems.map((item) => {
            const isChecked = checkedItems[item.id];
            return (
              <div
                key={item.id}
                onClick={() => toggleItem(item.id)}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                  isChecked
                    ? 'bg-white border-slate-200 hover:border-slate-300'
                    : 'bg-slate-50/70 border-slate-200 text-slate-400'
                }`}
              >
                <button
                  type="button"
                  className="mt-0.5 text-emerald-600 shrink-0 cursor-pointer"
                >
                  {isChecked ? (
                    <CheckCircle2 className="w-5 h-5 fill-emerald-100 text-emerald-600" />
                  ) : (
                    <Circle className="w-5 h-5 text-slate-300" />
                  )}
                </button>
                <div className="flex-1">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <span
                      className={`text-sm font-bold ${
                        isChecked ? 'text-slate-900' : 'text-slate-500 line-through'
                      }`}
                    >
                      {item.label}
                    </span>
                    <span className="text-[11px] font-mono text-slate-500 shrink-0">
                      {item.section}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Commands Guide Strip */}
        <div className="mt-10 grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Run Instructions */}
          <div className="bg-slate-900 text-slate-100 p-5 rounded-2xl border border-slate-800 shadow-md">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold font-mono text-slate-200">
                  Run Locally via Jupyter
                </span>
              </div>
              <button
                onClick={() => copyToClipboard(localRunCode, 'local')}
                className="inline-flex items-center gap-1 text-[11px] text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                {copiedCode === 'local' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <pre className="mt-3 text-xs font-mono text-emerald-300/90 leading-relaxed overflow-x-auto whitespace-pre">
              {localRunCode}
            </pre>
          </div>

          {/* Git Submission Commands */}
          <div className="bg-slate-900 text-slate-100 p-5 rounded-2xl border border-slate-800 shadow-md">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <FolderTree className="w-4 h-4 text-blue-400" />
                <span className="text-xs font-bold font-mono text-slate-200">
                  Git Submission Workflow
                </span>
              </div>
              <button
                onClick={() => copyToClipboard(gitCommands, 'git')}
                className="inline-flex items-center gap-1 text-[11px] text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                {copiedCode === 'git' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <pre className="mt-3 text-xs font-mono text-blue-300/90 leading-relaxed overflow-x-auto whitespace-pre">
              {gitCommands}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
