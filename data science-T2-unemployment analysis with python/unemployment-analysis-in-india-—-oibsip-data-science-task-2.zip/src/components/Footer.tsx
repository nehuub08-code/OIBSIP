import React from 'react';
import { Download, FileCode, Database } from 'lucide-react';

interface FooterProps {
  setActiveTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab }) => {
  return (
    <footer className="bg-white border-t border-slate-200 mt-16 py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-600" aria-hidden="true" />
              <span className="font-bold text-slate-900 text-sm">
                Oasis Infobyte (OIBSIP) · Task 2
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Data Science Internship · Unemployment Analysis with Python
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-slate-600 font-medium">
            <button
              onClick={() => setActiveTab('overview')}
              className="hover:text-slate-900 transition-colors cursor-pointer"
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('visualizations')}
              className="hover:text-slate-900 transition-colors cursor-pointer"
            >
              Charts & Visuals
            </button>
            <button
              onClick={() => setActiveTab('notebook')}
              className="hover:text-slate-900 transition-colors cursor-pointer"
            >
              Jupyter Notebook
            </button>
            <button
              onClick={() => setActiveTab('explorer')}
              className="hover:text-slate-900 transition-colors cursor-pointer"
            >
              Data Explorer
            </button>
            <button
              onClick={() => setActiveTab('checklist')}
              className="hover:text-slate-900 transition-colors cursor-pointer"
            >
              Internship Checklist
            </button>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            Dataset credit: Centre for Monitoring Indian Economy (CMIE) via Kaggle (Gokul Raj Kuppan).
          </div>
          <div>
            Strictly observational economic research project for educational and internship evaluation.
          </div>
        </div>
      </div>
    </footer>
  );
};
