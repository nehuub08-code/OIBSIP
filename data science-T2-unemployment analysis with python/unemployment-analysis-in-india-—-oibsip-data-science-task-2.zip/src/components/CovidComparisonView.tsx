import React, { useState } from 'react';
import { ArrowUpRight, TrendingUp, AlertTriangle, ShieldCheck, Download, Search } from 'lucide-react';
import datasetJson from '../data/unemploymentData.json';

interface RegionStat {
  region: string;
  mean: number;
  count: number;
  std: number;
  preMean: number;
  postMean: number;
  delta: number;
}

export const CovidComparisonView: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [sortBy, setSortBy] = useState<'delta' | 'postMean' | 'preMean'>('delta');
  const [selectedState, setSelectedState] = useState<string>('Haryana');

  const { summary, regionStats } = datasetJson as {
    summary: any;
    regionStats: RegionStat[];
  };

  const filteredRegions = [...regionStats]
    .filter((r) =>
      searchTerm === '' || r.region.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => b[sortBy] - a[sortBy]);

  const activeRegionData = regionStats.find((r) => r.region === selectedState) || regionStats[0];

  return (
    <div className="py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="pb-6 border-b border-slate-200">
          <p className="text-xs font-semibold uppercase tracking-wider text-rose-600">
            Econometric Impact Analysis
          </p>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 mt-1">
            Pre-COVID vs. Post-COVID Comparison
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-3xl">
            Empirical evaluation establishing an analytical cutoff at <strong>March 1, 2020</strong> to contrast 
            pre-pandemic baselines (May 2019 – Feb 2020) against lockdown and reopening periods (Mar 2020 – Jun 2020).
          </p>
        </div>

        {/* National Macro Shift Overview */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Pre-COVID Normal
            </span>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-blue-600 font-mono tabular-nums">
                {summary.preCovidMean.toFixed(2)}%
              </span>
              <span className="text-xs text-slate-500 font-mono">
                (536 obs)
              </span>
            </div>
            <p className="mt-2 text-xs text-slate-600 leading-relaxed">
              Calculated across 10 calendar months from May 2019 through February 2020 with standard deviation of 7.75%.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
            <span className="text-xs font-semibold uppercase tracking-wider text-rose-600">
              Post-COVID Shock
            </span>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-rose-600 font-mono tabular-nums">
                {summary.postCovidMean.toFixed(2)}%
              </span>
              <span className="text-xs text-slate-500 font-mono">
                (204 obs)
              </span>
            </div>
            <p className="mt-2 text-xs text-slate-600 leading-relaxed">
              Calculated across 4 calendar months from March 2020 through June 2020 with standard deviation of 14.93%.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-600">
              Econometric Jump
            </span>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-amber-700 font-mono tabular-nums">
                +{summary.absDifferencePp.toFixed(2)} pp
              </span>
              <span className="text-xs font-bold text-amber-700 font-mono">
                (+{summary.relativePctChange.toFixed(1)}%)
              </span>
            </div>
            <p className="mt-2 text-xs text-slate-600 leading-relaxed">
              Net increase in mean unemployment rate; cross-state dispersion and variance nearly doubled.
            </p>
          </div>
        </div>

        {/* State Spotlight Inspector */}
        <div className="mt-8 bg-slate-900 text-white rounded-2xl p-6 shadow-md">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <span className="text-xs font-mono text-blue-400 font-bold uppercase tracking-wider">
                State Spotlight Inspector
              </span>
              <h3 className="text-xl font-bold mt-0.5">
                {activeRegionData.region} Economic Shift
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs text-slate-400">Select Region:</label>
              <select
                value={selectedState}
                onChange={(e) => setSelectedState(e.target.value)}
                className="bg-slate-800 text-white text-xs px-3 py-1.5 rounded-lg border border-slate-700 focus:outline-hidden focus:ring-1 focus:ring-blue-500 cursor-pointer"
              >
                {regionStats.map((r) => (
                  <option key={r.region} value={r.region}>
                    {r.region}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/60">
              <span className="text-xs text-slate-400 block">Pre-COVID Average</span>
              <span className="text-2xl font-bold font-mono tabular-nums text-blue-400 mt-1 block">
                {activeRegionData.preMean.toFixed(2)}%
              </span>
            </div>
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/60">
              <span className="text-xs text-slate-400 block">Post-COVID Average</span>
              <span className="text-2xl font-bold font-mono tabular-nums text-rose-400 mt-1 block">
                {activeRegionData.postMean.toFixed(2)}%
              </span>
            </div>
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/60">
              <span className="text-xs text-slate-400 block">Absolute Increase</span>
              <span className={`text-2xl font-bold font-mono tabular-nums mt-1 block ${
                activeRegionData.delta >= 0 ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {activeRegionData.delta >= 0 ? `+${activeRegionData.delta.toFixed(2)}` : activeRegionData.delta.toFixed(2)} pp
              </span>
            </div>
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/60">
              <span className="text-xs text-slate-400 block">Relative Jump</span>
              <span className="text-2xl font-bold font-mono tabular-nums text-amber-300 mt-1 block">
                {activeRegionData.preMean > 0
                  ? `+${(((activeRegionData.postMean - activeRegionData.preMean) / activeRegionData.preMean) * 100).toFixed(1)}%`
                  : 'N/A'}
              </span>
            </div>
          </div>

          {/* Visual comparative bar */}
          <div className="mt-6 pt-4 border-t border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span>Visual Proportion: Pre-COVID vs. Post-COVID</span>
              <span className="font-mono">
                {activeRegionData.preMean.toFixed(1)}% $\rightarrow$ {activeRegionData.postMean.toFixed(1)}%
              </span>
            </div>
            <div className="h-4 bg-slate-800 rounded-full overflow-hidden flex">
              <div
                style={{ width: `${Math.min(activeRegionData.preMean * 1.5, 50)}%` }}
                className="bg-blue-500 h-full transition-all"
                title={`Pre-COVID: ${activeRegionData.preMean}%`}
              />
              <div
                style={{ width: `${Math.min(Math.max(activeRegionData.delta, 0) * 1.5, 50)}%` }}
                className="bg-rose-500 h-full transition-all"
                title={`Post-COVID Delta: +${activeRegionData.delta}%`}
              />
            </div>
          </div>
        </div>

        {/* State-by-State Comparison Matrix */}
        <div className="mt-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
          <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                State-Level Comparison Table (All 28 Regions)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Sorted by net percentage point increase from Pre-COVID to Post-COVID.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Filter state..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="flex items-center p-0.5 bg-slate-100 rounded-lg text-xs font-medium">
                <button
                  onClick={() => setSortBy('delta')}
                  className={`px-2.5 py-1 rounded cursor-pointer ${
                    sortBy === 'delta' ? 'bg-white font-bold text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Delta (pp)
                </button>
                <button
                  onClick={() => setSortBy('postMean')}
                  className={`px-2.5 py-1 rounded cursor-pointer ${
                    sortBy === 'postMean' ? 'bg-white font-bold text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Post-COVID
                </button>
                <button
                  onClick={() => setSortBy('preMean')}
                  className={`px-2.5 py-1 rounded cursor-pointer ${
                    sortBy === 'preMean' ? 'bg-white font-bold text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Pre-COVID
                </button>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/70 border-b border-slate-200 text-slate-600 uppercase text-[11px] font-semibold">
                <tr>
                  <th className="py-3 px-4">State / Union Territory</th>
                  <th className="py-3 px-4 text-right">Pre-COVID Mean (%)</th>
                  <th className="py-3 px-4 text-right">Post-COVID Mean (%)</th>
                  <th className="py-3 px-4 text-right">Net Delta (pp)</th>
                  <th className="py-3 px-4 text-right">Relative Jump (%)</th>
                  <th className="py-3 px-4">Impact Severity</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono text-[12px]">
                {filteredRegions.map((row) => {
                  const pct =
                    row.preMean > 0 ? ((row.delta / row.preMean) * 100).toFixed(1) : 'N/A';
                  return (
                    <tr
                      key={row.region}
                      onClick={() => setSelectedState(row.region)}
                      className={`hover:bg-blue-50/50 cursor-pointer transition-colors ${
                        selectedState === row.region ? 'bg-blue-50/70' : ''
                      }`}
                    >
                      <td className="py-3 px-4 font-sans font-medium text-slate-900">
                        {row.region}
                      </td>
                      <td className="py-3 px-4 text-right text-blue-700 tabular-nums">
                        {row.preMean.toFixed(2)}%
                      </td>
                      <td className="py-3 px-4 text-right text-rose-700 font-bold tabular-nums">
                        {row.postMean.toFixed(2)}%
                      </td>
                      <td className="py-3 px-4 text-right font-bold tabular-nums">
                        <span
                          className={
                            row.delta >= 10
                              ? 'text-rose-600'
                              : row.delta >= 5
                              ? 'text-amber-600'
                              : 'text-slate-700'
                          }
                        >
                          {row.delta >= 0 ? `+${row.delta.toFixed(2)}` : row.delta.toFixed(2)} pp
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right text-slate-600 tabular-nums">
                        {row.delta >= 0 ? `+${pct}%` : `${pct}%`}
                      </td>
                      <td className="py-3 px-4 font-sans">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium ${
                            row.delta >= 12
                              ? 'bg-rose-100 text-rose-800 font-bold'
                              : row.delta >= 6
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {row.delta >= 12 ? 'Severe Shock' : row.delta >= 6 ? 'Moderate Shock' : 'Contained'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
