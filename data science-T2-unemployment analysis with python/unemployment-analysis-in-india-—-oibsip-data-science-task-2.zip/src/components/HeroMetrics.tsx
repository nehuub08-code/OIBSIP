import React from 'react';
import { ArrowUpRight, TrendingUp, Calendar, MapPin, Database, FileSpreadsheet } from 'lucide-react';
import dataSummary from '../data/unemploymentData.json';

interface HeroMetricsProps {
  onExploreData: () => void;
  onViewNotebook: () => void;
}

export const HeroMetrics: React.FC<HeroMetricsProps> = ({ onExploreData, onViewNotebook }) => {
  const { summary } = dataSummary;

  const handleDownloadCsv = () => {
    const link = document.createElement('a');
    link.href = '/data/Unemployment_in_India.csv';
    link.download = 'Unemployment in India.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section className="bg-white border-b border-slate-200 pt-8 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Editorial Title & Kicker */}
        <div className="max-w-3xl">
          <p className="text-xs font-semibold uppercase tracking-widest text-blue-600 mb-2">
            Oasis Infobyte Data Science Internship · Task 2
          </p>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-slate-900 leading-tight">
            Econometric Unemployment Analysis in India
          </h1>
          <p className="mt-3 text-sm sm:text-base text-slate-600 leading-relaxed">
            Exploratory data analysis of monthly unemployment rates across 28 Indian states and union territories, 
            investigating baseline regional dynamics, labor force participation, and the immediate macroeconomic shock 
            triggered by the COVID-19 nationwide lockdowns.
          </p>

          {/* Unboxed Metadata with typographic separators */}
          <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-slate-500 font-medium">
            <span>CMIE Monthly Economic Survey</span>
            <span aria-hidden="true">·</span>
            <span>Kaggle (Gokul Raj Kuppan)</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">740 Valid Observations</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">May 2019 – June 2020</span>
            <span aria-hidden="true">·</span>
            <span>28 States & UTs</span>
          </div>
        </div>

        {/* 4 Primary KPI Metric Cards (Single-Elevation, Tabular Numerals) */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* KPI 1: Pre-COVID Baseline */}
          <div className="p-5 bg-slate-50/70 border border-slate-200/80 rounded-xl hover:border-slate-300 transition-colors">
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Pre-COVID Baseline Mean</span>
              <span className="text-slate-400 font-mono text-[11px]">May 19 – Feb 20</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
                {summary.preCovidMean.toFixed(2)}%
              </span>
              <span className="text-xs text-slate-500 font-mono tabular-nums">
                (n = {summary.preCovidCount})
              </span>
            </div>
            <p className="mt-2 text-xs text-slate-600 leading-normal">
              Stable pre-pandemic monthly average across 28 surveyed states and union territories.
            </p>
          </div>

          {/* KPI 2: Post-COVID Mean */}
          <div className="p-5 bg-rose-50/50 border border-rose-200/80 rounded-xl hover:border-rose-300 transition-colors">
            <div className="flex items-center justify-between text-xs font-medium text-rose-700">
              <span>Post-COVID Shock Mean</span>
              <span className="text-rose-500 font-mono text-[11px]">Mar 20 – Jun 20</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-rose-700 font-mono tabular-nums">
                {summary.postCovidMean.toFixed(2)}%
              </span>
              <span className="text-xs text-rose-600 font-mono tabular-nums">
                (n = {summary.postCovidCount})
              </span>
            </div>
            <p className="mt-2 text-xs text-rose-800 leading-normal">
              Elevated average during national containment lockdown and initial unlock phases.
            </p>
          </div>

          {/* KPI 3: Absolute Delta */}
          <div className="p-5 bg-amber-50/50 border border-amber-200/80 rounded-xl hover:border-amber-300 transition-colors">
            <div className="flex items-center justify-between text-xs font-medium text-amber-800">
              <span>Net Surge / Jump</span>
              <span className="text-amber-700 font-mono text-[11px]">Period Delta</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-amber-700 font-mono tabular-nums">
                +{summary.absDifferencePp.toFixed(2)} pp
              </span>
              <span className="text-xs font-bold text-amber-800 font-mono tabular-nums">
                (+{summary.relativePctChange.toFixed(1)}%)
              </span>
            </div>
            <p className="mt-2 text-xs text-amber-800 leading-normal">
              Net increase in mean unemployment rate with cross-state variance nearly doubling.
            </p>
          </div>

          {/* KPI 4: Peak Lockdown Month */}
          <div className="p-5 bg-blue-50/50 border border-blue-200/80 rounded-xl hover:border-blue-300 transition-colors">
            <div className="flex items-center justify-between text-xs font-medium text-blue-700">
              <span>Peak Lockdown Month</span>
              <span className="text-blue-500 font-mono text-[11px]">May 2020</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-blue-700 font-mono tabular-nums">
                24.88%
              </span>
              <span className="text-xs text-blue-600 font-mono tabular-nums">
                (Apr: 23.64%)
              </span>
            </div>
            <p className="mt-2 text-xs text-blue-800 leading-normal">
              Unprecedented high recorded during the second full month of nationwide lockdowns.
            </p>
          </div>
        </div>

        {/* Quick Action Strip */}
        <div className="mt-6 flex flex-wrap items-center gap-3">
          <button
            onClick={onExploreData}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <Database className="w-3.5 h-3.5 text-slate-500" />
            <span>Explore 740 Records</span>
          </button>
          <button
            onClick={onViewNotebook}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <TrendingUp className="w-3.5 h-3.5 text-slate-500" />
            <span>View Executed Notebook</span>
          </button>
          <button
            onClick={handleDownloadCsv}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-slate-500" />
            <span>Download Clean CSV</span>
          </button>
        </div>
      </div>
    </section>
  );
};
