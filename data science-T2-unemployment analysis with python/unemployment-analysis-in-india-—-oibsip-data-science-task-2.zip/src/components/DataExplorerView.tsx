import React, { useState, useMemo } from 'react';
import { Search, Filter, Download, ArrowUpDown, ChevronLeft, ChevronRight, FileSpreadsheet } from 'lucide-react';
import datasetJson from '../data/unemploymentData.json';

interface RecordItem {
  id: number;
  region: string;
  date: string;
  yearMonth: string;
  frequency: string;
  unemploymentRate: number;
  employed: number;
  labourParticipation: number;
  area: string;
  isPostCovid: boolean;
}

export const DataExplorerView: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedArea, setSelectedArea] = useState<string>('all');
  const [selectedPeriod, setSelectedPeriod] = useState<string>('all');
  const [sortField, setSortField] = useState<keyof RecordItem>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const pageSize = 25;

  const records: RecordItem[] = datasetJson.records as RecordItem[];

  // Filter & Search Logic
  const filteredRecords = useMemo(() => {
    return records.filter((item) => {
      // Region Search
      const matchesSearch =
        searchTerm === '' ||
        item.region.toLowerCase().includes(searchTerm.toLowerCase());

      // Area Filter
      const matchesArea =
        selectedArea === 'all' || item.area.toLowerCase() === selectedArea.toLowerCase();

      // Period Filter
      const matchesPeriod =
        selectedPeriod === 'all' ||
        (selectedPeriod === 'pre' && !item.isPostCovid) ||
        (selectedPeriod === 'post' && item.isPostCovid);

      return matchesSearch && matchesArea && matchesPeriod;
    });
  }, [records, searchTerm, selectedArea, selectedPeriod]);

  // Sorting
  const sortedRecords = useMemo(() => {
    const list = [...filteredRecords];
    list.sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return sortOrder === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
      }
      return 0;
    });
    return list;
  }, [filteredRecords, sortField, sortOrder]);

  // Pagination
  const totalPages = Math.ceil(sortedRecords.length / pageSize) || 1;
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedRecords.slice(start, start + pageSize);
  }, [sortedRecords, currentPage, pageSize]);

  // Filtered Summary Stats
  const subsetStats = useMemo(() => {
    if (filteredRecords.length === 0) return null;
    const rates = filteredRecords.map((r) => r.unemploymentRate);
    const mean = rates.reduce((a, b) => a + b, 0) / rates.length;
    const min = Math.min(...rates);
    const max = Math.max(...rates);
    return {
      count: filteredRecords.length,
      mean: mean.toFixed(2),
      min: min.toFixed(2),
      max: max.toFixed(2),
    };
  }, [filteredRecords]);

  const handleSort = (field: keyof RecordItem) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const handleExportCsv = () => {
    const headers = [
      'ID',
      'Region',
      'Date',
      'Frequency',
      'Estimated Unemployment Rate (%)',
      'Estimated Employed',
      'Estimated Labour Participation Rate (%)',
      'Area',
      'Period',
    ];

    const rows = sortedRecords.map((r) => [
      r.id,
      `"${r.region}"`,
      r.date,
      r.frequency,
      r.unemploymentRate,
      r.employed,
      r.labourParticipation,
      r.area,
      r.isPostCovid ? 'Post-COVID' : 'Pre-COVID',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `unemployment_filtered_data_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header & Controls */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-200">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-blue-600">
              Clean Dataset Explorer
            </p>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 mt-1">
              740 Cleaned Monthly Observations
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Filter by State, Area, or COVID timeline. Click table headers to sort any column.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-xs cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              <span>Export Filtered CSV ({filteredRecords.length})</span>
            </button>
          </div>
        </div>

        {/* Filter Strip */}
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          {/* Search Region */}
          <div className="relative">
            <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Search Region / State
            </label>
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="e.g. Haryana, Bihar..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500 focus:bg-white"
              />
            </div>
          </div>

          {/* Area Filter */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Area Classification
            </label>
            <div className="flex items-center p-0.5 bg-slate-100 rounded-lg">
              {['all', 'rural', 'urban'].map((area) => (
                <button
                  key={area}
                  onClick={() => {
                    setSelectedArea(area);
                    setCurrentPage(1);
                  }}
                  className={`flex-1 py-1.5 text-xs font-medium rounded-md capitalize transition-colors cursor-pointer ${
                    selectedArea === area
                      ? 'bg-white text-slate-900 shadow-xs font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {area}
                </button>
              ))}
            </div>
          </div>

          {/* Period Filter */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Time Period
            </label>
            <div className="flex items-center p-0.5 bg-slate-100 rounded-lg">
              {[
                { id: 'all', label: 'All' },
                { id: 'pre', label: 'Pre-COVID' },
                { id: 'post', label: 'Post-COVID' },
              ].map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    setSelectedPeriod(p.id);
                    setCurrentPage(1);
                  }}
                  className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                    selectedPeriod === p.id
                      ? 'bg-white text-slate-900 shadow-xs font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Filter Stats Badge Strip */}
          <div className="flex flex-col justify-end">
            {subsetStats && (
              <div className="p-2 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-between text-xs font-mono">
                <span className="text-slate-500">Filtered Mean:</span>
                <span className="font-bold text-slate-900">
                  {subsetStats.mean}%
                </span>
                <span className="text-slate-400">·</span>
                <span className="text-slate-500">Min/Max:</span>
                <span className="font-medium text-slate-700">
                  {subsetStats.min}% / {subsetStats.max}%
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Data Table */}
        <div className="mt-6 bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/80 border-b border-slate-200 text-slate-600 uppercase tracking-wider text-[11px] font-semibold">
                <tr>
                  <th
                    onClick={() => handleSort('date')}
                    className="py-3 px-4 cursor-pointer hover:text-slate-900"
                  >
                    <div className="flex items-center gap-1">
                      <span>Date</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('region')}
                    className="py-3 px-4 cursor-pointer hover:text-slate-900"
                  >
                    <div className="flex items-center gap-1">
                      <span>State / Region</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('area')}
                    className="py-3 px-4 cursor-pointer hover:text-slate-900"
                  >
                    <div className="flex items-center gap-1">
                      <span>Area</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('unemploymentRate')}
                    className="py-3 px-4 text-right cursor-pointer hover:text-slate-900"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Unemployment Rate (%)</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('employed')}
                    className="py-3 px-4 text-right cursor-pointer hover:text-slate-900"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Employed (Persons)</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('labourParticipation')}
                    className="py-3 px-4 text-right cursor-pointer hover:text-slate-900"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Labour Part. (%)</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th className="py-3 px-4 text-center">Period</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono text-[12px]">
                {paginatedRecords.length > 0 ? (
                  paginatedRecords.map((row) => (
                    <tr
                      key={row.id}
                      className="hover:bg-slate-50/80 transition-colors"
                    >
                      <td className="py-2.5 px-4 text-slate-600 whitespace-nowrap">
                        {row.date}
                      </td>
                      <td className="py-2.5 px-4 font-sans font-medium text-slate-900 whitespace-nowrap">
                        {row.region}
                      </td>
                      <td className="py-2.5 px-4 font-sans text-slate-600 whitespace-nowrap">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium ${
                            row.area === 'Rural'
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-blue-50 text-blue-700'
                          }`}
                        >
                          {row.area}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-right font-bold tabular-nums">
                        <span
                          className={`${
                            row.unemploymentRate >= 20
                              ? 'text-rose-600'
                              : row.unemploymentRate >= 10
                              ? 'text-amber-600'
                              : 'text-slate-900'
                          }`}
                        >
                          {row.unemploymentRate.toFixed(2)}%
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-right text-slate-700 tabular-nums">
                        {row.employed.toLocaleString('en-IN')}
                      </td>
                      <td className="py-2.5 px-4 text-right text-slate-700 tabular-nums">
                        {row.labourParticipation.toFixed(2)}%
                      </td>
                      <td className="py-2.5 px-4 text-center whitespace-nowrap">
                        <span
                          className={`inline-block text-[11px] font-medium ${
                            row.isPostCovid
                              ? 'text-rose-600 font-bold'
                              : 'text-slate-500'
                          }`}
                        >
                          {row.isPostCovid ? 'Post-COVID' : 'Pre-COVID'}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan={7}
                      className="py-12 text-center text-slate-500 font-sans text-xs"
                    >
                      No records match the active search criteria.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination Footer */}
          <div className="px-4 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600 font-medium">
            <div>
              Showing{' '}
              <span className="font-mono tabular-nums font-bold text-slate-900">
                {Math.min(
                  (currentPage - 1) * pageSize + 1,
                  sortedRecords.length
                )}
              </span>{' '}
              to{' '}
              <span className="font-mono tabular-nums font-bold text-slate-900">
                {Math.min(currentPage * pageSize, sortedRecords.length)}
              </span>{' '}
              of{' '}
              <span className="font-mono tabular-nums font-bold text-slate-900">
                {sortedRecords.length}
              </span>{' '}
              entries
            </div>

            <div className="flex items-center gap-1">
              <button
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
                className="p-1.5 rounded border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <span className="px-2 font-mono tabular-nums">
                Page {currentPage} of {totalPages}
              </span>
              <button
                disabled={currentPage >= totalPages}
                onClick={() =>
                  setCurrentPage((p) => Math.min(p + 1, totalPages))
                }
                className="p-1.5 rounded border border-slate-300 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
