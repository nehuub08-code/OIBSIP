import React, { useState } from 'react';
import { Download, Copy, Check, Play, FileCode, ChevronDown, ChevronRight, BookOpen } from 'lucide-react';

interface NotebookSection {
  id: string;
  title: string;
  cellIndices: number[];
}

export const NotebookView: React.FC = () => {
  const [selectedSection, setSelectedSection] = useState<string>('all');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [collapsedCells, setCollapsedCells] = useState<Record<number, boolean>>({});

  const sections: NotebookSection[] = [
    { id: 'all', title: 'Full Notebook (All 10 Sections)', cellIndices: [] },
    { id: 'sec1', title: '1. Introduction & Research Questions', cellIndices: [0] },
    { id: 'sec2', title: '2. Import Libraries & Load Data', cellIndices: [1, 2, 3, 4] },
    { id: 'sec3', title: '3. Data Cleaning & Standardization', cellIndices: [5, 6, 7] },
    { id: 'sec4', title: '4. Exploratory Data Analysis (EDA)', cellIndices: [8, 9, 10, 11, 12, 13, 14, 15] },
    { id: 'sec5', title: '5. Time-Series Line Chart', cellIndices: [16, 17, 18] },
    { id: 'sec6', title: '6. Correlation Heatmap', cellIndices: [19, 20, 21] },
    { id: 'sec7', title: '7. Pre-COVID vs Post-COVID Comparison', cellIndices: [22, 23, 24] },
    { id: 'sec8', title: '8. Synthesis of Observations', cellIndices: [25] },
    { id: 'sec9', title: '9. Final Conclusion & Limitations', cellIndices: [26] },
    { id: 'sec10', title: '10. Internship Checklist & Git Commands', cellIndices: [27] },
  ];

  const notebookCells = [
    // Cell 0: Markdown Intro
    {
      type: 'markdown',
      content: `# Oasis Infobyte Data Science Internship (OIBSIP)
## Task 2: Unemployment Analysis with Python
**Author:** Data Science Intern | **Domain:** Econometric Exploratory Data Analysis
**Dataset Source:** Centre for Monitoring Indian Economy (CMIE) via Kaggle

### 1. Introduction & Background
Unemployment represents individuals in the active labor force seeking employment who cannot find work.
$$\\text{Unemployment Rate (\\%)} = \\left( \\frac{\\text{Unemployed Individuals}}{\\text{Active Labour Force}} \\right) \\times 100$$

**Research Questions:**
1. How does the average unemployment rate vary across Indian states?
2. How did monthly unemployment rates fluctuate from May 2019 to June 2020?
3. Which states experienced the highest mean unemployment rate?
4. How do unemployment rate, employed headcount, and labor force participation relate?
5. How do average unemployment rates differ between pre-COVID (< Mar 1, 2020) and post-COVID (>= Mar 1, 2020)?`,
    },
    // Cell 1: Section 2 Markdown
    {
      type: 'markdown',
      content: `### 2. Import Libraries and Load Data
Load pandas, numpy, matplotlib, and seaborn. The dataset is referenced using a configurable relative path \`data/Unemployment in India.csv\`.`,
    },
    // Cell 2: Code 1
    {
      type: 'code',
      executionCount: 1,
      source: `import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
pd.set_option('display.max_columns', 10)

DATA_PATH = os.path.join('data', 'Unemployment in India.csv')
raw_df = pd.read_csv(DATA_PATH)

print(f"Dataset loaded from: {DATA_PATH}")
print(f"Initial Dimensions: {raw_df.shape[0]} rows, {raw_df.shape[1]} columns")
print("Initial Column Names:\\n", raw_df.columns.tolist())`,
      output: `Dataset loaded from: data/Unemployment in India.csv
Initial Dimensions: 768 rows, 7 columns
Initial Column Names:
['Region', ' Date', ' Frequency', ' Estimated Unemployment Rate (%)', ' Estimated Employed', ' Estimated Labour Participation Rate (%)', 'Area']`,
    },
    // Cell 3: Code 2
    {
      type: 'code',
      executionCount: 2,
      source: `# Inspect head, data types, missing values, and duplicates
print("--- FIRST 5 ROWS ---")
print(raw_df.head())

print("\\n--- MISSING VALUES PER COLUMN ---")
print(raw_df.isnull().sum())
print(f"\\nTotal duplicate rows in raw dataset: {raw_df.duplicated().sum()}")`,
      output: `--- FIRST 5 ROWS ---
           Region         Date  Frequency   Estimated Unemployment Rate (%)   Estimated Employed   Estimated Labour Participation Rate (%)   Area
0  Andhra Pradesh   31-05-2019    Monthly                              3.65           11999139.0                                     43.24  Rural
1  Andhra Pradesh   30-06-2019    Monthly                              3.05           11755881.0                                     42.05  Rural
2  Andhra Pradesh   31-07-2019    Monthly                              3.75           12086707.0                                     43.50  Rural
3  Andhra Pradesh   31-08-2019    Monthly                              3.32           12285693.0                                     43.97  Rural
4  Andhra Pradesh   30-09-2019    Monthly                              5.17           12256762.0                                     44.68  Rural

--- MISSING VALUES PER COLUMN ---
Region                                      28
 Date                                       28
 Frequency                                  28
 Estimated Unemployment Rate (%)            28
 Estimated Employed                         28
 Estimated Labour Participation Rate (%)    28
Area                                        28
dtype: int64

Total duplicate rows in raw dataset: 27`,
    },
    // Cell 4: Markdown notes
    {
      type: 'markdown',
      content: `**Initial Observations:**
- Extra leading whitespace exists in column headers (\`' Date'\`, \`' Frequency'\`).
- Exactly 28 trailing rows have \`NaN\` across all fields (leaving 740 valid rows).
- Duplicate rows (27) represent repeated empty rows. No valid economic rows are duplicated.`,
    },
    // Cell 5: Section 3 Markdown
    {
      type: 'markdown',
      content: `### 3. Data Cleaning & Standardization
We strip whitespace from column headers and string values, drop the 28 all-null rows, convert \`Date\` with \`pd.to_datetime(..., dayfirst=True)\`, convert numeric fields with \`pd.to_numeric\`, and sort chronologically.`,
    },
    // Cell 6: Code 3
    {
      type: 'code',
      executionCount: 3,
      source: `df = raw_df.copy()
df.columns = df.columns.str.strip()

# Drop 28 trailing all-blank rows
initial_len = len(df)
df = df.dropna(how='all').copy()
print(f"Dropped {initial_len - len(df)} blank rows. Clean rows: {len(df)}")

# Clean text columns
for col in ['Region', 'Frequency', 'Area']:
    df[col] = df[col].astype(str).str.strip()

# Convert datetime and numeric types
df['Date'] = pd.to_datetime(df['Date'], dayfirst=True, errors='coerce')
numeric_cols = ['Estimated Unemployment Rate (%)', 'Estimated Employed', 'Estimated Labour Participation Rate (%)']
for col in numeric_cols:
    df[col] = pd.to_numeric(df[col], errors='coerce')

df = df.sort_values(by=['Date', 'Region', 'Area']).reset_index(drop=True)
print("\\n--- SUMMARY STATISTICS OF CLEAN DATA ---")
print(df[numeric_cols].describe().round(2))`,
      output: `Dropped 28 blank rows. Clean rows: 740

--- SUMMARY STATISTICS OF CLEAN DATA ---
       Estimated Unemployment Rate (%)  Estimated Employed  Estimated Labour Participation Rate (%)
count                           740.00               740.0                                   740.00
mean                             11.79           7204460.0                                    42.63
std                              10.72          10655780.0                                     8.11
min                               0.00             49420.0                                    13.33
25%                               4.66           1190404.0                                    38.06
50%                               8.35           4744178.0                                    41.16
75%                              15.89          11275490.0                                    45.51
max                              76.74          45777510.0                                    72.57`,
    },
    // Cell 7: Markdown notes
    {
      type: 'markdown',
      content: `**Cleaning Summary:**
- Valid observations: 740 across 28 states/UTs.
- Overall mean unemployment: 11.79% (std: 10.72%, min: 0.00%, max: 76.74%).
- \`Estimated Employed\` is an absolute count (mean: 7.20 million persons), NOT an employment rate percentage.`,
    },
    // Cell 8: Section 4A Markdown
    {
      type: 'markdown',
      content: `### 4A. Region-wise Average Unemployment Rate
Calculate mean unemployment across all 28 states and union territories.`,
    },
    // Cell 9: Code 4
    {
      type: 'code',
      executionCount: 4,
      source: `region_stats = df.groupby('Region')['Estimated Unemployment Rate (%)'].agg(
    Mean_Unemployment_Rate='mean',
    Std_Dev='std',
    Count='count'
).sort_values(by='Mean_Unemployment_Rate', ascending=False)

print("Top 5 and Bottom 5 Regions:")
print(pd.concat([region_stats.head(5), region_stats.tail(5)]).round(2))`,
      output: `Top 5 and Bottom 5 Regions:
                  Mean_Unemployment_Rate  Std_Dev  Count
Region                                                  
Tripura                            28.35    10.63     28
Haryana                            26.28    11.37     28
Jharkhand                          20.58    18.59     28
Bihar                              18.92    13.56     28
Himachal Pradesh                   18.54     9.59     28
Gujarat                             6.66     4.91     28
Uttarakhand                         6.58     4.84     27
Assam                               6.43     3.78     26
Odisha                              5.66     4.44     28
Meghalaya                           4.80     4.40     27`,
    },
    // Cell 10: Markdown notes
    {
      type: 'markdown',
      content: `**Observation:**
Tripura (28.35%) and Haryana (26.28%) record the highest average rates. Meghalaya (4.80%), Odisha (5.66%), and Assam (6.43%) report the lowest rates.`,
    },
    // Cell 11: Section 4B Markdown
    {
      type: 'markdown',
      content: `### 4B. Month-wise Unemployment Trends
Calculate national monthly averages using datetime Year-Month periods.`,
    },
    // Cell 12: Code 5
    {
      type: 'code',
      executionCount: 5,
      source: `df['YearMonth'] = df['Date'].dt.to_period('M')
monthly_summary = df.groupby('YearMonth')['Estimated Unemployment Rate (%)'].agg(
    Monthly_Mean='mean',
    Count='count'
).reset_index()

print(monthly_summary.round(2))`,
      output: `   YearMonth  Monthly_Mean  Count
0    2019-05          8.87     54
1    2019-06          9.30     54
2    2019-07          9.03     54
3    2019-08          9.64     53
4    2019-09          9.05     52
5    2019-10          9.90     55
6    2019-11          9.87     55
7    2019-12          9.50     53
8    2020-01          9.95     53
9    2020-02          9.96     53
10   2020-03         10.70     52
11   2020-04         23.64     51
12   2020-05         24.88     51
13   2020-06         11.90     50`,
    },
    // Cell 13: Markdown notes
    {
      type: 'markdown',
      content: `**Monthly Trend Insight:**
Rates hovered predictably between 8.87% and 9.96% throughout 2019. In April and May 2020, during strict nationwide lockdowns, the average rate spiked to **23.64%** and **24.88%** respectively. As economic reopening ('Unlock 1.0') began in June 2020, the rate fell sharply back to **11.90%**.`,
    },
    // Cell 14: Section 4C Markdown
    {
      type: 'markdown',
      content: `### 4C. Top 10 States Horizontal Bar Chart
Visualizing the top 10 states by average rate, saved to \`outputs/top_10_states.png\`.`,
    },
    // Cell 15: Code 6
    {
      type: 'code',
      executionCount: 6,
      source: `top_10_states = region_stats.head(10)['Mean_Unemployment_Rate'].sort_values(ascending=True)

fig, ax = plt.subplots(figsize=(10, 6), dpi=300)
bars = ax.barh(top_10_states.index, top_10_states.values, color='#0284c7', edgecolor='#0369a1', height=0.65)
ax.set_title('Top 10 States by Average Unemployment Rate', fontsize=13, fontweight='bold', pad=14)
ax.set_xlabel('Average Estimated Unemployment Rate (%)')
for bar in bars:
    w = bar.get_width()
    ax.text(w + 0.35, bar.get_y() + bar.get_height()/2, f'{w:.2f}%', va='center', fontweight='bold', fontsize=9.5)
ax.set_xlim(0, max(top_10_states.values) + 3.5)
plt.tight_layout()
os.makedirs('outputs', exist_ok=True)
fig.savefig('outputs/top_10_states.png', dpi=300)
plt.show()`,
      imageSrc: '/outputs/top_10_states.png',
      output: `Figure successfully saved to outputs/top_10_states.png`,
    },
    // Cell 16: Section 5 Markdown
    {
      type: 'markdown',
      content: `### 5. Multi-State Time-Series Line Chart
Plotting Haryana, Bihar, Maharashtra, and Tamil Nadu over time with a COVID-19 cutoff reference line (March 2020). Saved to \`outputs/unemployment_trends.png\`.`,
    },
    // Cell 17: Code 7
    {
      type: 'code',
      executionCount: 7,
      source: `selected_states = ['Haryana', 'Bihar', 'Maharashtra', 'Tamil Nadu']
subset = df[df['Region'].isin(selected_states)].copy()
state_monthly = subset.groupby(['Date', 'Region'])['Estimated Unemployment Rate (%)'].mean().reset_index()

fig, ax = plt.subplots(figsize=(12, 6), dpi=300)
colors = {'Haryana': '#dc2626', 'Bihar': '#d97706', 'Maharashtra': '#2563eb', 'Tamil Nadu': '#059669'}
for s in selected_states:
    s_df = state_monthly[state_monthly['Region'] == s]
    ax.plot(s_df['Date'], s_df['Estimated Unemployment Rate (%)'], marker='o', linewidth=2.2, label=s, color=colors[s])

ax.axvline(pd.to_datetime('2020-03-01'), color='#475569', linestyle='--', linewidth=1.5, label='COVID-19 Onset (Mar 2020)')
ax.axvspan(pd.to_datetime('2020-03-01'), df['Date'].max(), color='#fee2e2', alpha=0.35, label='Post-COVID Shock')
ax.set_title('Monthly Unemployment Rate Trends Across Major Indian States (2019 - 2020)', fontsize=14, fontweight='bold', pad=15)
ax.set_ylabel('Estimated Unemployment Rate (%)')
ax.legend(loc='upper left', frameon=True)
plt.tight_layout()
fig.savefig('outputs/unemployment_trends.png', dpi=300)
plt.show()`,
      imageSrc: '/outputs/unemployment_trends.png',
      output: `Figure successfully saved to outputs/unemployment_trends.png`,
    },
    // Cell 18: Markdown notes
    {
      type: 'markdown',
      content: `**Observation on Selected States:**
All four states experienced simultaneous, extreme jumps in April 2020 (Tamil Nadu peaked at 49.8%, Bihar at 46.6%, Haryana at 43.3%, Maharashtra at 20.9%). Rebounding capacity differed, with Tamil Nadu recovering to 13.7% by June 2020 while Haryana remained elevated at 33.6%.`,
    },
    // Cell 19: Section 6 Markdown
    {
      type: 'markdown',
      content: `### 6. Correlation Heatmap
Computing Pearson correlation among Unemployment Rate, Employed count, and Labour Participation Rate. Saved to \`outputs/correlation_heatmap.png\`.`,
    },
    // Cell 20: Code 8
    {
      type: 'code',
      executionCount: 8,
      source: `corr_vars = ['Estimated Unemployment Rate (%)', 'Estimated Employed', 'Estimated Labour Participation Rate (%)']
rename_dict = {
    'Estimated Unemployment Rate (%)': 'Unemployment Rate (%)',
    'Estimated Employed': 'Employed Count (Persons)',
    'Estimated Labour Participation Rate (%)': 'Labour Participation (%)'
}
corr_data = df[corr_vars].rename(columns=rename_dict).corr()

fig, ax = plt.subplots(figsize=(8, 6), dpi=300)
sns.heatmap(corr_data, annot=True, fmt='.3f', cmap='coolwarm', vmin=-0.3, vmax=1.0, linewidths=1.2, ax=ax)
ax.set_title('Correlation Heatmap: Unemployment, Employment Count & Labour Participation', fontsize=12, fontweight='bold')
plt.tight_layout()
fig.savefig('outputs/correlation_heatmap.png', dpi=300)
plt.show()`,
      imageSrc: '/outputs/correlation_heatmap.png',
      output: `Figure successfully saved to outputs/correlation_heatmap.png`,
    },
    // Cell 21: Markdown notes
    {
      type: 'markdown',
      content: `**Correlation Insights:**
- Unemployment rate vs. Employed headcount: $r = -0.223$ (moderate negative association).
- Unemployment rate vs. Labour Participation: $r = +0.003$ (zero cross-sectional linear relationship).
- **Limitation:** Correlation does not prove causation, and headcount is strongly influenced by state population size.`,
    },
    // Cell 22: Section 7 Markdown
    {
      type: 'markdown',
      content: `### 7. Pre-COVID versus Post-COVID Comparison
Cutoff at March 1, 2020:
- Pre-COVID: May 2019 – Feb 2020 (536 observations).
- Post-COVID: Mar 2020 – Jun 2020 (204 observations).`,
    },
    // Cell 23: Code 9
    {
      type: 'code',
      executionCount: 9,
      source: `df['Period'] = np.where(df['Date'] < '2020-03-01', 'Pre-COVID (May 19 - Feb 20)', 'Post-COVID (Mar 20 - Jun 20)')
pre_post = df.groupby('Period')['Estimated Unemployment Rate (%)'].agg(
    Observations='count',
    Mean='mean',
    Std='std',
    Median='median'
).loc[['Pre-COVID (May 19 - Feb 20)', 'Post-COVID (Mar 20 - Jun 20)']]

pre_m = pre_post.loc['Pre-COVID (May 19 - Feb 20)', 'Mean']
post_m = pre_post.loc['Post-COVID (Mar 20 - Jun 20)', 'Mean']
diff_pp = post_m - pre_m
pct_chg = (diff_pp / pre_m) * 100

print(pre_post.round(2))
print(f"\\nAbsolute Difference: +{diff_pp:.2f} percentage points")
print(f"Relative Percentage Change: +{pct_chg:.2f}%")`,
      output: `                              Observations   Mean    Std  Median
Period                                                          
Pre-COVID (May 19 - Feb 20)            536   9.51   7.75    7.19
Post-COVID (Mar 20 - Jun 20)           204  17.77  14.93   14.07

Absolute Difference: +8.26 percentage points
Relative Percentage Change: +86.91%`,
    },
    // Cell 24: Markdown notes
    {
      type: 'markdown',
      content: `**Comparison Summary:**
- Mean unemployment increased from **9.51%** pre-COVID to **17.77%** post-COVID (+8.26 pp, +86.91%).
- Standard deviation nearly doubled from 7.75% to 14.93%, demonstrating sharp regional polarization.`,
    },
    // Cell 25: Section 8 Markdown
    {
      type: 'markdown',
      content: `### 8. Synthesis of Written Observations
Structured 4-part summaries were documented after each chart examining Descriptions, Observed Values, Implications, and Limitations.`,
    },
    // Cell 26: Section 9 Markdown
    {
      type: 'markdown',
      content: `### 9. Final Conclusion & Limitations
1. **Regional Asymmetry:** States with industrial migrant reliance (Bihar, Jharkhand) and high youth unemployment (Haryana, Tripura) faced the steepest challenges.
2. **Lockdown Shock & Unlock Rebound:** The national lockdown triggered an immediate spike to ~24% in April–May 2020, followed by a swift rebound to ~12% in June 2020.
3. **Macroeconomic Insights:** Higher unemployment aligned with fewer employed individuals ($r = -0.223$), while labor participation rates remained relatively constant ($r = +0.003$).
4. **Limitations:** 4-month post-lockdown window vs 10-month baseline; correlation is not causation; unweighted averages.`,
    },
    // Cell 27: Section 10 Checklist Markdown
    {
      type: 'markdown',
      content: `### 10. Internship Checklist & Git Submission Commands

**Checklist:**
- [x] Dataset obtained from suitable source (CMIE / Kaggle)
- [x] Data loaded and shape inspected (768 -> 740 rows)
- [x] Missing values checked and types converted
- [x] Region-wise averages calculated
- [x] Month-wise trends calculated
- [x] Time-series line chart created for 4 diverse states
- [x] Top 10 states horizontal bar chart generated
- [x] Correlation heatmap created
- [x] Pre-COVID and post-COVID means compared (+8.26 pp, +86.91%)
- [x] Written observations included after every chart
- [x] Clean and commented Python code
- [x] Complete README.md and requirements.txt
- [x] Charts saved in outputs folder
- [x] Notebook executed successfully from beginning to end

\`\`\`bash
# Local Execution:
cd OIBSIP/DataScience/Task2_Unemployment_Analysis/
pip install -r requirements.txt
jupyter notebook Unemployment_Analysis.ipynb

# Git Staging:
git add OIBSIP/DataScience/Task2_Unemployment_Analysis/
git commit -m "feat(oibsip-task2): complete unemployment analysis notebook, eda charts, and documentation"
\`\`\``,
    },
  ];

  const handleCopyCode = (code: string, index: number) => {
    navigator.clipboard.writeText(code);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const toggleCollapse = (index: number) => {
    setCollapsedCells((prev) => ({ ...prev, [index]: !prev[index] }));
  };

  const displayedCells =
    selectedSection === 'all'
      ? notebookCells
      : notebookCells.filter((_, idx) => {
          const sec = sections.find((s) => s.id === selectedSection);
          return sec ? sec.cellIndices.includes(idx) : true;
        });

  return (
    <div className="py-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Bar */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/10 text-amber-600 rounded-xl">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">
                  Unemployment_Analysis.ipynb
                </h2>
                <span className="text-xs px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded font-mono font-medium border border-emerald-200">
                  Kernel: Python 3 (ipykernel) · Executed
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                OIBSIP/DataScience/Task2_Unemployment_Analysis/ · 30 Pristine Cells
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <a
              href="/notebooks/Unemployment_Analysis.ipynb"
              download="Unemployment_Analysis.ipynb"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .ipynb (1.6 MB)</span>
            </a>
          </div>
        </div>

        {/* Section Navigation Tabs */}
        <div className="mt-4 flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
          {sections.map((sec) => (
            <button
              key={sec.id}
              onClick={() => setSelectedSection(sec.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                selectedSection === sec.id
                  ? 'bg-slate-900 text-white'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {sec.title}
            </button>
          ))}
        </div>

        {/* Notebook Cells Container */}
        <div className="mt-6 space-y-4">
          {displayedCells.map((cell, idx) => {
            const isCollapsed = collapsedCells[idx];
            return (
              <div
                key={idx}
                className="bg-white border border-slate-200/90 rounded-xl overflow-hidden shadow-xs"
              >
                {cell.type === 'markdown' ? (
                  <div className="p-5 text-slate-800 leading-relaxed text-sm prose max-w-none">
                    <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed text-slate-700 bg-transparent p-0 border-0">
                      {cell.content}
                    </pre>
                  </div>
                ) : (
                  <div>
                    {/* Code Cell Header */}
                    <div className="px-4 py-2 bg-slate-100/70 border-b border-slate-200 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2 text-slate-600 font-mono text-[11px]">
                        <button
                          onClick={() => toggleCollapse(idx)}
                          className="p-1 hover:bg-slate-200 rounded text-slate-500 cursor-pointer"
                        >
                          {isCollapsed ? (
                            <ChevronRight className="w-3.5 h-3.5" />
                          ) : (
                            <ChevronDown className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <span className="text-blue-600 font-bold">
                          In [{cell.executionCount}]:
                        </span>
                        <span className="text-slate-400">Python 3</span>
                      </div>
                      <button
                        onClick={() => handleCopyCode(cell.source || '', idx)}
                        className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-600 hover:text-slate-900 px-2 py-0.5 rounded hover:bg-slate-200 transition-colors cursor-pointer"
                      >
                        {copiedIndex === idx ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-600" />
                            <span className="text-emerald-600">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy Code</span>
                          </>
                        )}
                      </button>
                    </div>

                    {!isCollapsed && (
                      <>
                        {/* Code Input */}
                        <div className="p-4 bg-slate-900 text-slate-100 font-mono text-xs overflow-x-auto">
                          <pre className="leading-relaxed whitespace-pre font-mono">
                            {cell.source}
                          </pre>
                        </div>

                        {/* Cell Outputs */}
                        {cell.output && (
                          <div className="p-4 bg-slate-50 border-t border-slate-200 font-mono text-xs text-slate-800 overflow-x-auto">
                            <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                              Out [{cell.executionCount}]:
                            </span>
                            <pre className="whitespace-pre-wrap leading-relaxed text-slate-700">
                              {cell.output}
                            </pre>
                          </div>
                        )}

                        {/* Optional Inline Figure */}
                        {cell.imageSrc && (
                          <div className="p-4 bg-white border-t border-slate-200 flex flex-col items-center">
                            <img
                              src={cell.imageSrc}
                              alt="Cell output plot"
                              className="max-h-[380px] w-auto object-contain rounded border border-slate-200 shadow-xs"
                            />
                            <span className="text-[11px] text-slate-400 font-mono mt-2">
                              Inline Visual Output from Cell [{cell.executionCount}]
                            </span>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
