import React, { useState } from 'react';
import { Download, Maximize2, X, Info, TrendingUp, BarChart3, Grid, GitCompare } from 'lucide-react';

interface VisualCard {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  imageSrc: string;
  fileName: string;
  description: string;
  observedValues: string;
  implication: string;
  limitation: string;
  stats: { label: string; value: string }[];
}

export const VisualizationsView: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [modalImage, setModalImage] = useState<VisualCard | null>(null);

  const visualCards: VisualCard[] = [
    {
      id: 'trends',
      title: 'Monthly Unemployment Rate Trends Across Major Indian States',
      subtitle: 'Comparative time-series line chart tracking Haryana, Bihar, Maharashtra, and Tamil Nadu (May 2019 – June 2020)',
      category: 'time-series',
      imageSrc: '/outputs/unemployment_trends.png',
      fileName: 'unemployment_trends.png',
      stats: [
        { label: 'Baseline Average', value: '~9.5%' },
        { label: 'Apr 2020 Shock', value: '23.64%' },
        { label: 'May 2020 Peak', value: '24.88%' },
        { label: 'Jun 2020 Rebound', value: '11.90%' },
      ],
      description:
        'This multi-line time-series graph illustrates monthly unemployment rate shifts across four geographically and structurally distinct Indian states: Haryana (North), Bihar (East), Maharashtra (West), and Tamil Nadu (South). A vertical dashed line and shaded pink band distinguish the pre-COVID period from the post-lockdown period starting in March 2020.',
      observedValues:
        'Prior to March 2020, Maharashtra and Tamil Nadu maintained steady, low rates between 4.0% and 7.0%, while Bihar remained near 10%–15% and Haryana hovered between 20% and 30%. In April 2020, Tamil Nadu spiked dramatically from 6.4% to 49.8%, Bihar jumped from 14.4% to 46.6%, and Haryana reached 43.3%. In June 2020 (Unlock 1.0), Tamil Nadu and Maharashtra recovered rapidly to 13.7% and 10.4% respectively, while Haryana remained high at 33.6%.',
      implication:
        'The national lockdown exerted an immediate and severe shock across all geographical regions, but southern and western manufacturing/service hubs displayed faster labor re-absorption capabilities upon reopening than northern states with higher structural unemployment.',
      limitation:
        'These lines represent combined state-wide averages (rural plus urban). Localized agrarian harvest schedules and urban informal migrant dynamics may experience distinct micro-cycles not fully visible in aggregated monthly figures.',
    },
    {
      id: 'top10',
      title: 'Top 10 States/Regions by Average Unemployment Rate',
      subtitle: 'Sorted horizontal bar chart highlighting regions with the highest sustained mean unemployment rates',
      category: 'regional',
      imageSrc: '/outputs/top_10_states.png',
      fileName: 'top_10_states.png',
      stats: [
        { label: 'Tripura (Rank 1)', value: '28.35%' },
        { label: 'Haryana (Rank 2)', value: '26.28%' },
        { label: 'Jharkhand (Rank 3)', value: '20.58%' },
        { label: 'Bihar (Rank 4)', value: '18.92%' },
      ],
      description:
        'A horizontal bar chart identifying the 10 Indian states and union territories recording the highest mean unemployment rates across the full 14-month surveyed window. Direct percentage value annotations are attached to each bar.',
      observedValues:
        'Tripura leads the country with a 28.35% mean unemployment rate, closely followed by Haryana at 26.28%, Jharkhand at 20.58%, Bihar at 18.92%, and Himachal Pradesh at 18.54%. Delhi (16.50%), Jammu & Kashmir (16.19%), Chandigarh (15.99%), Rajasthan (14.06%), and Uttar Pradesh (12.55%) complete the top 10.',
      implication:
        'High average unemployment is disproportionately concentrated across northern states experiencing high educated-youth job-seeking ratios and eastern states with severe migrant worker displacement.',
      limitation:
        'The dataset groups full federated states together with municipal Union Territories (e.g., Chandigarh with 12 observations vs. 28 for states). Urban city-states possess entirely distinct employment structures compared to large agricultural states.',
    },
    {
      id: 'correlation',
      title: 'Correlation Heatmap: Unemployment, Employment & Participation',
      subtitle: 'Annotated Pearson correlation matrix among key labor market variables',
      category: 'econometric',
      imageSrc: '/outputs/correlation_heatmap.png',
      fileName: 'correlation_heatmap.png',
      stats: [
        { label: 'Unemp vs Employed', value: 'r = -0.223' },
        { label: 'Unemp vs Labour Part', value: 'r = +0.003' },
        { label: 'Employed vs Part', value: 'r = +0.011' },
      ],
      description:
        'An annotated Seaborn heatmap computing Pearson correlation coefficients across three continuous metrics: Estimated Unemployment Rate (%), Estimated Employed (count of persons), and Estimated Labour Participation Rate (%).',
      observedValues:
        'Unemployment rate has a moderate negative correlation with employed count (r = -0.223). The correlation between unemployment rate and labor participation rate is practically non-existent (r = +0.003), as is the correlation between employed count and labor participation (r = +0.011).',
      implication:
        'The negative correlation confirms that higher unemployment periods align with significant absolute reductions in employed worker counts. However, cross-state labor force participation rates appear structural and largely invariant to short-term changes in measured unemployment.',
      limitation:
        'CRITICAL SCHEMA CAVEAT: "Estimated Employed" is an absolute headcount count (persons), NOT an employment rate. Cross-state headcount is inherently confounded by underlying state population size (e.g. Uttar Pradesh vs. Sikkim). Correlation does not imply causation.',
    },
    {
      id: 'prepost',
      title: 'Pre-COVID vs. Post-COVID Econometric Shift',
      subtitle: 'Dual-panel comparison of overall national averages and top 7 impacted states',
      category: 'covid-impact',
      imageSrc: '/outputs/pre_post_covid_comparison.png',
      fileName: 'pre_post_covid_comparison.png',
      stats: [
        { label: 'Pre-COVID Mean', value: '9.51%' },
        { label: 'Post-COVID Mean', value: '17.77%' },
        { label: 'Absolute Surge', value: '+8.26 pp' },
        { label: 'Relative Jump', value: '+86.91%' },
      ],
      description:
        'A dual-panel comparative figure using March 1, 2020 as the analytical boundary. The left panel shows overall pre-COVID (May 2019 – Feb 2020, n=536) versus post-COVID (Mar 2020 – Jun 2020, n=204) mean unemployment with standard error bars. The right panel isolates the 7 states suffering the greatest rate expansions.',
      observedValues:
        'The nationwide average rate surged from 9.51% pre-COVID to 17.77% post-COVID (+8.26 percentage points, +86.91% increase). Standard deviation nearly doubled from 7.75% to 14.93%. States suffering the highest post-COVID surges include Puducherry (+21.94 pp), Jharkhand (+19.14 pp), Bihar (+16.92 pp), Tamil Nadu (+13.68 pp), and Haryana (+13.61 pp).',
      implication:
        'The pandemic shock introduced both an enormous central upward shift in unemployment and acute regional divergence, exposing differing vulnerabilities in state economies.',
      limitation:
        'The March 1, 2020 cutoff is an analytical convention. The post-COVID period is 4 months (incorporating the massive April–May lockdown trough), whereas pre-COVID spans 10 months. These factors mean the difference cannot be interpreted as a purely causal treatment effect.',
    },
  ];

  const filteredCards =
    activeCategory === 'all'
      ? visualCards
      : visualCards.filter((c) => c.category === activeCategory);

  const handleDownload = (fileName: string) => {
    const link = document.createElement('a');
    link.href = `/outputs/${fileName}`;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-200">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-blue-600">
              Publication Outputs
            </p>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 mt-1">
              Core Econometric Visualizations
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              High-resolution 300 DPI analytical figures generated from the executed Jupyter notebook, 
              paired with strict 4-part empirical interpretations.
            </p>
          </div>

          {/* Category Filter Controls */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg shrink-0">
            {[
              { id: 'all', label: 'All Figures' },
              { id: 'time-series', label: 'Time-Series' },
              { id: 'regional', label: 'Top 10 States' },
              { id: 'econometric', label: 'Correlation' },
              { id: 'covid-impact', label: 'COVID-19 Shift' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveCategory(tab.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                  activeCategory === tab.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Visual Cards Grid */}
        <div className="mt-8 space-y-12">
          {filteredCards.map((card, idx) => (
            <div
              key={card.id}
              className="bg-white border border-slate-200/90 rounded-2xl overflow-hidden shadow-xs hover:border-slate-300 transition-all"
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
                {/* Visual Image Frame (7 cols) */}
                <div className="lg:col-span-7 bg-slate-950/5 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-200">
                  <div className="p-4 sm:p-6 flex items-center justify-center bg-white min-h-[380px]">
                    <img
                      src={card.imageSrc}
                      alt={card.title}
                      referrerPolicy="no-referrer"
                      className="max-h-[460px] w-auto object-contain rounded-lg transition-transform hover:scale-[1.01]"
                    />
                  </div>

                  {/* Image Toolbar */}
                  <div className="px-5 py-3 bg-slate-50 border-t border-slate-200/70 flex items-center justify-between">
                    <span className="text-xs text-slate-500 font-mono">
                      outputs/{card.fileName} · 300 DPI
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setModalImage(card)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded hover:bg-slate-100 transition-colors cursor-pointer"
                        title="View Fullscreen"
                      >
                        <Maximize2 className="w-3.5 h-3.5" />
                        <span>Enlarge</span>
                      </button>
                      <button
                        onClick={() => handleDownload(card.fileName)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-white bg-slate-900 rounded hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Download High-Res PNG"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download PNG</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Structured 4-Part Written Observation (5 cols) */}
                <div className="lg:col-span-5 p-5 sm:p-7 flex flex-col justify-between bg-white">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600">
                      Figure 0{idx + 1} Analysis
                    </span>
                    <h3 className="text-lg font-bold text-slate-900 mt-1 leading-snug">
                      {card.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">
                      {card.subtitle}
                    </p>

                    {/* Quick Stats Grid */}
                    <div className="grid grid-cols-2 gap-2 mt-4 pt-4 border-t border-slate-100">
                      {card.stats.map((st, i) => (
                        <div key={i} className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                          <span className="block text-[11px] text-slate-500 font-medium">
                            {st.label}
                          </span>
                          <span className="block text-sm font-bold text-slate-900 font-mono tabular-nums mt-0.5">
                            {st.value}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* 4-Part Analysis Cells */}
                    <div className="mt-5 space-y-3.5 text-xs">
                      <div>
                        <span className="font-bold text-slate-900 block mb-0.5">
                          1. What the Figure Shows:
                        </span>
                        <p className="text-slate-600 leading-relaxed">
                          {card.description}
                        </p>
                      </div>

                      <div>
                        <span className="font-bold text-slate-900 block mb-0.5">
                          2. Observed Empirical Values:
                        </span>
                        <p className="text-slate-600 leading-relaxed font-mono text-[11.5px]">
                          {card.observedValues}
                        </p>
                      </div>

                      <div>
                        <span className="font-bold text-slate-900 block mb-0.5">
                          3. Macroeconomic Implication:
                        </span>
                        <p className="text-slate-600 leading-relaxed">
                          {card.implication}
                        </p>
                      </div>

                      <div>
                        <span className="font-bold text-amber-900 block mb-0.5">
                          4. Analytical Limitation:
                        </span>
                        <p className="text-slate-600 leading-relaxed bg-amber-50/60 p-2 rounded border border-amber-200/50">
                          {card.limitation}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal Fullscreen View */}
        {modalImage && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
            <div className="relative bg-white rounded-2xl max-w-5xl w-full max-h-[92vh] overflow-hidden flex flex-col shadow-2xl">
              <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm sm:text-base">
                    {modalImage.title}
                  </h4>
                  <span className="text-xs text-slate-500 font-mono">
                    outputs/{modalImage.fileName}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleDownload(modalImage.fileName)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                  <button
                    onClick={() => setModalImage(null)}
                    className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                    title="Close"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
              <div className="p-6 overflow-auto flex items-center justify-center bg-slate-50">
                <img
                  src={modalImage.imageSrc}
                  alt={modalImage.title}
                  className="max-h-[70vh] w-auto object-contain rounded-lg shadow-sm"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
