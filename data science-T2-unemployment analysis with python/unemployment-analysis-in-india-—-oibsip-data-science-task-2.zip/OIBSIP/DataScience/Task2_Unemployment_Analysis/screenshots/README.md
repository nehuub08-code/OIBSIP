# Project Screenshots & Visual Evidence

This directory is reserved for capturing and archiving screenshots of the executed Jupyter Notebook, interactive visual exploration, and internship verification reports.

---

## Generated Visualizations & Artifacts

All high-resolution visualization charts generated from the executed notebook are saved in the parent directory under `outputs/`:

1. `outputs/unemployment_trends.png`: Monthly time-series line chart comparing key states (Haryana, Bihar, Maharashtra, Tamil Nadu) before and after the COVID-19 nationwide lockdown.
2. `outputs/top_10_states.png`: Horizontal bar chart displaying the top 10 Indian states with the highest mean unemployment rate.
3. `outputs/correlation_heatmap.png`: Pearson correlation matrix among unemployment rate, employment headcount, and labor participation rate.
4. `outputs/pre_post_covid_comparison.png`: Dual-panel comparative analysis showing overall pre-COVID vs. post-COVID shift (+8.26 percentage points, +86.9% jump) alongside state-by-state surges.

---

## Instructions for Capturing Additional Notebook Execution Screenshots

When submitting this project for the Oasis Infobyte Data Science Internship evaluation:

1. Launch Jupyter Notebook:
   ```bash
   jupyter notebook OIBSIP/DataScience/Task2_Unemployment_Analysis/Unemployment_Analysis.ipynb
   ```
2. Run all cells (`Kernel` > `Restart & Run All`).
3. Take full-page or cell-specific screenshots of:
   - Section 2 & 3: Data loading and cleaning outputs showing `(740, 7)` shape after dropping null rows.
   - Section 4 & 5: Rendered Matplotlib / Seaborn figures inline with interpretation markdown.
   - Section 7 & 10: Pre vs. Post COVID summary and Internship Evaluation Checklist.
4. Save the screenshot images inside this `screenshots/` directory (e.g., `screenshots/notebook_execution_overview.png`).
