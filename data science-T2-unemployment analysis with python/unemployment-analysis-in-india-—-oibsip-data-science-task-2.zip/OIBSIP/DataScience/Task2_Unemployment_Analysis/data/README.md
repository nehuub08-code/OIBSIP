# Dataset Documentation: Unemployment in India

This directory contains the dataset used for **Oasis Infobyte (OIBSIP) Data Science Internship Task 2: Unemployment Analysis with Python**.

---

## 1. Dataset Provenance & Attribution

- **Dataset Title:** Unemployment in India
- **Platform:** [Kaggle](https://www.kaggle.com/datasets/gokulrajkmv/unemployment-in-india)
- **Dataset Author / Uploader:** Gokul Raj Kuppan (`gokulrajkmv`)
- **Original Source Agency:** Centre for Monitoring Indian Economy (CMIE)
- **Retrieval Date:** October 2026
- **License / Terms of Use:** Released on Kaggle under Open Data Community terms for research, educational, and analytical practice. Redistribution terms are subject to Kaggle and CMIE data guidelines; if uploading to an external public repository, it is recommended to keep raw data local and follow download instructions below.

---

## 2. File Information

- **Filename:** `Unemployment in India.csv`
- **Total Initial Rows:** 768 rows
- **Data Rows:** 740 valid monthly observations across Indian States & Union Territories
- **Trailing Blank Rows:** 28 rows containing null/empty values at the end of the file (dropped during data cleaning)
- **Total Columns:** 7
- **Time Coverage:** May 31, 2019 to June 30, 2020 (14 monthly reporting cycles)

---

## 3. Schema & Column Definitions

| Raw CSV Column Header | Standardized Name | Data Type | Description |
| :--- | :--- | :--- | :--- |
| `Region` | `Region` | String | Name of the Indian State or Union Territory (e.g., Andhra Pradesh, Bihar, Maharashtra, Tamil Nadu). |
| ` Date` | `Date` | Datetime (`%d-%m-%Y`) | Date of observation (recorded on the last day of each calendar month). |
| ` Frequency` | `Frequency` | String | Frequency of observation collection (Monthly / M). |
| ` Estimated Unemployment Rate (%)` | `Estimated Unemployment Rate (%)` | Float (Numeric) | Estimated percentage of the active labor force that is unemployed and actively seeking work. |
| ` Estimated Employed` | `Estimated Employed` | Float / Int (Numeric) | Estimated count of gainfully employed individuals in the specified region and area. |
| ` Estimated Labour Participation Rate (%)` | `Estimated Labour Participation Rate (%)` | Float (Numeric) | Estimated percentage of the working-age population participating in the labor force (employed + unemployed). |
| `Area` | `Area` | String | Geographical classification sector: `Rural` or `Urban`. |

> **Crucial Data Note on `Estimated Employed`:**  
> In this dataset, `Estimated Employed` represents an **absolute headcount count of employed persons**, NOT an employment rate or percentage. It is not relabeled as "employment rate" to preserve analytical integrity.

---

## 4. Manual Download Instructions

If the dataset CSV is not present in this folder:

1. Visit Kaggle at [https://www.kaggle.com/datasets/gokulrajkmv/unemployment-in-india](https://www.kaggle.com/datasets/gokulrajkmv/unemployment-in-india).
2. Sign in to your Kaggle account.
3. Click the **Download** button (top right of the dataset header) to download `archive.zip`.
4. Extract `archive.zip`.
5. Locate the file named `Unemployment in India.csv`.
6. Copy or move `Unemployment in India.csv` directly into this folder:
   ```bash
   cp ~/Downloads/Unemployment\ in\ India.csv OIBSIP/DataScience/Task2_Unemployment_Analysis/data/
   ```
7. Verify file location:
   ```bash
   head -n 5 "OIBSIP/DataScience/Task2_Unemployment_Analysis/data/Unemployment in India.csv"
   ```
