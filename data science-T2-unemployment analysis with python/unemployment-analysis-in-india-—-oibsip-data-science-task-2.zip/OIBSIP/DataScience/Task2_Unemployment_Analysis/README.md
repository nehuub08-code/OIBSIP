# Unemployment Analysis with Python — OIBSIP Data Science Internship (Task 2)

![Python](https://img.shields.io/badge/Python-3.10+-3776AB?style=flat&logo=python&logoColor=white)
![Jupyter](https://img.shields.io/badge/Jupyter-Notebook-F37626?style=flat&logo=jupyter&logoColor=white)
![Pandas](https://img.shields.io/badge/pandas-1.5+-150458?style=flat&logo=pandas&logoColor=white)
![Seaborn](https://img.shields.io/badge/seaborn-0.12+-4c72b0?style=flat)
![Status](https://img.shields.io/badge/Internship-Completed-success)

A complete, beginner-friendly, and reproducible econometric exploratory data analysis (EDA) of unemployment rates across Indian states and union territories before and during the COVID-19 pandemic. Built for the **Oasis Infobyte (OIBSIP) Data Science Internship Task 2**.

---

## Table of Contents
1. [Project Overview](#project-overview)
2. [Objectives & Research Questions](#objectives--research-questions)
3. [Technology Stack](#technology-stack)
4. [Dataset Source & Access Instructions](#dataset-source--access-instructions)
5. [Dataset Columns & Schema](#dataset-columns--schema)
6. [Folder Structure](#folder-structure)
7. [Installation & Setup](#installation--setup)
8. [Dataset Placement Instructions](#dataset-placement-instructions)
9. [How to Run the Notebook](#how-to-run-the-notebook)
10. [Data Cleaning Approach](#data-cleaning-approach)
11. [Key Visualizations & Outputs](#key-visualizations--outputs)
12. [Actual Findings & Statistical Evidence](#actual-findings--statistical-evidence)
13. [Limitations of the Analysis](#limitations-of-the-analysis)
14. [Internship Learning Outcomes](#internship-learning-outcomes)
15. [Task Verification Checklist](#task-verification-checklist)
16. [Acknowledgments & Attribution](#acknowledgments--attribution)

---

## Project Overview

Unemployment is a cornerstone macroeconomic indicator that directly mirrors industrial output, human resource efficiency, and societal well-being. In early 2020, the onset of the COVID-19 pandemic and subsequent national containment lockdowns in India generated massive labor shocks across both agricultural rural belts and urban service centers.

This project analyzes empirical monthly unemployment records from **May 31, 2019 to June 30, 2020** to assess:
- Spatial variation across 28 states and union territories.
- Temporal trajectories leading up to and during the nationwide lockdowns.
- Empirical shifts between the pre-COVID baseline (< March 1, 2020) and post-COVID shock periods (>= March 1, 2020).
- Inter-variable correlations between unemployment rate, employment headcount, and labor force participation.

---

## Objectives & Research Questions

The analysis answers five central research questions:
1. **Regional Variation:** How does the average unemployment rate vary across Indian states and union territories?
2. **Temporal Trends:** How did monthly unemployment rates fluctuate across India from May 2019 to June 2020?
3. **State-Level Hotspots:** Which states experienced the highest mean unemployment rate during the surveyed period?
4. **Inter-Variable Correlation:** How do unemployment rate, employed headcount, and labor force participation rate relate to one another?
5. **COVID-19 Impact Comparison:** How do average unemployment rates differ between the pre-COVID baseline (prior to March 1, 2020) and the post-COVID period (March 1, 2020 onwards)?

> **Observational Caveat:** This is strictly an observational empirical analysis. Correlation and temporal association do not prove that COVID-19 or lockdown orders caused 100% of the observed movements; seasonal shifts, monsoon rainfall patterns, and agricultural crop cycles also play concurrent roles.

---

## Technology Stack

- **Programming Language:** Python 3.10+
- **Interactive Computing:** Jupyter Notebook / IPython Kernel
- **Data Manipulation & Analysis:** `pandas` (v1.5+), `numpy` (v1.23+)
- **Data Visualization:** `matplotlib` (v3.6+), `seaborn` (v0.12+)
- **Version Control:** Git & GitHub

---

## Dataset Source & Access Instructions

- **Dataset Title:** Unemployment in India
- **Platform:** [Kaggle Dataset Directory](https://www.kaggle.com/datasets/gokulrajkmv/unemployment-in-india)
- **Author / Uploader:** Gokul Raj Kuppan (`gokulrajkmv`)
- **Original Source:** Centre for Monitoring Indian Economy (CMIE)
- **Retrieval Date:** October 2026
- **Terms:** Open Data for educational and research analysis.

### Download Instructions:
1. Visit [https://www.kaggle.com/datasets/gokulrajkmv/unemployment-in-india](https://www.kaggle.com/datasets/gokulrajkmv/unemployment-in-india).
2. Download `archive.zip` and extract it.
3. Locate `Unemployment in India.csv` and move it into `data/Unemployment in India.csv`.

---

## Dataset Columns & Schema

| Raw Column Header | Clean Standardized Name | Type | Description |
| :--- | :--- | :--- | :--- |
| `Region` | `Region` | Object / String | State or Union Territory name (e.g. Haryana, Bihar, Tamil Nadu). |
| ` Date` | `Date` | Datetime (`%Y-%m-%d`) | End-of-month date of survey observation. |
| ` Frequency` | `Frequency` | Object / String | Collection frequency (`Monthly` / `M`). |
| ` Estimated Unemployment Rate (%)` | `Estimated Unemployment Rate (%)` | Float64 | Unemployed individuals as a percentage of the active labor force. |
| ` Estimated Employed` | `Estimated Employed` | Float64 | **Absolute headcount of employed individuals** (range: 49,420 to 45.77 million). |
| ` Estimated Labour Participation Rate (%)` | `Estimated Labour Participation Rate (%)` | Float64 | Percentage of working-age population participating in the labor force. |
| `Area` | `Area` | Object / String | Geographical sector: `Rural` or `Urban`. |

> **Critical Note on `Estimated Employed`:** This field is an absolute headcount (count of persons), not an employment rate percentage. To maintain statistical integrity, it is not labeled as "employment rate."

---

## Folder Structure

```
OIBSIP/
└── DataScience/
    └── Task2_Unemployment_Analysis/
        ├── Unemployment_Analysis.ipynb     # Fully executed, documented Jupyter notebook
        ├── README.md                       # Comprehensive project documentation
        ├── requirements.txt                # Python package dependencies
        ├── data/
        │   ├── Unemployment in India.csv   # Dataset CSV
        │   └── README.md                   # Data documentation & download guide
        ├── outputs/
        │   ├── unemployment_trends.png     # Multi-state time-series line chart
        │   ├── top_10_states.png           # Top 10 states horizontal bar chart
        │   ├── correlation_heatmap.png     # Pearson correlation heatmap
        │   └── pre_post_covid_comparison.png # Pre vs Post COVID dual-panel figure
        └── screenshots/
            └── README.md                   # Guidelines for execution screenshots
```

---

## Installation & Setup

Ensure Python 3.8+ is installed on your operating system.

```bash
# 1. Clone repository and navigate to the project directory
git clone <YOUR_REPOSITORY_URL>
cd OIBSIP/DataScience/Task2_Unemployment_Analysis/

# 2. Create and activate a virtual environment
python3 -m venv venv
source venv/bin/activate       # On Linux/macOS
# or: venv\Scripts\activate   # On Windows

# 3. Install required packages
pip install -r requirements.txt
```

---

## Dataset Placement Instructions

Verify that the CSV file exists in `data/Unemployment in India.csv`:
```bash
ls -lh "data/Unemployment in India.csv"
```
If the file is absent, download it from Kaggle and place it in the `data/` subdirectory.

---

## How to Run the Notebook

```bash
# Start the Jupyter Notebook server
jupyter notebook Unemployment_Analysis.ipynb
```
Inside Jupyter:
1. Open `Unemployment_Analysis.ipynb`.
2. Click **Kernel** $\rightarrow$ **Restart & Run All**.
3. All code cells will execute sequentially, producing interactive console outputs, tables, and refreshed charts.

---

## Data Cleaning Approach

1. **Header Standardization:** Stripped leading and trailing whitespace characters across all 7 column names using `.str.strip()`.
2. **Trailing Blank Row Elimination:** 28 rows at the tail end of the file contained entirely empty values (`NaN` across all columns). These were removed using `df.dropna(how='all')`, leaving **740 valid rows** out of 768.
3. **Data Type Casting:**
   - `Date` converted via `pd.to_datetime(..., dayfirst=True, errors='coerce')`. 0 invalid dates found.
   - Numeric features converted via `pd.to_numeric(..., errors='coerce')`. 0 conversion failures found.
4. **Text Cleaning:** Stripped extraneous whitespace from `Region`, `Frequency`, and `Area`.
5. **Chronological Sorting:** Observations sorted by `Date`, `Region`, and `Area` to maintain time-series integrity.
6. **Sectoral Grouping:** Documented the `Rural` vs. `Urban` classification to avoid accidental double-counting when calculating overall regional figures.

---

## Key Visualizations & Outputs

### 1. Monthly Unemployment Trends (Selected States)
![Unemployment Trends](outputs/unemployment_trends.png)
*Tracking monthly movements across Haryana, Bihar, Maharashtra, and Tamil Nadu from May 2019 to June 2020. Shaded pink band marks the post-COVID period.*

### 2. Top 10 States by Average Unemployment Rate
![Top 10 States](outputs/top_10_states.png)
*Horizontal bar chart showing the highest average rates across the 14-month monitoring window.*

### 3. Correlation Heatmap
![Correlation Heatmap](outputs/correlation_heatmap.png)
*Pearson correlation matrix among Unemployment Rate, Employed Count, and Labor Participation Rate.*

### 4. Pre-COVID vs. Post-COVID Comparison
![Pre vs Post COVID](outputs/pre_post_covid_comparison.png)
*Dual-panel figure contrasting national averages (+8.26 pp increase) and state-specific surges.*

---

## Actual Findings & Statistical Evidence

All statistics are derived directly from the executed dataset:

1. **Overall National Mean:** Across 740 observations, the mean unemployment rate was **11.79%** (std: 10.72%, min: 0.00%, max: 76.74%).
2. **Top 5 Most Affected States/UTs (Overall Average):**
   - **Tripura:** 28.35% (std: 10.63%)
   - **Haryana:** 26.28% (std: 11.37%)
   - **Jharkhand:** 20.58% (std: 18.59%)
   - **Bihar:** 18.92% (std: 13.56%)
   - **Himachal Pradesh:** 18.54% (std: 9.59%)
3. **Lowest Unemployment States:**
   - **Meghalaya:** 4.80% (std: 4.40%)
   - **Odisha:** 5.66% (std: 4.44%)
   - **Assam:** 6.43% (std: 3.78%)
4. **Monthly Trajectory:**
   - May 2019 – Feb 2020: Stable baseline ranging between **8.87% and 9.96%**.
   - March 2020: Began creeping upward to **10.70%**.
   - **April 2020 (Peak Lockdown):** Surged to **23.64%** (more than 2.4× the pre-lockdown average).
   - **May 2020 (Extended Lockdown):** Peaked at **24.88%**.
   - **June 2020 (Unlock 1.0):** Rebounded quickly to **11.90%**.
5. **Pre-COVID vs. Post-COVID Shift:**
   - **Pre-COVID Mean (< March 1, 2020):** **9.51%** (536 observations, std: 7.75%)
   - **Post-COVID Mean ($\ge$ March 1, 2020):** **17.77%** (204 observations, std: 14.93%)
   - **Absolute Difference:** **+8.26 percentage points**
   - **Relative Increase:** **+86.91%**
   - **Volatility Surge:** Standard deviation nearly doubled from 7.75% to 14.93%.
6. **Correlation Results:**
   - Unemployment Rate vs. Employed Count: $r = -0.223$ (moderate negative relationship).
   - Unemployment Rate vs. Labour Participation: $r = +0.003$ (essentially zero correlation across regional cross-sections).
   - Employed Count vs. Labour Participation: $r = +0.011$.

---

## Limitations of the Analysis

1. **Observational Bounds:** Correlation does not establish causation. Non-pandemic macroeconomic dynamics and agricultural harvest cycles occurred concurrently.
2. **Temporal Imbalance:** The pre-COVID period spans 10 months, whereas the post-COVID period spans 4 months. The post-COVID average is heavily influenced by the immediate April–May lockdown shock.
3. **Reporting Granularity:** Monthly intervals conceal higher-frequency weekly spikes and localized daily disruptions.
4. **Demographic Confounding:** `Estimated Employed` is a raw headcount (strongly correlated with state population) rather than an employment-to-population ratio.
5. **Analytical Cutoff:** March 1, 2020 is a chosen convention. While national restrictions took full effect on March 24–25, voluntary behavioral changes and global trade freezes began earlier in March.

---

## Internship Learning Outcomes

- Formulated an end-to-end exploratory data science workflow from raw data ingestion to econometric reporting.
- Executed strict data cleaning protocols without silent data loss.
- Mastered publication-quality data visualization with `matplotlib` and `seaborn`.
- Developed critical data literacy regarding macroeconomic measurements, demographic scale confounding, and observational causal claims.

---

## Task Verification Checklist

- [x] Dataset obtained from a suitable source (CMIE / Kaggle).
- [x] Data loaded and shape inspected (`768, 7` $\rightarrow$ `740, 7`).
- [x] Missing values checked and types converted.
- [x] Region-wise averages calculated across all 28 states.
- [x] Month-wise trends calculated with Year-Month groupings.
- [x] Time-series line chart for 4 diverse states created with COVID-19 reference line.
- [x] Top 10 states horizontal bar chart generated.
- [x] Correlation heatmap created with proper column labels.
- [x] Pre-COVID and post-COVID means compared (+8.26 pp, +86.91%).
- [x] Markdown observations included after every chart.
- [x] Clean and thoroughly commented Python code.
- [x] Complete README and requirements.txt.
- [x] Charts saved in `outputs/` folder.
- [x] Notebook executed successfully from beginning to end.

---

## Acknowledgments & Attribution

- **Dataset Provider:** Gokul Raj Kuppan (`gokulrajkmv`) on Kaggle.
- **Original Source:** Centre for Monitoring Indian Economy (CMIE).
- **Internship Program:** Oasis Infobyte (OIBSIP) Data Science Internship — Task 2.
