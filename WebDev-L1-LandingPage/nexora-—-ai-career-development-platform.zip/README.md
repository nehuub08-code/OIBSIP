# Nexora — AI Career Development Platform

> **“Your Goals. Your Journey. Your Future.”**  
> *Turn your ambition into real-world skills, projects, and career opportunities — with your personal AI career mentor.*

---

## 📌 Project Overview

**Nexora** is a dynamic, modern, responsive landing page for an AI-powered personalized career development platform. It guides students and aspiring developers from beginner to career-ready through personalized learning roadmaps, real-world project labs, verified skill passports, interview simulations, and internship/job opportunities.

### 🎓 Internship Information
- **Organization:** OASIS INFOBYTE INTERNSHIP
- **Intern:** Neha Vinod Borkar
- **Domain:** Web Development & Designing
- **Level:** Level 1 — Task 1: Landing Page

---

## ✨ Key Features & Sections

1. **Mandatory Demo Video Opening Card**:
   - Displays the required title card for the first 2.5 seconds on load.
   - Includes progress countdown, skip option, and a persistent "Replay 2s Video Intro" button for video recordings.

2. **Responsive Sticky Navigation Bar**:
   - Custom abstract connected-path "N" logo.
   - Smooth navigation links with section scrolling.
   - **Dark Mode / Light Mode** theme toggle for comfortable late-night studying.
   - Interactive Log In and "Start Your Journey" modal triggers.
   - Mobile slide-down hamburger drawer.

3. **Interactive Hero Section**:
   - Headline: *“Your Future Doesn’t Happen. You Build It.”* with radiant gradient text.
   - Interactive live dashboard preview with active goal switcher (`AI Engineer`, `Full-Stack Developer`, `Data Scientist`).
   - Dynamic weekly progress gauge and interactive milestone status cards.
   - Mastery meters for key skills and next-action prompt.
   - Floating achievement badges (`14-Day Streak`, `+1,420 Skill XP`).

4. **Trust and Value Strip**:
   - 4 foundational pillars: Personalized Roadmaps, Project-Based Learning, AI Guidance, Career-Ready Skills.
   - Honest, student-centric design with zero fabricated statistics.

5. **Problem & Solution Section**:
   - *“Stop Guessing. Start Growing.”*
   - Breakdown of the 3 common struggles: *Too Many Choices*, *No Clear Roadmap*, and *No Proof of Skills*.
   - Connected solution banner highlighting the unified progression framework.

6. **How It Works Timeline**:
   - 4-step progressive timeline: *Discover Yourself* → *Choose Your Direction* → *Learn, Build, and Prove* → *Prepare for Opportunities*.
   - Connected line layout with interactive step selection and detailed feature checklists.

7. **Specialized Career Paths**:
   - 6 career tracks: **AI Engineer**, **AI Agent Engineer**, **Software Engineer**, **Data Scientist**, **Full-Stack Web Developer**, and **Cybersecurity Analyst**.
   - Search bar and category filters (`All`, `AI & Data`, `Software Engineering`, `Infrastructure & Security`).
   - **Detailed Path Preview Modal**: View curriculum syllabi, weekly milestones, target roles, market demand, and capstone project details.

8. **Nexora Ecosystem (16 Modules)**:
   - Clean category tabs (*Discovery & Planning*, *Skills & Projects*, *Career & Opportunity*, *Growth & Mentorship*).
   - Expandable highlights for each of the 16 core platform modules.

9. **AI Mentor Interactive Showcase**:
   - Interactive simulated chat preview demonstrating adaptive guidance.
   - 4 one-click suggested prompts (*Help me choose a career*, *Explain a difficult concept*, *What should I learn next?*, *Review my project progress*).
   - Context action chips and free-form input simulation.

10. **Real-World Project Lab**:
    - 3 journey stages: *Explore* → *Build* → *Demonstrate*.
    - Interactive Capstone Showcase (*“Build an AI-Powered Study Assistant”*).
    - 4 clickable milestone stages updating live Python code snippets, deliverable checklists, and progressive hints.

11. **Personalized Dashboard Preview**:
    - Full-width preview with soft purple-blue ambient gradient styling.
    - Interactive tasks checklist (clicking tasks updates completion count and progress bar dynamically).
    - Verified Skill Passport metrics and proactive AI mentor suggestion.

12. **Why Nexora**:
    - Central progression loop: `Goal → Learn → Practise → Build → Demonstrate → Prepare → Grow`.
    - 5 core platform differentiators.

13. **Interactive Onboarding Modal**:
    - 3-step personalized roadmap generator wizard.
    - Generates customized 16-week blueprints based on education level, selected track, and weekly hours.

14. **Authentication & Legal Modals**:
    - Clean demo Login & Registration modal with 1-click demo autofill and client-side validation.
    - Full Privacy Policy and Terms of Use modals accessible from footer.

---

## 🛠️ Tech Stack

- **Frontend Framework:** [React 19](https://react.dev/) + [TypeScript](https://www.typescriptlang.org/)
- **Build Tool:** [Vite](https://vitejs.dev/)
- **Styling:** [Tailwind CSS v4](https://tailwindcss.com/)
- **Icons:** [Lucide React](https://lucide.dev/)
- **Typography:** Plus Jakarta Sans & JetBrains Mono (Google Fonts)

---

## 🚀 Getting Started

### Prerequisites
- Node.js (v18 or higher recommended)
- npm or yarn

### Installation

1. Clone or extract the repository:
   ```bash
   git clone <repository-url>
   cd nexora-landing-page
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000) in your browser.

4. Build for production:
   ```bash
   npm run build
   ```

5. Run typecheck & linter:
   ```bash
   npm run lint
   ```

---

## 📱 Responsiveness & Accessibility

- Fully responsive across mobile (<640px), tablet (640px–1024px), and desktop (>1024px) viewports without horizontal overflow.
- Accessible semantic HTML elements (`header`, `main`, `section`, `nav`, `footer`, `role="dialog"` for modals).
- Keyboard navigation friendly with visible focus states.
- High color contrast ratios compliant with readability standards in both Light and Dark modes.

---

## 📄 License
This project is created as part of the Oasis Infobyte Web Development & Designing Internship by **Neha Vinod Borkar**.
