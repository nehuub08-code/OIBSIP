import { CareerPath, EcosystemModule, ProjectLabMilestone } from '../types';

export const CAREER_PATHS: CareerPath[] = [
  {
    id: 'ai-engineer',
    title: 'AI Engineer',
    category: 'AI & Data',
    tagline: 'Design, train, and deploy neural networks and production machine learning models.',
    description: 'Transform raw data and algorithms into intelligent systems. Master mathematical foundations, deep learning frameworks, and modern model optimization techniques.',
    skills: ['Python', 'PyTorch', 'TensorFlow', 'LLMs & Transformers', 'Data Structures & Algorithms', 'Model Deployment (Docker/FastAPI)'],
    difficulty: 'Beginner Friendly',
    estTimeToReady: '16–20 Weeks',
    sampleRoles: ['Associate AI Engineer', 'Junior ML Engineer', 'AI Research Fellow'],
    marketDemand: 'Ultra High',
    gradient: 'from-purple-500 via-indigo-500 to-blue-500',
    accentColor: '#8b5cf6',
    overview: 'As an AI Engineer, you bridge theory and practical code. Nexora guides you from basic matrix operations in NumPy through transformer architectures and deploying models that solve real-world industry tasks.',
    coreMilestones: [
      { week: 'Weeks 1–4', title: 'Python & Mathematical Foundations', description: 'Master vector math, NumPy, Pandas, and computational complexity.' },
      { week: 'Weeks 5–8', title: 'Classical ML & Deep Learning', description: 'Build regression, decision trees, PyTorch tensors, and convolution networks from scratch.' },
      { week: 'Weeks 9–14', title: 'LLMs, Fine-tuning & Embeddings', description: 'Fine-tune open-weights models, work with vector databases, and build Retrieval-Augmented Generation (RAG).' },
      { week: 'Weeks 15–18', title: 'Production AI Deployment & MLOps', description: 'Package models with FastAPI, containerize with Docker, and run inference pipelines.' },
    ],
    capstoneProject: {
      title: 'Multimodal Academic Search & Synthesis Engine',
      description: 'An AI service that ingests academic PDFs, extracts semantic embeddings, and generates verified citations and summaries with an interactive UI.',
      technologies: ['Python', 'FastAPI', 'PyTorch', 'Qdrant Vector DB', 'React', 'Docker'],
    },
  },
  {
    id: 'ai-agent-engineer',
    title: 'AI Agent Engineer',
    category: 'AI & Data',
    tagline: 'Architect autonomous multi-agent systems, tool-calling graphs, and reasoning workflows.',
    description: 'Build systems where AI doesn’t just generate text, but takes structured action, executes workflows, browses the web, and collaborates with other agents.',
    skills: ['Autonomous Agent Loops', 'LangGraph / LangChain', 'Tool Calling & Function Execution', 'Python & TypeScript', 'State Persistence', 'Prompt Engineering'],
    difficulty: 'Intermediate',
    estTimeToReady: '14–18 Weeks',
    sampleRoles: ['AI Agent Developer', 'Automation Architect', 'Applied AI Specialist'],
    marketDemand: 'Rising Rapidly',
    gradient: 'from-indigo-500 via-cyan-500 to-teal-400',
    accentColor: '#06b6d4',
    overview: 'Autonomous agents represent the frontier of software engineering. Learn to build reliable agentic loops with structured outputs, error recovery, tool-calling capabilities, and guardrails.',
    coreMilestones: [
      { week: 'Weeks 1–3', title: 'LLM Foundations & Tool Schema', description: 'Structured JSON outputs, function calling signatures, and API integrations.' },
      { week: 'Weeks 4–7', title: 'Agent Loops & State Graphs', description: 'ReAct loops, human-in-the-loop checkpoints, state persistence, and cyclical graphs.' },
      { week: 'Weeks 8–12', title: 'Multi-Agent Collaboration', description: 'Hierarchical supervisors, consensus systems, and specialist task routers.' },
      { week: 'Weeks 13–16', title: 'Testing, Benchmarking & Safety', description: 'Evaluating hallucinations, latency budgeting, and automated task regression suites.' },
    ],
    capstoneProject: {
      title: 'Autonomous Research & Code-Auditing Agent',
      description: 'A multi-agent team that analyzes GitHub pull requests, runs security scanners in sandbox containers, and writes test suites.',
      technologies: ['LangGraph', 'Python', 'TypeScript', 'Docker Sandbox', 'GitHub API'],
    },
  },
  {
    id: 'software-engineer',
    title: 'Software Engineer',
    category: 'Software Engineering',
    tagline: 'Master algorithms, distributed systems, clean code, and scalable architecture.',
    description: 'Build robust, scalable software that powers modern platforms. Develop mastery of data structures, algorithms, object-oriented design, databases, and microservices.',
    skills: ['Data Structures & Algorithms', 'System Design Basics', 'Java / Python / Go', 'SQL & NoSQL Databases', 'RESTful APIs', 'Git & CI/CD'],
    difficulty: 'Beginner Friendly',
    estTimeToReady: '20–24 Weeks',
    sampleRoles: ['Junior Software Engineer', 'Backend Developer', 'Core Platform Engineer'],
    marketDemand: 'Ultra High',
    gradient: 'from-blue-600 via-indigo-600 to-purple-600',
    accentColor: '#3b82f6',
    overview: 'Software engineering is the backbone of technology. Nexora provides structured coding katas, system design simulations, and collaborative Git workflows to prepare you for top engineering benchmarks.',
    coreMilestones: [
      { week: 'Weeks 1–6', title: 'Algorithmic Problem Solving', description: 'Arrays, HashMaps, Trees, Graphs, Dynamic Programming, and Big-O efficiency.' },
      { week: 'Weeks 7–12', title: 'Backend Systems & Database Design', description: 'Relational database schema normalization, indexing, transaction ACIDity, and REST APIs.' },
      { week: 'Weeks 13–18', title: 'Distributed Systems & Microservices', description: 'Caching with Redis, message queues with Kafka/RabbitMQ, and load balancing.' },
      { week: 'Weeks 19–22', title: 'Production Readiness & Testing', description: 'Unit/integration testing, Docker, CI/CD automated deployments, and logging.' },
    ],
    capstoneProject: {
      title: 'Real-Time Distributed Financial Ledger',
      description: 'A high-throughput double-entry bookkeeping ledger service with idempotent transactions, optimistic concurrency, and audit logs.',
      technologies: ['Go/Java', 'PostgreSQL', 'Redis', 'Docker', 'REST API'],
    },
  },
  {
    id: 'data-scientist',
    title: 'Data Scientist',
    category: 'AI & Data',
    tagline: 'Extract actionable signals, statistical insights, and predictive models from complex datasets.',
    description: 'Uncover stories in data. Master statistical analysis, hypothesis testing, predictive modeling, machine learning, and executive data storytelling.',
    skills: ['Statistical Inference', 'Python (Pandas, Scikit-Learn)', 'SQL Mastery', 'Data Visualization (Plotly, Seaborn)', 'Machine Learning Models', 'A/B Testing'],
    difficulty: 'Intermediate',
    estTimeToReady: '16–20 Weeks',
    sampleRoles: ['Junior Data Scientist', 'Product Data Analyst', 'Quantitative Research Associate'],
    marketDemand: 'High',
    gradient: 'from-emerald-500 via-teal-500 to-cyan-600',
    accentColor: '#10b981',
    overview: 'Data science is about making evidence-based decisions. Learn how to clean messy real-world datasets, engineer insightful features, build predictive models, and communicate findings persuasively.',
    coreMilestones: [
      { week: 'Weeks 1–4', title: 'Exploratory Data Analysis & Advanced SQL', description: 'Window functions, CTEs, data munging with Pandas, and exploratory statistical visuals.' },
      { week: 'Weeks 5–8', title: 'Statistical Modeling & Hypothesis Testing', description: 'Probability distributions, central limit theorem, p-values, ANOVA, and experimentation design.' },
      { week: 'Weeks 9–13', title: 'Predictive Modeling & Feature Engineering', description: 'Ensemble methods (XGBoost, Random Forest), feature scaling, cross-validation, and metrics.' },
      { week: 'Weeks 14–18', title: 'Data Storytelling & Model Governance', description: 'Interactive dashboard creation, model interpretability with SHAP, and executive presentations.' },
    ],
    capstoneProject: {
      title: 'Predictive Healthcare Patient Outcome Model',
      description: 'An end-to-end data science study analyzing clinical indicator trends to forecast readmission probabilities with SHAP interpretability.',
      technologies: ['Python', 'Scikit-Learn', 'XGBoost', 'Plotly Dash', 'PostgreSQL'],
    },
  },
  {
    id: 'web-developer',
    title: 'Full-Stack Web Developer',
    category: 'Software Engineering',
    tagline: 'Craft blazing-fast, accessible, and delightful interactive web applications.',
    description: 'Master the complete web landscape from intuitive frontend interfaces to reliable backend APIs, databases, authentication, and cloud deployment.',
    skills: ['React & Next.js', 'TypeScript', 'Node.js / Express', 'Tailwind CSS', 'PostgreSQL & ORMs', 'Web Performance & Accessibility'],
    difficulty: 'Beginner Friendly',
    estTimeToReady: '14–18 Weeks',
    sampleRoles: ['Junior Full-Stack Developer', 'Frontend Engineer', 'Web Applications Builder'],
    marketDemand: 'Ultra High',
    gradient: 'from-pink-500 via-rose-500 to-orange-400',
    accentColor: '#ec4899',
    overview: 'From responsive pixel-perfect layouts to robust server APIs, full-stack developers build the digital experiences people interact with every single day.',
    coreMilestones: [
      { week: 'Weeks 1–4', title: 'Modern Frontend & Component Architecture', description: 'HTML5 semantic standards, modern CSS/Tailwind, and modern TypeScript fundamentals.' },
      { week: 'Weeks 5–9', title: 'React Ecosystem & State Management', description: 'Hooks, component lifecycles, form validation, client routing, and responsive mobile patterns.' },
      { week: 'Weeks 10–13', title: 'Server-Side Engineering & APIs', description: 'Node.js, Express, REST conventions, JWT auth, and relational database migrations.' },
      { week: 'Weeks 14–17', title: 'Full-Stack Production Deployments', description: 'Full-stack integration, edge caching, Lighthouse accessibility audits, and CI/CD.' },
    ],
    capstoneProject: {
      title: 'Interactive Collaborative Learning Space',
      description: 'A full-stack collaborative platform with real-time markdown notes, student study rooms, and progress tracking widgets.',
      technologies: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Tailwind CSS'],
    },
  },
  {
    id: 'cybersecurity-analyst',
    title: 'Cybersecurity Analyst',
    category: 'Infrastructure & Security',
    tagline: 'Defend systems, analyze network traffic, identify vulnerabilities, and secure infrastructure.',
    description: 'Protect organizations against evolving cyber threats. Learn network security, threat modeling, vulnerability analysis, incident response, and ethical defense.',
    skills: ['Network Protocols (TCP/IP, DNS)', 'Linux Administration', 'Threat Analysis & SIEM', 'Vulnerability Assessment', 'Cryptography Basics', 'Security Compliance'],
    difficulty: 'Intermediate',
    estTimeToReady: '16–22 Weeks',
    sampleRoles: ['SOC Analyst (Tier 1)', 'Junior Security Engineer', 'Cyber Defense Specialist'],
    marketDemand: 'High',
    gradient: 'from-amber-500 via-red-500 to-purple-600',
    accentColor: '#f59e0b',
    overview: 'In an interconnected world, security is paramount. Master defense-in-depth principles, log analysis, packet inspection, and how to harden systems against attacks.',
    coreMilestones: [
      { week: 'Weeks 1–4', title: 'Networking & Operating System Security', description: 'TCP/IP handshake analysis, Wireshark packet capture, and Linux hardening.' },
      { week: 'Weeks 5–9', title: 'Threat Landscapes & Vulnerability Scanning', description: 'OWASP Top 10 web vulnerabilities, port scanning with Nmap, and vulnerability triage.' },
      { week: 'Weeks 10–14', title: 'Security Operations & Incident Handling', description: 'SIEM log aggregation, incident response playbooks, and alert correlation.' },
      { week: 'Weeks 15–18', title: 'Cryptography, IAM & Practical Defense Labs', description: 'Public key infrastructure (PKI), role-based access control, and defensible architecture.' },
    ],
    capstoneProject: {
      title: 'Automated Threat Detection & Honeypot Sensor',
      description: 'A cloud-deployed intrusion detection sensor that monitors SSH brute force attempts, analyzes suspicious payloads, and generates threat reports.',
      technologies: ['Linux', 'Python', 'Wireshark', 'Suricata / Snort', 'ELK Stack'],
    },
  },
];

export const ECOSYSTEM_MODULES: EcosystemModule[] = [
  {
    id: 'ai-goal-discovery',
    title: 'AI Career Goal Discovery',
    category: 'Discovery & Planning',
    icon: 'Compass',
    summary: 'Analyzes your passions, existing knowledge, and learning style to recommend tailored career tracks.',
    highlightTag: 'Smart Alignment',
    badgeColor: 'purple',
    keyFeatures: ['Interactive assessment questionnaire', 'Skills baseline diagnostic', 'Industry suitability matching'],
  },
  {
    id: 'personalized-roadmaps',
    title: 'Personalized Roadmaps & Tasks',
    category: 'Discovery & Planning',
    icon: 'MapPin',
    summary: 'Converts broad career goals into bite-sized, weekly actionable milestones calibrated to your schedule.',
    highlightTag: 'Paced For You',
    badgeColor: 'blue',
    keyFeatures: ['Weekly milestone breakdown', 'Adaptable study pacing', 'Prerequisite checking'],
  },
  {
    id: 'hard-skills-academy',
    title: 'Hard Skills Academy',
    category: 'Skills & Projects',
    icon: 'Code2',
    summary: 'Curated technical pathways covering programming languages, frameworks, algorithms, and system design.',
    highlightTag: 'Concept to Code',
    badgeColor: 'indigo',
    keyFeatures: ['Hands-on coding katas', 'Visual algorithmic explanations', 'Cheat sheets & reference guides'],
  },
  {
    id: 'english-communication',
    title: 'English Communication Practice',
    category: 'Skills & Projects',
    icon: 'MessageSquareText',
    summary: 'Build confidence in professional spoken and written workplace English for global tech teams.',
    highlightTag: 'Global Ready',
    badgeColor: 'emerald',
    keyFeatures: ['Email & Slack drafting exercises', 'Technical explanation drills', 'Pronunciation & phrasing feedback'],
  },
  {
    id: 'soft-skills-dev',
    title: 'Soft Skills Development',
    category: 'Skills & Projects',
    icon: 'Users',
    summary: 'Hone collaboration, emotional intelligence, critical thinking, and structured problem-solving.',
    highlightTag: 'Leadership & Teamwork',
    badgeColor: 'amber',
    keyFeatures: ['Conflict resolution scenarios', 'Cross-functional teamwork labs', 'Time management frameworks'],
  },
  {
    id: 'real-world-project-lab',
    title: 'Real-World Project Lab',
    category: 'Skills & Projects',
    icon: 'FolderGit2',
    summary: 'Tackle industry-inspired problem statements with progressive hints, milestone checks, and code reviews.',
    highlightTag: 'Proof of Work',
    badgeColor: 'rose',
    keyFeatures: ['Real-world problem briefs', 'Progressive hint tiering', 'Rubric-based evaluation checklist'],
  },
  {
    id: 'skill-passport',
    title: 'Skill Verification & Passport',
    category: 'Career & Opportunity',
    icon: 'ShieldCheck',
    summary: 'A verifiable digital ledger showcasing your completed projects, evaluated competencies, and code samples.',
    highlightTag: 'Verifiable Proof',
    badgeColor: 'cyan',
    keyFeatures: ['Shareable public proof link', 'Detailed competency matrix', 'Repository verification tags'],
  },
  {
    id: 'resume-portfolio-builder',
    title: 'Resume & Portfolio Builder',
    category: 'Career & Opportunity',
    icon: 'FileSpreadsheet',
    summary: 'Transform project deliverables and skills into ATS-friendly resumes and an elegant live web portfolio.',
    highlightTag: 'ATS Optimized',
    badgeColor: 'pink',
    keyFeatures: ['Action-verb bullet generator', 'Modern portfolio templates', 'ATS keyword compatibility checks'],
  },
  {
    id: 'interview-prep',
    title: 'Technical & HR Interview Prep',
    category: 'Career & Opportunity',
    icon: 'BrainCircuit',
    summary: 'Practice live coding questions, system design walkthroughs, and behavioral STAR-method responses.',
    highlightTag: 'Mock Simulator',
    badgeColor: 'purple',
    keyFeatures: ['Live coding simulator', 'Behavioral question bank', 'Instant feedback on clarity and tone'],
  },
  {
    id: 'internship-job-discovery',
    title: 'Internship & Job Discovery',
    category: 'Career & Opportunity',
    icon: 'Briefcase',
    summary: 'Discover verified student-friendly internships and entry-level positions matched to your skill passport.',
    highlightTag: 'Targeted Matches',
    badgeColor: 'blue',
    keyFeatures: ['Requirement matching score', 'Application status tracker', 'Direct entry-level filter'],
  },
  {
    id: 'company-readiness-analysis',
    title: 'Company Readiness Analysis',
    category: 'Career & Opportunity',
    icon: 'Building2',
    summary: 'Benchmark your current portfolio and skills against actual expectations of target tech companies.',
    highlightTag: 'Gap Analysis',
    badgeColor: 'indigo',
    keyFeatures: ['Company-specific tech stack audit', 'Targeted skill gap highlight', 'Interview style insights'],
  },
  {
    id: 'career-salary-insights',
    title: 'Career & Salary Insights',
    category: 'Growth & Mentorship',
    icon: 'TrendingUp',
    summary: 'Explore transparent compensation ranges, emerging role trajectories, and geographical market trends.',
    highlightTag: 'Market Data',
    badgeColor: 'teal',
    keyFeatures: ['Role trajectory maps', 'Entry to senior pay ranges', 'Emerging skill demand charts'],
  },
  {
    id: 'scholarships-resources',
    title: 'Scholarships & Free Resources',
    category: 'Growth & Mentorship',
    icon: 'GraduationCap',
    summary: 'Curated database of legitimate student grants, open educational resources, free student credits, and tools.',
    highlightTag: 'Zero Paywall',
    badgeColor: 'emerald',
    keyFeatures: ['Student developer pack guides', 'Verified scholarship directory', 'Open textbook repositories'],
  },
  {
    id: 'hackathons-open-source',
    title: 'Hackathons & Open Source',
    category: 'Growth & Mentorship',
    icon: 'GitPullRequest',
    summary: 'Find beginner-friendly open source repositories (Good First Issue) and upcoming virtual student hackathons.',
    highlightTag: 'Community Impact',
    badgeColor: 'orange',
    keyFeatures: ['Curated good first issues', 'Hackathon teammate matching', 'Pull request contribution checklist'],
  },
  {
    id: 'productivity-habit-tracking',
    title: 'Productivity & Habit Tracking',
    category: 'Growth & Mentorship',
    icon: 'Flame',
    summary: 'Maintain consistent learning momentum with daily study streaks, Pomodoro timers, and focus analytics.',
    highlightTag: 'Stay Consistent',
    badgeColor: 'red',
    keyFeatures: ['Visual streak counter', 'Integrated focus timers', 'Weekly consistency analytics'],
  },
  {
    id: 'ai-personal-mentor',
    title: 'AI Personal Career Mentor',
    category: 'Growth & Mentorship',
    icon: 'Sparkles',
    summary: 'A supportive 24/7 AI guide that explains tough concepts, suggests next tasks, and reviews project code.',
    highlightTag: '24/7 Guidance',
    badgeColor: 'purple',
    keyFeatures: ['Socratic concept breakdowns', 'Context-aware task guidance', 'Encouraging personalized feedback'],
  },
];

export const SAMPLE_PROJECT_LAB_MILESTONES: ProjectLabMilestone[] = [
  {
    id: 1,
    name: 'Problem Understanding',
    tag: 'Requirements & Scope',
    status: 'completed',
    description: 'Deconstruct user needs for a student study assistant. Define input queries, response constraints, and error scenarios.',
    checklist: [
      'Define core use cases (concept explanation, quiz generation, summary)',
      'Establish API rate limits and token budget limits',
      'Design expected JSON schema for structured study notes',
    ],
    codeSnippet: `// Study Assistant Schema Definition
interface StudyNote {
  topic: string;
  keyConcepts: string[];
  summaryBulletPoints: string[];
  practiceQuizQuestions: {
    question: string;
    options: string[];
    correctAnswerIndex: number;
    explanation: string;
  }[];
}`,
  },
  {
    id: 2,
    name: 'Implementation',
    tag: 'Core Logic & APIs',
    status: 'in-progress',
    description: 'Write the Python backend service utilizing client API calls, prompt formatting templates, and response validation.',
    checklist: [
      'Initialize API client with safe environment variables',
      'Create system instructions enforcing student-friendly explanations',
      'Implement structured output validation using Pydantic',
    ],
    codeSnippet: `import os
from pydantic import BaseModel, Field

class StudySessionService:
    def __init__(self, api_key: str):
        self.api_key = api_key
        # Configured for low temperature to ensure accuracy
        self.temperature = 0.2

    def generate_study_notes(self, subject: str, topic: str):
        prompt = f"Break down '{topic}' in {subject} for an undergraduate student."
        return self._execute_safe_inference(prompt)`,
  },
  {
    id: 3,
    name: 'Testing & Validation',
    tag: 'Edge Cases & Quality',
    status: 'upcoming',
    description: 'Run automated assertions against diverse queries (e.g. edge case inputs, overly long documents, ambiguous questions).',
    checklist: [
      'Write unit tests verifying response adheres to StudyNote schema',
      'Test timeout recovery and graceful degradation on API errors',
      'Run hallucination checks against known curriculum facts',
    ],
    codeSnippet: `def test_study_assistant_output_schema():
    service = StudySessionService(api_key="mock_test_key")
    result = service.generate_study_notes("Computer Science", "Binary Search")
    assert result is not None
    assert "time complexity" in str(result).lower()`,
  },
  {
    id: 4,
    name: 'Final Submission & Review',
    tag: 'Evaluation & Feedback',
    status: 'upcoming',
    description: 'Submit your GitHub repository link and deployed demo link for automated rubric evaluation and AI mentor feedback.',
    checklist: [
      'Clean README with clear installation and setup instructions',
      'Demo video or live web link included',
      'AI Mentor code quality review and Skill Passport verification badge',
    ],
    codeSnippet: `# Final Checklist
✓ Code modularity & documentation: 94/100
✓ Test coverage (>80%): Pass
✓ Skill Passport points awarded: +350 XP`,
  },
];

export const MENTOR_DEMO_PRESETS = [
  {
    prompt: 'Help me choose a career.',
    answer: "I'd love to help! Let's start with what energizes you most. Do you enjoy:\n\n1. **Solving logical puzzles & math algorithms?** → AI Engineer or Data Scientist\n2. **Designing interactive user experiences and web apps?** → Full-Stack Web Developer\n3. **Automating complex workflows & reasoning bots?** → AI Agent Engineer\n4. **Protecting systems and finding security flaws?** → Cybersecurity Analyst\n\nTell me which one sparks your curiosity, or click 'Start My Journey' above to run our 2-minute diagnostic!",
    action: {
      title: 'Run Career Goal Diagnostic',
      description: 'Answer 5 quick questions about your favorite subjects and projects.',
      ctaText: 'Launch Diagnostic →',
      type: 'roadmap' as const,
    },
  },
  {
    prompt: 'Explain a difficult concept.',
    answer: "Let's demystify **'Attention Mechanism' in Modern AI (Transformers)** using a simple analogy!\n\nImagine reading a long detective novel. When the detective asks *'Where was the key found?'*, your brain doesn't re-read all 300 pages with equal focus. Instead, your mind instantly *attends* to the specific sentences mentioning the butler, the study, and the locked desk.\n\nIn Neural Networks, the **Attention Mechanism** calculates a mathematical score between every word in a sentence and all other words. It allows the model to know that in *'The animal didn't cross the street because it was too tired'*, the word **'it'** refers to the **animal**, not the street!\n\nWould you like to see how this is implemented in PyTorch or explore Self-Attention math?",
    action: {
      title: 'View Interactive Transformer Visualizer',
      description: 'Explore query, key, and value vectors interactively.',
      ctaText: 'Open Visualizer →',
      type: 'quiz' as const,
    },
  },
  {
    prompt: 'What should I learn next?',
    answer: "Looking at your active goal (**AI Engineer**), here is your immediate next high-leverage step:\n\n• **Current Completed:** Python Fundamentals, NumPy vector math, Pandas data wrangling.\n• **Immediate Next Step:** **Matrix Calculus & Gradient Descent in PyTorch**.\n• **Recommended Mini-Task:** Write a single-layer perceptron from scratch in raw Python, then re-implement it in 10 lines using `torch.nn`.\n\nThis will solidify why backpropagation works before you dive into deep convolutional or transformer networks!",
    action: {
      title: 'Start PyTorch Milestone 1',
      description: 'Estimated time: 45 minutes · 3 interactive coding exercises included.',
      ctaText: 'Begin Milestone →',
      type: 'project' as const,
    },
  },
  {
    prompt: 'Review my project progress.',
    answer: "Great initiative! You are currently working on **'Build an AI-Powered Study Assistant'** in the Project Lab.\n\n**Status Assessment:**\n✓ **Milestone 1 (Problem Understanding):** 100% Complete. Clean schema design!\n⏳ **Milestone 2 (Implementation):** 65% Complete. You have the API integration working. Next, add the structured Pydantic fallback for malformed outputs.\n\n**Mentor Pro-Tip:** Don't forget to implement exponential backoff on API rate limits so your app doesn't crash during multiple rapid queries!",
    action: {
      title: 'Jump to Project Lab Milestone 2',
      description: 'Review the Pydantic fallback template and finish your submission.',
      ctaText: 'Continue Project →',
      type: 'project' as const,
    },
  },
];
