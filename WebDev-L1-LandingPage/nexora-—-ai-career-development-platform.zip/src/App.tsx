/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { OpeningTitleCard, TitleCardReplayButton } from './components/OpeningTitleCard';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { BenefitsStrip } from './components/BenefitsStrip';
import { ProblemSolution } from './components/ProblemSolution';
import { HowItWorks } from './components/HowItWorks';
import { CareerPaths } from './components/CareerPaths';
import { EcosystemFeatures } from './components/EcosystemFeatures';
import { AIMentorPreview } from './components/AIMentorPreview';
import { ProjectLab } from './components/ProjectLab';
import { DashboardPreview } from './components/DashboardPreview';
import { WhyNexora } from './components/WhyNexora';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';

// Modals
import { CareerPathModal } from './components/CareerPathModal';
import { OnboardingModal } from './components/OnboardingModal';
import { AuthModal } from './components/AuthModal';
import { LegalModal } from './components/LegalModal';

import { CAREER_PATHS } from './data/nexoraData';
import { CareerPath } from './types';

export default function App() {
  // Theme state: dark / light
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  // Modal states
  const [selectedCareerPath, setSelectedCareerPath] = useState<CareerPath | null>(null);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [preselectedGoal, setPreselectedGoal] = useState<string | undefined>(undefined);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [legalModalState, setLegalModalState] = useState<{ isOpen: boolean; type: 'privacy' | 'terms' }>({
    isOpen: false,
    type: 'privacy',
  });

  // Demo Title Card state
  const [showTitleCard, setShowTitleCard] = useState(true);

  // User feedback toast message
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handleToggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const handleOpenOnboarding = (goal?: string) => {
    setPreselectedGoal(goal);
    setIsOnboardingOpen(true);
  };

  const handleOpenAuth = (mode: 'login' | 'signup' = 'login') => {
    setAuthMode(mode);
    setIsAuthOpen(true);
  };

  const handleAuthSuccess = (email: string) => {
    showToast(`Welcome back, ${email}! Your session is active.`);
  };

  const handleExploreCareerPath = (pathId: string) => {
    const found = CAREER_PATHS.find((p) => p.id === pathId);
    if (found) {
      setSelectedCareerPath(found);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-300 selection:bg-purple-500 selection:text-white">
      
      {/* 2-Second Mandatory Demo Video Title Card */}
      {showTitleCard && (
        <OpeningTitleCard onDismiss={() => setShowTitleCard(false)} />
      )}

      {/* Replay Title Card Button (useful for screen recording video demo anytime) */}
      {!showTitleCard && (
        <TitleCardReplayButton onReplay={() => setShowTitleCard(true)} />
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 rounded-xl bg-purple-900/95 text-white border border-purple-400/40 px-4 py-2.5 text-xs font-semibold shadow-2xl backdrop-blur-md animate-in slide-in-from-top-2 duration-200">
          {toastMessage}
        </div>
      )}

      {/* Main Navigation Bar */}
      <Navbar
        darkMode={darkMode}
        onToggleDarkMode={handleToggleDarkMode}
        onOpenAuth={handleOpenAuth}
        onOpenOnboarding={() => handleOpenOnboarding()}
      />

      {/* Main Page Sections */}
      <main>
        {/* Section 4: Hero Section with Live Career Dashboard Preview */}
        <HeroSection
          onStartJourney={() => handleOpenOnboarding()}
          onExploreHowItWorks={() => {
            const el = document.getElementById('how-it-works');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          onExploreCareerPath={handleExploreCareerPath}
        />

        {/* Section 5: Trust and Value Strip */}
        <BenefitsStrip />

        {/* Section 6: Problem and Solution Section */}
        <ProblemSolution onStartJourney={() => handleOpenOnboarding()} />

        {/* Section 7: How It Works Section */}
        <HowItWorks onStartJourney={() => handleOpenOnboarding()} />

        {/* Section 8: Career Paths Section */}
        <CareerPaths
          onSelectPath={(path) => setSelectedCareerPath(path)}
          onStartJourney={() => handleOpenOnboarding()}
        />

        {/* Section 9: Nexora Ecosystem Section */}
        <EcosystemFeatures onStartJourney={() => handleOpenOnboarding()} />

        {/* Section 10: AI Mentor Showcase */}
        <AIMentorPreview
          onStartJourney={() => handleOpenOnboarding()}
          onExploreProjects={() => {
            const el = document.getElementById('project-lab');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* Section 11: Project Lab Showcase */}
        <ProjectLab onStartJourney={() => handleOpenOnboarding()} />

        {/* Section 12: Personalized Dashboard Preview */}
        <DashboardPreview onStartJourney={() => handleOpenOnboarding()} />

        {/* Section 13: Why Nexora Section */}
        <WhyNexora />

        {/* Section 14: Final CTA Section */}
        <FinalCTA
          onStartJourney={() => handleOpenOnboarding()}
          onExploreCareerPaths={() => {
            const el = document.getElementById('career-paths');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
        />
      </main>

      {/* Section 15: Footer */}
      <Footer
        onOpenLegal={(type) => setLegalModalState({ isOpen: true, type })}
        onReplayTitleCard={() => setShowTitleCard(true)}
      />

      {/* Detailed Career Path Modal */}
      <CareerPathModal
        path={selectedCareerPath}
        onClose={() => setSelectedCareerPath(null)}
        onStartWithGoal={(goalTitle) => handleOpenOnboarding(goalTitle)}
      />

      {/* Interactive Onboarding / Start Your Journey Roadmap Generator */}
      <OnboardingModal
        isOpen={isOnboardingOpen}
        onClose={() => setIsOnboardingOpen(false)}
        preselectedGoal={preselectedGoal}
      />

      {/* Log In / Sign Up Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        initialMode={authMode}
        onClose={() => setIsAuthOpen(false)}
        onSuccess={handleAuthSuccess}
      />

      {/* Privacy Policy & Terms of Use Modal */}
      <LegalModal
        isOpen={legalModalState.isOpen}
        type={legalModalState.type}
        onClose={() => setLegalModalState({ isOpen: false, type: 'privacy' })}
      />

    </div>
  );
}
