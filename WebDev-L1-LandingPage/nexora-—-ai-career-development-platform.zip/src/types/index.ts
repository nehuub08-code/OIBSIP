export interface CareerPath {
  id: string;
  title: string;
  category: 'AI & Data' | 'Software Engineering' | 'Infrastructure & Security';
  tagline: string;
  description: string;
  skills: string[];
  difficulty: 'Beginner Friendly' | 'Intermediate' | 'Advanced';
  estTimeToReady: string;
  sampleRoles: string[];
  marketDemand: 'Ultra High' | 'High' | 'Rising Rapidly';
  gradient: string;
  accentColor: string;
  overview: string;
  coreMilestones: {
    week: string;
    title: string;
    description: string;
  }[];
  capstoneProject: {
    title: string;
    description: string;
    technologies: string[];
  };
}

export type EcosystemCategory = 'All' | 'Discovery & Planning' | 'Skills & Projects' | 'Career & Opportunity' | 'Growth & Mentorship';

export interface EcosystemModule {
  id: string;
  title: string;
  category: 'Discovery & Planning' | 'Skills & Projects' | 'Career & Opportunity' | 'Growth & Mentorship';
  icon: string;
  summary: string;
  highlightTag?: string;
  keyFeatures: string[];
  badgeColor: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'mentor';
  text: string;
  timestamp: string;
  actionCard?: {
    title: string;
    description: string;
    ctaText: string;
    type: 'project' | 'roadmap' | 'quiz';
  };
}

export interface ProjectLabMilestone {
  id: number;
  name: string;
  tag: string;
  status: 'completed' | 'in-progress' | 'upcoming';
  description: string;
  checklist: string[];
  codeSnippet?: string;
}

export interface UserPersonalizedPlan {
  name: string;
  careerGoal: string;
  experienceLevel: string;
  hoursPerWeek: number;
  primaryInterests: string[];
  generatedRoadmap: {
    phase: string;
    weeks: string;
    title: string;
    keySkills: string[];
    deliverable: string;
  }[];
}
