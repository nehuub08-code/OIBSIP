import React, { useState } from 'react';
import {
  Sparkles,
  Flame,
  Award,
  CheckCircle2,
  Clock,
  ArrowRight,
  TrendingUp,
  Bot,
  Play,
  Calendar,
  Layers,
  BarChart2,
  ListTodo,
  AlertCircle
} from 'lucide-react';

interface DashboardPreviewProps {
  onStartJourney: () => void;
}

export const DashboardPreview: React.FC<DashboardPreviewProps> = ({ onStartJourney }) => {
  // Interactive checklist tasks state
  const [tasks, setTasks] = useState([
    { id: 1, title: 'Implement Vector Embeddings in Qdrant', time: '40 mins', completed: true },
    { id: 2, title: 'Write PyTorch Multi-Head Self Attention class', time: '60 mins', completed: true },
    { id: 3, title: 'Refactor Study Assistant API with Pydantic validation', time: '30 mins', completed: false },
    { id: 4, title: 'Complete Mock Behavioral Interview on Communication', time: '20 mins', completed: false },
  ]);

  const [activeCareerGoal, setActiveCareerGoal] = useState('AI Engineer');

  const toggleTask = (id: number) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };

  const completedCount = tasks.filter((t) => t.completed).length;
  const progressPercent = Math.round((completedCount / tasks.length) * 100);

  return (
    <section id="dashboard-preview" className="py-24 relative overflow-hidden bg-gradient-to-b from-purple-900/10 via-indigo-900/10 to-slate-900/20">
      {/* Background Soft Purple-Blue Gradient Mesh */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-600/15 via-indigo-600/10 to-transparent -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-purple-400/40 bg-purple-50 dark:bg-purple-950/40 px-3.5 py-1 text-xs font-bold text-purple-700 dark:text-purple-300 uppercase">
            <span>Unified Student Control Center</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tight">
            Your Career Command Center.{' '}
            <span className="text-gradient-primary">In One View.</span>
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 font-normal">
            Every goal, daily task, project milestone, and AI mentor suggestion automatically synchronized to keep you moving forward.
          </p>

          <div className="inline-flex items-center gap-2 rounded-lg bg-white/80 dark:bg-slate-800/80 px-3 py-1 border border-slate-200 dark:border-slate-700 text-xs text-slate-500 dark:text-slate-400">
            <AlertCircle className="w-3.5 h-3.5 text-purple-500" />
            <span>Interactive Realistic Preview with Sample Student Data</span>
          </div>
        </div>

        {/* Full-Width Dashboard Showcase Card */}
        <div className="mt-12 rounded-3xl border border-slate-200/90 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 shadow-2xl backdrop-blur-xl p-6 sm:p-8">
          
          {/* Dashboard Header Bar */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-6">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                  Welcome back, learner! 👋
                </span>
                <span className="text-xs bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-bold px-2.5 py-0.5 rounded-full">
                  Level 3 Scholar
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
                Selected Career Goal:{' '}
                <span className="font-bold text-purple-600 dark:text-purple-400">
                  {activeCareerGoal}
                </span>{' '}
                · Track Progress: Week 7 of 18
              </p>
            </div>

            {/* Career Goal Quick Switcher & Metrics */}
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                {['AI Engineer', 'Data Scientist', 'Web Developer'].map((goal) => (
                  <button
                    key={goal}
                    onClick={() => setActiveCareerGoal(goal)}
                    className={`text-xs px-3 py-1.5 rounded-lg font-semibold transition-all ${
                      activeCareerGoal === goal
                        ? 'bg-white dark:bg-slate-700 text-purple-600 dark:text-purple-300 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    {goal}
                  </button>
                ))}
              </div>

              {/* Streak Pill */}
              <div className="flex items-center gap-1.5 bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800/50 px-3 py-1.5 rounded-xl text-xs font-bold">
                <Flame className="w-4 h-4 fill-amber-500 text-amber-500" />
                <span>14 Day Streak</span>
              </div>
            </div>
          </div>

          {/* 3 Columns Top Metrics Grid */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-5">
            
            {/* Widget 1: Weekly Progress */}
            <div className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-850/60 p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  Weekly Learning Pace
                </span>
                <span className="text-xs font-extrabold text-purple-600 dark:text-purple-400">
                  {completedCount} of {tasks.length} Completed
                </span>
              </div>
              <div className="h-2.5 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 transition-all duration-500"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2 flex items-center justify-between">
                <span>Target: 12 hrs/week</span>
                <span>{progressPercent}% Met</span>
              </p>
            </div>

            {/* Widget 2: Skill Development Overview */}
            <div className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-850/60 p-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  Verified Skill Passport
                </span>
                <span className="text-xs font-bold text-cyan-600 dark:text-cyan-400">
                  +1,420 XP
                </span>
              </div>
              <div className="flex items-center gap-2 mt-2">
                <div className="flex-1 bg-white dark:bg-slate-800 p-2 rounded-lg text-center border border-slate-200/60 dark:border-slate-700/60">
                  <p className="text-[10px] text-slate-400 font-medium">Python & DSA</p>
                  <p className="text-xs font-bold text-slate-800 dark:text-slate-200">89% Level</p>
                </div>
                <div className="flex-1 bg-white dark:bg-slate-800 p-2 rounded-lg text-center border border-slate-200/60 dark:border-slate-700/60">
                  <p className="text-[10px] text-slate-400 font-medium">PyTorch/ML</p>
                  <p className="text-xs font-bold text-slate-800 dark:text-slate-200">76% Level</p>
                </div>
                <div className="flex-1 bg-white dark:bg-slate-800 p-2 rounded-lg text-center border border-slate-200/60 dark:border-slate-700/60">
                  <p className="text-[10px] text-slate-400 font-medium">System Design</p>
                  <p className="text-xs font-bold text-slate-800 dark:text-slate-200">65% Level</p>
                </div>
              </div>
            </div>

            {/* Widget 3: Project Milestones */}
            <div className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-850/60 p-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  Active Capstone Project
                </span>
                <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded-full">
                  Milestone 2
                </span>
              </div>
              <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                AI-Powered Study Assistant
              </p>
              <div className="flex items-center gap-1.5 mt-2 text-[11px] text-slate-500">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                <span>Next review ready in 2 days</span>
              </div>
            </div>

          </div>

          {/* Main Dashboard Body: Upcoming Tasks + AI Mentor Suggestion + Recommended Action */}
          <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left 7 Cols: Interactive Upcoming Tasks Checklist */}
            <div className="lg:col-span-7 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 bg-white dark:bg-slate-850">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <ListTodo className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    Upcoming Learning Tasks (Click to test checklist)
                  </h4>
                </div>
                <span className="text-xs text-slate-400">Week 7 Focus</span>
              </div>

              <div className="space-y-2.5">
                {tasks.map((task) => (
                  <div
                    key={task.id}
                    onClick={() => toggleTask(task.id)}
                    className={`cursor-pointer p-3 rounded-xl border transition-all flex items-center justify-between ${
                      task.completed
                        ? 'bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 text-slate-400'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-purple-300 text-slate-800 dark:text-slate-200 shadow-sm'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-5 h-5 rounded-md flex items-center justify-center transition-colors ${
                          task.completed
                            ? 'bg-emerald-500 text-white'
                            : 'border-2 border-slate-300 dark:border-slate-600'
                        }`}
                      >
                        {task.completed && <CheckCircle2 className="w-4 h-4" />}
                      </div>
                      <span
                        className={`text-xs font-medium ${
                          task.completed ? 'line-through text-slate-400' : ''
                        }`}
                      >
                        {task.title}
                      </span>
                    </div>
                    <span className="text-[11px] font-mono text-slate-400 shrink-0">
                      {task.time}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Right 5 Cols: Recommended Action & AI Mentor Proactive Suggestion */}
            <div className="lg:col-span-5 space-y-4">
              
              {/* Recommended Next Action */}
              <div className="rounded-2xl border border-indigo-200/80 dark:border-indigo-800/80 bg-gradient-to-tr from-indigo-50/70 via-purple-50/50 to-white dark:from-indigo-950/40 dark:via-purple-950/20 dark:to-slate-850 p-5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-300 bg-indigo-100 dark:bg-indigo-900/60 px-2 py-0.5 rounded-full">
                  Recommended Next Action
                </span>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-2">
                  Build your first ML Project Milestone
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  You’ve finished the theoretical concepts on model tuning. Now write the evaluation assert tests in the Project Lab.
                </p>
                <div className="mt-3">
                  <a
                    href="#project-lab"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300"
                  >
                    <span>Jump to Project Lab Workspace</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* AI Mentor Suggestion */}
              <div className="rounded-2xl border border-purple-200/80 dark:border-purple-800/80 bg-gradient-to-tr from-purple-50/70 to-white dark:from-purple-950/40 dark:to-slate-850 p-5 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    AI Mentor Suggestion
                  </span>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                    “Great momentum! You’ve maintained your 14-day study habit. Take 10 minutes to run through the English communication interview drill before wrapping up today.”
                  </p>
                </div>
              </div>

            </div>

          </div>

          {/* CTA Banner */}
          <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                Ready to generate your personal curriculum?
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Calibrated to your exact background, target timeline, and available hours.
              </p>
            </div>
            <button
              onClick={onStartJourney}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white text-xs sm:text-sm font-bold shadow-lg shadow-purple-500/25 transition-transform hover:scale-105 active:scale-95 flex items-center gap-2"
            >
              <span>Build My Personalized Roadmap</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>

      </div>
    </section>
  );
};
