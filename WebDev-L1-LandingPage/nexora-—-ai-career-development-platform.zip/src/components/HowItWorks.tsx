import React, { useState } from 'react';
import { Compass, Target, Code, Briefcase, ArrowRight, Check } from 'lucide-react';

interface HowItWorksProps {
  onStartJourney: () => void;
}

export const HowItWorks: React.FC<HowItWorksProps> = ({ onStartJourney }) => {
  const [selectedStep, setSelectedStep] = useState<number>(1);

  const steps = [
    {
      step: 1,
      title: 'Discover Yourself',
      tagline: 'Your Baseline & Ambition',
      icon: Compass,
      gradient: 'from-purple-500 to-indigo-600',
      description:
        'Tell Nexora about your interests, education, existing skills, experience, and ambitions.',
      details: [
        'Interactive diagnostic evaluates your analytical, visual, or systems inclinations',
        'Upload your current resume or syllabus for automated skill mapping',
        'Establish weekly time availability calibrated to your student schedule',
      ],
      previewBadge: 'Takes ~3 Minutes',
    },
    {
      step: 2,
      title: 'Choose Your Direction',
      tagline: 'Clarity Over Confusion',
      icon: Target,
      gradient: 'from-indigo-500 to-blue-600',
      description:
        'Explore suitable career paths and select the goal that fits you.',
      details: [
        'Compare AI Engineer, Agent Engineer, Web Developer, Data Science, and Security',
        'Inspect actual salary ranges, day-to-day work samples, and industry requirements',
        'Select or customize your career track with zero lock-in',
      ],
      previewBadge: '6 Tailored Tracks',
    },
    {
      step: 3,
      title: 'Learn, Build, and Prove',
      tagline: 'Action-Driven Growth',
      icon: Code,
      gradient: 'from-blue-500 to-cyan-500',
      description:
        'Follow a personalized roadmap, practise skills, complete projects, and demonstrate what you can do.',
      details: [
        'Weekly bite-sized tasks structured with conceptual fundamentals and coding katas',
        'Build capstone projects in the Project Lab with progressive hints and mentor reviews',
        'Earn verifiable Skill Passport credentials backed by genuine code deliverables',
      ],
      previewBadge: 'Hands-on Projects',
    },
    {
      step: 4,
      title: 'Prepare for Opportunities',
      tagline: 'Real Career Readiness',
      icon: Briefcase,
      gradient: 'from-pink-500 to-rose-600',
      description:
        'Build your portfolio, improve interview skills, explore eligible internships and jobs, and track applications.',
      details: [
        'Generate ATS-friendly resumes and live portfolio websites from verified projects',
        'Simulate technical coding screens and behavioral interviews with instant AI feedback',
        'Discover entry-level openings and internships tailored to your verified skills',
      ],
      previewBadge: 'Job & Internship Ready',
    },
  ];

  return (
    <section id="how-it-works" className="py-24 relative overflow-hidden">
      {/* Background radial accent */}
      <div className="pointer-events-none absolute top-1/4 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-purple-400/40 bg-purple-50 dark:bg-purple-950/40 px-3.5 py-1 text-xs font-bold text-purple-700 dark:text-purple-300 uppercase">
            <span>Structured Progression</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            From Where You Are to{' '}
            <span className="text-gradient-primary">Where You Want to Be.</span>
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 font-normal">
            A clear, 4-step framework engineered to eliminate paralysis and guide you step-by-step from curious beginner to industry-ready candidate.
          </p>
        </div>

        {/* Timeline Desktop & Mobile */}
        <div className="mt-16">
          
          {/* Step Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
            
            {/* Desktop Connecting Line behind cards */}
            <div className="hidden md:block absolute top-12 left-12 right-12 h-1 bg-gradient-to-r from-purple-500 via-blue-500 to-rose-500 -z-0 opacity-40 rounded-full" />

            {steps.map((item) => {
              const Icon = item.icon;
              const isSelected = selectedStep === item.step;
              return (
                <div
                  key={item.step}
                  onClick={() => setSelectedStep(item.step)}
                  className={`relative z-10 cursor-pointer rounded-2xl p-6 transition-all duration-300 flex flex-col justify-between ${
                    isSelected
                      ? 'bg-white dark:bg-slate-850 border-2 border-purple-500 shadow-xl shadow-purple-500/15 -translate-y-2'
                      : 'bg-white/80 dark:bg-slate-900/80 border border-slate-200/90 dark:border-slate-800 hover:border-purple-300 hover:shadow-md hover:-translate-y-1'
                  }`}
                >
                  <div>
                    {/* Step Node Circle with Number & Icon */}
                    <div className="flex items-center justify-between mb-4">
                      <div
                        className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${item.gradient} flex items-center justify-center text-white shadow-md transition-transform ${
                          isSelected ? 'scale-110' : ''
                        }`}
                      >
                        <Icon className="w-6 h-6" />
                      </div>
                      <span className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xs font-black text-slate-700 dark:text-slate-300">
                        0{item.step}
                      </span>
                    </div>

                    <span className="text-[11px] font-bold text-purple-600 dark:text-purple-400 uppercase tracking-wider">
                      Step {item.step}
                    </span>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                      {item.title}
                    </h3>
                    <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
                      {item.tagline}
                    </p>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <span className="text-[10px] font-semibold text-purple-600 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/60 px-2 py-0.5 rounded-full">
                      {item.previewBadge}
                    </span>
                    <span className="text-xs text-purple-600 dark:text-purple-400 font-bold flex items-center gap-1">
                      <span>{isSelected ? 'Active' : 'View'}</span>
                      <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Interactive Step Detail Showcase */}
          <div className="mt-8 rounded-2xl border border-purple-200/60 dark:border-purple-900/50 bg-gradient-to-r from-purple-50/70 via-indigo-50/40 to-cyan-50/70 dark:from-slate-900 dark:via-purple-950/30 dark:to-slate-900 p-6 sm:p-8 backdrop-blur-md">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center text-xs font-bold">
                    {selectedStep}
                  </span>
                  <h4 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                    Step {selectedStep} Deep-Dive: {steps[selectedStep - 1].title}
                  </h4>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  {steps[selectedStep - 1].details.map((detail, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-2.5 p-3 rounded-xl bg-white/90 dark:bg-slate-800/90 border border-slate-200/60 dark:border-slate-700/60 text-xs shadow-sm"
                    >
                      <Check className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span className="text-slate-700 dark:text-slate-300 font-medium leading-relaxed">
                        {detail}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="shrink-0 flex items-center">
                <button
                  onClick={onStartJourney}
                  className="w-full md:w-auto px-6 py-3 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-purple-500/25 transition-all flex items-center justify-center gap-2"
                >
                  <span>Start Step 1 Now</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
