import React from 'react';
import { ArrowUp, Mail, Shield, FileText, Sparkles, Award } from 'lucide-react';

interface FooterProps {
  onOpenLegal: (type: 'privacy' | 'terms') => void;
  onReplayTitleCard: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenLegal, onReplayTitleCard }) => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          
          {/* Col 1 & 2: Brand & Tagline */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-400 p-[2px]">
                <div className="w-full h-full bg-slate-900 rounded-[10px] flex items-center justify-center">
                  <svg
                    className="w-5 h-5 text-purple-400"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M6 19V5" />
                    <path d="M6 5L18 19" />
                    <path d="M18 19V5" />
                    <circle cx="6" cy="5" r="2" fill="currentColor" />
                    <circle cx="18" cy="19" r="2" fill="currentColor" />
                  </svg>
                </div>
              </div>
              <div>
                <span className="text-xl font-black text-white tracking-tight">Nexora</span>
                <span className="block text-[10px] text-purple-400 font-semibold uppercase tracking-wider">
                  AI Career Ecosystem
                </span>
              </div>
            </div>

            <p className="text-slate-300 font-medium text-sm">
              “Your Goals. Your Journey. Your Future.”
            </p>
            <p className="text-slate-400 text-xs max-w-sm leading-relaxed">
              Turn your ambition into real-world skills, projects, and career opportunities — with your personal AI career mentor.
            </p>

            {/* Project Attribution Badge */}
            <div className="pt-2">
              <div className="inline-flex items-center gap-2 rounded-lg bg-slate-800/80 border border-slate-700/80 px-3 py-1.5 text-[11px] text-purple-300">
                <Award className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span>
                  OASIS INFOBYTE Internship Project · Neha Vinod Borkar
                </span>
              </div>
            </div>
          </div>

          {/* Col 3: Quick Navigation */}
          <div className="space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-white">
              Quick Links
            </p>
            <ul className="space-y-2">
              <li>
                <a href="#home" className="hover:text-purple-400 transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#how-it-works" className="hover:text-purple-400 transition-colors">
                  How It Works
                </a>
              </li>
              <li>
                <a href="#ecosystem" className="hover:text-purple-400 transition-colors">
                  Features & Ecosystem
                </a>
              </li>
              <li>
                <a href="#career-paths" className="hover:text-purple-400 transition-colors">
                  Career Paths
                </a>
              </li>
              <li>
                <a href="#why-nexora" className="hover:text-purple-400 transition-colors">
                  About & Why Nexora
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Platform Modules */}
          <div className="space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-white">
              Platform
            </p>
            <ul className="space-y-2">
              <li>
                <a href="#ai-mentor" className="hover:text-purple-400 transition-colors">
                  AI Personal Mentor
                </a>
              </li>
              <li>
                <a href="#project-lab" className="hover:text-purple-400 transition-colors">
                  Real-World Project Lab
                </a>
              </li>
              <li>
                <a href="#dashboard-preview" className="hover:text-purple-400 transition-colors">
                  Personalized Roadmaps
                </a>
              </li>
              <li>
                <a href="#ecosystem" className="hover:text-purple-400 transition-colors">
                  Skill Passport & Verification
                </a>
              </li>
            </ul>
          </div>

          {/* Col 5: Contact & Legal */}
          <div className="space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-white">
              Contact & Inquiries
            </p>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-slate-300">
                <Mail className="w-4 h-4 text-purple-400 shrink-0" />
                <span className="text-xs">contact@nexora-careers.demo</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Official contact placeholder for student prototype demo review.
              </p>
            </div>

            <div className="pt-2 space-y-1.5">
              <button
                onClick={() => onOpenLegal('privacy')}
                className="block hover:text-purple-400 transition-colors text-left"
              >
                Privacy Policy
              </button>
              <button
                onClick={() => onOpenLegal('terms')}
                className="block hover:text-purple-400 transition-colors text-left"
              >
                Terms of Use
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[11px] text-slate-500 text-center sm:text-left">
            © {currentYear} Nexora. All rights reserved. “Your Goals. Your Journey. Your Future.”
          </p>

          <div className="flex items-center gap-4">
            <button
              onClick={onReplayTitleCard}
              className="text-xs text-purple-400 hover:text-purple-300 flex items-center gap-1.5 font-medium"
            >
              <span>Replay Video Title Card</span>
            </button>

            <button
              onClick={scrollToTop}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              title="Back to Top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
