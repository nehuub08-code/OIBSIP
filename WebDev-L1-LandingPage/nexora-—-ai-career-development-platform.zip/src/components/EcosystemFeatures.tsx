import React, { useState } from 'react';
import {
  Compass,
  MapPin,
  Code2,
  MessageSquareText,
  Users,
  FolderGit2,
  ShieldCheck,
  FileSpreadsheet,
  BrainCircuit,
  Briefcase,
  Building2,
  TrendingUp,
  GraduationCap,
  GitPullRequest,
  Flame,
  Sparkles,
  ArrowRight,
  ChevronRight,
  Layers
} from 'lucide-react';
import { ECOSYSTEM_MODULES } from '../data/nexoraData';
import { EcosystemCategory, EcosystemModule } from '../types';

interface EcosystemFeaturesProps {
  onStartJourney: () => void;
  onSelectFeature?: (module: EcosystemModule) => void;
}

export const EcosystemFeatures: React.FC<EcosystemFeaturesProps> = ({
  onStartJourney,
  onSelectFeature,
}) => {
  const [activeCategory, setActiveCategory] = useState<EcosystemCategory>('All');
  const [expandedModuleId, setExpandedModuleId] = useState<string | null>(null);

  const categories: EcosystemCategory[] = [
    'All',
    'Discovery & Planning',
    'Skills & Projects',
    'Career & Opportunity',
    'Growth & Mentorship',
  ];

  const getModuleIcon = (iconName: string) => {
    switch (iconName) {
      case 'Compass':
        return Compass;
      case 'MapPin':
        return MapPin;
      case 'Code2':
        return Code2;
      case 'MessageSquareText':
        return MessageSquareText;
      case 'Users':
        return Users;
      case 'FolderGit2':
        return FolderGit2;
      case 'ShieldCheck':
        return ShieldCheck;
      case 'FileSpreadsheet':
        return FileSpreadsheet;
      case 'BrainCircuit':
        return BrainCircuit;
      case 'Briefcase':
        return Briefcase;
      case 'Building2':
        return Building2;
      case 'TrendingUp':
        return TrendingUp;
      case 'GraduationCap':
        return GraduationCap;
      case 'GitPullRequest':
        return GitPullRequest;
      case 'Flame':
        return Flame;
      case 'Sparkles':
        return Sparkles;
      default:
        return Sparkles;
    }
  };

  const getBadgeStyle = (badgeColor: string) => {
    switch (badgeColor) {
      case 'purple':
        return 'text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/60 border-purple-200 dark:border-purple-800';
      case 'blue':
        return 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 border-blue-200 dark:border-blue-800';
      case 'indigo':
        return 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-800';
      case 'emerald':
        return 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800';
      case 'amber':
        return 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-800';
      case 'rose':
        return 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-800';
      case 'cyan':
        return 'text-cyan-600 dark:text-cyan-400 bg-cyan-50 dark:bg-cyan-950/60 border-cyan-200 dark:border-cyan-800';
      case 'pink':
        return 'text-pink-600 dark:text-pink-400 bg-pink-50 dark:bg-pink-950/60 border-pink-200 dark:border-pink-800';
      case 'teal':
        return 'text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/60 border-teal-200 dark:border-teal-800';
      case 'orange':
        return 'text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/60 border-orange-200 dark:border-orange-800';
      case 'red':
        return 'text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/60 border-red-200 dark:border-red-800';
      default:
        return 'text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700';
    }
  };

  const filteredModules =
    activeCategory === 'All'
      ? ECOSYSTEM_MODULES
      : ECOSYSTEM_MODULES.filter((m) => m.category === activeCategory);

  return (
    <section id="ecosystem" className="py-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-cyan-400/40 bg-cyan-50 dark:bg-cyan-950/40 px-3.5 py-1 text-xs font-bold text-cyan-700 dark:text-cyan-300 uppercase">
            <span>Modular Career Architecture</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tight">
            Everything You Need.{' '}
            <span className="text-gradient-primary">One Connected Journey.</span>
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 font-normal">
            Nexora unifies learning, coding, communication, real projects, interview simulation, and job exploration into a synchronized career ecosystem.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`text-xs sm:text-sm font-semibold px-4 py-2 rounded-xl transition-all ${
                activeCategory === cat
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-500/25'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-750 border border-slate-200/80 dark:border-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* 16 Modules Grid */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {filteredModules.map((module) => {
            const Icon = getModuleIcon(module.icon);
            const isExpanded = expandedModuleId === module.id;

            return (
              <div
                key={module.id}
                className="group relative rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white/90 dark:bg-slate-850/80 p-5 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3.5">
                    <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400 flex items-center justify-center border border-purple-100 dark:border-purple-800/50 group-hover:scale-110 transition-transform">
                      <Icon className="w-5 h-5" />
                    </div>
                    {module.highlightTag && (
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getBadgeStyle(
                          module.badgeColor
                        )}`}
                      >
                        {module.highlightTag}
                      </span>
                    )}
                  </div>

                  <h3 className="text-base font-bold text-slate-900 dark:text-white tracking-tight mb-1.5">
                    {module.title}
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    {module.summary}
                  </p>

                  {/* Expandable Key Features */}
                  {isExpanded && (
                    <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1.5 animate-in fade-in duration-200">
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Features included:</p>
                      {module.keyFeatures.map((feat, i) => (
                        <div key={i} className="flex items-center gap-1.5 text-[11px] text-slate-700 dark:text-slate-300">
                          <span className="w-1 h-1 rounded-full bg-purple-500" />
                          <span>{feat}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <button
                    onClick={() => setExpandedModuleId(isExpanded ? null : module.id)}
                    className="text-[11px] font-semibold text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 inline-flex items-center gap-1"
                  >
                    <span>{isExpanded ? 'Hide details' : 'View highlights'}</span>
                    <ChevronRight className={`w-3 h-3 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                  </button>

                  <span className="text-[10px] text-slate-400 font-medium">
                    {module.category}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Ecosystem Bottom Call to Action */}
        <div className="mt-14 text-center">
          <button
            onClick={onStartJourney}
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 shadow-xl shadow-purple-500/25 transition-transform hover:scale-105 active:scale-95"
          >
            <span>Explore the Nexora Ecosystem</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </section>
  );
};
