import React, { useState } from 'react';
import {
  FolderGit2,
  Compass,
  Code2,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Terminal,
  FileCode2,
  Lightbulb,
  Check,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { SAMPLE_PROJECT_LAB_MILESTONES } from '../data/nexoraData';

interface ProjectLabProps {
  onStartJourney: () => void;
}

export const ProjectLab: React.FC<ProjectLabProps> = ({ onStartJourney }) => {
  const [activeMilestoneId, setActiveMilestoneId] = useState<number>(2); // Default to in-progress
  const [hintTier, setHintTier] = useState<number>(1);
  const [isCopiedCode, setIsCopiedCode] = useState(false);

  const activeMilestone =
    SAMPLE_PROJECT_LAB_MILESTONES.find((m) => m.id === activeMilestoneId) ||
    SAMPLE_PROJECT_LAB_MILESTONES[1];

  const hints = [
    'Hint 1 (Conceptual): Start by defining the Pydantic schema for your expected structured response.',
    'Hint 2 (API Call): Use the systemInstruction parameter to constrain the tone to an encouraging tutor.',
    'Hint 3 (Resilience): Wrap inference calls in a try-except block to gracefully handle model quota limits.',
  ];

  const handleCopyCode = () => {
    if (activeMilestone.codeSnippet) {
      navigator.clipboard.writeText(activeMilestone.codeSnippet);
      setIsCopiedCode(true);
      setTimeout(() => setIsCopiedCode(false), 2000);
    }
  };

  return (
    <section id="project-lab" className="py-24 relative overflow-hidden bg-slate-50/60 dark:bg-slate-900/40">
      {/* Ambient background decoration */}
      <div className="pointer-events-none absolute -top-10 left-1/3 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-rose-400/40 bg-rose-50 dark:bg-rose-950/40 px-3.5 py-1 text-xs font-bold text-rose-700 dark:text-rose-300 uppercase">
            <span>Experiential Learning</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tight">
            Don’t Just Learn Skills.{' '}
            <span className="text-gradient-warm">Demonstrate Them.</span>
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 font-normal">
            Move past passive video lectures. Work on authentic problem statements, receive progressive hints when stuck, and submit verified deliverables for your Skill Passport.
          </p>
        </div>

        {/* 3 Project Journey Cards */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 shadow-sm hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold text-sm mb-4">
              01
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1.5 flex items-center gap-2">
              <Compass className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              <span>Explore</span>
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Understand a real-world problem statement. Read real user stories, constraints, input requirements, and architecture diagrams before writing code.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 shadow-sm hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-sm mb-4">
              02
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1.5 flex items-center gap-2">
              <Code2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>Build</span>
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Develop your solution with progressive hints and guidance. Get step-by-step unblocking support without having the answers given away completely.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 shadow-sm hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-xl bg-cyan-100 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 flex items-center justify-center font-bold text-sm mb-4">
              03
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1.5 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
              <span>Demonstrate</span>
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Submit your work for evaluation, receive automated rubric feedback, and earn verified competencies linked directly into your public Skill Passport.
            </p>
          </div>
        </div>

        {/* Interactive Sample Project Showcase Card */}
        <div className="mt-12 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 shadow-2xl overflow-hidden">
          
          {/* Project Header Bar */}
          <div className="p-6 md:p-8 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-r from-purple-50/50 via-white to-indigo-50/50 dark:from-slate-900 dark:via-slate-850 dark:to-slate-900 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex flex-wrap items-center gap-2.5 mb-2">
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  Level: Beginner
                </span>
                <span className="text-xs text-slate-500 font-medium">Estimated Duration: ~8 Hours</span>
                <span className="text-xs bg-purple-100 dark:bg-purple-950/70 text-purple-700 dark:text-purple-300 font-bold px-2.5 py-0.5 rounded-full">
                  Verified Lab Project
                </span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                Build an AI-Powered Study Assistant
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                Skills: Python · APIs · Prompt Design · Pydantic · Testing
              </p>
            </div>

            <div className="shrink-0">
              <button
                onClick={onStartJourney}
                className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs sm:text-sm font-bold shadow-md shadow-purple-500/20 transition-all flex items-center gap-2"
              >
                <span>Start This Project</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Connected Milestones Stepper Bar */}
          <div className="p-4 md:px-8 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
              Interactive Milestone Journey (Click to preview code & checklist):
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {SAMPLE_PROJECT_LAB_MILESTONES.map((m) => {
                const isActive = activeMilestoneId === m.id;
                const isCompleted = m.status === 'completed';
                return (
                  <button
                    key={m.id}
                    onClick={() => setActiveMilestoneId(m.id)}
                    className={`text-left p-3 rounded-xl border transition-all ${
                      isActive
                        ? 'bg-purple-50 dark:bg-purple-950/50 border-purple-500 shadow-sm'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-mono font-bold text-slate-400">
                        0{m.id}
                      </span>
                      {isCompleted ? (
                        <Check className="w-3.5 h-3.5 text-emerald-500" />
                      ) : isActive ? (
                        <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
                      ) : (
                        <span className="text-[10px] text-slate-400">Upcoming</span>
                      )}
                    </div>
                    <p className={`text-xs font-bold truncate ${isActive ? 'text-purple-900 dark:text-purple-200' : 'text-slate-800 dark:text-slate-200'}`}>
                      {m.name}
                    </p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                      {m.tag}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Interactive Milestone Details & Code Preview */}
          <div className="p-6 md:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left side: Requirements & Rubric */}
            <div className="lg:col-span-5 space-y-5">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
                  Milestone {activeMilestone.id}: {activeMilestone.name}
                </span>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  {activeMilestone.description}
                </p>
              </div>

              {/* Checklist */}
              <div className="space-y-2">
                <p className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  Deliverable Checklist:
                </p>
                <div className="space-y-2">
                  {activeMilestone.checklist.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-2.5 text-xs text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-200/60 dark:border-slate-700/60"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Progressive Hints Drawer */}
              <div className="rounded-xl border border-amber-300/50 dark:border-amber-800/50 bg-amber-50/60 dark:bg-amber-950/20 p-3.5 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-800 dark:text-amber-300">
                    <Lightbulb className="w-4 h-4 text-amber-500" />
                    <span>Progressive Hint Engine</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3].map((t) => (
                      <button
                        key={t}
                        onClick={() => setHintTier(t)}
                        className={`text-[10px] font-bold px-2 py-0.5 rounded transition-all ${
                          hintTier === t
                            ? 'bg-amber-500 text-white'
                            : 'bg-amber-200/60 dark:bg-amber-900/40 text-amber-900 dark:text-amber-200'
                        }`}
                      >
                        Hint {t}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="text-xs text-amber-900 dark:text-amber-200/90 leading-relaxed italic">
                  {hints[hintTier - 1]}
                </p>
              </div>
            </div>

            {/* Right side: Code & Architecture Inspector */}
            <div className="lg:col-span-7">
              <div className="rounded-2xl border border-slate-800 bg-slate-900 text-slate-200 overflow-hidden shadow-xl">
                {/* Editor Header */}
                <div className="px-4 py-2.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                    </div>
                    <span className="font-mono text-slate-400 text-[11px] ml-2">
                      src/project_milestone_{activeMilestone.id}.py
                    </span>
                  </div>

                  <button
                    onClick={handleCopyCode}
                    className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 bg-slate-800 px-2 py-1 rounded"
                  >
                    <span>{isCopiedCode ? 'Copied!' : 'Copy Code'}</span>
                  </button>
                </div>

                {/* Code Body */}
                <pre className="p-4 text-xs font-mono overflow-x-auto leading-relaxed text-cyan-300/90">
                  <code>{activeMilestone.codeSnippet || '// Milestone ready for implementation'}</code>
                </pre>

                {/* Rubric Verification Status */}
                <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Skill Passport Rubric: Ready for Submission</span>
                  </span>
                  <span className="text-[11px] font-semibold text-purple-400">+350 Skill XP</span>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
