import React, { useState } from 'react';
import { X, ShieldCheck, FileText } from 'lucide-react';

interface LegalModalProps {
  isOpen: boolean;
  type: 'privacy' | 'terms';
  onClose: () => void;
}

export const LegalModal: React.FC<LegalModalProps> = ({ isOpen, type, onClose }) => {
  const [activeTab, setActiveTab] = useState<'privacy' | 'terms'>(type);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 overflow-y-auto"
    >
      <div className="relative w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl p-6 sm:p-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white bg-slate-100 dark:bg-slate-800 transition-colors"
          aria-label="Close modal"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 mb-6">
          <button
            onClick={() => setActiveTab('privacy')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'privacy'
                ? 'bg-purple-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Privacy Policy</span>
          </button>
          <button
            onClick={() => setActiveTab('terms')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'terms'
                ? 'bg-purple-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Terms of Use</span>
          </button>
        </div>

        {/* Content */}
        {activeTab === 'privacy' ? (
          <div className="space-y-4 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
              Nexora Privacy Policy
            </h3>
            <p>
              Your privacy and learning integrity are fundamental to Nexora. This prototype policy describes how student information, learning progress, and project submissions are handled within the platform.
            </p>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white pt-2">
              1. Information Collection
            </h4>
            <p>
              Nexora gathers profile preferences, selected career goals, completed milestone submissions, and code snippets entered into the interactive project lab solely to provide personalized mentorship and curriculum pacing.
            </p>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white pt-2">
              2. AI Mentorship Data Handling
            </h4>
            <p>
              Chat inquiries submitted to the Nexora AI Career Mentor are processed to generate contextual educational responses. Private student communications are never sold to external advertising brokers.
            </p>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white pt-2">
              3. Verifiable Skill Passport
            </h4>
            <p>
              Only deliverables explicitly marked as public by you are shareable on your public profile link. You retain full ownership of all code and projects authored in the Project Lab.
            </p>
          </div>
        ) : (
          <div className="space-y-4 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
              Nexora Terms of Use
            </h3>
            <p>
              Welcome to Nexora. By accessing our platform, you agree to these fair usage and educational integrity terms.
            </p>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white pt-2">
              1. Educational Prototype Notice
            </h4>
            <p>
              Nexora provides structured roadmaps, interactive coding exercises, and career preparation tools. The platform is designed for career development and skill verification. It does not promise guaranteed hiring or accredited university degrees without partner institution authorization.
            </p>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white pt-2">
              2. Academic Honesty in the Project Lab
            </h4>
            <p>
              Students are encouraged to utilize AI mentor guidance for unblocking and understanding concepts. Submitting unverified plagiarism or malicious code to the public ledger is strictly prohibited.
            </p>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white pt-2">
              3. Availability & Changes
            </h4>
            <p>
              Curricula, salary estimates, and market indicators are updated periodically to reflect current engineering industry standards.
            </p>
          </div>
        )}

        <div className="mt-8 pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 dark:bg-slate-800 text-white text-xs font-bold hover:bg-slate-800 dark:hover:bg-slate-700 transition-colors"
          >
            I Understand
          </button>
        </div>

      </div>
    </div>
  );
};
