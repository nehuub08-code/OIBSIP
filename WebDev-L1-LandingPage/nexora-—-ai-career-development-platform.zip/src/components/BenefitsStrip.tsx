import React from 'react';
import { MapPin, FolderGit2, Sparkles, Award } from 'lucide-react';

export const BenefitsStrip: React.FC = () => {
  const benefits = [
    {
      icon: MapPin,
      title: 'Personalized Career Roadmaps',
      description: 'Step-by-step milestones adapted to your existing background, target timeline, and career goal.',
      gradient: 'from-purple-500 to-indigo-600',
      shadow: 'group-hover:shadow-purple-500/20',
    },
    {
      icon: FolderGit2,
      title: 'Learn by Building Projects',
      description: 'Hands-on problem briefs with guided hints that turn theoretical concepts into practical portfolio proofs.',
      gradient: 'from-indigo-500 to-blue-600',
      shadow: 'group-hover:shadow-indigo-500/20',
    },
    {
      icon: Sparkles,
      title: 'AI-Powered Guidance',
      description: 'Context-aware explanations, instant doubt resolution, and adaptive suggestions along every step.',
      gradient: 'from-blue-500 to-cyan-500',
      shadow: 'group-hover:shadow-cyan-500/20',
    },
    {
      icon: Award,
      title: 'Career-Ready Skills',
      description: 'Rigorous technical and communication competencies mapped directly to real engineering expectations.',
      gradient: 'from-pink-500 to-rose-600',
      shadow: 'group-hover:shadow-pink-500/20',
    },
  ];

  return (
    <section className="relative z-10 -mt-4 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {benefits.map((benefit) => {
            const Icon = benefit.icon;
            return (
              <div
                key={benefit.title}
                className="group relative rounded-2xl border border-slate-200/80 dark:border-slate-800/80 bg-white/70 dark:bg-slate-900/60 p-5 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 backdrop-blur-sm"
              >
                <div
                  className={`w-11 h-11 rounded-xl bg-gradient-to-tr ${benefit.gradient} flex items-center justify-center text-white mb-4 shadow-md transition-transform group-hover:scale-105`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-tight mb-1.5">
                  {benefit.title}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
