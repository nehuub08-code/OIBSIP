import React, { useState } from 'react';
import {
  BrainCircuit,
  Bot,
  Terminal,
  BarChart3,
  Globe2,
  ShieldAlert,
  ArrowRight,
  Sparkles,
  Layers,
  Clock,
  TrendingUp,
  Search
} from 'lucide-react';
import { CAREER_PATHS } from '../data/nexoraData';
import { CareerPath } from '../types';

interface CareerPathsProps {
  onSelectPath: (path: CareerPath) => void;
  onStartJourney: () => void;
}

export const CareerPaths: React.FC<CareerPathsProps> = ({ onSelectPath, onStartJourney }) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filterOptions = ['All', 'AI & Data', 'Software Engineering', 'Infrastructure & Security'];

  // Icon mapping
  const getIcon = (id: string) => {
    switch (id) {
      case 'ai-engineer':
        return BrainCircuit;
      case 'ai-agent-engineer':
        return Bot;
      case 'software-engineer':
        return Terminal;
      case 'data-scientist':
        return BarChart3;
      case 'web-developer':
        return Globe2;
      case 'cybersecurity-analyst':
        return ShieldAlert;
      default:
        return Sparkles;
    }
  };

  const filteredPaths = CAREER_PATHS.filter((p) => {
    const matchesCategory = selectedFilter === 'All' || p.category === selectedFilter;
    const matchesSearch =
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.skills.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <section id="career-paths" className="py-24 bg-slate-50/70 dark:bg-slate-900/60 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="pointer-events-none absolute bottom-10 left-1/4 w-[600px] h-[300px] bg-purple-500/10 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-indigo-400/40 bg-indigo-50 dark:bg-indigo-950/40 px-3.5 py-1 text-xs font-bold text-indigo-700 dark:text-indigo-300 uppercase">
            <span>Specialized Tech Tracks</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Your Ambition.{' '}
            <span className="text-gradient-purple-coral">Your Path.</span>
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 font-normal">
            Choose from industry-calibrated learning roadmaps designed to build real competencies, portfolio projects, and technical interview readiness.
          </p>
        </div>

        {/* Filter Tabs & Search Bar */}
        <div className="mt-10 flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Category Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2">
            {filterOptions.map((opt) => (
              <button
                key={opt}
                onClick={() => setSelectedFilter(opt)}
                className={`text-xs sm:text-sm font-semibold px-4 py-2 rounded-xl transition-all ${
                  selectedFilter === opt
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-500/20'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-750 border border-slate-200/80 dark:border-slate-700'
                }`}
              >
                {opt}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search skills, titles (e.g. Python)..."
              className="w-full pl-10 pr-4 py-2 rounded-xl text-xs sm:text-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>
        </div>

        {/* Career Path Cards Grid */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPaths.map((path) => {
            const Icon = getIcon(path.id);
            return (
              <div
                key={path.id}
                className="group relative rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-850 p-6 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between"
              >
                <div>
                  {/* Top Header */}
                  <div className="flex items-start justify-between gap-3 mb-4">
                    <div
                      className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${path.gradient} flex items-center justify-center text-white shadow-md transition-transform group-hover:scale-105`}
                    >
                      <Icon className="w-6 h-6" />
                    </div>

                    <div className="flex flex-col items-end">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/60 px-2.5 py-0.5 rounded-full border border-purple-200/50 dark:border-purple-800/50">
                        {path.difficulty}
                      </span>
                      <span className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {path.estTimeToReady}
                      </span>
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">
                    {path.title}
                  </h3>
                  <p className="text-xs text-purple-600 dark:text-purple-400 font-semibold mb-2">
                    {path.tagline}
                  </p>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-4 line-clamp-3">
                    {path.description}
                  </p>

                  {/* Skills Pills */}
                  <div className="space-y-1.5 mb-4">
                    <p className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      Example Skills Required:
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {path.skills.slice(0, 4).map((skill) => (
                        <span
                          key={skill}
                          className="text-[11px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded-md border border-slate-200/60 dark:border-slate-700/60"
                        >
                          {skill}
                        </span>
                      ))}
                      {path.skills.length > 4 && (
                        <span className="text-[10px] font-semibold text-slate-400 self-center">
                          +{path.skills.length - 4} more
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>Demand: {path.marketDemand}</span>
                  </div>

                  <button
                    onClick={() => onSelectPath(path)}
                    className="text-xs font-bold text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 flex items-center gap-1 group/btn"
                  >
                    <span>Explore Path</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Banner */}
        <div className="mt-12 text-center p-6 rounded-2xl bg-white/70 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-center sm:text-left">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              Not sure which career path fits your current background?
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Let the AI Career Diagnostic evaluate your interests and generate a custom hybrid track.
            </p>
          </div>
          <button
            onClick={onStartJourney}
            className="shrink-0 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-md shadow-purple-500/20 transition-all flex items-center gap-2"
          >
            <span>Take 2-Min Career Diagnostic</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </section>
  );
};
