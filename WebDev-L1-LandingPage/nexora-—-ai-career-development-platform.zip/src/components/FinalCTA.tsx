import React from 'react';
import { ArrowRight, Sparkles, Compass, CheckCircle2 } from 'lucide-react';

interface FinalCTAProps {
  onStartJourney: () => void;
  onExploreCareerPaths: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({
  onStartJourney,
  onExploreCareerPaths,
}) => {
  return (
    <section className="py-20 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Deep Indigo-to-Purple Gradient Showcase Box */}
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-tr from-purple-950 via-indigo-900 to-slate-900 border border-purple-500/30 p-8 sm:p-14 text-center text-white shadow-2xl">
          
          {/* Subtle Ambient Decorative Glowing Shapes */}
          <div className="pointer-events-none absolute -top-24 -left-24 w-80 h-80 rounded-full bg-purple-600/30 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-24 -right-24 w-80 h-80 rounded-full bg-cyan-500/30 blur-3xl" />
          <div className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-indigo-500/20 blur-3xl" />

          <div className="relative z-10 max-w-3xl mx-auto space-y-6">
            
            {/* Badge */}
            <div className="inline-flex items-center gap-2 rounded-full border border-purple-400/40 bg-purple-500/20 px-4 py-1.5 text-xs font-bold text-purple-200 uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
              <span>Free Student Onboarding Diagnostic</span>
            </div>

            {/* Headline */}
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight leading-tight">
              Your Next Chapter{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-300 via-indigo-200 to-cyan-300">
                Starts Here.
              </span>
            </h2>

            {/* Supporting Text */}
            <p className="text-base sm:text-lg text-slate-300 max-w-xl mx-auto font-normal leading-relaxed">
              You don’t need to have everything figured out. You just need a starting point.
            </p>

            {/* Micro Highlights */}
            <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-300 pt-2">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Zero Tuition Barrier</span>
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                <span>Calibrated to Your Pace</span>
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-purple-400" />
                <span>AI Guidance Every Step</span>
              </span>
            </div>

            {/* Action Buttons */}
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={onStartJourney}
                className="w-full sm:w-auto px-8 py-4 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-cyan-400 via-teal-300 to-indigo-300 hover:from-cyan-300 hover:to-indigo-200 shadow-xl shadow-cyan-500/25 transition-transform hover:scale-105 active:scale-95 flex items-center justify-center gap-2 text-sm sm:text-base"
              >
                <span>Start My Journey</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onExploreCareerPaths}
                className="w-full sm:w-auto px-6 py-4 rounded-xl font-semibold text-white bg-white/10 hover:bg-white/15 border border-white/20 transition-all flex items-center justify-center gap-2 text-sm sm:text-base"
              >
                <Compass className="w-4 h-4 text-cyan-300" />
                <span>Explore Career Paths</span>
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
