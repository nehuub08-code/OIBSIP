import React from 'react';
import { X, Clock, TrendingUp, CheckCircle2, ArrowRight, Sparkles, FolderGit2, BookOpen } from 'lucide-react';
import { CareerPath } from '../types';

interface CareerPathModalProps {
  path: CareerPath | null;
  onClose: () => void;
  onStartWithGoal: (goalTitle: string) => void;
}

export const CareerPathModal: React.FC<CareerPathModalProps> = ({
  path,
  onClose,
  onStartWithGoal,
}) => {
  if (!path) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 overflow-y-auto"
    >
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl p-6 sm:p-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/60 px-3 py-1 rounded-full border border-purple-200 dark:border-purple-800">
              {path.category}
            </span>
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-1 rounded-full border border-emerald-200 dark:border-emerald-800">
              <TrendingUp className="w-3 h-3" />
              <span>{path.marketDemand} Market Demand</span>
            </span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            {path.title}
          </h3>
          <p className="text-xs sm:text-sm font-semibold text-purple-600 dark:text-purple-400">
            {path.tagline}
          </p>
        </div>

        {/* Overview */}
        <div className="mt-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
          {path.overview}
        </div>

        {/* Meta Stats Row */}
        <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 text-center">
            <p className="text-[11px] text-slate-400 uppercase font-bold">Estimated Time</p>
            <p className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200 mt-0.5">{path.estTimeToReady}</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 text-center">
            <p className="text-[11px] text-slate-400 uppercase font-bold">Entry Difficulty</p>
            <p className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200 mt-0.5">{path.difficulty}</p>
          </div>
          <div className="col-span-2 sm:col-span-1 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 text-center">
            <p className="text-[11px] text-slate-400 uppercase font-bold">Target Roles</p>
            <p className="text-xs sm:text-sm font-bold text-purple-600 dark:text-purple-400 mt-0.5 truncate">{path.sampleRoles[0]}</p>
          </div>
        </div>

        {/* Core Curriculum Milestones */}
        <div className="mt-6 space-y-3">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Roadmap Milestones & Syllabus
            </h4>
          </div>
          <div className="space-y-2.5">
            {path.coreMilestones.map((m, i) => (
              <div
                key={i}
                className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-start gap-3 text-xs"
              >
                <span className="font-mono font-bold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/60 px-2 py-0.5 rounded border border-purple-200 dark:border-purple-800 shrink-0">
                  {m.week}
                </span>
                <div>
                  <p className="font-bold text-slate-800 dark:text-slate-200">{m.title}</p>
                  <p className="text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">{m.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Capstone Project Showcase */}
        <div className="mt-6 p-4 rounded-2xl border border-cyan-300/40 dark:border-cyan-800/40 bg-cyan-50/50 dark:bg-cyan-950/20 space-y-2">
          <div className="flex items-center gap-2">
            <FolderGit2 className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
            <h4 className="text-xs font-bold text-cyan-900 dark:text-cyan-200 uppercase tracking-wider">
              Capstone Lab Project
            </h4>
          </div>
          <p className="text-sm font-bold text-slate-900 dark:text-white">
            {path.capstoneProject.title}
          </p>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            {path.capstoneProject.description}
          </p>
          <div className="flex flex-wrap gap-1.5 pt-1">
            {path.capstoneProject.technologies.map((tech) => (
              <span
                key={tech}
                className="text-[10px] font-semibold bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700"
              >
                {tech}
              </span>
            ))}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="mt-8 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-4">
          <button
            onClick={onClose}
            className="text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 px-4 py-2"
          >
            Close Preview
          </button>
          <button
            onClick={() => {
              onClose();
              onStartWithGoal(path.title);
            }}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-bold text-xs sm:text-sm shadow-lg shadow-purple-500/25 transition-transform hover:scale-105 active:scale-95 flex items-center gap-1.5"
          >
            <span>Start {path.title} Roadmap</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
