import React, { useState, useEffect } from 'react';
import { Sparkles, X, Play, Award } from 'lucide-react';

interface OpeningTitleCardProps {
  onDismiss?: () => void;
}

export const OpeningTitleCard: React.FC<OpeningTitleCardProps> = ({ onDismiss }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [progress, setProgress] = useState(100);

  useEffect(() => {
    // 2.5 seconds duration as specified in mandatory demo video instruction
    const duration = 2500;
    const intervalTime = 25;
    const step = (intervalTime / duration) * 100;

    const progressTimer = setInterval(() => {
      setProgress((prev) => Math.max(0, prev - step));
    }, intervalTime);

    const dismissTimer = setTimeout(() => {
      setIsVisible(false);
      if (onDismiss) {
        onDismiss();
      }
    }, duration);

    return () => {
      clearInterval(progressTimer);
      clearTimeout(dismissTimer);
    };
  }, [onDismiss]);

  if (!isVisible) {
    return null;
  }

  return (
    <div
      role="dialog"
      aria-label="Demo Video Opening Title Card"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/95 backdrop-blur-xl transition-opacity duration-500 p-4"
    >
      <div className="relative w-full max-w-xl overflow-hidden rounded-2xl border border-purple-500/30 bg-slate-900/90 p-8 text-center shadow-2xl shadow-purple-900/40">
        {/* Ambient background glow */}
        <div className="pointer-events-none absolute -top-24 -left-24 h-64 w-64 rounded-full bg-purple-600/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -right-24 h-64 w-64 rounded-full bg-cyan-600/20 blur-3xl" />

        {/* Skip button */}
        <button
          onClick={() => {
            setIsVisible(false);
            if (onDismiss) onDismiss();
          }}
          className="absolute top-4 right-4 text-xs flex items-center gap-1 text-slate-400 hover:text-white bg-slate-800/60 hover:bg-slate-800 px-2.5 py-1 rounded-full border border-slate-700/50 transition-colors"
          title="Skip intro title card"
        >
          <span>Skip</span>
          <X className="w-3.5 h-3.5" />
        </button>

        {/* Badge */}
        <div className="inline-flex items-center gap-2 rounded-full border border-purple-400/30 bg-purple-500/10 px-4 py-1.5 text-xs font-semibold tracking-wider text-purple-300 uppercase mb-6">
          <Award className="w-3.5 h-3.5 text-purple-400" />
          <span>Demo Video Opening Card</span>
        </div>

        {/* Mandatory exact text lines */}
        <div className="space-y-3">
          <h1 className="text-xl md:text-2xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-purple-300 via-indigo-200 to-cyan-300 uppercase">
            OASIS INFOBYTE INTERNSHIP
          </h1>

          <div className="py-2">
            <p className="text-2xl md:text-3xl font-extrabold text-white tracking-wide">
              Neha Vinod Borkar
            </p>
            <p className="text-sm md:text-base font-medium text-purple-300/90 mt-1">
              Web Development & Designing
            </p>
          </div>

          <div className="inline-block rounded-lg bg-slate-800/80 px-4 py-2 border border-slate-700/60 mt-2">
            <p className="text-sm font-semibold text-cyan-300">
              Level 1 — Task 1: Landing Page
            </p>
          </div>
        </div>

        {/* Progress bar countdown */}
        <div className="mt-8 space-y-1.5">
          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 transition-all ease-linear"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-[11px] text-slate-400 flex items-center justify-between">
            <span>Displaying required opening card...</span>
            <span>Entering Nexora Live Preview</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export const TitleCardReplayButton: React.FC<{ onReplay: () => void }> = ({ onReplay }) => {
  return (
    <button
      onClick={onReplay}
      className="fixed bottom-4 left-4 z-40 flex items-center gap-2 rounded-full border border-purple-500/30 bg-slate-900/90 px-3 py-1.5 text-xs font-medium text-purple-300 shadow-lg backdrop-blur-md hover:bg-slate-800 hover:text-white transition-all hover:scale-105"
      title="Replay mandatory demo video title card for recording"
    >
      <Play className="w-3 h-3 text-purple-400 fill-purple-400" />
      <span>Replay 2s Video Intro</span>
    </button>
  );
};
