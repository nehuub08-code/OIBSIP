import React, { useState } from 'react';
import {
  X,
  Compass,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Clock,
  Layers,
  BrainCircuit,
  Bot,
  Download,
  Share2
} from 'lucide-react';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedGoal?: string;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onClose,
  preselectedGoal,
}) => {
  const [step, setStep] = useState<number>(1);
  const [educationLevel, setEducationLevel] = useState('Undergraduate Student');
  const [interests, setInterests] = useState<string[]>(['AI & Machine Learning', 'Autonomous Agents']);
  const [careerGoal, setCareerGoal] = useState(preselectedGoal || 'AI Engineer');
  const [weeklyHours, setWeeklyHours] = useState(12);
  const [isCopied, setIsCopied] = useState(false);

  if (!isOpen) return null;

  const interestOptions = [
    'AI & Machine Learning',
    'Autonomous Agents',
    'Full-Stack Web',
    'Data Science & Analytics',
    'Cybersecurity & Defense',
    'Distributed Systems',
    'Algorithm Optimization',
    'Mobile Development',
  ];

  const toggleInterest = (interest: string) => {
    setInterests((prev) =>
      prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]
    );
  };

  const handleShareOrCopy = () => {
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 overflow-y-auto"
    >
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl p-6 sm:p-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Progress Stepper Bar */}
        <div className="mb-6 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider">
            <span>Step {step} of 3</span>
            <span>
              {step === 1 && 'Background & Interests'}
              {step === 2 && 'Goal & Weekly Commitment'}
              {step === 3 && 'Your Generated Roadmap'}
            </span>
          </div>
          <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-purple-600 to-cyan-500 transition-all duration-300"
              style={{ width: `${(step / 3) * 100}%` }}
            />
          </div>
        </div>

        {/* Step 1: Background & Interests */}
        {step === 1 && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold text-purple-600 dark:text-purple-400 uppercase tracking-wider mb-1">
                <Compass className="w-3.5 h-3.5" />
                <span>Step 1: Discover Yourself</span>
              </div>
              <h3 className="text-2xl font-extrabold text-slate-900 dark:text-white">
                Tell us about your background & ambitions
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Nexora calibrates your starting difficulty and study milestones accordingly.
              </p>
            </div>

            {/* Current Education / Status */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                Current Background:
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                {[
                  'Undergraduate Student',
                  'High School Student',
                  'Recent Graduate',
                  'Self-Taught / Career Switcher',
                ].map((status) => (
                  <button
                    key={status}
                    type="button"
                    onClick={() => setEducationLevel(status)}
                    className={`p-3 rounded-xl border text-left text-xs font-semibold transition-all ${
                      educationLevel === status
                        ? 'border-purple-600 bg-purple-50 dark:bg-purple-950/50 text-purple-700 dark:text-purple-300 shadow-sm'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                    }`}
                  >
                    {status}
                  </button>
                ))}
              </div>
            </div>

            {/* Topics of Interest */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                Select Your Key Interests (Choose 1 or more):
              </label>
              <div className="flex flex-wrap gap-2">
                {interestOptions.map((topic) => {
                  const isChecked = interests.includes(topic);
                  return (
                    <button
                      key={topic}
                      type="button"
                      onClick={() => toggleInterest(topic)}
                      className={`text-xs px-3 py-1.5 rounded-xl font-medium border transition-all flex items-center gap-1.5 ${
                        isChecked
                          ? 'bg-purple-600 text-white border-purple-600'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-purple-300'
                      }`}
                    >
                      {isChecked && <CheckCircle2 className="w-3.5 h-3.5" />}
                      <span>{topic}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <button
                onClick={() => setStep(2)}
                className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-1.5"
              >
                <span>Continue to Step 2</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Goal & Weekly Commitment */}
        {step === 2 && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold text-purple-600 dark:text-purple-400 uppercase tracking-wider mb-1">
                <Layers className="w-3.5 h-3.5" />
                <span>Step 2: Choose Your Direction</span>
              </div>
              <h3 className="text-2xl font-extrabold text-slate-900 dark:text-white">
                Select your primary career goal
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                You can change this or customize hybrid tracks at any time.
              </p>
            </div>

            {/* Career Track Selection */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {[
                { title: 'AI Engineer', tag: 'PyTorch, LLMs, Neural Networks' },
                { title: 'AI Agent Engineer', tag: 'LangGraph, Reasoning, Tool Calling' },
                { title: 'Software Engineer', tag: 'Algorithms, Systems, Databases' },
                { title: 'Data Scientist', tag: 'Inference, Statistics, Scikit-Learn' },
                { title: 'Full-Stack Developer', tag: 'React, Node, TypeScript, APIs' },
                { title: 'Cybersecurity Analyst', tag: 'Threat Analysis, Network Security' },
              ].map((item) => (
                <button
                  key={item.title}
                  type="button"
                  onClick={() => setCareerGoal(item.title)}
                  className={`p-3.5 rounded-xl border text-left transition-all ${
                    careerGoal === item.title
                      ? 'border-purple-600 bg-purple-50 dark:bg-purple-950/50 shadow-sm'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 hover:border-slate-300'
                  }`}
                >
                  <p className={`text-xs font-bold ${careerGoal === item.title ? 'text-purple-900 dark:text-purple-200' : 'text-slate-800 dark:text-slate-200'}`}>
                    {item.title}
                  </p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">{item.tag}</p>
                </button>
              ))}
            </div>

            {/* Weekly Hours Slider */}
            <div className="space-y-2 p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Weekly Study Availability:
                </label>
                <span className="text-xs font-black text-purple-600 dark:text-purple-400 bg-purple-100 dark:bg-purple-950/80 px-2.5 py-0.5 rounded-md">
                  {weeklyHours} Hours / Week
                </span>
              </div>
              <input
                type="range"
                min="4"
                max="25"
                step="1"
                value={weeklyHours}
                onChange={(e) => setWeeklyHours(Number(e.target.value))}
                className="w-full accent-purple-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>Light (4 hrs/wk)</span>
                <span>Moderate (12 hrs/wk)</span>
                <span>Intensive (25 hrs/wk)</span>
              </div>
            </div>

            <div className="pt-4 flex items-center justify-between">
              <button
                onClick={() => setStep(1)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>

              <button
                onClick={() => setStep(3)}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-1.5"
              >
                <span>Generate My Roadmap</span>
                <Sparkles className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Generated Custom Personalized Roadmap */}
        {step === 3 && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider mb-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Personalized Roadmap Generated</span>
              </div>
              <h3 className="text-2xl font-extrabold text-slate-900 dark:text-white">
                {careerGoal} · Custom 16-Week Blueprint
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Paced for {educationLevel} at {weeklyHours} hours/week.
              </p>
            </div>

            {/* Generated Phase Breakdown */}
            <div className="space-y-3">
              {[
                {
                  phase: 'Phase 1 · Weeks 1–4',
                  title: 'Core Foundations & Syntax Mastery',
                  deliverable: 'CLI Algorithmic Problem Solver',
                  skills: ['Clean Code Principles', 'NumPy & Vectors', 'Computational Big-O'],
                },
                {
                  phase: 'Phase 2 · Weeks 5–8',
                  title: 'Model Architecture & Deep Frameworks',
                  deliverable: 'Trained Neural Classifier from Scratch',
                  skills: ['PyTorch Tensors', 'Loss Functions', 'Gradient Descent Optimization'],
                },
                {
                  phase: 'Phase 3 · Weeks 9–13',
                  title: 'Project Lab Capstone & Deployment',
                  deliverable: 'AI Study Assistant Microservice with FastAPI',
                  skills: ['RAG Vector DB', 'Docker Containers', 'Prompt Evaluation Rubrics'],
                },
                {
                  phase: 'Phase 4 · Weeks 14–16',
                  title: 'Interview Preparation & Portfolio Launch',
                  deliverable: 'Verifiable Skill Passport & ATS Resume',
                  skills: ['Technical Mock Screens', 'STAR Behavioral Drills', 'Internship Matching'],
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-850/70 space-y-1.5 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-purple-600 dark:text-purple-400">
                      {item.phase}
                    </span>
                    <span className="text-[10px] bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 px-2 py-0.5 rounded font-bold">
                      {item.deliverable}
                    </span>
                  </div>
                  <p className="font-bold text-slate-800 dark:text-slate-200 text-sm">
                    {item.title}
                  </p>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {item.skills.map((s) => (
                      <span
                        key={s}
                        className="text-[10px] bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Action Bar */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                onClick={handleShareOrCopy}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center gap-1.5"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>{isCopied ? 'Roadmap Link Copied!' : 'Share / Copy Roadmap'}</span>
              </button>

              <button
                onClick={onClose}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-1.5"
              >
                <span>Save & Enter Learning Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
