import React from 'react';
import { HelpCircle, GitFork, AlertOctagon, CheckCircle2, ArrowDown, Sparkles } from 'lucide-react';

interface ProblemSolutionProps {
  onStartJourney: () => void;
}

export const ProblemSolution: React.FC<ProblemSolutionProps> = ({ onStartJourney }) => {
  const problems = [
    {
      number: '01',
      title: 'Too Many Choices',
      subtitle: 'Unsure which career path to follow',
      icon: GitFork,
      color: 'from-amber-500 to-orange-500',
      description:
        'Endless bootcamps, conflicting YouTube tutorials, and changing buzzwords leave you overwhelmed about which direction genuinely fits your unique background.',
      impact: 'Result: Analysis paralysis and months lost browsing without committing.',
    },
    {
      number: '02',
      title: 'No Clear Roadmap',
      subtitle: 'Confused about what to learn first',
      icon: HelpCircle,
      color: 'from-rose-500 to-pink-600',
      description:
        'Jumping randomly between syntax cheatsheets and advanced documentation without prerequisite clarity creates gaps in foundational thinking and confidence.',
      impact: 'Result: High burnout, tutorial hell, and zero compound progression.',
    },
    {
      number: '03',
      title: 'No Proof of Skills',
      subtitle: 'Struggling to turn knowledge into practical experience',
      icon: AlertOctagon,
      color: 'from-purple-500 to-indigo-600',
      description:
        'Passive video watching and copy-pasted code snippets don’t demonstrate real engineering capability or stand out to internship reviewers looking for genuine problem solvers.',
      impact: 'Result: Empty GitHub portfolios and rejection letters without feedback.',
    },
  ];

  return (
    <section className="py-20 bg-slate-100/60 dark:bg-slate-900/40 relative overflow-hidden">
      {/* Subtle background glow */}
      <div className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-purple-500/5 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-rose-300/50 dark:border-rose-900/60 bg-rose-50 dark:bg-rose-950/40 px-3.5 py-1 text-xs font-bold text-rose-700 dark:text-rose-300 uppercase">
            <span>The Reality of Learning Tech</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tight">
            Stop Guessing.{' '}
            <span className="text-gradient-warm">Start Growing.</span>
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 font-normal">
            Learning without direction can leave you confused about what to learn next, which skills matter, and how to prove your abilities.
          </p>
        </div>

        {/* 3 Problem Cards */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          {problems.map((prob) => {
            const Icon = prob.icon;
            return (
              <div
                key={prob.title}
                className="relative rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white/90 dark:bg-slate-850/80 p-6 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div
                      className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${prob.color} flex items-center justify-center text-white shadow-md`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-black tracking-widest text-slate-300 dark:text-slate-700 font-mono">
                      {prob.number}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    {prob.title}
                  </h3>
                  <p className="text-xs font-semibold text-rose-600 dark:text-rose-400 mb-3">
                    {prob.subtitle}
                  </p>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    {prob.description}
                  </p>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 italic">
                    {prob.impact}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Visual Connecting Arrow */}
        <div className="my-10 flex flex-col items-center justify-center">
          <div className="w-10 h-10 rounded-full bg-gradient-to-b from-purple-500 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-purple-500/30 animate-bounce">
            <ArrowDown className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400 mt-2">
            The Nexora Shift
          </span>
        </div>

        {/* The Solution Banner */}
        <div className="relative overflow-hidden rounded-3xl border border-purple-500/30 bg-gradient-to-r from-purple-900 via-indigo-950 to-slate-900 text-white p-8 md:p-12 shadow-2xl">
          <div className="pointer-events-none absolute -right-20 -bottom-20 w-80 h-80 bg-cyan-500/20 rounded-full blur-3xl" />
          
          <div className="relative z-10 max-w-3xl mx-auto text-center space-y-4">
            <div className="inline-flex items-center gap-2 rounded-full border border-cyan-400/40 bg-cyan-500/20 px-3.5 py-1 text-xs font-bold text-cyan-300 uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              <span>The Connected Solution</span>
            </div>

            <h3 className="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight">
              One connected journey from discovering your goal to demonstrating your abilities and preparing for real opportunities.
            </h3>

            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-normal">
              Nexora eliminates the guesswork. Everything — your roadmap, daily practice, hands-on projects, interview simulations, and AI mentor — works in tandem so you constantly make verifiable progress.
            </p>

            <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold bg-white/10 px-3 py-1.5 rounded-full border border-white/10">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Zero Tutorial Hell</span>
              </span>
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold bg-white/10 px-3 py-1.5 rounded-full border border-white/10">
                <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                <span>Real Portfolio Deliverables</span>
              </span>
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold bg-white/10 px-3 py-1.5 rounded-full border border-white/10">
                <CheckCircle2 className="w-4 h-4 text-purple-400" />
                <span>Continuous Adaptive Feedback</span>
              </span>
            </div>

            <div className="pt-4">
              <button
                onClick={onStartJourney}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-400 via-teal-400 to-indigo-500 hover:from-cyan-300 hover:to-indigo-400 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-500/25 transition-transform hover:scale-105 active:scale-95"
              >
                Experience the Difference →
              </button>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
