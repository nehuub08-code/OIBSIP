import React, { useState } from 'react';
import {
  Target,
  BookOpen,
  Terminal,
  FolderGit2,
  CheckCircle2,
  Briefcase,
  TrendingUp,
  Sparkles,
  ArrowRight,
  Shield,
  Layers,
  Cpu
} from 'lucide-react';

export const WhyNexora: React.FC = () => {
  const [activeJourneyStep, setActiveJourneyStep] = useState<number>(3);

  const differentiators = [
    {
      title: 'Personalized Around Your Goals',
      description:
        'Calibrated to your exact current abilities, college commitments, and target timeline — no one-size-fits-all curriculum.',
      icon: Target,
      gradient: 'from-purple-500 to-indigo-600',
    },
    {
      title: 'Connects Learning with Real Projects',
      description:
        'Every line of theory is immediately validated through hands-on coding katas and portfolio-grade deliverables in the Project Lab.',
      icon: FolderGit2,
      gradient: 'from-indigo-500 to-blue-600',
    },
    {
      title: 'Brings Prep & Opportunities Together',
      description:
        'Technical drills, English communication, ATS resumes, and vetted entry-level internships live inside the same ecosystem.',
      icon: Briefcase,
      gradient: 'from-blue-500 to-cyan-500',
    },
    {
      title: 'Adapts When Your Ambitions Change',
      description:
        'If you pivot from software engineering to machine learning, Nexora re-maps your completed credits and calculates your fastest crossover path.',
      icon: Layers,
      gradient: 'from-pink-500 to-rose-600',
    },
    {
      title: 'AI Mentor Available 24/7',
      description:
        'Instant concept breakdowns, code reviews, and reassuring guidance whenever you encounter blockers, day or late night.',
      icon: Sparkles,
      gradient: 'from-amber-500 to-orange-500',
    },
  ];

  // Central Journey Flow Nodes: Goal -> Learn -> Practise -> Build -> Demonstrate -> Prepare -> Grow
  const journeyNodes = [
    { name: 'Goal', icon: Target, desc: 'Diagnostic & career path alignment' },
    { name: 'Learn', icon: BookOpen, desc: 'Foundations & conceptual mastery' },
    { name: 'Practise', icon: Terminal, desc: 'Interactive coding katas & drills' },
    { name: 'Build', icon: FolderGit2, desc: 'Industry-grade project implementation' },
    { name: 'Demonstrate', icon: CheckCircle2, desc: 'Rubric verification & Skill Passport' },
    { name: 'Prepare', icon: Briefcase, desc: 'ATS resume & mock interview drills' },
    { name: 'Grow', icon: TrendingUp, desc: 'Internship matches & long-term career' },
  ];

  return (
    <section id="why-nexora" className="py-24 relative overflow-hidden">
      {/* Background radial soft light */}
      <div className="pointer-events-none absolute top-1/2 right-10 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-purple-400/40 bg-purple-50 dark:bg-purple-950/40 px-3.5 py-1 text-xs font-bold text-purple-700 dark:text-purple-300 uppercase">
            <span>The Nexora Difference</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tight">
            Your Career Journey,{' '}
            <span className="text-gradient-purple-coral">Connected.</span>
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 font-normal">
            Why jump between disconnected platforms when every milestone of your professional development can compound together?
          </p>
        </div>

        {/* Central Journey Diagram: Goal -> Learn -> Practise -> Build -> Demonstrate -> Prepare -> Grow */}
        <div className="mt-16 rounded-3xl border border-purple-200/60 dark:border-purple-900/50 bg-gradient-to-r from-purple-50/70 via-indigo-50/40 to-cyan-50/70 dark:from-slate-900 dark:via-purple-950/30 dark:to-slate-900 p-6 sm:p-10 shadow-lg">
          <div className="text-center mb-6">
            <span className="text-xs font-extrabold uppercase tracking-widest text-purple-600 dark:text-purple-400">
              The Connected Progression Loop
            </span>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Click any stage to see how it synchronizes with your personal roadmap:
            </p>
          </div>

          {/* Interactive Stepper Nodes */}
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 relative">
            {journeyNodes.map((node, index) => {
              const NodeIcon = node.icon;
              const isActive = activeJourneyStep === index;
              return (
                <React.Fragment key={node.name}>
                  <button
                    onClick={() => setActiveJourneyStep(index)}
                    className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl border transition-all text-xs font-bold shadow-sm ${
                      isActive
                        ? 'bg-purple-600 text-white border-purple-600 shadow-purple-500/30 scale-105'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-purple-300'
                    }`}
                  >
                    <NodeIcon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-purple-600 dark:text-purple-400'}`} />
                    <span>{node.name}</span>
                  </button>

                  {index < journeyNodes.length - 1 && (
                    <span className="text-slate-400 dark:text-slate-600 font-bold hidden md:inline">
                      →
                    </span>
                  )}
                </React.Fragment>
              );
            })}
          </div>

          {/* Active Node Detail Card */}
          <div className="mt-6 max-w-xl mx-auto text-center p-4 rounded-xl bg-white/90 dark:bg-slate-800/90 border border-slate-200/60 dark:border-slate-700/60 shadow-sm animate-in fade-in duration-200">
            <p className="text-xs font-bold text-purple-600 dark:text-purple-400 uppercase tracking-wider">
              Stage 0{activeJourneyStep + 1}: {journeyNodes[activeJourneyStep].name}
            </p>
            <p className="text-xs text-slate-700 dark:text-slate-300 font-medium mt-1">
              {journeyNodes[activeJourneyStep].desc}
            </p>
          </div>
        </div>

        {/* 5 Core Differentiator Cards Grid */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {differentiators.map((diff) => {
            const Icon = diff.icon;
            return (
              <div
                key={diff.title}
                className="group relative rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white/80 dark:bg-slate-850/80 p-6 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <div
                  className={`w-11 h-11 rounded-xl bg-gradient-to-tr ${diff.gradient} flex items-center justify-center text-white mb-4 shadow-md group-hover:scale-105 transition-transform`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                  {diff.title}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  {diff.description}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
