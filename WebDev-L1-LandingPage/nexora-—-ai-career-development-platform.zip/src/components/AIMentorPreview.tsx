import React, { useState } from 'react';
import { Bot, User, Send, Sparkles, AlertCircle, ArrowRight, CornerDownLeft, CheckCircle2 } from 'lucide-react';
import { MENTOR_DEMO_PRESETS } from '../data/nexoraData';
import { ChatMessage } from '../types';

interface AIMentorPreviewProps {
  onStartJourney: () => void;
  onExploreProjects: () => void;
}

export const AIMentorPreview: React.FC<AIMentorPreviewProps> = ({
  onStartJourney,
  onExploreProjects,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'user',
      text: 'I want to become an AI Engineer, but I am a beginner. Where should I start?',
      timestamp: '10:42 AM',
    },
    {
      id: '2',
      sender: 'mentor',
      text: "Let's start with your current skills. We’ll build your journey step by step, starting with Python fundamentals and gradually progressing to machine learning projects.",
      timestamp: '10:42 AM',
      actionCard: {
        title: 'Python Foundations for AI',
        description: 'Bite-sized exercises covering variables, data structures, and NumPy vectorization.',
        ctaText: 'Start Foundation Step →',
        type: 'roadmap',
      },
    },
  ]);

  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const handlePresetClick = (presetPrompt: string) => {
    const matched = MENTOR_DEMO_PRESETS.find((p) => p.prompt === presetPrompt);
    if (!matched) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: matched.prompt,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsTyping(true);

    setTimeout(() => {
      const mentorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'mentor',
        text: matched.answer,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        actionCard: matched.action,
      };
      setMessages((prev) => [...prev, mentorMsg]);
      setIsTyping(false);
    }, 600);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const userText = inputMessage.trim();
    setInputMessage('');

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsTyping(true);

    // Smart contextual mentor response for demonstration
    setTimeout(() => {
      let responseText = `That's a thoughtful question regarding "${userText}". In your personalized Nexora roadmap, we break this down into actionable milestones: foundational theory, hands-on coding drills, and project lab verification.`;
      
      if (userText.toLowerCase().includes('python') || userText.toLowerCase().includes('code')) {
        responseText = `Python is the gold standard in modern AI and software engineering. I recommend focusing on vector operations in NumPy and clean function modularity before moving into neural architectures. Ready to see the beginner Python project brief?`;
      } else if (userText.toLowerCase().includes('job') || userText.toLowerCase().includes('intern')) {
        responseText = `To stand out for student internships, focus on proof of work: having 2 deployed, well-documented projects in your Skill Passport carries far more weight than 10 passive tutorial certificates.`;
      }

      const mentorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'mentor',
        text: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, mentorMsg]);
      setIsTyping(false);
    }, 700);
  };

  const handleActionClick = (type: 'project' | 'roadmap' | 'quiz') => {
    if (type === 'project') {
      onExploreProjects();
    } else {
      onStartJourney();
    }
  };

  return (
    <section id="ai-mentor" className="py-24 bg-slate-900 text-white relative overflow-hidden">
      {/* Decorative gradient glow */}
      <div className="pointer-events-none absolute top-10 left-10 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl -z-10" />
      <div className="pointer-events-none absolute bottom-10 right-10 w-96 h-96 bg-cyan-600/20 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-purple-400/40 bg-purple-500/10 px-3.5 py-1 text-xs font-bold text-purple-300 uppercase">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Interactive AI Mentor Showcase</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight">
            Not Just a Roadmap.{' '}
            <span className="text-gradient-purple-coral">A Mentor Along the Way.</span>
          </h2>
          <p className="text-base sm:text-lg text-slate-300 font-normal">
            Get help understanding concepts, resolving doubts, choosing your next task, and improving your projects — with guidance that adapts to your progress.
          </p>

          {/* Clear Demonstration Badge as required by brief */}
          <div className="inline-flex items-center gap-2 rounded-lg bg-slate-800/80 px-3 py-1.5 border border-slate-700 text-xs text-slate-300">
            <AlertCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>Interactive Chat Preview · Click prompts below to test mentor guidance</span>
          </div>
        </div>

        {/* Chat Interface Container */}
        <div className="mt-12 max-w-4xl mx-auto rounded-2xl border border-slate-700/80 bg-slate-850/90 shadow-2xl backdrop-blur-xl overflow-hidden flex flex-col h-[580px]">
          
          {/* Chat Window Top Bar */}
          <div className="p-4 bg-slate-800/90 border-b border-slate-700/80 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 flex items-center justify-center text-white shadow-md">
                  <Bot className="w-5 h-5" />
                </div>
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-slate-800 rounded-full" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-white">Nexora AI Career Mentor</h3>
                  <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full font-semibold border border-purple-500/30">
                    Active & Adaptive
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">Context: Undergraduate Student · Goal: AI Engineer</p>
              </div>
            </div>

            <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span>Real-time Guidance</span>
            </div>
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
            {messages.map((msg) => {
              const isUser = msg.sender === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 items-start ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
                >
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      isUser
                        ? 'bg-purple-600 text-white'
                        : 'bg-gradient-to-tr from-indigo-600 to-cyan-500 text-white'
                    }`}
                  >
                    {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                  </div>

                  <div className={`max-w-[85%] sm:max-w-[75%] space-y-2`}>
                    <div
                      className={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed whitespace-pre-line ${
                        isUser
                          ? 'bg-purple-600 text-white rounded-tr-none'
                          : 'bg-slate-800 border border-slate-700 text-slate-200 rounded-tl-none'
                      }`}
                    >
                      {msg.text}
                    </div>

                    {/* Action Card if present */}
                    {msg.actionCard && (
                      <div className="p-3.5 rounded-xl border border-purple-500/30 bg-purple-950/40 text-left">
                        <div className="flex items-center justify-between text-xs font-bold text-purple-200 mb-1">
                          <span>{msg.actionCard.title}</span>
                          <span className="text-[10px] uppercase text-cyan-400 font-mono tracking-wider">Suggested Step</span>
                        </div>
                        <p className="text-xs text-slate-300 mb-2.5">
                          {msg.actionCard.description}
                        </p>
                        <button
                          onClick={() => handleActionClick(msg.actionCard!.type)}
                          className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-purple-500 to-indigo-600 text-white text-xs font-bold hover:from-purple-400 hover:to-indigo-500 transition-colors flex items-center gap-1.5"
                        >
                          <span>{msg.actionCard.ctaText}</span>
                        </button>
                      </div>
                    )}

                    <span className="text-[10px] text-slate-500 block px-1">
                      {msg.timestamp}
                    </span>
                  </div>
                </div>
              );
            })}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex gap-3 items-center text-slate-400 text-xs pl-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-900/50 flex items-center justify-center text-indigo-400">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="flex items-center gap-1.5 bg-slate-800 px-3 py-2 rounded-xl border border-slate-700">
                  <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce" />
                  <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                  <span className="text-xs text-slate-400 ml-1">Nexora Mentor is formulating guidance...</span>
                </div>
              </div>
            )}
          </div>

          {/* Clickable Suggested Prompts Strip */}
          <div className="p-3 bg-slate-800/60 border-t border-slate-700/80">
            <p className="text-[11px] font-semibold text-slate-400 mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-cyan-400" />
              <span>Try a suggested prompt:</span>
            </p>
            <div className="flex flex-wrap gap-2">
              {[
                'Help me choose a career.',
                'Explain a difficult concept.',
                'What should I learn next?',
                'Review my project progress.',
              ].map((pText) => (
                <button
                  key={pText}
                  onClick={() => handlePresetClick(pText)}
                  className="text-xs px-3 py-1.5 rounded-lg bg-slate-750 hover:bg-purple-900/50 border border-slate-700 hover:border-purple-500/50 text-slate-200 hover:text-white transition-all text-left flex items-center gap-1.5 group"
                >
                  <span>{pText}</span>
                  <ArrowRight className="w-3 h-3 text-slate-400 group-hover:text-purple-300 group-hover:translate-x-0.5 transition-transform" />
                </button>
              ))}
            </div>
          </div>

          {/* Input Form */}
          <form
            onSubmit={handleSendMessage}
            className="p-3 sm:p-4 bg-slate-800 border-t border-slate-700 flex items-center gap-2"
          >
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Ask your mentor anything (e.g. 'How do I start Python?')..."
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <button
              type="submit"
              disabled={!inputMessage.trim()}
              className="p-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-40 disabled:hover:bg-purple-600 text-white transition-all shadow-md"
              title="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>

      </div>
    </section>
  );
};
