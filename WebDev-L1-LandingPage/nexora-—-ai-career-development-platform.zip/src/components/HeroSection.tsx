import React, { useState } from 'react';
import {
  ArrowRight,
  Sparkles,
  Bot,
  BrainCircuit,
  Flame,
  Award,
  CheckCircle2,
  Clock,
  ChevronRight,
  Code2,
  LineChart,
  Layers,
  Compass,
  Play
} from 'lucide-react';

interface HeroSectionProps {
  onStartJourney: () => void;
  onExploreHowItWorks: () => void;
  onExploreCareerPath: (pathId: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onStartJourney,
  onExploreHowItWorks,
  onExploreCareerPath,
}) => {
  // Interactive state for dashboard preview
  const [selectedGoal, setSelectedGoal] = useState<'AI Engineer' | 'Full-Stack Developer' | 'Data Scientist'>('AI Engineer');
  const [activeTab, setActiveTab] = useState<'roadmap' | 'skills'>('roadmap');
  const [isNextActionClicked, setIsNextActionClicked] = useState(false);

  const goalData = {
    'AI Engineer': {
      streak: 14,
      xp: 1420,
      weeklyProgress: 78,
      currentMilestone: 'Transformers & RAG Pipelines',
      nextAction: 'Build your first ML project',
      nextActionTime: '45 mins remaining',
      skills: [
        { name: 'Python', level: '92%', status: 'Advanced' },
        { name: 'PyTorch & Tensors', level: '74%', status: 'Proficient' },
        { name: 'Data Structures (DSA)', level: '85%', status: 'Strong' },
        { name: 'Technical Communication', level: '80%', status: 'Fluent' },
      ],
      pathId: 'ai-engineer',
    },
    'Full-Stack Developer': {
      streak: 11,
      xp: 1180,
      weeklyProgress: 84,
      currentMilestone: 'React State & Backend APIs',
      nextAction: 'Implement JWT Auth & Middleware',
      nextActionTime: '30 mins remaining',
      skills: [
        { name: 'React & Next.js', level: '88%', status: 'Proficient' },
        { name: 'TypeScript', level: '82%', status: 'Strong' },
        { name: 'Node.js & Express', level: '76%', status: 'Intermediate' },
        { name: 'PostgreSQL & ORM', level: '70%', status: 'Intermediate' },
      ],
      pathId: 'web-developer',
    },
    'Data Scientist': {
      streak: 9,
      xp: 990,
      weeklyProgress: 68,
      currentMilestone: 'Hypothesis Testing & Feature Selection',
      nextAction: 'Complete Random Forest Model tuning',
      nextActionTime: '50 mins remaining',
      skills: [
        { name: 'Statistical Inference', level: '86%', status: 'Strong' },
        { name: 'SQL & Window Functions', level: '90%', status: 'Advanced' },
        { name: 'Scikit-Learn & ML', level: '72%', status: 'Proficient' },
        { name: 'Executive Storytelling', level: '78%', status: 'Fluent' },
      ],
      pathId: 'data-scientist',
    },
  };

  const current = goalData[selectedGoal];

  return (
    <section id="home" className="relative pt-28 pb-16 md:pt-36 md:pb-24 overflow-hidden">
      {/* Background Decorative Mesh Gradients */}
      <div className="pointer-events-none absolute top-12 left-1/2 -translate-x-1/2 w-[1000px] h-[550px] bg-gradient-to-tr from-purple-500/15 via-indigo-500/10 to-cyan-400/15 rounded-full blur-3xl -z-10" />
      <div className="pointer-events-none absolute -top-10 -right-20 w-80 h-80 bg-pink-500/10 rounded-full blur-3xl -z-10" />
      <div className="pointer-events-none absolute bottom-0 left-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Hero Text & CTAs */}
          <div className="lg:col-span-6 space-y-6 text-center lg:text-left">
            {/* Small Badge */}
            <div className="inline-flex items-center gap-2 rounded-full border border-purple-400/40 bg-purple-500/10 dark:bg-purple-950/50 px-4 py-1.5 text-xs font-bold tracking-wider text-purple-700 dark:text-purple-300 uppercase shadow-sm">
              <span className="flex h-2 w-2 rounded-full bg-cyan-500 animate-pulse" />
              <span>YOUR PERSONAL AI CAREER ECOSYSTEM</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.12]">
              Your Future Doesn’t Happen.{' '}
              <span className="text-gradient-purple-coral block sm:inline">
                You Build It.
              </span>
            </h1>

            {/* Description */}
            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-xl mx-auto lg:mx-0 leading-relaxed font-normal">
              Discover your career path, build in-demand skills, create real-world projects, and prepare for internships and jobs — with an AI mentor guiding your journey.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={onStartJourney}
                className="w-full sm:w-auto px-7 py-3.5 rounded-xl font-bold text-white bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2 text-base"
              >
                <span>Start My Journey</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onExploreHowItWorks}
                className="w-full sm:w-auto px-6 py-3.5 rounded-xl font-semibold text-slate-700 dark:text-slate-200 bg-white/80 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-750 transition-all flex items-center justify-center gap-2 text-base shadow-sm hover:shadow"
              >
                <span>Explore How It Works</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            {/* Supporting line */}
            <p className="text-xs sm:text-sm font-medium text-slate-500 dark:text-slate-400 pt-1">
              ✨ Your goals. Your pace. Your personalized roadmap.
            </p>

            {/* Quick Stats Strip */}
            <div className="pt-4 grid grid-cols-3 gap-3 border-t border-slate-200/80 dark:border-slate-800/80 max-w-md mx-auto lg:mx-0">
              <div className="text-center lg:text-left">
                <p className="text-xl font-black text-purple-600 dark:text-purple-400">100%</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Personalized Pace</p>
              </div>
              <div className="text-center lg:text-left">
                <p className="text-xl font-black text-indigo-600 dark:text-indigo-400">Real-World</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Project Lab</p>
              </div>
              <div className="text-center lg:text-left">
                <p className="text-xl font-black text-cyan-600 dark:text-cyan-400">24/7</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">AI Mentor Guidance</p>
              </div>
            </div>
          </div>

          {/* Right Column: Visually Rich Interactive Career Dashboard Preview */}
          <div className="lg:col-span-6 relative">
            
            {/* Floating Achievement Badge 1 (Top Left) */}
            <div className="hidden sm:flex absolute -top-5 -left-4 z-20 items-center gap-2.5 rounded-xl bg-white/90 dark:bg-slate-800/90 p-2.5 shadow-xl border border-purple-200/50 dark:border-purple-800/50 backdrop-blur-md animate-float-slow">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-400 to-orange-500 flex items-center justify-center text-white shadow-sm">
                <Flame className="w-4 h-4" />
              </div>
              <div>
                <p className="text-[11px] font-bold text-slate-800 dark:text-slate-100">{current.streak}-Day Streak!</p>
                <p className="text-[10px] text-amber-600 dark:text-amber-400 font-medium">Momentum Active</p>
              </div>
            </div>

            {/* Floating Achievement Badge 2 (Top Right) */}
            <div className="hidden sm:flex absolute -bottom-5 -right-4 z-20 items-center gap-2.5 rounded-xl bg-white/90 dark:bg-slate-800/90 p-2.5 shadow-xl border border-cyan-200/50 dark:border-cyan-800/50 backdrop-blur-md">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-400 to-blue-500 flex items-center justify-center text-white shadow-sm">
                <Award className="w-4 h-4" />
              </div>
              <div>
                <p className="text-[11px] font-bold text-slate-800 dark:text-slate-100">+{current.xp} Skill XP</p>
                <p className="text-[10px] text-cyan-600 dark:text-cyan-400 font-medium">Verified by Lab Rubric</p>
              </div>
            </div>

            {/* Main Interactive Product Card */}
            <div className="relative rounded-2xl border border-slate-200/90 dark:border-slate-800/90 bg-white/80 dark:bg-slate-900/80 shadow-2xl backdrop-blur-xl p-5 sm:p-6 transition-all">
              
              {/* Card Header: Career Goal Selector & Live Status */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800/80 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] uppercase tracking-wider font-bold text-purple-600 dark:text-purple-400">
                      Active Career Goal
                    </span>
                    <span className="flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
                  </div>
                  {/* Goal Dropdown / Switcher */}
                  <div className="flex items-center gap-1.5 mt-1">
                    {(['AI Engineer', 'Full-Stack Developer', 'Data Scientist'] as const).map((g) => (
                      <button
                        key={g}
                        onClick={() => setSelectedGoal(g)}
                        className={`text-xs px-2.5 py-1 rounded-lg font-semibold transition-all ${
                          selectedGoal === g
                            ? 'bg-purple-600 text-white shadow-sm'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        {g}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Progress Circle & Weekly % */}
                <div className="flex items-center gap-2.5 bg-slate-50 dark:bg-slate-850 px-3 py-1.5 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
                  <div className="relative w-8 h-8 flex items-center justify-center">
                    <svg className="w-8 h-8 transform -rotate-90">
                      <circle
                        cx="16"
                        cy="16"
                        r="13"
                        stroke="currentColor"
                        strokeWidth="3"
                        fill="transparent"
                        className="text-slate-200 dark:text-slate-700"
                      />
                      <circle
                        cx="16"
                        cy="16"
                        r="13"
                        stroke="currentColor"
                        strokeWidth="3"
                        fill="transparent"
                        strokeDasharray={81.6}
                        strokeDashoffset={81.6 - (81.6 * current.weeklyProgress) / 100}
                        strokeLinecap="round"
                        className="text-purple-600 dark:text-purple-400 transition-all duration-700"
                      />
                    </svg>
                    <span className="absolute text-[10px] font-bold text-slate-800 dark:text-slate-200">
                      {current.weeklyProgress}%
                    </span>
                  </div>
                  <div className="text-left">
                    <p className="text-[11px] font-bold text-slate-800 dark:text-slate-200">Weekly Pace</p>
                    <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">On Schedule</p>
                  </div>
                </div>
              </div>

              {/* Friendly AI Mentor Card */}
              <div className="mt-4 rounded-xl border border-purple-200/80 dark:border-purple-900/50 bg-gradient-to-r from-purple-500/10 via-indigo-500/5 to-cyan-500/10 p-3.5 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shrink-0 shadow-sm">
                  <Bot className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span>Nexora AI Mentor</span>
                      <span className="text-[10px] bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300 px-1.5 py-0.2 rounded font-semibold">Adaptive</span>
                    </span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400">Just now</span>
                  </div>
                  <p className="text-xs text-slate-700 dark:text-slate-300 mt-1 font-medium leading-relaxed">
                    “Ready to take your next step? You’ve conquered the foundations. Let’s connect your theory into a practical portfolio deliverable!”
                  </p>
                </div>
              </div>

              {/* View Toggle: Roadmap Milestones vs Skill Meters */}
              <div className="mt-4 flex items-center justify-between border-b border-slate-100 dark:border-slate-800/80 pb-2">
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setActiveTab('roadmap')}
                    className={`text-xs font-bold pb-1 transition-colors ${
                      activeTab === 'roadmap'
                        ? 'text-purple-600 dark:text-purple-400 border-b-2 border-purple-600'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    Personalized Roadmap
                  </button>
                  <button
                    onClick={() => setActiveTab('skills')}
                    className={`text-xs font-bold pb-1 transition-colors ${
                      activeTab === 'skills'
                        ? 'text-purple-600 dark:text-purple-400 border-b-2 border-purple-600'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    Mastered Skills
                  </button>
                </div>
                <span className="text-[11px] text-slate-400 font-medium">Simulated Preview</span>
              </div>

              {/* Tab Content */}
              {activeTab === 'roadmap' ? (
                <div className="mt-3 space-y-2.5">
                  {/* Completed Milestone */}
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs">
                    <div className="flex items-center gap-2.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                      <div>
                        <p className="font-semibold text-slate-800 dark:text-slate-200">Core Foundations & Architecture</p>
                        <p className="text-[10px] text-slate-500">Milestone 1 · Completed</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-full">
                      Verified ✓
                    </span>
                  </div>

                  {/* In-Progress Milestone */}
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-purple-50/60 dark:bg-purple-950/30 border border-purple-200/60 dark:border-purple-800/60 text-xs">
                    <div className="flex items-center gap-2.5">
                      <div className="w-4 h-4 rounded-full border-2 border-purple-600 dark:border-purple-400 border-t-transparent animate-spin shrink-0" />
                      <div>
                        <p className="font-semibold text-purple-900 dark:text-purple-200">{current.currentMilestone}</p>
                        <p className="text-[10px] text-purple-700/80 dark:text-purple-300/80">Milestone 2 · In Progress (65%)</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-purple-700 dark:text-purple-300 bg-purple-100 dark:bg-purple-900/60 px-2 py-0.5 rounded-full">
                      Current
                    </span>
                  </div>

                  {/* Upcoming Milestone */}
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50/40 dark:bg-slate-850/30 border border-slate-100 dark:border-slate-800 text-xs opacity-75">
                    <div className="flex items-center gap-2.5">
                      <Clock className="w-4 h-4 text-slate-400 shrink-0" />
                      <div>
                        <p className="font-semibold text-slate-600 dark:text-slate-400">Technical Interview & Mock Drills</p>
                        <p className="text-[10px] text-slate-400">Milestone 3 · Up next</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-medium text-slate-400">Locked</span>
                  </div>
                </div>
              ) : (
                /* Skills Tab */
                <div className="mt-3 grid grid-cols-2 gap-2.5">
                  {current.skills.map((skill) => (
                    <div
                      key={skill.name}
                      className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800"
                    >
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="font-bold text-slate-800 dark:text-slate-200 truncate">{skill.name}</span>
                        <span className="text-[11px] font-bold text-purple-600 dark:text-purple-400">{skill.level}</span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full transition-all duration-500"
                          style={{ width: skill.level }}
                        />
                      </div>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1">{skill.status}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* Next Action Card */}
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80">
                <button
                  onClick={() => setIsNextActionClicked(true)}
                  className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between group ${
                    isNextActionClicked
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-700'
                      : 'bg-gradient-to-r from-slate-900 to-indigo-950 text-white border-transparent hover:shadow-md'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-lg bg-purple-500/30 flex items-center justify-center text-cyan-300">
                      <Play className="w-3.5 h-3.5 fill-current" />
                    </div>
                    <div>
                      <p className={`text-xs font-bold ${isNextActionClicked ? 'text-emerald-800 dark:text-emerald-200' : 'text-white'}`}>
                        {isNextActionClicked ? 'Action Initialized in Lab!' : `Next Action: ${current.nextAction}`}
                      </p>
                      <p className={`text-[10px] ${isNextActionClicked ? 'text-emerald-600 dark:text-emerald-300' : 'text-slate-300'}`}>
                        {isNextActionClicked ? 'Redirecting to Project Lab...' : current.nextActionTime}
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-purple-300 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>

              {/* Deep Link to Career Path Modal */}
              <div className="mt-3 text-center">
                <button
                  onClick={() => onExploreCareerPath(current.pathId)}
                  className="text-xs font-semibold text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 inline-flex items-center gap-1"
                >
                  <span>View Full {selectedGoal} Roadmap Details</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
