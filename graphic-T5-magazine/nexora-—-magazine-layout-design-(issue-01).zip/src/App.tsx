import React, { useState, useEffect } from 'react';
import { TopBar } from './components/TopBar';
import { ReaderControls } from './components/ReaderControls';
import { MagazineContainer } from './components/MagazineContainer';
import { Page1Cover } from './components/pages/Page1Cover';
import { Page2EditorNote } from './components/pages/Page2EditorNote';
import { Page3AIFeature } from './components/pages/Page3AIFeature';
import { Page4VisualStory } from './components/pages/Page4VisualStory';
import { Page5BuildersPlaybook } from './components/pages/Page5BuildersPlaybook';
import { Page6ClosingPage } from './components/pages/Page6ClosingPage';
import { DeliverablesModal } from './components/DeliverablesModal';
import { PdfExportModal } from './components/PdfExportModal';
import { GuideToggles, MAGAZINE_PAGES, ViewMode } from './types/magazine';
import { Layers, BookOpen, Printer, Download, Sparkles, CheckCircle2, ChevronRight, ChevronLeft } from 'lucide-react';

export default function App() {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [viewMode, setViewMode] = useState<ViewMode>('single');
  const [scale, setScale] = useState<number>(1);
  const [guides, setGuides] = useState<GuideToggles>({
    showBleed: false,
    showTrim: false,
    showMargins: false,
    showGrid: false,
  });

  const [isDeliverablesOpen, setIsDeliverablesOpen] = useState<boolean>(false);
  const [deliverablesInitialTab, setDeliverablesInitialTab] = useState<string>('readme');
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isDeliverablesOpen || isExportOpen) return;
      if (e.key === 'ArrowRight' || e.key === 'PageDown') {
        setCurrentPage((prev) => Math.min(6, prev + 1));
      } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        setCurrentPage((prev) => Math.max(1, prev - 1));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isDeliverablesOpen, isExportOpen]);

  const toggleGuide = (guide: keyof GuideToggles) => {
    setGuides((prev) => ({
      ...prev,
      [guide]: !prev[guide],
    }));
  };

  const renderPage = (pageNum: number) => {
    switch (pageNum) {
      case 1:
        return <Page1Cover showGuides={guides.showGrid} />;
      case 2:
        return <Page2EditorNote showGuides={guides.showGrid} />;
      case 3:
        return <Page3AIFeature showGuides={guides.showGrid} />;
      case 4:
        return <Page4VisualStory showGuides={guides.showGrid} />;
      case 5:
        return <Page5BuildersPlaybook showGuides={guides.showGrid} />;
      case 6:
        return <Page6ClosingPage showGuides={guides.showGrid} />;
      default:
        return <Page1Cover />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Strict 3-Zone Top Navigation Bar */}
      <TopBar
        viewMode={viewMode}
        onSelectViewMode={setViewMode}
        onOpenDeliverables={() => {
          setDeliverablesInitialTab('readme');
          setIsDeliverablesOpen(true);
        }}
        onOpenChecklist={() => {
          setDeliverablesInitialTab('checklist');
          setIsDeliverablesOpen(true);
        }}
        onOpenExport={() => setIsExportOpen(true)}
      />

      {/* Reader & Inspection Controls */}
      <ReaderControls
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        guides={guides}
        onToggleGuide={toggleGuide}
        scale={scale}
        onScaleChange={setScale}
      />

      {/* MAIN SCREEN CANVAS */}
      <main className="no-print flex-1 py-8 px-4 sm:px-6 overflow-x-auto flex flex-col items-center justify-start bg-radial from-slate-900 to-slate-950">
        {/* SINGLE PAGE VIEW */}
        {viewMode === 'single' && (
          <div className="w-full max-w-4xl flex flex-col items-center">
            <MagazineContainer
              pageNumber={currentPage}
              guides={guides}
              scale={scale}
            >
              {renderPage(currentPage)}
            </MagazineContainer>

            {/* Quick Next/Prev floating bar below */}
            <div className="mt-6 flex items-center justify-center gap-4 text-xs">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-3 py-1.5 bg-slate-900 border border-slate-800 rounded text-slate-300 hover:text-white disabled:opacity-30 cursor-pointer flex items-center gap-1 transition-colors"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                Previous Page
              </button>

              <span className="font-mono text-slate-400">
                {MAGAZINE_PAGES[currentPage - 1].section}
              </span>

              <button
                onClick={() => setCurrentPage((p) => Math.min(6, p + 1))}
                disabled={currentPage === 6}
                className="px-3 py-1.5 bg-slate-900 border border-slate-800 rounded text-slate-300 hover:text-white disabled:opacity-30 cursor-pointer flex items-center gap-1 transition-colors"
              >
                Next Page
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* TWO-PAGE EDITORIAL SPREAD VIEW */}
        {viewMode === 'spread' && (
          <div className="w-full max-w-7xl flex flex-col items-center">
            {currentPage === 1 ? (
              // Cover Spread (solo focal display)
              <div className="w-full max-w-md flex flex-col items-center">
                <div className="text-center mb-3 text-xs font-mono text-slate-400 uppercase tracking-widest">
                  Outside Front Cover (Solo Spread)
                </div>
                <MagazineContainer
                  pageNumber={1}
                  guides={guides}
                  scale={scale * 0.9}
                >
                  <Page1Cover />
                </MagazineContainer>
              </div>
            ) : currentPage === 6 ? (
              // Closing Page Spread (solo focal display)
              <div className="w-full max-w-md flex flex-col items-center">
                <div className="text-center mb-3 text-xs font-mono text-slate-400 uppercase tracking-widest">
                  Back / Closing Manifesto (Solo Spread)
                </div>
                <MagazineContainer
                  pageNumber={6}
                  guides={guides}
                  scale={scale * 0.9}
                >
                  <Page6ClosingPage />
                </MagazineContainer>
              </div>
            ) : (
              // 2-Page Center Spread
              <div className="w-full flex flex-col items-center">
                <div className="text-center mb-3 text-xs font-mono text-slate-400 uppercase tracking-widest">
                  Editorial 2-Page Spread: {currentPage <= 3 ? 'Pages 02 & 03' : 'Pages 04 & 05'}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-5xl justify-center items-center">
                  {currentPage <= 3 ? (
                    <>
                      <MagazineContainer
                        pageNumber={2}
                        guides={guides}
                        scale={scale * 0.72}
                      >
                        <Page2EditorNote />
                      </MagazineContainer>
                      <MagazineContainer
                        pageNumber={3}
                        guides={guides}
                        scale={scale * 0.72}
                      >
                        <Page3AIFeature />
                      </MagazineContainer>
                    </>
                  ) : (
                    <>
                      <MagazineContainer
                        pageNumber={4}
                        guides={guides}
                        scale={scale * 0.72}
                      >
                        <Page4VisualStory />
                      </MagazineContainer>
                      <MagazineContainer
                        pageNumber={5}
                        guides={guides}
                        scale={scale * 0.72}
                      >
                        <Page5BuildersPlaybook />
                      </MagazineContainer>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ALL 6 PAGES VIEW (Vertical Proofing Gallery) */}
        {viewMode === 'all' && (
          <div className="w-full max-w-4xl space-y-12 flex flex-col items-center pb-12">
            <div className="text-center text-xs text-slate-400 font-mono">
              Proofing All 6 Pages in Consecutive Editorial Order · Ready for Multi-Page PDF Review
            </div>

            {MAGAZINE_PAGES.map((page) => (
              <div key={page.pageNumber} className="w-full flex flex-col items-center">
                <div className="w-full max-w-2xl flex items-center justify-between text-xs text-slate-400 pb-2 px-1 font-mono">
                  <span className="font-bold text-[#48D9D0]">PAGE 0{page.pageNumber}</span>
                  <span className="text-slate-300">{page.section}</span>
                  <span>{page.isFullBleed ? 'Full-Bleed Image Page' : 'Editorial Multi-Column Grid'}</span>
                </div>
                <MagazineContainer
                  pageNumber={page.pageNumber}
                  guides={guides}
                  scale={scale}
                >
                  {renderPage(page.pageNumber)}
                </MagazineContainer>
              </div>
            ))}
          </div>
        )}

        {/* Thumbnail Filmstrip Navigation (Bottom) */}
        <div className="mt-12 w-full max-w-5xl border-t border-slate-800 pt-6">
          <div className="flex items-center justify-between mb-3 text-xs text-slate-400">
            <span className="font-semibold text-slate-200">Page Filmstrip</span>
            <span className="font-mono text-[11px]">Click to jump to any page</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            {MAGAZINE_PAGES.map((page) => (
              <button
                key={page.pageNumber}
                onClick={() => {
                  setCurrentPage(page.pageNumber);
                  if (viewMode === 'all') setViewMode('single');
                }}
                className={`p-2 bg-slate-900 border text-left transition-all cursor-pointer ${
                  currentPage === page.pageNumber
                    ? 'border-[#3867FF] ring-2 ring-[#3867FF]/30'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="aspect-[210/297] bg-slate-950 flex flex-col items-center justify-center p-2 mb-2 border border-slate-800 relative overflow-hidden">
                  <span className="text-lg font-bold font-mono text-slate-300">
                    0{page.pageNumber}
                  </span>
                  <span className="text-[9px] font-mono text-[#3867FF] text-center mt-1 truncate w-full">
                    {page.isFullBleed ? 'FULL BLEED' : 'EDITORIAL'}
                  </span>
                </div>
                <div className="text-[11px] font-bold text-white truncate">
                  {page.title}
                </div>
                <div className="text-[10px] text-slate-400 truncate">
                  {page.section}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Task 5 Information Footer Bar */}
        <div className="mt-12 w-full max-w-5xl bg-slate-900/60 border border-slate-800 p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <div>
            <span className="text-white font-semibold">Oasis Infobyte Internship Task 5: </span>
            <span>Magazine or Brochure Layout Design</span>
          </div>
          <div className="flex items-center gap-4">
            <span>Designer: <strong className="text-white">Neha Vinod Borkar</strong></span>
            <span>·</span>
            <span>Submission: <strong className="text-[#48D9D0]">OIBSIP</strong></span>
          </div>
        </div>
      </main>

      {/* PRINT-ONLY DOM CONTAINER: Always contains all 6 consecutive pages with strict A4 styling */}
      <div className="print-only hidden">
        <div className="print-page-container">
          <div className="magazine-page-print w-[210mm] h-[297mm] overflow-hidden relative">
            <Page1Cover />
          </div>
          <div className="magazine-page-print w-[210mm] h-[297mm] overflow-hidden relative">
            <Page2EditorNote />
          </div>
          <div className="magazine-page-print w-[210mm] h-[297mm] overflow-hidden relative">
            <Page3AIFeature />
          </div>
          <div className="magazine-page-print w-[210mm] h-[297mm] overflow-hidden relative">
            <Page4VisualStory />
          </div>
          <div className="magazine-page-print w-[210mm] h-[297mm] overflow-hidden relative">
            <Page5BuildersPlaybook />
          </div>
          <div className="magazine-page-print w-[210mm] h-[297mm] overflow-hidden relative">
            <Page6ClosingPage />
          </div>
        </div>
      </div>

      {/* Deliverables Repository Hub Modal */}
      <DeliverablesModal
        isOpen={isDeliverablesOpen}
        onClose={() => setIsDeliverablesOpen(false)}
        initialTab={deliverablesInitialTab}
      />

      {/* Export & PDF Modal */}
      <PdfExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
      />
    </div>
  );
}
