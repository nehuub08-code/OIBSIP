export type ViewMode = 'single' | 'spread' | 'all';

export interface GuideToggles {
  showBleed: boolean;
  showTrim: boolean;
  showMargins: boolean;
  showGrid: boolean;
}

export interface PageMetadata {
  pageNumber: number;
  title: string;
  section: string;
  isFullBleed: boolean;
}

export const MAGAZINE_PAGES: PageMetadata[] = [
  { pageNumber: 1, title: 'The Future Is Built Today', section: 'Cover', isFullBleed: true },
  { pageNumber: 2, title: 'The Future Is Built, Not Predicted', section: 'From the Editor', isFullBleed: false },
  { pageNumber: 3, title: 'AI Beyond the Hype', section: 'Artificial Intelligence', isFullBleed: false },
  { pageNumber: 4, title: 'Start Small. Build Something Useful.', section: 'Ideas Into Action', isFullBleed: true },
  { pageNumber: 5, title: 'From Idea to First Project', section: "The Builder's Playbook", isFullBleed: false },
  { pageNumber: 6, title: 'Stay Curious. Keep Creating.', section: 'The Next Chapter', isFullBleed: false },
];
