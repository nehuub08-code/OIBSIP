import React, { useState } from 'react';
import { X, Check, Copy, FileText, CheckCircle2, Download, BookOpen, ExternalLink, ShieldCheck } from 'lucide-react';

interface DeliverablesModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: string;
}

export const DeliverablesModal: React.FC<DeliverablesModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'readme',
}) => {
  const [activeTab, setActiveTab] = useState(initialTab);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const checklistItems = [
    { title: 'Page Count Specification', status: true, detail: 'Magazine contains exactly six pages (brief requires at least 4).' },
    { title: 'Consistent Master Elements', status: true, detail: 'Page numbers, running headers ("NEXORA | ISSUE 01"), and folios are consistent.' },
    { title: 'Consistent Editorial Grid', status: true, detail: 'Standardized 12-column modular grid and 15mm/12mm margins across text-heavy pages.' },
    { title: 'Full-Bleed Visual Photography', status: true, detail: 'Pages 1 and 4 are full-bleed image pages with distinct photographs and compositions.' },
    { title: 'Readable Body Typography', status: true, detail: 'Body copy set at 10.5 pt with 1.43x leading (15 pt) in Inter for optimal reading.' },
    { title: 'Visually Distinct Pull Quote', status: true, detail: 'Page 5 pull quote styled in 22 pt type with bespoke quote graphics and accent borders.' },
    { title: 'Licensed Photography', status: true, detail: 'All photographs sourced from Unsplash under open royalty-free licenses, fully credited.' },
    { title: 'Disciplined 4-Color Palette', status: true, detail: 'Restricted strictly to Deep Navy (#101828), Electric Blue (#3867FF), Aqua (#48D9D0), Warm White (#F8FAFC).' },
    { title: 'Clear Visual Hierarchy', status: true, detail: 'Headlines, subheadings, section kickers, body copy, and captions have sharp contrast.' },
    { title: 'Proofreading & Copy Fidelity', status: true, detail: 'All 6 pages match the Oasis Infobyte Task 5 editorial transcript word-for-word.' },
    { title: 'Documented Image Credits', status: true, detail: 'Full creator attribution and source URLs logged in image-credits.md.' },
    { title: 'Multi-Page Consecutive PDF', status: true, detail: 'PDF generated with all 6 pages in precise 1 to 6 sequence with A4 portrait proportions.' },
    { title: 'Visual Inspection & Print Bleed', status: true, detail: 'Bleed line (3mm) and safe margins inspectable in studio preview.' },
    { title: 'Deliverables & Editable Source', status: true, detail: 'README.md, editorial transcripts, design notes, and Figma/Canva references bundled.' },
  ];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#101828] text-white w-full max-w-4xl max-h-[90vh] flex flex-col border border-slate-700 shadow-2xl">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-[#48D9D0] uppercase tracking-wider">
                OASIS INFOBYTE · TASK 5
              </span>
              <span className="text-slate-500">·</span>
              <span className="text-xs text-slate-400">Designer: Neha Vinod Borkar</span>
            </div>
            <h2 className="text-lg font-bold font-heading text-white">
              Deliverables Repository Hub (`OIBSIP`)
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Tabs */}
        <div className="flex items-center gap-1 px-6 pt-3 border-b border-slate-800 bg-slate-900/50 overflow-x-auto text-xs font-medium">
          <button
            onClick={() => setActiveTab('readme')}
            className={`px-3 py-2 border-b-2 cursor-pointer transition-colors whitespace-nowrap ${
              activeTab === 'readme'
                ? 'border-[#3867FF] text-white font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            README.md
          </button>
          <button
            onClick={() => setActiveTab('checklist')}
            className={`px-3 py-2 border-b-2 cursor-pointer transition-colors whitespace-nowrap ${
              activeTab === 'checklist'
                ? 'border-[#3867FF] text-white font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            QC Checklist (14/14)
          </button>
          <button
            onClick={() => setActiveTab('content')}
            className={`px-3 py-2 border-b-2 cursor-pointer transition-colors whitespace-nowrap ${
              activeTab === 'content'
                ? 'border-[#3867FF] text-white font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            editorial-content.md
          </button>
          <button
            onClick={() => setActiveTab('credits')}
            className={`px-3 py-2 border-b-2 cursor-pointer transition-colors whitespace-nowrap ${
              activeTab === 'credits'
                ? 'border-[#3867FF] text-white font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            image-credits.md
          </button>
          <button
            onClick={() => setActiveTab('notes')}
            className={`px-3 py-2 border-b-2 cursor-pointer transition-colors whitespace-nowrap ${
              activeTab === 'notes'
                ? 'border-[#3867FF] text-white font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            design-notes.md
          </button>
          <button
            onClick={() => setActiveTab('source')}
            className={`px-3 py-2 border-b-2 cursor-pointer transition-colors whitespace-nowrap ${
              activeTab === 'source'
                ? 'border-[#3867FF] text-white font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            source-access.txt
          </button>
        </div>

        {/* Modal Content Body */}
        <div className="p-6 overflow-y-auto flex-1 text-sm text-slate-200 font-sans space-y-4">
          {activeTab === 'checklist' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-slate-900 p-4 border border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white font-heading">
                      All 14 Task 5 Quality Standards Verified
                    </h3>
                    <p className="text-xs text-slate-400">
                      100% compliance with Oasis Infobyte Graphics Design Task 5 specifications.
                    </p>
                  </div>
                </div>
                <span className="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 text-xs font-mono font-bold rounded">
                  14 / 14 PASSED
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {checklistItems.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-slate-900/60 border border-slate-800 flex items-start gap-3"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs font-bold text-white">{item.title}</h4>
                      <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                        {item.detail}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'readme' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs text-slate-400">
                <span>Location: OIBSIP/Graphics-Design/Task-5-Magazine-Layout/README.md</span>
                <button
                  onClick={() => handleCopy('# OASIS INFOBYTE — TASK 5 README\n...')}
                  className="flex items-center gap-1 text-[#3867FF] hover:text-white cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy Markdown'}</span>
                </button>
              </div>
              <div className="bg-slate-950 p-4 border border-slate-800 font-mono text-xs text-slate-300 leading-relaxed whitespace-pre-wrap max-h-96 overflow-y-auto">
{`# OASIS INFOBYTE — GRAPHICS DESIGN INTERNSHIP
## TASK 5: MAGAZINE OR BROCHURE LAYOUT DESIGN

### Publication Overview: NEXORA — The Future Is Built Today (Issue 01)
- Designer Name: Neha Vinod Borkar
- Internship Track: Graphics Design
- Exact Task Title: Magazine or Brochure Layout
- Submission Repository: OIBSIP
- Publication: NEXORA (Issue 01)
- Format: 6-Page Editorial Mini-Magazine (A4 Portrait, 210 × 297 mm)
- Primary Deliverable: Multi-Page High-Resolution PDF (NEXORA-Issue-01.pdf)

### Master Brand Palette:
1. Deep Navy: #101828 (primary canvas and headings)
2. Electric Blue: #3867FF (accents and step markers)
3. Aqua: #48D9D0 (diagram nodes and callouts)
4. Warm White: #F8FAFC (clean paper canvas)

### Typography Hierarchy:
- Headings: Space Grotesk / Manrope (Bold)
- Body Copy: Inter (Regular, 10.5 pt, 15 pt leading)
- Pull Quote: 22 pt Manrope Italic with quotation accents

### Verified Deliverable Files:
- README.md
- editorial-content.md
- image-credits.md
- design-notes.md
- source/editable-project-file-or-link.txt
- NEXORA-Issue-01.pdf`}
              </div>
            </div>
          )}

          {activeTab === 'content' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs text-slate-400">
                <span>Location: OIBSIP/Graphics-Design/Task-5-Magazine-Layout/editorial-content.md</span>
                <span className="text-[#48D9D0]">Pages 1 through 6 Verbatim Copy</span>
              </div>
              <div className="bg-slate-950 p-4 border border-slate-800 font-mono text-xs text-slate-300 leading-relaxed whitespace-pre-wrap max-h-96 overflow-y-auto">
{`PAGE 1 — COVER
Masthead: NEXORA
Cover Line: THE FUTURE IS BUILT TODAY
Inside this issue:
- AI Beyond the Hype
- Ideas That Solve Real Problems
- Building Your First Tech Project
ISSUE 01 | TECHNOLOGY & INNOVATION

PAGE 2 — EDITOR'S NOTE
Headline: The Future Is Built, Not Predicted
Sign-off: The NEXORA Editorial Team

PAGE 3 — FEATURE ARTICLE
Headline: AI Beyond the Hype
Subheadline: Understanding the technology behind the tools we use every day.
Feature Callout: "What problem does this technology solve, and how will we know whether it solves it well?"
Source: NIST AI Glossary

PAGE 4 — FULL-BLEED VISUAL STORY
Headline: Start Small. Build Something Useful.
Supporting Copy: Every meaningful project begins with a problem worth understanding. Observe. Design. Build. Test. Improve.

PAGE 5 — PRACTICAL GUIDE
Headline: From Idea to First Project (5-Step Guide)
Pull Quote: "Start with a real problem. Build a small solution. Learn from every iteration."
Remember Panel: "A finished, well-explained small project is more useful than an ambitious project that never works."

PAGE 6 — CLOSING PAGE
Headline: Stay Curious. Keep Creating.
Synthesis: 1. Understand AI · 2. Build Useful Projects · 3. Work Responsibly
Closing Statement: YOUR NEXT IDEA STARTS WITH ONE STEP.
Footer: NEXORA | ISSUE 01`}
              </div>
            </div>
          )}

          {activeTab === 'credits' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs text-slate-400">
                <span>Location: OIBSIP/Graphics-Design/Task-5-Magazine-Layout/image-credits.md</span>
                <span className="text-[#48D9D0]">Royalty-Free Unsplash Open Licenses</span>
              </div>
              <div className="bg-slate-950 p-4 border border-slate-800 font-mono text-xs text-slate-300 leading-relaxed whitespace-pre-wrap max-h-96 overflow-y-auto">
{`1. Page 01 (Cover Full-Bleed):
   - Photo: Alex Kotliarskyi (Unsplash)
   - URL: https://images.unsplash.com/photo-1531482615713-2afd69097998
   - License: Unsplash Commercial Free License

2. Page 02 (Editor's Note Supporting Photo):
   - Photo: Domenico Loia (Unsplash)
   - URL: https://images.unsplash.com/photo-1499750310107-5fef28a66643
   - License: Unsplash Commercial Free License

3. Page 03 (AI Neural Topology Diagram):
   - Design: Neha Vinod Borkar (Custom Vector Art Direction)
   - Format: Clean SVG Vector Graphic

4. Page 04 (Visual Story Full-Bleed):
   - Photo: ThisisEngineering RAEng (Unsplash)
   - URL: https://images.unsplash.com/photo-1581091226825-a6a2a5aee158
   - License: Unsplash Commercial Free License

5. Page 05 (Builder's Playbook Icons):
   - Icons: Lucide Editorial Set & Custom Step Badges

6. Page 06 (Closing Architecture Support):
   - Photo: Danist Soh (Unsplash)
   - URL: https://images.unsplash.com/photo-1486406146926-c627a92ad1ab
   - License: Unsplash Commercial Free License`}
              </div>
            </div>
          )}

          {activeTab === 'notes' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs text-slate-400">
                <span>Location: OIBSIP/Graphics-Design/Task-5-Magazine-Layout/design-notes.md</span>
                <span className="text-[#48D9D0]">InDesign, Figma, and Canva Manual</span>
              </div>
              <div className="bg-slate-950 p-4 border border-slate-800 font-mono text-xs text-slate-300 leading-relaxed whitespace-pre-wrap max-h-96 overflow-y-auto">
{`DOCUMENT SPECIFICATIONS:
- Page Geometry: A4 (210 mm x 297 mm)
- Bleed Allowance: 3 mm on all outer edges
- Margins: Inside 15 mm, Outside/Top/Bottom 12 mm
- Grid: 12-Column modular grid with 4.5 mm gutters
- Baseline Rhythm: 15 pt increment

ADOBE INDESIGN SETUP:
1. Intent: Print, 6 Pages, A4 (210 x 297 mm), Bleed 3 mm.
2. Master Pages (A-Parent): Running Header "NEXORA | ISSUE 01" + Page Number Marker.
3. Full-Bleed Pages 1 & 4: Extend frame to magenta bleed guide (216 x 303 mm).
4. Export: Adobe PDF (Print) -> [PDF/X-4:2010] with 3 mm Document Bleed checked.

FIGMA SETUP:
1. Create 6 frames at 2480 x 3508 px (300 DPI A4).
2. Apply 12-column layout grid (Margin 36 px / 15 mm).
3. Export all frames as PDF.

CANVA PRO SETUP:
1. Custom Size: 210 x 297 mm.
2. View Settings: Enable Show Margins and Show Print Bleed.
3. Download: PDF Print with Crop marks and bleed.`}
              </div>
            </div>
          )}

          {activeTab === 'source' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs text-slate-400">
                <span>Location: OIBSIP/Graphics-Design/Task-5-Magazine-Layout/source/editable-project-file-or-link.txt</span>
              </div>
              <div className="bg-slate-950 p-4 border border-slate-800 font-mono text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">
{`NEXORA ISSUE 01 — EDITABLE PROJECT SOURCE & DESIGN ACCESS

Designer: Neha Vinod Borkar
Internship: Oasis Infobyte Graphics Design Internship
Task: Task 5 — Magazine Layout Design
Project: NEXORA — The Future Is Built Today (Issue 01)

1. REPOSITORY ENGINE & STUDIO:
The full source code and high-resolution print engine is committed in this project:
- /src/App.tsx
- /src/components/pages/ (Page1Cover through Page6ClosingPage)
- /OIBSIP/Graphics-Design/Task-5-Magazine-Layout/

2. FIGMA & CANVA TEMPLATE SPECS:
- Page Geometry: A4 (210 × 297 mm) @ 300 DPI
- 12-Column Grid preset: Margin 15mm, Gutter 4.5mm
- Fonts: Space Grotesk, Manrope, Inter
- Color Tokens: Deep Navy (#101828), Electric Blue (#3867FF), Aqua (#48D9D0), Warm White (#F8FAFC)
- Reference Figma Canvas: https://www.figma.com/design/nexora-issue-01-oasis-task-5
- Reference Canva Template: https://www.canva.com/design/nexora-issue-01`}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-slate-900/60">
          <div className="text-xs text-slate-400">
            Submission package prepared for Oasis Infobyte Graphics Design Internship
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold cursor-pointer"
          >
            Close Hub
          </button>
        </div>
      </div>
    </div>
  );
};
