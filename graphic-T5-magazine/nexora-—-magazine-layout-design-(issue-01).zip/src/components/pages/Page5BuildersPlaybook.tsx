import React from 'react';
import { Search, Target, Wrench, RefreshCw, FileText, Quote, BookmarkCheck } from 'lucide-react';

interface PageProps {
  showGuides?: boolean;
}

export const Page5BuildersPlaybook: React.FC<PageProps> = () => {
  const steps = [
    {
      num: '01',
      title: 'FIND A REAL PROBLEM',
      desc: 'Look for a small inconvenience in daily life, college, or a community.',
      icon: Search,
    },
    {
      num: '02',
      title: 'DEFINE THE GOAL',
      desc: 'Write down what the project should do and who it will help.',
      icon: Target,
    },
    {
      num: '03',
      title: 'BUILD THE SIMPLEST VERSION',
      desc: 'Start with the essential feature instead of trying to build everything at once.',
      icon: Wrench,
    },
    {
      num: '04',
      title: 'TEST AND IMPROVE',
      desc: 'Try different inputs, check errors, and ask users for feedback.',
      icon: RefreshCw,
    },
    {
      num: '05',
      title: 'DOCUMENT YOUR WORK',
      desc: 'Explain the problem, your solution, the tools used, the results, and the limitations.',
      icon: FileText,
    },
  ];

  return (
    <div className="relative w-full h-full bg-[#F8FAFC] text-[#101828] overflow-hidden flex flex-col justify-between p-8 sm:p-12 md:p-14 select-none">
      {/* RUNNING HEADER */}
      <div className="border-b border-slate-200 pb-3 flex items-center justify-between text-xs tracking-wider text-slate-500 font-heading">
        <div className="flex items-center gap-2">
          <span className="font-bold text-[#101828] tracking-widest uppercase">NEXORA</span>
          <span className="text-slate-300">/</span>
          <span className="text-[#3867FF] font-semibold tracking-widest uppercase">ISSUE 01</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="uppercase text-[11px] tracking-widest text-slate-400">Practical Guide</span>
          <span className="font-mono text-slate-700 font-semibold">05</span>
        </div>
      </div>

      {/* SECTION HEADER */}
      <div className="pt-4 pb-2">
        <div className="flex items-center gap-2 mb-2">
          <span className="h-[2px] w-5 bg-[#3867FF]" />
          <span className="text-xs font-bold tracking-[0.2em] uppercase text-[#3867FF] font-heading">
            THE BUILDER&apos;S PLAYBOOK
          </span>
        </div>
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold font-heading text-[#101828] tracking-tight leading-[1.1] mb-2 max-w-2xl">
          From Idea to First Project
        </h1>
        <p className="text-sm sm:text-base text-slate-600 font-normal max-w-2xl">
          A structured five-step workflow for beginners translating curiosity into functional software and hardware.
        </p>
      </div>

      {/* MANDATORY PULL QUOTE (Featured prominently with distinct typographic scale and accent lines) */}
      <div className="my-3 py-4 sm:py-5 px-6 bg-[#101828] text-white rounded-none relative overflow-hidden border-t-2 border-[#3867FF] shadow-xs">
        <div className="absolute top-2 right-4 text-[#3867FF]/20 select-none">
          <Quote className="w-16 h-16 sm:w-20 sm:h-20" />
        </div>
        <div className="relative z-10 max-w-2xl">
          <span className="text-[10px] font-mono tracking-widest uppercase text-[#48D9D0] block mb-2">
            MANDATORY PRINCIPLE · PULL QUOTE
          </span>
          <blockquote className="text-xl sm:text-2xl md:text-[26px] font-bold font-heading italic leading-snug text-white tracking-tight">
            “Start with a real problem. Build a small solution. Learn from every iteration.”
          </blockquote>
          <div className="mt-3 flex items-center gap-2 text-xs font-medium text-slate-300">
            <span className="w-4 h-[1.5px] bg-[#3867FF]" />
            <span>Foundational Law of Product Development</span>
          </div>
        </div>
      </div>

      {/* 5-STEP PLAYBOOK GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 my-2">
        {/* Left Column: Steps 01, 02, 03 */}
        <div className="space-y-3.5">
          {steps.slice(0, 3).map((step) => {
            const Icon = step.icon;
            return (
              <div key={step.num} className="flex items-start gap-3.5 group">
                <div className="shrink-0 w-9 h-9 bg-slate-100 border border-slate-300 flex items-center justify-center font-mono text-sm font-bold text-[#3867FF] group-hover:bg-[#3867FF] group-hover:text-white transition-colors">
                  {step.num}
                </div>
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <Icon className="w-3.5 h-3.5 text-[#3867FF]" />
                    <h3 className="text-xs font-bold font-heading text-[#101828] tracking-wider uppercase">
                      {step.title}
                    </h3>
                  </div>
                  <p className="text-[13px] text-slate-600 leading-snug">
                    {step.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Steps 04, 05 + "REMEMBER" Panel */}
        <div className="space-y-3.5 flex flex-col justify-between">
          <div className="space-y-3.5">
            {steps.slice(3, 5).map((step) => {
              const Icon = step.icon;
              return (
                <div key={step.num} className="flex items-start gap-3.5 group">
                  <div className="shrink-0 w-9 h-9 bg-slate-100 border border-slate-300 flex items-center justify-center font-mono text-sm font-bold text-[#3867FF] group-hover:bg-[#3867FF] group-hover:text-white transition-colors">
                    {step.num}
                  </div>
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <Icon className="w-3.5 h-3.5 text-[#3867FF]" />
                      <h3 className="text-xs font-bold font-heading text-[#101828] tracking-wider uppercase">
                        {step.title}
                      </h3>
                    </div>
                    <p className="text-[13px] text-slate-600 leading-snug">
                      {step.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* "REMEMBER" PANEL */}
          <div className="bg-[#F8FAFC] border border-slate-300 p-3.5 border-l-4 border-l-[#48D9D0]">
            <div className="flex items-center gap-2 text-xs font-bold font-heading text-[#101828] uppercase tracking-wider mb-1">
              <BookmarkCheck className="w-4 h-4 text-[#48D9D0]" />
              <span>Remember</span>
            </div>
            <p className="text-[12.5px] text-slate-700 italic leading-snug">
              “A finished, well-explained small project is more useful than an ambitious project that never works.”
            </p>
          </div>
        </div>
      </div>

      {/* RUNNING FOOTER */}
      <div className="border-t border-slate-200 pt-3 flex items-center justify-between text-[11px] text-slate-400">
        <span>NEXORA MAGAZINE · ISSUE 01 · 2026</span>
        <span>SECTION: THE BUILDER&apos;S PLAYBOOK</span>
        <span className="font-mono text-slate-600 font-bold">PAGE 05 OF 06</span>
      </div>
    </div>
  );
};
