import React, { useState } from 'react';

interface PageProps {
  showGuides?: boolean;
}

export const Page4VisualStory: React.FC<PageProps> = () => {
  const [imgError, setImgError] = useState(false);

  return (
    <div className="relative w-full h-full bg-[#101828] text-[#F8FAFC] overflow-hidden flex flex-col justify-between p-8 sm:p-12 md:p-14 select-none">
      {/* Full-bleed background image with authentic student prototyping & engineering collaboration */}
      {!imgError ? (
        <img
          src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1600&q=85"
          alt="Young student innovator prototyping physical tech project with hardware components"
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          className="absolute inset-0 w-full h-full object-cover object-center filter brightness-[0.70] contrast-[1.10] pointer-events-none"
        />
      ) : null}

      {/* Measured Dark Scrim: Deep navy gradient concentrated at top and bottom for typographic clarity */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#101828]/95 via-[#101828]/40 to-[#101828]/70 pointer-events-none" />

      {/* Geometric accent line */}
      <div className="absolute top-0 right-0 w-1/3 h-1 bg-[#48D9D0] pointer-events-none" />

      {/* TOP HEADER: Subtle Running Folio on Dark Canvas */}
      <div className="relative z-10 flex items-center justify-between border-b border-white/20 pb-3 text-xs tracking-wider font-heading">
        <div className="flex items-center gap-2">
          <span className="font-bold text-white tracking-widest uppercase">NEXORA</span>
          <span className="text-white/40">/</span>
          <span className="text-[#48D9D0] font-semibold tracking-widest uppercase">ISSUE 01</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="uppercase text-[11px] tracking-widest text-white/60">Visual Essay</span>
          <span className="font-mono text-white/90 font-semibold">04</span>
        </div>
      </div>

      {/* MIDDLE ZONE: Atmospheric Negative Space to let photography speak */}
      <div className="relative z-10 my-auto py-12" />

      {/* LOWER ZONE: Dominant Headline & Supporting Philosophy */}
      <div className="relative z-10 max-w-2xl bg-[#101828]/60 backdrop-blur-sm p-6 sm:p-8 border border-white/10">
        {/* Section Label */}
        <div className="flex items-center gap-2 mb-3">
          <span className="h-[2px] w-6 bg-[#48D9D0]" />
          <span className="text-xs font-bold tracking-[0.25em] uppercase text-[#48D9D0] font-heading">
            IDEAS INTO ACTION
          </span>
        </div>

        {/* Headline */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold font-heading text-white tracking-tight leading-[1.08] mb-4 text-balance drop-shadow-md">
          Start Small. Build Something Useful.
        </h1>

        {/* Supporting Copy */}
        <p className="text-base sm:text-lg text-slate-200 font-light leading-relaxed mb-6">
          Every meaningful project begins with a problem worth understanding.
        </p>

        {/* 5-Word Iterative Cadence */}
        <div className="pt-4 border-t border-white/20 flex flex-wrap items-center gap-2 sm:gap-4 text-xs sm:text-sm font-mono tracking-wider text-[#48D9D0]">
          <span className="font-bold text-white">Observe.</span>
          <span className="text-white/40">→</span>
          <span className="font-bold text-white">Design.</span>
          <span className="text-white/40">→</span>
          <span className="font-bold text-[#3867FF]">Build.</span>
          <span className="text-white/40">→</span>
          <span className="font-bold text-[#48D9D0]">Test.</span>
          <span className="text-white/40">→</span>
          <span className="font-bold text-white">Improve.</span>
        </div>
      </div>

      {/* BOTTOM RUNNING FOOTER */}
      <div className="relative z-10 border-t border-white/20 pt-3 flex items-center justify-between text-[11px] text-white/60">
        <span>NEXORA MAGAZINE · ISSUE 01 · 2026</span>
        <span className="hidden sm:inline">FULL-BLEED EDITORIAL PHOTO ESSAY</span>
        <span className="font-mono text-white/80 font-bold">PAGE 04 OF 06</span>
      </div>
    </div>
  );
};
