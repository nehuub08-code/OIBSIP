import React, { useState } from 'react';
import { ArrowUpRight, CheckCircle2, Compass, Layers, ShieldCheck } from 'lucide-react';

interface PageProps {
  showGuides?: boolean;
}

export const Page6ClosingPage: React.FC<PageProps> = () => {
  const [imgError, setImgError] = useState(false);

  return (
    <div className="relative w-full h-full bg-[#F8FAFC] text-[#101828] overflow-hidden flex flex-col justify-between p-8 sm:p-12 md:p-14 select-none">
      {/* RUNNING HEADER */}
      <div className="border-b border-slate-200 pb-3 flex items-center justify-between text-xs tracking-wider text-slate-500 font-heading">
        <div className="flex items-center gap-2">
          <span className="font-bold text-[#101828] tracking-widest uppercase">NEXORA</span>
          <span className="text-slate-300">/</span>
          <span className="text-[#3867FF] font-semibold tracking-widest uppercase">ISSUE 01</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="uppercase text-[11px] tracking-widest text-slate-400">Closing Manifesto</span>
          <span className="font-mono text-slate-700 font-semibold">06</span>
        </div>
      </div>

      {/* MAIN ESSAY CONTENT */}
      <div className="my-auto py-4">
        {/* Section Label */}
        <div className="flex items-center gap-2 mb-2">
          <span className="h-[2px] w-5 bg-[#3867FF]" />
          <span className="text-xs font-bold tracking-[0.2em] uppercase text-[#3867FF] font-heading">
            THE NEXT CHAPTER
          </span>
        </div>

        {/* Headline */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold font-heading text-[#101828] tracking-tight leading-[1.1] mb-6 max-w-2xl text-balance">
          Stay Curious. Keep Creating.
        </h1>

        {/* Split Grid: Prose (Left) + Recap & Visual (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Body Copy (7 cols) */}
          <div className="lg:col-span-7 space-y-4 text-[13.5px] sm:text-[14px] leading-[1.65] text-slate-700 font-normal">
            <p className="text-slate-900 font-medium text-base leading-relaxed">
              The future of technology will not be shaped by tools alone. It will also depend on the questions people ask, the problems they choose to solve, and the care they take when turning ideas into reality.
            </p>

            <p>
              You do not need to build something extraordinary on your first attempt. Begin with a clear goal, learn the fundamentals, create a small version, and improve it through feedback.
            </p>

            <p>
              Curiosity starts the journey. Consistent practice moves it forward.
            </p>

            {/* THREE THEMES COMPACT RECAP */}
            <div className="pt-4 border-t border-slate-200">
              <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase block mb-3">
                ISSUE 01 SYNTHESIS · THREE CORE THEMES
              </span>

              <div className="space-y-2.5">
                <div className="flex items-start gap-3 p-2.5 bg-white border border-slate-200">
                  <div className="w-6 h-6 rounded bg-[#3867FF]/10 text-[#3867FF] flex items-center justify-center shrink-0 mt-0.5">
                    <Layers className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold font-heading text-[#101828] uppercase tracking-wide">
                      1. Understand AI
                    </h4>
                    <p className="text-xs text-slate-600">
                      Learn how probabilistic models work, recognize limitations, and apply verification.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-2.5 bg-white border border-slate-200">
                  <div className="w-6 h-6 rounded bg-[#3867FF]/10 text-[#3867FF] flex items-center justify-center shrink-0 mt-0.5">
                    <Compass className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold font-heading text-[#101828] uppercase tracking-wide">
                      2. Build Useful Projects
                    </h4>
                    <p className="text-xs text-slate-600">
                      Anchor solutions in real human problems and ship the simplest working version first.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-2.5 bg-white border border-slate-200">
                  <div className="w-6 h-6 rounded bg-[#3867FF]/10 text-[#3867FF] flex items-center justify-center shrink-0 mt-0.5">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold font-heading text-[#101828] uppercase tracking-wide">
                      3. Work Responsibly
                    </h4>
                    <p className="text-xs text-slate-600">
                      Validate outputs, transparently document limitations, and design with ethical care.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Supporting Cropped Visual & Colophon Card (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            {/* Supporting Architectural Innovation Graphic */}
            <div className="relative border border-slate-200 bg-white overflow-hidden shadow-xs">
              {!imgError ? (
                <img
                  src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80"
                  alt="Modern architectural lines of glass technology and innovation center"
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="w-full h-44 sm:h-48 object-cover filter contrast-[1.08]"
                />
              ) : null}
              <div className="p-2.5 bg-white text-[10.5px] text-slate-500 italic border-t border-slate-200">
                Structures of the future are constructed beam by beam, prototype by prototype.
              </div>
            </div>

            {/* Editorial Colophon Box */}
            <div className="bg-[#101828] text-white p-4 text-xs space-y-2 border-b-2 border-[#3867FF]">
              <span className="text-[10px] font-mono tracking-widest text-[#48D9D0] uppercase block">
                PUBLICATION COLOPHON
              </span>
              <div className="text-[11px] text-slate-300 space-y-1 font-mono">
                <div><span className="text-white font-semibold">Title:</span> NEXORA Magazine</div>
                <div><span className="text-white font-semibold">Issue:</span> 01 (Inaugural Edition)</div>
                <div><span className="text-white font-semibold">Type:</span> A4 Portrait (210 × 297 mm)</div>
                <div><span className="text-white font-semibold">Designer:</span> Neha Vinod Borkar</div>
                <div><span className="text-white font-semibold">Track:</span> Oasis Infobyte Graphics Design</div>
              </div>
            </div>
          </div>
        </div>

        {/* STRONG TYPOGRAPHIC CLOSING STATEMENT (Full Width) */}
        <div className="mt-6 pt-5 border-t-2 border-[#101828] bg-slate-50 p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <span className="text-[10px] font-mono tracking-widest text-[#3867FF] uppercase font-bold block mb-1">
              CLOSING CONVICTION
            </span>
            <p className="text-lg sm:text-xl md:text-2xl font-extrabold font-heading text-[#101828] tracking-tight uppercase">
              YOUR NEXT IDEA STARTS WITH ONE STEP.
            </p>
          </div>
          <div className="shrink-0">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#101828] text-white text-xs font-mono font-medium">
              BUILD TODAY
              <ArrowUpRight className="w-3.5 h-3.5 text-[#48D9D0]" />
            </span>
          </div>
        </div>
      </div>

      {/* OPTIONAL FOOTER PER BRIEF */}
      <div className="border-t border-slate-200 pt-3 flex items-center justify-between text-[11px] text-slate-500 font-heading">
        <span className="font-bold text-[#101828] tracking-wider">NEXORA | ISSUE 01</span>
        <span className="text-slate-400">TECHNOLOGY & INNOVATION</span>
        <span className="font-mono text-slate-700 font-semibold">PAGE 06 OF 06</span>
      </div>
    </div>
  );
};
