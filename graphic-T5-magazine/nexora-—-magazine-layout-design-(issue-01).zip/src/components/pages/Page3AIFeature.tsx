import React from 'react';
import { Cpu, ExternalLink, HelpCircle, Network } from 'lucide-react';

interface PageProps {
  showGuides?: boolean;
}

export const Page3AIFeature: React.FC<PageProps> = () => {
  return (
    <div className="relative w-full h-full bg-[#F8FAFC] text-[#101828] overflow-hidden flex flex-col justify-between p-8 sm:p-12 md:p-14 select-none">
      {/* RUNNING HEADER */}
      <div className="border-b border-slate-200 pb-3 flex items-center justify-between text-xs tracking-wider text-slate-500 font-heading">
        <div className="flex items-center gap-2">
          <span className="font-bold text-[#101828] tracking-widest uppercase">NEXORA</span>
          <span className="text-slate-300">/</span>
          <span className="text-[#3867FF] font-semibold tracking-widest uppercase">ISSUE 01</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="uppercase text-[11px] tracking-widest text-slate-400">Feature Article</span>
          <span className="font-mono text-slate-700 font-semibold">03</span>
        </div>
      </div>

      {/* ARTICLE HEADER */}
      <div className="pt-4 pb-2">
        <div className="flex items-center gap-2 mb-2">
          <span className="h-[2px] w-5 bg-[#3867FF]" />
          <span className="text-xs font-bold tracking-[0.2em] uppercase text-[#3867FF] font-heading">
            ARTIFICIAL INTELLIGENCE
          </span>
        </div>
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold font-heading text-[#101828] tracking-tight leading-[1.1] mb-2 max-w-2xl text-balance">
          AI Beyond the Hype
        </h1>
        <p className="text-base sm:text-lg text-slate-600 font-medium font-heading max-w-2xl leading-snug">
          Understanding the technology behind the tools we use every day.
        </p>
      </div>

      {/* TECHNICAL INFOGRAPHIC: Neural Network / Deep Learning Architecture */}
      <div className="bg-white border border-slate-200 p-4 sm:p-5 my-2 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-100 pb-2 mb-3">
          <div className="flex items-center gap-2">
            <Network className="w-4 h-4 text-[#3867FF]" />
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#101828] font-heading">
              Technical Topology: Multi-Layer Neural Processing
            </span>
          </div>
          <span className="text-[10px] font-mono text-slate-400">Fig. 2.1 — Computational Flow</span>
        </div>

        {/* Custom SVG Neural Diagram */}
        <div className="w-full flex items-center justify-center py-2">
          <svg viewBox="0 0 640 120" className="w-full max-h-24 sm:max-h-28" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Connection Lines (Synapses) */}
            <g stroke="#E2E8F0" strokeWidth="1.2">
              {/* Input to Hidden 1 */}
              <line x1="80" y1="25" x2="240" y2="20" />
              <line x1="80" y1="25" x2="240" y2="60" />
              <line x1="80" y1="25" x2="240" y2="100" />
              <line x1="80" y1="60" x2="240" y2="20" stroke="#3867FF" strokeOpacity="0.4" />
              <line x1="80" y1="60" x2="240" y2="60" stroke="#3867FF" strokeOpacity="0.7" />
              <line x1="80" y1="60" x2="240" y2="100" />
              <line x1="80" y1="95" x2="240" y2="20" />
              <line x1="80" y1="95" x2="240" y2="60" />
              <line x1="80" y1="95" x2="240" y2="100" stroke="#48D9D0" strokeOpacity="0.6" />

              {/* Hidden 1 to Hidden 2 */}
              <line x1="240" y1="20" x2="400" y2="25" />
              <line x1="240" y1="20" x2="400" y2="60" stroke="#3867FF" strokeOpacity="0.5" />
              <line x1="240" y1="60" x2="400" y2="60" stroke="#48D9D0" strokeOpacity="0.8" />
              <line x1="240" y1="60" x2="400" y2="95" />
              <line x1="240" y1="100" x2="400" y2="60" />
              <line x1="240" y1="100" x2="400" y2="95" />

              {/* Hidden 2 to Output */}
              <line x1="400" y1="25" x2="560" y2="40" stroke="#3867FF" strokeOpacity="0.7" />
              <line x1="400" y1="60" x2="560" y2="40" stroke="#48D9D0" strokeOpacity="0.8" />
              <line x1="400" y1="60" x2="560" y2="80" stroke="#3867FF" strokeOpacity="0.6" />
              <line x1="400" y1="95" x2="560" y2="80" />
            </g>

            {/* Input Layer Nodes */}
            <circle cx="80" cy="25" r="9" fill="#101828" stroke="#3867FF" strokeWidth="2" />
            <circle cx="80" cy="60" r="9" fill="#3867FF" />
            <circle cx="80" cy="95" r="9" fill="#101828" stroke="#3867FF" strokeWidth="2" />

            {/* Hidden Dense Layer 1 */}
            <circle cx="240" cy="20" r="9" fill="#F8FAFC" stroke="#101828" strokeWidth="2" />
            <circle cx="240" cy="60" r="10" fill="#48D9D0" stroke="#101828" strokeWidth="2" />
            <circle cx="240" cy="100" r="9" fill="#F8FAFC" stroke="#101828" strokeWidth="2" />

            {/* Hidden Dense Layer 2 */}
            <circle cx="400" cy="25" r="9" fill="#F8FAFC" stroke="#3867FF" strokeWidth="2" />
            <circle cx="400" cy="60" r="10" fill="#3867FF" />
            <circle cx="400" cy="95" r="9" fill="#F8FAFC" stroke="#3867FF" strokeWidth="2" />

            {/* Output Prediction Nodes */}
            <circle cx="560" cy="40" r="11" fill="#101828" stroke="#48D9D0" strokeWidth="2.5" />
            <circle cx="560" cy="80" r="10" fill="#F8FAFC" stroke="#101828" strokeWidth="2" />

            {/* Labels */}
            <text x="80" y="117" textAnchor="middle" fill="#64748B" fontSize="9" fontWeight="600" fontFamily="Space Grotesk">INPUT DATA</text>
            <text x="240" y="117" textAnchor="middle" fill="#64748B" fontSize="9" fontWeight="600" fontFamily="Space Grotesk">PATTERN WEIGHTS</text>
            <text x="400" y="117" textAnchor="middle" fill="#64748B" fontSize="9" fontWeight="600" fontFamily="Space Grotesk">DEEP ABSTRACTION</text>
            <text x="560" y="117" textAnchor="middle" fill="#101828" fontSize="9" fontWeight="700" fontFamily="Space Grotesk">OUTPUT DECISION</text>
          </svg>
        </div>
      </div>

      {/* TWO-COLUMN EDITORIAL BODY GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-7 text-[13px] sm:text-[13.5px] leading-[1.65] text-slate-700 font-normal">
        {/* Column 1 */}
        <div className="space-y-3.5">
          <p className="text-slate-900 font-medium">
            Artificial intelligence is a broad field concerned with creating systems that perform tasks associated with capabilities such as prediction, language processing, pattern recognition, and decision support.
          </p>
          <p>
            Machine learning is one approach within AI. It uses data to learn patterns that can help a system make predictions or produce outputs. Deep learning uses multi-layer neural networks to learn more complex patterns, while generative AI can produce content such as text, images, audio, and code.
          </p>
          <p>
            These technologies have many potential applications. They can support learning, assist with repetitive tasks, help analyze information, and make creative experimentation more accessible.
          </p>

          {/* FEATURE CALLOUT QUESTION */}
          <div className="bg-[#101828] text-white p-4 border-l-4 border-[#48D9D0] my-2">
            <span className="text-[10px] font-mono tracking-widest text-[#48D9D0] uppercase block mb-1">
              CRITICAL INQUIRY
            </span>
            <p className="font-heading font-bold text-sm sm:text-base leading-snug text-white">
              <span className="text-[#3867FF]">A useful question to ask:</span> What problem does this technology solve, and how will we know whether it solves it well?
            </p>
          </div>
        </div>

        {/* Column 2 */}
        <div className="space-y-3.5">
          <p>
            However, AI outputs are not automatically correct. Systems can produce misleading answers, reflect bias in their data, or perform poorly in unfamiliar situations. Human judgment, verification, and responsible use remain important.
          </p>
          <p>
            For students beginning their AI journey, a practical approach is to understand the fundamentals, experiment with small projects, test results, and document limitations. Building a useful tool is not only about making it work; it is also about understanding when it works and when it does not.
          </p>

          {/* KEY TAKEAWAYS FACT BOX */}
          <div className="bg-slate-100 border border-slate-200 p-4 space-y-2">
            <div className="flex items-center gap-1.5 text-[11px] font-bold text-[#101828] font-heading uppercase tracking-wider">
              <Cpu className="w-3.5 h-3.5 text-[#3867FF]" />
              <span>Core Takeaway for Student Builders</span>
            </div>
            <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-4 marker:text-[#3867FF]">
              <li><strong className="text-slate-800">Probabilistic, not sentient:</strong> Models generate mathematical likenesses, not verified ground truth.</li>
              <li><strong className="text-slate-800">Verification first:</strong> Always cross-validate automated outputs before production release.</li>
              <li><strong className="text-slate-800">Scope narrow:</strong> High-utility tools address one acute workflow with clear success metrics.</li>
            </ul>
          </div>

          {/* SOURCE NOTE LINK (NIST AI Glossary) */}
          <div className="pt-2 text-[11px] text-slate-500 border-t border-slate-200">
            <span className="font-semibold text-slate-700">Source Reference:</span> National Institute of Standards and Technology (NIST) AI Glossary.
            <a
              href="https://csrc.nist.gov/glossary/term/artificial_intelligence"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-[#3867FF] hover:underline ml-1 font-mono text-[10px]"
            >
              csrc.nist.gov/glossary/term/artificial_intelligence
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
          </div>
        </div>
      </div>

      {/* RUNNING FOOTER */}
      <div className="border-t border-slate-200 pt-3 flex items-center justify-between text-[11px] text-slate-400">
        <span>NEXORA MAGAZINE · ISSUE 01 · 2026</span>
        <span>SECTION: ARTIFICIAL INTELLIGENCE</span>
        <span className="font-mono text-slate-600 font-bold">PAGE 03 OF 06</span>
      </div>
    </div>
  );
};
