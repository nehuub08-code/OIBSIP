import React, { useState } from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';

interface PageProps {
  showGuides?: boolean;
}

export const Page1Cover: React.FC<PageProps> = () => {
  const [imgError, setImgError] = useState(false);

  return (
    <div className="relative w-full h-full bg-[#101828] text-[#F8FAFC] overflow-hidden flex flex-col justify-between p-8 sm:p-12 md:p-14 select-none">
      {/* Full-bleed background image with subtle dark scrim for typography legibility */}
      {!imgError ? (
        <img
          src="https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1600&q=85"
          alt="Focused young technologist working in modern tech lab"
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          className="absolute inset-0 w-full h-full object-cover object-center filter brightness-[0.72] contrast-[1.08] pointer-events-none"
        />
      ) : null}

      {/* Editorial Gradient Scrims: Top for masthead, bottom for cover story */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#101828]/85 via-[#101828]/45 to-[#101828]/95 pointer-events-none" />
      
      {/* Subtle geometric grid line accents (Electric Blue & Aqua) */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#3867FF] via-[#48D9D0] to-transparent pointer-events-none" />
      <div className="absolute top-12 right-12 w-32 h-32 rounded-full bg-[#3867FF]/15 blur-3xl pointer-events-none" />

      {/* TOP ZONE: Issue Header & Masthead */}
      <div className="relative z-10">
        {/* Top Folio Bar */}
        <div className="flex items-center justify-between border-b border-white/20 pb-3 mb-6">
          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold tracking-[0.25em] text-[#48D9D0] uppercase">
              Technology & Innovation
            </span>
            <span className="text-white/40 text-xs">·</span>
            <span className="text-xs font-medium tracking-wider text-white/80 uppercase">
              First Edition
            </span>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono tracking-widest text-white/90">
            <span className="text-[#3867FF] font-bold">ISSUE 01</span>
            <span className="text-white/40">/</span>
            <span>2026</span>
          </div>
        </div>

        {/* Primary Magazine Masthead */}
        <div className="flex items-baseline justify-between">
          <h1 className="text-6xl sm:text-7xl md:text-8xl font-extrabold tracking-[-0.04em] font-heading leading-none text-white drop-shadow-md">
            NEXORA
          </h1>
          <div className="text-right hidden sm:block">
            <span className="block text-[10px] tracking-[0.3em] font-mono uppercase text-white/60">
              Editorial Monthly
            </span>
            <span className="block text-xs font-medium tracking-widest text-[#48D9D0]">
              ISSN 2940-182X
            </span>
          </div>
        </div>
      </div>

      {/* MIDDLE / LOWER ZONE: Feature Highlights & Main Headline */}
      <div className="relative z-10 mt-auto pt-12">
        {/* Main Issue Cover Headline */}
        <div className="mb-8">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-6 h-[2px] bg-[#3867FF]" />
            <span className="text-xs font-bold tracking-[0.2em] uppercase text-[#3867FF]">
              Cover Story
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold font-heading text-white tracking-tight leading-[1.08] max-w-xl text-balance drop-shadow-lg">
            THE FUTURE IS BUILT TODAY
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-200 font-light max-w-lg leading-relaxed">
            Moving beyond hype into practical innovation. A curated guide for college students, young creators, and beginner developers.
          </p>
        </div>

        {/* Inside This Issue Section Box */}
        <div className="bg-[#101828]/85 backdrop-blur-md border border-white/15 p-5 rounded-none max-w-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-2 mb-3">
            <span className="text-[11px] font-bold tracking-[0.2em] text-[#48D9D0] uppercase font-heading">
              Inside This Issue
            </span>
            <span className="text-[11px] font-mono text-white/50">pp. 02–06</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="group">
              <span className="block text-[10px] font-mono text-[#3867FF] font-semibold mb-0.5">03 / FOCUS</span>
              <p className="text-xs font-medium text-white/95 leading-snug group-hover:text-[#48D9D0] transition-colors">
                AI Beyond the Hype
              </p>
            </div>
            <div className="group">
              <span className="block text-[10px] font-mono text-[#3867FF] font-semibold mb-0.5">04 / VISION</span>
              <p className="text-xs font-medium text-white/95 leading-snug group-hover:text-[#48D9D0] transition-colors">
                Ideas That Solve Real Problems
              </p>
            </div>
            <div className="group">
              <span className="block text-[10px] font-mono text-[#3867FF] font-semibold mb-0.5">05 / GUIDE</span>
              <p className="text-xs font-medium text-white/95 leading-snug group-hover:text-[#48D9D0] transition-colors">
                Building Your First Tech Project
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar: Barcode, Trim & Editorial Credit */}
        <div className="mt-6 pt-3 border-t border-white/15 flex items-center justify-between text-[11px] text-white/70">
          <div className="flex items-center gap-3">
            <div className="w-16 h-4 bg-white/20 flex items-center justify-around px-1">
              {/* Micro Barcode Representation */}
              <div className="w-[1px] h-full bg-white/80" />
              <div className="w-[2px] h-full bg-white/80" />
              <div className="w-[1px] h-full bg-white/80" />
              <div className="w-[3px] h-full bg-white/80" />
              <div className="w-[1px] h-full bg-white/80" />
              <div className="w-[2px] h-full bg-white/80" />
            </div>
            <span className="font-mono text-[10px] text-white/60">01 98402 11094</span>
          </div>
          <span className="font-medium text-[#48D9D0] tracking-wider text-[11px]">
            OASIS INFOBYTE GRAPHICS DESIGN TASK 5
          </span>
          <span className="font-mono text-white/80">PAGE 01</span>
        </div>
      </div>
    </div>
  );
};
