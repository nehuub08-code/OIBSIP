import React, { useState } from 'react';
import { PenTool, Compass, BookOpen } from 'lucide-react';

interface PageProps {
  showGuides?: boolean;
}

export const Page2EditorNote: React.FC<PageProps> = () => {
  const [imgError, setImgError] = useState(false);

  return (
    <div className="relative w-full h-full bg-[#F8FAFC] text-[#101828] overflow-hidden flex flex-col justify-between p-8 sm:p-12 md:p-14 select-none">
      {/* RUNNING HEADER */}
      <div className="border-b border-slate-200 pb-3 flex items-center justify-between text-xs tracking-wider text-slate-500 font-heading">
        <div className="flex items-center gap-2">
          <span className="font-bold text-[#101828] tracking-widest uppercase">NEXORA</span>
          <span className="text-slate-300">/</span>
          <span className="text-[#3867FF] font-semibold tracking-widest uppercase">ISSUE 01</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="uppercase text-[11px] tracking-widest text-slate-400">Editorial Column</span>
          <span className="font-mono text-slate-700 font-semibold">02</span>
        </div>
      </div>

      {/* MAIN EDITORIAL CONTENT */}
      <div className="my-auto py-6">
        {/* Section Label & Kicker */}
        <div className="flex items-center gap-2 mb-2">
          <span className="h-[2px] w-5 bg-[#3867FF]" />
          <span className="text-xs font-bold tracking-[0.2em] uppercase text-[#3867FF] font-heading">
            FROM THE EDITOR
          </span>
        </div>

        {/* Headline */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold font-heading text-[#101828] tracking-tight leading-[1.12] mb-6 max-w-2xl text-balance">
          The Future Is Built, Not Predicted
        </h1>

        {/* 2-Column Asymmetric Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column (Prose, 7 cols) */}
          <div className="lg:col-span-7 space-y-4 text-[13.5px] sm:text-[14px] leading-[1.65] text-slate-700 font-normal">
            {/* Paragraph 1 with Drop Cap */}
            <p className="text-slate-800">
              <span className="float-left text-5xl font-extrabold font-heading text-[#101828] leading-[0.85] pr-3 pt-1">
                T
              </span>
              echnology is often described as a race toward the next big breakthrough. But meaningful progress begins with a simpler question: what problem are we trying to solve?
            </p>

            {/* Paragraph 2 */}
            <p>
              NEXORA explores the ideas, tools, and habits that help people turn curiosity into useful work. Artificial intelligence, software development, and digital creativity are changing how we approach challenges, but tools alone do not guarantee good results.
            </p>

            {/* Paragraph 3 */}
            <p className="font-medium text-slate-900 bg-slate-50 border-l-2 border-[#3867FF] pl-4 py-2 my-2">
              The most valuable skills remain the ability to ask thoughtful questions, understand problems, test ideas, learn from mistakes, and communicate clearly.
            </p>

            {/* Paragraph 4 */}
            <p>
              In this first issue, we explore how technology can support creativity, how small projects can become learning experiences, and why responsible thinking matters when building digital products.
            </p>

            {/* Paragraph 5 */}
            <p>
              Our goal is simple: encourage readers to stay curious, experiment thoughtfully, and create things that are genuinely useful.
            </p>

            <p className="font-semibold text-[#101828] text-base pt-1">
              Welcome to NEXORA.
            </p>

            {/* Sign-off */}
            <div className="pt-4 mt-2 border-t border-slate-200 flex items-center justify-between">
              <div>
                <span className="block text-[11px] uppercase tracking-wider text-slate-400 font-mono">
                  Editorial Direction
                </span>
                <span className="text-sm font-bold font-heading text-[#101828]">
                  The NEXORA Editorial Team
                </span>
              </div>
              <div className="text-right">
                <span className="inline-block px-2.5 py-1 bg-slate-100 text-[10px] font-mono text-slate-600 rounded">
                  VOL. 01 / ED. 01
                </span>
              </div>
            </div>
          </div>

          {/* Right Column (Visual Support & Editorial Insights, 5 cols) */}
          <div className="lg:col-span-5 space-y-5">
            {/* Supporting Photograph with Subtle Border */}
            <div className="relative border border-slate-200 bg-slate-100 overflow-hidden shadow-xs">
              {!imgError ? (
                <img
                  src="https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=800&q=80"
                  alt="Minimalist design desk with notebook and technology tools"
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="w-full h-48 sm:h-56 object-cover filter contrast-[1.05]"
                />
              ) : (
                <div className="w-full h-48 sm:h-56 bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center p-6 text-center">
                  <BookOpen className="w-8 h-8 text-[#3867FF]/60 mb-2" />
                  <p className="text-xs text-slate-500 font-medium">NEXORA Studio Workspace Proofs</p>
                </div>
              )}
              <div className="p-3 bg-white border-t border-slate-200 text-[11px] text-slate-500 italic">
                Fig. 1.0 — Thoughtful product discovery starts with quiet reflection, notebooks, and deliberate problem scoping.
              </div>
            </div>

            {/* Curatorial Principles Box */}
            <div className="bg-[#101828] text-white p-5 rounded-none border-t-2 border-[#48D9D0]">
              <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-[#48D9D0] font-heading block mb-2">
                Guiding Editorial Tenet
              </span>
              <p className="text-sm font-medium leading-snug text-slate-100 mb-3 font-heading">
                “Tools magnify intent. Good architecture and clear questions give technology purpose.”
              </p>
              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-white/10 text-[11px] text-slate-300">
                <div>
                  <span className="text-[#3867FF] font-bold block">Pragmatism</span>
                  <span>Solve tangible problems</span>
                </div>
                <div>
                  <span className="text-[#48D9D0] font-bold block">Iteration</span>
                  <span>Test, refine, document</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* RUNNING FOOTER */}
      <div className="border-t border-slate-200 pt-3 flex items-center justify-between text-[11px] text-slate-400">
        <span>NEXORA MAGAZINE · ISSUE 01 · 2026</span>
        <span>SECTION: EDITORIAL NOTE</span>
        <span className="font-mono text-slate-600 font-bold">PAGE 02 OF 06</span>
      </div>
    </div>
  );
};
