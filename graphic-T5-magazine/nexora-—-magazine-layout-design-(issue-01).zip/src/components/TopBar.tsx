import React from 'react';
import { Download } from 'lucide-react';
import { ViewMode } from '../types/magazine';

interface TopBarProps {
  viewMode: ViewMode;
  onSelectViewMode: (mode: ViewMode) => void;
  onOpenDeliverables: () => void;
  onOpenChecklist: () => void;
  onOpenExport: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  viewMode,
  onSelectViewMode,
  onOpenDeliverables,
  onOpenChecklist,
  onOpenExport,
}) => {
  return (
    <header className="no-print bg-[#101828] border-b border-slate-800 text-white sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xl font-bold font-heading tracking-tight text-white whitespace-nowrap">
            NEXORA
          </span>
          <span className="text-xs font-mono text-[#48D9D0] tracking-widest hidden sm:inline">
            ISSUE 01
          </span>
        </div>

        {/* Zone 2: 4–5 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-300">
          <button
            onClick={() => onSelectViewMode('single')}
            className={`whitespace-nowrap transition-colors cursor-pointer py-1 ${
              viewMode === 'single'
                ? 'text-white font-semibold border-b-2 border-[#3867FF]'
                : 'hover:text-white'
            }`}
          >
            Single Page
          </button>

          <button
            onClick={() => onSelectViewMode('spread')}
            className={`whitespace-nowrap transition-colors cursor-pointer py-1 ${
              viewMode === 'spread'
                ? 'text-white font-semibold border-b-2 border-[#3867FF]'
                : 'hover:text-white'
            }`}
          >
            Spreads
          </button>

          <button
            onClick={() => onSelectViewMode('all')}
            className={`whitespace-nowrap transition-colors cursor-pointer py-1 ${
              viewMode === 'all'
                ? 'text-white font-semibold border-b-2 border-[#3867FF]'
                : 'hover:text-white'
            }`}
          >
            All 6 Pages
          </button>

          <button
            onClick={onOpenDeliverables}
            className="whitespace-nowrap hover:text-white transition-colors cursor-pointer py-1 text-slate-300 hover:text-[#48D9D0]"
          >
            Deliverables Hub
          </button>

          <button
            onClick={onOpenChecklist}
            className="whitespace-nowrap hover:text-white transition-colors cursor-pointer py-1 text-slate-300 hover:text-[#48D9D0]"
          >
            QC Checklist
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenExport}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#3867FF] hover:bg-[#2e55db] transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export PDF (A4)</span>
          </button>
        </div>
      </div>
    </header>
  );
};
