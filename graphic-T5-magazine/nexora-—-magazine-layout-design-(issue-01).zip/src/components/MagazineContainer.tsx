import React from 'react';
import { GuideToggles } from '../types/magazine';

interface MagazineContainerProps {
  children: React.ReactNode;
  pageNumber: number;
  guides: GuideToggles;
  scale?: number;
  className?: string;
}

export const MagazineContainer: React.FC<MagazineContainerProps> = ({
  children,
  pageNumber,
  guides,
  scale = 1,
  className = '',
}) => {
  return (
    <div
      className={`relative mx-auto transition-all duration-200 ${className}`}
      style={{
        // A4 Ratio: 210mm x 297mm (1 : 1.41428)
        width: '100%',
        maxWidth: `${794 * scale}px`,
      }}
    >
      {/* Aspect Ratio Box (A4 Portrait) */}
      <div
        className="relative w-full shadow-2xl bg-white overflow-hidden magazine-page-print"
        style={{
          aspectRatio: '210 / 297',
        }}
      >
        {/* Render Actual Page Content */}
        {children}

        {/* PRINT PRODUCTION OVERLAYS (Toggleable for Graphic Design Review) */}
        {guides.showBleed && (
          <div className="absolute inset-0 pointer-events-none border-2 border-dashed border-pink-500/80 z-50">
            <div className="absolute top-1 left-1 bg-pink-600 text-white text-[9px] font-mono px-1 py-0.5 rounded-none uppercase">
              3mm Bleed Line
            </div>
          </div>
        )}

        {guides.showTrim && (
          <div className="absolute inset-[6px] pointer-events-none border border-black/80 z-50">
            <div className="absolute bottom-1 right-1 bg-black text-white text-[9px] font-mono px-1 py-0.5 rounded-none uppercase">
              210×297mm Trim Edge
            </div>
          </div>
        )}

        {guides.showMargins && (
          <div className="absolute inset-[36px] pointer-events-none border border-cyan-400/80 border-dashed z-50">
            <div className="absolute top-1 right-1 bg-cyan-600 text-white text-[9px] font-mono px-1 py-0.5 rounded-none uppercase">
              15mm Safe Margin
            </div>
          </div>
        )}

        {guides.showGrid && (
          <div className="absolute inset-0 pointer-events-none z-40 px-[36px] py-[36px] grid grid-cols-12 gap-[8px]">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="h-full bg-blue-500/10 border-x border-blue-500/20" />
            ))}
          </div>
        )}
      </div>

      {/* Screen Mode Page Caption below container */}
      <div className="no-print mt-2 flex items-center justify-between text-xs text-slate-400 px-1 font-mono">
        <span>A4 Portrait (210 × 297 mm)</span>
        <span className="font-semibold text-slate-300">Page {pageNumber} of 06</span>
      </div>
    </div>
  );
};
