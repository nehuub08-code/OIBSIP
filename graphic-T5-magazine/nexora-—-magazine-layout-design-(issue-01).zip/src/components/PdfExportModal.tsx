import React, { useState } from 'react';
import { X, Printer, Download, CheckCircle, FileCheck, Loader2 } from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

interface PdfExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PdfExportModal: React.FC<PdfExportModalProps> = ({ isOpen, onClose }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [progressText, setProgressText] = useState('');
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleNativePrint = () => {
    onClose();
    // Small timeout to allow modal animation to unmount
    setTimeout(() => {
      window.print();
    }, 250);
  };

  const handleDirectPdfDownload = async () => {
    setIsGenerating(true);
    setSuccess(false);

    try {
      // Find all 6 page elements with class 'magazine-page-print'
      const pageElements = document.querySelectorAll<HTMLElement>('.magazine-page-print');
      
      if (!pageElements || pageElements.length === 0) {
        throw new Error('No magazine pages found in DOM');
      }

      // Initialize jsPDF with A4 Portrait (210 x 297 mm)
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      // Capture all 6 pages consecutively
      for (let i = 0; i < pageElements.length; i++) {
        setProgressText(`Rendering Page ${i + 1} of ${pageElements.length}...`);

        const element = pageElements[i];

        const canvas = await html2canvas(element, {
          scale: 2, // 2x for high resolution
          useCORS: true,
          logging: false,
          allowTaint: true,
          backgroundColor: '#ffffff',
        });

        const imgData = canvas.toDataURL('image/jpeg', 0.95);

        if (i > 0) {
          pdf.addPage('a4', 'portrait');
        }

        pdf.addImage(imgData, 'JPEG', 0, 0, 210, 297);
      }

      setProgressText('Assembling multi-page PDF document...');
      pdf.save('NEXORA-Issue-01.pdf');

      setSuccess(true);
      setProgressText('Download completed: NEXORA-Issue-01.pdf');
    } catch (err) {
      console.error('PDF Generation Error:', err);
      alert('Error generating client-side PDF. Please use the recommended "Browser Vector Print" option.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#101828] text-white w-full max-w-xl border border-slate-700 shadow-2xl p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 text-slate-400 hover:text-white cursor-pointer"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs font-mono text-[#48D9D0] uppercase tracking-wider">
            PRINT PRODUCTION EXPORT
          </span>
          <span className="text-slate-500">·</span>
          <span className="text-xs text-slate-400">A4 Portrait (210 × 297 mm)</span>
        </div>

        <h2 className="text-2xl font-bold font-heading text-white mb-2">
          Export NEXORA Issue 01
        </h2>

        <p className="text-sm text-slate-300 mb-6 leading-relaxed">
          Produce the official 6-page multi-page editorial PDF deliverables for Oasis Infobyte Task 5 review and print grading.
        </p>

        {/* Options */}
        <div className="space-y-4">
          {/* OPTION 1: Vector Browser Print (Recommended for crisp vector text & zero distortion) */}
          <div className="bg-slate-900 border border-[#3867FF]/60 p-4 relative">
            <span className="absolute -top-2.5 right-4 px-2 py-0.5 bg-[#3867FF] text-white text-[10px] font-mono uppercase font-bold tracking-wider">
              Recommended (True 300 DPI Vector)
            </span>

            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded bg-[#3867FF]/20 text-[#3867FF] flex items-center justify-center shrink-0 mt-0.5">
                <Printer className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-bold text-white font-heading">
                  High-Resolution Vector PDF (via Print Pipeline)
                </h3>
                <p className="text-xs text-slate-300 mt-1 leading-snug">
                  Uses the browser print engine with strict CSS `@page &#123; size: A4 portrait; margin: 0 &#125;`. Preserves 100% crisp vector typography and layout fidelity.
                </p>

                {/* Print Settings Checklist */}
                <div className="mt-3 p-2.5 bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-400 space-y-1">
                  <div className="text-[#48D9D0] font-semibold">Print Dialog Recommended Settings:</div>
                  <div>• Destination: <strong>Save as PDF</strong></div>
                  <div>• Paper Size: <strong>A4</strong> (210 × 297 mm)</div>
                  <div>• Margins: <strong>None</strong></div>
                  <div>• Options: <strong>Background graphics [✓] Checked</strong></div>
                </div>

                <button
                  onClick={handleNativePrint}
                  className="mt-3 w-full py-2 bg-[#3867FF] hover:bg-[#2e55db] text-white text-xs font-bold font-heading uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  Launch Vector Print / PDF Dialog
                </button>
              </div>
            </div>
          </div>

          {/* OPTION 2: Direct Automated JS PDF File Download */}
          <div className="bg-slate-900 border border-slate-800 p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded bg-slate-800 text-[#48D9D0] flex items-center justify-center shrink-0 mt-0.5">
                <Download className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-bold text-white font-heading">
                  Direct Automated PDF File Download
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-snug">
                  Captures all 6 pages client-side into a single multi-page file named <span className="text-white font-mono">NEXORA-Issue-01.pdf</span>.
                </p>

                {progressText && (
                  <div className="mt-2 text-xs font-mono text-[#48D9D0] flex items-center gap-2">
                    {isGenerating && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                    {success && <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />}
                    <span>{progressText}</span>
                  </div>
                )}

                <button
                  onClick={handleDirectPdfDownload}
                  disabled={isGenerating}
                  className="mt-3 w-full py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer border border-slate-700"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Generating Multi-Page PDF...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      Download NEXORA-Issue-01.pdf Directly
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Prepared by Neha Vinod Borkar</span>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white cursor-pointer"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
