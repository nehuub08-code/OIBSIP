import React from 'react';
import { ChevronLeft, ChevronRight, Grid, Maximize2, Minimize2, ZoomIn, ZoomOut, Sliders } from 'lucide-react';
import { GuideToggles, MAGAZINE_PAGES, ViewMode } from '../types/magazine';

interface ReaderControlsProps {
  currentPage: number;
  onPageChange: (page: number) => void;
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  guides: GuideToggles;
  onToggleGuide: (guide: keyof GuideToggles) => void;
  scale: number;
  onScaleChange: (scale: number) => void;
}

export const ReaderControls: React.FC<ReaderControlsProps> = ({
  currentPage,
  onPageChange,
  viewMode,
  onViewModeChange,
  guides,
  onToggleGuide,
  scale,
  onScaleChange,
}) => {
  return (
    <div className="no-print bg-[#101828]/95 backdrop-blur-md border-b border-slate-800 text-slate-200 py-2.5 px-4 sticky top-16 z-40">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Left: Page Navigator (when in single or spread mode) */}
        <div className="flex items-center gap-2">
          {viewMode !== 'all' ? (
            <>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => onPageChange(Math.max(1, currentPage - 1))}
                  disabled={currentPage <= 1}
                  className="p-1.5 rounded hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-transparent cursor-pointer transition-colors"
                  title="Previous Page"
                  aria-label="Previous Page"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-1 font-mono px-2 py-1 bg-slate-900 border border-slate-800">
                  <span className="font-bold text-[#48D9D0]">Page {currentPage}</span>
                  <span className="text-slate-500">/ 06</span>
                </div>

                <button
                  onClick={() => onPageChange(Math.min(6, currentPage + 1))}
                  disabled={currentPage >= 6}
                  className="p-1.5 rounded hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-transparent cursor-pointer transition-colors"
                  title="Next Page"
                  aria-label="Next Page"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Quick Jump Page Buttons */}
              <div className="hidden lg:flex items-center gap-1 ml-2 border-l border-slate-800 pl-3">
                {MAGAZINE_PAGES.map((page) => (
                  <button
                    key={page.pageNumber}
                    onClick={() => onPageChange(page.pageNumber)}
                    className={`px-2 py-1 text-[11px] font-mono transition-colors cursor-pointer ${
                      currentPage === page.pageNumber
                        ? 'bg-[#3867FF] text-white font-bold'
                        : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    0{page.pageNumber}
                  </button>
                ))}
              </div>
            </>
          ) : (
            <div className="flex items-center gap-2 text-slate-300 font-mono">
              <span className="text-[#48D9D0] font-bold">Showing All 6 Pages</span>
              <span className="text-slate-500">· Consecutive Order</span>
            </div>
          )}
        </div>

        {/* Center: Current Section Indicator */}
        <div className="hidden xl:block text-slate-400 text-xs">
          <span className="text-slate-500">Current Section: </span>
          <span className="text-white font-medium">
            {MAGAZINE_PAGES[currentPage - 1]?.section} — &quot;{MAGAZINE_PAGES[currentPage - 1]?.title}&quot;
          </span>
        </div>

        {/* Right: Print Inspection Guides & Zoom */}
        <div className="flex items-center gap-3">
          {/* Print Inspection Guides Toggles */}
          <div className="flex items-center gap-1.5 bg-slate-900 p-1 border border-slate-800">
            <span className="text-[10px] uppercase font-mono text-slate-400 px-1 hidden sm:inline">
              Guides:
            </span>

            <button
              onClick={() => onToggleGuide('showBleed')}
              className={`px-2 py-0.5 text-[10px] font-mono transition-colors cursor-pointer ${
                guides.showBleed
                  ? 'bg-pink-600 text-white font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Toggle 3mm Bleed Boundary"
            >
              3mm Bleed
            </button>

            <button
              onClick={() => onToggleGuide('showTrim')}
              className={`px-2 py-0.5 text-[10px] font-mono transition-colors cursor-pointer ${
                guides.showTrim
                  ? 'bg-slate-200 text-slate-900 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Toggle Trim Line (210x297mm)"
            >
              Trim Edge
            </button>

            <button
              onClick={() => onToggleGuide('showMargins')}
              className={`px-2 py-0.5 text-[10px] font-mono transition-colors cursor-pointer ${
                guides.showMargins
                  ? 'bg-cyan-600 text-white font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Toggle 15mm Safe Margin"
            >
              Margins
            </button>

            <button
              onClick={() => onToggleGuide('showGrid')}
              className={`px-2 py-0.5 text-[10px] font-mono transition-colors cursor-pointer ${
                guides.showGrid
                  ? 'bg-blue-600 text-white font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Toggle 12-Column Editorial Grid"
            >
              12-Col Grid
            </button>
          </div>

          {/* Zoom controls */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 border border-slate-800">
            <button
              onClick={() => onScaleChange(Math.max(0.65, Number((scale - 0.1).toFixed(2))))}
              className="p-1 text-slate-400 hover:text-white cursor-pointer"
              title="Zoom Out"
              aria-label="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="font-mono text-[10px] px-1 text-slate-300 w-10 text-center">
              {Math.round(scale * 100)}%
            </span>
            <button
              onClick={() => onScaleChange(Math.min(1.4, Number((scale + 0.1).toFixed(2))))}
              className="p-1 text-slate-400 hover:text-white cursor-pointer"
              title="Zoom In"
              aria-label="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
