# OASIS INFOBYTE — GRAPHICS DESIGN INTERNSHIP
## TASK 5: MAGAZINE OR BROCHURE LAYOUT DESIGN

### Publication Overview: NEXORA — The Future Is Built Today (Issue 01)

- **Designer Name:** Neha Vinod Borkar
- **Internship Track:** Graphics Design
- **Exact Task Title:** Magazine or Brochure Layout
- **Submission Repository:** `OIBSIP`
- **Publication Title:** NEXORA
- **Issue Title:** The Future Is Built Today
- **Issue Number:** 01
- **Publication Type:** Fictional Technology & Innovation Magazine
- **Target Audience:** College students, young innovators, beginner developers, and technology enthusiasts
- **Format:** 6-Page Editorial Mini-Magazine (A4 Portrait, 210 × 297 mm)
- **Primary Delivery:** Multi-Page High-Resolution PDF (`NEXORA-Issue-01.pdf`)

---

## 1. Project Concept & Editorial Vision

NEXORA is a premier editorial publication designed to bridge the gap between complex emerging technologies and aspiring young builders. Unlike traditional high-tech publications that focus heavily on venture capital speculation or corporate press releases, NEXORA champions a human-centric, pragmatic philosophy: **"The Future Is Built, Not Predicted."**

The publication balances intellectual rigor with beginner accessibility, presenting artificial intelligence, product architecture, and engineering principles through structured editorial layouts, clear typography, and intentional visual pacing.

---

## 2. Document Setup & Print-Production Specifications

- **Page Geometry:** International Standard A4 Portrait (210 mm × 297 mm / 8.27 × 11.69 inches)
- **Page Count:** Exactly 6 pages
- **Bleed Allowance:** 3 mm (total document canvas: 216 mm × 303 mm)
- **Safe Zone / Inner Margin:** 15 mm inner margin, 12 mm outer/top/bottom margin
- **Column Grids:**
  - Cover & Visual Story: Asymmetric full-bleed focal canvas
  - Text Features (Pages 2, 3, 5, 6): 2-column and 3-column modular grids (12-column sub-grid) with 5 mm gutters
- **Body Text Size:** 10.5 pt with 15 pt leading (1.43× ratio)
- **Color Model:** Screen RGB for digital publication; CMYK conversion recipe mapped for offset printing
- **Resolution:** 300 DPI target for imagery and vector text rasterization

---

## 3. Brand Identity & Design System

### 4-Colour Master Brand Palette
Strictly adheres to the maximum 4-colour brand rule (excluding natural photography):

1. **Deep Navy (`#101828`):** Primary masthead, dominant headings, high-contrast dark sections, and running folios.
2. **Electric Blue (`#3867FF`):** Editorial highlights, step markers, pull quote accents, and visual hierarchy anchors.
3. **Aqua (`#48D9D0`):** Secondary technical callouts, neural diagram highlights, and subtle rule dividers.
4. **Warm White (`#F8FAFC`):** Crisp editorial paper canvas, negative space fields, and contrasting text on navy sections.

### Typography Hierarchy

- **Headings & Masthead:** Space Grotesk (Bold, 600–700 weight) & Manrope (SemiBold)
  - Masthead: 56 pt / 62 pt, uppercase, tracking +0.02em
  - Feature Headlines: 32–38 pt, leading 1.15×, optical kerning
  - Section Kickers: 9–10 pt uppercase, tracking +0.18em
- **Body Prose & Decks:** Inter (Regular 400 & Medium 500)
  - Subheadlines / Decks: 14–16 pt, leading 1.35×
  - Body Text: 10.5 pt, leading 15 pt (1.43×)
  - Pull Quote: 22 pt, italicized serif/grotesk styling with generous vertical breathing room
  - Captions & Citations: 8–8.5 pt, regular/italic

---

## 4. Six-Page Editorial Breakdown

| Page | Section Label | Title / Content | Layout Structure | Visual Asset |
|---|---|---|---|---|
| **01** | Cover | **NEXORA: The Future Is Built Today** | Full-Bleed Edge-to-Edge Hero | Architectural tech lab & student innovator |
| **02** | From the Editor | **The Future Is Built, Not Predicted** | 2-Column Asymmetric Editorial with Drop Cap | Clean studio workspace photography |
| **03** | Artificial Intelligence | **AI Beyond the Hype** | 2-Column Analytical Grid with Fact Box & NIST Citation | Neural network architecture vector diagram |
| **04** | Ideas Into Action | **Start Small. Build Something Useful.** | Full-Bleed Visual Story with Measured Contrast Scrim | Hands-on prototyping & hardware collaboration |
| **05** | The Builder's Playbook | **From Idea to First Project** (5-Step Guide) | Structured Modular Grid + Featured Pull Quote + Remember Box | Custom geometric step icons & callout framing |
| **06** | The Next Chapter | **Stay Curious. Keep Creating.** | Balanced Closing Editorial with 3-Pillar Synthesis | Minimalist architectural hardware illustration |

---

## 5. Mandatory Requirements Verification

- [x] **Full-Bleed Pages:** Pages 1 and 4 are completely full-bleed with distinct photography and distinct focal compositions.
- [x] **Pull Quote:** Page 5 features a dedicated, prominent pull quote (*“Start with a real problem. Build a small solution. Learn from every iteration.”*) styled in 22 pt type with bespoke quote graphics and accent borders.
- [x] **Consistent Master Elements:** All interior pages (Pages 2, 3, 5, 6) incorporate running headers (`NEXORA | ISSUE 01`), section markers, uniform margins, and synchronized page folios.
- [x] **Editorial Grid Discipline:** Strict alignment across multi-column grids, baseline rhythm, and zero orphan headlines.
- [x] **Brand Color Discipline:** Palette restricted strictly to Deep Navy, Electric Blue, Aqua, and Warm White.
- [x] **High-Resolution Multi-Page PDF:** Exportable via native print vector pipeline and canvas raster generator.

---

## 6. Software & Production Tools

- **Interactive Editorial Studio:** Built in React 19, TypeScript, Tailwind CSS, Vite.
- **Graphic Design Layout Tools Compatible:** Adobe InDesign CC, Figma, Canva Pro.
- **Export Formats:** Print-Ready PDF with 3mm Bleed, Digital Spread PDF, High-Resolution PNG Previews.

---

## 7. Submission Checklist Confirmation

- [x] All 6 pages designed and verified in consecutive order.
- [x] All editorial body copy sourced directly from the Oasis Infobyte Task 5 brief.
- [x] Image credits and licensing links fully documented in `image-credits.md`.
- [x] Step-by-step layout recreation guides documented in `design-notes.md`.
- [x] Complete repository structure created in `OIBSIP/Graphics-Design/Task-5-Magazine-Layout/`.

*Submission prepared by Neha Vinod Borkar for Oasis Infobyte Graphics Design Internship.*
