# NEXORA ISSUE 01 — EDITORIAL DESIGN SPECIFICATION & PRODUCTION MANUAL

**Designer:** Neha Vinod Borkar  
**Track:** Graphics Design | Oasis Infobyte Task 5  
**Document Format:** 6-Page Editorial Publication (A4 Portrait, 210 × 297 mm)  
**Deliverable:** Print-Ready & Digital Multi-Page PDF (`NEXORA-Issue-01.pdf`)

---

## 1. Editorial Philosophy & Art Direction

NEXORA's visual language is rooted in European editorial design principles:
- **Quiet Authority:** Ample negative space allows complex concepts to breathe.
- **Rhythmic Contrast:** Heavy geometric display typography paired with calm, highly readable neutral body text.
- **Intentional Pacing:** The 6-page sequence deliberately alternates between high-impact full-bleed visual pages (Pages 1 & 4) and disciplined, grid-governed analytical pages (Pages 2, 3, 5, 6).
- **Anti-Slop Discipline:** No generic purple AI gradients, no floating pill tags, no low-opacity background watermark text, and no arbitrary numbers pretending to be real metrics.

---

## 2. Mathematical Grid & Page Architecture

### Physical Dimensions
- **Trim Size:** 210 mm (Width) × 297 mm (Height) [A4 Portrait]
- **Bleed Allowance:** 3 mm on all 4 outer edges (Canvas with bleed: 216 mm × 303 mm)
- **Slug:** 0 mm (Top/Bottom/Left/Right)
- **Safe Inner Margin (Gutter):** 15 mm (ensures text remains uncompromised when bound)
- **Safe Outer / Top / Bottom Margin:** 12 mm

### 12-Column Subdivided Editorial Grid
Interior pages employ a standard 12-column layout grid:
- **Number of columns:** 12 (flexible across 1-col, 2-col, 3-col, or 4-col modules)
- **Column Gutter:** 4.5 mm (approx. 13 pt)
- **Baseline Grid:** 15 pt increment, starting at 15 mm from top margin
- **Page Numbers (Folios):** Anchored 8 mm from bottom trim, styled in 8 pt Space Grotesk Medium with tracking `+0.12em`

---

## 3. Typographic System & Type Scale

| Element | Font Family | Weight | Size (pt) | Leading (pt) | Tracking | Alignment / Notes |
|---|---|---|---|---|---|---|
| **Cover Masthead** | Space Grotesk | Bold 700 | 54 pt | 56 pt | +0.04em | Left / Top anchored |
| **Cover Headline** | Space Grotesk | Bold 700 | 28 pt | 32 pt | +0.01em | All caps, high contrast |
| **Cover Teasers** | Manrope | SemiBold 600 | 12 pt | 16 pt | Normal | Left aligned with blue bullet |
| **Section Kickers** | Space Grotesk | Bold 700 | 9 pt | 11 pt | +0.18em | Uppercase, Electric Blue `#3867FF` |
| **Primary Headlines** | Space Grotesk | Bold 700 | 28–34 pt | 34–40 pt | -0.01em | Title case, optical kerning |
| **Subheadlines / Decks** | Manrope | Medium 500 | 14 pt | 19 pt | Normal | Deep Navy `#101828` or muted slate |
| **Drop Cap (Page 2)** | Space Grotesk | Bold 700 | 48 pt | 44 pt | Normal | 3-line drop, Deep Navy |
| **Body Copy** | Inter | Regular 400 | 10.5 pt | 15 pt (1.43×) | Normal | 65–72 characters per line |
| **Pull Quote (Page 5)**| Manrope | Bold 700 | 22 pt | 28 pt | -0.01em | Italic, styled with quotes & accents |
| **Step Titles (Page 5)**| Space Grotesk | Bold 700 | 11 pt | 14 pt | +0.08em | Uppercase with accent numbers |
| **Running Folios** | Space Grotesk | Medium 500 | 8 pt | 10 pt | +0.12em | Synchronized across all interior pages |

---

## 4. Software Recreation Guide: Adobe InDesign, Figma, and Canva

### A. Adobe InDesign CC Setup
1. **New Document:**
   - Intent: Print
   - Number of Pages: 6 (Facing Pages: Off for digital review, or On for spread check)
   - Page Size: A4 (210 × 297 mm)
   - Margins: Top 12 mm, Bottom 12 mm, Inside 15 mm, Outside 12 mm
   - Bleed: 3 mm Top, Bottom, Inside, Outside
2. **Master Pages (A-Parent):**
   - Place Running Header text frame on top margin: `NEXORA | ISSUE 01` (8 pt Space Grotesk)
   - Place Current Page Number marker (`Type > Insert Special Character > Markers > Current Page Number`) at bottom margin
   - Draw a 0.5 pt hairline rule across the bottom margin in 15% black / Slate 300
3. **Placing Full-Bleed Imagery (Pages 1 & 4):**
   - Create a rectangular frame from the top-left bleed guide to the bottom-right bleed guide (216 × 303 mm)
   - Place image (`Cmd+D`), set to `Fitting > Fill Frame Proportionally`
   - Apply a gradient feather or rectangle with 60–80% black/navy fill for text contrast
4. **Export Settings:**
   - `File > Export > Adobe PDF (Print)`
   - Preset: `[High Quality Print]` or `[PDF/X-4:2010]`
   - Marks and Bleeds: Check `Use Document Bleed Settings` (3 mm)
   - Compatibility: Acrobat 7 (PDF 1.6) or later

### B. Figma Setup
1. **Frame Creation:**
   - Create 6 frames at standard 300 DPI A4 pixel dimensions: `2480 × 3508 px` (or 1x vector preview `595 × 842 pt`)
   - Add Layout Grid: Columns (12), Margin (36 px / 15 mm), Gutter (16 px)
2. **Typography Styles:**
   - Import Google Fonts `Space Grotesk`, `Manrope`, `Inter` via Figma font selector
   - Save text styles: `Display/Hero`, `H1/Feature`, `H2/Section`, `Body/Regular`, `Caption/Folio`
3. **Color Variables:**
   - Define color tokens: `Navy: #101828`, `Electric Blue: #3867FF`, `Aqua: #48D9D0`, `Warm White: #F8FAFC`
4. **Export:**
   - Select all 6 frames in sequence
   - `File > Export frames to PDF...`

### C. Canva Pro Setup
1. **Custom Size:**
   - Select `Custom Size` > Choose `mm` > Enter `210 × 297 mm`
   - Turn on `File > View settings > Show margins` and `Show print bleed`
2. **Layout Setup:**
   - Duplicate page to reach 6 total pages
   - For Pages 1 and 4, drag background photos until they snap past the trim line into the canvas edges
   - Use `Space Grotesk` or `Manrope` for all headlines, `Inter` for all body blocks
3. **Export:**
   - `Share > Download > PDF Print`
   - Check `Crop marks and bleed` (if sending to offset press) or uncheck for standard client delivery
   - Select `All 6 pages`

---

## 5. Quality Control Verification

- **Bleed Continuity:** Checked on Pages 1 and 4 (image data extends past page boundary).
- **Legibility Check:** All body copy verified at 10.5 pt with minimum contrast ratio of 8.2:1 against light backgrounds and 12.1:1 against dark backgrounds.
- **Folio Continuity:** Sequenced consecutively from 01 (Cover) through 06 (Closing).
- **Spelling & Copy Fidelity:** 100% compliant with Oasis Infobyte Task 5 brief.
