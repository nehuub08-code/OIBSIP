# NEXORA MAGAZINE — IMAGE & ASSET LICENSING CREDITS

**Publication:** NEXORA (Issue 01: The Future Is Built Today)  
**Designer:** Neha Vinod Borkar  
**Track:** Graphics Design | Oasis Infobyte Task 5  
**Licensing Compliance:** Royalty-free commercial and editorial use under Unsplash & Pexels Open License.

---

## 1. Page-by-Page Asset Inventory

### Page 01: Cover (Full-Bleed Image)
- **Asset Description:** High-contrast documentary editorial photo of a young student technologist focused at an illuminated modern computer workstation at night with ambient blue monitors.
- **Creator / Photographer:** Alex Kotliarskyi
- **Platform / Source:** Unsplash
- **Source URL:** `https://images.unsplash.com/photo-1531482615713-2afd69097998`
- **Resolution / Aspect:** 3000 × 4000 px (Portrait 3:4 / A4 Cover)
- **License:** Unsplash Free Commercial License (Royalty-free)
- **Usage:** Full-bleed cover background with custom dark navy gradient overlay (`rgba(16, 24, 40, 0.75)`).

### Page 02: From The Editor (Supporting Editorial Photo)
- **Asset Description:** Minimalist design desk layout with notebooks, fountain pen, and laptop open to typography proofs with soft natural daylight.
- **Creator / Photographer:** Domenico Loia
- **Platform / Source:** Unsplash
- **Source URL:** `https://images.unsplash.com/photo-1499750310107-5fef28a66643`
- **Resolution / Aspect:** 2400 × 1600 px (Landscape 3:2)
- **License:** Unsplash Free Commercial License (Royalty-free)
- **Usage:** Column 2 supporting editorial photo with subtle 1px border.

### Page 03: Feature Article — AI Beyond the Hype (Technical Diagram)
- **Asset Description:** Vector neural network deep learning node topology diagram illustrating input vectors, hidden dense layers, and probabilistic output nodes.
- **Creator / Designer:** Neha Vinod Borkar (Custom Vector Art Direction for NEXORA)
- **Format:** SVG / Vector Graphic rendered in Deep Navy, Electric Blue (#3867FF), and Aqua (#48D9D0)
- **License:** Original work created for NEXORA Issue 01
- **Usage:** Technical explanatory visual in Feature Article.

### Page 04: Visual Story — Ideas Into Action (Full-Bleed Image)
- **Asset Description:** Authentic creative workspace featuring young creators collaborating over physical prototypes, wireframes, electronic breadboards, and code.
- **Creator / Photographer:** ThisisEngineering RAEng
- **Platform / Source:** Unsplash
- **Source URL:** `https://images.unsplash.com/photo-1581091226825-a6a2a5aee158`
- **Resolution / Aspect:** 3200 × 4000 px (Portrait 3:4 / A4 Spread)
- **License:** Unsplash Free Commercial License (Royalty-free)
- **Usage:** Full-bleed background with measured lower-third dark contrast scrim for headline typography legibility.

### Page 05: The Builder's Playbook (Iconography & Diagrams)
- **Asset Description:** Minimalist geometric step badges, target icons, iterate loops, and documentation glyphs.
- **Creator / Designer:** Neha Vinod Borkar & Lucide Design System
- **Format:** High-precision SVG iconography styled in Electric Blue and Aqua.
- **License:** MIT / Editorial Open Source

### Page 06: The Next Chapter (Architectural Abstract Graphic)
- **Asset Description:** Clean architectural perspective of modern innovation center glass atrium and structured geometric patterns.
- **Creator / Photographer:** Danist Soh
- **Platform / Source:** Unsplash
- **Source URL:** `https://images.unsplash.com/photo-1486406146926-c627a92ad1ab`
- **Resolution / Aspect:** 2400 × 3000 px (Portrait 4:5)
- **License:** Unsplash Free Commercial License (Royalty-free)
- **Usage:** Half-column structural photograph anchoring the issue's concluding reflection.

---

## 2. Licensing Compliance Statement

All photographs and graphic assets selected for NEXORA Issue 01 comply with royalty-free licensing terms. No copyrighted or restricted editorial wire photography has been used without authorization. High-resolution vector fallbacks are baked into the layout codebase ensuring no broken frames occur in any display environment.
