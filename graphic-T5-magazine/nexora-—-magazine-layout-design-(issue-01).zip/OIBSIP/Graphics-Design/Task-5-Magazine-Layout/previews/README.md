# NEXORA ISSUE 01 — PAGE PREVIEWS DIRECTORY

This directory houses the high-resolution page previews for OASIS INFOBYTE Task 5:
- page-1-cover.png (Full-Bleed Cover)
- page-2-editors-note.png (From The Editor)
- page-3-ai-feature.png (AI Beyond the Hype)
- page-4-visual-story.png (Ideas Into Action Full-Bleed)
- page-5-builders-guide.png (The Builder's Playbook)
- page-6-closing-page.png (The Next Chapter Closing Page)

All 6 pages can be rendered in real-time or exported at 300 DPI via the NEXORA Editorial Studio interactive viewer at port 3000.
