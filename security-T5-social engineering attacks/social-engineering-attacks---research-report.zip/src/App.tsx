/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  ShieldAlert,
  FileText,
  BookOpen,
  Search,
  CheckCircle2,
  Copy,
  Download,
  ExternalLink,
  ChevronRight,
  AlertTriangle,
  Lock,
  UserCheck,
  Building2,
  Sparkles,
  GitBranch,
  Terminal,
  Layers,
  ArrowRight,
  PhoneCall,
  Mail,
  Smartphone,
  HardDrive,
  HelpCircle,
  FolderTree,
  Eye,
  Check
} from 'lucide-react';

interface ReferenceItem {
  id: number;
  author: string;
  title: string;
  year: string;
  source: string;
  url: string;
  note: string;
}

const REFERENCES: ReferenceItem[] = [
  {
    id: 1,
    author: 'CISA (Cybersecurity & Infrastructure Security Agency)',
    title: 'Avoiding Social Engineering and Phishing Attacks (Security Tip ST04-014)',
    year: '2021',
    source: 'U.S. Department of Homeland Security',
    url: 'https://www.cisa.gov/news-events/news/avoiding-social-engineering-and-phishing-attacks',
    note: 'Baseline definitions, psychological triggers (urgency, authority, fear), red flags, and identity verification guidance.'
  },
  {
    id: 2,
    author: 'CISA, NSA, FBI, & MS-ISAC',
    title: 'Phishing Guidance: Stopping the Attack Cycle at Phase One',
    year: '2023',
    source: 'Joint Cybersecurity Advisory',
    url: 'https://www.cisa.gov/resources-tools/resources/phishing-guidance-stopping-attack-cycle-phase-one',
    note: 'Domain validation (SPF, DKIM, DMARC), FIDO2 phishing-resistant MFA, email filtering, and incident containment.'
  },
  {
    id: 3,
    author: 'David Gragg',
    title: 'A Multi-Level Defense Against Social Engineering',
    year: '2002',
    source: 'SANS Institute Information Security Reading Room',
    url: 'https://www.sans.org/white-papers/520/',
    note: 'Core psychological dynamics (social compliance, conformity, reciprocity) and multi-tier defensive operational policies.'
  },
  {
    id: 4,
    author: 'Uri Rivner (RSA) / Dark Reading',
    title: 'Anatomy of an Attack: How RSA Was Compromised',
    year: '2011',
    source: 'Dark Reading Threat Analysis',
    url: 'https://www.darkreading.com/attacks-breaches/anatomy-of-an-attack-how-rsa-was-compromised',
    note: 'Spear-phishing Excel attachment (2011 Recruitment plan.xls), Adobe Flash CVE-2011-0609 zero-day, Poison Ivy RAT, SecurID seed exfiltration.'
  },
  {
    id: 5,
    author: 'Linda A. Lacewell (Superintendent of Financial Services)',
    title: 'Report on Investigation of Twitter’s July 15, 2020, Cybersecurity Incident',
    year: '2020',
    source: 'New York State Department of Financial Services (NY DFS)',
    url: 'https://www.dfs.ny.gov/Twitter_Report',
    note: 'Phone pretexting/vishing posing as IT help desk for remote VPN support, fake VPN login portal, real-time MFA theft, abuse of internal Customer Support Admin tool.'
  },
  {
    id: 6,
    author: 'M. Tischer, Z. Durumeric, S. Foster, S. Duan, A. Mori, E. Bursztein, & M. Bailey',
    title: 'Users Really Do Plug in USB Drives They Find',
    year: '2016',
    source: 'Proceedings of the 2016 IEEE Symposium on Security and Privacy (S&P), pp. 306-319',
    url: 'https://www.elie.net/publication/users-really-do-plug-in-usb-drives-they-find/',
    note: 'Empirical university study: 297 dropped USBs; 45%–98% plugged in; first plugged in under 6 minutes; altruism stated (68%) yet curiosity drove opening photos first.'
  },
  {
    id: 7,
    author: 'The MITRE Corporation',
    title: 'Technique T1566: Phishing & T1598: Phishing for Information',
    year: '2024',
    source: 'MITRE ATT&CK Enterprise Matrix',
    url: 'https://attack.mitre.org/techniques/T1566/',
    note: 'Tactical categorization of spear-phishing attachments, links, services, and adversary credential theft techniques.'
  },
  {
    id: 8,
    author: 'Verizon Business Security Research',
    title: '2024 Data Breach Investigations Report (DBIR)',
    year: '2024',
    source: 'Verizon Business',
    url: 'https://www.verizon.com/business/resources/reports/dbir/',
    note: 'Empirical finding: human element involved in 68% of analyzed global breaches (phishing, pretexting, misconfiguration, and inadvertent error).'
  }
];

const COMPARISON_ROWS = [
  {
    type: 'Phishing',
    target: 'Broad employee populations & consumers',
    lever: 'Urgency, fear, anxiety, routine habit',
    countermeasure: 'Automated email gateway filtering (SPF/DKIM/DMARC) & simulation training [1], [2]',
    category: 'Phishing'
  },
  {
    type: 'Spear Phishing',
    target: 'Specific individual, project team, or department',
    lever: 'Familiarity, professional duty, contextual trust',
    countermeasure: 'Domain verification, email link sandboxing, & out-of-band communication checks [1], [7]',
    category: 'Phishing'
  },
  {
    type: 'Whaling',
    target: 'High-level executives (CEOs, CFOs, Board members)',
    lever: 'Legal intimidation, urgency, authority, high stakes',
    countermeasure: 'Executive dual-authorization for financial transfers & bespoke whaling drills [1]',
    category: 'Phishing'
  },
  {
    type: 'Vishing',
    target: 'Staff with phone access (remote workers, call centers)',
    lever: 'Perceived technical authority, urgency, helpfulness',
    countermeasure: 'Out-of-band directory callbacks & formal caller challenge-response questions [1], [5]',
    category: 'Phishing'
  },
  {
    type: 'Smishing',
    target: 'Mobile device users & mobile workforce',
    lever: 'Convenience, impulsive curiosity, delivery deadlines',
    countermeasure: 'Never clicking SMS links, mobile threat defense, & checking official carrier apps [1]',
    category: 'Phishing'
  },
  {
    type: 'Pretexting',
    target: 'Employees holding sensitive data or system access',
    lever: 'Fabricated authority, professional empathy, social compliance',
    countermeasure: 'Multi-tier identity verification policies, least privilege, & 4-eyes authorization [3], [5]',
    category: 'Pretexting'
  },
  {
    type: 'Physical Baiting',
    target: 'On-site corporate personnel & office visitors',
    lever: 'Curiosity, greed, desire for free goods, altruism',
    countermeasure: 'Strict ban on unknown media, disabling USB mass storage via EDR, & port locks [6]',
    category: 'Baiting'
  },
  {
    type: 'Digital Baiting',
    target: 'Internet users seeking free software, media, or tools',
    lever: 'Greed, desire for free resources, convenience',
    countermeasure: 'Application allowlisting, web filtering, & downloading solely from verified repos [1], [6]',
    category: 'Baiting'
  },
  {
    type: 'Quid Pro Quo',
    target: 'Frustrated or busy employees needing tech assistance',
    lever: 'Reciprocity, relief, gratitude for assistance',
    countermeasure: 'Mandatory IT ticketing workflows, refusal to disclose passwords/OTPs to support [3]',
    category: 'Quid Pro Quo'
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'report' | 'markdown' | 'cases' | 'checklist' | 'github'>('report');
  const [activeSection, setActiveSection] = useState<string>('intro');
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);
  const [selectedCitation, setSelectedCitation] = useState<ReferenceItem | null>(null);
  const [checklistProgress, setChecklistProgress] = useState<Record<number, boolean>>({
    1: true,
    2: true,
    3: true,
    4: true,
    5: true
  });

  const fullMarkdownText = useMemo(() => {
    return `# Social Engineering Attacks: Types, Real-World Cases, and Prevention

Track: OIBSIP Security Analyst
Task: Task 5 — Research Report: Social Engineering Attacks
Prepared by: [Your Name]
Date: October 29, 2026

## 1. Title and Report Information
- Document Title: Social Engineering Attacks: Types, Real-World Cases, and Prevention
- Academic / Internship Track: Oasis Infobyte Security Analyst Internship (OIBSIP) — Task 5
- Research Subject: Human-centric cyber attack vectors, exploitation mechanics, historical incident case studies, and defense-in-depth countermeasures.
- Classification: Public / Technical Portfolio Report

## 2. Introduction
Social engineering in cybersecurity refers to the psychological manipulation of human individuals into voluntarily performing actions or divulging confidential information that compromises personal or organizational security [1]. Unlike purely technical attacks that exploit software bugs, social engineering targets cognitive heuristics: Trust, Urgency, Fear, Authority, Curiosity, and Routine Behavior [3]. According to the Verizon 2024 Data Breach Investigations Report (DBIR), the human element was involved in 68% of all analyzed breaches globally [8]. Technical controls alone are insufficient because legitimate credentials handed over willingly bypass traditional firewalls.

## 3. Phishing Attacks
3.1 Definition & Lifecycle: Target Selection -> Deceptive Delivery -> Psychological Trigger -> Victim Action -> Post-Compromise Misuse [1], [7].
3.2 Types: Spear Phishing, Whaling, Vishing, Smishing with educational scenarios and red flags.
3.3 Attacker vs Victim perspective: Reverse proxies (Evilginx), homoglyph domains, weaponized attachments.
3.4 Case Study: 2011 RSA SecurID Attack (Excel '2011 Recruitment plan.xls' retrieved from Junk folder, Adobe Flash CVE-2011-0609 zero-day, Poison Ivy RAT, SecurID token seed exfiltration) [4].
3.5 Four Prevention Recommendations: Adaptive training, Phishing-resistant FIDO2 MFA, Email protocols (SPF/DKIM/DMARC), and rapid session revocation [1], [2].

## 4. Pretexting Attacks
4.1 Definition: Fabricating a plausible identity and scenario to manipulate victims [3].
4.2 Case Study: July 15, 2020 Twitter Incident (NY DFS investigation: phone pretexting/vishing posing as IT Help Desk for remote VPN, fake VPN login portal, real-time MFA capture, Customer Support Admin tool abuse, 130 accounts hijacked for Bitcoin scam) [5].
4.3 Prevention: Out-of-band verification callback script, strict help desk policies, and least-privilege dual authorization [5].

## 5. Baiting Attacks
5.1 Definition & Forms: Physical Baiting (infected USBs) & Digital Baiting (cracked software) [1], [6].
5.2 Case Study: 2016 IEEE S&P Study by Tischer et al. (297 dropped USBs, 45%-98% connected, 68% altruism stated yet vacation photos opened first) [6].
5.3 Prevention: Ban on unknown removable media, EDR mass-storage blocking, and safe physical reporting procedures.

## 6. Bonus Topic: Quid Pro Quo
Offers an active reciprocal service (e.g., fake IT support offering to fix network latency in exchange for credentials) vs passive lure baiting [3].

## 7. Comparison Table
Detailed 9-vector matrix contrasting targets, psychological levers, and top countermeasures.

## 8. Five-Point Employee Checklist
Recognize, Verify, Protect, Report, and Practice & Improve.

## 9. Organizational Recommendations
Least privilege, Phishing-resistant MFA, email authentication, and blame-free reporting.

## 10. Conclusion: Three Key Takeaways
1. Exploits human nature, not just software flaws.
2. Layered defense (FIDO2 + verification + least privilege) beats single solutions.
3. Speed of reporting determines impact.

## 11. References
8 authoritative, verified citations across CISA, SANS, Dark Reading, NY DFS, IEEE S&P, MITRE ATT&CK, and Verizon DBIR.`;
  }, []);

  const handleCopyMarkdown = () => {
    navigator.clipboard.writeText(fullMarkdownText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadMarkdown = () => {
    const blob = new Blob([fullMarkdownText], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'social_engineering_report.md');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredComparison = useMemo(() => {
    if (!searchQuery) return COMPARISON_ROWS;
    const q = searchQuery.toLowerCase();
    return COMPARISON_ROWS.filter(
      r =>
        r.type.toLowerCase().includes(q) ||
        r.target.toLowerCase().includes(q) ||
        r.lever.toLowerCase().includes(q) ||
        r.countermeasure.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Banner / Header */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-40 px-4 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/10 border border-cyan-500/30 rounded-lg text-cyan-400">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                OIBSIP Security Analyst
              </span>
              <span className="text-xs text-slate-400 font-mono">Task 5: Research Report</span>
            </div>
            <h1 className="text-base lg:text-lg font-bold text-white tracking-tight">
              Social Engineering Attacks: Types, Real-World Cases, and Prevention
            </h1>
          </div>
        </div>

        {/* Tab Switcher & Quick Actions */}
        <div className="flex items-center gap-2">
          <nav className="flex p-1 bg-slate-950/80 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('report')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1.5 ${
                activeTab === 'report' ? 'bg-cyan-500 text-slate-950 font-semibold shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              Report
            </button>
            <button
              onClick={() => setActiveTab('cases')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1.5 ${
                activeTab === 'cases' ? 'bg-cyan-500 text-slate-950 font-semibold shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              Case Studies
            </button>
            <button
              onClick={() => setActiveTab('checklist')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1.5 ${
                activeTab === 'checklist' ? 'bg-cyan-500 text-slate-950 font-semibold shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              Checklist & Matrix
            </button>
            <button
              onClick={() => setActiveTab('markdown')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1.5 ${
                activeTab === 'markdown' ? 'bg-cyan-500 text-slate-950 font-semibold shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              Raw .MD
            </button>
            <button
              onClick={() => setActiveTab('github')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1.5 ${
                activeTab === 'github' ? 'bg-cyan-500 text-slate-950 font-semibold shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              <GitBranch className="w-3.5 h-3.5" />
              GitHub Submission
            </button>
          </nav>

          <button
            onClick={handleCopyMarkdown}
            title="Copy Report Markdown"
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition flex items-center gap-1 text-xs"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span className="hidden sm:inline">{copied ? 'Copied' : 'Copy'}</span>
          </button>
          <button
            onClick={handleDownloadMarkdown}
            title="Download social_engineering_report.md"
            className="p-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-semibold transition flex items-center gap-1 text-xs"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">Download .MD</span>
          </button>
        </div>
      </header>

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Navigation Sidebar (Visible on Report view) */}
        {activeTab === 'report' && (
          <aside className="w-64 border-r border-slate-800 bg-slate-900/50 p-4 hidden md:flex flex-col justify-between shrink-0 overflow-y-auto">
            <div className="space-y-4">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider font-mono">
                Report Sections
              </div>
              <nav className="space-y-1 text-xs">
                {[
                  { id: 'sec-1', label: '1. Title & Metadata' },
                  { id: 'sec-2', label: '2. Introduction' },
                  { id: 'sec-3', label: '3. Phishing Attacks' },
                  { id: 'sec-3-4', label: '   ↳ 2011 RSA SecurID Study' },
                  { id: 'sec-3-5', label: '   ↳ 4 Phishing Defenses' },
                  { id: 'sec-4', label: '4. Pretexting Attacks' },
                  { id: 'sec-4-2', label: '   ↳ 2020 Twitter Case Study' },
                  { id: 'sec-5', label: '5. Baiting Attacks' },
                  { id: 'sec-5-2', label: '   ↳ 2016 IEEE USB Study' },
                  { id: 'sec-6', label: '6. Quid Pro Quo (Bonus)' },
                  { id: 'sec-7', label: '7. Comparison Matrix' },
                  { id: 'sec-8', label: '8. 5-Point Checklist' },
                  { id: 'sec-9', label: '9. Organizational Defenses' },
                  { id: 'sec-10', label: '10. Three Key Takeaways' },
                  { id: 'sec-11', label: '11. References (8 Sources)' }
                ].map(item => (
                  <a
                    key={item.id}
                    href={`#${item.id}`}
                    onClick={() => setActiveSection(item.id)}
                    className={`block py-1.5 px-2.5 rounded transition ${
                      activeSection === item.id
                        ? 'bg-cyan-500/20 text-cyan-300 font-semibold border-l-2 border-cyan-400'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                    }`}
                  >
                    {item.label}
                  </a>
                ))}
              </nav>
            </div>

            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400 space-y-2">
              <div className="flex items-center gap-1.5 text-emerald-400 font-mono">
                <CheckCircle2 className="w-3.5 h-3.5" /> 8 Verified Citations
              </div>
              <div className="flex items-center gap-1.5 text-cyan-400 font-mono">
                <CheckCircle2 className="w-3.5 h-3.5" /> 3 Real Case Studies
              </div>
              <div className="flex items-center gap-1.5 text-slate-400 font-mono">
                <FolderTree className="w-3.5 h-3.5" /> OIBSIP Task 5 Ready
              </div>
            </div>
          </aside>
        )}

        {/* Content Viewer Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-10 max-w-5xl mx-auto space-y-10">
          {/* VIEW: EXECUTIVE FORMATTED REPORT */}
          {activeTab === 'report' && (
            <div className="space-y-12">
              {/* Header Card */}
              <div id="sec-1" className="p-6 sm:p-8 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-cyan-950/40 border border-slate-800 shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
                  <ShieldAlert className="w-48 h-48 text-cyan-400" />
                </div>
                <div className="flex items-center gap-2 mb-3">
                  <span className="px-2.5 py-1 rounded-md text-xs font-mono font-bold bg-cyan-500 text-slate-950 uppercase">
                    Task 5 Deliverable
                  </span>
                  <span className="text-xs text-slate-400 font-mono">Oasis Infobyte Internship Program</span>
                </div>
                <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight mb-4">
                  Social Engineering Attacks: Types, Real-World Cases, and Prevention
                </h1>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-slate-800 text-xs font-mono text-slate-300">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Track</span>
                    OIBSIP Security Analyst
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Prepared By</span>
                    [Your Name]
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Date</span>
                    October 29, 2026
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase">Primary File</span>
                    <span className="text-cyan-400">social_engineering_report.md</span>
                  </div>
                </div>
              </div>

              {/* Section 2: Introduction */}
              <section id="sec-2" className="space-y-4">
                <div className="flex items-center gap-2 text-cyan-400 font-mono text-sm uppercase tracking-wider">
                  <BookOpen className="w-4 h-4" /> Section 2
                </div>
                <h2 className="text-2xl font-bold text-white">Introduction & Cognitive Heuristics</h2>
                <div className="text-slate-300 leading-relaxed space-y-4 text-base">
                  <p>
                    <strong>Social engineering</strong> in cybersecurity is the psychological manipulation of human individuals into voluntarily performing actions or divulging confidential information that compromises personal or enterprise security <button onClick={() => setSelectedCitation(REFERENCES[0])} className="text-cyan-400 hover:underline font-mono text-xs font-bold">[1]</button>. While traditional attacks attempt to exploit software vulnerabilities, unpatched operating systems, or open firewall ports, social engineering targets human cognition and social dynamics <button onClick={() => setSelectedCitation(REFERENCES[2])} className="text-cyan-400 hover:underline font-mono text-xs font-bold">[3]</button>.
                  </p>
                  
                  {/* Stat Callout */}
                  <div className="p-4 rounded-xl bg-slate-900 border-l-4 border-cyan-500 border border-slate-800 flex items-start gap-4">
                    <Sparkles className="w-6 h-6 text-cyan-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="text-xs uppercase font-mono text-cyan-400 font-bold">Empirical Threat Metric (Verizon DBIR 2024)</div>
                      <p className="text-sm text-slate-200 mt-1">
                        The <strong>Verizon 2024 Data Breach Investigations Report (DBIR)</strong> established that the <strong>human element was involved in 68% of all analyzed breaches globally</strong> <button onClick={() => setSelectedCitation(REFERENCES[7])} className="text-cyan-400 hover:underline font-mono text-xs font-bold">[8]</button>. This metric accounts for breaches wherein non-malicious humans were manipulated through phishing or pretexting, or inadvertently committed configuration errors that granted adversaries initial access.
                      </p>
                    </div>
                  </div>

                  <p>
                    Attackers exploit specific evolutionary and psychological levers because human beings are wired with heuristics that prioritize trust, social cohesion, and efficiency:
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
                    {[
                      { title: 'Trust & Rapport', desc: 'Victims naturally seek to be collaborative and helpful to supposed colleagues or service personnel.' },
                      { title: 'Urgency', desc: 'Artificial deadlines ("Account suspended in 15 mins") induce panic, bypassing rational scrutiny.' },
                      { title: 'Fear & Intimidation', desc: 'Threats of disciplinary action, legal liability, or financial penalties compel compliance.' },
                      { title: 'Authority', desc: 'Impersonating executives, IT directors, or law enforcement leverages institutional hierarchy.' },
                      { title: 'Curiosity & Greed', desc: 'Incentives like compensation files, free items, or leaked data entice unsafe actions.' },
                      { title: 'Routine & Habit', desc: 'Employees process hundreds of daily messages, creating fatigue where vigilance lapses.' }
                    ].map((lever, i) => (
                      <div key={i} className="p-3.5 rounded-lg bg-slate-900/80 border border-slate-800/80">
                        <div className="text-sm font-semibold text-cyan-300 font-mono">{lever.title}</div>
                        <div className="text-xs text-slate-400 mt-1 leading-snug">{lever.desc}</div>
                      </div>
                    ))}
                  </div>

                  <p className="text-sm text-slate-400 italic pt-2">
                    <strong>Why technical controls alone fail:</strong> Firewalls, antivirus scanners, and intrusion detection systems are completely bypassed when an attacker uses legitimate credentials voluntarily provided by a deceived user. True enterprise resilience requires a defense-in-depth model that reinforces human awareness alongside technical defenses.
                  </p>
                </div>
              </section>

              {/* Section 3: Phishing Attacks */}
              <section id="sec-3" className="space-y-6 pt-6 border-t border-slate-800">
                <div className="flex items-center gap-2 text-cyan-400 font-mono text-sm uppercase tracking-wider">
                  <Mail className="w-4 h-4" /> Section 3
                </div>
                <h2 className="text-2xl font-bold text-white">Phishing Attacks: Lifecycle, Variants, and Mechanics</h2>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                  <h3 className="text-xs font-mono uppercase text-slate-400 mb-3 tracking-wider">General Phishing Lifecycle (5 Stages)</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 text-center text-xs">
                    {[
                      { step: '1. Target Selection', note: 'OSINT reconnaissance & directory scraping' },
                      { step: '2. Deceptive Delivery', note: 'Email, SMS, VoIP, or collaboration tools' },
                      { step: '3. Psychological Trigger', note: 'Urgency, fear, authority, or curiosity' },
                      { step: '4. Victim Action', note: 'Clicks link, opens file, inputs password' },
                      { step: '5. Post-Compromise', note: 'Credential theft, C2 beacon, wire redirection' }
                    ].map((s, idx) => (
                      <div key={idx} className="p-2.5 rounded bg-slate-950 border border-slate-800 flex flex-col justify-between">
                        <span className="font-bold text-cyan-300 font-mono">{s.step}</span>
                        <span className="text-[11px] text-slate-400 mt-1">{s.note}</span>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-slate-400 mt-3">
                    <em>Crucial note:</em> Not every phishing attack relies on malware. A substantial proportion focuses exclusively on <strong>credential harvesting</strong> or <strong>Business Email Compromise (BEC)</strong> financial redirection <button onClick={() => setSelectedCitation(REFERENCES[1])} className="text-cyan-400 hover:underline font-mono text-xs font-bold">[2]</button>.
                  </p>
                </div>

                {/* Subsections: Types */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-cyan-400 font-mono">Spear Phishing</span>
                      <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">Targeted</span>
                    </div>
                    <p className="text-xs text-slate-300">Customized messages directed at a specific individual or team using contextual reconnaissance <button onClick={() => setSelectedCitation(REFERENCES[6])} className="text-cyan-400 hover:underline font-mono text-[10px] font-bold">[7]</button>.</p>
                    <div className="p-2.5 rounded bg-slate-950 border border-slate-800/80 text-[11px] text-slate-400">
                      <strong className="text-slate-200">Example:</strong> Accountant receives email referencing an active internal project code with an invoice from an existing vendor.
                    </div>
                    <div className="text-[11px] text-slate-400"><strong>Trigger:</strong> Contextual relevance & professional duty.</div>
                    <div className="text-[11px] text-amber-400"><strong>Warning Sign:</strong> Subtle domain typo (`vendor-billing.com` instead of `vendor.com`).</div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-purple-400 font-mono">Whaling</span>
                      <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800">Executive</span>
                    </div>
                    <p className="text-xs text-slate-300">Spear phishing directed at senior executives or high-value board members holding signing authority.</p>
                    <div className="p-2.5 rounded bg-slate-950 border border-slate-800/80 text-[11px] text-slate-400">
                      <strong className="text-slate-200">Example:</strong> CFO receives a confidential email alleging an urgent regulatory subpoena requiring immediate review.
                    </div>
                    <div className="text-[11px] text-slate-400"><strong>Trigger:</strong> High-stakes legal fear & confidentiality constraints.</div>
                    <div className="text-[11px] text-amber-400"><strong>Warning Sign:</strong> Demands to bypass procurement channels under "emergency board secrecy."</div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-emerald-400 font-mono">Vishing (Voice)</span>
                      <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">Telephone</span>
                    </div>
                    <p className="text-xs text-slate-300">Phishing executed over telephone calls where attackers verbally manipulate victims in real time <button onClick={() => setSelectedCitation(REFERENCES[0])} className="text-cyan-400 hover:underline font-mono text-[10px] font-bold">[1]</button>.</p>
                    <div className="p-2.5 rounded bg-slate-950 border border-slate-800/80 text-[11px] text-slate-400">
                      <strong className="text-slate-200">Example:</strong> Caller claiming to be from Corporate Help Desk needs employee's MFA passcode to patch an active network leak.
                    </div>
                    <div className="text-[11px] text-slate-400"><strong>Trigger:</strong> Perceived IT authority & urgency to fix an impediment.</div>
                    <div className="text-[11px] text-amber-400"><strong>Warning Sign:</strong> Unprompted caller requesting one-time authentication codes or passwords.</div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-amber-400 font-mono">Smishing (SMS)</span>
                      <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">Mobile SMS</span>
                    </div>
                    <p className="text-xs text-slate-300">Phishing through SMS or mobile messages containing malicious shortened links or fraudulent call-backs.</p>
                    <div className="p-2.5 rounded bg-slate-950 border border-slate-800/80 text-[11px] text-slate-400">
                      <strong className="text-slate-200">Example:</strong> SMS stating package delivery is held due to wrong postal address, directing to shortened link.
                    </div>
                    <div className="text-[11px] text-slate-400"><strong>Trigger:</strong> Impulsive convenience & fear of lost package.</div>
                    <div className="text-[11px] text-amber-400"><strong>Warning Sign:</strong> Unknown international sender number and generic URL shortener masking the destination.</div>
                  </div>
                </div>

                {/* Case Study 1: RSA SecurID */}
                <div id="sec-3-4" className="p-5 sm:p-6 rounded-xl bg-slate-900 border border-cyan-500/30 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-cyan-500 text-slate-950 text-[10px] font-mono font-bold uppercase">
                        Case Study 1
                      </span>
                      <h3 className="text-lg font-bold text-white">The 2011 RSA SecurID Spear-Phishing Breach</h3>
                    </div>
                    <span className="text-xs text-slate-400 font-mono">Dark Reading / Uri Rivner [4]</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    In March 2011, RSA (the security division of EMC) suffered an APT breach that compromised technical data relating to its flagship SecurID two-factor authentication tokens. The breach originated when attackers sent two small batches of emails titled <strong>"2011 Recruitment Plan"</strong> to lower-level employees. Although the email gateway filtered the message directly into the <strong>Junk Mail folder</strong>, an employee retrieved it and opened the attachment <code>2011 Recruitment plan.xls</code>.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs font-mono pt-2">
                    <div className="p-2 rounded bg-slate-950 border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">Zero-Day Exploit</span>
                      <span className="text-amber-400">Adobe Flash CVE-2011-0609</span>
                    </div>
                    <div className="p-2 rounded bg-slate-950 border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">Payload Implant</span>
                      <span className="text-cyan-400">Poison Ivy Reverse RAT</span>
                    </div>
                    <div className="p-2 rounded bg-slate-950 border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">Downstream Fallout</span>
                      <span className="text-purple-400">Lockheed Martin Intrusion</span>
                    </div>
                  </div>
                  <p className="text-xs text-slate-400 italic">
                    <strong>Key Lesson:</strong> Human curiosity can override automated perimeter defenses (retrieving files from spam). Even high-security manufacturers are vulnerable to weaponized documents exploiting zero-days.
                  </p>
                </div>

                {/* 4 Phishing Prevention Recommendations */}
                <div id="sec-3-5" className="space-y-3">
                  <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                    Four Phishing Prevention Recommendations & Inherent Limitations
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
                      <div className="font-bold text-cyan-300 font-mono">1. Adaptive Awareness & Simulations</div>
                      <p className="text-slate-300 mt-1">Periodic micro-trainings and realistic simulated phishing drills.</p>
                      <span className="text-slate-400 mt-2 block text-[11px]"><em>Limitation:</em> Human alertness degrades under fatigue and high operational stress.</span>
                    </div>
                    <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
                      <div className="font-bold text-cyan-300 font-mono">2. Phishing-Resistant MFA (FIDO2)</div>
                      <p className="text-slate-300 mt-1">Hardware security keys (WebAuthn/FIDO2) cryptographically bound to the domain.</p>
                      <span className="text-slate-400 mt-2 block text-[11px]"><em>Limitation:</em> Legacy systems lack WebAuthn support; SMS/push MFA remain vulnerable to AitM proxies.</span>
                    </div>
                    <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
                      <div className="font-bold text-cyan-300 font-mono">3. Perimeter Protocols (DMARC/Sandboxes)</div>
                      <p className="text-slate-300 mt-1">Enforcing SPF, DKIM, and DMARC (`p=reject`), paired with dynamic URL inspection.</p>
                      <span className="text-slate-400 mt-2 block text-[11px]"><em>Limitation:</em> Adversaries abuse legitimate cloud services (SharePoint, Google Drive) that bypass reputation.</span>
                    </div>
                    <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
                      <div className="font-bold text-cyan-300 font-mono">4. Rapid Incident Reporting & Revocation</div>
                      <p className="text-slate-300 mt-1">One-click reporting buttons connected to SOAR playbooks for instant session invalidation.</p>
                      <span className="text-slate-400 mt-2 block text-[11px]"><em>Limitation:</em> Depends entirely on the victim noticing and reporting the compromise without delay.</span>
                    </div>
                  </div>
                </div>
              </section>

              {/* Section 4: Pretexting */}
              <section id="sec-4" className="space-y-6 pt-6 border-t border-slate-800">
                <div className="flex items-center gap-2 text-cyan-400 font-mono text-sm uppercase tracking-wider">
                  <PhoneCall className="w-4 h-4" /> Section 4
                </div>
                <h2 className="text-2xl font-bold text-white">Pretexting Attacks: Fabricated Realities</h2>
                <p className="text-slate-300 text-sm leading-relaxed">
                  <strong>Pretexting</strong> is a social engineering technique where an adversary invents a plausible false identity, situation, or background story to persuade a victim into releasing sensitive information or granting unauthorized system privileges <button onClick={() => setSelectedCitation(REFERENCES[2])} className="text-cyan-400 hover:underline font-mono text-xs font-bold">[3]</button>. Unlike generic phishing, pretexting relies on deep contextual credibility and structured dialogue.
                </p>

                {/* Case Study 2: Twitter 2020 */}
                <div id="sec-4-2" className="p-5 sm:p-6 rounded-xl bg-slate-900 border border-cyan-500/30 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-cyan-500 text-slate-950 text-[10px] font-mono font-bold uppercase">
                        Case Study 2
                      </span>
                      <h3 className="text-lg font-bold text-white">The July 15, 2020 Twitter Security Incident</h3>
                    </div>
                    <span className="text-xs text-slate-400 font-mono">NY DFS Investigation Report [5]</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    According to the New York State Department of Financial Services (NY DFS) regulatory investigation, attackers phoned remote Twitter employees posing as internal IT Help Desk personnel assisting with remote VPN connectivity issues. Employees were guided to a counterfeit VPN login page that harvested their credentials and captured their multi-factor authentication passcodes in real time.
                  </p>
                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono space-y-1">
                    <div className="text-cyan-300"><strong>Access Escalation:</strong> Attackers accessed Twitter’s Customer Support Admin Tool ("Agent" tool).</div>
                    <div className="text-amber-300"><strong>Impact:</strong> Hijacked 130 verified accounts (Obama, Biden, Musk, Apple) to broadcast a Bitcoin doubling scam.</div>
                    <div className="text-emerald-300"><strong>Fraud Total:</strong> Defrauded public victims of over $118,000 USD within hours before containment.</div>
                  </div>
                  <div className="text-xs text-slate-400">
                    <strong>Systemic Deficiencies Exposed:</strong> Twitter lacked a permanent CISO at the time, granted more than 1,000 employees access to internal administrative tools, and lacked dual-authorization requirements for critical account overrides.
                  </div>
                </div>

                {/* Practical Employee Script */}
                <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-800/60 space-y-2">
                  <div className="text-xs font-mono font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                    Standardized Script: Politely Refusing & Verifying an Inbound Request
                  </div>
                  <blockquote className="text-xs text-slate-200 italic font-mono bg-slate-950/70 p-3 rounded border border-cyan-900/50">
                    "Thank you for reaching out. Due to our company information security policy, I cannot provide credentials, session tokens, or system modifications during an unsolicited inbound interaction. I will document your request, verify your contact info in our official internal corporate directory, and call you back through our verified internal ticketing system."
                  </blockquote>
                </div>
              </section>

              {/* Section 5: Baiting Attacks */}
              <section id="sec-5" className="space-y-6 pt-6 border-t border-slate-800">
                <div className="flex items-center gap-2 text-cyan-400 font-mono text-sm uppercase tracking-wider">
                  <HardDrive className="w-4 h-4" /> Section 5
                </div>
                <h2 className="text-2xl font-bold text-white">Baiting Attacks: Physical Removable Media & Digital Lures</h2>
                <p className="text-slate-300 text-sm leading-relaxed">
                  <strong>Baiting</strong> entices victims with something desirable, seemingly valuable, or convenient to encourage an unsafe action <button onClick={() => setSelectedCitation(REFERENCES[0])} className="text-cyan-400 hover:underline font-mono text-xs font-bold">[1]</button>. It operates across two primary domains:
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                    <div className="font-bold text-amber-400 font-mono text-sm">Physical Baiting</div>
                    <p className="text-slate-300">Leaving weaponized USB drives, hard drives, or charging cables in corporate parking lots, lobbies, or breakrooms with intriguing labels like "Executive Salaries" or "Confidential Layoffs" <button onClick={() => setSelectedCitation(REFERENCES[5])} className="text-cyan-400 hover:underline font-mono text-[10px] font-bold">[6]</button>.</p>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                    <div className="font-bold text-cyan-400 font-mono text-sm">Digital Baiting</div>
                    <p className="text-slate-300">Enticing users online with "free" cracked commercial software, unreleased video media, or bogus PDF industry salary matrices that conceal trojanized installers or spyware.</p>
                  </div>
                </div>

                {/* Case Study 3: 2016 IEEE USB Study */}
                <div id="sec-5-2" className="p-5 sm:p-6 rounded-xl bg-slate-900 border border-cyan-500/30 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-cyan-500 text-slate-950 text-[10px] font-mono font-bold uppercase">
                        Case Study 3
                      </span>
                      <h3 className="text-lg font-bold text-white">2016 IEEE S&P Study: "Users Really Do Plug in USB Drives They Find"</h3>
                    </div>
                    <span className="text-xs text-slate-400 font-mono">Tischer, Bursztein et al. [6]</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Researchers dropped <strong>297 functional USB drives</strong> with benign tracking beacons across the University of Illinois Urbana-Champaign campus to empirically evaluate human risk behavior under peer-reviewed experimental controls.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
                    <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                      <span className="text-cyan-400 text-base font-bold block">45% – 98%</span>
                      <span className="text-slate-400 text-[11px]">Drives plugged into internet-connected computers</span>
                    </div>
                    <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                      <span className="text-amber-400 text-base font-bold block">&lt; 6 Minutes</span>
                      <span className="text-slate-400 text-[11px]">Time elapsed until the first drive was connected</span>
                    </div>
                    <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
                      <span className="text-purple-400 text-base font-bold block">68% Altruism</span>
                      <span className="text-slate-400 text-[11px]">Users claimed wanting to find owner, yet opened private photos first</span>
                    </div>
                  </div>
                </div>
              </section>

              {/* Section 6: Bonus Quid Pro Quo */}
              <section id="sec-6" className="space-y-4 pt-6 border-t border-slate-800">
                <div className="flex items-center gap-2 text-cyan-400 font-mono text-sm uppercase tracking-wider">
                  <HelpCircle className="w-4 h-4" /> Section 6 (Bonus Topic)
                </div>
                <h2 className="text-2xl font-bold text-white">Bonus Topic: Quid Pro Quo Attacks</h2>
                <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3 text-xs text-slate-300">
                  <p className="text-sm">
                    <strong>Quid Pro Quo</strong> ("something for something") is an attack where an adversary promises an explicit service, technical fix, or benefit in exchange for user credentials or security compromises <button onClick={() => setSelectedCitation(REFERENCES[2])} className="text-cyan-400 hover:underline font-mono text-xs font-bold">[3]</button>.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div className="p-3 rounded bg-slate-950 border border-slate-800">
                      <div className="font-bold text-amber-300 font-mono">Baiting (Passive)</div>
                      <p className="text-slate-400 mt-1">Dangles an attractive lure (free USB, movie torrent, prize) and waits passively for the victim to interact.</p>
                    </div>
                    <div className="p-3 rounded bg-slate-950 border border-slate-800">
                      <div className="font-bold text-cyan-300 font-mono">Quid Pro Quo (Active)</div>
                      <p className="text-slate-400 mt-1">Directly approaches the victim with an active offer: "I will optimize your network connection if you provide your domain password."</p>
                    </div>
                  </div>
                  <div className="pt-2 text-slate-400">
                    <strong>Countermeasures:</strong> Strictly require that internal IT only connects in response to existing, user-generated support tickets, and maintain an uncompromised policy that support staff never request passwords or MFA tokens.
                  </div>
                </div>
              </section>

              {/* Section 7: Comparison Table */}
              <section id="sec-7" className="space-y-4 pt-6 border-t border-slate-800">
                <div className="flex items-center gap-2 text-cyan-400 font-mono text-sm uppercase tracking-wider">
                  <Layers className="w-4 h-4" /> Section 7
                </div>
                <h2 className="text-2xl font-bold text-white">Comprehensive Attack Comparison Matrix</h2>
                <div className="overflow-x-auto rounded-xl border border-slate-800">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-900 text-cyan-300 font-mono border-b border-slate-800">
                        <th className="p-3">Attack Type</th>
                        <th className="p-3">Primary Target</th>
                        <th className="p-3">Psychological Lever</th>
                        <th className="p-3">Best Countermeasure</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/80 bg-slate-950/60 font-sans">
                      {COMPARISON_ROWS.map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-900/40 transition">
                          <td className="p-3 font-semibold font-mono text-white whitespace-nowrap">{row.type}</td>
                          <td className="p-3 text-slate-300">{row.target}</td>
                          <td className="p-3 text-slate-400">{row.lever}</td>
                          <td className="p-3 text-cyan-300/90 text-[11px]">{row.countermeasure}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>

              {/* Section 8: 5-Point Checklist */}
              <section id="sec-8" className="space-y-4 pt-6 border-t border-slate-800">
                <div className="flex items-center gap-2 text-cyan-400 font-mono text-sm uppercase tracking-wider">
                  <UserCheck className="w-4 h-4" /> Section 8
                </div>
                <h2 className="text-2xl font-bold text-white">Five-Point Employee Security Awareness Checklist</h2>
                <div className="space-y-3">
                  {[
                    { num: 1, title: 'Recognize', action: 'Inspect unexpected links, urgent tones, mismatched domains, and unsolicited offers before taking action.' },
                    { num: 2, title: 'Verify', action: 'Confirm all unexpected requests for credentials, money, or access through an official, independently obtained directory.' },
                    { num: 3, title: 'Protect', action: 'Never disclose passwords, session tokens, or MFA one-time passcodes to anyone under any circumstance.' },
                    { num: 4, title: 'Report', action: 'Promptly report suspicious emails, phone calls, or dropped media via official reporting channels without fear of reprisal.' },
                    { num: 5, title: 'Practice and Improve', action: 'Participate actively in security drills and micro-training to continuously sharpen behavioral defense instincts.' }
                  ].map(c => (
                    <div key={c.num} className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-start gap-3">
                      <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-mono text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                        {c.num}
                      </span>
                      <div>
                        <div className="text-sm font-bold text-white">{c.title}</div>
                        <div className="text-xs text-slate-300 mt-0.5">{c.action}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-slate-400 italic">
                  <strong>Cultural Principle:</strong> A supportive, blame-free reporting culture encourages employees to flag errors immediately, reducing adversary dwell time from months to minutes.
                </p>
              </section>

              {/* Section 9: Organizational Recommendations */}
              <section id="sec-9" className="space-y-4 pt-6 border-t border-slate-800">
                <div className="flex items-center gap-2 text-cyan-400 font-mono text-sm uppercase tracking-wider">
                  <Building2 className="w-4 h-4" /> Section 9
                </div>
                <h2 className="text-2xl font-bold text-white">Organizational Recommendations (Defense-in-Depth)</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                  <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="font-bold text-cyan-300 font-mono">Least-Privilege & RBAC</div>
                    <p className="text-slate-400 mt-1">Restrict administrative privileges strictly and require multi-party dual authorization for sensitive actions.</p>
                  </div>
                  <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="font-bold text-cyan-300 font-mono">Phishing-Resistant MFA</div>
                    <p className="text-slate-400 mt-1">Enforce FIDO2 / WebAuthn cryptographic hardware security keys to eliminate proxy credential harvesting.</p>
                  </div>
                  <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="font-bold text-cyan-300 font-mono">Email & Endpoint Hygiene</div>
                    <p className="text-slate-400 mt-1">Deploy strict DMARC (`p=reject`), endpoint mass-storage USB disabling, and real-time link sandboxing.</p>
                  </div>
                  <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="font-bold text-cyan-300 font-mono">Help Desk Identity Protocols</div>
                    <p className="text-slate-400 mt-1">Enforce video confirmation or manager sign-off before executing password or MFA token resets.</p>
                  </div>
                  <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="font-bold text-cyan-300 font-mono">Tested Session Revocation</div>
                    <p className="text-slate-400 mt-1">Maintain automated playbooks to instantly revoke session tokens and isolate endpoints across the fleet.</p>
                  </div>
                  <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="font-bold text-cyan-300 font-mono">Blame-Free Culture</div>
                    <p className="text-slate-400 mt-1">Reward employees who quickly report suspicious interactions rather than penalizing accidental clicks.</p>
                  </div>
                </div>
              </section>

              {/* Section 10: Conclusion */}
              <section id="sec-10" className="space-y-4 pt-6 border-t border-slate-800">
                <div className="flex items-center gap-2 text-cyan-400 font-mono text-sm uppercase tracking-wider">
                  <CheckCircle2 className="w-4 h-4" /> Section 10
                </div>
                <h2 className="text-2xl font-bold text-white">Conclusion: Three Key Takeaways</h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    { num: '1', title: 'Exploits Human Nature', desc: 'Social engineering manipulates cognitive trust and normal behavior, which is cheaper and faster than breaking cryptographic code.' },
                    { num: '2', title: 'Layered Defense Beats Single Fixes', desc: 'True security requires combining phishing-resistant MFA, least privilege, out-of-band verification, and continuous training.' },
                    { num: '3', title: 'Speed of Reporting Decides Outcome', desc: 'The severity of a compromise is governed by how fast an employee reports it, enabling rapid session revocation and threat containment.' }
                  ].map((t, idx) => (
                    <div key={idx} className="p-4 rounded-xl bg-slate-900 border border-slate-800 relative">
                      <div className="text-2xl font-extrabold text-cyan-400 font-mono mb-2">0{t.num}</div>
                      <div className="text-sm font-bold text-white mb-1">{t.title}</div>
                      <div className="text-xs text-slate-400">{t.desc}</div>
                    </div>
                  ))}
                </div>
              </section>

              {/* Section 11: References */}
              <section id="sec-11" className="space-y-4 pt-6 border-t border-slate-800">
                <div className="flex items-center gap-2 text-cyan-400 font-mono text-sm uppercase tracking-wider">
                  <ExternalLink className="w-4 h-4" /> Section 11
                </div>
                <h2 className="text-2xl font-bold text-white">References (8 Authoritative Citations)</h2>
                <div className="space-y-2 text-xs">
                  {REFERENCES.map(ref => (
                    <div key={ref.id} className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <span className="font-mono text-cyan-400 font-bold mr-2">[{ref.id}]</span>
                        <span className="font-semibold text-white">{ref.author}</span> ({ref.year}). <em>{ref.title}</em>. <span className="text-slate-400">{ref.source}</span>.
                      </div>
                      <a
                        href={ref.url}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-mono text-[11px] shrink-0"
                      >
                        Source Link <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  ))}
                </div>
              </section>
            </div>
          )}

          {/* VIEW: CASE STUDIES DEEP-DIVE */}
          {activeTab === 'cases' && (
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold text-white">Forensic Case Study Analyses</h2>
                <p className="text-xs text-slate-400 mt-1">
                  In-depth forensic breakdowns of the three real-world case studies documented in the Task 5 report.
                </p>
              </div>

              {/* RSA SecurID */}
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <span className="text-xs font-mono uppercase px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                      Phishing / APT Vector
                    </span>
                    <h3 className="text-xl font-bold text-white mt-1">2011 RSA SecurID Spear-Phishing Attack</h3>
                  </div>
                  <span className="text-xs text-slate-400 font-mono">Source: Dark Reading / Uri Rivner [4]</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-2">
                    <h4 className="font-bold text-cyan-300 font-mono uppercase">Attack Progression</h4>
                    <ul className="list-disc list-inside text-slate-300 space-y-1.5">
                      <li>Attackers targeted small batches of low-profile employees via email.</li>
                      <li>Subject line: <code>"2011 Recruitment Plan"</code> with attachment <code>2011 Recruitment plan.xls</code>.</li>
                      <li>Spam filters automatically placed email into the <strong>Junk Mail folder</strong>.</li>
                      <li>Curious employee actively moved email out of junk and opened the spreadsheet.</li>
                      <li>Embedded Adobe Flash zero-day (<code>CVE-2011-0609</code>) executed automatically.</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-bold text-cyan-300 font-mono uppercase">Fallout & Lessons</h4>
                    <ul className="list-disc list-inside text-slate-300 space-y-1.5">
                      <li>Poison Ivy RAT established an outbound encrypted tunnel to external C2.</li>
                      <li>Lateral movement harvested administrative credentials across network segments.</li>
                      <li>Adversaries exfiltrated sensitive algorithms and seed data for SecurID tokens.</li>
                      <li>Downstream defense contractors (Lockheed Martin) faced targeted follow-on attacks.</li>
                      <li>Proved that human curiosity can circumvent spam quarantine defenses.</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Twitter 2020 */}
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <span className="text-xs font-mono uppercase px-2 py-0.5 rounded bg-purple-950 text-purple-400 border border-purple-800">
                      Pretexting / Vishing Vector
                    </span>
                    <h3 className="text-xl font-bold text-white mt-1">July 15, 2020 Twitter Administrative Incident</h3>
                  </div>
                  <span className="text-xs text-slate-400 font-mono">Source: NY DFS Report [5]</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-2">
                    <h4 className="font-bold text-purple-300 font-mono uppercase">Attack Progression</h4>
                    <ul className="list-disc list-inside text-slate-300 space-y-1.5">
                      <li>Attackers telephoned remote employees pretending to be Twitter IT Help Desk staff.</li>
                      <li>Exploited remote pandemic work disorientation regarding VPN connection trouble.</li>
                      <li>Guided employees to a cloned VPN login page that harvested user credentials.</li>
                      <li>Intercepted multi-factor authentication (MFA) codes in real time and replayed them.</li>
                      <li>Pivoted into Twitter's internal Customer Support Admin ("Agent") tool.</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-bold text-purple-300 font-mono uppercase">Fallout & Lessons</h4>
                    <ul className="list-disc list-inside text-slate-300 space-y-1.5">
                      <li>Adversaries hijacked 130 high-profile accounts (Biden, Obama, Musk, Apple).</li>
                      <li>Broadcasted a cryptocurrency doubling scam, defrauding over $118,000 USD.</li>
                      <li>NY DFS reported Twitter lacked a permanent CISO and had over-broad tool permissions.</li>
                      <li>Emphasized the critical need for out-of-band callback verification.</li>
                      <li>Demonstrated that administrative tools must require dual authorization (4-eyes principle).</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* IEEE USB Study */}
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <span className="text-xs font-mono uppercase px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800">
                      Physical Baiting Vector
                    </span>
                    <h3 className="text-xl font-bold text-white mt-1">2016 IEEE S&P Empirical USB Study</h3>
                  </div>
                  <span className="text-xs text-slate-400 font-mono">Source: Tischer, Bursztein et al. [6]</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-2">
                    <h4 className="font-bold text-amber-300 font-mono uppercase">Experiment Methodology</h4>
                    <ul className="list-disc list-inside text-slate-300 space-y-1.5">
                      <li>Dropped 297 benign USB flash drives across UIUC campus locations.</li>
                      <li>Drives contained benign HTML files with tracking beacons (no malware).</li>
                      <li>45% to 98% of dropped USBs were connected to computers.</li>
                      <li>The fastest drive was connected less than 6 minutes after drop.</li>
                      <li>Surveyed users who opened files to identify cognitive motivators.</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-bold text-amber-300 font-mono uppercase">Findings & Defense</h4>
                    <ul className="list-disc list-inside text-slate-300 space-y-1.5">
                      <li>68% claimed altruistic intentions (seeking contact info to return the drive).</li>
                      <li>Behavior paradox: users consistently clicked vacation photo folders before resumes.</li>
                      <li>Technical controls must disable USB mass storage by default via EDR/MDM.</li>
                      <li>Physical port blockers and clear physical drop reporting procedures are mandatory.</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* VIEW: CHECKLIST & MATRIX */}
          {activeTab === 'checklist' && (
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold text-white">Interactive Security Checklist & Matrix</h2>
                <p className="text-xs text-slate-400 mt-1">
                  Validate employee behavioral compliance and search the attack comparison matrix.
                </p>
              </div>

              {/* Interactive 5-Point Checklist */}
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <UserCheck className="w-5 h-5 text-cyan-400" />
                    Five-Point Employee Awareness Verification Checklist
                  </h3>
                  <span className="text-xs text-cyan-400 font-mono">
                    {Object.values(checklistProgress).filter(Boolean).length}/5 Completed
                  </span>
                </div>

                <div className="space-y-3">
                  {[
                    { id: 1, title: '1. Recognize', desc: 'Identify suspicious links, unexpected attachments, mismatched domains, and artificial urgency.' },
                    { id: 2, title: '2. Verify', desc: 'Independently confirm unusual payment, credential, or access requests via official published channels.' },
                    { id: 3, title: '3. Protect', desc: 'Never share passwords or one-time MFA authentication codes with any internal or external contact.' },
                    { id: 4, title: '4. Report', desc: 'Promptly report suspected incidents via official reporting buttons without fear of disciplinary blame.' },
                    { id: 5, title: '5. Practice and Improve', desc: 'Participate actively in authorized simulations and training drills to build collective resilience.' }
                  ].map(item => (
                    <div
                      key={item.id}
                      onClick={() =>
                        setChecklistProgress(prev => ({ ...prev, [item.id]: !prev[item.id] }))
                      }
                      className={`p-3.5 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                        checklistProgress[item.id]
                          ? 'bg-cyan-950/20 border-cyan-800/80 text-white'
                          : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-5 h-5 rounded flex items-center justify-center border ${
                            checklistProgress[item.id]
                              ? 'bg-cyan-500 border-cyan-400 text-slate-950'
                              : 'border-slate-700'
                          }`}
                        >
                          {checklistProgress[item.id] && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                        <div>
                          <div className="text-sm font-semibold">{item.title}</div>
                          <div className="text-xs text-slate-400">{item.desc}</div>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {checklistProgress[item.id] ? 'Verified' : 'Pending'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Filterable Comparison Matrix */}
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <Layers className="w-5 h-5 text-cyan-400" />
                    Attack Type Comparison Matrix ({filteredComparison.length} Entries)
                  </h3>
                  <div className="relative w-full sm:w-64">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      placeholder="Search vector, lever, target..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                </div>

                <div className="overflow-x-auto rounded-xl border border-slate-800">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-950 text-cyan-300 font-mono border-b border-slate-800">
                        <th className="p-3">Attack Type</th>
                        <th className="p-3">Primary Target</th>
                        <th className="p-3">Psychological Lever</th>
                        <th className="p-3">Best Countermeasure</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/80 bg-slate-900/60 font-sans">
                      {filteredComparison.map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-800/50 transition">
                          <td className="p-3 font-semibold font-mono text-cyan-400 whitespace-nowrap">{row.type}</td>
                          <td className="p-3 text-slate-300">{row.target}</td>
                          <td className="p-3 text-slate-400">{row.lever}</td>
                          <td className="p-3 text-slate-300 font-mono text-[11px]">{row.countermeasure}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* VIEW: RAW MARKDOWN */}
          {activeTab === 'markdown' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-xl bg-slate-900 border border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-cyan-400 uppercase">Primary Deliverable</span>
                    <span className="text-xs text-slate-400 font-mono">social_engineering_report.md</span>
                  </div>
                  <h3 className="text-base font-bold text-white mt-0.5">Raw Markdown Source Viewer</h3>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyMarkdown}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono text-white flex items-center gap-1.5 border border-slate-700 transition"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? 'Copied to Clipboard' : 'Copy Text'}
                  </button>
                  <button
                    onClick={handleDownloadMarkdown}
                    className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-xs font-mono font-bold text-slate-950 flex items-center gap-1.5 transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download File
                  </button>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-slate-300 overflow-x-auto whitespace-pre leading-relaxed select-all">
                {fullMarkdownText}
              </div>
            </div>
          )}

          {/* VIEW: GITHUB SUBMISSION HUB */}
          {activeTab === 'github' && (
            <div className="space-y-6">
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-emerald-400 uppercase">Phase 7 Submission</span>
                      <span className="text-xs text-slate-400 font-mono">Portfolio Preparation</span>
                    </div>
                    <h3 className="text-xl font-bold text-white mt-1">GitHub Submission Files & Instructions</h3>
                  </div>
                  <GitBranch className="w-6 h-6 text-cyan-400" />
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  All required deliverables for <strong>OIBSIP Security Analyst Task 5</strong> have been generated and structured inside the standard task directory:
                </p>

                {/* File Tree */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-slate-300 space-y-1">
                  <div className="text-cyan-400 font-bold">OIBSIP/</div>
                  <div className="text-cyan-400 font-bold pl-4">└── SecurityAnalyst/</div>
                  <div className="text-cyan-400 font-bold pl-8">└── Task5_Social_Engineering_Attacks/</div>
                  <div className="pl-12 flex items-center justify-between py-1 text-slate-200 border-b border-slate-900">
                    <span>├── README.md</span>
                    <span className="text-emerald-400 text-[11px] font-bold">Created & Verified</span>
                  </div>
                  <div className="pl-12 flex items-center justify-between py-1 text-slate-200 border-b border-slate-900">
                    <span>├── social_engineering_report.md</span>
                    <span className="text-emerald-400 text-[11px] font-bold">Primary Report (11 Sections)</span>
                  </div>
                  <div className="pl-12 flex items-center justify-between py-1 text-slate-200 border-b border-slate-900">
                    <span>├── references.md</span>
                    <span className="text-emerald-400 text-[11px] font-bold">Annotated Bibliography (8 Sources)</span>
                  </div>
                  <div className="pl-12 flex items-center justify-between py-1 text-slate-200">
                    <span>└── .gitignore</span>
                    <span className="text-emerald-400 text-[11px] font-bold">Configured</span>
                  </div>
                </div>

                {/* Git Instructions Box */}
                <div className="space-y-2">
                  <div className="text-xs font-bold text-slate-300 font-mono flex items-center gap-1.5">
                    <Terminal className="w-4 h-4 text-cyan-400" /> Git Review & Commit Commands (for your local repo):
                  </div>
                  <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs text-cyan-300 space-y-1">
                    <div>git status</div>
                    <div>git add OIBSIP/SecurityAnalyst/Task5_Social_Engineering_Attacks/README.md</div>
                    <div>git add OIBSIP/SecurityAnalyst/Task5_Social_Engineering_Attacks/social_engineering_report.md</div>
                    <div>git add OIBSIP/SecurityAnalyst/Task5_Social_Engineering_Attacks/references.md</div>
                    <div>git add OIBSIP/SecurityAnalyst/Task5_Social_Engineering_Attacks/.gitignore</div>
                    <div>git diff --cached</div>
                    <div>git commit -m "Add OIBSIP Task 5 social engineering research report"</div>
                    <div>git push</div>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    <em>Notice:</em> In this isolated container runtime, remote git remotes or user credentials are not pre-configured, preventing automatic remote pushing. You can copy the files directly into your GitHub repository or drag-and-drop via the GitHub web UI.
                  </p>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Citation Modal / Flyout */}
      {selectedCitation && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-cyan-500 text-slate-950 font-mono font-bold text-xs">
                  Source [{selectedCitation.id}]
                </span>
                <span className="text-xs text-slate-400 font-mono">{selectedCitation.year}</span>
              </div>
              <button
                onClick={() => setSelectedCitation(null)}
                className="text-slate-400 hover:text-white text-xs font-mono p-1 rounded hover:bg-slate-800"
              >
                Close ✕
              </button>
            </div>
            <div>
              <h4 className="text-base font-bold text-white">{selectedCitation.title}</h4>
              <div className="text-xs text-cyan-400 font-mono mt-1">{selectedCitation.author}</div>
              <div className="text-xs text-slate-400 mt-0.5">{selectedCitation.source}</div>
            </div>
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300 leading-relaxed">
              <strong className="text-cyan-300 block mb-1 font-mono text-[11px] uppercase">Supported Evidence:</strong>
              {selectedCitation.note}
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <a
                href={selectedCitation.url}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold font-mono text-xs flex items-center gap-1.5 transition"
              >
                Visit Source URL <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
