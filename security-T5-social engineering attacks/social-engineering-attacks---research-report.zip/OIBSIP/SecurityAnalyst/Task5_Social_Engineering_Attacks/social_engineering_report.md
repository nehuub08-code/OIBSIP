# Social Engineering Attacks: Types, Real-World Cases, and Prevention

**Track:** OIBSIP Security Analyst  
**Task:** Task 5 — Research Report: Social Engineering Attacks  
**Prepared by:** [Your Name]  
**Date:** October 29, 2026  

---

## 1. Title and Report Information

- **Document Title:** Social Engineering Attacks: Types, Real-World Cases, and Prevention
- **Academic / Internship Track:** Oasis Infobyte Security Analyst Internship (OIBSIP) — Task 5
- **Research Subject:** Human-centric cyber attack vectors, exploitation mechanics, historical incident case studies, and defense-in-depth countermeasures.
- **Author Identity:** [Your Name], Student Cybersecurity Researcher
- **Document Version:** 1.0 (Final Research Deliverable)
- **Classification:** Public / Technical Portfolio Report

---

## 2. Introduction

Social engineering in cybersecurity refers to the psychological manipulation of human individuals into voluntarily performing actions or divulging confidential information that compromises personal or organizational security [1]. While traditional cyberattacks focus on identifying and exploiting flaws within software code, unpatched operating systems, open network ports, or firewall configurations, social engineering directly targets human cognition and interpersonal social dynamics [3]. In essence, instead of attempting to brute-force a 256-bit cryptographic key or locate a software zero-day vulnerability, an attacker convinces an authorized employee to hand over the key willingly.

Social engineering remains exceptionally prevalent and lethal across modern enterprise environments because human beings are naturally wired with cognitive heuristics that prioritize trust, social cohesion, and efficiency [3]. Threat actors exploit well-documented psychological levers, including:

- **Trust and Rapport:** Victims inherently desire to be collaborative and helpful to colleagues, clients, or service personnel.
- **Urgency:** Artificial deadlines (e.g., *"Your account will be suspended in 15 minutes"*) force victims into rapid, emotional decision-making, bypassing analytical scrutiny.
- **Fear and Intimidation:** Threats of disciplinary action, regulatory non-compliance, legal liability, or catastrophic financial penalties intimidate targets into submissive compliance.
- **Authority:** Attackers impersonate company executives, system administrators, legal advisors, or law enforcement officers to leverage institutional hierarchy.
- **Curiosity and Greed:** Tempting incentives, such as unexpected compensation adjustments, unreleased products, or free promotional items, entice users into unsafe interactions.
- **Routine and Habit:** Employees perform hundreds of repetitive digital tasks daily (reading emails, downloading attachments, clicking portal links), creating behavioral blind spots where vigilance naturally lapses.

Attackers orchestrate these psychological triggers to manipulate individuals and circumvent organizational business processes. Their primary objectives typically include harvesting administrative credentials, gaining unauthorized initial footholds into corporate perimeters, staging ransomware deployment, redirecting financial wire transfers, or exfiltrating proprietary intellectual property [2].

According to the **Verizon 2024 Data Breach Investigations Report (DBIR)**, the human element was involved in **68% of all analyzed breaches** globally [8]. The report clarifies that this metric measures incidents wherein non-malicious humans were manipulated through phishing or pretexting, or inadvertently committed errors (such as misdelivery of data or system misconfigurations) that directly facilitated unauthorized access [8]. This empirical finding underscores a fundamental reality of cybersecurity: **technical controls alone are insufficient.** Firewalls, antivirus scanners, and intrusion detection systems are rendered ineffective when an attacker possesses legitimate credentials handed to them by a deceived, authorized user. Robust security requires a defense-in-depth model that reinforces human awareness alongside resilient technical controls.

---

## 3. Phishing Attacks

### 3.1 Definition and General Attack Lifecycle

Phishing is a form of social engineering where an adversary delivers a fraudulent communication disguised as coming from a legitimate, trusted entity to deceive a victim into executing an unsafe action [1], [7]. 

The general phishing attack lifecycle progresses through five distinct stages:

```text
[1. Target Selection] ──> [2. Deceptive Delivery] ──> [3. Psychological Trigger] 
                                                                  │
                                                                  ▼
[5. Post-Compromise Misuse] <── [4. Victim Action Execution] <────┘
```

1. **Target Selection:** The adversary identifies either a broad demographic (bulk untargeted phishing) or specific individuals within an enterprise based on open-source intelligence (OSINT), corporate directories, or compromised contact lists.
2. **Deceptive Delivery:** The attacker crafts and dispatches a deceptive message via electronic channels (email, web forms, direct messages, collaboration platforms) impersonating a trusted brand, vendor, or internal department.
3. **Psychological Trigger Activation:** The message employs urgent language, impending deadlines, disciplinary warnings, or enticing rewards to elicit an emotional response rather than rational deliberation.
4. **Victim Action Execution:** Under psychological pressure, the victim interacts with the message—clicking a malicious hyperlink, opening an armed file attachment, entering credentials into a lookalike portal, or authorizing a transaction.
5. **Post-Compromise Exploitation:** The attacker captures the stolen credentials, executes an initial payload, pivots laterally into the internal corporate network, or initiates fraudulent monetary diversions.

Crucially, **not every phishing attempt relies on malicious software.** A large percentage of modern phishing campaigns focus exclusively on **credential harvesting** (capturing login tokens via spoofed web portals) or **financial fraud** (such as Business Email Compromise, where attackers manipulate invoice routing without executing any malicious code) [2], [8].

---

### 3.2 Types of Phishing

Phishing manifests in several specialized variants based on medium, target selection, and delivery technique:

#### A. Spear Phishing
- **Definition:** A highly targeted, customized phishing attack directed at a specific individual, team, or organization, utilizing gathered reconnaissance to maximize credibility [1], [7].
- **Illustrative Example:** An accountant receives an email addressing them by name, referencing an ongoing project code, and attaching an invoice that appears to originate from an established consulting vendor asking for remittance approval.
- **Psychological Trigger:** Familiarity, contextual relevance, and routine professional responsibility.
- **Warning Sign:** Subtle anomalies in the sender's email address (e.g., `vendor-billing.com` instead of `vendor.com`) or an unprompted change in payment wire instructions.

#### B. Whaling
- **Definition:** A specialized branch of spear phishing directed exclusively at high-profile executives, board members, or corporate officers who possess high-level administrative access or financial authority [1].
- **Illustrative Example:** A Chief Financial Officer receives a confidential communication claiming to be from the company's outside legal counsel, alleging an urgent, pending regulatory subpoena that requires immediate review of an encrypted legal brief.
- **Psychological Trigger:** Fear of legal/regulatory repercussions, high-stakes authority, and strict confidentiality constraints that discourage delegating or consulting colleagues.
- **Warning Sign:** Demands to bypass established procurement or verification channels under the guise of an "emergency board directive."

#### C. Vishing (Voice Phishing)
- **Definition:** Phishing conducted over telephone systems or voice communications, where an attacker verbally manipulates the victim [1].
- **Illustrative Example:** An employee receives a phone call from an individual claiming to be a technical engineer from the company's corporate IT Help Desk, stating that the employee's workstation is broadcasting anomalous network packets and requesting their one-time authentication passcode to apply a corrective patch.
- **Psychological Trigger:** Immediate urgency, perceived technical authority, and the victim's natural desire to resolve an operational impediment.
- **Warning Sign:** An unprompted caller requesting sensitive passwords, session tokens, or multi-factor authentication (MFA) prompts that legitimate IT staff are strictly policy-bound never to ask for.

#### D. Smishing (SMS Phishing)
- **Definition:** Phishing executed through Short Message Service (SMS), mobile text messages, or instant messaging platforms [1].
- **Illustrative Example:** An individual receives a mobile text message: *"Parcel delivery on hold due to incorrect postal address details. Confirm your delivery information within 12 hours at [shortened-link] to avoid return."*
- **Psychological Trigger:** Convenience, curiosity, and artificial urgency.
- **Warning Sign:** The message originates from an unknown international phone number or generic shortcode, uses a shortened URL (e.g., bit.ly or tinyurl) masking the true destination, and requests credit card or identity information for a package the recipient may not even recall ordering.

---

### 3.3 How Phishing Works: Attacker vs. Victim Perspective

Understanding phishing requires examining both sides of the engagement:

```text
ATTACKER PERSPECTIVE                           VICTIM PERSPECTIVE
[Domain Spoofing / Typosquatting] ─── Email ───> [Sees Familiar Sender Name]
[Reverse-Proxy / Armed Attachment] ── Link ────> [Believes Action is Routine]
[Interception of Passwords & MFA] ── Submit ───> [Assumes Portal is Legitimate]
```

- **The Attacker's Perspective:**
  The attacker prepares technical infrastructure designed to mimic legitimate services. They register lookalike domain names (typosquatting or homoglyph attacks, such as substituting Latin letters with visually identical Cyrillic characters), forge email header fields (`From:`, `Reply-To:`), and configure reverse-proxy phishing kits (e.g., Modlishka or Evilginx). These proxy kits mirror legitimate corporate login portals in real time, capturing both static user credentials and transient session cookies or multi-factor authentication passcodes before relaying the user to the real service [2]. Alternatively, the attacker arms weaponized files (such as macro-enabled Office documents, PDFs with embedded JavaScript, or ISO image containers) designed to exploit client-side software vulnerabilities and establish a command-and-control (C2) beacon.

- **The Victim's Perspective:**
  The victim experiences an ordinary day filled with operational tasks and communication noise. When a notification appears from what looks like Microsoft 365, Google Workspace, or their HR department, the employee focuses on the task at hand rather than examining technical metadata. Because the corporate branding, typography, and logos appear authentic, the user treats the request as routine maintenance, clicks the link, and inputs their credentials without realizing they are interacting with an external adversary.

---

### 3.4 Documented Case Study: The 2011 RSA SecurID Attack

#### Organizational Context
In March 2011, RSA (the security division of EMC Corporation) suffered one of the most consequential advanced persistent threat (APT) breaches in cybersecurity history [4]. RSA was a premier cybersecurity vendor worldwide; its SecurID two-factor authentication tokens were deployed by defense contractors, government agencies, and multinational financial institutions to secure sensitive network perimeters [4].

#### The Attack Vector and Exploitation Mechanics
According to RSA's official forensic disclosures and threat analysis published by Uri Rivner and *Dark Reading*, the attackers initiated their breach not through a brute-force assault on the corporate perimeter, but through a highly targeted spear-phishing campaign [4]:

1. Over a two-day period, the attackers dispatched two small batches of emails to a very small group of low-level, non-executive employees within EMC/RSA.
2. The emails carried the enticing subject line **"2011 Recruitment Plan"** and contained an attached Microsoft Excel spreadsheet named `2011 Recruitment plan.xls` [4].
3. The email was so overtly suspicious that the email gateway filtered it directly into the recipient's **Junk Mail folder**. However, driven by curiosity regarding corporate hiring and compensation, an employee intentionally retrieved the email from the junk folder and opened the spreadsheet [4].
4. The Excel spreadsheet contained an embedded Adobe Flash object that exploited an unpatched zero-day vulnerability in Adobe Flash Player (`CVE-2011-0609`) [4].
5. Opening the document triggered an arbitrary code execution sequence that bypassed endpoint antivirus solutions, silently installing a customized variant of the **Poison Ivy Remote Access Trojan (RAT)** on the employee's workstation [4].

#### Network Pivoting and Consequences
Once inside the local workstation, the attackers used the Poison Ivy backdoor to establish an encrypted outbound reverse connection to an external command-and-control server, making the traffic blend in with normal outbound web requests [4]. The adversaries conducted internal reconnaissance, harvested valid administrative credentials, escalated privileges, and moved laterally across RSA's internal segments.

Ultimately, the attackers reached high-security development repositories and exfiltrated sensitive proprietary data directly relating to RSA's **SecurID two-factor authentication system** [4]. While the attackers did not steal all customer databases directly from RSA, the exfiltrated algorithmic seed keys and cryptographic architectures degraded the integrity of SecurID deployments globally. Months later, defense contractor **Lockheed Martin** detected and blocked an intrusion attempt that attempted to utilize intelligence derived from the compromised RSA SecurID algorithms [4].

#### Key Lessons
The RSA incident demonstrated that even elite cybersecurity firms are vulnerable when individual human curiosity overrides basic security precautions. It underscored the danger of employees retrieving quarantined messages from junk folders, the necessity of least-privilege segmentation, and the critical risk posed by client-side zero-day exploits embedded in common business documents.

---

### 3.5 Four Phishing Prevention Recommendations

A resilient defense against phishing requires four interdependent safeguards [1], [2]:

| # | Defensive Measure | Operational Function | Inherent Limitations |
|---|---|---|---|
| **1** | **Continuous Security Awareness & Adaptive Simulation** | Trains employees to recognize red flags (urgency, unfamiliar senders, spoofed links) through regular micro-training modules and simulated phishing exercises [1]. | Training degrades over time; sophisticated spear phishing or high-stress operational environments can still deceive trained employees. Human behavior cannot be patched 100%. |
| **2** | **Phishing-Resistant Multi-Factor Authentication (MFA)** | Implements cryptographic hardware security keys (FIDO2 / WebAuthn standards) or certificate-based smart cards where the authentication token is bound cryptographically to the exact domain origin [2]. | Legacy systems may lack FIDO2 support. Push notifications or SMS-based MFA remain vulnerable to adversary-in-the-middle (AitM) proxy harvesting and MFA fatigue attacks. |
| **3** | **Automated Email & Web Perimeter Protections** | Deploys strict email authentication protocols (SPF, DKIM, DMARC), AI-driven spam/malware filtering, link rewrites with real-time inspection, and web domain sandboxing [2]. | Adversaries frequently use legitimate compromised accounts, free cloud services (Google Drive, Azure Blob, SharePoint), or newly registered clean domains that bypass reputation filters. |
| **4** | **Streamlined Incident Reporting & Rapid Response** | Provides a single-click "Report Phish" button in email clients, coupled with automated Security Orchestration, Automation, and Response (SOAR) playbooks to reset credentials and invalidate active session tokens enterprise-wide [1], [2]. | Relies on the user noticing and reporting the event promptly; if a victim fails to report the compromise, attackers can persist inside the network undetected for weeks or months. |

---

## 4. Pretexting Attacks

### 4.1 Definition and Process Flow

Pretexting is an advanced social engineering technique in which an adversary invents an elaborate, plausible scenario, false identity, or fictitious premise (the "pretext") to manipulate a victim into releasing confidential information, granting administrative access, performing financial transactions, or creating security policy exceptions [1], [3].

The standard pretexting methodology follows a structured five-step lifecycle:

```text
[1. Target Reconnaissance]
         │ (Harvest OSINT, org charts, job titles, internal terminology)
         ▼
[2. Pretext Formulation]
         │ (Construct believable persona: IT auditor, vendor, executive)
         ▼
[3. Direct Engagement]
         │ (Contact via phone, video, internal chat, or in-person visit)
         ▼
[4. Request Execution / Exception]
         │ (Ask for password reset, MFA token, data export, wire transfer)
         ▼
[5. Exploitation & Lateral Expansion]
           (Abuse obtained access to compromise core systems)
```

While phishing often casts a wider net with generic urgency, pretexting relies on deep contextual credibility. Pretexting frequently overlaps with vishing (when conducted by phone) and spear phishing (when delivered via email); however, the defining hallmark of pretexting is the **manufactured identity and narrative** constructed to convince the target that fulfilling the request is normal, authorized, and necessary [3].

---

### 4.2 Documented Case Study: The July 2020 Twitter Security Incident

#### Background and Investigative Context
On July 15, 2020, Twitter (now X) experienced one of the most visible social engineering breaches in social media history. A small group of young threat actors orchestrated an attack that hijacked **130 high-profile verified Twitter accounts**, including those of then-presidential candidate Joe Biden, former President Barack Obama, Elon Musk, Bill Gates, Jeff Bezos, Apple, and major cryptocurrency exchanges [5]. 

The incident was thoroughly investigated by the **New York State Department of Financial Services (NY DFS)** under Superintendent Linda A. Lacewell [5], alongside Twitter's internal security disclosures.

```text
[Attacker Phone Call] ── Vishing/Pretext ──> [Twitter Employee (Remote Work)]
        │                                                     │
   Posed as Twitter Help Desk                        Directed to Fake VPN Portal
        │                                                     │
        ▼                                                     ▼
[Real-Time MFA Interception] <─────────────── [Employee Inputs Credentials]
        │
        ▼
[Attacker Enters Twitter Internal Perimeter]
        │
        ▼
[Accesses Customer Support Admin Tool] ───> [Hijacks 130 Verified Accounts]
        │
        ▼
[Broadcasts Bitcoin Scam -> Defrauds Public of >$118,000 USD]
```

#### Incident Mechanics and Pretexting Strategy
The NY DFS investigative report documented that the breach began when the attackers initiated a sophisticated telephone-based pretexting (vishing) campaign targeting Twitter employees [5]:

1. **Exploiting the Remote Work Environment:** During the COVID-19 pandemic, Twitter staff were working remotely and frequently experienced virtual private network (VPN) connectivity issues [5].
2. **The Pretext:** The attackers phoned employees, claiming to be technicians from Twitter’s internal IT Help Desk calling to troubleshoot or update the employee's VPN configuration [5].
3. **The Hook:** To establish legitimacy, the attackers used technical jargon, referenced real internal Twitter terminology, and directed the employees to a lookalike phishing website that duplicated the visual appearance of Twitter's authentic internal VPN login page [5].
4. **Credential and MFA Capture:** When employees typed their corporate usernames, passwords, and multi-factor authentication codes into the counterfeit portal, the attackers intercepted them in real time and immediately replayed them against Twitter's genuine VPN gateways [5].
5. **Administrative Privilege Abuse:** Once inside the internal network, the attackers navigated through internal systems until they obtained access to Twitter’s proprietary **Customer Support Admin Tool** (internally referred to as the "Agent" tool) [5].
6. **Account Hijacking:** Using this internal administrative tool, the adversaries bypassed Twitter’s standard password reset workflows, reassigned the account email addresses associated with 130 target accounts, and tweeted a fraudulent cryptocurrency doubling scam (*"I am giving back to my community! All Bitcoin sent to the address below will be sent back doubled!"*), defrauding victims of over **$118,000 USD** within a few hours [5].

#### Psychological Levers and Systemic Vulnerabilities
The attackers succeeded by exploiting three primary psychological levers:
- **Helpfulness and Routine:** Remote employees genuinely wanted to fix their corporate VPN connection to continue their daily tasks.
- **Authority:** The attackers posed as internal IT personnel possessing authoritative oversight of network operations.
- **Disorientation:** The sudden transition to remote work created communication fragmentation, making it difficult for employees to verify whether an IT caller was genuine.

Crucially, the NY DFS report highlighted systemic organizational failings: Twitter lacked a permanent Chief Information Security Officer (CISO) at the time, allowed excessive numbers of employees (over 1,000 contractors and staff) access to sensitive administrative account tools, failed to enforce granular least-privilege segmentation, and did not require multi-party approval or re-authentication before modifying critical verified accounts [5].

---

### 4.3 Three Pretexting Prevention Measures

Organizations must implement rigorous controls to defeat deceptive narratives:

1. **Independent Out-of-Band Identity Verification:**
   Employees must never verify a caller’s identity using phone numbers, email addresses, or web links provided directly by the requester. Instead, organizations must mandate an out-of-band callback protocol: the employee hangs up, locates the official contact in the published internal company directory, and calls back via verified internal communication channels (e.g., enterprise VoIP directory or corporate Slack/Teams with verified profile tags) [1], [5].

2. **Strict Help-Desk Verification Standards for High-Risk Actions:**
   Help-desk personnel must follow unbendable verification protocols before executing password resets, MFA device re-enrollments, or granting remote access permissions. High-risk requests should require a visual identity check via company video conference, approval from the employee's direct manager, or a cryptographically signed verification ticket [5].

3. **Least Privilege, Role-Based Access Control, and Dual Authorization:**
   Internal tools that can modify customer accounts, alter billing details, or reassign credentials must be strictly segmented. Access must be granted based on the principle of least privilege, and sensitive administrative actions must require **dual authorization (four-eyes principle)**, ensuring that no single compromised account can execute high-impact system changes unilaterally [5].

#### Practical Script: Politely Refusing and Verifying an Unusual Request
When confronted with an unexpected request from someone claiming authority, employees should use a standardized verification script:

> *"Thank you for contacting me. Due to our company's information security verification policy, I cannot provide credentials, session tokens, or system modifications during an inbound call or unverified message. I will document your request, look up your official contact information in our verified corporate directory, and contact you back directly through our internal ticketing portal to complete this process."*

---

## 5. Baiting Attacks

### 5.1 Definition and Forms

Baiting is a social engineering attack in which an adversary entices a victim with the promise of a desirable item, free good, or perceived benefit to lure them into executing a security-compromising action [1], [6]. Baiting leverages powerful psychological drivers: **curiosity**, **greed**, **convenience**, and **altruism** (the desire to help return a lost item) [6].

Baiting operates across two primary physical and digital domains:

```text
                                BAITING ATTACKS
                                       │
            ┌──────────────────────────┴──────────────────────────┐
            ▼                                                     ▼
     PHYSICAL BAITING                                      DIGITAL BAITING
• "Lost" USB Flash Drives in parking lots             • Pirated software / cracked licenses
• Malicious branded promotional swags                 • Fraudulent "free" media downloads
• Weaponized hardware cables (e.g. O.MG cables)        • Trojanized system updates / PDF guides
```

- **Physical Baiting:**
  An adversary leaves malware-infected physical media (such as USB thumb drives, external hard drives, or CD/DVDs) in locations where employees will naturally encounter them—corporate parking lots, office lobbies, cafeterias, smoking areas, or executive restrooms [6]. To increase intrigue, attackers often affix enticing labels to the drives, such as *"Executive Salaries 2026,"* *"Confidential Layoff Plan,"* *"Q4 Bonus Matrix,"* or an official company logo. When an inquisitive employee plugs the device into an internal network computer, the media executes malicious payloads, runs keyloggers, or deploys hardware emulation attacks (e.g., USB Rubber Ducky keystroke injection).

- **Digital Baiting:**
  Adversaries place deceptive lures on public internet channels, search engines, or peer-to-peer networks. Examples include pirated commercial software ("cracked" software licenses), unreleased movie or music files, free PDF whitepapers on high-interest topics, or bogus browser updates. When users download and open these files, they inadvertently execute trojanized installers that compromise their endpoints.

---

### 5.2 Documented Case Study: 2016 IEEE Empirical USB Study (Tischer et al.)

#### Study Identification and Methodological Context
To rigorously evaluate whether real-world humans actually plug in unknown USB drives, a team of cybersecurity researchers from the University of Illinois Urbana-Champaign, the University of Michigan, and Google (Matthew Tischer, Zakir Durumeric, Sam Foster, Sunny Duan, Alec Mori, Elie Bursztein, and Michael Bailey) conducted a controlled, ethical empirical research study [6]. The findings were peer-reviewed and published at the prestigious **2016 IEEE Symposium on Security and Privacy (S&P)** in their paper titled *"Users Really Do Plug in USB Drives They Find"* [6].

*Note: This controlled academic study is deliberately analyzed here rather than unverified internet folklore, providing rigorous, peer-reviewed data on physical baiting behavior.*

```text
[297 Benign USB Drives Dropped on Campus]
                   │
                   ▼
     [45% - 98% Connected to Computers]
                   │
                   ├─> First drive connected in < 6 MINUTES
                   ├─> 68% of users cited ALTRUISM (finding owner)
                   └─> Yet users opened PERSONAL PHOTOS first (CURIOSITY)
```

#### Experimental Setup and Empirical Findings
The researchers dropped **297 functional USB flash drives** across various indoor and outdoor locations on the University of Illinois Urbana-Champaign campus [6]. The drives were loaded exclusively with benign HTML files embedded with image web beacons that notified the research servers when an HTML file was rendered in a browser. Crucially, the experiment contained no malicious payloads or exploits.

The study produced alarming findings regarding human physical security hygiene:
1. **Extremely High Engagement Rate:** Between **45% and 98%** of the dropped USB drives were plugged into an internet-connected computer [6]. Across all locations, at least 48% of the dropped drives not only were plugged in but also had files executed by users.
2. **Speed of Execution:** The attack vector operated with alarming speed; the first dropped USB drive was inserted into an active workstation and opened within **less than six minutes** of being placed on the ground [6]. The median time to first connection was under seven hours.
3. **Altruism vs. Curiosity (The Behavioral Paradox):** The researchers surveyed participants who opened the files to understand their motivations. A commanding **68% of users stated their primary motivation was altruistic**—they claimed they plugged in the drive specifically to locate contact information and return the lost property to its rightful owner [6]. However, the researchers' server logs revealed a stark behavioral paradox: despite altruistic intentions, **curiosity dominated user actions.** Users consistently clicked on enticing personal folders (e.g., `"Summer Vacation Photos"`, `"Winter Break Pics"`) before opening documents labeled with contact information (e.g., `"Resume.pdf"`).
4. **Demographic Reach:** The individuals who plugged in the drives were not merely naive or non-technical individuals; participants spanned engineering students, administrative staff, and general university faculty.

#### Comparison to Real-World Cybercrime
While the 2016 IEEE study demonstrated human behavioral vulnerability in a safe, controlled setting, threat actors actively exploit this exact vector in criminal campaigns. For instance, the financially motivated cybercrime syndicate **FIN7 (Carbanak)** mailed malicious USB drives disguised as promotional packages from Amazon or the U.S. Department of Health and Human Services to targets in the financial, hospitality, and defense sectors. These devices functioned as programmable Human Interface Device (HID) hardware emulators that injected malicious PowerShell commands upon connection [6].

---

### 5.3 Three Baiting Prevention Measures

Defending against baiting requires both technical lockdown and procedural hygiene:

1. **Strict Prohibition on Unauthorized Removable Media:**
   Organizational security policies must strictly prohibit connecting any personal, found, or unapproved external storage media to corporate endpoints. Employees must be trained that an unknown USB drive is fundamentally indistinguishable from a malicious hardware payload [1], [6].

2. **Technical Endpoint Controls & Port Restrictions:**
   Organizations must implement technical controls through Endpoint Detection and Response (EDR) software or Mobile Device Management (MDM) solutions. Policies should disable USB mass storage by default, whitelist only encrypted corporate-issued hardware with verified hardware serial numbers, or physically disable USB data lanes on critical workstations using physical port blockers [2], [6].

3. **Software Whitelisting and Restricting Unapproved Downloads:**
   To counter digital baiting, network firewalls and endpoint agents should enforce application allowlisting (AppLocker, Windows Defender Application Control). Employees must be prevented from executing unapproved software installers, torrent clients, or unverified executable files downloaded from the public internet.

#### Safe Reporting Procedure for Suspicious Physical Media
If an employee locates an unknown USB drive, hard drive, or charging cable on corporate premises, they must:
- **Never insert the device into any computer** (neither work workstations nor personal laptops).
- Immediately place the physical item into a secure container or envelope.
- Deliver the item to the Corporate Security / Physical Facilities or IT Security desk with exact notes detailing the time and physical location where it was discovered.

---

## 6. Bonus Topic: Quid Pro Quo Attacks

### 6.1 Definition and Mechanism

*Quid Pro Quo* (a Latin phrase meaning "something for something") is a social engineering attack in which an adversary promises an explicit service, professional benefit, or direct assistance in exchange for the victim's sensitive information, credentials, or compliance [3].

Unlike baiting, which generally relies on the passive allure of an enticing object, free download, or monetary windfall, **quid pro quo involves an active, negotiated exchange of services** [3]:

```text
                      BAITING vs. QUID PRO QUO
┌─────────────────────────────────┬─────────────────────────────────┐
│        BAITING (Passive)        │      QUID PRO QUO (Active)      │
├─────────────────────────────────┼─────────────────────────────────┤
│ Attacker leaves a lure (USB,    │ Attacker approaches victim and  │
│ free cracked software, free     │ offers an immediate service or  │
│ movie download).                │ assistance ("I will fix your    │
│                                 │ computer if you give me your    │
│                                 │ password").                     │
│ Psychological trigger:          │ Psychological trigger:          │
│ Curiosity, greed, or altruism.  │ Reciprocity, relief, and        │
│                                 │ gratitude for perceived help.   │
└─────────────────────────────────┴─────────────────────────────────┘
```

### 6.2 Illustrative Example

An attacker identifies an enterprise undergoing a widely publicized software migration (e.g., migrating from an on-premise email server to Microsoft 365). The attacker repeatedly dials phone numbers across corporate office extensions until reaching an employee who is currently experiencing technical frustration with their computer. 

The attacker states:
> *"Hello, this is Kevin from the Corporate Desktop Support Team. We noticed an active sync error on your mail client resulting from this morning's patch cycle. I can clear the cache and resolve the freezing for you right now, but I need you to confirm your current domain password and read me the 6-digit confirmation code on your mobile device so I can authenticate the background service."*

Relieved that IT reached out proactively to resolve an annoying operational problem, the grateful employee provides their credentials and MFA passcode, allowing the attacker to establish persistent administrative access.

### 6.3 Prevention Measures

1. **Standardized Support Workflows:** Organizations must mandate that IT support only initiates remote administrative sessions in response to an existing, verifiable employee-generated support ticket. Unsolicited inbound calls from "tech support" offering impromptu fixes must be treated with immediate skepticism [1].
2. **Absolute Prohibition on Disclosing Credentials:** Clear corporate policy must establish that legitimate IT personnel possess administrative mechanisms to reset systems and will **never** ask an employee for their raw password or one-time MFA codes [2].
3. **Mandatory Callback Verification:** Employees must be instructed to verify any unexpected IT outreach by terminating the call and calling the official Help Desk extension listed on the corporate intranet.

---

## 7. Comprehensive Social Engineering Comparison Table

The following matrix compares the core social engineering vectors analyzed throughout this report:

| Attack Type | Primary Target | Psychological Lever Exploited | Best Countermeasure |
|---|---|---|---|
| **Phishing** | Broad, untargeted employee populations and consumers | Urgency, fear, anxiety, routine habit | Automated email gateway filtering (SPF/DKIM/DMARC) and user awareness training [1], [2] |
| **Spear Phishing** | Specific individual, project team, or corporate department | Familiarity, professional duty, contextual trust | Domain verification, email link sandboxing, and out-of-band communication checks [1], [7] |
| **Whaling** | High-level corporate executives (CEOs, CFOs, Board members) | Legal intimidation, fear of severe consequence, authority | Strict executive approval policies, dual-authorization for finances, executive-tailored training [1] |
| **Vishing** | Employees with phone access (call centers, remote workers) | Perceived technical authority, urgency, helpfulness | Out-of-band directory callbacks, formal employee verification questions [1], [5] |
| **Smishing** | Mobile device users and mobile workforce | Convenience, impulsive curiosity, immediate deadlines | Never clicking SMS links, using mobile threat defense, verifying directly via official web apps [1] |
| **Pretexting** | Specific employees holding sensitive data or access | Fabricated authority, professional empathy, social compliance | Multi-tier identity verification policies, least privilege, and four-eyes authorization [3], [5] |
| **Physical Baiting** | On-site corporate personnel and physical office visitors | Curiosity, greed, desire for free goods, altruism | Strict ban on unknown media, disabling USB mass storage via EDR, physical port locks [6] |
| **Digital Baiting** | Internet users seeking software, entertainment, or guides | Greed, desire for free resources, convenience | Application allowlisting, web filtering, downloading solely from authenticated repositories [1], [6] |
| **Quid Pro Quo** | Frustrated or busy employees seeking technical assistance | Reciprocity, relief, gratitude for assistance | Mandatory IT ticketing workflows, strict prohibition on sharing passwords/MFA tokens [3] |

---

## 8. Five-Point Employee Security Awareness Checklist

Every employee serves as a frontline sensor in an organization's defensive posture. The following five-point checklist defines concrete behavioral standards for daily operations:

```text
   ┌─────────────────────────────────────────────────────────────┐
   │        5-POINT EMPLOYEE SECURITY AWARENESS CHECKLIST        │
   ├─────────────────────────────────────────────────────────────┤
   │  [1] RECOGNIZE  ──> Identify anomalies, urgency, & links    │
   │  [2] VERIFY     ──> Confirm requests via trusted channels   │
   │  [3] PROTECT    ──> Never share passwords or MFA codes      │
   │  [4] REPORT     ──> Report suspicious activity immediately  │
   │  [5] PRACTICE   ──> Engage positively in drills & training  │
   └─────────────────────────────────────────────────────────────┘
```

1. **Recognize:** Carefully evaluate incoming communications for artificial urgency, unexpected attachments, mismatched sender domain names, unusual wire transfer requests, or unsolicited offers of technical assistance.  
   *Expected Employee Behavior:* Pause and inspect email headers and hyperlinked URLs before clicking, treating unsolicited urgency with heightened scrutiny.

2. **Verify:** Independently validate any unusual request involving passwords, financial disbursements, confidential data, or system configuration changes through an official, established contact channel.  
   *Expected Employee Behavior:* Disconnect from the incoming interaction and contact the supposed requester using an independently verified phone number or internal directory listing.

3. **Protect:** Safeguard all credentials, cryptographic hardware keys, and authentication tokens as confidential assets.  
   *Expected Employee Behavior:* Never share passwords, PINs, or one-time MFA codes with anyone—including individuals claiming to represent internal IT, management, or executive leadership.

4. **Report:** Promptly forward suspicious communications, misplaced removable media, or anomalous requests to the internal security operations team through official reporting buttons.  
   *Expected Employee Behavior:* Immediately notify the security team without fear of disciplinary reprisal, understanding that reporting potential mistakes early allows the organization to contain threats before data loss occurs.

5. **Practice and Improve:** Actively participate in authorized security awareness training modules and simulated phishing exercises to hone threat identification skills.  
   *Expected Employee Behavior:* View simulated phishing exercises not as punitive tests, but as continuous educational opportunities to build individual and organizational resilience.

---

## 9. Organizational Recommendations

While human vigilance is essential, an organization cannot rely exclusively on individual caution. A mature cybersecurity posture demands an institutional defense-in-depth framework that minimizes the blast radius when an individual inevitable makes an error [2], [5]:

- **Enforce the Principle of Least Privilege and Role-Based Access Control (RBAC):** Restrict user and service account privileges strictly to what is required for core job functions. Segment administrative access so that compromising a standard employee account does not yield administrative domain dominance [5].
- **Mandate Phishing-Resistant Multi-Factor Authentication (MFA):** Phase out legacy SMS and basic mobile push-based MFA in favor of FIDO2 / WebAuthn cryptographic hardware security keys (e.g., YubiKeys) for all internal portals, remote access VPNs, and administrative consoles [2].
- **Implement Robust Perimeter & Protocol Validations:** Deploy and rigorously enforce SPF, DKIM, and DMARC policies (`p=reject`) to prevent spoofing of the organization's domain name, coupled with advanced email sandboxing to analyze dynamic attachments and embedded URLs before delivery [2].
- **Standardize Secure Verification Protocols for Help Desks:** Formally restrict Help Desk staff from resetting passwords, changing MFA tokens, or establishing remote access without cryptographic, manager-approved, or in-person verification protocols [5].
- **Foster a Supportive, Blame-Free Reporting Culture:** Organizations that punish employees for reporting accidental clicks create an environment of fear where compromises go hidden for months. Organizations must celebrate and reward rapid reporting, treating reporting employees as active defense assets [1].
- **Conduct Regular Incident Response Drills & Session Revocation Testing:** Maintain tested incident response playbooks that include automated capabilities to immediately invalidate active web application session tokens, terminate anomalous OAuth credentials, and isolate compromised endpoints across the entire enterprise [2].

---

## 10. Conclusion: Three Key Takeaways

1. **Social Engineering Exploits Human Nature, Not Software Flaws:** Adversaries recognize that manipulating human heuristics—trust, urgency, authority, curiosity, and reciprocity—is consistently cheaper and faster than circumventing modern encryption or firewalls.
2. **Layered Defense Beats Single Solutions:** Neither employee training nor technical perimeter tools can succeed in isolation; true resilience requires combining phishing-resistant authentication (FIDO2), least-privilege segmentation, strict verification protocols, and continuous education.
3. **Speed of Reporting Determines Impact:** A successful cyberattack is not defined by whether an employee clicks a link, but by how quickly the incident is reported, triaged, and contained through automated response and a supportive, blame-free security culture.

---

## 11. References

[1] Cybersecurity and Infrastructure Security Agency (CISA). (2021). *Avoiding Social Engineering and Phishing Attacks* (Security Tip ST04-014). U.S. Department of Homeland Security.  
Available: `https://www.cisa.gov/news-events/news/avoiding-social-engineering-and-phishing-attacks` (Accessed: Oct. 29, 2026).

[2] Cybersecurity and Infrastructure Security Agency (CISA), National Security Agency (NSA), Federal Bureau of Investigation (FBI), and Multi-State Information Sharing and Analysis Center (MS-ISAC). (2023). *Phishing Guidance: Stopping the Attack Cycle at Phase One*. Joint Cybersecurity Advisory.  
Available: `https://www.cisa.gov/resources-tools/resources/phishing-guidance-stopping-attack-cycle-phase-one` (Accessed: Oct. 29, 2026).

[3] D. Gragg. (2002). *A Multi-Level Defense Against Social Engineering*. SANS Institute Information Security Reading Room.  
Available: `https://www.sans.org/white-papers/520/` (Accessed: Oct. 29, 2026).

[4] U. Rivner. (2011). *Anatomy of an Attack: How RSA Was Compromised*. Dark Reading (InformationWeek).  
Available: `https://www.darkreading.com/attacks-breaches/anatomy-of-an-attack-how-rsa-was-compromised` (Accessed: Oct. 29, 2026).

[5] L. A. Lacewell. (2020). *Report on Investigation of Twitter’s July 15, 2020, Cybersecurity Incident and the Implications for Election Security*. New York State Department of Financial Services (NY DFS).  
Available: `https://www.dfs.ny.gov/Twitter_Report` (Accessed: Oct. 29, 2026).

[6] M. Tischer, Z. Durumeric, S. Foster, S. Duan, A. Mori, E. Bursztein, and M. Bailey. (2016). *Users Really Do Plug in USB Drives They Find*. In Proceedings of the 2016 IEEE Symposium on Security and Privacy (S&P), San Jose, CA, pp. 306-319. IEEE. DOI: 10.1109/SP.2016.26.  
Available: `https://www.elie.net/publication/users-really-do-plug-in-usb-drives-they-find/` (Accessed: Oct. 29, 2026).

[7] MITRE Corporation. (2024). *Technique T1566: Phishing*. MITRE ATT&CK® Enterprise Matrix.  
Available: `https://attack.mitre.org/techniques/T1566/` (Accessed: Oct. 29, 2026).

[8] Verizon. (2024). *2024 Data Breach Investigations Report (DBIR)*. Verizon Business Security Research.  
Available: `https://www.verizon.com/business/resources/reports/dbir/` (Accessed: Oct. 29, 2026).
