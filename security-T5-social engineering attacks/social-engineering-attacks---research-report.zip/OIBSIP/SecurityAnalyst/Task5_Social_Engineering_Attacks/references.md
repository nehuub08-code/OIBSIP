# Supplementary Bibliography & Source Analysis Notes
## OIBSIP Security Analyst Track — Task 5: Social Engineering Attacks

This document provides supplementary bibliographic documentation, methodological evaluation notes, and source mapping for the research report: **"Social Engineering Attacks: Types, Real-World Cases, and Prevention"** (`social_engineering_report.md`).

---

### Numbered Source Catalog

#### [1] Cybersecurity and Infrastructure Security Agency (CISA)
- **Title:** Avoiding Social Engineering and Phishing Attacks (Security Tip ST04-014)
- **Authoring Organization:** Cybersecurity and Infrastructure Security Agency (CISA), U.S. Department of Homeland Security
- **Publication / Revision Date:** Revised August 2021 (Originally published 2009)
- **Direct URL:** https://www.cisa.gov/news-events/news/avoiding-social-engineering-and-phishing-attacks
- **Access Date:** October 29, 2026
- **Source Type:** Official Government Cybersecurity Advisory / Guidance
- **Key Evidence Supported:**
  - Standard baseline definitions of social engineering, phishing, smishing, and vishing.
  - Psychological triggers exploited: artificial urgency, fear of penalty, appeal to authority, and casual helpfulness.
  - Baseline technical and procedural indicators of suspicious electronic communications.
  - Core defensive protocols: independent identity verification via published contact channels, multi-factor authentication (MFA), and immediate incident reporting.
- **Verification Status:** Verified via official `cisa.gov` technical repository.

---

#### [2] CISA, NSA, FBI, and MS-ISAC Joint Cybersecurity Advisory
- **Title:** Phishing Guidance: Stopping the Attack Cycle at Phase One
- **Authoring Organizations:** Cybersecurity and Infrastructure Security Agency (CISA), National Security Agency (NSA), Federal Bureau of Investigation (FBI), and Multi-State Information Sharing and Analysis Center (MS-ISAC)
- **Publication Date:** March 2023
- **Direct URL:** https://www.cisa.gov/resources-tools/resources/phishing-guidance-stopping-attack-cycle-phase-one
- **Access Date:** October 29, 2026
- **Source Type:** Multi-Agency Joint Technical Guidance
- **Key Evidence Supported:**
  - Technical categorization of phishing defenses into email domain validation (SPF, DKIM, DMARC).
  - Phishing-resistant multi-factor authentication requirements (FIDO2 / WebAuthn cryptographic tokens over SMS/push notifications).
  - Endpoint protection rules, URL inspection sandboxes, and defensive architectures to break the initial access stage of threat actors.
- **Verification Status:** Verified via official `cisa.gov` technical publications library.

---

#### [3] SANS Institute Information Security Reading Room
- **Title:** A Multi-Level Defense Against Social Engineering
- **Author:** David Gragg
- **Authoring Organization:** SANS Institute
- **Publication Date:** December 2002
- **Direct URL:** https://www.sans.org/white-papers/520/
- **Access Date:** October 29, 2026
- **Source Type:** Peer-Reviewed Academic & Industry Security Research Paper
- **Key Evidence Supported:**
  - Foundational psychological model of social engineering: deceptive authority, social compliance, conformity, curiosity, and reciprocity.
  - Multi-tier defensive model integrating organizational policy, continuous human awareness training, and systemic "social engineering tripwires/landmines" (operational checkpoints).
  - Distinctions between technical exploits and human manipulation vulnerabilities.
- **Verification Status:** Verified through SANS Information Security Reading Room repository.

---

#### [4] Dark Reading & RSA Threat Analysis
- **Title:** Anatomy of an Attack: How RSA Was Compromised
- **Author:** Uri Rivner (Director of New Technologies at RSA) / Dark Reading Security Analysis
- **Publication Date:** April 1, 2011
- **Direct URL:** https://www.darkreading.com/attacks-breaches/anatomy-of-an-attack-how-rsa-was-compromised
- **Access Date:** October 29, 2026
- **Source Type:** First-Party Forensic Disclosure & Technical Security Journalism
- **Key Evidence Supported:**
  - Case study details on the March 2011 RSA SecurID APT compromise.
  - Phishing vector: Two small-batch targeted emails titled `"2011 Recruitment plan"` sent to lower-level non-executive employees; attachment named `2011 Recruitment plan.xls`.
  - Exploit mechanism: Embedded Adobe Flash zero-day exploit (`CVE-2011-0609`) within Microsoft Excel triggering a Poison Ivy Remote Access Trojan (RAT).
  - Lateral movement: Privilege escalation, internal reconnaissance, and exfiltration of sensitive SecurID two-factor authentication seed algorithms and architectural data.
- **Verification Status:** Verified via Dark Reading archives and corresponding EMC/RSA corporate disclosures.

---

#### [5] New York State Department of Financial Services (NY DFS)
- **Title:** Report on Investigation of Twitter’s July 15, 2020, Cybersecurity Incident and the Implications for Election Security
- **Author / Investigator:** Linda A. Lacewell, Superintendent of Financial Services
- **Authoring Body:** New York State Department of Financial Services
- **Publication Date:** October 14, 2020
- **Direct URL:** https://www.dfs.ny.gov/Twitter_Report
- **Access Date:** October 29, 2026
- **Source Type:** Official Government Regulatory Forensic Investigation
- **Key Evidence Supported:**
  - Pretexting / vishing case study details on the July 15, 2020 Twitter breach.
  - Attack mechanism: Attackers called employees posing as Twitter IT Helpdesk staff assisting with remote-work VPN issues, redirected staff to a credential-harvesting phishing website, and intercepted multi-factor authentication codes in real time.
  - Access abuse: Attackers gained access to internal customer support administrative tools, compromised 130 high-profile verified accounts (e.g., Barack Obama, Joe Biden, Elon Musk, Apple), and carried out a double-your-crypto Bitcoin scam.
  - Systemic findings: Lack of a permanent CISO, broad administrative privileges without MFA re-prompting or dual authorization, and inadequate real-time monitoring of support tooling.
- **Verification Status:** Verified through NY DFS official government publication server.

---

#### [6] IEEE Symposium on Security and Privacy (S&P)
- **Title:** Users Really Do Plug in USB Drives They Find
- **Authors:** Matthew Tischer, Zakir Durumeric, Sam Foster, Sunny Duan, Alec Mori, Elie Bursztein, and Michael Bailey
- **Publication Date:** May 2016 (Proceedings of the 2016 IEEE Symposium on Security and Privacy, San Jose, CA, pp. 306-319)
- **DOI:** 10.1109/SP.2016.26
- **Direct URL:** https://www.elie.net/publication/users-really-do-plug-in-usb-drives-they-find/
- **Access Date:** October 29, 2026
- **Source Type:** Peer-Reviewed Empirical Scientific Study
- **Key Evidence Supported:**
  - Empirical case study on physical baiting: 297 USB flash drives were dropped across university campus locations.
  - Finding: Between 45% and 98% of dropped drives were plugged in and connected to internet-enabled machines; the first drive was connected within six minutes of drop.
  - Human psychology: 68% of users stated altruistic motivations (finding the owner's identity), yet user behavior demonstrated curiosity (opening personal photo folders before business contact files).
  - Demonstrates that human intuition often overrides theoretical security awareness training unless enforced by technical endpoint controls.
- **Verification Status:** Verified via IEEE Xplore digital library and Elie Bursztein's research publication archive.

---

#### [7] MITRE ATT&CK® Enterprise Matrix
- **Title:** Technique T1566: Phishing & Technique T1598: Phishing for Information
- **Authoring Organization:** The MITRE Corporation
- **Publication / Revision Date:** 2024
- **Direct URL:** https://attack.mitre.org/techniques/T1566/
- **Access Date:** October 29, 2026
- **Source Type:** Industry Standard Adversarial Tactics, Techniques, and Common Knowledge Repository
- **Key Evidence Supported:**
  - Technical categorization of sub-techniques: T1566.001 (Spearphishing Attachment), T1566.002 (Spearphishing Link), and T1566.003 (Spearphishing via Service).
  - Adversary methods for bypassing email security gateways and credential theft mechanisms.
- **Verification Status:** Verified via MITRE ATT&CK official knowledge base.

---

#### [8] Verizon Business
- **Title:** 2024 Data Breach Investigations Report (DBIR)
- **Authoring Organization:** Verizon Business Security Research Team
- **Publication Date:** April 2024
- **Direct URL:** https://www.verizon.com/business/resources/reports/dbir/
- **Access Date:** October 29, 2026
- **Source Type:** Quantitative Global Industry Threat Intelligence Report
- **Key Evidence Supported:**
  - Analysis of human factors in corporate breaches: 68% of confirmed breaches analyzed involved a non-malicious human element (such as falling for phishing or pretexting, or committing errors).
  - Quantifies pretexting and phishing as primary initial attack paths for financial fraud, ransomware staging, and business email compromise.
- **Verification Status:** Verified via Verizon DBIR publication series.

---

### Source Quality & Fact-Checking Methodology

1. **Origin Verification:** Each citation was cross-referenced against primary disclosures (government regulatory investigations, IEEE peer-reviewed proceedings, official vendor disclosures, and CISA advisories).
2. **Exclusion of Speculative Claims:** Unsubstantiated claims (such as attributing every modern data breach to social engineering or generalizing university USB findings as universal enterprise statistics) have been deliberately excluded or contextualized.
3. **URL Integrity:** All URLs link directly to primary documents, permanent digital object identifiers (DOIs), or established institutional directories.
