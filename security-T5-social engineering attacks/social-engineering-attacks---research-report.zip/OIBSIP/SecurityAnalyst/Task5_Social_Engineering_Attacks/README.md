# Research Report: Social Engineering Attacks — Types, Real-World Cases, and Prevention
## Oasis Infobyte Internship Program (OIBSIP) — Security Analyst Track

**Task:** Task 5 — Research Report: Social Engineering Attacks  
**Author / Intern:** [Your Name]  
**Date:** October 29, 2026  
**Primary Deliverable:** `social_engineering_report.md`  

---

## 1. Project Overview

This repository subproject contains the comprehensive research report and supporting analytical documentation for **OIBSIP Security Analyst Task 5: Social Engineering Attacks**. 

Social engineering represents one of the most persistent and devastating threat vectors in cybersecurity. Rather than attacking cryptographic algorithms or hardened firewalls, social engineering attacks exploit the cognitive biases, emotional vulnerabilities, and social heuristics of authorized human operators. This project delivers an in-depth, cited investigation into the mechanics of social engineering, analyzing real-world historical compromises (including the 2011 RSA SecurID APT attack and the July 2020 Twitter administrative breach), an empirical academic study on USB baiting, attack taxonomies, and multi-layered defense-in-depth countermeasures.

---

## 2. Research Objectives

1. **Deconstruct the Social Engineering Lifecycle:** Analyze how adversaries leverage psychological levers (urgency, authority, fear, curiosity, greed, helpfulness) to circumvent technical security perimeters.
2. **Examine Attack Modalities:** Categorize and compare distinct social engineering disciplines, including Phishing (Spear Phishing, Whaling, Vishing, Smishing), Pretexting, Physical and Digital Baiting, and Quid Pro Quo.
3. **Forensic Real-World Case Studies:** Conduct rigorous, fact-checked analyses of documented real-world security incidents and empirical research studies to identify root vulnerabilities and operational fallout.
4. **Formulate Actionable Countermeasures:** Develop concrete defensive frameworks encompassing technical protections (FIDO2 phishing-resistant MFA, DMARC, endpoint control), procedural verification standards, and a supportive 5-point employee awareness checklist.

---

## 3. Topics Covered

- **Theoretical Foundations:** Social engineering versus technical exploitation; cognitive heuristics exploited; empirical breach statistics (Verizon DBIR 2024 analysis).
- **Phishing Vectors:** Comprehensive 5-stage lifecycle; detailed breakdowns of Spear Phishing, Whaling, Vishing, and Smishing with illustrative educational scenarios; attacker vs. victim perspectives.
- **Pretexting Mechanics:** Five-step pretexting methodology; telephone-based social engineering and credential harvesting.
- **Baiting Disciplines:** Physical media drops vs. digital trojanized downloads; behavioral paradoxes (altruism vs. curiosity).
- **Bonus Topic — Quid Pro Quo:** Mechanics, active reciprocal manipulation vs. passive baiting, and IT support verification workflows.
- **Incident Deep-Dives:**
  - *2011 RSA SecurID Attack:* Spear-phishing spreadsheet (`2011 Recruitment plan.xls`), Adobe Flash zero-day (`CVE-2011-0609`), Poison Ivy RAT, and exfiltration of SecurID two-factor authentication seed algorithms.
  - *July 2020 Twitter Incident:* Telephone pretexting (vishing) impersonating IT helpdesk, fraudulent VPN portals, real-time MFA interception, and administrative privilege abuse across 130 verified accounts (NY DFS investigation).
  - *2016 IEEE S&P USB Empirical Study (Tischer et al.):* Controlled university campus study analyzing 297 dropped USB flash drives, 45%–98% interaction rates, and behavioral motivations.
- **Defensive Strategies:** Comprehensive 9-row comparison matrix, 5-point employee awareness checklist, and institutional enterprise recommendations.

---

## 4. Key Learning Outcomes

Through completing this technical research report, the following core cybersecurity competencies were developed:
- Understanding human-centric adversarial tactics and cognitive vulnerabilities in enterprise environments.
- Ability to conduct structured, evidence-based threat research using official primary sources (CISA, NY DFS, SANS Reading Room, IEEE, MITRE ATT&CK).
- Designing balanced defense-in-depth architectures combining cryptographic technical controls (FIDO2) with procedural verifications (out-of-band callbacks, dual authorization).
- Writing professional, technical documentation suitable for an industry security analyst portfolio.

---

## 5. Project Structure

```text
OIBSIP/
└── SecurityAnalyst/
    └── Task5_Social_Engineering_Attacks/
        ├── README.md                      # Project overview, methodology, and learning outcomes
        ├── social_engineering_report.md   # Primary comprehensive research report (11 sections)
        ├── references.md                  # Annotated bibliography and source evaluation notes
        └── .gitignore                     # Repository hygiene exclusions
```

---

## 6. Research Methodology & Source-Quality Criteria

All claims, case study details, and technical descriptions in this report were developed following strict cybersecurity research standards:
- **Primary & Official Sources First:** Prioritized official government advisories (CISA), formal regulatory forensic investigations (New York State Department of Financial Services), peer-reviewed IEEE publications, and first-party vendor incident disclosures.
- **Zero Fabrication Policy:** All statistics, incident mechanics, and software vulnerability identifiers (`CVE-2011-0609`) were strictly fact-checked against primary sources; no synthetic data, unverified rumors, or fictional citations were utilized.
- **Distinction Between Research and Active Testing:** Clearly separated controlled empirical experiments (such as the 2016 UIUC study) from confirmed real-world cybercriminal attacks (such as the FIN7 USB campaign).
- **Numbered In-Text Citations:** Every key technical and historical claim is mapped to an authoritative entry in the references catalog using standard Markdown brackets (e.g., `[1]`, `[5]`).

---

## 7. How to Read or Preview the Markdown Report

You can review the deliverables using several methods:

1. **Interactive Web Dashboard (Included in this Applet):**  
   The web application running in this environment provides a dedicated interactive viewer with active table of contents navigation, search filtering, comparison table matrix, case study breakdowns, and one-click Markdown copy and download tools.
2. **Local Markdown Viewer / GitHub Preview:**  
   Open `social_engineering_report.md` in any Markdown-compatible viewer (e.g., Visual Studio Code with Markdown Preview `Ctrl+Shift+V` / `Cmd+Shift+V`, Obsidian, or directly on GitHub).
3. **Command-Line Terminal:**  
   Inspect the raw text using terminal pagers:
   ```bash
   cat OIBSIP/SecurityAnalyst/Task5_Social_Engineering_Attacks/social_engineering_report.md
   ```

---

## 8. Responsible Research Statement & Limitations

- **Nature of Work:** This submission is strictly an academic and professional cybersecurity research report. No active penetration testing, unauthorized social engineering campaigns, unauthorized network scanning, or live exploitation was conducted against any real-world organization, system, or individual.
- **Defensive Focus:** All descriptions of adversarial tactics, lookalike domains, and phishing mechanics are provided exclusively for defensive, educational, and risk-mitigation purposes in accordance with responsible disclosure principles.
- **Demo Video Requirement:** As specified in the OIBSIP task guidelines, a video demonstration is not required for Task 5; the primary deliverable is the written, fact-checked report (`social_engineering_report.md`).
