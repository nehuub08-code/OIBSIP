# Annotated References and Source Documentation

**Project:** Common Network Security Threats: Attack Mechanisms, Real-World Impact, and Mitigation Strategies  
**Organization:** Oasis Infobyte (OIBSIP)  
**Track:** Security Analyst  
**Task:** Task 4 — Research Report  
**Author:** Sakshi Borkar  

This document serves as supporting bibliographic documentation for the primary research deliverable: `network_security_threats_report.md`. All sources comply with research integrity standards, prioritizing authoritative government agencies, internet standards bodies (IETF), academic journals, and first-party vendor incident disclosures.

---

## Authoritative Reference List

### [1] Internet Protocol Architecture Security Foundations
* **Organization / Authors:** C. E. Perkins and J. T. Stewart
* **Title:** Security in the Internet Protocol Architecture
* **Publication:** *IEEE Communications Magazine*, vol. 48, no. 7, pp. 44–51
* **Publication Date:** July 2010
* **URL:** https://doi.org/10.1109/MCOM.2010.5496877
* **Specific Claims Supported:** Analyzes the foundational design assumptions of the original ARPANET / TCP/IP suite, explaining why legacy protocols lacked native cryptographic authenticity, confidentiality, and source address verification.

### [2] Incident Response and Defensive Handling Framework
* **Organization:** National Institute of Standards and Technology (NIST)
* **Authors:** Computer Security Division, Information Technology Laboratory
* **Title:** Computer Security Incident Handling Guide (Special Publication 800-61 Revision 2)
* **Publication Date:** August 2012
* **URL:** https://csrc.nist.gov/publications/detail/sp/800-61/rev-2/final
* **Specific Claims Supported:** Provides the 7-step incident response lifecycle (Detection & Validation, Scoping, Containment, Evidence Preservation, Eradication & Restoration, Notification, and Post-Incident Hardening) and defense-in-depth methodologies.

### [3] Dyn DNS DDoS Incident Postmortem
* **Organization:** Cloudflare
* **Author:** Matthew Caulfield
* **Title:** How the Dyn outage affected Cloudflare
* **Publication Date:** October 21, 2016
* **URL:** https://blog.cloudflare.com/how-the-dyn-outage-affected-cloudflare/
* **Specific Claims Supported:** Documents the real-world impact of the October 2016 Mirai botnet attack on Dyn's Anycast authoritative DNS infrastructure, DNS cascade effects across major platforms (Twitter, Spotify, GitHub), and lessons in single-point-of-failure dependencies.

### [4] Mirai IoT Botnet Threat Advisory
* **Organization:** Cybersecurity and Infrastructure Security Agency (CISA)
* **Title:** Alert (TA16-288A): Heightened DDoS Threat Posed by Mirai and Other Botnets
* **Publication Date:** October 14, 2016
* **URL:** https://www.cisa.gov/news-events/alerts/2016/10/14/heightened-ddos-threat-posed-mirai-and-other-botnets
* **Specific Claims Supported:** Details the automated scanning of default Telnet credentials on consumer IoT devices (DVRs, CCTV cameras), botnet composition, and volumetric DDoS capabilities.

### [5] Adversary-in-the-Middle Framework Technique
* **Organization:** MITRE ATT&CK®
* **Title:** Adversary-in-the-Middle (Technique T1557)
* **Version / Matrix:** Enterprise Matrix, Version 15
* **Publication Date:** April 2024
* **URL:** https://attack.mitre.org/techniques/T1557/
* **Specific Claims Supported:** Technical definition and categorization of MITM/AiTM sub-techniques, including ARP poisoning (T1557.002), DHCP spoofing, SSL/TLS interception, and modern reverse-proxy phishing (Evilginx) bypassing MFA.

### [6] DigiNotar Certificate Authority Intrusion Investigation
* **Organization / Author:** Fox-IT (Commissioned by Dutch Ministry of the Interior) / J. R. Prins
* **Title:** DigiNotar Certificate Authority breach 'Operation Black Tulip' Final Report
* **Publication Date:** December 2011
* **URL:** https://staff.science.uva.nl/b.d.r.m.v.groenewegen/papers/DigiNotar-Black-Tulip-Update.pdf
* **Specific Claims Supported:** Verifies the generation of 530+ fraudulent wildcard certificates including `*.google.com`, the interception of 300,000 Iranian Gmail users, and the subsequent bankruptcy and revocation of DigiNotar's root CA.

### [7] CISA Advisory on DigiNotar CA Compromise
* **Organization:** Cybersecurity and Infrastructure Security Agency (CISA)
* **Title:** Alert (TA11-242A): DigiNotar Certificate Authority Compromise
* **Publication Date:** September 2, 2011
* **URL:** https://www.cisa.gov/news-events/alerts/2011/09/02/diginotar-certificate-authority-compromise
* **Specific Claims Supported:** Confirms official government advisory regarding rogue DigiNotar certificates, advising system administrators on revoking trust and updating root certificate bundles.

### [8] Network Ingress and Egress Filtering Standards
* **Organization:** Internet Engineering Task Force (IETF)
* **Authors:** P. Ferguson and D. Senie
* **Title:** Network Ingress Filtering: Defeating Denial of Service Attacks which employ IP Source Address Spoofing (Best Current Practice 38, RFC 2827)
* **Publication Date:** May 2000
* **URL:** https://www.rfc-editor.org/rfc/rfc2827
* **Specific Claims Supported:** Establishes the technical standard for source address validation (BCP 38), requiring border routers to drop packets whose source IP does not match legitimate customer IP prefixes.

### [9] GitHub Memcached Reflection DDoS Incident Analysis
* **Organization:** GitHub Engineering
* **Author:** Sam Kottler
* **Title:** February 28th DDoS Incident Report
* **Publication Date:** March 1, 2018
* **URL:** https://github.blog/2018-03-01-ddos-incident-report/
* **Specific Claims Supported:** Details the 1.35 Tbps Memcached reflection attack against GitHub, UDP source address spoofing on port 11211, the ~51,000:1 amplification factor, and mitigation via Akamai Prolexic scrubbing.

### [10] CISA Advisory on Memcached Amplification Floods
* **Organization:** Cybersecurity and Infrastructure Security Agency (CISA)
* **Title:** Alert (TA18-067A): Increased Use of Memcached Servers in Reflection Denial of Service Attacks
* **Publication Date:** March 8, 2018
* **URL:** https://www.cisa.gov/news-events/alerts/2018/03/08/increased-use-memcached-servers-reflection-denial-service-attacks
* **Specific Claims Supported:** Verifies that public exposure of unauthenticated Memcached UDP ports allowed weaponized reflection attacks, detailing administrative firewall mitigations.

### [11] DNS Security Architecture Standards (DNSSEC)
* **Organization:** Internet Engineering Task Force (IETF)
* **Authors:** R. Arends, R. Austein, M. Larson, D. Massey, and S. Rose
* **Title:** DNS Security Introduction and Requirements (RFC 4033)
* **Publication Date:** March 2005
* **URL:** https://www.rfc-editor.org/rfc/rfc4033
* **Specific Claims Supported:** Defines the DNSSEC specification, RRSIG digital signatures, DNSKEY cryptographic keys, and Delegation Signer (DS) chains of trust for authenticating DNS responses.

### [12] Dan Kaminsky DNS Cache Poisoning Flaw Presentation
* **Organization / Author:** Black Hat Briefings / Dan Kaminsky
* **Title:** It's The End Of The Cache As We Know It
* **Publication Date:** August 2008
* **URL:** https://www.blackhat.com/presentations/bh-usa-08/Kaminsky/bh-us-08-kaminsky.pdf
* **Specific Claims Supported:** Explains the mechanics of CVE-2008-1447, bypassing TTL constraints using pseudo-random subdomain queries, and injecting rogue authoritative NS records into recursive resolvers.

### [13] US-CERT / CERT Coordination Center Vulnerability Note
* **Organization:** Carnegie Mellon Software Engineering Institute CERT Coordination Center / US-CERT
* **Title:** Vulnerability Note VU#800113: Multiple DNS implementations vulnerable to cache poisoning (CVE-2008-1447)
* **Publication Date:** July 8, 2008
* **URL:** https://www.kb.cert.org/vuls/id/800113
* **Specific Claims Supported:** Documents the coordinated multi-vendor global patch release introducing UDP Source Port Randomization (SPR) and accelerating DNSSEC deployment.
