# Common Network Security Threats: Attack Mechanisms, Real-World Impact, and Mitigation Strategies

**Track:** Security Analyst Internship (OIBSIP)  
**Task:** Task 4 — Research Report  
**Author / Security Analyst:** Sakshi Borkar  
**Focus Area:** Network Security, Threat Intelligence, and Incident Mitigation  
**Date:** October 2026  
**Format:** Academic and Technical Research Report  

---

## Executive Summary

Modern computational ecosystems are defined by ubiquitous interconnectivity, public cloud infrastructures, microservice architectures, and mission-critical web applications. As organizations migrate essential services—spanning financial transactions, healthcare records, governmental administration, and enterprise communications—onto distributed networks, network security has transitioned from an operational support discipline into a foundational requirement for organizational survival. 

This research report provides a rigorous technical analysis of four prevalent and damaging network security threats:
1. **Denial-of-Service (DoS) and Distributed Denial-of-Service (DDoS) Attacks**
2. **Man-in-the-Middle (MITM) / Adversary-in-the-Middle (AiTM) Attacks**
3. **IP Address Spoofing**
4. **Domain Name System (DNS) Cache Poisoning and Spoofing**

For each threat, this report dissects the underlying attack mechanisms, evaluates real-world incidents supported by verified case studies, quantifies financial and operational impacts, details three concrete mitigation strategies with technical depth, establishes monitoring and incident response frameworks, and synthesizes strategic takeaways for network administrators and security analysts.

---

## Introduction

In the contemporary digital landscape, enterprise reliance on public cloud environments, hybrid networks, and global internet connectivity has transformed network security into a mission-critical pillar of societal and economic stability. Everyday commercial transactions, digital payments, automated supply chains, telecommunications, and sensitive personal interactions depend uninterruptedly on the foundational protocols of the Internet Protocol Suite (TCP/IP). However, many of these core protocols—conceived during an era when the ARPANET was a trusted academic research network—were engineered primarily for interoperability, resiliency, and open communication rather than adversarial resilience [1]. Consequently, fundamental properties of the CIA triad—Confidentiality, Integrity, and Availability—are consistently challenged by motivated threat actors ranging from opportunistic script kiddies to sophisticated Advanced Persistent Threat (APT) groups. When network perimeters or transit paths are breached, organizations face catastrophic operational disruption, intellectual property theft, severe regulatory penalties, and lasting reputational erosion. Mitigating these risks necessitates moving beyond perimeter-only defense models toward layered defense-in-depth, continuous network telemetry, automated ingress/egress validation, and cryptographic identity verification [2]. This report examines four foundational threats that exploit weaknesses across the physical, network, transport, and application layers: Denial-of-Service (DoS/DDoS), Man-in-the-Middle (MITM/AiTM), IP Spoofing, and DNS Cache Poisoning.

---

## 1. Denial-of-Service (DoS) and Distributed Denial-of-Service (DDoS) Attacks

### 1.1 Definition
A Denial-of-Service (DoS) attack is a deliberate attempt by an adversary to exhaust the computational, memory, or network resources of a target system, rendering it unavailable to legitimate users [2]. While a basic DoS attack typically originates from a single computer or single IP address, a Distributed Denial-of-Service (DDoS) attack harnesses hundreds, thousands, or millions of geographically distributed compromised devices—collectively known as a **botnet**—to assault the target simultaneously [3]. 

Crucially, from an analytical perspective, network administrators must distinguish malicious DDoS events from benign traffic surges:
* **Benign Traffic Surges ("Flash Crowds"):** Spontaneous spikes caused by major news broadcasts, promotional sales (e.g., Black Friday), or viral media. These obey standard protocol state machines, generate legitimate application requests, and complete standard handshakes.
* **Malicious DDoS Attacks:** Characterized by malformed packets, incomplete protocol handshakes (such as SYN floods without matching ACKs), repetitive non-cacheable URI queries, or amplification reflection loops engineered to exhaust bandwidth or system queues.
* **Infrastructure Failures:** Upstream Border Gateway Protocol (BGP) routing misconfigurations, optical fiber cuts, or internal software deadlocks that induce service unavailability without external malicious packet injection.

### 1.2 How the Attack Works
DDoS attacks operate across different layers of the Open Systems Interconnection (OSI) model, generally classified into three architectural vectors:

1. **Volumetric Attacks (Layer 3 & Layer 4):**
   * *Mechanism:* The adversary's objective is to saturate the physical bandwidth capacity of the victim’s internet transit pipe or intermediate network equipment.
   * *Technique:* Flooding the pipe with massive volumes of traffic using UDP floods or ICMP floods. Because UDP is connectionless, attackers forge source IP addresses and leverage public reflection amplifiers (e.g., NTP, DNS, or SNMP servers) to multiply the data volume transmitted toward the target [3].
2. **Protocol and State-Exhaustion Attacks (Layer 4):**
   * *Mechanism:* These attacks target state tables maintained by operating system network stacks, stateful firewalls, load balancers, and network address translation (NAT) gateways.
   * *Technique:* In a classic **TCP SYN Flood**, the attacker sends a barrage of SYN packets containing forged source IPs. The target server allocates state memory in its TCP connection backlog queue and responds with a SYN-ACK. Because the source is spoofed or unresponsive, the final ACK packet is never returned. The connection remains in the `SYN_RECEIVED` state until timeouts elapse, rapidly exhausting the server’s connection table and denying incoming legitimate connections.
3. **Application-Layer Attacks (Layer 7):**
   * *Mechanism:* These attacks target computational bottlenecks within the application itself (CPU, memory, database connection pools, or backend thread pools) using low-bandwidth, seemingly legitimate HTTP/HTTPS transactions.
   * *Technique:* Examples include **HTTP GET/POST Floods** targeting computationally heavy endpoints (such as database search queries or PDF generation) and **Slowloris** attacks, which open numerous HTTP connections and send incomplete headers at periodic intervals to exhaust server thread pools while consuming virtually zero attacker bandwidth.

Botnets driving these attacks are assembled through automated vulnerability exploitation, credential brute-forcing against exposed telnet/SSH services, or malware distribution targeting Internet of Things (IoT) gadgets, routers, and unprotected servers [3].

### 1.3 Real-World Incident Case Study: Mirai Botnet & Dyn DNS Outage (October 21, 2016)
On October 21, 2016, an unprecedented volumetric and protocol DDoS attack was unleashed against Dyn (now Oracle Dyn), a premier Managed Domain Name System (DNS) infrastructure service provider [3]. The assault was powered by the **Mirai botnet**, a malware variant that automatically scanned the public IPv4 space for Internet of Things (IoT) hardware—including digital video recorders (DVRs), CCTV IP cameras, and domestic broadband routers—running default factory credentials (such as `admin:admin` or `root:123456`) over Telnet [4].

The attackers marshaled an estimated 100,000+ compromised IoT devices to flood Dyn's Anycast DNS infrastructure across multiple waves with a combined assault peaking between 600 Gbps and 1.2 Tbps [3], [4]. The attack utilized a blend of masked recursive DNS queries (pseudo-random subdomains forcing recursive lookups), TCP SYN floods directed at port 53, and massive UDP packet streams [3]. 

Because Dyn resolved authoritative DNS records for major global platforms, the outage cascaded internationally. While the servers of Dyn's corporate clients remained operational, users across North America and Europe were unable to resolve domain names for Twitter, Spotify, GitHub, Netflix, Reddit, PayPal, and Amazon [3]. Cloudflare's technical analysis of the event highlighted how modern internet resilience is heavily dependent on shared upstream infrastructure: a failure in an authoritative DNS provider effectively decouples clients from applications even if the origin servers are fully operational [3]. This incident catalyzed international regulatory debates on IoT security standards and demonstrated the peril of centralized third-party dependencies.

### 1.4 Real-World Impact
The impacts of sustained DDoS campaigns are multifaceted and severe:
* **Direct Operational Downtime:** Immediate unavailability of revenue-generating customer portals, e-commerce checkout funnels, internal SaaS applications, and API endpoints.
* **Financial Losses:** Lost transactions, contractual Service Level Agreement (SLA) penalty payouts to enterprise clients, and emergency incident-response retainer fees.
* **Customer Attrition & Reputational Damage:** Erosion of consumer trust and institutional credibility, driving enterprise clients toward competitors with proven multi-cloud uptime records.
* **Secondary Threat Distraction:** Adversaries frequently employ volumetric DDoS attacks as a tactical smokescreen to overwhelm Security Operations Centers (SOCs) and mask concurrent data exfiltration or credential stuffing activities.
* **Cloud Infrastructure Overages:** Without automatic mitigation, auto-scaling cloud groups spin up excessive compute and ingress/egress resources, causing astronomical cloud billing spikes (Denial of Wallet).

### 1.5 Three Specific Mitigation Strategies

#### Mitigation 1: DDoS Protection and Cloud Traffic Scrubbing Centers
* **Technical Operation:** Enterprise traffic is routed through globally distributed Anycast edge networks operated by specialized mitigation providers (e.g., Cloudflare, Akamai Prolexic, AWS Shield Advanced). Using Border Gateway Protocol (BGP) Anycast, incoming traffic is announced across hundreds of Points of Presence (PoPs), distributing the attack volume across a multi-terabit-per-second global backplane. Within these scrubbing centers, specialized hardware inspection appliances and automated heuristics strip out malformed packets, invalid TCP flag combinations, and known amplification patterns, forwarding only clean, inspected traffic to the origin server via GRE tunnels or authenticated reverse proxies [3].
* **Limitations:** Introduces minor routing latency for geographically distant users; requires architectural restructuring (delegating DNS or BGP routes); cost can be substantial for continuous high-capacity tiers.
* **Implementation Context:** Mandatory for mission-critical web applications, fintech infrastructure, and public-facing authoritative name servers.

#### Mitigation 2: Rate Limiting, Request Validation, and Web Application Firewalls (WAF)
* **Technical Operation:** At the application layer (Layer 7), reverse proxies and WAFs enforce granular rate-limiting algorithms (e.g., Token Bucket or Leaky Bucket) tied to client IP addresses, session cookies, or authenticated API keys. A WAF inspects HTTP headers, drops requests with irregular user-agent strings, terminates SSL/TLS at the edge, verifies TLS fingerprints (JA3/JA4), and challenges suspicious automated clients using invisible cryptographic challenges or Managed Captchas. Concurrently, operating systems should be tuned with **SYN Cookies** (`net.ipv4.tcp_syncookies = 1`), which encode connection parameters into the initial sequence number, eliminating the need to allocate kernel memory for half-open connections.
* **Limitations:** Does not protect against massive volumetric pipe saturation (which chokes upstream bandwidth before reaching the firewall); aggressive rate limits can inadvertently throttle legitimate corporate proxy users sharing a single NAT gateway (false positives).
* **Implementation Context:** Deployed on load balancers, API gateways, and web application reverse proxies (e.g., NGINX, HAProxy, Envoy).

#### Mitigation 3: Resilient Multi-Provider Architecture and Incident-Response Playbooks
* **Technical Operation:** Eliminating single points of failure by deploying multi-provider, active-active architectures. In the context of DNS, organizations should implement Dual Authoritative DNS providers (using hidden masters and zone transfers via AXFR/TSIG) to guarantee name resolution if one provider experiences an outage. At the network routing level, network engineers configure BGP Flowspec (RFC 5575) and coordinate with upstream Tier-1 Internet Service Providers (ISPs) to rapidly signal blackhole routing (Remotely Triggered Black Hole - RTBH) for targeted IP addresses, preserving overall transit trunk integrity [1], [3].
* **Limitations:** Significant operational complexity in synchronizing configurations across diverse cloud environments; RTBH routing stops all traffic to the victim IP (effectively accomplishing the attacker's goal of denial-of-service, albeit protecting neighboring infrastructure).
* **Implementation Context:** Core enterprise network engineering, autonomous systems (ASNs), and multi-cloud infrastructure orchestration.

---

## 2. Man-in-the-Middle (MITM) Attacks

### 2.1 Definition
A Man-in-the-Middle (MITM) attack—formally categorized in the MITRE ATT&CK framework as **Adversary-in-the-Middle (AiTM) (Technique T1557)** [5]—occurs when an unauthorized threat actor positions themselves logically or physically between two communicating systems to intercept, inspect, decrypt, or alter the data stream in transit without the knowledge of either endpoint [5]. 

In a successful MITM scenario, both legitimate parties believe they are communicating directly with each other over a trusted channel, whereas both are communicating directly through the adversary's proxy system [5].

### 2.2 How the Attack Works
An adversary must divert the legitimate communication path to intercept packets. Common execution mechanisms include:

* **Local Layer 2 Address Resolution Protocol (ARP) Poisoning:** On a local Ethernet or Wi-Fi network, an attacker broadcasts unsolicited, forged ARP replies mapping the IP address of the default gateway to the attacker’s own MAC address. Target hosts update their ARP caches, subsequently routing all outbound internet traffic directly to the attacker’s machine.
* **Rogue Wi-Fi Access Points ("Evil Twin"):** The attacker deploys a wireless access point broadcasting the identical SSID and frequency as a legitimate corporate or public network. Unwary mobile devices automatically associate with the rogue AP, channeling all unencrypted or improperly validated network frames through the attacker’s interface.
* **BGP Route Hijacking:** On a global scale, malicious or misconfigured Autonomous Systems (ASNs) announce unauthorized IP prefixes to upstream peers, diverting internet traffic across continents through foreign surveillance infrastructure before relaying it to the true destination.
* **SSL/TLS Stripping and Protocol Downgrade:** Tools intercept unencrypted HTTP requests before they can upgrade to HTTPS, stripping the `Location: https://` header and rewriting secure links into plain HTTP, forcing the victim to converse in cleartext while the attacker maintains a separate encrypted HTTPS session with the target server.
* **Rogue / Fraudulent Digital Certificates:** If an attacker compromises a trusted Certificate Authority (CA) or forces an endpoint to install a rogue Root CA certificate, the attacker can generate valid-appearing cryptographic certificates on-the-fly, allowing them to decrypt, read, and re-encrypt TLS/HTTPS sessions seamlessly.

Crucially, modern transport security relies on **Transport Layer Security (TLS)**. However, TLS only guarantees security if both cryptographic endpoints are authenticated and certificate validity is rigorously enforced by client software [5].

### 2.3 Real-World Incident Case Study: DigiNotar Certificate Authority Compromise (2011)
In July and August 2011, Dutch commercial Certificate Authority **DigiNotar** suffered an intrusion that represents one of the most critical supply-chain compromises in cryptographic history [6], [7]. Threat actors breached DigiNotar’s internal certificate issuance infrastructure and generated over 530 fraudulent wildcard SSL/TLS certificates for high-profile domains, prominently including `*.google.com`, `*.microsoft.com`, `*.torproject.org`, and foreign intelligence services [6].

Equipped with the authentic-appearing fraudulent `*.google.com` certificate (which was trusted natively by all major operating systems and web browsers because DigiNotar's root was embedded in default trust stores), adversaries executed widespread AiTM interception [6]. In Iran, internet service providers redirected traffic intended for Google services directly through state-aligned surveillance proxy servers. Because the forged certificate chained to DigiNotar's legitimate root, users' web browsers did not trigger any security warnings or broken padlock icons [6], [7]. 

An estimated 300,000 unique Iranian IP addresses had their Gmail accounts, search queries, and communications intercepted in cleartext [6]. The compromise was uncovered only because Google Chrome’s built-in Public Key Pinning (HPKP) mechanism detected that the presented certificate did not match Google's pinned public keys, raising an explicit exception. The incident resulted in Microsoft, Google, Mozilla, and Apple revoking trust in the entire DigiNotar root authority, culminating in the CA declaring immediate bankruptcy [6]. This watershed incident directly accelerated the development and mandatory adoption of **Certificate Transparency (RFC 6962)** and DNS Certification Authority Authorization (CAA).

### 2.4 Real-World Impact
The ramifications of an unmitigated MITM / AiTM attack are devastating:
* **Session Hijacking and Credential Interception:** Attackers capture plaintext passwords, OAuth bearer tokens, and session cookies in real time. Modern AiTM reverse proxies (e.g., Evilginx) intercept session tokens post-authentication, completely bypassing Multi-Factor Authentication (MFA) mechanisms that rely on SMS or time-based one-time passwords (TOTP) [5].
* **Integrity Compromise and Data Tampering:** Adversaries modify files in transit, inject malicious JavaScript payloads into unencrypted web streams, or alter destination banking account numbers within financial API calls.
* **Total Surveillance and Privacy Breach:** Sensitive personal identifiable information (PII), proprietary trade secrets, health records, and private communications are harvested without visible alerts.
* **Erosion of Public Key Infrastructure (PKI) Trust:** When trusted CAs are subverted, the cryptographic foundation of global e-commerce and secure internet transit is systematically undermined.

### 2.5 Three Specific Mitigation Strategies

#### Mitigation 1: Enforce Strict HTTPS, HSTS Preloading, and Modern TLS Configurations
* **Technical Operation:** Web servers must enforce HTTPS across all endpoints and reject unencrypted HTTP connections. To defeat SSL-stripping attacks, servers transmit the `Strict-Transport-Security` (HSTS) response header with a long `max-age` (e.g., `Strict-Transport-Security: max-age=63072000; includeSubDomains; preload`). By submitting the domain to the global browser HSTS Preload list, web browsers hardcode the requirement that connections to the domain must *always* originate over TLS, forbidding unencrypted initial requests. Deprecated cryptographic protocols (SSLv2, SSLv3, TLS 1.0, TLS 1.1) and vulnerable ciphers (RC4, 3DES, CBC-mode ciphers) must be disabled in favor of TLS 1.3 with Ephemeral Diffie-Hellman key exchange (PFS - Perfect Forward Secrecy) [2], [5].
* **Limitations:** HSTS does not prevent MITM if the attacker possesses a compromised root CA installed in the client’s trust store; preloading requires strict operational discipline since domain misconfigurations can lock users out permanently.
* **Implementation Context:** Applied across enterprise web application servers, CDNs, and API gateways.

#### Mitigation 2: Secure Local Network Access, Port Security, and Dynamic ARP Inspection (DAI)
* **Technical Operation:** At the local switching layer (OSI Layer 2), enterprise switches must enforce **DHCP Snooping**, which builds a database of valid IP-to-MAC-to-port bindings by monitoring DHCP exchanges. Using this table, switches activate **Dynamic ARP Inspection (DAI)**, dropping any ARP broadcast packet that asserts an invalid IP-to-MAC relationship, thereby eliminating ARP poisoning attacks. On wireless networks, open networks must be strictly prohibited; organizations must deploy **WPA3-Enterprise** with IEEE 802.1X authentication (EAP-TLS), which provides mutual authentication and mandates 802.11w Protected Management Frames (PMF) to prevent rogue deauthentication attacks [1].
* **Limitations:** Requires managed enterprise switches; non-trivial configuration overhead; does not mitigate remote MITM attacks occurring across upstream internet transit or BGP routes.
* **Implementation Context:** Corporate campus local area networks (LANs), branch office switches, and managed enterprise Wi-Fi controllers.

#### Mitigation 3: Certificate Transparency, CAA Records, and FIDO2/WebAuthn Authentication
* **Technical Operation:** Organizations must configure **DNS Certification Authority Authorization (CAA)** resource records (RFC 8659) specifying exclusively which CAs are permitted to issue certificates for their domains (e.g., `example.com. CAA 0 issue "letsencrypt.org"`). Furthermore, automated monitoring of public **Certificate Transparency (CT) logs** alerts security teams within minutes if an unauthorized CA issues a fraudulent certificate for their domain [6]. To defend against modern AiTM reverse-proxy credential harvesting, organizations must transition from TOTP/SMS to **FIDO2 / WebAuthn passkeys**. FIDO2 tokens bind the cryptographic signature to the exact origin URL displayed in the browser's address bar, ensuring that an attacker-controlled proxy domain cannot replay captured credentials to the legitimate authentication portal [5].
* **Limitations:** CT logs detect fraudulent certificates retrospectively rather than blocking them instantaneously; FIDO2 adoption requires hardware token deployment or modern operating system support.
* **Implementation Context:** Enterprise identity and access management (IAM), public DNS zones, and corporate endpoint policy enforcement.

---

## 3. IP Spoofing

### 3.1 Definition
IP address spoofing is the creation of Internet Protocol (IP) packets with a forged, fraudulent source address in the IP packet header, purposefully disguising the true origin of the packet or impersonating another computing system [1], [8]. 

An essential analytical distinction must be maintained: **forging a source IP address does not, by itself, grant an adversary access to the victim host or allow them to receive response packets.** In standard IP routing, routers forward packets based solely on the *destination* address in the IP header. Consequently, any return packets generated by the receiving host are routed back to the *spoofed* IP address, not to the attacker [8]. As a result, IP spoofing is primarily leveraged in **stateless protocols (UDP/ICMP)**, blind injection attacks, or reflection/amplification DDoS attacks.

Crucially, IP spoofing differs mechanically from related spoofing threats:
* **IP Spoofing (Layer 3):** Manipulation of the 32-bit IPv4 or 128-bit IPv6 source address in the IP header.
* **ARP Spoofing (Layer 2):** Forging MAC address-to-IP relationships on a local Ethernet broadcast domain.
* **DNS Spoofing (Layer 7):** Providing forged domain-to-IP resolution mappings in DNS payload responses.

### 3.2 How the Attack Works
The operation of IP spoofing is dictated by the transport protocol in use:

1. **UDP-Based Stateless Spoofing & Amplification:**
   Because UDP is connectionless and lacks handshakes, sequence tracking, or acknowledgment acknowledgments, an attacker can craft raw sockets that populate the source IP header with the victim's IP address. When sent to third-party public reflector servers (e.g., open DNS resolvers, NTP servers, Memcached servers), the reflectors process the query and send the corresponding response to the forged source address (the victim). If the service exhibits an **Amplification Factor**—where the response payload is orders of magnitude larger than the request query—the victim's network link is saturated by reflected bandwidth [8], [9].
2. **TCP Blind Connection Manipulation:**
   Under TCP, establishing a connection requires completing the three-way handshake (`SYN -> SYN-ACK -> ACK`). If an attacker spoofs the source IP address in a SYN packet, the server transmits the `SYN-ACK` (containing a randomly generated initial sequence number [ISN]) to the legitimate owner of that IP address, not the attacker. Unless the attacker can accurately predict the 32-bit ISN or sits on the physical wire to intercept the packet, they cannot complete the handshake. While historical implementations with predictable ISNs permitted blind session hijacking (as demonstrated in the legendary 1994 Kevin Mitnick attack on Tsutomu Shimomura's systems), modern operating systems generate cryptographically secure pseudo-random sequence numbers, rendering blind TCP session establishment virtually impossible across the public internet [8].
3. **Bypassing Weak IP-Whitelisting Trust Controls:**
   In poorly architected internal networks where legacy Unix services (`rsh`, `rlogin`) or administrative firewalls grant implicit access based purely on source IP addresses without requiring cryptographic authentication, an attacker on the same local subnet or non-validating path can inject unidirectional malicious commands.

### 3.3 Real-World Incident Case Study: GitHub 1.35 Tbps Memcached Amplification Attack (February 28, 2018)
On February 28, 2018, developer platform GitHub was struck by what was, at the time, the largest documented distributed denial-of-service attack in internet history, peaking at an astonishing **1.35 Terabits per second (Tbps)** and 126.9 million packets per second [9], [10]. 

The attack was driven entirely by **IP source-address spoofing combined with Memcached reflection amplification** [9]. Memcached is a high-performance, distributed memory caching system designed for internal deployment behind private networks. However, thousands of systems had been misconfigured by administrators and exposed directly to the public internet on UDP port 11211 without authentication [9]. 

Adversaries forged the source IP of their outbound UDP requests to match GitHub's public IP ranges. They transmitted small UDP requests (e.g., `get` commands for pre-loaded large data keys) to approximately 100,000 exposed Memcached servers worldwide [9]. Because Memcached over UDP responded with immense cached payload values, the attack achieved an unprecedented amplification factor of approximately **51,000 to 1** [9]. A 15-byte request from the attacker generated a 750-kilobyte response directed straight at GitHub’s border routers.

GitHub’s systems detected the massive inbound saturation immediately. Because GitHub had pre-integrated automated volumetric DDoS mitigation via Akamai Prolexic, traffic was redirected to global scrubbing centers within 10 minutes of initial detection, filtering out the spoofed Memcached traffic and restoring full service availability [9]. The incident demonstrated how open UDP services coupled with the failure of transit networks to filter spoofed packets create catastrophic internet-wide vulnerabilities.

### 3.4 Real-World Impact
* **Catastrophic Bandwidth Amplification:** Enables attackers with modest broadband uplinks to generate multi-hundred-gigabit or terabit floods against target networks.
* **Attribution Camouflage & Forensic Impediment:** Spoofing obscures the true origin of attacking machines, frustrating packet tracing, legal prosecution, and real-time automated firewall blocking.
* **Subversion of IP-Based Access Controls:** In organizations that rely solely on source IP whitelisting for access to APIs, administrative panels, or internal databases, spoofing allows attackers to inject unauthorized commands or trigger state changes if return traffic is unneeded.
* **Intermediary Reflector Blacklisting:** Benign corporate servers running open UDP services that are abused as reflectors face reputation blacklisting, operational disruption, and upstream transit suspension.

### 3.5 Three Specific Mitigation Strategies

#### Mitigation 1: Ingress and Egress Filtering via IETF BCP 38 / RFC 2827
* **Technical Operation:** Published by the Internet Engineering Task Force (IETF) as Best Current Practice 38 (BCP 38 / RFC 2827), **Network Ingress Filtering** requires network operators and Internet Service Providers (ISPs) to configure border edge routers to validate the source address of all outbound and inbound packets [8]. An edge router serving a specific customer network must strictly drop any outbound packet whose source IP does not belong to that customer’s legitimately allocated IP prefix (egress filtering). Similarly, ingress filters drop packets entering a network whose source address matches internal private ranges (RFC 1918) or unroutable Martian addresses [8].
* **Limitations:** BCP 38 is extraordinarily effective if adopted universally; however, its implementation requires voluntary deployment by every individual ISP worldwide. Because an ISP incurs configuration costs while the benefits primarily protect *other* networks from spoofed traffic, compliance remains incomplete across the global internet (as monitored by the CAIDA Spoofer Project).
* **Implementation Context:** Internet service providers, telecom carriers, autonomous system border routers (ASBRs), and enterprise data center egress gateways.

#### Mitigation 2: Unicast Reverse Path Forwarding (uRPF) and Boundary ACLs
* **Technical Operation:** Network engineers enable **Unicast Reverse Path Forwarding (uRPF)** on edge routers [8]. In **Strict Mode uRPF**, when a router receives a packet, it consults its Forwarding Information Base (FIB). If the interface on which the packet arrived is not the exact best return path to the packet's source IP address, the packet is immediately dropped as spoofed. In **Loose Mode uRPF**, the router checks whether the source IP exists in the routing table at all; if it points to an unroutable destination or blackhole, it is dropped. Additionally, edge firewalls enforce explicit Access Control Lists (ACLs) denying external packets masquerading as internal subnet addresses [8].
* **Limitations:** Strict uRPF can break legitimate asymmetric routing paths common in complex multi-homed enterprise networks; loose uRPF provides weaker protection and allows spoofing among valid routable IP addresses.
* **Implementation Context:** Enterprise perimeter routers, core switch-routers, and data center edge firewalls.

#### Mitigation 3: Cryptographic Protocols and Rejection of IP-Based Identity
* **Technical Operation:** Security architecture must abolish the assumption that an IP address represents a verified identity. All network interactions must demand cryptographic integrity and mutual identity verification. Protocols such as **IPsec (AH/ESP)**, **Mutual TLS (mTLS)**, and **SSH** utilize cryptographic keys to sign and encrypt headers and payloads. In mTLS, both client and server present X.509 certificates validated against a trusted internal CA; a packet with a spoofed IP cannot generate the required cryptographic signature, resulting in immediate connection termination before application processing [2].
* **Limitations:** Adds computational cryptographic overhead; requires Public Key Infrastructure (PKI) deployment and automated certificate lifecycle management.
* **Implementation Context:** Application programming interfaces (APIs), inter-service microservice communications, database connections, and remote administrative access.

---

## 4. DNS Poisoning and DNS Spoofing

### 4.1 Definition
The Domain Name System (DNS) is the hierarchical, distributed directory service that translates human-memorable hostnames (e.g., `bank.example.com`) into numerical IP addresses (e.g., `192.0.2.1`) required for routing network packets [11]. 

* **DNS Spoofing:** A broad umbrella term describing any technique where deceptive DNS resolution data is returned to a client, directing them to an unauthorized IP address.
* **DNS Cache Poisoning:** A specific, technical exploit wherein an attacker injects fraudulent DNS resource records (RRs) into the local cache of a recursive DNS resolver (caching server) [12]. Once poisoned, the resolver serves this fraudulent mapping to every downstream client until the record's Time-To-Live (TTL) expires [11], [12].

DNS cache poisoning must be analytically separated from other forms of DNS compromise:
* **Registrar / Account Hijacking:** Threat actors compromise the administrative credentials of a domain owner at their registrar (e.g., GoDaddy, Namecheap) to officially alter the authoritative Name Server (NS) records. This is an administrative credential breach, not a protocol-level vulnerability.
* **Local Hosts File Modification:** Malware on an endpoint modifies `/etc/hosts` or the Windows `hosts` file locally, bypassing DNS resolution entirely.
* **Malicious Resolvers:** Rogue DHCP servers assigning untrusted DNS resolver IPs to endpoints.

### 4.2 How the Attack Works
A standard recursive DNS query operates as follows:
1. A client host asks its local recursive resolver for the IP of `target.example.com`.
2. If not cached, the resolver transmits iterative UDP queries to the root servers, the Top-Level Domain (TLD) servers, and ultimately the authoritative name server for `example.com`.
3. The authoritative server replies with a DNS response packet containing the genuine IP.

Because DNS historically relied on stateless UDP on port 53, the resolver validated responses using only two data fields:
* The destination port of the resolver.
* A 16-bit **Transaction ID (TxID)** included in the query header, yielding only $2^{16} = 65,536$ possible values.

In a classic cache-poisoning attack, an attacker triggers the recursive resolver to query a target domain. While the resolver waits for the legitimate authoritative server's response, the attacker floods the resolver with thousands of forged UDP response packets containing fabricated IP mappings, cycling through guesses for the 16-bit TxID. If a forged packet arrives *before* the legitimate response and matches the correct TxID, the resolver accepts the forged response, caches it, and terminates the query [11], [12].

When client browsers subsequently resolve the domain, they are directed to the attacker’s rogue IP address. If the target service uses HTTPS, modern browsers will display severe SSL/TLS certificate warnings because the attacker cannot present a valid certificate signed for that domain—unless the attacker has also compromised a Certificate Authority (as occurred with DigiNotar) or the user clicks through the warning [6], [12].

### 4.3 Real-World Incident Case Study: Dan Kaminsky’s Cache Poisoning Flaw (CVE-2008-1447)
In early 2008, renowned security researcher Dan Kaminsky discovered a critical structural vulnerability in the DNS protocol implementation that dramatically altered the global internet security landscape [12], [13].

Prior to Kaminsky’s discovery, traditional DNS cache poisoning was constrained by query round-trip times: if an attacker failed to guess the 16-bit TxID before the legitimate authoritative response arrived, the resolver cached the legitimate record for the duration of its TTL (often days), preventing further attempts until the record expired [12].

Kaminsky realized that an attacker could bypass this limitation entirely by requesting non-existent, pseudo-random subdomains of the target domain (e.g., `1248.example.com`, `1249.example.com`, `1250.example.com`) [12]. Because these subdomains were never cached, the recursive resolver was forced to query the authoritative server for `example.com` continuously. With each query, the attacker fired hundreds of forged responses that not only matched the fabricated subdomain but also injected an **Additional Authority Record** asserting that the attacker’s own IP was the authoritative name server (`NS`) for the entire `example.com` domain [12], [13]. 

Mathematical modeling demonstrated that an attacker on a typical broadband connection could deterministically poison an entire domain within approximately 10 seconds [12]. Once poisoned, every subsequent lookup for any host under that domain (`mail.example.com`, `www.example.com`) was redirected to the attacker's server [12]. Recognizing the catastrophic internet-wide implications, Kaminsky organized an unprecedented secret international summit bringing together Microsoft, Cisco, BIND, and other vendors to coordinate a synchronized global patch release on July 8, 2008 [13]. 

The emergency remediation introduced **Source Port Randomization (SPR)**—randomizing both the 16-bit UDP source port ($65,536$ combinations) and the 16-bit TxID ($65,536$ combinations), raising the guessing complexity from $65,536$ to $65,536 \times 65,536 \approx 4.29 \times 10^9$ possibilities [11], [13]. This landmark vulnerability demonstrated that protocol-level entropy was insufficient and accelerated the formal deployment of **DNSSEC** [11].

### 4.4 Real-World Impact
* **Seamless Phishing and Credential Harvesting:** Users entering legitimate URLs in their browser are routed directly to identical-looking fraudulent clone websites.
* **Silent Email Interception:** By poisoning DNS Mail Exchange (MX) records, attackers redirect corporate email traffic through their own mail transfer agents, reading sensitive communications and intercepting password-reset tokens before forwarding messages to the authentic destination.
* **Malware Distribution via Software Update Spoofing:** Applications that perform automatic software updates over unencrypted channels or without digital signature validation can be tricked into downloading malware binaries hosted on poisoned servers.
* **Denial of Resolution:** Injecting invalid or unreachable IP addresses effectively knocks domains offline for all users querying the affected recursive resolver.

### 4.5 Three Specific Mitigation Strategies

#### Mitigation 1: DNS Security Extensions (DNSSEC) Validation
* **Technical Operation:** Standardized in IETF RFC 4033, 4034, and 4035, **DNSSEC** adds cryptographic authentication to DNS data [11]. Authoritative zone owners sign their DNS records using asymmetric cryptography. Resource Record Sets (RRsets) are accompanied by a cryptographic signature record (**RRSIG**), verified against a public Key Signing Key (**DNSKEY**) that chains up to the root zone via Delegation Signer (**DS**) records. When a recursive resolver performs a lookup, it cryptographically validates the signature chain. If an attacker attempts to inject a forged IP mapping, the digital signature check fails, and the resolver discards the response, returning a `SERVFAIL` status to the client [11].
* **Limitations:** DNSSEC provides data authenticity and integrity, but **does not provide confidentiality or encryption** (queries and responses remain visible in cleartext); deployment requires careful key maintenance and registrar support; misconfigured DNSSEC signatures can inadvertently cause global domain resolution failures.
* **Implementation Context:** Authoritative domain zone configurations, corporate DNS registries, and enterprise validating recursive resolvers.

#### Mitigation 2: Secure Recursive Resolver Configuration & Source Port Randomization
* **Technical Operation:** DNS resolver software (e.g., Unbound, BIND 9, PowerDNS) must be updated to enforce Source Port Randomization (SPR), drawing UDP ephemeral client ports from a pool of at least 16,000 to 30,000 randomized ports rather than static or sequential allocations. Furthermore, recursive resolvers should implement **0x20 bit encoding** (randomizing uppercase and lowercase letters in the queried domain name, e.g., `wWw.ExAmPlE.cOm`), which requires the authoritative response to echo the exact case combination, adding additional entropy. Crucially, enterprise resolvers must be configured to reject recursive queries from external public IP addresses (closing open resolvers) and should implement strict query rate limits to prevent cache-snooping abuse [11], [13].
* **Limitations:** Source port randomization can be degraded if the resolver sits behind a legacy NAT gateway that rewrites source ports into sequential ranges; 0x20 bit encoding requires authoritative server compliance.
* **Implementation Context:** Enterprise DNS infrastructure, ISP recursive resolvers, and local caching servers.

#### Mitigation 3: Encrypted Transport (DoH/DoT), Protective DNS (PDNS), and Automated Zone Auditing
* **Technical Operation:** To secure the "last mile" between client endpoints and recursive resolvers, organizations deploy encrypted DNS protocols: **DNS-over-HTTPS (DoH - RFC 8484)** or **DNS-over-TLS (DoT - RFC 7858)**. These wrap DNS queries inside encrypted TLS tunnels, preventing local Wi-Fi or transit eavesdroppers from observing, injecting, or spoofing DNS replies. At the enterprise tier, organizations route queries through **Protective DNS (PDNS)** services (such as CISA’s Protective DNS or enterprise Threat Intelligence resolvers), which block lookups to known malicious domains in real time. Finally, automated zone-monitoring tools monitor public authoritative records $24/7$, alerting administrators to unauthorized record additions or registrar modifications [1], [11].
* **Limitations:** DoH can bypass enterprise network perimeter inspection and firewall monitoring if endpoints configure arbitrary external resolvers; PDNS requires continuous threat feed subscriptions.
* **Implementation Context:** Corporate mobile devices, workstation endpoint policies, and secure enterprise gateway routers.

---

## 5. Comparison of Network Security Threats

To provide network administrators and security analysts with an actionable comparative reference, the four examined threats are evaluated side-by-side in Table 1.

### 5.1 Comprehensive Threat Comparison Matrix

| Threat | Main Attack Vector | Who Is at Risk? | Difficulty to Execute | Ease of Mitigation |
|---|---|---|---|---|
| **Denial-of-Service (DoS / DDoS)** | Distributed botnets flooding volumetric bandwidth (UDP/ICMP), protocol queues (SYN floods), or application endpoints (HTTP floods). | Public web applications, e-commerce platforms, APIs, gaming servers, authoritative DNS services, and cloud-hosted infrastructure. | **Moderate** (Botnets-for-hire and automated stressers are easily accessible, but custom large-scale botnet creation requires skill). | **Moderate** (Manageable via cloud scrubbing providers, CDN edge caching, and upstream BGP filtering; hard to eliminate without third-party services). |
| **Man-in-the-Middle (MITM / AiTM)** | Local ARP poisoning, rogue Wi-Fi APs, BGP hijacking, rogue digital certificates, and reverse-proxy phishing (e.g., Evilginx). | Public Wi-Fi users, unmanaged remote workers, systems using unencrypted HTTP/legacy protocols, and organizations lacking FIDO2 MFA. | **Moderate** (Local network poisoning is low difficulty; full TLS interception across public internet requires high-capability CA/BGP subversion). | **Easier** (Universally defeated on endpoints by strict HSTS preloaded HTTPS, WPA3/802.1X, DAI, and FIDO2 cryptographic authentication). |
| **IP Spoofing** | Forging the 32-bit source IP address in stateless UDP packet headers, leveraged primarily for reflection/amplification floods. | Intermediary open UDP servers (abused as reflectors), and target organizations subjected to massive reflected DDoS attacks. | **Low to Moderate** (Crafting raw UDP packets with forged headers is trivial; finding network paths lacking egress filtering requires reconnaissance). | **Difficult** (Individual organizations cannot stop incoming spoofed packets; requires global ISP-level enforcement of BCP 38 / RFC 2827). |
| **DNS Poisoning / Spoofing** | Racing forged UDP responses with randomized Transaction IDs to corrupt recursive resolver caches; exploiting Kaminsky-style flaws. | Internet users relying on non-validating recursive resolvers, organizations without DNSSEC, and enterprise domains without registrar MFA. | **Moderate to High** (Modern source port randomization and 0x20 encoding make blind cache poisoning difficult; rogue resolver injection remains moderate). | **Moderate** (Completely mitigated at the root by DNSSEC validation, closed recursive resolvers, encrypted DoH/DoT, and registrar security). |

*Note on Evaluation Scales:* Ratings are established relative to a typical organization operating standard commercial network infrastructure:
* **Difficulty to Execute:** *Low* (readily scriptable with public tools), *Moderate* (requires protocol understanding and reconnaissance), *High* (demands advanced exploit capability, cryptographic subversion, or nation-state infrastructure).
* **Ease of Mitigation:** *Easier* (remediable via internal configuration and free protocols), *Moderate* (requires architectural adjustments and specialized services), *Difficult* (relies on external third-party cooperation, upstream transit providers, or global internet compliance).

### 5.2 Comparative Analysis & Defense-in-Depth Synthesis

A critical insight from this comparison is how these threats map to the **CIA Triad** (Confidentiality, Integrity, Availability):
* **Availability:** Exclusively targeted by **DoS/DDoS** and secondarily by **IP Spoofing** (via reflection amplification) and **DNS Poisoning** (via dead-end routing).
* **Confidentiality:** Primarily threatened by **MITM/AiTM** (eavesdropping on unencrypted traffic, session harvesting) and **DNS Poisoning** (silently routing users to credential-harvesting phishing portals).
* **Integrity:** Violated by **MITM/AiTM** (payload tampering, malicious script injection) and **DNS Poisoning** (tampering with name resolution records).

Furthermore, in sophisticated real-world campaigns, **threat vectors frequently overlap and chain together**:
1. *IP Spoofing + DDoS:* Attackers forge source IPs to weaponize third-party servers in massive Memcached or NTP reflection DDoS attacks.
2. *DNS Poisoning + MITM:* Attackers poison a DNS resolver to redirect traffic to their proxy, where they subsequently execute a Man-in-the-Middle session capture.
3. *DDoS + Intrusion:* A massive volumetric DDoS flood is launched against a corporate firewall to exhaust logs and distract the SOC while an AiTM credential theft campaign targets remote executives.

Because no individual control can defeat all four threats, organizations must implement a **Defense-in-Depth** model spanning Layer 2 (DAI, 802.1X), Layer 3 (uRPF, BCP 38), Layer 4 (TLS 1.3, SYN cookies), and Layer 7 (WAF, DNSSEC, HSTS, FIDO2).

---

## 6. Detection and Incident Response

Early detection and disciplined incident containment represent the difference between a transient operational anomaly and a catastrophic enterprise breach. Network administrators must establish proactive telemetry across all network tiers.

### 6.1 Threat Indicator Matrix

| Threat | Possible Warning Signs & Anomalies | Defensive Monitoring & Telemetry | Initial Containment Response |
|---|---|---|---|
| **DoS / DDoS** | • Sudden, abnormal spikes in ingress/egress bandwidth (Gbps) or packet rates (pps).<br>• Dramatic surge in TCP SYN packets without corresponding ACKs.<br>• Elevated HTTP 502/503/504 gateway timeout errors.<br>• Customer reports of service latency or timeouts. | • Real-time NetFlow / sFlow / IPFIX traffic flow analytics.<br>• Server resource telemetry (CPU, RAM, connection queue depths).<br>• Edge CDN / WAF anomaly dashboards.<br>• Upstream ISP BGP transit bandwidth alerts. | 1. Activate cloud DDoS scrubbing / diversion (BGP swing or DNS shift).<br>2. Enable WAF rate limiting and aggressive challenge mode (JS/Captcha).<br>3. Engage upstream ISP for Remotely Triggered Blackhole (RTBH) routing if link is saturated. |
| **MITM / AiTM** | • End-users report untrusted SSL/TLS certificate security warnings.<br>• Unexpected MAC address changes for the default gateway IP on local switches.<br>• Duplicate IP/MAC collision alerts in network logs.<br>• Anomalous authentication events from unusual geographic locations within seconds of login. | • Continuous Certificate Transparency (CT) log monitoring.<br>• Managed switch ARP table change alerts and DHCP snooping logs.<br>• Identity Provider (IdP) risk-based conditional access logs (impossible travel).<br>• Network Intrusion Detection System (NIDS - e.g., Zeek, Suricata) ARP poisoning signatures. | 1. Isolate compromised switch ports or disconnect rogue wireless access points.<br>2. Revoke active user session tokens and enforce global password/MFA resets.<br>3. Check and purge local ARP caches on affected subnets.<br>4. Inspect host trust stores for unauthorized root CA certificates. |
| **IP Spoofing** | • Inbound packets arriving on external interfaces claiming internal RFC 1918 source IPs.<br>• Massive inbound UDP traffic on atypical high ports originating from single services (Memcached, NTP, DNS).<br>• Asymmetric traffic ratio anomalies (millions of response packets with zero initial outbound requests). | • Edge router uRPF drop counters and ingress ACL violation logging.<br>• Flow-based protocol ratio monitoring (UDP vs TCP traffic balance).<br>• SIEM ingestion of firewall boundary drop events. | 1. Implement temporary boundary firewall filters blocking target UDP ports.<br>2. Enable Strict or Loose uRPF on perimeter router interfaces.<br>3. Coordinate with upstream transit providers to filter unverified source prefixes. |
| **DNS Poisoning / Spoofing** | • Discrepancies between authoritative DNS zone files and recursive resolver query results.<br>• Sudden drop in legitimate application traffic accompanied by spikes to unknown external IPs.<br>• Elevated DNS `SERVFAIL` responses on validating resolvers.<br>• Unexpected registrar email notifications regarding nameserver modifications. | • Continuous DNS record resolution monitoring from external vantage points.<br>• Protective DNS (PDNS) query resolution telemetry.<br>• Local resolver cache inspection and NXDOMAIN spike alerts.<br>• Registrar account activity logging and multi-factor notifications. | 1. Flush the poisoned cache on all internal recursive resolvers (`rndc flush` or equivalent).<br>2. Verify authoritative nameserver records and lock registrar accounts.<br>3. Switch internal resolver forwarders to validated public secure resolvers (e.g., 1.1.1.1, 8.8.8.8, 9.9.9.9).<br>4. Enforce strict DNSSEC validation on all caching resolvers. |

### 6.2 High-Level 7-Step Incident Response Sequence

When telemetry alerts security personnel to potential malicious activity, administrators should follow an established incident response lifecycle (adapted from NIST SP 800-61 Rev. 2) [2]:

```text
[Step 1: Detect & Validate Alert] ──> [Step 2: Scope & Assess Triage] ──> [Step 3: Rapid Containment]
                                                                                    │
[Step 6: Stakeholder Notification] <── [Step 5: Eradication & Restore] <── [Step 4: Evidence Preservation]
              │
              └──> [Step 7: Post-Incident Review & Hardening]
```

1. **Step 1: Detect and Validate the Alert:** 
   Correlate alerts across multiple telemetry sources (e.g., matching a NetFlow bandwidth spike with firewall drop logs) to rule out benign transient anomalies, network equipment misconfigurations, or planned internal load tests.
2. **Step 2: Scope and Assess Triage:** 
   Determine the blast radius. Identify specifically which subnets, customer accounts, critical business applications, or external transit interfaces are impacted, and classify the severity level based on organizational business impact.
3. **Step 3: Rapid Containment:** 
   Execute pre-approved, threat-specific containment procedures: divert volumetric traffic to cloud scrubbing centers, isolate suspicious switch ports via network access control (NAC), disable compromised user accounts, or flush poisoned resolver caches.
4. **Step 4: Evidence Preservation:** 
   Before rebooting systems or clearing state tables, securely capture volatile memory, export firewall and DNS transaction logs, record full packet capture (PCAP) traces of attack traffic, and preserve cryptographic hashes of forensic artifacts for legal and regulatory attribution.
5. **Step 5: Eradication and Service Restoration:** 
   Remove the root cause: patch vulnerable software, re-establish valid DNS records, revoke compromised digital certificates, enforce uRPF on edge routers, and restore clean, verified configurations before gradually re-enabling production traffic.
6. **Step 6: Stakeholder and Regulatory Notification:** 
   Notify internal leadership, legal counsel, and operational teams. If protected consumer data or regulatory compliance boundaries were breached, initiate mandatory reporting to regulatory bodies (e.g., GDPR, HIPAA, SEC) and external communication teams.
7. **Step 7: Post-Incident Review and Control Hardening:** 
   Conduct a formal "blameless post-mortem" within 72 hours. Document the timeline, evaluate response effectiveness, identify defensive gaps, and update firewall rules, network architectures, and response playbooks to prevent recurrence.

---

## 7. Conclusion

As enterprise systems continue their architectural shift toward distributed microservices, multi-cloud platforms, and boundary-less remote environments, network security can no longer rely on perimeter defense alone. The four threats analyzed in this report—Denial-of-Service, Man-in-the-Middle, IP Spoofing, and DNS Cache Poisoning—exploit fundamental design assumptions in legacy internet protocols. While their mechanisms differ across protocol layers, their mitigation relies on a cohesive philosophy of zero-trust, automated verification, and infrastructural resilience.

For network administrators, systems engineers, and security analysts, this research synthesizes into **three key takeaways**:

1. **Availability and Resilience Require Redundancy and Upstream Scale:**  
   Volumetric DDoS attacks and reflection floods powered by millions of insecure IoT devices can rapidly overwhelm any individual enterprise data connection. Protecting availability requires architectural resilience: deploying multi-provider authoritative DNS, utilizing globally distributed Anycast edge scrubbing networks, and pre-establishing automated BGP upstream diversion playbooks before an incident strikes.
2. **Communication Security Demands Universal Cryptographic Authentication:**  
   Trust cannot be based on easily manipulated network metadata such as source IP addresses, MAC addresses, or cleartext domain names. Confidentiality and integrity demand end-to-end cryptographic protection: enforcing HSTS-preloaded TLS 1.3, authenticating Layer 2 access with 802.1X, mandating phishing-resistant FIDO2/WebAuthn authentication, and employing mutual TLS (mTLS) for system-to-system communications.
3. **Infrastructure Integrity Hinges on Global Standards and Continuous Telemetry:**  
   Securing foundational network plumbing requires both local diligence and adherence to global internet standards. Network operators must enforce source address validation via BCP 38 / uRPF to eliminate IP spoofing, implement DNSSEC validation to guarantee naming integrity, and maintain continuous telemetry across NetFlow, DNS query logs, and Certificate Transparency streams to detect anomalies before they manifest as operational catastrophes.

Ultimately, no single security appliance, vendor tool, or configuration switch guarantees protection. Sustainable network defense requires an ongoing commitment to defense-in-depth, rigorous security auditing, staff awareness, and proactive incident response readiness.

---

## 8. References

[1] C. E. Perkins and J. T. Stewart, "Security in the Internet Protocol Architecture," *IEEE Communications Magazine*, vol. 48, no. 7, pp. 44–51, Jul. 2010.

[2] National Institute of Standards and Technology (NIST), "Computer Security Incident Handling Guide," *NIST Special Publication 800-61 Revision 2*, Computer Security Division, Information Technology Laboratory, Gaithersburg, MD, Aug. 2012. [Online]. Available: https://csrc.nist.gov/publications/detail/sp/800-61/rev-2/final

[3] M. Caulfield, "How the Dyn outage affected Cloudflare," *Cloudflare Official Blog*, Oct. 21, 2016. [Online]. Available: https://blog.cloudflare.com/how-the-dyn-outage-affected-cloudflare/

[4] Cybersecurity and Infrastructure Security Agency (CISA), "Alert (TA16-288A): Heightened DDoS Threat Posed by Mirai and Other Botnets," *CISA Current Activity & Advisories*, Oct. 2016. [Online]. Available: https://www.cisa.gov/news-events/alerts/2016/10/14/heightened-ddos-threat-posed-mirai-and-other-botnets

[5] MITRE ATT&CK®, "Adversary-in-the-Middle (Technique T1557)," *MITRE Corporation Enterprise Matrix*, Version 15, Apr. 2024. [Online]. Available: https://attack.mitre.org/techniques/T1557/

[6] J. R. Prins, "DigiNotar Certificate Authority breach 'Operation Black Tulip' Final Report," *Fox-IT Technical Investigation Commissioned by the Dutch Ministry of the Interior*, The Hague, Netherlands, Dec. 2011. [Online]. Available: https://staff.science.uva.nl/b.d.r.m.v.groenewegen/papers/DigiNotar-Black-Tulip-Update.pdf

[7] Cybersecurity and Infrastructure Security Agency (CISA), "Alert (TA11-242A): DigiNotar Certificate Authority Compromise," *National Cyber Awareness System*, Sep. 2011. [Online]. Available: https://www.cisa.gov/news-events/alerts/2011/09/02/diginotar-certificate-authority-compromise

[8] P. Ferguson and D. Senie, "Network Ingress Filtering: Defeating Denial of Service Attacks which employ IP Source Address Spoofing," *IETF Best Current Practice 38, RFC 2827*, May 2000. [Online]. Available: https://www.rfc-editor.org/rfc/rfc2827

[9] S. Kottler, "February 28th DDoS Incident Report," *The GitHub Blog*, Mar. 1, 2018. [Online]. Available: https://github.blog/2018-03-01-ddos-incident-report/

[10] Cybersecurity and Infrastructure Security Agency (CISA), "Alert (TA18-067A): Increased Use of Memcached Servers in Reflection Denial of Service Attacks," *CISA Technical Alerts*, Mar. 2018. [Online]. Available: https://www.cisa.gov/news-events/alerts/2018/03/08/increased-use-memcached-servers-reflection-denial-service-attacks

[11] R. Arends, R. Austein, M. Larson, D. Massey, and S. Rose, "DNS Security Introduction and Requirements," *IETF RFC 4033*, Mar. 2005. [Online]. Available: https://www.rfc-editor.org/rfc/rfc4033

[12] D. Kaminsky, "It's The End Of The Cache As We Know It," *Black Hat USA 2008 Technical Briefing*, Las Vegas, NV, Aug. 2008. [Online]. Available: https://www.blackhat.com/presentations/bh-usa-08/Kaminsky/bh-us-08-kaminsky.pdf

[13] US-CERT / CISA, "Vulnerability Note VU#800113: Multiple DNS implementations vulnerable to cache poisoning (CVE-2008-1447)," *Carnegie Mellon Software Engineering Institute CERT Coordination Center*, Jul. 2008. [Online]. Available: https://www.kb.cert.org/vuls/id/800113
