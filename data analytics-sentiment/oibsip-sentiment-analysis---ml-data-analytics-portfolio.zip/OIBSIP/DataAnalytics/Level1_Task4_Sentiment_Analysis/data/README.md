# Dataset Documentation — OIBSIP Data Analytics Level 1 Task 4

## Dataset Information

- **Title:** TweetEval Benchmark — Sentiment Classification (SemEval-2017 Task 4 Subtask A)
- **Primary Source:** Cardiff NLP / Snap Research
- **Repository URL:** [https://github.com/cardiffnlp/tweeteval](https://github.com/cardiffnlp/tweeteval)
- **Paper Citation:** 
  > Barbieri, F., Camacho-Collados, J., Espinosa-Anke, L., & Neves, L. (2020). *TweetEval: Unified Benchmark and Comparative Evaluation for Tweet Classification*. Findings of the Association for Computational Linguistics: EMNLP 2020, pp. 1644–1650.
- **License:** Creative Commons Attribution 4.0 International (CC BY 4.0) and Twitter Developer Agreement.
- **Task Scope:** 3-Class Sentiment Analysis (`positive`, `negative`, `neutral`).

---

## File Details

- **File Name:** `twitter_sentiment_dataset.csv`
- **File Format:** UTF-8 Comma-Separated Values (CSV)
- **Total Records:** 45,615 annotated tweets
- **Class Breakdown:**
  - `neutral`: 20,673 tweets (45.32%)
  - `positive`: 17,849 tweets (39.13%)
  - `negative`: 7,093 tweets (15.55%)

---

## Schema & Column Definitions

| Column Name | Data Type | Description |
|:------------|:----------|:------------|
| `text` | `string` | The raw tweet text, preserving mentions (`@user`), hashtags (`#...`), punctuation, emoticons, and casing. |
| `sentiment` | `string` | Standardized categorical sentiment label: `positive`, `negative`, or `neutral`. |
| `label_id` | `int64` | Original numeric code (0 = negative, 1 = neutral, 2 = positive) from the SemEval-2017 / TweetEval benchmark. |

---

## Download and Recreation Instructions

If this dataset needs to be reconstructed from official Cardiff NLP raw sources, run the automated extraction script or the following Python commands:

```python
import urllib.request
import pandas as pd

train_text_url = "https://raw.githubusercontent.com/cardiffnlp/tweeteval/main/datasets/sentiment/train_text.txt"
train_labels_url = "https://raw.githubusercontent.com/cardiffnlp/tweeteval/main/datasets/sentiment/train_labels.txt"

with urllib.request.urlopen(train_text_url) as ft:
    texts = [line.decode("utf-8").strip() for line in ft]

with urllib.request.urlopen(train_labels_url) as fl:
    label_map = {0: "negative", 1: "neutral", 2: "positive"}
    numeric_ids = [int(line.strip()) for line in fl]
    sentiments = [label_map[i] for i in numeric_ids]

df = pd.DataFrame({
    "text": texts,
    "sentiment": sentiments,
    "label_id": numeric_ids
})

df.to_csv("data/twitter_sentiment_dataset.csv", index=False)
print(f"Saved {len(df)} rows to data/twitter_sentiment_dataset.csv")
```

---

## Ethical and Privacy Safeguards

1. User identifiers have been standardized to `@user` by the benchmark curators to safeguard individual privacy.
2. The dataset captures real-world social commentary, reflecting authentic digital linguistics including slang, negation constructs, and emojis.
3. Content is provided strictly for academic and research benchmarking.
