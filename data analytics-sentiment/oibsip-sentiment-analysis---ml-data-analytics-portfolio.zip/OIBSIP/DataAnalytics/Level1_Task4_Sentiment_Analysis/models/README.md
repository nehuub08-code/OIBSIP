# Model Artifacts Documentation — OIBSIP Data Analytics Level 1 Task 4

## Overview

This directory houses trained and serialized machine-learning pipelines for 3-class sentiment analysis (`positive`, `negative`, `neutral`).

## Model Artifacts

- **File:** `sentiment_pipeline_best.joblib`
- **Architecture:** Complete scikit-learn Pipeline incorporating:
  1. `TfidfVectorizer` (sublinear term frequency scaling, unigram + bigram combinations `(1, 2)`, min_df=3, max_df=0.9, max_features=10,000)
  2. `LogisticRegression` (L2 regularization, solver='lbfgs', max_iter=1000, multi_class='auto', random_state=42)

## Loading and Inference in Python

```python
import joblib

# Load the fitted pipeline (includes vectorizer + classifier)
pipeline = joblib.load("models/sentiment_pipeline_best.joblib")

# Inference on arbitrary new text
sample_texts = [
    "Absolutely in love with the new update! Smooth and lightning fast.",
    "Customer service was terrible, delayed my issue for three days with zero help.",
    "The package is scheduled for delivery tomorrow at 2 PM."
]

predictions = pipeline.predict(sample_texts)
probabilities = pipeline.predict_proba(sample_texts)

for text, pred, prob in zip(sample_texts, predictions, probabilities):
    conf = max(prob) * 100
    print(f"[{pred.upper()}] ({conf:.1f}% confidence): {text}")
```

## Security Warning & Environment Compatibility

1. Serialized `joblib` artifacts execute arbitrary Python byte-code during unpickling. Only load model files from trusted sources.
2. The model was trained with `scikit-learn >= 1.3.0` and `Python 3.10+`. Loading across incompatible scikit-learn minor versions may result in unpickling warnings or deviations in floating-point outputs.
3. This model is evaluated for educational and benchmarking purposes within the OIBSIP Data Analytics program; before deploying to customer-facing automated systems, additional stress testing across domain-specific jargon, negation, and multilingual inputs should be conducted.
