# OIBSIP Data Analytics — Level 1 | Task 4: Sentiment Analysis

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Scikit-Learn](https://img.shields.io/badge/scikit--learn-v1.7%2B-orange.svg)](https://scikit-learn.org/)
[![License: CC BY 4.0](https://img.shields.io/badge/License-CC_BY_4.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)
[![Status: Completed](https://img.shields.io/badge/Status-Completed-success.svg)]()

> **Oasis Infobyte Internship Program (OIBSIP)**  
> **Track:** Data Analytics  
> **Level:** Level 1  
> **Task:** Task 4 — Sentiment Analysis Using Machine Learning  
> **Deliverable:** Reproducible Jupyter Notebook, Trained Models, Visualizations, and Technical Report  

---

## 📌 Project Overview

This project implements an end-to-end, production-grade **3-Class Sentiment Analysis System** (`positive`, `negative`, `neutral`) using real social media benchmark data from **TweetEval** (SemEval-2017 Task 4). 

Unlike standard binary classifiers (positive vs negative), real-world business analytics demands distinguishing opinionated customer feedback from objective statements, inquiries, and logistics updates. We build a leakage-free text preprocessing and TF-IDF extraction pipeline, train and benchmark **Multinomial Naive Bayes** against regularized **Logistic Regression**, generate high-resolution visual diagnostics, and conduct qualitative error analysis on misclassified tweets.

---

## 🎯 Objectives

1. Ingest and validate a real 3-class labeled benchmark dataset without fabrication or synthetic labels.
2. Build an intelligent NLP preprocessing pipeline that preserves sentiment-critical negation tokens (*not*, *never*, *no*).
3. Implement a leakage-free TF-IDF vectorization strategy (fitted strictly on training data).
4. Train and compare two distinct classifiers: **Multinomial Naive Bayes** and **Balanced Logistic Regression**.
5. Calculate comprehensive multi-class evaluation metrics (Accuracy, Macro/Weighted Precision, Recall, and F1-Score).
6. Generate and save diagnostic visualizations: Class Distribution, Confusion Matrices, and Sentiment WordClouds.
7. Conduct qualitative error analysis on misclassified instances to diagnose failure modes (negation, sarcasm, mixed clauses).
8. Serialize the best-performing pipeline artifact for instant inference.

---

## 📊 Dataset Attribution & Summary

- **Dataset Title:** TweetEval Benchmark — Sentiment Classification (SemEval-2017 Task 4 Subtask A)
- **Creators:** Francesco Barbieri, Jose Camacho-Collados, Luis Espinosa-Anke, Leonardo Neves (Cardiff NLP & Snap Inc.)
- **Canonical Paper:** *Findings of the Association for Computational Linguistics: EMNLP 2020*, pp. 1644–1650.
- **Source Repository:** [https://github.com/cardiffnlp/tweeteval](https://github.com/cardiffnlp/tweeteval)
- **License:** Creative Commons Attribution 4.0 International (CC BY 4.0)

### Dataset Distribution (45,583 Cleaned Tweets)

| Sentiment Polarity | Tweet Count | Percentage | Description |
|:---|:---:|:---:|:---|
| **Neutral** | 20,653 | 45.31% | Objective facts, questions, event schedules, entity mentions |
| **Positive** | 17,839 | 39.14% | Customer compliments, enthusiasm, praise, endorsements |
| **Negative** | 7,091 | 15.56% | Frustrations, service complaints, grievances, defects |
| **Total** | **45,583** | **100.00%** | Held in `data/twitter_sentiment_dataset.csv` |

---

## 🗂️ Project Directory Structure

```text
OIBSIP/
└── DataAnalytics/
    └── Level1_Task4_Sentiment_Analysis/
        ├── README.md                              <- Project overview & execution guide
        ├── sentiment_analysis.ipynb               <- Fully documented Jupyter Notebook (18 sections)
        ├── run_pipeline.py                        <- Automated execution script
        ├── generate_notebook.py                   <- Notebook generator script
        ├── requirements.txt                       <- Python dependencies
        ├── .gitignore                             <- Python/Jupyter ignore rules
        ├── data/
        │   ├── README.md                          <- Dataset schema, source, & instructions
        │   └── twitter_sentiment_dataset.csv      <- Benchmark dataset (45,583 rows)
        ├── models/
        │   ├── README.md                          <- Model artifact loading instructions
        │   └── sentiment_pipeline_best.joblib     <- Serialized TF-IDF + Logistic Regression (722 KB)
        ├── outputs/
        │   ├── figures/
        │   │   ├── sentiment_distribution.png     <- Class balance bar chart
        │   │   ├── naive_bayes_confusion_matrix.png
        │   │   ├── logistic_regression_confusion_matrix.png
        │   │   ├── wordcloud_positive.png
        │   │   ├── wordcloud_negative.png
        │   │   └── wordcloud_neutral.png
        │   ├── metrics/
        │   │   ├── model_comparison.csv           <- Comparative evaluation table
        │   │   ├── naive_bayes_classification_report.csv
        │   │   ├── logistic_regression_classification_report.csv
        │   │   └── summary_metadata.json
        │   └── predictions/
        │       └── misclassified_examples.csv     <- Curated diagnostic error analysis
        └── reports/
            └── sentiment_analysis_report.md       <- Full technical research report
```

---

## ⚙️ Installation & Setup Instructions

### 1. Clone the Repository & Navigate to Project Directory
```bash
git clone https://github.com/<your-username>/OIBSIP.git
cd OIBSIP/DataAnalytics/Level1_Task4_Sentiment_Analysis
```

### 2. Create and Activate Virtual Environment
```bash
# Create virtual environment
python -m venv .venv

# Activate on Windows:
.venv\Scripts\activate

# Activate on macOS / Linux:
source .venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Execute the Pipeline and Launch Notebook
```bash
# Run the automated pipeline to reproduce all outputs:
python run_pipeline.py

# Launch Jupyter Notebook:
jupyter notebook sentiment_analysis.ipynb
```

---

## 🧪 Machine Learning Pipeline Overview

```
Raw Social Media Text
         │
         ▼
[Preprocessing & Cleaning]
├── Strip URLs & noise
├── Standardize user handles (@user)
├── Case normalization (lowercase)
├── Lemmatization (WordNet)
└── Custom Stopwords (Preserving Negation: not, no, never, n't)
         │
         ▼
[Stratified 80/20 Train/Test Split]
├── Training Set: 36,466 samples (80.0%)
└── Held-out Test Set: 9,117 samples (20.0%)
         │
         ▼
[Leakage-Free TF-IDF Vectorizer] (Fitted ONLY on X_train)
├── N-grams: (1, 2) unigrams + bigrams
├── Sublinear TF scaling (1 + log(tf))
├── Frequency bounds: min_df=3, max_df=0.90
└── Max Features: 12,000 vocabulary dimension
         │
    ┌────┴──────────────────────────┐
    ▼                               ▼
[Model 1: Multinomial Naive Bayes]  [Model 2: Balanced Logistic Regression]
- Generative probabilistic model     - Discriminative log-linear model
- Prior probability smoothing        - Inverse frequency class weights (class_weight='balanced')
- Ultra-fast baseline (2.51s fit)    - L2 Ridge Regularization (C=1.5, 5.98s fit)
```

---

## 📈 Evaluation Results & Comparison

Evaluated on the held-out test partition (**9,117 unseen tweets**):

| Model Architecture | Accuracy | Macro Precision | Macro Recall | Macro F1 | Weighted F1 | Fit Time |
|:---|:---:|:---:|:---:|:---:|:---:|:---:|
| **Multinomial Naive Bayes** | 0.6229 | **0.6324** | 0.5245 | 0.5286 | 0.5997 | **2.51s** |
| **Logistic Regression (Balanced)** | **0.6369** | 0.6081 | **0.6333** | **0.6156** | **0.6411** | 5.98s |

### Class-Specific Breakdown: The Critical Minority Class Finding

| Metric (Negative Class) | Multinomial Naive Bayes | Logistic Regression (Balanced) | Delta |
|:---|:---:|:---:|:---:|
| **Precision** | **0.6429** | 0.4429 | -20.00% |
| **Recall** | 0.1650 | **0.6135** | **+44.85% (272% relative boost!)** |
| **F1-Score** | 0.2626 | **0.5145** | **+25.19%** |

> **Key Interview Takeaway:** Naive Bayes collapsed on the minority `negative` class, identifying only **234 out of 1,418 negative tweets (16.5% recall)** because the dominant prior probabilities of neutral and positive tweets biased the generative decision boundary. Logistic Regression with inverse class weighting recovered balanced detection across all three classes, boosting negative recall to **61.4%** and overall Macro F1 to **0.6156**.

---

## 🖼️ Generated Visualizations

| Visual Artifact | Path | Preview Description |
|:---|:---|:---|
| **Class Distribution** | `outputs/figures/sentiment_distribution.png` | Bar plot illustrating the 45.3% neutral, 39.1% positive, 15.6% negative distribution. |
| **Logistic Regression Confusion Matrix** | `outputs/figures/logistic_regression_confusion_matrix.png` | 3x3 normalized heatmap showcasing balanced diagonal performance across classes. |
| **Naive Bayes Confusion Matrix** | `outputs/figures/naive_bayes_confusion_matrix.png` | Heatmap exposing MNB's severe false-neutral collapse on negative instances. |
| **Positive WordCloud** | `outputs/figures/wordcloud_positive.png` | WordCloud of terms: *love*, *great*, *good*, *thank*, *happy*, *best*, *congrats*. |
| **Negative WordCloud** | `outputs/figures/wordcloud_negative.png` | WordCloud of terms: *hate*, *bad*, *worst*, *delay*, *lost*, *shit*, *suck*, *never*. |
| **Neutral WordCloud** | `outputs/figures/wordcloud_neutral.png` | WordCloud of terms: *tomorrow*, *tonight*, *game*, *watch*, *day*, *time*, *update*. |

---

## 🔍 Error Analysis Case Studies

From `outputs/predictions/misclassified_examples.csv`:

1. **Negation Valence Inversion:**  
   - *"We are no way losing it! C'mon you little monsters ! #MTVStars Lady Gaga"*  
   - **Actual:** `POSITIVE` | **Predicted:** `NEGATIVE`  
   - *Cause:* Colloquial double negative (*"no way losing"*). Linear model unigram weights penalized *"no"* and *"losing"*.
2. **Mixed Multi-Clause Sentiment:**  
   - *"I'm going to try to get it done before I see Shawn tomorrow but I don't think it's gunna happen"*  
   - **Actual:** `NEGATIVE` | **Predicted:** `NEUTRAL`  
   - *Cause:* Factual first clause (*"try to get it done before I see Shawn"*) diluted the disappointed second clause.
3. **Subjective Term False Trigger:**  
   - *"Don't Forget The Classical Brit Awards At 10pm tonight for a Special appearance..."*  
   - **Actual:** `NEUTRAL` | **Predicted:** `POSITIVE`  
   - *Cause:* Factual reminder containing promotional polarity keywords (*"Special"*, *"Bday"*).

---

## 🚀 Live Inference on Saved Pipeline

```python
import joblib

# Load serialized pipeline (vectorizer + classifier in one)
pipeline = joblib.load("models/sentiment_pipeline_best.joblib")

tweets = [
    "Absolutely thrilled with the quick delivery and high quality! 5 stars.",
    "Customer service left me on hold for 40 minutes and hung up. Terrible.",
    "The store opens at 9:00 AM on Monday."
]

predictions = pipeline.predict(tweets)
probabilities = pipeline.predict_proba(tweets)

for text, pred, prob in zip(tweets, predictions, probabilities):
    conf = max(prob) * 100
    print(f"[{pred.upper()}] ({conf:.1f}%): {text}")
```

---

## 📜 License & Citation

- **Code:** MIT License
- **Dataset:** TweetEval Benchmark (CC BY 4.0). Barbieri et al., *Findings of EMNLP 2020*.
