# Comprehensive Technical Report: 3-Class Sentiment Analysis Using Machine Learning
**Oasis Infobyte Internship Program (OIBSIP) — Data Analytics Track**  
**Level 1 | Task 4: Sentiment Analysis**  
**Author:** Data Analytics Intern  
**Date:** October 2026  
**Repository Path:** `OIBSIP/DataAnalytics/Level1_Task4_Sentiment_Analysis/`

---

## 1. Executive Summary & Project Overview

Sentiment analysis represents one of the foundational capabilities of applied machine learning in customer analytics, brand intelligence, and conversational AI. The objective of this project is to architect, evaluate, and interpret a multi-class Natural Language Processing (NLP) pipeline capable of categorizing real-world digital text into **three distinct polarities**: `positive`, `negative`, and `neutral`.

Unlike standard toy binary classifications (positive vs. negative), a 3-class system directly models the messy reality of organic customer interactions, where a substantial portion of communications consist of objective inquiries, logistics updates, or non-opinionated discourse. We systematically benchmark **Multinomial Naive Bayes** against regularized **Logistic Regression** over a corpus of **45,583 cleaned tweets** extracted from the standardized **TweetEval** benchmark (SemEval-2017 Task 4). Our findings demonstrate that while Multinomial Naive Bayes suffers catastrophic recall collapse on the minority negative class (16.50% recall), balanced Logistic Regression successfully recovers balanced recall (61.35% recall) and establishes superior performance with a **Macro F1-Score of 0.6156**.

---

## 2. Dataset Source, Integrity, and Schema

### 2.1 Attribution and Benchmark Pedigree
- **Dataset Title:** TweetEval Benchmark — Sentiment Classification (SemEval-2017 Task 4 Subtask A)
- **Creators:** Francesco Barbieri, Jose Camacho-Collados, Luis Espinosa-Anke, Leonardo Neves (Cardiff NLP & Snap Inc.)
- **Canonical Reference:** *Findings of the Association for Computational Linguistics: EMNLP 2020*, pp. 1644–1650.
- **Repository URL:** [https://github.com/cardiffnlp/tweeteval](https://github.com/cardiffnlp/tweeteval)
- **License:** Creative Commons Attribution 4.0 International (CC BY 4.0) and Twitter Developer Agreement.

### 2.2 Data Ingestion and Cleansing Protocol
The raw corpus was downloaded via the official Cardiff NLP repository. Ingestion inspection revealed:
- **Raw Volume:** 45,615 records.
- **Missing Values:** Zero null text or label fields.
- **Duplicate Text Detection:** 54 identical text records were identified. Analysis revealed that **3 text records carried contradictory sentiment labels** (label noise). To preserve strict data integrity, contradictory examples were purged and duplicates consolidated, yielding a final cleaned corpus of **45,583 rows**.

### 2.3 Class Distribution and Imbalance Analysis
The distribution of classes across the 45,583 instances is summarized below:

| Sentiment Class | Sample Count | Percentage of Corpus | Polarity Characterization |
|:---|:---:|:---:|:---|
| **Neutral** | 20,653 | 45.31% | Objective facts, questions, event schedules, entity mentions |
| **Positive** | 17,839 | 39.14% | Compliments, enthusiasm, gratitude, endorsement |
| **Negative** | 7,091 | 15.56% | Frustrations, service delays, complaints, grievances |
| **Total** | **45,583** | **100.00%** | Full Benchmark Corpus |

**Data Science Implication:** The dataset exhibits moderate class imbalance, with `neutral` and `positive` dominating and `negative` representing only 15.56%. Consequently, **overall accuracy is a misleading metric**, as a baseline predicting only majority classes would achieve ~45% accuracy while completely failing to identify unhappy customers. Multi-class **Macro F1** and **Class-specific Recall** were designated as primary evaluation criteria.

The distribution chart is saved in `outputs/figures/sentiment_distribution.png`.

---

## 3. Text Preprocessing Methodology

Textual data on social media platforms contains severe noise: irregular capitalization, hyperlinks, hashtags, user handles, and non-standard syntax. 

### 3.1 Preservation of Negation Markers (Anti-Information Loss)
Standard NLP stopword packages (e.g., vanilla NLTK) routinely eliminate words such as *not*, *no*, *never*, and *nor*. In sentiment classification, stripping negation fundamentally distorts semantic valence:
- *Raw:* "The customer service was **not** helpful."
- *Naively Filtered:* "customer service helpful" $\rightarrow$ **Falsely classified as Positive**.

To eliminate this vulnerability, our custom stopword list explicitly preserves the negation tokens:
`{"not", "no", "nor", "never", "none", "neither", "n't", "barely", "hardly", "scarcely"}`.

### 3.2 Preprocessing Transformation Stages
1. **Hyperlink Stripping:** Regex pattern `r'http\S+|www\S+|https\S+'` strips non-lexical URLs.
2. **Handle Normalization:** User mentions are preserved as standardized `@user` tokens to capture conversational structure without exposing private accounts.
3. **Case Normalization:** Universal conversion to lowercase to collapse identical lemmas.
4. **Tokenization:** Regex word boundary extraction `r"\b[a-zA-Z']+\b"`.
5. **Lemmatization:** WordNet lemmatizer resolves inflected forms (*"delayed"*, *\"delays\"*, *\"delaying\"* $\rightarrow$ *\"delay\"*).
6. **Dual Column Tracking:** The cleaned text is stored in `cleaned_text`, while the unedited string is preserved in `original_text` to enable qualitative error analysis.

---

## 4. Feature Extraction: Leakage-Free TF-IDF Vectorization

### 4.1 Mathematical Formulation
Term Frequency-Inverse Document Frequency (TF-IDF) translates variable-length text sequences into fixed-dimensional sparse numerical feature vectors:

$$\text{TF-IDF}(t, d, D) = \text{TF}(t, d) \times \log\left(\frac{1 + |D|}{1 + |\{d \in D : t \in d\}|}\right) + 1$$

Sublinear term frequency scaling ($1 + \log(\text{tf})$) was enabled to mitigate the disproportionate weight of repetitive words within individual tweets.

### 4.2 Hyperparameter Configuration
- `ngram_range=(1, 2)`: Captures single terms (*unigrams*) as well as contiguous pairs (*bigrams*, such as *"not good"*, *"worst ever"*, *"can't wait"*).
- `min_df=3`: Filters terms appearing in fewer than 3 documents, pruning idiosyncratic typos.
- `max_df=0.90`: Excludes ubiquitous tokens appearing in >90% of documents.
- `max_features=12,000`: Bounds vocabulary dimensionality to prevent memory explosion.

### 4.3 Strict Leakage Prevention
To ensure zero data leakage, the TF-IDF vectorizer was **strictly fit on the training partition** (`X_train`) only. The test partition was subsequently transformed using the vocabulary and IDF weights computed solely from the training data.

---

## 5. Model Architecture & Theoretical Formulations

We benchmarked two complementary supervised classification paradigms:

### 5.1 Model 1: Multinomial Naive Bayes (MNB)
Multinomial Naive Bayes is a generative probabilistic model applying Bayes' Theorem under the conditional independence assumption:

$$P(C_k \mid \mathbf{x}) \propto P(C_k) \prod_{i=1}^n P(x_i \mid C_k)$$

- **Smoothing:** Additive Laplace smoothing ($\alpha = 1.0$) handles out-of-vocabulary terms.
- **Hypothesis:** MNB provides an exceptionally fast, highly scalable baseline for sparse text features, but its empirical prior probabilities $P(C_k)$ can penalize under-represented minority classes.

### 5.2 Model 2: Logistic Regression with Balanced Class Weighting
Multinomial Logistic Regression is a discriminative linear model parameterizing class probabilities via the Softmax function:

$$P(y = c \mid \mathbf{x}) = \frac{\exp(\mathbf{w}_c^T \mathbf{x} + b_c)}{\sum_{j=1}^K \exp(\mathbf{w}_j^T \mathbf{x} + b_j)}$$

- **Regularization:** L2 ridge regularization with inverse regularization strength $C=1.5$.
- **Class Balancing:** `class_weight='balanced'` assigns sample weights inversely proportional to class frequencies:
  
  $$w_c = \frac{N}{K \cdot N_c}$$

  This heavily penalizes misclassification on the minority `negative` class during gradient descent.
- **Optimization:** Solved using the L-BFGS quasi-Newton optimization algorithm with up to 1,000 iterations.

---

## 6. Experimental Validation & Evaluation Results

### 6.1 Train / Test Stratification Protocol
The cleaned corpus of 45,583 instances was partitioned using an **80/20 stratified split** (`random_state=42`):
- **Training Set:** 36,466 tweets (80.0%)
- **Test Set:** 9,117 tweets (20.0%)
- **Class Proportions (Train vs Test):** Identical across all classes (Neutral: 45.31%, Positive: 39.14%, Negative: 15.56%).

### 6.2 Consolidated Model Comparison

| Evaluation Metric | Multinomial Naive Bayes | Logistic Regression (Balanced) | Delta / Winner |
|:---|:---:|:---:|:---:|
| **Accuracy** | 0.6229 | **0.6369** | **+1.40% (LR)** |
| **Macro Precision** | **0.6324** | 0.6081 | +2.43% (MNB) |
| **Macro Recall** | 0.5245 | **0.6333** | **+10.88% (LR)** |
| **Macro F1-Score** | 0.5286 | **0.6156** | **+8.70% (LR)** |
| **Weighted F1-Score** | 0.5997 | **0.6411** | **+4.14% (LR)** |
| **Negative Class Precision** | **0.6429** | 0.4429 | +20.00% (MNB) |
| **Negative Class Recall** | 0.1650 | **0.6135** | **+44.85% abs (LR)** |
| **Negative Class F1** | 0.2626 | **0.5145** | **+25.19% abs (LR)** |
| **Training Time** | **2.51 seconds** | 5.98 seconds | 2.4x faster (MNB) |

The complete comparison table is serialized at `outputs/metrics/model_comparison.csv`.

---

## 7. Confusion Matrix Observations

The confusion matrices are illustrated in `outputs/figures/naive_bayes_confusion_matrix.png` and `outputs/figures/logistic_regression_confusion_matrix.png`.

```text
Multinomial Naive Bayes (Test Set: 9,117 samples)
Actual \ Pred     Negative    Neutral    Positive
Negative            234        927         257      (Recall: 16.50%)
Neutral             100       3,079        952      (Recall: 74.53%)
Positive             30       1,173      2,365      (Recall: 66.28%)

Logistic Regression (Balanced) (Test Set: 9,117 samples)
Actual \ Pred     Negative    Neutral    Positive
Negative            870        348         200      (Recall: 61.35%)
Neutral             638       2,525        968      (Recall: 61.12%)
Positive            456         694      2,418      (Recall: 67.77%)
```

### Key Analytical Takeaways:
1. **The MNB Majority Trap:** Multinomial Naive Bayes suffers from extreme prior bias. Out of 1,418 actual negative tweets, MNB misclassified **927 as Neutral (65.4%)** and **257 as Positive (18.1%)**, recognizing only 234 negative instances.
2. **Balanced Recall Restoration:** Logistic Regression's inverse frequency weighting balanced the decision boundary, successfully classifying **870 negative tweets**—a **272% relative improvement** in capturing critical complaints.
3. **Neutral Boundary Permeability:** Both models encounter the highest classification confusion between `Neutral` and `Positive`/`Negative`. Tweets communicating factual events (*"Concert begins at 8 PM"*) often carry enthusiastic syntax or entity proper nouns that linear models confuse with polarity signals.

---

## 8. WordCloud Vocabulary Insights

Class-specific WordClouds were rendered and stored in `outputs/figures/`:
- `wordcloud_positive.png`: Heavily characterized by affirmative adjectives and gratitude terms: *love*, *good*, *great*, *thank*, *best*, *happy*, *awesome*, *beautiful*, *congrats*.
- `wordcloud_negative.png`: Prominently features disruptions, dissatisfaction, and invective: *hate*, *bad*, *worst*, *shit*, *suck*, *delay*, *lost*, *never*, *miss*, *stop*, *problem*.
- `wordcloud_neutral.png`: Dominated by temporal coordinators, scheduled activities, and news references: *tomorrow*, *tonight*, *game*, *watch*, *day*, *time*, *new*, *update*, *release*, *stream*.

---

## 9. Error Analysis: Qualitative Failure Mode Diagnosis

Real data science demands understanding *why* predictions fail. We extracted misclassified test cases and categorized them into four dominant linguistic failure modes (stored in `outputs/predictions/misclassified_examples.csv`):

### Diagnostic Case Studies:

1. **Negation Valence Inversion**
   - **Text:** *"We are no way losing it! C'mon you little monsters ! #MTVStars Lady Gaga"*
   - **Ground Truth:** `POSITIVE` | **Predicted:** `NEGATIVE`
   - **Linguistic Diagnosis:** Double negative / colloquial affirmation (*"no way losing"*). Linear model unigram weights penalized *"no"* and *"losing"*, failing to recognize the colloquial emphatic praise.

2. **Mixed Multi-Clause Sentiment**
   - **Text:** *"I'm going to try to get it done before I see Shawn tomorrow but I don't think it's gunna happen"*
   - **Ground Truth:** `NEGATIVE` | **Predicted:** `NEUTRAL`
   - **Linguistic Diagnosis:** The factual first clause (*"try to get it done before I see Shawn tomorrow"*) provided neutral scheduling features that outweighed the negative valence of the disappointing subordinate clause (*"don't think it's gunna happen"*).

3. **Promotional Fact vs. Subjective Adjective Ambiguity**
   - **Text:** *"Don't Forget The Classical Brit Awards At 10pm tonight for a Special appearance of the 25th anniversary Cast of Phantom for 26th Bday??"*
   - **Ground Truth:** `NEUTRAL` | **Predicted:** `POSITIVE`
   - **Linguistic Diagnosis:** Factual tune-in reminder containing polar promotional modifiers (*"Special"*, *"Bday"*), causing the linear model to push probabilities across the positive decision boundary.

4. **Tragic Real-World Entity Spillover**
   - **Text:** *"I'm in the south but my greatest desire is to see an end to Boko Haram. May God help our @user president. @user"*
   - **Ground Truth:** `POSITIVE` (supportive civic prayer) | **Predicted:** `NEGATIVE`
   - **Linguistic Diagnosis:** Mention of an extremist entity (*"Boko Haram"*) carried massive negative training weights that overpowered the affirmative civic desire (*"greatest desire"*, *"May God help"*).

---

## 10. Model Selection & Production Recommendation

### Winner: Logistic Regression with Balanced Class Weighting
- **Primary Metric Justification:** Achieved a **Macro F1-Score of 0.6156** (compared to 0.5286 for MNB) and maintained balanced recall above 61% across all three classes.
- **Operational Feasibility:** The serialized model artifact (`models/sentiment_pipeline_best.joblib`) requires only **722 KB** of storage and delivers **< 1 millisecond inference latency** per tweet on standard CPU hardware.

---

## 11. Practical Business Applications

1. **Automated Help Desk Routing:** Routing incoming negative customer inquiries directly to senior retention specialists while funneling neutral status requests to self-service knowledge base bots.
2. **Social Media Crisis Early Warning:** Triggering threshold alerts when the ratio of negative tweets mentioning brand keywords spikes by >25% hour-over-hour.
3. **Product Feature Sentiment Decomposition:** Parsing feedback on mobile apps to identify which specific features (e.g., UI, checkout, notifications) drive neutral vs negative sentiment.

---

## 12. Limitations & Ethical Considerations

1. **Domain Transferability:** The model is calibrated on social media Twitter syntax. Applying this model directly to medical EHR notes, legal contracts, or technical documentation will incur performance drops due to domain vocabulary shift.
2. **Sarcasm and Context Blindness:** Bag-of-words and n-gram linear models cannot reconstruct world knowledge or vocal sarcasm (*"Oh wonderful, another system crash!"*).
3. **Algorithmic Fairness:** Sentiment models should never be used as the sole basis for high-stakes decisions, including automated HR filtering, user banning, or credit scoring.

---

## 13. References & Attributions

1. Barbieri, F., Camacho-Collados, J., Espinosa-Anke, L., & Neves, L. (2020). *TweetEval: Unified Benchmark and Comparative Evaluation for Tweet Classification*. Findings of EMNLP 2020.
2. Rosenthal, S., Farra, N., & Nakov, P. (2017). *SemEval-2017 Task 4: Sentiment Analysis in Twitter*. Proceedings of the 11th International Workshop on Semantic Evaluation.
3. Pedregosa, F., et al. (2011). *Scikit-learn: Machine Learning in Python*. JMLR 12, pp. 2825-2830.
