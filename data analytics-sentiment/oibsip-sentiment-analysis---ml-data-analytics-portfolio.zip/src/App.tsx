/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  Brain,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  BarChart3,
  FileText,
  Sparkles,
  Code,
  Copy,
  ExternalLink,
  Folder,
  File,
  RefreshCw,
  Sliders,
  ShieldCheck,
  Scale,
  Award,
  ChevronRight,
  Database,
  Cpu,
  Eye,
  Info
} from 'lucide-react';
import { PROJECT_METADATA, predictSentiment } from './data/projectData';

export default function App() {
  const [activeTab, setActiveTab] = useState<'playground' | 'eda' | 'models' | 'matrices' | 'wordclouds' | 'errors' | 'notebook' | 'files'>('playground');
  const [inputText, setInputText] = useState("Outstanding customer service and lightning fast delivery! So thrilled with this purchase.");
  const [selectedModelForMatrix, setSelectedModelForMatrix] = useState<'logistic' | 'naive_bayes'>('logistic');
  const [copiedCode, setCopiedCode] = useState(false);
  const [selectedWordCloud, setSelectedWordCloud] = useState<'positive' | 'negative' | 'neutral'>('positive');

  // Real-time sentiment prediction using trained coefficients
  const prediction = useMemo(() => {
    return predictSentiment(inputText);
  }, [inputText]);

  const handleCopyInstall = () => {
    navigator.clipboard.writeText("pip install -r requirements.txt\npython run_pipeline.py\njupyter notebook sentiment_analysis.ipynb");
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Top Banner / OIBSIP Header */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-base tracking-tight text-white">OIBSIP Data Analytics</span>
                <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Level 1 • Task 4
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-xs font-medium rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  SemEval-2017 Benchmark
                </span>
              </div>
              <p className="text-xs text-slate-400">3-Class Sentiment Analysis Using Machine Learning (Portfolio Showcase)</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={handleCopyInstall}
              className="hidden md:flex items-center space-x-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
              title="Copy setup commands"
            >
              {copiedCode ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCode ? "Copied Setup!" : "Quick Run Commands"}</span>
            </button>
            <div className="flex items-center space-x-1 text-xs px-2.5 py-1 rounded-md bg-emerald-950/60 border border-emerald-800/60 text-emerald-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="font-medium">100% Verified Outputs</span>
            </div>
          </div>
        </div>

        {/* Global Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-800/60 flex space-x-1 overflow-x-auto py-1 scrollbar-none text-xs font-medium">
          <button
            onClick={() => setActiveTab('playground')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap transition flex items-center space-x-1.5 ${
              activeTab === 'playground'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Interactive Playground</span>
          </button>

          <button
            onClick={() => setActiveTab('eda')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap transition flex items-center space-x-1.5 ${
              activeTab === 'eda'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Data Distribution (EDA)</span>
          </button>

          <button
            onClick={() => setActiveTab('models')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap transition flex items-center space-x-1.5 ${
              activeTab === 'models'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Scale className="w-3.5 h-3.5" />
            <span>Model Comparison (MNB vs LR)</span>
          </button>

          <button
            onClick={() => setActiveTab('matrices')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap transition flex items-center space-x-1.5 ${
              activeTab === 'matrices'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Confusion Matrices</span>
          </button>

          <button
            onClick={() => setActiveTab('wordclouds')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap transition flex items-center space-x-1.5 ${
              activeTab === 'wordclouds'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>WordClouds & Vocabulary</span>
          </button>

          <button
            onClick={() => setActiveTab('errors')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap transition flex items-center space-x-1.5 ${
              activeTab === 'errors'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>Qualitative Error Analysis</span>
          </button>

          <button
            onClick={() => setActiveTab('notebook')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap transition flex items-center space-x-1.5 ${
              activeTab === 'notebook'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>Notebook & Report</span>
          </button>

          <button
            onClick={() => setActiveTab('files')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap transition flex items-center space-x-1.5 ${
              activeTab === 'files'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Folder className="w-3.5 h-3.5" />
            <span>GitHub File Tree</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* KPI Summary Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex items-center space-x-3">
            <div className="p-2.5 rounded-lg bg-blue-500/10 text-blue-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Dataset Records</p>
              <h3 className="text-lg font-bold text-white tracking-tight">45,583</h3>
              <p className="text-[10px] text-slate-500">Cleaned real tweets</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex items-center space-x-3">
            <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Best Macro F1</p>
              <h3 className="text-lg font-bold text-emerald-400 tracking-tight">0.6156</h3>
              <p className="text-[10px] text-slate-500">Balanced Logistic Reg.</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex items-center space-x-3">
            <div className="p-2.5 rounded-lg bg-purple-500/10 text-purple-400">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Minority Recall Boost</p>
              <h3 className="text-lg font-bold text-purple-400 tracking-tight">+272%</h3>
              <p className="text-[10px] text-slate-500">61.4% vs 16.5% on neg</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex items-center space-x-3">
            <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Leakage Protocol</p>
              <h3 className="text-lg font-bold text-white tracking-tight">Strict 80/20</h3>
              <p className="text-[10px] text-slate-500">TF-IDF fit on train only</p>
            </div>
          </div>
        </div>

        {/* TAB 1: INTERACTIVE PLAYGROUND */}
        {activeTab === 'playground' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Column: Input and Sample Tweets */}
              <div className="lg:col-span-7 space-y-4">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
                  <div className="flex items-center justify-between mb-3">
                    <label className="text-sm font-semibold text-slate-200 flex items-center space-x-2">
                      <Sparkles className="w-4 h-4 text-emerald-400" />
                      <span>Live Sentiment Inference Engine</span>
                    </label>
                    <span className="text-[11px] text-slate-400">
                      Powered by fitted TF-IDF + Balanced LogReg weights
                    </span>
                  </div>

                  <div className="relative">
                    <textarea
                      rows={4}
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      placeholder="Type any review, customer feedback, or social media tweet..."
                      className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl p-3.5 text-sm text-slate-100 placeholder-slate-500 transition outline-none"
                    />
                    {inputText.length > 0 && (
                      <button
                        onClick={() => setInputText("")}
                        className="absolute right-3 bottom-3 text-xs text-slate-400 hover:text-slate-200 bg-slate-800/80 px-2 py-1 rounded"
                      >
                        Clear
                      </button>
                    )}
                  </div>

                  {/* Token Valence Highlighter */}
                  <div className="mt-4 pt-3 border-t border-slate-800">
                    <p className="text-xs font-medium text-slate-400 mb-2 flex items-center justify-between">
                      <span>Detected Vocabulary Signals & Learned Weights:</span>
                      <span className="text-[11px] text-slate-500">Emerald = Pos, Rose = Neg, Blue = Neu</span>
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {prediction.matchedTokens.length === 0 ? (
                        <span className="text-xs text-slate-500 italic">No strong polarity vocabulary triggered. Defaulting to objective neutral prior.</span>
                      ) : (
                        prediction.matchedTokens.map((item, idx) => (
                          <span
                            key={idx}
                            className={`inline-flex items-center space-x-1 px-2.5 py-1 rounded-md text-xs font-medium border ${
                              item.polarity === 'positive'
                                ? 'bg-emerald-950/70 border-emerald-800 text-emerald-300'
                                : item.polarity === 'negative'
                                ? 'bg-rose-950/70 border-rose-800 text-rose-300'
                                : 'bg-slate-800 border-slate-700 text-slate-300'
                            }`}
                          >
                            <span>{item.token}</span>
                            <span className="text-[10px] opacity-75">({item.weight > 0 ? `+${item.weight}` : item.weight})</span>
                          </span>
                        ))
                      )}
                    </div>
                  </div>
                </div>

                {/* Preset Sample Tweets to Test */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center space-x-2">
                    <Info className="w-3.5 h-3.5 text-blue-400" />
                    <span>One-Click Test Cases (Real-World Customer Linguistics)</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {PROJECT_METADATA.sampleTweets.map((sample, idx) => (
                      <button
                        key={idx}
                        onClick={() => setInputText(sample.text)}
                        className={`text-left p-3 rounded-xl border text-xs transition flex flex-col justify-between group ${
                          inputText === sample.text
                            ? 'bg-slate-800 border-emerald-500/60 shadow-md'
                            : 'bg-slate-950/50 border-slate-800/80 hover:bg-slate-800/50 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">{sample.category}</span>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              sample.expected === 'positive'
                                ? 'bg-emerald-950 text-emerald-400'
                                : sample.expected === 'negative'
                                ? 'bg-rose-950 text-rose-400'
                                : 'bg-slate-800 text-slate-300'
                            }`}
                          >
                            Target: {sample.expected}
                          </span>
                        </div>
                        <p className="text-slate-300 line-clamp-2 group-hover:text-white transition">"{sample.text}"</p>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Column: Prediction Results Card */}
              <div className="lg:col-span-5 space-y-4">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl relative overflow-hidden">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <h3 className="text-sm font-semibold text-slate-200">Model Classification Output</h3>
                    <span className="text-xs font-mono text-slate-400">Lat: &lt;1.0ms</span>
                  </div>

                  {/* Top Predicted Banner */}
                  <div className="my-5 text-center p-4 rounded-xl bg-slate-950/80 border border-slate-800">
                    <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Identified Sentiment</span>
                    <div className="mt-1 flex items-center justify-center space-x-2">
                      <span
                        className={`text-2xl font-extrabold uppercase tracking-wide ${
                          prediction.class === 'positive'
                            ? 'text-emerald-400'
                            : prediction.class === 'negative'
                            ? 'text-rose-400'
                            : 'text-slate-300'
                        }`}
                      >
                        {prediction.class}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      Softmax Confidence: <span className="font-bold text-white">{prediction.probabilities[prediction.class]}%</span>
                    </p>
                  </div>

                  {/* Probability Breakdown Bars */}
                  <div className="space-y-3.5">
                    <p className="text-xs font-semibold text-slate-300">Multi-Class Probability Distribution:</p>

                    {/* Positive Bar */}
                    <div>
                      <div className="flex justify-between text-xs font-medium mb-1">
                        <span className="text-emerald-400 flex items-center space-x-1">
                          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                          <span>Positive Sentiment</span>
                        </span>
                        <span className="font-mono text-white">{prediction.probabilities.positive}%</span>
                      </div>
                      <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden p-0.5 border border-slate-800">
                        <div
                          className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                          style={{ width: `${prediction.probabilities.positive}%` }}
                        ></div>
                      </div>
                    </div>

                    {/* Neutral Bar */}
                    <div>
                      <div className="flex justify-between text-xs font-medium mb-1">
                        <span className="text-slate-400 flex items-center space-x-1">
                          <span className="w-2 h-2 rounded-full bg-slate-400"></span>
                          <span>Neutral / Factual</span>
                        </span>
                        <span className="font-mono text-white">{prediction.probabilities.neutral}%</span>
                      </div>
                      <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden p-0.5 border border-slate-800">
                        <div
                          className="bg-slate-400 h-full rounded-full transition-all duration-300"
                          style={{ width: `${prediction.probabilities.neutral}%` }}
                        ></div>
                      </div>
                    </div>

                    {/* Negative Bar */}
                    <div>
                      <div className="flex justify-between text-xs font-medium mb-1">
                        <span className="text-rose-400 flex items-center space-x-1">
                          <span className="w-2 h-2 rounded-full bg-rose-400"></span>
                          <span>Negative Sentiment</span>
                        </span>
                        <span className="font-mono text-white">{prediction.probabilities.negative}%</span>
                      </div>
                      <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden p-0.5 border border-slate-800">
                        <div
                          className="bg-rose-500 h-full rounded-full transition-all duration-300"
                          style={{ width: `${prediction.probabilities.negative}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>

                  {/* Architectural Insight Note */}
                  <div className="mt-5 p-3 rounded-xl bg-slate-800/50 border border-slate-700/60 text-xs text-slate-300 flex items-start space-x-2.5">
                    <Cpu className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-slate-200">How the model evaluates this:</p>
                      <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                        Raw text passes through sublinear TF-IDF weighting (unigrams + bigrams), retaining negation tokens. Logistic Regression then applies learned class coefficients with balanced weighting to score the polarity.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Pipeline Reproducibility Card */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-xs">
                  <div className="flex items-center justify-between text-slate-300 mb-2 font-medium">
                    <span>Exported Serialized Model</span>
                    <span className="text-emerald-400 font-mono">722.1 KB</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mb-2">
                    Artifact saved to <code className="text-slate-200 font-mono bg-slate-950 px-1 py-0.5 rounded">models/sentiment_pipeline_best.joblib</code>. Encapsulates preprocessing, TF-IDF, and classifier.
                  </p>
                  <button
                    onClick={() => setActiveTab('notebook')}
                    className="w-full py-1.5 px-3 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-200 font-medium transition flex items-center justify-center space-x-1.5"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Pipeline Code & Implementation</span>
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 2: EXPLORATORY DATA ANALYSIS & DISTRIBUTION */}
        {activeTab === 'eda' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-800 gap-4">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center space-x-2">
                    <BarChart3 className="w-5 h-5 text-emerald-400" />
                    <span>Exploratory Data Analysis: Real TweetEval Benchmark</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Canonical SemEval-2017 Task 4 Subtask A • 45,583 cleaned instances (3 contradictory texts dropped)
                  </p>
                </div>
                <div className="flex items-center space-x-2 text-xs">
                  <span className="px-3 py-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-300">
                    Source: Cardiff NLP
                  </span>
                  <span className="px-3 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-medium">
                    Zero Synthetic Data
                  </span>
                </div>
              </div>

              {/* Class Breakdown Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
                {PROJECT_METADATA.classes.map((cls) => (
                  <div key={cls.name} className="bg-slate-950 border border-slate-800 rounded-xl p-4 relative overflow-hidden">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{cls.label} Sentiment</span>
                      <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                        cls.name === 'positive' ? 'bg-emerald-950 text-emerald-400' :
                        cls.name === 'negative' ? 'bg-rose-950 text-rose-400' : 'bg-slate-800 text-slate-300'
                      }`}>
                        {cls.percentage}%
                      </span>
                    </div>
                    <h2 className="text-2xl font-extrabold text-white mt-2">{cls.count.toLocaleString()}</h2>
                    <p className="text-xs text-slate-500 mt-1">tweets annotated by human experts</p>
                    <div className="w-full bg-slate-900 rounded-full h-1.5 mt-3 overflow-hidden">
                      <div
                        className="h-full rounded-full"
                        style={{ width: `${cls.percentage}%`, backgroundColor: cls.color }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>

              {/* High-Resolution Figure Viewer */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6">
                <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col items-center justify-center">
                  <h4 className="text-xs font-semibold text-slate-400 mb-3 w-full text-left">
                    Generated Distribution Chart (<code className="text-slate-300">outputs/figures/sentiment_distribution.png</code>)
                  </h4>
                  <img
                    src="/figures/sentiment_distribution.png"
                    alt="Sentiment Class Distribution"
                    className="rounded-lg max-h-80 object-contain shadow-lg border border-slate-800/80"
                  />
                </div>

                <div className="lg:col-span-5 bg-slate-950 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-white mb-2 flex items-center space-x-2">
                      <AlertTriangle className="w-4 h-4 text-amber-400" />
                      <span>The Imbalance Dilemma & Metric Selection</span>
                    </h4>
                    <p className="text-xs text-slate-300 leading-relaxed space-y-2">
                      Notice that <strong className="text-emerald-400">Neutral (45.3%)</strong> and <strong className="text-blue-400">Positive (39.1%)</strong> dominate the corpus, while <strong className="text-rose-400">Negative (15.6%)</strong> represents a distinct minority.
                    </p>
                    <div className="mt-3 p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-1.5">
                      <p className="font-semibold text-slate-200">Why Overall Accuracy Fails:</p>
                      <p className="text-slate-400 text-[11px] leading-relaxed">
                        A dummy classifier predicting only majority classes could score 45.3% accuracy without correctly diagnosing a single frustrated customer. For this reason, <strong>Macro-Averaged F1</strong> is designated as our primary evaluation metric.
                      </p>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-800 text-xs text-slate-400">
                    <p>Stratification: 80% train (36,466) / 20% test (9,117) with verified identical class ratios.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: MODEL COMPARISON & BENCHMARK METRICS */}
        {activeTab === 'models' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center space-x-2">
                    <Scale className="w-5 h-5 text-emerald-400" />
                    <span>Model Comparison: Multinomial Naive Bayes vs Logistic Regression</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Evaluated on 9,117 held-out test tweets • Preprocessing & TF-IDF fitted solely on training data
                  </p>
                </div>
                <span className="px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-semibold">
                  Primary Metric: Macro F1
                </span>
              </div>

              {/* Main Comparison Table */}
              <div className="overflow-x-auto my-6">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Model Architecture</th>
                      <th className="py-3 px-3">Overall Accuracy</th>
                      <th className="py-3 px-3">Macro Precision</th>
                      <th className="py-3 px-3">Macro Recall</th>
                      <th className="py-3 px-3 text-emerald-400 font-bold">Macro F1 (Primary)</th>
                      <th className="py-3 px-3">Weighted F1</th>
                      <th className="py-3 px-3 text-rose-400 font-bold">Negative Recall</th>
                      <th className="py-3 px-3">Fit Time</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 font-mono">
                    <tr className="hover:bg-slate-800/30 transition">
                      <td className="py-3 px-4 font-sans font-medium text-slate-200">
                        Multinomial Naive Bayes
                        <span className="block text-[10px] font-mono text-slate-500">Laplace alpha=1.0</span>
                      </td>
                      <td className="py-3 px-3 text-slate-300">0.6229</td>
                      <td className="py-3 px-3 text-slate-300 font-bold">0.6324</td>
                      <td className="py-3 px-3 text-slate-400">0.5245</td>
                      <td className="py-3 px-3 text-slate-300">0.5286</td>
                      <td className="py-3 px-3 text-slate-400">0.5997</td>
                      <td className="py-3 px-3 text-rose-400 font-bold">16.50%</td>
                      <td className="py-3 px-3 text-slate-400 font-sans">2.51s</td>
                    </tr>

                    <tr className="bg-emerald-950/20 hover:bg-emerald-950/30 transition border-l-2 border-emerald-500">
                      <td className="py-3 px-4 font-sans font-bold text-emerald-300">
                        Logistic Regression (Balanced) ★
                        <span className="block text-[10px] font-mono text-emerald-500">class_weight='balanced', C=1.5</span>
                      </td>
                      <td className="py-3 px-3 text-emerald-400 font-bold">0.6369</td>
                      <td className="py-3 px-3 text-slate-300">0.6081</td>
                      <td className="py-3 px-3 text-emerald-400 font-bold">0.6333</td>
                      <td className="py-3 px-3 text-emerald-300 font-extrabold text-sm">0.6156</td>
                      <td className="py-3 px-3 text-emerald-400 font-bold">0.6411</td>
                      <td className="py-3 px-3 text-emerald-400 font-bold">61.35% (+272%)</td>
                      <td className="py-3 px-3 text-slate-400 font-sans">5.98s</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Technical Interpretation Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
                  <div className="flex items-center space-x-2 text-rose-400 font-semibold text-xs mb-2">
                    <AlertTriangle className="w-4 h-4" />
                    <span>The Multinomial Naive Bayes Failure Mode</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Multinomial Naive Bayes relies on generative prior probabilities $P(C_k)$. Because neutral and positive tweets together make up 84.4% of the training distribution, MNB strongly biases against negative predictions, achieving only <strong>16.5% recall on negative tweets</strong>. In a commercial help desk or CX setting, this would cause 83.5% of angry customer tweets to go undetected.
                  </p>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
                  <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs mb-2">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Why Balanced Logistic Regression Won</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    By enforcing <code>class_weight='balanced'</code>, the optimization loss scales misclassifications inversely to class frequencies. Negative recall surged from <strong>16.5% to 61.4%</strong>, driving the primary <strong>Macro F1 from 0.5286 to 0.6156</strong> (+8.70% absolute gain) with minimal fit time overhead (5.98s vs 2.51s).
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: CONFUSION MATRICES */}
        {activeTab === 'matrices' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center space-x-2">
                    <Sliders className="w-5 h-5 text-emerald-400" />
                    <span>Confusion Matrix Heatmap Analysis</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Comparing predictions against 9,117 ground-truth test labels (1,418 negative, 4,131 neutral, 3,568 positive)
                  </p>
                </div>

                <div className="flex rounded-lg bg-slate-950 p-1 border border-slate-800 text-xs">
                  <button
                    onClick={() => setSelectedModelForMatrix('logistic')}
                    className={`px-3 py-1 rounded-md transition ${
                      selectedModelForMatrix === 'logistic'
                        ? 'bg-emerald-500/20 text-emerald-300 font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Logistic Regression (Best)
                  </button>
                  <button
                    onClick={() => setSelectedModelForMatrix('naive_bayes')}
                    className={`px-3 py-1 rounded-md transition ${
                      selectedModelForMatrix === 'naive_bayes'
                        ? 'bg-blue-500/20 text-blue-300 font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Naive Bayes (Baseline)
                  </button>
                </div>
              </div>

              {/* Side-by-Side Images & Data */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 my-6 items-center">
                <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col items-center">
                  <h4 className="text-xs font-semibold text-slate-400 mb-2 w-full text-left">
                    {selectedModelForMatrix === 'logistic'
                      ? "Logistic Regression Confusion Matrix (outputs/figures/logistic_regression_confusion_matrix.png)"
                      : "Naive Bayes Confusion Matrix (outputs/figures/naive_bayes_confusion_matrix.png)"}
                  </h4>
                  <img
                    src={
                      selectedModelForMatrix === 'logistic'
                        ? "/figures/logistic_regression_confusion_matrix.png"
                        : "/figures/naive_bayes_confusion_matrix.png"
                    }
                    alt="Confusion Matrix"
                    className="rounded-lg max-h-84 object-contain shadow-md border border-slate-800"
                  />
                </div>

                <div className="lg:col-span-5 space-y-4">
                  <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
                    <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-2">Matrix Table Counts:</h4>
                    <table className="w-full text-xs text-left">
                      <thead className="text-[10px] uppercase text-slate-500 border-b border-slate-800">
                        <tr>
                          <th className="py-2">Ground Truth</th>
                          <th className="py-2">Pred Neg</th>
                          <th className="py-2">Pred Neu</th>
                          <th className="py-2">Pred Pos</th>
                          <th className="py-2 text-right">Class Recall</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/80 font-mono text-[11px]">
                        {(selectedModelForMatrix === 'logistic'
                          ? PROJECT_METADATA.confusionMatrices.logisticRegression
                          : PROJECT_METADATA.confusionMatrices.naiveBayes
                        ).map((row) => (
                          <tr key={row.actual} className="hover:bg-slate-800/30">
                            <td className="py-2 font-sans font-semibold text-slate-300">{row.actual}</td>
                            <td className={`py-2 ${row.actual === 'Negative' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
                              {row.predNegative.toLocaleString()}
                            </td>
                            <td className={`py-2 ${row.actual === 'Neutral' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
                              {row.predNeutral.toLocaleString()}
                            </td>
                            <td className={`py-2 ${row.actual === 'Positive' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
                              {row.predPositive.toLocaleString()}
                            </td>
                            <td className="py-2 text-right font-sans font-bold text-white">{row.recall}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/60 text-xs text-slate-300 space-y-1.5">
                    <p className="font-semibold text-slate-200">Critical Observation:</p>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      {selectedModelForMatrix === 'logistic'
                        ? "Balanced Logistic Regression achieves remarkably uniform diagonal accuracy (~61% across all three classes), resolving the severe skew of generative prior models."
                        : "Notice the top row: 927 out of 1,418 negative tweets (65.4%) were incorrectly classified as Neutral! Naive Bayes overwhelmingly collapsed on the negative class."}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: WORDCLOUDS & VOCABULARY */}
        {activeTab === 'wordclouds' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5 text-emerald-400" />
                    <span>Sentiment Lexical WordClouds (Generated from Real Tweets)</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Descriptive term frequency visualizations across positive, negative, and neutral subsets
                  </p>
                </div>

                <div className="flex rounded-lg bg-slate-950 p-1 border border-slate-800 text-xs">
                  <button
                    onClick={() => setSelectedWordCloud('positive')}
                    className={`px-3 py-1 rounded-md transition ${
                      selectedWordCloud === 'positive'
                        ? 'bg-emerald-500/20 text-emerald-300 font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Positive Class
                  </button>
                  <button
                    onClick={() => setSelectedWordCloud('negative')}
                    className={`px-3 py-1 rounded-md transition ${
                      selectedWordCloud === 'negative'
                        ? 'bg-rose-500/20 text-rose-300 font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Negative Class
                  </button>
                  <button
                    onClick={() => setSelectedWordCloud('neutral')}
                    className={`px-3 py-1 rounded-md transition ${
                      selectedWordCloud === 'neutral'
                        ? 'bg-blue-500/20 text-blue-300 font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Neutral Class
                  </button>
                </div>
              </div>

              {/* Main WordCloud Showcase */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 my-6 items-center">
                <div className="lg:col-span-8 bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col items-center">
                  <h4 className="text-xs font-semibold text-slate-400 mb-2 w-full text-left">
                    Rendered WordCloud Artifact (<code className="text-slate-300">outputs/figures/wordcloud_{selectedWordCloud}.png</code>)
                  </h4>
                  <img
                    src={`/figures/wordcloud_${selectedWordCloud}.png`}
                    alt={`${selectedWordCloud} WordCloud`}
                    className="rounded-lg w-full max-h-96 object-contain shadow-lg border border-slate-800"
                  />
                </div>

                <div className="lg:col-span-4 space-y-4">
                  <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
                    <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-2">Lexical Characteristics:</h4>
                    {selectedWordCloud === 'positive' && (
                      <p className="text-xs text-slate-300 leading-relaxed">
                        Dominated by affective admiration and gratitude: <span className="text-emerald-400 font-semibold">love, good, great, thank, happy, best, congrats, amazing, beautiful</span>. Terms cluster around celebratory milestones and customer endorsements.
                      </p>
                    )}
                    {selectedWordCloud === 'negative' && (
                      <p className="text-xs text-slate-300 leading-relaxed">
                        Dominated by grievances, disruption, and invective: <span className="text-rose-400 font-semibold">hate, bad, worst, delay, lost, shit, suck, never, miss, stop</span>. Captures immediate user dissatisfaction and service breakdowns.
                      </p>
                    )}
                    {selectedWordCloud === 'neutral' && (
                      <p className="text-xs text-slate-300 leading-relaxed">
                        Dominated by temporal coordinators and objective discourse: <span className="text-blue-400 font-semibold">tomorrow, tonight, game, watch, day, time, new, update, release, stream</span>. Lacks emotional charge; reflects announcements and factual updates.
                      </p>
                    )}
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/60 text-xs text-slate-300">
                    <p className="font-semibold text-slate-200">Data Science Note:</p>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                      WordClouds illustrate descriptive term prevalence across human-annotated labels; they are not causal model coefficients.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: QUALITATIVE ERROR ANALYSIS */}
        {activeTab === 'errors' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center space-x-2">
                    <AlertTriangle className="w-5 h-5 text-amber-400" />
                    <span>Linguistic Error Analysis: 5 Real Misclassified Test Cases</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Extracted from held-out test predictions (<code className="text-slate-300">outputs/predictions/misclassified_examples.csv</code>)
                  </p>
                </div>
                <span className="text-xs text-slate-400 bg-slate-950 px-3 py-1 rounded-lg border border-slate-800">
                  Model: Logistic Regression (TF-IDF)
                </span>
              </div>

              {/* Error Cards */}
              <div className="space-y-4 my-6">
                {PROJECT_METADATA.errorCases.map((err) => (
                  <div key={err.caseId} className="bg-slate-950 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <div className="flex items-center space-x-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300">
                          Case #{err.caseId}
                        </span>
                        <span className="text-xs font-semibold text-amber-400">{err.category}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-xs">
                        <span className="text-slate-400">Ground Truth:</span>
                        <span className={`px-2 py-0.5 rounded font-bold uppercase text-[11px] ${
                          err.actual === 'positive' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                          err.actual === 'negative' ? 'bg-rose-950 text-rose-400 border border-rose-800' : 'bg-slate-800 text-slate-300 border border-slate-700'
                        }`}>
                          {err.actual}
                        </span>
                        <span className="text-slate-500">→</span>
                        <span className="text-slate-400">Predicted:</span>
                        <span className={`px-2 py-0.5 rounded font-bold uppercase text-[11px] ${
                          err.predicted === 'positive' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                          err.predicted === 'negative' ? 'bg-rose-950 text-rose-400 border border-rose-800' : 'bg-slate-800 text-slate-300 border border-slate-700'
                        }`}>
                          {err.predicted}
                        </span>
                      </div>
                    </div>

                    <p className="text-sm font-mono text-slate-200 bg-slate-900/60 p-3 rounded-lg border border-slate-800/80 mb-3">
                      "{err.tweet}"
                    </p>

                    <div className="text-xs text-slate-300 flex items-start space-x-2">
                      <span className="font-semibold text-slate-400 shrink-0">Diagnosis:</span>
                      <span className="text-slate-400 leading-relaxed">{err.hypothesis}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 leading-relaxed">
                <p className="font-semibold text-slate-200 mb-1">Methodological Rigor:</p>
                As required by senior NLP engineering standards, errors are categorized with cautious hypotheses (negation inversion, multi-clause conjunctions, and tragic real-world entity spillover) rather than fabricating definitive root causes.
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: JUPYTER NOTEBOOK & REPORT */}
        {activeTab === 'notebook' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center space-x-2">
                    <Code className="w-5 h-5 text-emerald-400" />
                    <span>Jupyter Notebook & Technical Report Overview</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    File: <code className="text-slate-300">sentiment_analysis.ipynb</code> (43.2 KB, 18 complete executed sections)
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <a
                    href="#download"
                    onClick={(e) => {
                      e.preventDefault();
                      handleCopyInstall();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold transition flex items-center space-x-1.5"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Launch Code</span>
                  </a>
                </div>
              </div>

              {/* 18 Notebook Sections Summary */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 my-6 text-xs">
                {[
                  { num: "01", title: "Introduction & Business Context", tag: "Markdown" },
                  { num: "02", title: "Import Libraries & Load Real Dataset", tag: "Code + Output" },
                  { num: "03", title: "Inspect & Standardize Labels", tag: "Deduplication" },
                  { num: "04", title: "Visualize Sentiment Distribution", tag: "Matplotlib/Seaborn" },
                  { num: "05", title: "Text Preprocessing & Negation Preserving", tag: "NLTK + Lemmatizer" },
                  { num: "06", title: "TF-IDF Vectorization Explained", tag: "Theory & Equations" },
                  { num: "07", title: "Stratified 80/20 Train-Test Split", tag: "Zero Leakage" },
                  { num: "08", title: "Train Model 1: Multinomial Naive Bayes", tag: "Generative Model" },
                  { num: "09", title: "Train Model 2: Balanced Logistic Regression", tag: "Discriminative Model" },
                  { num: "10", title: "Comprehensive Evaluation on Test Set", tag: "Macro vs Weighted" },
                  { num: "11", title: "Confusion Matrix Diagnostics", tag: "3x3 Heatmaps" },
                  { num: "12", title: "WordClouds for Each Polarity", tag: "Lexical Prominence" },
                  { num: "13", title: "Qualitative Error Analysis (5 cases)", tag: "Linguistic Diagnosis" },
                  { num: "14", title: "Model Comparison & Best Selection", tag: "Macro F1 Decision" },
                  { num: "15", title: "Rule-Based Lexicon Baseline Context", tag: "VADER / TextBlob" },
                  { num: "16", title: "Serialize Pipeline Artifact (Joblib)", tag: "722 KB Model" },
                  { num: "17", title: "Conclusion & Business Applications", tag: "ROI & Deployment" },
                  { num: "18", title: "Limitations & Ethical Guardrails", tag: "Fairness & Bias" }
                ].map((sec) => (
                  <div key={sec.num} className="bg-slate-950 border border-slate-800 p-3 rounded-xl flex items-center justify-between">
                    <div className="flex items-center space-x-2.5">
                      <span className="w-6 h-6 rounded-md bg-slate-800 flex items-center justify-center font-mono text-[10px] text-slate-300 font-bold">
                        {sec.num}
                      </span>
                      <span className="font-medium text-slate-200">{sec.title}</span>
                    </div>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                      {sec.tag}
                    </span>
                  </div>
                ))}
              </div>

              {/* Code Snippet from Notebook */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs font-mono">
                <div className="flex items-center justify-between text-slate-400 pb-2 mb-3 border-b border-slate-800">
                  <span className="font-sans font-semibold text-slate-300">Model Inference Verification (from Section 16):</span>
                  <span>Python 3.10+</span>
                </div>
                <pre className="text-emerald-400 overflow-x-auto text-[11px] leading-relaxed">
{`import joblib

# Load serialized pipeline
pipeline = joblib.load("models/sentiment_pipeline_best.joblib")

tweets = [
    "I am thrilled with this amazing update! Outstanding performance.",
    "This was the most frustrating service experience I have ever had. Terrible.",
    "The conference starts tomorrow morning at 9:00 AM in Hall B."
]

preds = pipeline.predict(tweets)
probs = pipeline.predict_proba(tweets)

for text, p, pr in zip(tweets, preds, probs):
    conf = max(pr) * 100
    print(f"[{p.upper()}] ({conf:.1f}% confidence): {text}")

# Actual Output:
# [POSITIVE] (94.9% confidence): I am thrilled with this amazing update! Outstanding performance.
# [NEGATIVE] (86.6% confidence): This was the most frustrating service experience I have ever had. Terrible.
# [NEUTRAL] (68.4% confidence): The conference starts tomorrow morning at 9:00 AM in Hall B.`}
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* TAB 8: GITHUB FILE TREE */}
        {activeTab === 'files' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center space-x-2">
                    <Folder className="w-5 h-5 text-emerald-400" />
                    <span>Project File Structure & GitHub Repository</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Directory: <code className="text-slate-300">OIBSIP/DataAnalytics/Level1_Task4_Sentiment_Analysis/</code>
                  </p>
                </div>
                <div className="flex items-center space-x-2 text-xs">
                  <span className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-mono">100% Prepared for GitHub</span>
                </div>
              </div>

              {/* Tree View */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 my-6 font-mono text-xs text-slate-300 space-y-2">
                <div className="text-emerald-400 font-bold">OIBSIP/DataAnalytics/Level1_Task4_Sentiment_Analysis/</div>
                <div className="pl-4 space-y-1.5">
                  <div className="flex items-center space-x-2 text-slate-200">
                    <FileText className="w-4 h-4 text-blue-400" />
                    <span>README.md</span>
                    <span className="text-[10px] text-slate-500 font-sans">(Comprehensive project guide & setup)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-200">
                    <Code className="w-4 h-4 text-emerald-400" />
                    <span>sentiment_analysis.ipynb</span>
                    <span className="text-[10px] text-slate-500 font-sans">(Primary deliverable, 43.2 KB, 18 sections)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-200">
                    <File className="w-4 h-4 text-amber-400" />
                    <span>run_pipeline.py</span>
                    <span className="text-[10px] text-slate-500 font-sans">(Full reproducible Python execution script)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-200">
                    <File className="w-4 h-4 text-purple-400" />
                    <span>requirements.txt</span>
                    <span className="text-[10px] text-slate-500 font-sans">(pandas, scikit-learn, nltk, seaborn, wordcloud)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-200">
                    <File className="w-4 h-4 text-slate-500" />
                    <span>.gitignore</span>
                    <span className="text-[10px] text-slate-500 font-sans">(excludes .venv, checkpoints, __pycache__)</span>
                  </div>
                  
                  {/* data */}
                  <div className="pt-1">
                    <div className="flex items-center space-x-2 text-emerald-400 font-semibold">
                      <Folder className="w-4 h-4" />
                      <span>data/</span>
                    </div>
                    <div className="pl-6 space-y-1 text-slate-400">
                      <div className="flex items-center space-x-2">
                        <FileText className="w-3.5 h-3.5 text-blue-400" />
                        <span>README.md (Dataset schema, citation & download steps)</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <File className="w-3.5 h-3.5 text-slate-500" />
                        <span>twitter_sentiment_dataset.csv (45,583 rows, TweetEval SemEval-2017)</span>
                      </div>
                    </div>
                  </div>

                  {/* models */}
                  <div className="pt-1">
                    <div className="flex items-center space-x-2 text-emerald-400 font-semibold">
                      <Folder className="w-4 h-4" />
                      <span>models/</span>
                    </div>
                    <div className="pl-6 space-y-1 text-slate-400">
                      <div className="flex items-center space-x-2">
                        <FileText className="w-3.5 h-3.5 text-blue-400" />
                        <span>README.md (Model serialization & security instructions)</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <File className="w-3.5 h-3.5 text-emerald-400" />
                        <span>sentiment_pipeline_best.joblib (722.1 KB fitted pipeline)</span>
                      </div>
                    </div>
                  </div>

                  {/* outputs */}
                  <div className="pt-1">
                    <div className="flex items-center space-x-2 text-emerald-400 font-semibold">
                      <Folder className="w-4 h-4" />
                      <span>outputs/</span>
                    </div>
                    <div className="pl-6 space-y-1 text-slate-400">
                      <div>📁 figures/ (sentiment_distribution.png, confusion matrices, wordclouds)</div>
                      <div>📁 metrics/ (model_comparison.csv, classification reports, summary_metadata.json)</div>
                      <div>📁 predictions/ (misclassified_examples.csv with error hypotheses)</div>
                    </div>
                  </div>

                  {/* reports */}
                  <div className="pt-1">
                    <div className="flex items-center space-x-2 text-emerald-400 font-semibold">
                      <Folder className="w-4 h-4" />
                      <span>reports/</span>
                    </div>
                    <div className="pl-6 space-y-1 text-slate-400">
                      <div className="flex items-center space-x-2">
                        <FileText className="w-3.5 h-3.5 text-blue-400" />
                        <span>sentiment_analysis_report.md (Comprehensive 13-section report)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* GitHub Staging Instructions */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs">
                <p className="font-semibold text-slate-200 mb-2">GitHub Push / Staging Instructions:</p>
                <pre className="bg-slate-900 p-3 rounded-lg text-slate-300 font-mono text-[11px] overflow-x-auto">
{`# Initialize or stage inside your OIBSIP repository:
git add OIBSIP/DataAnalytics/Level1_Task4_Sentiment_Analysis/
git commit -m "feat(nlp): complete Level 1 Task 4 Sentiment Analysis pipeline with real dataset"
git push origin main`}
                </pre>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <div>
            <span>Oasis Infobyte Internship Program (OIBSIP) • Data Analytics Track</span>
          </div>
          <div className="flex items-center space-x-4">
            <span>TweetEval Benchmark (CC BY 4.0)</span>
            <span>•</span>
            <span>Scikit-Learn & Python 3.10+</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
