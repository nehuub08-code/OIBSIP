// Comprehensive metadata and true experimental metrics for OIBSIP Data Analytics Level 1 Task 4
import modelCoefficients from './model_coefficients.json';

export interface SentimentResult {
  class: 'positive' | 'negative' | 'neutral';
  probabilities: {
    positive: number;
    negative: number;
    neutral: number;
  };
  matchedTokens: {
    token: string;
    weight: number;
    polarity: 'positive' | 'negative' | 'neutral';
  }[];
}

export const PROJECT_METADATA = {
  track: "Data Analytics",
  level: "Level 1",
  task: "Task 4 — Sentiment Analysis",
  program: "Oasis Infobyte Internship Program (OIBSIP)",
  datasetName: "TweetEval Benchmark (SemEval-2017 Task 4 Subtask A)",
  datasetUrl: "https://github.com/cardiffnlp/tweeteval",
  license: "Creative Commons Attribution 4.0 International (CC BY 4.0)",
  totalSamples: 45583,
  trainSamples: 36466,
  testSamples: 9117,
  splitRatio: "80% Train / 20% Test (Stratified)",
  classes: [
    { name: "neutral", label: "Neutral", count: 20653, percentage: 45.31, color: "#64748B", badge: "bg-slate-100 text-slate-800 border-slate-300 dark:bg-slate-800 dark:text-slate-200 dark:border-slate-700" },
    { name: "positive", label: "Positive", count: 17839, percentage: 39.14, color: "#10B981", badge: "bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-200 dark:border-emerald-800" },
    { name: "negative", label: "Negative", count: 7091, percentage: 15.56, color: "#EF4444", badge: "bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-950 dark:text-rose-200 dark:border-rose-800" },
  ],
  models: [
    {
      name: "Multinomial Naive Bayes",
      type: "Generative Probabilistic Classifier",
      accuracy: 0.6229,
      macroPrecision: 0.6324,
      macroRecall: 0.5245,
      macroF1: 0.5286,
      weightedF1: 0.5997,
      fitTime: "2.51s",
      negPrecision: 0.6429,
      negRecall: 0.1650,
      negF1: 0.2626,
      neuPrecision: 0.5984,
      neuRecall: 0.7453,
      neuF1: 0.6639,
      posPrecision: 0.6558,
      posRecall: 0.6631,
      posF1: 0.6594,
      description: "Applies Bayes' theorem under feature independence assumption. Extremely rapid to fit, but empirical class priors severely handicap minority class recall."
    },
    {
      name: "Logistic Regression (Balanced)",
      type: "Discriminative Log-Linear Model (Winner)",
      accuracy: 0.6369,
      macroPrecision: 0.6081,
      macroRecall: 0.6333,
      macroF1: 0.6156,
      weightedF1: 0.6411,
      fitTime: "5.98s",
      negPrecision: 0.4429,
      negRecall: 0.6135,
      negF1: 0.5145,
      neuPrecision: 0.6830,
      neuRecall: 0.6112,
      neuF1: 0.6451,
      posPrecision: 0.7070,
      posRecall: 0.6777,
      posF1: 0.6920,
      description: "Optimizes multinomial cross-entropy with L2 regularization and inverse class frequency weighting. Restores balanced recall (+272% on negative class)."
    }
  ],
  confusionMatrices: {
    naiveBayes: [
      { actual: "Negative", predNegative: 234, predNeutral: 927, predPositive: 257, recall: "16.5%" },
      { actual: "Neutral", predNegative: 100, predNeutral: 3079, predPositive: 952, recall: "74.5%" },
      { actual: "Positive", predNegative: 30, predNeutral: 1173, predPositive: 2365, recall: "66.3%" }
    ],
    logisticRegression: [
      { actual: "Negative", predNegative: 870, predNeutral: 348, predPositive: 200, recall: "61.4%" },
      { actual: "Neutral", predNegative: 638, predNeutral: 2525, predPositive: 968, recall: "61.1%" },
      { actual: "Positive", predNegative: 456, predNeutral: 694, predPositive: 2418, recall: "67.8%" }
    ]
  },
  sampleTweets: [
    { text: "Outstanding customer service and lightning fast delivery! So thrilled with this purchase.", expected: "positive", category: "Praise & Delight" },
    { text: "Worst delay ever. Ground staff were rude, baggage was lost, and zero compensation offered.", expected: "negative", category: "Severe Grievance" },
    { text: "Flight 412 is scheduled to depart gate 14 at 4:30 PM tomorrow.", expected: "neutral", category: "Factual Schedule" },
    { text: "The camera is fantastic but battery life doesn't even last half a day.", expected: "negative", category: "Mixed Conjunction" },
    { text: "We are no way losing this championship! Let's go team!", expected: "positive", category: "Negation Idiom" },
    { text: "Don't forget the webinar begins at 11 AM sharp on Monday morning.", expected: "neutral", category: "Event Reminder" }
  ],
  errorCases: [
    {
      caseId: 1,
      tweet: "@user This is like my 3rd msg about this but im dumb. Do you know kane's # anymore? i lost it. Also hope everythings good and stuff",
      actual: "positive",
      predicted: "negative",
      hypothesis: "Negation / Self-Deprecating Slang: Model heavily penalized negative polarity terms ('dumb', 'lost') over the closing positive cordiality ('hope everythings good').",
      category: "Self-Deprecating Language"
    },
    {
      caseId: 2,
      tweet: "We are no way losing it! C'mon you little monsters ! #MTVStars Lady Gaga",
      actual: "positive",
      predicted: "negative",
      hypothesis: "Negation Inversion: The colloquial double negative ('no way losing') represents an emphatic victory chant, but the linear model penalized 'no' and 'losing'.",
      category: "Colloquial Double Negative"
    },
    {
      caseId: 3,
      tweet: "I'm going to try to get it done before I see Shawn tomorrow but I don't think it's gunna happen",
      actual: "negative",
      predicted: "neutral",
      hypothesis: "Mixed Sentiment Multi-Clause: Factual scheduling prefix ('try to get it done before I see Shawn') diluted the disappointed conclusion ('don't think it's gunna happen').",
      category: "Clause Conjunction"
    },
    {
      caseId: 4,
      tweet: "Don't Forget The Classical Brit Awards At 10pm tonight for a Special appearance of the 25th anniversary Cast of Phantom for 26th Bday??",
      actual: "neutral",
      predicted: "positive",
      hypothesis: "Subjective Term False Trigger: Promotional reminder contains polarity modifiers ('Special', 'Bday') triggering positive classification on a factual announcement.",
      category: "Promotional Fact"
    },
    {
      caseId: 5,
      tweet: "I'm in the south but my greatest desire is to see an end to Boko Haram. May God help our @user president. @user",
      actual: "positive",
      predicted: "negative",
      hypothesis: "Tragic Entity Spillover: Mention of extremist organization ('Boko Haram') carried strong negative weights that outweighed the affirmative civic prayer.",
      category: "Tragic Real-World Entity"
    }
  ]
};

// Client-side scoring algorithm simulating the trained Logistic Regression pipeline
export function predictSentiment(inputText: string): SentimentResult {
  const text = inputText.toLowerCase();
  const tokens = text.match(/\b[a-zA-Z']+\b/g) || [];
  
  let posScore = 0.1;
  let negScore = 0.0;
  let neuScore = 0.3; // Slight prior for neutral factual statements
  
  const matchedTokens: SentimentResult['matchedTokens'] = [];

  // Check extracted coefficients from the trained model
  const topNeg = new Map(modelCoefficients.top_words.negative.map(w => [w.word, w.weight]));
  const topPos = new Map(modelCoefficients.top_words.positive.map(w => [w.word, w.weight]));
  const topNeu = new Map(modelCoefficients.top_words.neutral.map(w => [w.word, w.weight]));

  // Common sentiment heuristics aligned with the trained model
  const negations = new Set(["not", "no", "never", "can't", "cannot", "n't", "barely", "hardly", "neither"]);
  let hasNegation = false;

  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    if (negations.has(t)) {
      hasNegation = true;
    }

    if (topNeg.has(t)) {
      const w = topNeg.get(t) || 1.5;
      negScore += w;
      matchedTokens.push({ token: t, weight: w, polarity: 'negative' });
    }
    if (topPos.has(t)) {
      const w = topPos.get(t) || 1.5;
      if (hasNegation && i > 0 && negations.has(tokens[i - 1])) {
        // Invert if directly preceded by negation
        negScore += w * 0.9;
        matchedTokens.push({ token: `${tokens[i - 1]} ${t}`, weight: w, polarity: 'negative' });
      } else {
        posScore += w;
        matchedTokens.push({ token: t, weight: w, polarity: 'positive' });
      }
    }
    if (topNeu.has(t)) {
      const w = topNeu.get(t) || 1.0;
      neuScore += w * 0.5;
      matchedTokens.push({ token: t, weight: w, polarity: 'neutral' });
    }
  }

  // Softmax normalization
  const expPos = Math.exp(posScore);
  const expNeg = Math.exp(negScore);
  const expNeu = Math.exp(neuScore);
  const sumExp = expPos + expNeg + expNeu;

  const probPos = expPos / sumExp;
  const probNeg = expNeg / sumExp;
  const probNeu = expNeu / sumExp;

  let predictedClass: 'positive' | 'negative' | 'neutral' = 'neutral';
  if (probPos >= probNeg && probPos >= probNeu) {
    predictedClass = 'positive';
  } else if (probNeg >= probPos && probNeg >= probNeu) {
    predictedClass = 'negative';
  } else {
    predictedClass = 'neutral';
  }

  return {
    class: predictedClass,
    probabilities: {
      positive: Math.round(probPos * 1000) / 10,
      negative: Math.round(probNeg * 1000) / 10,
      neutral: Math.round(probNeu * 1000) / 10
    },
    matchedTokens: matchedTokens.slice(0, 10)
  };
}
