# Aivanta — Minimalist AI Brand Identity & Logo Design System

**Designer:** Neha Vinod Borkar  
**Internship Track:** Graphics Design  
**Task Title:** Task 2 — Logo Design  
**GitHub Repository:** `OIBSIP`  
**Design Tools:** Figma / Adobe Illustrator (Vector geometry, typography, and optical kerning)

---

## 1. Project Overview & Brand Identity

**Aivanta** is a fictional artificial intelligence and productivity technology startup. The company's mission is to empower professionals, developers, students, and startups to work smarter through accessible, intelligent tools.

- **Brand Name:** Aivanta
- **Industry:** Artificial Intelligence & Productivity Technology
- **Brand Tagline:** *Intelligence. In Motion.*
- **Target Audience:** Developers, modern professionals, startups, researchers, and technology enthusiasts.
- **Brand Personality:**
  - Intelligent & Analytical
  - Modern & Forward-Leaning
  - Trustworthy & Secure
  - Minimalist & Refined
  - Innovative
  - Approachable & Ergonomic

---

## 2. Design Concept & Symbolism

The Aivanta logo mark is an original geometric emblem built from pure mathematical vectors that synthesize three core ideas:

1. **The Ascendant Apex ("A"):** An abstract, upward-surging letterform representing the initial of Aivanta and continuous human advancement.
2. **Dual-Convergence Struts:** 
   - *Left Foundation Pillar (Navy):* Represents human grounding, structural rigor, and trust.
   - *Right Kinetic Wing (Electric Blue):* Represents AI velocity, acceleration, and adaptive intelligence.
3. **Neural Connection Bridge:** A horizontal nexus linking both pillars, symbolizing synaptic data transfer and collaborative synthesis.
4. **Internal Delta Negative Space:** A calibrated triangular aperture that provides optical breathing room and immediate micro-scale legibility.

### Concept Exploration & Evaluation

Three distinct concepts were drafted and evaluated:
- **Concept 1: The Ascendant Nexus / Dynamic "A" (Selected & Refined):** Score 9.6/10. Unites letterform, kinetic motion, and negative space with exceptional optical reduction down to 16px.
- **Concept 2: Neural Delta Mesh:** Score 7.4/10. Formed by three interconnected nodes. While strong in AI symbolism, it compromised legibility below 32px.
- **Concept 3: Continuous Kinetic Loop:** Score 7.8/10. An unclosed Möbius-style loop. Dynamic, but lacked enterprise trust and architectural authority.

---

## 3. Brand Colour Palette

| Colour Name | Hex Code | RGB | CMYK | Purpose & Psychological Impact |
|:---|:---|:---|:---|:---|
| **Deep Navy** | `#101828` | `16, 24, 40` | `88, 77, 51, 65` | Foundational stability, depth, enterprise trust, and primary typography. |
| **Electric Blue** | `#3867FF` | `56, 103, 255` | `75, 55, 0, 0` | Neural intelligence, kinetic energy, technological innovation, and accent focus. |
| **Pure White** | `#FFFFFF` | `255, 255, 255` | `0, 0, 0, 0` | Clean negative space, dark-mode reversals, and high contrast. |
| **Solid Black** | `#000000` | `0, 0, 0` | `0, 0, 0, 100` | 1-ink monochrome reproduction, stamps, embossing, and physical print. |

---

## 4. Typography Specifications

- **Primary Typeface:** *Plus Jakarta Sans*
- **Wordmark Weight:** SemiBold (`font-weight: 600`)
- **Wordmark Tracking:** `-0.025em` (`-25`) for tight, cohesive architectural presence.
- **Tagline Weight:** Medium (`font-weight: 500`)
- **Tagline Tracking:** `+0.14em` (`+140`) uppercase for balanced optical width beneath the wordmark.
- **Alignment:** Baseline-calibrated with the lower edge of the neural bridge.

---

## 5. Mandatory Logo Variants

All three variants maintain identical vector geometry and optical proportions:

1. **Variant A — Full Colour (`Aivanta-Full-Colour`):** Electric Blue (`#3867FF`) and Deep Navy (`#101828`) on transparent background. Used as the primary brand asset for light interfaces, corporate website headers, and promotional collateral.
2. **Variant B — Monochrome Black (`Aivanta-Monochrome-Black`):** Solid Black (`#000000`) on transparent background. Engineered for single-color print, laser engraving, invoices, packaging, and embroidery.
3. **Variant C — Reversed White (`Aivanta-Reversed-White`):** Solid White (`#FFFFFF`) artwork on transparent background, previewed against Deep Navy (`#101828`). Engineered for dark UI modes, developer consoles, and dark backdrops.

---

## 6. Directory Structure & Verified Deliverables

```
OIBSIP/
└── Graphics-Design/
    └── Task-2-Logo-Design/
        ├── README.md
        ├── design-rationale.md
        ├── linkedin-post.md
        ├── presentation/
        │   └── Aivanta-Logo-Presentation.png      [1920 × 1080 px, High-Res Canvas]
        ├── source/
        │   ├── Aivanta-Logo-Editable.svg          [Scalable Vector with editable text & paths]
        │   └── Aivanta-Logo-Source.ai             [Source Note & Vector Interchange Guide]
        └── exports/
            ├── Aivanta-Full-Colour.svg            [Scalable Vector Graphic]
            ├── Aivanta-Monochrome-Black.svg       [Scalable Vector Graphic]
            ├── Aivanta-Reversed-White.svg         [Scalable Vector Graphic]
            ├── Aivanta-Full-Colour.png            [1200 × 1200 px, 300 DPI, Transparent]
            ├── Aivanta-Monochrome-Black.png       [1200 × 1200 px, 300 DPI, Transparent]
            └── Aivanta-Reversed-White.png         [1200 × 1200 px, 300 DPI, Transparent]
```

*Note on `Aivanta-Logo-Source.ai`: Per Rule 9, rather than providing an incompatible fake binary file, the editable SVG is fully compatible with Adobe Illustrator (File > Open > SVG preserves all layers, shapes, and text) and Figma (Direct Drag & Drop).*

---

## 7. Quality Assurance Checklist

- [x] Original concept (no template modifications, stock icons, or AI cliparts).
- [x] Symbol communicates intelligence, progress, and connectivity.
- [x] Strict minimalist geometry with zero extraneous decoration.
- [x] Variant A (Full Colour) generated and verified.
- [x] Variant B (Monochrome Black) generated and verified.
- [x] Variant C (Reversed White) generated and verified.
- [x] Vector source SVGs open cleanly in Illustrator, Figma, and browsers.
- [x] PNG exports have transparent backgrounds.
- [x] PNG dimensions verified at 1200 × 1200 px (exceeds the 1000 × 1000 px requirement).
- [x] Typography spacing and optical kerning verified.
- [x] Micro-scale recognizability verified at 16px, 24px, 32px, and 48px.
- [x] Presentation Sheet created (1920 × 1080 px).
- [x] 2–3 sentence LinkedIn Design Rationale prepared in `design-rationale.md`.
- [x] Full LinkedIn submission post prepared in `linkedin-post.md`.
- [x] Clean directory layout under `OIBSIP/Graphics-Design/Task-2-Logo-Design/`.
