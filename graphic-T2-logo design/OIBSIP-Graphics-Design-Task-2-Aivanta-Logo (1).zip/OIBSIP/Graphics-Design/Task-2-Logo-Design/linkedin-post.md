# LinkedIn Post — Aivanta Logo Design Showcase

🚀 Excited to share my latest brand identity project: **Aivanta — Intelligence. In Motion.**

As part of my **Graphics Design Internship at Oasis Infobyte (OIBSIP — Task 2: Logo Design)**, I had the opportunity to develop a comprehensive, minimalist brand identity for a fictional artificial intelligence and productivity startup.

### 💡 The Design Challenge
Create an original, scalable, and modern visual symbol that avoids generic AI clichés (like stock robot heads or complex brain illustrations) while visually communicating **intelligence, progress, and human-machine connectivity**.

### 📐 The Concept: The Ascendant Nexus
The mark combines an architectural, upward-surging "A" with a forward kinetic wing and a central neural connection bridge. The dual-color convergence highlights the synthesis between human creativity (deep navy foundation) and intelligent computational velocity (electric blue). An internal negative-space delta aperture ensures the mark remains razor-sharp from a 16px mobile favicon to billboard-scale environmental signage.

### 🎨 Design System Specifications:
- **Colour Palette:** Electric Blue (`#3867FF`), Deep Navy (`#101828`), Pure White (`#FFFFFF`), and Solid Black (`#000000`).
- **Typography:** Plus Jakarta Sans (SemiBold 600 wordmark with `-25` optical kerning).
- **Core Deliverables:** Full-Colour, Monochrome Black, and Reversed White variants in scalable vector SVGs and transparent 1200×1200px PNGs, accompanied by an interactive brand presentation sheet.
- **Tools Used:** Figma, Adobe Illustrator, and mathematical vector geometry.

*Disclaimer: Aivanta is a fictional brand created exclusively for educational and portfolio demonstration during the OIBSIP Graphics Design internship.*

I’d love to hear your thoughts and feedback on the symbol and lockup! 👇

#GraphicDesign #LogoDesign #BrandIdentity #VisualIdentity #Minimalism #UIUX #OasisInfobyte #OIBSIP #InternshipProject #TechBranding #Portfolio
