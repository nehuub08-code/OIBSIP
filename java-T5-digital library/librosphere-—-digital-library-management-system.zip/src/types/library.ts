export type UserRole = 'ADMIN' | 'USER';
export type AccountStatus = 'ACTIVE' | 'DEACTIVATED';

export interface User {
  id: string;
  fullName: string;
  email: string;
  username: string;
  role: UserRole;
  accountStatus: AccountStatus;
  createdAt: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  isbn: string;
  category: string;
  totalQuantity: number;
  availableQuantity: number;
  description: string;
  shelfLocation: string;
  createdAt: string;
  updatedAt: string;
}

export interface BookIssue {
  id: string;
  userId: string;
  bookId: string;
  issueDate: string;
  dueDate: string;
  returnDate: string | null;
  status: 'ACTIVE' | 'RETURNED';
  fineAmount: number;
  createdAt: string;
  bookTitle?: string;
  bookAuthor?: string;
  bookIsbn?: string;
  memberName?: string;
  memberUsername?: string;
  memberEmail?: string;
  isOverdue?: boolean;
  estimatedOverdueFine?: number;
}

export interface Reservation {
  id: string;
  userId: string;
  bookId: string;
  reservationDate: string;
  status: 'PENDING' | 'READY_FOR_PICKUP' | 'FULFILLED' | 'CANCELLED';
  queuePosition: number;
  expiryDate: string | null;
  createdAt: string;
  bookTitle?: string;
  bookAuthor?: string;
  bookIsbn?: string;
  bookAvailable?: number;
  memberName?: string;
  memberUsername?: string;
  memberEmail?: string;
}

export interface Fine {
  id: string;
  bookIssueId: string;
  userId: string;
  bookId: string;
  amount: number;
  status: 'UNPAID' | 'PAID';
  calculatedTimestamp: string;
  paidTimestamp: string | null;
  bookTitle?: string;
  memberName?: string;
  memberUsername?: string;
  memberEmail?: string;
}

export interface ContactMessage {
  id: string;
  userId: string | null;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: 'NEW' | 'IN_PROGRESS' | 'RESOLVED';
  createdAt: string;
}

export interface AdminOverview {
  counts: {
    totalBooks: number;
    availableCopies: number;
    issuedCopies: number;
    registeredMembers: number;
    outstandingFines: number;
    pendingQueries: number;
    pendingReservations: number;
  };
  issues: BookIssue[];
  members: Array<{
    id: string;
    fullName: string;
    email: string;
    username: string;
    accountStatus: AccountStatus;
    createdAt: string;
    activeIssueCount: number;
    unpaidFinesTotal: number;
    totalHistoryCount: number;
  }>;
  fines: Fine[];
  reservations: Reservation[];
  contacts: ContactMessage[];
}

export interface UserDashboardData {
  user: User;
  activeIssueCount: number;
  unpaidFineTotal: number;
  issues: BookIssue[];
  reservations: Reservation[];
  fines: Fine[];
  queries: ContactMessage[];
}
