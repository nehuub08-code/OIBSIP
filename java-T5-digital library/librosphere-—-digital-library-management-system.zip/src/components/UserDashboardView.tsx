import React, { useState } from 'react';
import { UserDashboardData, BookIssue, Fine, Reservation, ContactMessage } from '../types/library';
import { BookOpen, AlertCircle, Clock, CheckCircle2, Bookmark, IndianRupee, RotateCcw, X, MessageSquare, ShieldAlert } from 'lucide-react';

interface UserDashboardViewProps {
  dashboardData: UserDashboardData;
  onReturnBook: (issueId: string, simulatedDate?: string) => Promise<void>;
  onCancelReservation: (reservationId: string) => Promise<void>;
  onNavigateToCatalogue: () => void;
  onNavigateToContact: () => void;
  onRefresh: () => void;
}

export const UserDashboardView: React.FC<UserDashboardViewProps> = ({
  dashboardData,
  onReturnBook,
  onCancelReservation,
  onNavigateToCatalogue,
  onNavigateToContact,
  onRefresh,
}) => {
  const { user, activeIssueCount, unpaidFineTotal, issues, reservations, fines, queries } = dashboardData;
  const [returningIssue, setReturningIssue] = useState<BookIssue | null>(null);
  const [simulatedDaysLate, setSimulatedDaysLate] = useState<number>(0);
  const [isSubmittingReturn, setIsSubmittingReturn] = useState(false);

  const activeIssues = issues.filter((i) => i.status === 'ACTIVE');
  const returnedIssues = issues.filter((i) => i.status === 'RETURNED');
  const pendingReservations = reservations.filter((r) => r.status === 'PENDING' || r.status === 'READY_FOR_PICKUP');

  const handleReturnSubmit = async () => {
    if (!returningIssue) return;
    try {
      setIsSubmittingReturn(true);
      let returnDateStr: string | undefined;

      if (simulatedDaysLate > 0) {
        const dueDate = new Date(returningIssue.dueDate);
        dueDate.setDate(dueDate.getDate() + simulatedDaysLate);
        returnDateStr = dueDate.toISOString().split('T')[0];
      }

      await onReturnBook(returningIssue.id, returnDateStr);
      setReturningIssue(null);
      setSimulatedDaysLate(0);
    } finally {
      setIsSubmittingReturn(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Welcome Banner */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-mono text-stone-500">
            <span>Member ID: {user.id}</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-700 font-medium">Account Status: {user.accountStatus}</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-stone-900">
            Welcome back, {user.fullName}
          </h1>
          <p className="text-xs sm:text-sm text-stone-500">
            Access your active book loans, track due dates, view waitlist reservations, and review fine balances.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onNavigateToCatalogue}
            className="px-4 py-2 text-xs font-semibold text-white bg-amber-800 hover:bg-amber-900 rounded-xl transition-colors shadow-xs"
          >
            Browse Catalogue
          </button>
          <button
            onClick={onRefresh}
            className="px-3 py-2 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors"
          >
            Refresh
          </button>
        </div>
      </div>

      {/* KPI Stat Cards (Single-Elevation, Tabular figures) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Stat 1: Active Loans */}
        <div className="bg-white border border-stone-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-stone-500 mb-2">
            <span className="text-xs font-medium">Active Loans</span>
            <BookOpen className="w-4 h-4 text-stone-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-stone-900 font-mono tabular-nums">
              {activeIssueCount}
            </span>
            <span className="text-xs text-stone-400 font-mono">/ 3 max</span>
          </div>
          <p className="text-[11px] text-stone-500 mt-1">14-day borrowing duration</p>
        </div>

        {/* Stat 2: Outstanding Fines */}
        <div className={`border rounded-xl p-5 shadow-xs ${unpaidFineTotal > 0 ? 'bg-amber-50/50 border-amber-200' : 'bg-white border-stone-200'}`}>
          <div className="flex items-center justify-between text-stone-500 mb-2">
            <span className="text-xs font-medium">Outstanding Fines</span>
            <IndianRupee className={`w-4 h-4 ${unpaidFineTotal > 0 ? 'text-amber-700' : 'text-stone-400'}`} />
          </div>
          <div className="flex items-baseline gap-1">
            <span className={`text-2xl font-bold font-mono tabular-nums ${unpaidFineTotal > 0 ? 'text-amber-800' : 'text-stone-900'}`}>
              ₹{unpaidFineTotal}
            </span>
          </div>
          <p className="text-[11px] text-stone-500 mt-1">
            {unpaidFineTotal > 0 ? 'Clear at Library Admin Desk' : 'No overdue penalties due'}
          </p>
        </div>

        {/* Stat 3: Waitlist Reservations */}
        <div className="bg-white border border-stone-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-stone-500 mb-2">
            <span className="text-xs font-medium">Active Reservations</span>
            <Bookmark className="w-4 h-4 text-stone-400" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold text-stone-900 font-mono tabular-nums">
              {pendingReservations.length}
            </span>
          </div>
          <p className="text-[11px] text-stone-500 mt-1">FIFO Queue priority</p>
        </div>

        {/* Stat 4: Contact Queries */}
        <div className="bg-white border border-stone-200 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-stone-500 mb-2">
            <span className="text-xs font-medium">Help Desk Inquiries</span>
            <MessageSquare className="w-4 h-4 text-stone-400" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold text-stone-900 font-mono tabular-nums">
              {queries.length}
            </span>
          </div>
          <p className="text-[11px] text-stone-500 mt-1">
            <button onClick={onNavigateToContact} className="text-amber-800 hover:underline">
              Submit new inquiry →
            </button>
          </p>
        </div>
      </div>

      {/* Section 1: Currently Issued Books */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-display text-lg font-bold text-stone-900">
              Currently Borrowed Books ({activeIssues.length})
            </h2>
            <p className="text-xs text-stone-500">
              Ensure titles are returned on or before their due date to avoid the ₹5/day overdue fine.
            </p>
          </div>
          {activeIssues.length < 3 && (
            <button
              onClick={onNavigateToCatalogue}
              className="text-xs font-semibold text-amber-800 hover:text-amber-900 hover:underline"
            >
              + Issue Another Book
            </button>
          )}
        </div>

        {activeIssues.length === 0 ? (
          <div className="rounded-xl border border-dashed border-stone-200 p-8 text-center space-y-2">
            <BookOpen className="w-8 h-8 text-stone-300 mx-auto" />
            <p className="text-xs text-stone-600 font-medium">You have no active book loans</p>
            <p className="text-xs text-stone-400 max-w-sm mx-auto">
              Explore our library catalogue to borrow classic computer science textbooks, software engineering guides, and literature.
            </p>
            <button
              onClick={onNavigateToCatalogue}
              className="mt-2 px-3.5 py-1.5 text-xs font-semibold text-white bg-stone-900 hover:bg-stone-800 rounded-lg"
            >
              Explore Books
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 font-medium">
                  <th className="pb-3 pl-1 font-semibold">Book Title & Author</th>
                  <th className="pb-3 font-semibold">Issue Date</th>
                  <th className="pb-3 font-semibold">Due Date</th>
                  <th className="pb-3 font-semibold">Status / Fine</th>
                  <th className="pb-3 pr-1 text-right font-semibold">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {activeIssues.map((issue) => {
                  return (
                    <tr key={issue.id} className="hover:bg-stone-50/60 transition-colors">
                      <td className="py-3.5 pl-1">
                        <p className="font-semibold text-stone-900">{issue.bookTitle}</p>
                        <p className="text-[11px] text-stone-500">by {issue.bookAuthor} · <span className="font-mono">{issue.bookIsbn}</span></p>
                      </td>
                      <td className="py-3.5 font-mono text-stone-600 tabular-nums">
                        {issue.issueDate}
                      </td>
                      <td className="py-3.5 font-mono tabular-nums">
                        <span className={issue.isOverdue ? 'text-rose-700 font-bold' : 'text-stone-700 font-medium'}>
                          {issue.dueDate}
                        </span>
                      </td>
                      <td className="py-3.5">
                        {issue.isOverdue ? (
                          <div className="space-y-0.5">
                            <span className="inline-flex items-center gap-1 text-rose-700 font-semibold text-[11px]">
                              <AlertCircle className="w-3.5 h-3.5" />
                              Overdue!
                            </span>
                            <p className="text-[10px] text-rose-600 font-mono">
                              Est. Fine: ₹{issue.estimatedOverdueFine}
                            </p>
                          </div>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-emerald-700 font-medium text-[11px]">
                            <Clock className="w-3.5 h-3.5" />
                            Active Loan
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 pr-1 text-right">
                        <button
                          onClick={() => {
                            setReturningIssue(issue);
                            setSimulatedDaysLate(issue.isOverdue ? 3 : 0);
                          }}
                          className="px-3 py-1.5 text-xs font-semibold text-stone-800 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors inline-flex items-center gap-1 cursor-pointer"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Return Book</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Section 2: Advance Waitlist Reservations */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-4">
        <div>
          <h2 className="font-display text-lg font-bold text-stone-900">
            My Waitlist Reservations ({reservations.length})
          </h2>
          <p className="text-xs text-stone-500">
            When all physical copies are issued, members join the advance reservation queue. Copies are prioritized to position #1 upon return.
          </p>
        </div>

        {reservations.length === 0 ? (
          <div className="rounded-xl border border-dashed border-stone-200 p-6 text-center text-xs text-stone-500">
            No active reservations placed. You can reserve any out-of-stock book directly from the catalogue.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 font-medium">
                  <th className="pb-3 pl-1 font-semibold">Book Title</th>
                  <th className="pb-3 font-semibold">Reservation Date</th>
                  <th className="pb-3 font-semibold">Queue Position</th>
                  <th className="pb-3 font-semibold">Status</th>
                  <th className="pb-3 pr-1 text-right font-semibold">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {reservations.map((resv) => (
                  <tr key={resv.id} className="hover:bg-stone-50/60 transition-colors">
                    <td className="py-3 pl-1">
                      <p className="font-semibold text-stone-900">{resv.bookTitle}</p>
                      <p className="text-[11px] text-stone-500 font-mono">{resv.bookIsbn}</p>
                    </td>
                    <td className="py-3 font-mono text-stone-600 tabular-nums">
                      {resv.reservationDate.split('T')[0]}
                    </td>
                    <td className="py-3 font-mono text-stone-800 tabular-nums font-semibold">
                      #{resv.queuePosition} in Queue
                    </td>
                    <td className="py-3">
                      {resv.status === 'READY_FOR_PICKUP' ? (
                        <span className="text-emerald-700 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Ready for Pickup! (Hold expires: {resv.expiryDate || '3 days'})
                        </span>
                      ) : resv.status === 'PENDING' ? (
                        <span className="text-amber-700 font-medium flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          Waiting for Return
                        </span>
                      ) : resv.status === 'FULFILLED' ? (
                        <span className="text-stone-500">Fulfilled & Borrowed</span>
                      ) : (
                        <span className="text-stone-400">Cancelled</span>
                      )}
                    </td>
                    <td className="py-3 pr-1 text-right">
                      {resv.status === 'PENDING' && (
                        <button
                          onClick={() => onCancelReservation(resv.id)}
                          className="text-xs text-rose-600 hover:text-rose-800 hover:underline"
                        >
                          Cancel
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Section 3: Fine History & Clearance */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-display text-lg font-bold text-stone-900">
              Overdue Fine History ({fines.length})
            </h2>
            <p className="text-xs text-stone-500">
              Fines are generated automatically upon late return (₹5/calendar day overdue). Payments are recorded administratively by Library Staff.
            </p>
          </div>
        </div>

        {fines.length === 0 ? (
          <div className="rounded-xl border border-dashed border-stone-200 p-6 text-center text-xs text-stone-500">
            Great record! You have no outstanding or historical library fines.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 font-medium">
                  <th className="pb-3 pl-1 font-semibold">Fine Reference</th>
                  <th className="pb-3 font-semibold">Book Loan</th>
                  <th className="pb-3 font-semibold">Amount</th>
                  <th className="pb-3 font-semibold">Date Assessed</th>
                  <th className="pb-3 pr-1 text-right font-semibold">Payment Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {fines.map((fine) => (
                  <tr key={fine.id} className="hover:bg-stone-50/60 transition-colors">
                    <td className="py-3 pl-1 font-mono text-stone-500 text-[11px]">
                      {fine.id}
                    </td>
                    <td className="py-3 font-medium text-stone-900">
                      {fine.bookTitle}
                    </td>
                    <td className="py-3 font-mono font-bold text-stone-900 tabular-nums">
                      ₹{fine.amount}
                    </td>
                    <td className="py-3 font-mono text-stone-500 tabular-nums">
                      {fine.calculatedTimestamp.split('T')[0]}
                    </td>
                    <td className="py-3 pr-1 text-right">
                      {fine.status === 'PAID' ? (
                        <span className="text-emerald-700 font-semibold inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          PAID ({fine.paidTimestamp ? fine.paidTimestamp.split('T')[0] : 'Cleared'})
                        </span>
                      ) : (
                        <span className="text-amber-800 font-bold bg-amber-50 px-2 py-0.5 rounded text-[11px]">
                          UNPAID · Present to Admin
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Return Book Modal with Overdue Fine Simulator */}
      {returningIssue && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-stone-200">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-display text-lg font-bold text-stone-900">
                  Return Book
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">{returningIssue.bookTitle}</p>
              </div>
              <button
                onClick={() => setReturningIssue(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-stone-50 p-4 rounded-xl border border-stone-100 space-y-2 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Issue Date:</span>
                <span className="font-mono font-medium">{returningIssue.issueDate}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Agreed Due Date:</span>
                <span className="font-mono font-bold text-stone-800">{returningIssue.dueDate}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Fine Policy:</span>
                <span className="font-medium text-amber-800">₹5.00 per overdue calendar day</span>
              </div>
            </div>

            {/* Test Simulation Controls: Allows testing on-time vs late returns! */}
            <div className="p-3.5 bg-amber-50/70 border border-amber-200/80 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-amber-900">
                  Test Simulation: Simulate Overdue Days
                </span>
                <span className="text-xs font-mono font-bold text-amber-800 tabular-nums">
                  {simulatedDaysLate} day(s) late
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="10"
                value={simulatedDaysLate}
                onChange={(e) => setSimulatedDaysLate(parseInt(e.target.value, 10))}
                className="w-full accent-amber-700 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-amber-800 font-mono">
                <span>0 Days (On-time, ₹0 fine)</span>
                <span>3 Days (Task 5 Demo, ₹15 fine)</span>
                <span>10 Days (₹50 fine)</span>
              </div>
              <div className="pt-1 border-t border-amber-200/50 flex justify-between items-center text-xs">
                <span className="text-stone-700 font-medium">Calculated Fine to Assess:</span>
                <span className="font-mono font-bold text-stone-900 text-sm">
                  ₹{simulatedDaysLate * 5}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setReturningIssue(null)}
                className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-800"
              >
                Cancel
              </button>
              <button
                onClick={handleReturnSubmit}
                disabled={isSubmittingReturn}
                className="px-4 py-2 text-xs font-semibold text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-xs"
              >
                {isSubmittingReturn ? 'Processing...' : 'Confirm Return'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
