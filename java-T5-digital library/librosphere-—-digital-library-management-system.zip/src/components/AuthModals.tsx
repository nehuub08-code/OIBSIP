import React, { useState } from 'react';
import { X, Lock, Mail, User as UserIcon, Shield, Sparkles } from 'lucide-react';

interface AuthModalsProps {
  isLoginOpen: boolean;
  isRegisterOpen: boolean;
  onCloseLogin: () => void;
  onCloseRegister: () => void;
  onSwitchToRegister: () => void;
  onSwitchToLogin: () => void;
  onLogin: (usernameOrEmail: string, password: string) => Promise<void>;
  onRegister: (payload: {
    fullName: string;
    email: string;
    username: string;
    password: string;
    confirmPassword: string;
  }) => Promise<void>;
}

export const AuthModals: React.FC<AuthModalsProps> = ({
  isLoginOpen,
  isRegisterOpen,
  onCloseLogin,
  onCloseRegister,
  onSwitchToRegister,
  onSwitchToLogin,
  onLogin,
  onRegister,
}) => {
  // Login State
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Register State
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regError, setRegError] = useState<string | null>(null);
  const [isRegistering, setIsRegistering] = useState(false);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    try {
      setIsLoggingIn(true);
      await onLogin(loginIdentifier, loginPassword);
      onCloseLogin();
    } catch (err: any) {
      setLoginError(err.message || 'Invalid username or password.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleQuickLogin = (userType: 'admin' | 'nehaborkar' | 'rahulsharma') => {
    if (userType === 'admin') {
      setLoginIdentifier('admin');
      setLoginPassword('Admin@123');
    } else if (userType === 'nehaborkar') {
      setLoginIdentifier('nehaborkar');
      setLoginPassword('User@123');
    } else {
      setLoginIdentifier('rahulsharma');
      setLoginPassword('User@123');
    }
    setLoginError(null);
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);

    if (regPassword !== regConfirmPassword) {
      setRegError('Passwords do not match.');
      return;
    }

    if (regPassword.length < 6) {
      setRegError('Password must be at least 6 characters long.');
      return;
    }

    try {
      setIsRegistering(true);
      await onRegister({
        fullName: regFullName,
        email: regEmail,
        username: regUsername,
        password: regPassword,
        confirmPassword: regConfirmPassword,
      });
      onCloseRegister();
      onSwitchToLogin();
    } catch (err: any) {
      setRegError(err.message || 'Registration failed.');
    } finally {
      setIsRegistering(false);
    }
  };

  return (
    <>
      {/* LOGIN MODAL */}
      {isLoginOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 sm:p-8 space-y-5 shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-mono text-amber-800 font-semibold uppercase tracking-wider">
                  Authentication & RBAC
                </span>
                <h3 className="font-display text-2xl font-bold text-stone-900 mt-1">
                  Sign In to LibroSphere
                </h3>
                <p className="text-xs text-stone-500">
                  Enter your library credentials to manage loans, fines, and reservations.
                </p>
              </div>
              <button
                onClick={onCloseLogin}
                className="p-1 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Demo Credentials Preset Bar */}
            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/80 space-y-1.5 text-xs">
              <div className="flex items-center justify-between text-[11px] font-semibold text-stone-700">
                <span className="flex items-center gap-1 text-amber-900">
                  <Sparkles className="w-3.5 h-3.5" />
                  Quick Demo Sign-In:
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1.5 pt-1">
                <button
                  type="button"
                  onClick={() => handleQuickLogin('admin')}
                  className="px-2 py-1.5 bg-white hover:bg-stone-100 border border-stone-200 rounded text-[11px] font-medium text-stone-800 transition-colors cursor-pointer text-center"
                >
                  🛡️ Admin
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickLogin('nehaborkar')}
                  className="px-2 py-1.5 bg-white hover:bg-stone-100 border border-stone-200 rounded text-[11px] font-medium text-stone-800 transition-colors cursor-pointer text-center"
                >
                  👤 Neha (Dev)
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickLogin('rahulsharma')}
                  className="px-2 py-1.5 bg-white hover:bg-stone-100 border border-stone-200 rounded text-[11px] font-medium text-stone-800 transition-colors cursor-pointer text-center"
                >
                  👤 Rahul (User)
                </button>
              </div>
            </div>

            {loginError && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700">
                {loginError}
              </div>
            )}

            <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Username or Email Address
                </label>
                <div className="relative">
                  <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                  <input
                    type="text"
                    required
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    placeholder="e.g. admin or nehaborkar"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-amber-700"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Enter password"
                    className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-amber-700"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full py-2.5 px-4 bg-amber-800 hover:bg-amber-900 text-white font-semibold rounded-xl shadow-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                {isLoggingIn ? 'Verifying Credentials...' : 'Sign In'}
              </button>
            </form>

            <div className="text-center text-xs text-stone-500 pt-2 border-t border-stone-100">
              Don't have an account?{' '}
              <button
                onClick={onSwitchToRegister}
                className="font-semibold text-amber-800 hover:underline cursor-pointer"
              >
                Register as Member
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REGISTER MODAL */}
      {isRegisterOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 sm:p-8 space-y-4 shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-mono text-amber-800 font-semibold uppercase tracking-wider">
                  Member Registration
                </span>
                <h3 className="font-display text-2xl font-bold text-stone-900 mt-1">
                  Create Library Account
                </h3>
                <p className="text-xs text-stone-500">
                  Newly registered accounts are automatically assigned the USER role with 3-book loan privileges.
                </p>
              </div>
              <button
                onClick={onCloseRegister}
                className="p-1 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {regError && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700">
                {regError}
              </div>
            )}

            <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={regFullName}
                  onChange={(e) => setRegFullName(e.target.value)}
                  placeholder="e.g., Neha Vinod Borkar"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-700"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="e.g., neha@domain.com"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-700"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Username *</label>
                  <input
                    type="text"
                    required
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value)}
                    placeholder="e.g., nehaborkar"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-700 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Password *</label>
                  <input
                    type="password"
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-700"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Confirm Password *</label>
                  <input
                    type="password"
                    required
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    placeholder="Repeat password"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-700"
                  />
                </div>
              </div>

              <div className="p-2.5 bg-stone-50 rounded-lg border border-stone-200 text-[11px] text-stone-500">
                <span className="font-semibold text-stone-700">Security Policy:</span> Passwords are hashed with BCrypt. Newly registered members cannot elevate privileges to ADMIN.
              </div>

              <button
                type="submit"
                disabled={isRegistering}
                className="w-full py-2.5 px-4 bg-amber-800 hover:bg-amber-900 text-white font-semibold rounded-xl shadow-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                {isRegistering ? 'Registering Account...' : 'Complete Registration'}
              </button>
            </form>

            <div className="text-center text-xs text-stone-500 pt-2 border-t border-stone-100">
              Already have an account?{' '}
              <button
                onClick={onSwitchToLogin}
                className="font-semibold text-amber-800 hover:underline cursor-pointer"
              >
                Sign In Instead
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
