import React, { useState } from 'react';
import { User } from '../types/library';
import { BookOpen, User as UserIcon, LogOut, ShieldCheck, Code2, PlayCircle, BookMarked, HelpCircle, Layers } from 'lucide-react';

interface NavbarProps {
  currentUser: User | null;
  activeTab: 'catalogue' | 'user-dashboard' | 'admin-dashboard' | 'contact' | 'java-source' | 'demo-runner';
  setActiveTab: (tab: 'catalogue' | 'user-dashboard' | 'admin-dashboard' | 'contact' | 'java-source' | 'demo-runner') => void;
  onOpenLogin: () => void;
  onOpenRegister: () => void;
  onLogout: () => void;
  onQuickSwitchUser: (username: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  activeTab,
  setActiveTab,
  onOpenLogin,
  onOpenRegister,
  onLogout,
  onQuickSwitchUser,
}) => {
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Zone 1: Single text element Brand wordmark */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('catalogue')}
              className="flex items-center gap-2.5 text-left group focus:outline-none"
            >
              <div className="w-9 h-9 rounded-lg bg-amber-700 text-amber-50 flex items-center justify-center font-display text-lg font-bold shadow-xs">
                <BookOpen className="w-5 h-5 text-amber-100" />
              </div>
              <div>
                <span className="font-display text-xl font-bold tracking-tight text-stone-900 group-hover:text-amber-800 transition-colors">
                  LibroSphere
                </span>
                <span className="hidden sm:inline-block text-[11px] font-sans text-stone-500 font-medium ml-2">
                  Digital Library System
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Navigation links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-stone-600">
            <button
              onClick={() => setActiveTab('catalogue')}
              className={`hover:text-amber-800 transition-colors whitespace-nowrap cursor-pointer py-1 ${
                activeTab === 'catalogue' ? 'text-amber-800 font-semibold border-b-2 border-amber-800' : ''
              }`}
            >
              Book Catalogue
            </button>

            {currentUser && currentUser.role === 'USER' && (
              <button
                onClick={() => setActiveTab('user-dashboard')}
                className={`hover:text-amber-800 transition-colors whitespace-nowrap cursor-pointer py-1 ${
                  activeTab === 'user-dashboard' ? 'text-amber-800 font-semibold border-b-2 border-amber-800' : ''
                }`}
              >
                My Loans & Fines
              </button>
            )}

            {currentUser && currentUser.role === 'ADMIN' && (
              <button
                onClick={() => setActiveTab('admin-dashboard')}
                className={`flex items-center gap-1.5 hover:text-amber-800 transition-colors whitespace-nowrap cursor-pointer py-1 ${
                  activeTab === 'admin-dashboard' ? 'text-amber-800 font-semibold border-b-2 border-amber-800' : ''
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-amber-700" />
                Admin Console
              </button>
            )}

            <button
              onClick={() => setActiveTab('contact')}
              className={`hover:text-amber-800 transition-colors whitespace-nowrap cursor-pointer py-1 ${
                activeTab === 'contact' ? 'text-amber-800 font-semibold border-b-2 border-amber-800' : ''
              }`}
            >
              Ask Librarian
            </button>

            <button
              onClick={() => setActiveTab('demo-runner')}
              className={`flex items-center gap-1.5 hover:text-amber-800 transition-colors whitespace-nowrap cursor-pointer py-1 ${
                activeTab === 'demo-runner' ? 'text-amber-800 font-semibold border-b-2 border-amber-800' : ''
              }`}
            >
              <PlayCircle className="w-4 h-4 text-emerald-600" />
              <span>Oasis Demo Checklist</span>
            </button>

            <button
              onClick={() => setActiveTab('java-source')}
              className={`flex items-center gap-1.5 hover:text-amber-800 transition-colors whitespace-nowrap cursor-pointer py-1 ${
                activeTab === 'java-source' ? 'text-amber-800 font-semibold border-b-2 border-amber-800' : ''
              }`}
            >
              <Code2 className="w-4 h-4 text-amber-700" />
              <span>Spring Boot Source</span>
            </button>
          </nav>

          {/* Zone 3: Account / Primary Action */}
          <div className="flex items-center gap-3 shrink-0">
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 transition-colors text-left"
                >
                  <div className="w-7 h-7 rounded-full bg-stone-800 text-white flex items-center justify-center text-xs font-semibold">
                    {currentUser.fullName.charAt(0)}
                  </div>
                  <div className="hidden sm:block text-xs">
                    <p className="font-semibold text-stone-800 truncate max-w-[130px]">{currentUser.fullName}</p>
                    <span className="text-[10px] text-stone-500 font-mono">
                      {currentUser.role === 'ADMIN' ? '🛡️ Admin' : '👤 Member'}
                    </span>
                  </div>
                </button>

                {profileDropdownOpen && (
                  <div
                    className="absolute right-0 mt-2 w-64 rounded-xl bg-white border border-stone-200 shadow-xl py-2 z-50 animate-in fade-in slide-in-from-top-2"
                    onMouseLeave={() => setProfileDropdownOpen(false)}
                  >
                    <div className="px-4 py-2 border-b border-stone-100">
                      <p className="text-xs text-stone-500 font-medium">Signed in as</p>
                      <p className="text-sm font-semibold text-stone-900 truncate">{currentUser.fullName}</p>
                      <p className="text-xs text-stone-500 truncate font-mono">{currentUser.email}</p>
                    </div>

                    <div className="py-1">
                      {currentUser.role === 'ADMIN' ? (
                        <button
                          onClick={() => {
                            setActiveTab('admin-dashboard');
                            setProfileDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-stone-700 hover:bg-stone-50 flex items-center gap-2"
                        >
                          <ShieldCheck className="w-4 h-4 text-amber-700" />
                          Admin Overview & Ledger
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            setActiveTab('user-dashboard');
                            setProfileDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-stone-700 hover:bg-stone-50 flex items-center gap-2"
                        >
                          <BookMarked className="w-4 h-4 text-amber-700" />
                          My Borrowed Books & Fines
                        </button>
                      )}

                      <button
                        onClick={() => {
                          setActiveTab('demo-runner');
                          setProfileDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-stone-700 hover:bg-stone-50 flex items-center gap-2"
                      >
                        <PlayCircle className="w-4 h-4 text-emerald-600" />
                        Run Oasis Infobyte Demo
                      </button>
                    </div>

                    <div className="px-4 py-2 border-t border-stone-100 text-[11px] text-stone-500">
                      <p className="font-semibold text-stone-700 mb-1">Quick Account Switch:</p>
                      <div className="flex flex-col gap-1">
                        <button
                          onClick={() => {
                            onQuickSwitchUser('admin');
                            setProfileDropdownOpen(false);
                          }}
                          className="text-left text-amber-800 hover:underline"
                        >
                          • Switch to Administrator (admin)
                        </button>
                        <button
                          onClick={() => {
                            onQuickSwitchUser('nehaborkar');
                            setProfileDropdownOpen(false);
                          }}
                          className="text-left text-amber-800 hover:underline"
                        >
                          • Switch to Neha Vinod Borkar (nehaborkar)
                        </button>
                        <button
                          onClick={() => {
                            onQuickSwitchUser('rahulsharma');
                            setProfileDropdownOpen(false);
                          }}
                          className="text-left text-amber-800 hover:underline"
                        >
                          • Switch to Rahul Sharma (rahulsharma)
                        </button>
                      </div>
                    </div>

                    <div className="border-t border-stone-100 pt-1">
                      <button
                        onClick={() => {
                          setProfileDropdownOpen(false);
                          onLogout();
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-red-600 hover:bg-red-50 flex items-center gap-2"
                      >
                        <LogOut className="w-4 h-4" />
                        Sign Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={onOpenLogin}
                  className="px-3.5 py-1.5 text-xs font-semibold text-stone-700 hover:text-stone-900 border border-stone-200 rounded-lg hover:bg-stone-50 transition-colors"
                >
                  Sign In
                </button>
                <button
                  onClick={onOpenRegister}
                  className="px-3.5 py-1.5 text-xs font-semibold text-white bg-amber-800 hover:bg-amber-900 rounded-lg transition-colors shadow-xs"
                >
                  Register
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Sub-Navigation Bar */}
        <div className="lg:hidden flex items-center justify-between border-t border-stone-100 py-2 overflow-x-auto text-xs text-stone-600 gap-4">
          <button
            onClick={() => setActiveTab('catalogue')}
            className={`whitespace-nowrap ${activeTab === 'catalogue' ? 'text-amber-800 font-bold' : ''}`}
          >
            Catalogue
          </button>
          {currentUser && currentUser.role === 'USER' && (
            <button
              onClick={() => setActiveTab('user-dashboard')}
              className={`whitespace-nowrap ${activeTab === 'user-dashboard' ? 'text-amber-800 font-bold' : ''}`}
            >
              My Loans
            </button>
          )}
          {currentUser && currentUser.role === 'ADMIN' && (
            <button
              onClick={() => setActiveTab('admin-dashboard')}
              className={`whitespace-nowrap ${activeTab === 'admin-dashboard' ? 'text-amber-800 font-bold' : ''}`}
            >
              Admin
            </button>
          )}
          <button
            onClick={() => setActiveTab('contact')}
            className={`whitespace-nowrap ${activeTab === 'contact' ? 'text-amber-800 font-bold' : ''}`}
          >
            Contact
          </button>
          <button
            onClick={() => setActiveTab('demo-runner')}
            className={`whitespace-nowrap text-emerald-700 font-medium ${activeTab === 'demo-runner' ? 'font-bold' : ''}`}
          >
            Oasis Demo
          </button>
          <button
            onClick={() => setActiveTab('java-source')}
            className={`whitespace-nowrap text-amber-800 font-medium ${activeTab === 'java-source' ? 'font-bold' : ''}`}
          >
            Spring Boot
          </button>
        </div>
      </div>
    </header>
  );
};
