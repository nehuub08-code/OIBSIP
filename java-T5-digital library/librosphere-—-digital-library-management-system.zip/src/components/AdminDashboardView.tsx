import React, { useState } from 'react';
import { AdminOverview, Book, BookIssue, Fine, ContactMessage, User } from '../types/library';
import {
  BookOpen,
  Users,
  IndianRupee,
  Layers,
  MessageSquare,
  Bookmark,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  Clock,
  AlertCircle,
  Search,
  Filter,
  RefreshCw,
  X,
  Check,
  Ban,
  ShieldAlert
} from 'lucide-react';

interface AdminDashboardViewProps {
  overview: AdminOverview;
  books: Book[];
  onAddBook: (book: Partial<Book>) => Promise<void>;
  onEditBook: (id: string, book: Partial<Book>) => Promise<void>;
  onDeleteBook: (id: string) => Promise<void>;
  onPayFine: (fineId: string) => Promise<void>;
  onToggleMemberStatus: (memberId: string, newStatus: 'ACTIVE' | 'DEACTIVATED') => Promise<void>;
  onUpdateQueryStatus: (contactId: string, status: 'NEW' | 'IN_PROGRESS' | 'RESOLVED') => Promise<void>;
  onResetDatabase: () => Promise<void>;
  onRefresh: () => void;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  overview,
  books,
  onAddBook,
  onEditBook,
  onDeleteBook,
  onPayFine,
  onToggleMemberStatus,
  onUpdateQueryStatus,
  onResetDatabase,
  onRefresh,
}) => {
  const [activeTab, setActiveTab] = useState<'books' | 'issues' | 'members' | 'fines' | 'reservations' | 'queries'>('books');

  // Book Modal States
  const [isAddBookOpen, setIsAddBookOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);
  const [deletingBook, setDeletingBook] = useState<Book | null>(null);

  // Form states for Add / Edit
  const [bookForm, setBookForm] = useState({
    title: '',
    author: '',
    isbn: '',
    category: 'Computer Science',
    totalQuantity: 3,
    description: '',
    shelfLocation: 'Stack CS-01',
  });

  // Filter States
  const [bookSearch, setBookSearch] = useState('');
  const [issueFilter, setIssueFilter] = useState<'ALL' | 'ACTIVE' | 'RETURNED' | 'OVERDUE'>('ALL');
  const [fineFilter, setFineFilter] = useState<'ALL' | 'UNPAID' | 'PAID'>('ALL');
  const [queryFilter, setQueryFilter] = useState<'ALL' | 'NEW' | 'IN_PROGRESS' | 'RESOLVED'>('ALL');

  // Confirm Fine Payment Modal
  const [payingFine, setPayingFine] = useState<Fine | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Open Edit Modal helper
  const handleOpenEdit = (book: Book) => {
    setEditingBook(book);
    setBookForm({
      title: book.title,
      author: book.author,
      isbn: book.isbn,
      category: book.category,
      totalQuantity: book.totalQuantity,
      description: book.description || '',
      shelfLocation: book.shelfLocation || 'General Stacks',
    });
  };

  const handleSaveBook = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsSubmitting(true);
      if (editingBook) {
        await onEditBook(editingBook.id, bookForm);
        setEditingBook(null);
      } else {
        await onAddBook(bookForm);
        setIsAddBookOpen(false);
      }
      setBookForm({
        title: '',
        author: '',
        isbn: '',
        category: 'Computer Science',
        totalQuantity: 3,
        description: '',
        shelfLocation: 'Stack CS-01',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deletingBook) return;
    try {
      setIsSubmitting(true);
      await onDeleteBook(deletingBook.id);
      setDeletingBook(null);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFinePayConfirm = async () => {
    if (!payingFine) return;
    try {
      setIsSubmitting(true);
      await onPayFine(payingFine.id);
      setPayingFine(null);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filtered Lists
  const filteredBooks = books.filter(
    (b) =>
      b.title.toLowerCase().includes(bookSearch.toLowerCase()) ||
      b.author.toLowerCase().includes(bookSearch.toLowerCase()) ||
      b.isbn.toLowerCase().includes(bookSearch.toLowerCase())
  );

  const filteredIssues = overview.issues.filter((issue) => {
    if (issueFilter === 'ACTIVE') return issue.status === 'ACTIVE';
    if (issueFilter === 'RETURNED') return issue.status === 'RETURNED';
    if (issueFilter === 'OVERDUE') return issue.isOverdue;
    return true;
  });

  const filteredFines = overview.fines.filter((fine) => {
    if (fineFilter === 'UNPAID') return fine.status === 'UNPAID';
    if (fineFilter === 'PAID') return fine.status === 'PAID';
    return true;
  });

  const filteredQueries = overview.contacts.filter((c) => {
    if (queryFilter === 'ALL') return true;
    return c.status === queryFilter;
  });

  return (
    <div className="space-y-8">
      {/* Admin Header with Quick Actions */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-stone-500">
            <span>Role: System Administrator</span>
            <span aria-hidden="true">·</span>
            <span className="text-amber-800 font-semibold">Oasis Infobyte Task 5 Console</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-stone-900 mt-1">
            Library Administration & Ledger
          </h1>
          <p className="text-xs sm:text-sm text-stone-500">
            Manage physical book inventory, track loan statuses, oversee overdue penalties, and review member accounts.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => {
              setEditingBook(null);
              setBookForm({
                title: '',
                author: '',
                isbn: '',
                category: 'Computer Science',
                totalQuantity: 3,
                description: '',
                shelfLocation: 'Stack CS-01',
              });
              setIsAddBookOpen(true);
            }}
            className="px-4 py-2 text-xs font-semibold text-white bg-amber-800 hover:bg-amber-900 rounded-xl transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Book</span>
          </button>
          <button
            onClick={onRefresh}
            className="px-3 py-2 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Refresh Ledger"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
          <button
            onClick={onResetDatabase}
            className="px-3 py-2 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-xl transition-colors cursor-pointer"
            title="Reset data back to initial demo seeds"
          >
            Reset Demo Data
          </button>
        </div>
      </div>

      {/* 6 Key Performance Indicators (Derived from live DB, not hardcoded) */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Metric 1 */}
        <div className="bg-white border border-stone-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-medium text-stone-500 block">Total Copies</span>
          <span className="text-xl font-bold font-mono text-stone-900 tabular-nums">
            {overview.counts.totalBooks}
          </span>
          <p className="text-[10px] text-stone-400 mt-0.5">Across catalog</p>
        </div>

        {/* Metric 2 */}
        <div className="bg-white border border-stone-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-medium text-stone-500 block">Available on Shelf</span>
          <span className="text-xl font-bold font-mono text-emerald-700 tabular-nums">
            {overview.counts.availableCopies}
          </span>
          <p className="text-[10px] text-stone-400 mt-0.5">Ready for checkout</p>
        </div>

        {/* Metric 3 */}
        <div className="bg-white border border-stone-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-medium text-stone-500 block">Active Loans</span>
          <span className="text-xl font-bold font-mono text-stone-900 tabular-nums">
            {overview.counts.issuedCopies}
          </span>
          <p className="text-[10px] text-stone-400 mt-0.5">Currently borrowed</p>
        </div>

        {/* Metric 4 */}
        <div className="bg-white border border-stone-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-medium text-stone-500 block">Members</span>
          <span className="text-xl font-bold font-mono text-stone-900 tabular-nums">
            {overview.counts.registeredMembers}
          </span>
          <p className="text-[10px] text-stone-400 mt-0.5">Registered accounts</p>
        </div>

        {/* Metric 5 */}
        <div className="bg-white border border-stone-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-medium text-stone-500 block">Unpaid Fines</span>
          <span className="text-xl font-bold font-mono text-amber-800 tabular-nums">
            ₹{overview.counts.outstandingFines}
          </span>
          <p className="text-[10px] text-stone-400 mt-0.5">Overdue ledger</p>
        </div>

        {/* Metric 6 */}
        <div className="bg-white border border-stone-200 rounded-xl p-4 shadow-xs">
          <span className="text-[11px] font-medium text-stone-500 block">Pending Inquiries</span>
          <span className="text-xl font-bold font-mono text-stone-900 tabular-nums">
            {overview.counts.pendingQueries}
          </span>
          <p className="text-[10px] text-stone-400 mt-0.5">Help desk queries</p>
        </div>
      </div>

      {/* Main Admin Section Tabs */}
      <div className="border-b border-stone-200">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-semibold text-stone-600">
          <button
            onClick={() => setActiveTab('books')}
            className={`px-4 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'books' ? 'bg-stone-900 text-white shadow-xs' : 'hover:bg-stone-100'
            }`}
          >
            Manage Books ({books.length})
          </button>
          <button
            onClick={() => setActiveTab('issues')}
            className={`px-4 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'issues' ? 'bg-stone-900 text-white shadow-xs' : 'hover:bg-stone-100'
            }`}
          >
            Issued Books Ledger ({overview.issues.length})
          </button>
          <button
            onClick={() => setActiveTab('members')}
            className={`px-4 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'members' ? 'bg-stone-900 text-white shadow-xs' : 'hover:bg-stone-100'
            }`}
          >
            Members ({overview.members.length})
          </button>
          <button
            onClick={() => setActiveTab('fines')}
            className={`px-4 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'fines' ? 'bg-stone-900 text-white shadow-xs' : 'hover:bg-stone-100'
            }`}
          >
            Fines ({overview.fines.length})
          </button>
          <button
            onClick={() => setActiveTab('reservations')}
            className={`px-4 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'reservations' ? 'bg-stone-900 text-white shadow-xs' : 'hover:bg-stone-100'
            }`}
          >
            Reservations ({overview.reservations.length})
          </button>
          <button
            onClick={() => setActiveTab('queries')}
            className={`px-4 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'queries' ? 'bg-stone-900 text-white shadow-xs' : 'hover:bg-stone-100'
            }`}
          >
            Contact Queries ({overview.contacts.length})
          </button>
        </div>
      </div>

      {/* TAB 1: MANAGE BOOKS */}
      {activeTab === 'books' && (
        <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
              <input
                type="text"
                placeholder="Filter books by title, author, ISBN..."
                value={bookSearch}
                onChange={(e) => setBookSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-700"
              />
            </div>
            <button
              onClick={() => {
                setEditingBook(null);
                setBookForm({
                  title: '',
                  author: '',
                  isbn: '',
                  category: 'Computer Science',
                  totalQuantity: 3,
                  description: '',
                  shelfLocation: 'Stack CS-01',
                });
                setIsAddBookOpen(true);
              }}
              className="px-3.5 py-2 text-xs font-semibold text-white bg-amber-800 hover:bg-amber-900 rounded-lg flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Book</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 font-medium">
                  <th className="pb-3 pl-1 font-semibold">Title & Author</th>
                  <th className="pb-3 font-semibold">ISBN</th>
                  <th className="pb-3 font-semibold">Category</th>
                  <th className="pb-3 font-semibold">Shelf</th>
                  <th className="pb-3 font-semibold">Stock (Avail/Total)</th>
                  <th className="pb-3 pr-1 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredBooks.map((book) => (
                  <tr key={book.id} className="hover:bg-stone-50/60 transition-colors">
                    <td className="py-3 pl-1">
                      <p className="font-semibold text-stone-900">{book.title}</p>
                      <p className="text-[11px] text-stone-500">by {book.author}</p>
                    </td>
                    <td className="py-3 font-mono text-stone-600">{book.isbn}</td>
                    <td className="py-3 text-stone-700 font-medium">{book.category}</td>
                    <td className="py-3 font-mono text-stone-500 text-[11px]">{book.shelfLocation}</td>
                    <td className="py-3 font-mono tabular-nums">
                      <span className={book.availableQuantity > 0 ? 'text-emerald-700 font-semibold' : 'text-rose-700 font-semibold'}>
                        {book.availableQuantity}
                      </span>
                      <span className="text-stone-400"> / {book.totalQuantity}</span>
                    </td>
                    <td className="py-3 pr-1 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleOpenEdit(book)}
                          className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-md transition-colors"
                          title="Edit Book Details"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeletingBook(book)}
                          className="p-1.5 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded-md transition-colors"
                          title="Delete Book"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: ISSUED BOOKS MASTER LEDGER */}
      {activeTab === 'issues' && (
        <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center justify-between">
            <div>
              <h2 className="font-display text-lg font-bold text-stone-900">
                Loan Transactions Master Ledger
              </h2>
              <p className="text-xs text-stone-500">
                Comprehensive record of active borrowings, completed returns, and overdue states across all members.
              </p>
            </div>
            {/* Filter Buttons */}
            <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-lg self-start sm:self-auto text-xs font-medium">
              {(['ALL', 'ACTIVE', 'RETURNED', 'OVERDUE'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setIssueFilter(filter)}
                  className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                    issueFilter === filter ? 'bg-white text-stone-900 font-semibold shadow-xs' : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 font-medium">
                  <th className="pb-3 pl-1 font-semibold">Issue Ref</th>
                  <th className="pb-3 font-semibold">Member</th>
                  <th className="pb-3 font-semibold">Book Title</th>
                  <th className="pb-3 font-semibold">Issue Date</th>
                  <th className="pb-3 font-semibold">Due Date</th>
                  <th className="pb-3 font-semibold">Return Date</th>
                  <th className="pb-3 font-semibold">Status</th>
                  <th className="pb-3 pr-1 text-right font-semibold">Fine Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredIssues.map((issue) => (
                  <tr key={issue.id} className="hover:bg-stone-50/60 transition-colors">
                    <td className="py-3 pl-1 font-mono text-[11px] text-stone-400">{issue.id}</td>
                    <td className="py-3">
                      <p className="font-semibold text-stone-900">{issue.memberName}</p>
                      <p className="text-[10px] text-stone-500 font-mono">@{issue.memberUsername}</p>
                    </td>
                    <td className="py-3 font-medium text-stone-900">{issue.bookTitle}</td>
                    <td className="py-3 font-mono text-stone-600 tabular-nums">{issue.issueDate}</td>
                    <td className="py-3 font-mono tabular-nums">
                      <span className={issue.isOverdue ? 'text-rose-700 font-bold' : 'text-stone-700'}>
                        {issue.dueDate}
                      </span>
                    </td>
                    <td className="py-3 font-mono text-stone-600 tabular-nums">{issue.returnDate || '—'}</td>
                    <td className="py-3">
                      {issue.status === 'RETURNED' ? (
                        <span className="text-emerald-700 font-medium">Returned</span>
                      ) : issue.isOverdue ? (
                        <span className="text-rose-700 font-bold">Overdue</span>
                      ) : (
                        <span className="text-stone-700 font-medium">Active</span>
                      )}
                    </td>
                    <td className="py-3 pr-1 text-right font-mono font-semibold tabular-nums text-stone-900">
                      ₹{issue.fineAmount}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: MEMBER MANAGEMENT */}
      {activeTab === 'members' && (
        <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div>
            <h2 className="font-display text-lg font-bold text-stone-900">
              Registered Library Members ({overview.members.length})
            </h2>
            <p className="text-xs text-stone-500">
              Review member borrowing activity, outstanding fine balances, and manage account authorization.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 font-medium">
                  <th className="pb-3 pl-1 font-semibold">Member Name & Email</th>
                  <th className="pb-3 font-semibold">Username</th>
                  <th className="pb-3 font-semibold">Registration Date</th>
                  <th className="pb-3 font-semibold">Active Loans</th>
                  <th className="pb-3 font-semibold">Unpaid Fines</th>
                  <th className="pb-3 font-semibold">Status</th>
                  <th className="pb-3 pr-1 text-right font-semibold">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {overview.members.map((member) => (
                  <tr key={member.id} className="hover:bg-stone-50/60 transition-colors">
                    <td className="py-3 pl-1">
                      <p className="font-semibold text-stone-900">{member.fullName}</p>
                      <p className="text-[11px] text-stone-500 font-mono">{member.email}</p>
                    </td>
                    <td className="py-3 font-mono text-stone-700">@{member.username}</td>
                    <td className="py-3 font-mono text-stone-500 tabular-nums">
                      {member.createdAt.split('T')[0]}
                    </td>
                    <td className="py-3 font-mono font-semibold text-stone-900 tabular-nums">
                      {member.activeIssueCount} active
                    </td>
                    <td className="py-3 font-mono font-bold tabular-nums">
                      <span className={member.unpaidFinesTotal > 0 ? 'text-amber-800' : 'text-stone-500'}>
                        ₹{member.unpaidFinesTotal}
                      </span>
                    </td>
                    <td className="py-3">
                      {member.accountStatus === 'ACTIVE' ? (
                        <span className="text-emerald-700 font-medium">Active</span>
                      ) : (
                        <span className="text-rose-700 font-bold">Deactivated</span>
                      )}
                    </td>
                    <td className="py-3 pr-1 text-right">
                      {member.accountStatus === 'ACTIVE' ? (
                        <button
                          onClick={() => onToggleMemberStatus(member.id, 'DEACTIVATED')}
                          className="px-2.5 py-1 text-[11px] font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-md transition-colors cursor-pointer"
                        >
                          Deactivate
                        </button>
                      ) : (
                        <button
                          onClick={() => onToggleMemberStatus(member.id, 'ACTIVE')}
                          className="px-2.5 py-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-md transition-colors cursor-pointer"
                        >
                          Activate
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: FINE MANAGEMENT */}
      {activeTab === 'fines' && (
        <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center justify-between">
            <div>
              <h2 className="font-display text-lg font-bold text-stone-900">
                Overdue Fines Master Ledger
              </h2>
              <p className="text-xs text-stone-500">
                Administratively record in-person cash/cheque fine payments and verify settled debts.
              </p>
            </div>
            <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-lg text-xs font-medium self-start sm:self-auto">
              {(['ALL', 'UNPAID', 'PAID'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setFineFilter(filter)}
                  className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                    fineFilter === filter ? 'bg-white text-stone-900 font-semibold shadow-xs' : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 font-medium">
                  <th className="pb-3 pl-1 font-semibold">Fine Ref</th>
                  <th className="pb-3 font-semibold">Member</th>
                  <th className="pb-3 font-semibold">Book Title</th>
                  <th className="pb-3 font-semibold">Fine Amount</th>
                  <th className="pb-3 font-semibold">Date Assessed</th>
                  <th className="pb-3 font-semibold">Status / Paid Date</th>
                  <th className="pb-3 pr-1 text-right font-semibold">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredFines.map((fine) => (
                  <tr key={fine.id} className="hover:bg-stone-50/60 transition-colors">
                    <td className="py-3 pl-1 font-mono text-[11px] text-stone-400">{fine.id}</td>
                    <td className="py-3">
                      <p className="font-semibold text-stone-900">{fine.memberName}</p>
                      <p className="text-[10px] text-stone-500 font-mono">{fine.memberEmail}</p>
                    </td>
                    <td className="py-3 font-medium text-stone-900">{fine.bookTitle}</td>
                    <td className="py-3 font-mono font-bold text-stone-900 tabular-nums">₹{fine.amount}</td>
                    <td className="py-3 font-mono text-stone-500 tabular-nums">
                      {fine.calculatedTimestamp.split('T')[0]}
                    </td>
                    <td className="py-3">
                      {fine.status === 'PAID' ? (
                        <span className="text-emerald-700 font-semibold inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          PAID ({fine.paidTimestamp ? fine.paidTimestamp.split('T')[0] : 'Cleared'})
                        </span>
                      ) : (
                        <span className="text-amber-800 font-semibold">UNPAID</span>
                      )}
                    </td>
                    <td className="py-3 pr-1 text-right">
                      {fine.status === 'UNPAID' && (
                        <button
                          onClick={() => setPayingFine(fine)}
                          className="px-2.5 py-1 text-xs font-semibold text-white bg-amber-800 hover:bg-amber-900 rounded-md transition-colors cursor-pointer"
                        >
                          Mark as Paid
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: RESERVATION QUEUE */}
      {activeTab === 'reservations' && (
        <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div>
            <h2 className="font-display text-lg font-bold text-stone-900">
              Advance Waitlist Reservations
            </h2>
            <p className="text-xs text-stone-500">
              When all copies are borrowed, members join this FIFO queue. Returned copies automatically trigger hold availability.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 font-medium">
                  <th className="pb-3 pl-1 font-semibold">Res Ref</th>
                  <th className="pb-3 font-semibold">Member</th>
                  <th className="pb-3 font-semibold">Book Title</th>
                  <th className="pb-3 font-semibold">Reservation Date</th>
                  <th className="pb-3 font-semibold">Queue Position</th>
                  <th className="pb-3 pr-1 text-right font-semibold">Queue Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {overview.reservations.map((resv) => (
                  <tr key={resv.id} className="hover:bg-stone-50/60 transition-colors">
                    <td className="py-3 pl-1 font-mono text-[11px] text-stone-400">{resv.id}</td>
                    <td className="py-3">
                      <p className="font-semibold text-stone-900">{resv.memberName}</p>
                      <p className="text-[10px] text-stone-500 font-mono">{resv.memberEmail}</p>
                    </td>
                    <td className="py-3 font-medium text-stone-900">{resv.bookTitle}</td>
                    <td className="py-3 font-mono text-stone-500 tabular-nums">
                      {resv.reservationDate.split('T')[0]}
                    </td>
                    <td className="py-3 font-mono font-bold text-stone-900 tabular-nums">
                      #{resv.queuePosition}
                    </td>
                    <td className="py-3 pr-1 text-right">
                      {resv.status === 'READY_FOR_PICKUP' ? (
                        <span className="text-emerald-700 font-semibold inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Ready for Pickup (Hold: {resv.expiryDate || '3 days'})
                        </span>
                      ) : resv.status === 'PENDING' ? (
                        <span className="text-amber-700 font-medium">Pending Waitlist</span>
                      ) : resv.status === 'FULFILLED' ? (
                        <span className="text-stone-500">Fulfilled (Issued)</span>
                      ) : (
                        <span className="text-stone-400">Cancelled</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 6: CONTACT QUERIES */}
      {activeTab === 'queries' && (
        <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center justify-between">
            <div>
              <h2 className="font-display text-lg font-bold text-stone-900">
                Help Desk & Member Inquiries
              </h2>
              <p className="text-xs text-stone-500">
                Review submitted questions, book acquisition requests, and visitor inquiries.
              </p>
            </div>
            <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-lg text-xs font-medium self-start sm:self-auto">
              {(['ALL', 'NEW', 'IN_PROGRESS', 'RESOLVED'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setQueryFilter(filter)}
                  className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                    queryFilter === filter ? 'bg-white text-stone-900 font-semibold shadow-xs' : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            {filteredQueries.map((query) => (
              <div
                key={query.id}
                className="p-4 rounded-xl border border-stone-200 bg-stone-50/50 hover:bg-white transition-all space-y-2"
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="font-semibold text-stone-900 text-sm">{query.subject}</h3>
                    <p className="text-xs text-stone-500">
                      From: <strong className="text-stone-700">{query.name}</strong> ({query.email}) · <span className="font-mono">{query.createdAt.split('T')[0]}</span>
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <span
                      className={`text-[11px] font-semibold px-2 py-0.5 rounded ${
                        query.status === 'NEW'
                          ? 'bg-rose-100 text-rose-800'
                          : query.status === 'IN_PROGRESS'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {query.status}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-stone-700 leading-relaxed bg-white p-3 rounded-lg border border-stone-100">
                  {query.message}
                </p>

                <div className="flex items-center justify-end gap-2 pt-1 text-xs">
                  {query.status !== 'IN_PROGRESS' && query.status !== 'RESOLVED' && (
                    <button
                      onClick={() => onUpdateQueryStatus(query.id, 'IN_PROGRESS')}
                      className="px-2.5 py-1 font-semibold text-amber-900 bg-amber-50 hover:bg-amber-100 rounded-md transition-colors"
                    >
                      Mark In Progress
                    </button>
                  )}
                  {query.status !== 'RESOLVED' && (
                    <button
                      onClick={() => onUpdateQueryStatus(query.id, 'RESOLVED')}
                      className="px-2.5 py-1 font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-md transition-colors"
                    >
                      Mark Resolved
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add / Edit Book Modal */}
      {(isAddBookOpen || editingBook) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl border border-stone-200">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-display text-lg font-bold text-stone-900">
                  {editingBook ? 'Edit Book Details' : 'Add New Book to Catalogue'}
                </h3>
                <p className="text-xs text-stone-500">
                  {editingBook
                    ? 'Update metadata and stock. Total quantity cannot be reduced below actively issued copies.'
                    : 'Enter complete book metadata with unique ISBN and initial stock quantity.'}
                </p>
              </div>
              <button
                onClick={() => {
                  setIsAddBookOpen(false);
                  setEditingBook(null);
                }}
                className="p-1 text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBook} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">Book Title *</label>
                <input
                  type="text"
                  required
                  value={bookForm.title}
                  onChange={(e) => setBookForm({ ...bookForm, title: e.target.value })}
                  placeholder="e.g., Clean Architecture"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-700"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Author *</label>
                  <input
                    type="text"
                    required
                    value={bookForm.author}
                    onChange={(e) => setBookForm({ ...bookForm, author: e.target.value })}
                    placeholder="e.g., Robert C. Martin"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-700"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">ISBN *</label>
                  <input
                    type="text"
                    required
                    value={bookForm.isbn}
                    onChange={(e) => setBookForm({ ...bookForm, isbn: e.target.value })}
                    placeholder="e.g., 978-0134494166"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-700 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Category *</label>
                  <select
                    value={bookForm.category}
                    onChange={(e) => setBookForm({ ...bookForm, category: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-700"
                  >
                    <option value="Computer Science">Computer Science</option>
                    <option value="Software Engineering">Software Engineering</option>
                    <option value="Information Systems">Information Systems</option>
                    <option value="Literature & Fiction">Literature & Fiction</option>
                    <option value="Physics & Cosmology">Physics & Cosmology</option>
                    <option value="Personal Development">Personal Development</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Total Quantity *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={bookForm.totalQuantity}
                    onChange={(e) => setBookForm({ ...bookForm, totalQuantity: parseInt(e.target.value, 10) || 1 })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-700 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Shelf Stack Location</label>
                <input
                  type="text"
                  value={bookForm.shelfLocation}
                  onChange={(e) => setBookForm({ ...bookForm, shelfLocation: e.target.value })}
                  placeholder="e.g., Stack CS-04"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-700"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Description / Summary</label>
                <textarea
                  rows={3}
                  value={bookForm.description}
                  onChange={(e) => setBookForm({ ...bookForm, description: e.target.value })}
                  placeholder="Brief synopsis of book..."
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-700"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddBookOpen(false);
                    setEditingBook(null);
                  }}
                  className="px-4 py-2 text-stone-600 hover:text-stone-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-white bg-amber-800 hover:bg-amber-900 font-semibold rounded-lg shadow-xs"
                >
                  {isSubmitting ? 'Saving...' : editingBook ? 'Update Book' : 'Add Book to Catalog'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Book Confirmation Modal */}
      {deletingBook && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-stone-200">
            <div className="flex items-center gap-3 text-rose-700">
              <div className="w-10 h-10 rounded-full bg-rose-50 flex items-center justify-center">
                <Trash2 className="w-5 h-5 text-rose-600" />
              </div>
              <h3 className="font-display text-lg font-bold text-stone-900">
                Confirm Book Deletion
              </h3>
            </div>

            <p className="text-xs text-stone-600 leading-relaxed">
              Are you sure you want to delete <strong className="text-stone-900">"{deletingBook.title}"</strong> (ISBN: {deletingBook.isbn})?
              This operation cannot be undone. System safeguards will block deletion if active loans or pending waitlists exist.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setDeletingBook(null)}
                className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-800"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteConfirm}
                disabled={isSubmitting}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-xs"
              >
                {isSubmitting ? 'Deleting...' : 'Confirm Deletion'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mark Fine as Paid Confirmation Modal */}
      {payingFine && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-stone-200">
            <div className="flex items-center gap-3 text-emerald-700">
              <div className="w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              </div>
              <h3 className="font-display text-lg font-bold text-stone-900">
                Record Fine Payment
              </h3>
            </div>

            <div className="bg-stone-50 p-4 rounded-xl border border-stone-100 space-y-1.5 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Member:</span>
                <span className="font-semibold text-stone-900">{payingFine.memberName}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Book Loan:</span>
                <span className="text-stone-800">{payingFine.bookTitle}</span>
              </div>
              <div className="flex justify-between text-stone-600 font-bold">
                <span>Amount Collected:</span>
                <span className="font-mono text-stone-900 text-sm">₹{payingFine.amount}</span>
              </div>
            </div>

            <p className="text-[11px] text-stone-500">
              This action administratively records receipt of payment into the library database with the current timestamp.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setPayingFine(null)}
                className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-800"
              >
                Cancel
              </button>
              <button
                onClick={handleFinePayConfirm}
                disabled={isSubmitting}
                className="px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs"
              >
                {isSubmitting ? 'Recording...' : 'Confirm Paid'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
