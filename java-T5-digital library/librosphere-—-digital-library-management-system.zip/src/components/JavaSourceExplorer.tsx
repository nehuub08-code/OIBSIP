import React, { useState } from 'react';
import { JAVA_PROJECT_FILES, JavaFileItem } from '../data/javaProjectData';
import { Code2, Download, Copy, Check, FileText, Folder, Terminal, Sparkles, Shield, Database } from 'lucide-react';

export const JavaSourceExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<JavaFileItem>(JAVA_PROJECT_FILES[2]); // FineService.java default
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadAll = () => {
    // Generate text archive or single bundled download
    const bundleText = JAVA_PROJECT_FILES.map(
      (f) => `// ==========================================\n// FILE: ${f.path}\n// ==========================================\n\n${f.content}\n\n`
    ).join('\n');

    const blob = new Blob([bundleText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'LibroSphere-JavaSpringBoot-Task5-SourceBundle.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-stone-500">
            <span>Package: com.librosphere</span>
            <span aria-hidden="true">·</span>
            <span className="text-amber-800 font-semibold">Spring Boot 3.3.4 & Maven</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-stone-900 mt-1">
            Java Spring Boot Source Explorer
          </h1>
          <p className="text-xs sm:text-sm text-stone-500">
            Browse the backend architecture in the <span className="font-mono font-medium">OIBSIP/Task5_DigitalLibraryManagementSystem</span> repository.
          </p>
        </div>

        <button
          onClick={handleDownloadAll}
          className="px-4 py-2 text-xs font-semibold text-white bg-amber-800 hover:bg-amber-900 rounded-xl transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
        >
          <Download className="w-4 h-4" />
          <span>Export Source Bundle</span>
        </button>
      </div>

      {/* Terminal & Build Instructions Banner */}
      <div className="bg-stone-900 text-stone-200 rounded-2xl p-5 border border-stone-800 space-y-3">
        <div className="flex items-center justify-between text-xs font-mono text-stone-400">
          <span className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-emerald-400" />
            Maven Terminal Commands
          </span>
          <span>Java 17+ · Spring Boot 3.3.4</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono text-xs">
          <div className="bg-stone-950 p-3 rounded-lg border border-stone-800">
            <span className="text-stone-500 block text-[10px]"># 1. Build & Compile</span>
            <span className="text-emerald-400 font-semibold">mvn clean install</span>
          </div>
          <div className="bg-stone-950 p-3 rounded-lg border border-stone-800">
            <span className="text-stone-500 block text-[10px]"># 2. Run Spring Boot Server</span>
            <span className="text-emerald-400 font-semibold">mvn spring-boot:run</span>
          </div>
          <div className="bg-stone-950 p-3 rounded-lg border border-stone-800">
            <span className="text-stone-500 block text-[10px]"># 3. Run JUnit 5 Tests</span>
            <span className="text-emerald-400 font-semibold">mvn test</span>
          </div>
        </div>
      </div>

      {/* Code Explorer Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        {/* File Navigator */}
        <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-xs lg:col-span-1 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-stone-100">
            <span className="text-xs font-semibold text-stone-700 flex items-center gap-1.5">
              <Folder className="w-4 h-4 text-amber-700" />
              Repository Files
            </span>
            <span className="text-[10px] font-mono text-stone-400">
              {JAVA_PROJECT_FILES.length} items
            </span>
          </div>

          <div className="space-y-1">
            {JAVA_PROJECT_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs font-mono transition-colors flex items-center justify-between cursor-pointer ${
                    isSelected
                      ? 'bg-amber-50 text-amber-900 font-bold border border-amber-200'
                      : 'text-stone-600 hover:bg-stone-50 hover:text-stone-900'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileText className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-amber-800' : 'text-stone-400'}`} />
                    <span className="truncate">{file.filename}</span>
                  </div>
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-stone-100 text-stone-500 shrink-0 uppercase">
                    {file.category}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Code Content Viewer */}
        <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs lg:col-span-3 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100">
            <div>
              <p className="text-xs font-mono text-stone-500">{selectedFile.path}</p>
              <h2 className="font-semibold text-stone-900 text-sm">{selectedFile.filename}</h2>
            </div>
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 text-xs font-semibold text-stone-700 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>

          {/* Syntax Code block */}
          <div className="relative">
            <pre className="p-4 rounded-xl bg-stone-950 text-stone-100 font-mono text-xs leading-relaxed overflow-x-auto max-h-[550px] scrollbar-thin">
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
