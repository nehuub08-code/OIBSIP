import React, { useState } from 'react';
import { User } from '../types/library';
import { Send, CheckCircle2, MessageSquare, Clock, MapPin, Mail, Phone } from 'lucide-react';

interface ContactViewProps {
  currentUser: User | null;
  onSubmitContact: (payload: {
    userId: string | null;
    name: string;
    email: string;
    subject: string;
    message: string;
  }) => Promise<void>;
}

export const ContactView: React.FC<ContactViewProps> = ({ currentUser, onSubmitContact }) => {
  const [name, setName] = useState(currentUser ? currentUser.fullName : '');
  const [email, setEmail] = useState(currentUser ? currentUser.email : '');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsSubmitting(true);
      await onSubmitContact({
        userId: currentUser ? currentUser.id : null,
        name: name.trim(),
        email: email.trim(),
        subject: subject.trim(),
        message: message.trim(),
      });
      setIsSuccess(true);
      setSubject('');
      setMessage('');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-2">
        <span className="text-xs font-semibold text-amber-800 uppercase tracking-wider font-mono">
          Oasis Infobyte Task 5 · Member Help Desk
        </span>
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-stone-900">
          Ask the Library Staff
        </h1>
        <p className="text-xs sm:text-sm text-stone-500 max-w-xl mx-auto">
          Need assistance with textbook reservations, research materials, borrowing policies, or fine settlements? Send our librarians a direct query.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Contact Info Card */}
        <div className="bg-stone-900 text-stone-200 rounded-2xl p-6 space-y-6 shadow-md md:col-span-1">
          <div>
            <h3 className="font-display text-lg font-bold text-white">Central Library</h3>
            <p className="text-xs text-stone-400 mt-1">Information & Loans Desk</p>
          </div>

          <div className="space-y-4 text-xs">
            <div className="flex items-start gap-3">
              <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-white">Main Stacks & Reading Hall</p>
                <p className="text-stone-400 text-[11px]">Academic Complex B, 2nd Floor</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Mail className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-white">Email Inquiries</p>
                <p className="text-stone-400 text-[11px] font-mono">library@librosphere.edu</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-white">Circulation Hours</p>
                <p className="text-stone-400 text-[11px]">Mon – Sat: 08:30 AM – 08:00 PM</p>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-stone-800 text-[11px] text-stone-400">
            <p className="font-semibold text-stone-300">Administrative Note:</p>
            <p className="mt-1 leading-relaxed">
              All inquiries submitted through this form are logged directly to the MySQL database and assigned to the duty librarian on the Admin dashboard.
            </p>
          </div>
        </div>

        {/* Contact Form */}
        <div className="bg-white border border-stone-200 rounded-2xl p-6 sm:p-8 shadow-xs md:col-span-2">
          {isSuccess ? (
            <div className="p-8 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h3 className="font-display text-xl font-bold text-stone-900">
                Inquiry Submitted Successfully
              </h3>
              <p className="text-xs text-stone-600 max-w-md mx-auto leading-relaxed">
                Thank you for contacting LibroSphere. Your message has been saved to the library management database. The administrator can view and update its progress from the Admin Console.
              </p>
              <button
                onClick={() => setIsSuccess(false)}
                className="mt-4 px-4 py-2 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 rounded-lg transition-colors cursor-pointer"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Your Full Name *</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g., Neha Vinod Borkar"
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-amber-700"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Your Email Address *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g., member@librosphere.edu"
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-amber-700"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Subject *</label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g., Request for New Edition of Effective Java"
                  className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-amber-700"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Message Details *</label>
                <textarea
                  rows={4}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Please describe your question or book acquisition request in detail..."
                  className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-amber-700 leading-relaxed"
                />
              </div>

              <div className="pt-2 flex items-center justify-between">
                <span className="text-[11px] text-stone-400">
                  {currentUser ? `Sending as authenticated member (${currentUser.username})` : 'Submitting as guest inquiry'}
                </span>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 text-xs font-semibold text-white bg-amber-800 hover:bg-amber-900 rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'Sending...' : 'Submit Query'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
