import React, { useState } from 'react';
import { Book, User } from '../types/library';
import { Search, BookPlus, Calendar, MapPin, CheckCircle, AlertCircle, Bookmark, Info, X } from 'lucide-react';

interface CatalogueViewProps {
  books: Book[];
  currentUser: User | null;
  onIssueBook: (bookId: string) => Promise<void>;
  onReserveBook: (bookId: string) => Promise<void>;
  onPromptLogin: () => void;
  isLoading: boolean;
  onRefresh: () => void;
}

const CATEGORIES = [
  'ALL',
  'Computer Science',
  'Software Engineering',
  'Information Systems',
  'Literature & Fiction',
  'Physics & Cosmology',
  'Personal Development',
];

export const CatalogueView: React.FC<CatalogueViewProps> = ({
  books,
  currentUser,
  onIssueBook,
  onReserveBook,
  onPromptLogin,
  isLoading,
  onRefresh,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [selectedBookDetails, setSelectedBookDetails] = useState<Book | null>(null);
  const [submittingBookId, setSubmittingBookId] = useState<string | null>(null);

  const filteredBooks = books.filter((book) => {
    const matchesCategory =
      selectedCategory === 'ALL' || book.category.toLowerCase() === selectedCategory.toLowerCase();
    const query = searchQuery.trim().toLowerCase();
    const matchesSearch =
      query === '' ||
      book.title.toLowerCase().includes(query) ||
      book.author.toLowerCase().includes(query) ||
      book.isbn.toLowerCase().includes(query) ||
      book.category.toLowerCase().includes(query);

    return matchesCategory && matchesSearch;
  });

  const handleIssueClick = async (book: Book) => {
    if (!currentUser) {
      onPromptLogin();
      return;
    }
    try {
      setSubmittingBookId(book.id);
      await onIssueBook(book.id);
    } finally {
      setSubmittingBookId(null);
    }
  };

  const handleReserveClick = async (book: Book) => {
    if (!currentUser) {
      onPromptLogin();
      return;
    }
    try {
      setSubmittingBookId(book.id);
      await onReserveBook(book.id);
    } finally {
      setSubmittingBookId(null);
    }
  };

  return (
    <div className="space-y-8">
      {/* Editorial Hero Header */}
      <div className="relative overflow-hidden rounded-2xl bg-stone-900 text-stone-100 p-8 sm:p-12 shadow-md">
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-300 tracking-wider uppercase font-mono">
            <span>Oasis Infobyte Task 5</span>
            <span aria-hidden="true">·</span>
            <span>Digital Library Management System</span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white text-balance leading-tight">
            Curated Knowledge, Timeless Learning
          </h1>
          <p className="text-stone-300 text-sm sm:text-base leading-relaxed max-w-2xl">
            Explore our academic collection of computer science, literature, physical sciences, and software engineering masterpieces. Borrow seamlessly with automated overdue protection and advance waitlist reservation queues.
          </p>
          <div className="pt-2 flex flex-wrap items-center gap-4 text-xs text-stone-300">
            <span className="flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              14-Day Standard Borrowing
            </span>
            <span aria-hidden="true">·</span>
            <span className="flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-amber-400" />
              ₹5/Day Automatic Overdue Rate
            </span>
            <span aria-hidden="true">·</span>
            <span className="flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-sky-400" />
              FIFO Waitlist Queue
            </span>
          </div>
        </div>

        {/* Ambient background book geometric styling */}
        <div className="absolute right-0 bottom-0 top-0 w-1/3 opacity-10 pointer-events-none flex items-center justify-center">
          <svg className="w-full h-full" viewBox="0 0 200 200" fill="currentColor">
            <path d="M20 30h160v140H20z" />
          </svg>
        </div>
      </div>

      {/* Search and Category Filter Section */}
      <div className="space-y-4">
        <div className="flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
          {/* Search Box */}
          <div className="relative flex-1 max-w-xl">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input
              type="text"
              placeholder="Search by title, author, ISBN (e.g., Clean Code, Martin, 978-)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-700 focus:border-amber-700 text-stone-900 placeholder:text-stone-400 transition-all shadow-xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto text-xs text-stone-500">
            <span>Showing <strong className="font-semibold text-stone-900 tabular-nums">{filteredBooks.length}</strong> titles</span>
            <button
              onClick={onRefresh}
              className="ml-2 text-amber-800 hover:underline cursor-pointer font-medium"
            >
              Refresh
            </button>
          </div>
        </div>

        {/* Category Tabs (Segmented interactive buttons) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-stone-900 text-white shadow-xs'
                  : 'bg-white text-stone-600 hover:text-stone-900 border border-stone-200 hover:bg-stone-50'
              }`}
            >
              {cat === 'ALL' ? 'All Collections' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Book Grid */}
      {filteredBooks.length === 0 ? (
        <div className="rounded-2xl border border-stone-200 bg-white p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-stone-100 text-stone-400 flex items-center justify-center mx-auto">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-stone-900">No books found</h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            We couldn't find any books matching "{searchQuery}" in {selectedCategory === 'ALL' ? 'our catalogue' : selectedCategory}. Try clearing your search query or selecting another category.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('ALL');
            }}
            className="mt-2 px-4 py-2 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 rounded-lg transition-colors"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBooks.map((book) => {
            const isAvailable = book.availableQuantity > 0;
            const isSubmitting = submittingBookId === book.id;

            return (
              <div
                key={book.id}
                className="bg-white rounded-xl border border-stone-200 hover:border-stone-300 transition-all flex flex-col justify-between overflow-hidden group shadow-xs hover:shadow-sm"
              >
                {/* Book Card Header */}
                <div className="p-5 space-y-3">
                  {/* Category & Shelf metadata (Unboxed, typographic separators) */}
                  <div className="flex items-center justify-between text-xs text-stone-500">
                    <span className="font-medium text-amber-800 truncate">{book.category}</span>
                    <span className="flex items-center gap-1 text-[11px] font-mono text-stone-500 shrink-0">
                      <MapPin className="w-3 h-3 text-stone-400" />
                      {book.shelfLocation}
                    </span>
                  </div>

                  {/* Title & Author */}
                  <div>
                    <h3
                      onClick={() => setSelectedBookDetails(book)}
                      className="font-display text-lg font-bold text-stone-900 group-hover:text-amber-800 transition-colors cursor-pointer line-clamp-2 leading-snug"
                    >
                      {book.title}
                    </h3>
                    <p className="text-xs text-stone-600 mt-1 font-medium">by {book.author}</p>
                  </div>

                  {/* Book Description Snippet */}
                  {book.description && (
                    <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
                      {book.description}
                    </p>
                  )}

                  {/* ISBN and Date Metadata */}
                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-400 font-mono">
                    <span>ISBN: {book.isbn}</span>
                    <span className="tabular-nums">Total: {book.totalQuantity}</span>
                  </div>
                </div>

                {/* Stock Status Bar & Action Area */}
                <div className="px-5 py-3.5 bg-stone-50/80 border-t border-stone-100 flex items-center justify-between gap-3">
                  {/* Status Indicator */}
                  <div>
                    {isAvailable ? (
                      <div className="text-xs">
                        <span className="font-semibold text-emerald-700 tabular-nums">
                          {book.availableQuantity} of {book.totalQuantity} Available
                        </span>
                        <p className="text-[10px] text-stone-400">Ready for instant loan</p>
                      </div>
                    ) : (
                      <div className="text-xs">
                        <span className="font-semibold text-rose-700">0 Available</span>
                        <p className="text-[10px] text-stone-500">Queue reservations active</p>
                      </div>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setSelectedBookDetails(book)}
                      className="p-1.5 text-stone-500 hover:text-stone-800 hover:bg-stone-200/50 rounded-lg transition-colors cursor-pointer"
                      title="View Book Information"
                    >
                      <Info className="w-4 h-4" />
                    </button>

                    {isAvailable ? (
                      <button
                        onClick={() => handleIssueClick(book)}
                        disabled={isSubmitting}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-stone-900 hover:bg-stone-800 disabled:opacity-50 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs whitespace-nowrap shrink-0"
                      >
                        <BookPlus className="w-3.5 h-3.5" />
                        <span>{isSubmitting ? 'Issuing...' : 'Issue Book'}</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => handleReserveClick(book)}
                        disabled={isSubmitting}
                        className="px-3 py-1.5 text-xs font-semibold text-amber-900 bg-amber-100 hover:bg-amber-200 disabled:opacity-50 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
                      >
                        <Bookmark className="w-3.5 h-3.5" />
                        <span>{isSubmitting ? 'Reserving...' : 'Advance Reserve'}</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Book Details Modal */}
      {selectedBookDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl border border-stone-200">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs font-medium text-amber-800 uppercase tracking-wider font-mono">
                  {selectedBookDetails.category}
                </span>
                <h2 className="font-display text-xl font-bold text-stone-900 mt-1">
                  {selectedBookDetails.title}
                </h2>
                <p className="text-xs text-stone-600 mt-0.5">Author: {selectedBookDetails.author}</p>
              </div>
              <button
                onClick={() => setSelectedBookDetails(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs text-stone-600 space-y-2 bg-stone-50 p-4 rounded-xl border border-stone-100">
              <p className="leading-relaxed">{selectedBookDetails.description || 'No extended summary available.'}</p>
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-stone-200/60 font-mono text-[11px] text-stone-500">
                <div>
                  <span className="text-stone-400">ISBN: </span>
                  <span className="text-stone-800 font-semibold">{selectedBookDetails.isbn}</span>
                </div>
                <div>
                  <span className="text-stone-400">Shelf Stack: </span>
                  <span className="text-stone-800 font-semibold">{selectedBookDetails.shelfLocation}</span>
                </div>
                <div>
                  <span className="text-stone-400">Total Copies: </span>
                  <span className="text-stone-800 font-semibold tabular-nums">{selectedBookDetails.totalQuantity}</span>
                </div>
                <div>
                  <span className="text-stone-400">Available: </span>
                  <span className={`font-semibold tabular-nums ${selectedBookDetails.availableQuantity > 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                    {selectedBookDetails.availableQuantity}
                  </span>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-stone-500 space-y-1">
              <p className="font-semibold text-stone-700">Library Borrowing Policy:</p>
              <ul className="list-disc list-inside space-y-0.5 text-stone-500">
                <li>14 days loan duration with automatic reminder alerts.</li>
                <li>Overdue fee assessed at ₹5.00 per calendar day beyond due date.</li>
                <li>Members are limited to a maximum of 3 concurrent active loans.</li>
              </ul>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setSelectedBookDetails(null)}
                className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-800 hover:bg-stone-100 rounded-lg"
              >
                Close
              </button>
              {selectedBookDetails.availableQuantity > 0 ? (
                <button
                  onClick={() => {
                    handleIssueClick(selectedBookDetails);
                    setSelectedBookDetails(null);
                  }}
                  className="px-4 py-2 text-xs font-semibold text-white bg-amber-800 hover:bg-amber-900 rounded-lg shadow-xs"
                >
                  Issue This Book
                </button>
              ) : (
                <button
                  onClick={() => {
                    handleReserveClick(selectedBookDetails);
                    setSelectedBookDetails(null);
                  }}
                  className="px-4 py-2 text-xs font-semibold text-amber-900 bg-amber-100 hover:bg-amber-200 rounded-lg"
                >
                  Place Advance Reservation
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
