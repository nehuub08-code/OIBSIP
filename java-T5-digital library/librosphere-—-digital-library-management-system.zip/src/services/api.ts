import { Book, User, AdminOverview, UserDashboardData, ContactMessage, BookIssue, Reservation, Fine } from '../types/library';

const BASE_URL = '/api';

export async function fetchHealth() {
  const res = await fetch(`${BASE_URL}/health`);
  return res.json();
}

export async function apiLogin(usernameOrEmail: string, password: string):Promise<{ message: string; user: User }> {
  const res = await fetch(`${BASE_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usernameOrEmail, password }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to login');
  return data;
}

export async function apiRegister(payload: {
  fullName: string;
  email: string;
  username: string;
  password: string;
  confirmPassword: string;
}): Promise<{ message: string; user: User }> {
  const res = await fetch(`${BASE_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Registration failed');
  return data;
}

export async function apiGetBooks(query?: string, category?: string): Promise<Book[]> {
  const params = new URLSearchParams();
  if (query) params.append('query', query);
  if (category && category !== 'ALL') params.append('category', category);
  
  const res = await fetch(`${BASE_URL}/books?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch books');
  return res.json();
}

export async function apiAddBook(book: Partial<Book>): Promise<{ message: string; book: Book }> {
  const res = await fetch(`${BASE_URL}/books`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(book),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to add book');
  return data;
}

export async function apiUpdateBook(id: string, book: Partial<Book>): Promise<{ message: string; book: Book }> {
  const res = await fetch(`${BASE_URL}/books/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(book),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update book');
  return data;
}

export async function apiDeleteBook(id: string): Promise<{ message: string }> {
  const res = await fetch(`${BASE_URL}/books/${id}`, {
    method: 'DELETE',
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to delete book');
  return data;
}

export async function apiIssueBook(userId: string, bookId: string): Promise<{ message: string; issue: BookIssue; dueDate: string }> {
  const res = await fetch(`${BASE_URL}/issues`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId, bookId }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to issue book');
  return data;
}

export async function apiReturnBook(
  issueId: string,
  requestingUserId: string,
  simulatedReturnDate?: string
): Promise<{
  message: string;
  dueDate: string;
  returnDate: string;
  overdueDays: number;
  fineAmount: number;
  fineRecord: Fine | null;
}> {
  const res = await fetch(`${BASE_URL}/issues/${issueId}/return`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ requestingUserId, simulatedReturnDate }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to return book');
  return data;
}

export async function apiReserveBook(userId: string, bookId: string): Promise<{ message: string; reservation: Reservation }> {
  const res = await fetch(`${BASE_URL}/reservations`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId, bookId }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to reserve book');
  return data;
}

export async function apiCancelReservation(reservationId: string, userId: string): Promise<{ message: string }> {
  const res = await fetch(`${BASE_URL}/reservations/${reservationId}`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to cancel reservation');
  return data;
}

export async function apiPayFine(fineId: string, adminUserId: string): Promise<{ message: string; fine: Fine }> {
  const res = await fetch(`${BASE_URL}/fines/${fineId}/pay`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ adminUserId }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to mark fine as paid');
  return data;
}

export async function apiSubmitContact(payload: {
  userId: string | null;
  name: string;
  email: string;
  subject: string;
  message: string;
}): Promise<{ message: string; query: ContactMessage }> {
  const res = await fetch(`${BASE_URL}/contacts`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to submit message');
  return data;
}

export async function apiUpdateContactStatus(
  contactId: string,
  status: 'NEW' | 'IN_PROGRESS' | 'RESOLVED',
  adminUserId: string
): Promise<{ message: string }> {
  const res = await fetch(`${BASE_URL}/contacts/${contactId}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status, adminUserId }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update contact status');
  return data;
}

export async function apiToggleMemberStatus(
  memberId: string,
  accountStatus: 'ACTIVE' | 'DEACTIVATED',
  adminUserId: string
): Promise<{ message: string }> {
  const res = await fetch(`${BASE_URL}/members/${memberId}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ accountStatus, adminUserId }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update member status');
  return data;
}

export async function apiGetUserDashboard(userId: string): Promise<UserDashboardData> {
  const res = await fetch(`${BASE_URL}/user/${userId}/dashboard`);
  if (!res.ok) throw new Error('Failed to fetch user dashboard');
  return res.json();
}

export async function apiGetAdminOverview(): Promise<AdminOverview> {
  const res = await fetch(`${BASE_URL}/admin/overview`);
  if (!res.ok) throw new Error('Failed to fetch admin overview');
  return res.json();
}

export async function apiResetDatabase(): Promise<{ message: string }> {
  const res = await fetch(`${BASE_URL}/admin/reset-database`, { method: 'POST' });
  return res.json();
}
