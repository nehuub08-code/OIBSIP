export interface JavaFileItem {
  path: string;
  filename: string;
  language: string;
  category: 'Configuration' | 'Entities' | 'Services' | 'Controllers' | 'Repositories' | 'Tests' | 'SQL';
  content: string;
}

export const JAVA_PROJECT_FILES: JavaFileItem[] = [
  {
    path: 'pom.xml',
    filename: 'pom.xml',
    language: 'xml',
    category: 'Configuration',
    content: `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.3.4</version>
        <relativePath/>
    </parent>
    <groupId>com.librosphere</groupId>
    <artifactId>librosphere-library-system</artifactId>
    <version>1.0.0</version>
    <name>LibroSphere — Digital Library Management System</name>
    <description>Oasis Infobyte Java Development Task 5 by Neha Vinod Borkar.</description>
    <properties>
        <java.version>17</java.version>
    </properties>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-validation</artifactId>
        </dependency>
        <dependency>
            <groupId>com.mysql</groupId>
            <artifactId>mysql-connector-j</artifactId>
            <scope>runtime</scope>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
</project>`
  },
  {
    path: 'src/main/resources/application.properties',
    filename: 'application.properties',
    language: 'properties',
    category: 'Configuration',
    content: `# LibroSphere Spring Boot Configuration
spring.application.name=LibroSphere
server.port=8080

spring.datasource.url=\${DB_URL:jdbc:mysql://localhost:3306/librosphere_db?useSSL=false&serverTimezone=UTC}
spring.datasource.username=\${DB_USERNAME:root}
spring.datasource.password=\${DB_PASSWORD:root}
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=false

# Task 5 Business Rules
library.borrowing.duration-days=14
library.borrowing.max-active-issues=3
library.fines.rate-per-day=5.00
library.reservation.pickup-hold-days=3`
  },
  {
    path: 'src/main/java/com/librosphere/service/FineService.java',
    filename: 'FineService.java',
    language: 'java',
    category: 'Services',
    content: `package com.librosphere.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Service for calculating overdue fines based on calendar dates.
 * Policy: ₹5 per overdue calendar day.
 */
@Service
public class FineService {

    private final BigDecimal ratePerDay;

    public FineService(@Value("\${library.fines.rate-per-day:5.00}") BigDecimal ratePerDay) {
        this.ratePerDay = ratePerDay;
    }

    public BigDecimal calculateOverdueFine(LocalDate dueDate, LocalDate returnDate) {
        if (dueDate == null || returnDate == null) {
            throw new IllegalArgumentException("Due date and return date cannot be null.");
        }
        if (!returnDate.isAfter(dueDate)) {
            return BigDecimal.ZERO;
        }
        long overdueDays = ChronoUnit.DAYS.between(dueDate, returnDate);
        return overdueDays > 0 ? ratePerDay.multiply(BigDecimal.valueOf(overdueDays)) : BigDecimal.ZERO;
    }

    public long getOverdueDays(LocalDate dueDate, LocalDate returnDate) {
        if (dueDate == null || returnDate == null || !returnDate.isAfter(dueDate)) {
            return 0;
        }
        return ChronoUnit.DAYS.between(dueDate, returnDate);
    }
}`
  },
  {
    path: 'src/main/java/com/librosphere/config/SecurityConfig.java',
    filename: 'SecurityConfig.java',
    language: 'java',
    category: 'Configuration',
    content: `package com.librosphere.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/", "/books", "/books/search", "/contact", "/auth/**").permitAll()
                .requestMatchers("/admin/**").hasRole("ADMIN")
                .requestMatchers("/user/**", "/issues/**", "/reservations/**").hasAnyRole("USER", "ADMIN")
                .anyRequest().authenticated()
            )
            .formLogin(login -> login
                .loginPage("/auth/login")
                .defaultSuccessUrl("/auth/redirect-by-role", true)
                .permitAll()
            )
            .logout(logout -> logout
                .logoutSuccessUrl("/auth/login?logout=true")
                .invalidateHttpSession(true)
                .permitAll()
            );
        return http.build();
    }
}`
  },
  {
    path: 'src/main/java/com/librosphere/entity/Book.java',
    filename: 'Book.java',
    language: 'java',
    category: 'Entities',
    content: `package com.librosphere.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "books")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 255)
    private String title;

    @Column(nullable = false, length = 200)
    private String author;

    @Column(nullable = false, unique = true, length = 50)
    private String isbn;

    @Column(nullable = false, length = 100)
    private String category;

    @Column(name = "total_quantity", nullable = false)
    private Integer totalQuantity;

    @Column(name = "available_quantity", nullable = false)
    private Integer availableQuantity;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "shelf_location", length = 100)
    private String shelfLocation;
}`
  },
  {
    path: 'src/main/java/com/librosphere/entity/BookIssue.java',
    filename: 'BookIssue.java',
    language: 'java',
    category: 'Entities',
    content: `package com.librosphere.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "book_issues")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookIssue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "book_id", nullable = false)
    private Book book;

    @Column(name = "issue_date", nullable = false)
    private LocalDate issueDate;

    @Column(name = "due_date", nullable = false)
    private LocalDate dueDate;

    @Column(name = "return_date")
    private LocalDate returnDate;

    @Column(nullable = false, length = 20)
    private String status; // "ACTIVE" or "RETURNED"

    @Column(name = "fine_amount", precision = 10, scale = 2)
    private BigDecimal fineAmount;
}`
  },
  {
    path: 'src/test/java/com/librosphere/FineCalculationTest.java',
    filename: 'FineCalculationTest.java',
    language: 'java',
    category: 'Tests',
    content: `package com.librosphere;

import com.librosphere.service.FineService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

class FineCalculationTest {

    private FineService fineService;

    @BeforeEach
    void setUp() {
        fineService = new FineService(new BigDecimal("5.00"));
    }

    @Test
    @DisplayName("On-time return generates ₹0 fine")
    void testReturnOnDueDateGeneratesZeroFine() {
        LocalDate due = LocalDate.of(2026, 10, 10);
        LocalDate returned = LocalDate.of(2026, 10, 10);
        assertEquals(BigDecimal.ZERO, fineService.calculateOverdueFine(due, returned));
    }

    @Test
    @DisplayName("Overdue by 3 days generates ₹15 fine")
    void testThreeDaysOverdueGeneratesFifteenRupeesFine() {
        LocalDate due = LocalDate.of(2026, 10, 10);
        LocalDate returned = LocalDate.of(2026, 10, 13);
        assertEquals(new BigDecimal("15.00"), fineService.calculateOverdueFine(due, returned));
    }
}`
  },
  {
    path: 'src/main/resources/schema.sql',
    filename: 'schema.sql',
    language: 'sql',
    category: 'SQL',
    content: `CREATE DATABASE IF NOT EXISTS librosphere_db;
USE librosphere_db;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'USER',
    account_status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS books (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(200) NOT NULL,
    isbn VARCHAR(50) NOT NULL UNIQUE,
    category VARCHAR(100) NOT NULL,
    total_quantity INT NOT NULL DEFAULT 1,
    available_quantity INT NOT NULL DEFAULT 1,
    description TEXT,
    shelf_location VARCHAR(100) DEFAULT 'General Stacks',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS book_issues (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    book_id BIGINT NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    fine_amount DECIMAL(10,2) DEFAULT 0.00,
    CONSTRAINT fk_issue_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_issue_book FOREIGN KEY (book_id) REFERENCES books(id)
);`
  }
];
