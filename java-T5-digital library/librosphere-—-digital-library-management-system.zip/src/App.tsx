import React, { useState, useEffect } from 'react';
import { Book, User, AdminOverview, UserDashboardData } from './types/library';
import {
  apiGetBooks,
  apiLogin,
  apiRegister,
  apiIssueBook,
  apiReturnBook,
  apiReserveBook,
  apiCancelReservation,
  apiAddBook,
  apiUpdateBook,
  apiDeleteBook,
  apiPayFine,
  apiToggleMemberStatus,
  apiUpdateContactStatus,
  apiSubmitContact,
  apiGetUserDashboard,
  apiGetAdminOverview,
  apiResetDatabase,
} from './services/api';
import { Navbar } from './components/Navbar';
import { CatalogueView } from './components/CatalogueView';
import { UserDashboardView } from './components/UserDashboardView';
import { AdminDashboardView } from './components/AdminDashboardView';
import { ContactView } from './components/ContactView';
import { OasisDemoRunner } from './components/OasisDemoRunner';
import { JavaSourceExplorer } from './components/JavaSourceExplorer';
import { AuthModals } from './components/AuthModals';
import { CheckCircle2, AlertCircle, X, Shield, BookOpen, Heart } from 'lucide-react';

export default function App() {
  // App navigation tabs
  const [activeTab, setActiveTab] = useState<'catalogue' | 'user-dashboard' | 'admin-dashboard' | 'contact' | 'java-source' | 'demo-runner'>('catalogue');

  // Authenticated User State (Initial default to Neha Vinod Borkar for immediate feature exploration)
  const [currentUser, setCurrentUser] = useState<User | null>({
    id: 'usr-user-1',
    fullName: 'Neha Vinod Borkar',
    email: 'nehaborkar2408@gmail.com',
    username: 'nehaborkar',
    role: 'USER',
    accountStatus: 'ACTIVE',
    createdAt: '2026-02-01T10:30:00Z',
  });

  // Modal Auth states
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);

  // Global Data states
  const [books, setBooks] = useState<Book[]>([]);
  const [userDashboardData, setUserDashboardData] = useState<UserDashboardData | null>(null);
  const [adminOverview, setAdminOverview] = useState<AdminOverview | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Toast notification state
  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => {
      setToast((prev) => (prev?.message === message ? null : prev));
    }, 4500);
  };

  // Load Catalogue
  const loadBooks = async () => {
    try {
      setIsLoading(true);
      const data = await apiGetBooks();
      setBooks(data);
    } catch (err: any) {
      showToast('error', err.message || 'Failed to load books catalogue.');
    } finally {
      setIsLoading(false);
    }
  };

  // Load User Dashboard
  const loadUserDashboard = async () => {
    if (!currentUser || currentUser.role !== 'USER') return;
    try {
      const data = await apiGetUserDashboard(currentUser.id);
      setUserDashboardData(data);
    } catch (err: any) {
      console.error('Failed to load user dashboard', err);
    }
  };

  // Load Admin Overview
  const loadAdminOverview = async () => {
    if (!currentUser || currentUser.role !== 'ADMIN') return;
    try {
      const data = await apiGetAdminOverview();
      setAdminOverview(data);
    } catch (err: any) {
      console.error('Failed to load admin overview', err);
    }
  };

  // Initial and reactive data fetching
  useEffect(() => {
    loadBooks();
  }, []);

  useEffect(() => {
    if (currentUser?.role === 'USER') {
      loadUserDashboard();
    } else if (currentUser?.role === 'ADMIN') {
      loadAdminOverview();
    }
  }, [currentUser]);

  const refreshAll = () => {
    loadBooks();
    if (currentUser?.role === 'USER') loadUserDashboard();
    if (currentUser?.role === 'ADMIN') loadAdminOverview();
  };

  // Handlers
  const handleLogin = async (usernameOrEmail: string, pass: string) => {
    const res = await apiLogin(usernameOrEmail, pass);
    setCurrentUser(res.user);
    showToast('success', `Welcome back, ${res.user.fullName}!`);
    if (res.user.role === 'ADMIN') {
      setActiveTab('admin-dashboard');
    } else {
      setActiveTab('user-dashboard');
    }
  };

  const handleRegister = async (payload: {
    fullName: string;
    email: string;
    username: string;
    password: string;
    confirmPassword: string;
  }) => {
    const res = await apiRegister(payload);
    showToast('success', res.message);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setUserDashboardData(null);
    setAdminOverview(null);
    setActiveTab('catalogue');
    showToast('success', 'You have been signed out successfully.');
  };

  const handleQuickSwitchUser = async (username: string) => {
    try {
      if (username === 'admin') {
        await handleLogin('admin', 'Admin@123');
      } else if (username === 'nehaborkar') {
        await handleLogin('nehaborkar', 'User@123');
      } else if (username === 'rahulsharma') {
        await handleLogin('rahulsharma', 'User@123');
      }
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  // User Actions: Borrow / Return / Reserve
  const handleIssueBook = async (bookId: string) => {
    if (!currentUser) {
      setIsLoginOpen(true);
      return;
    }
    try {
      const res = await apiIssueBook(currentUser.id, bookId);
      showToast('success', res.message);
      refreshAll();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  const handleReturnBook = async (issueId: string, simulatedDate?: string) => {
    if (!currentUser) return;
    try {
      const res = await apiReturnBook(issueId, currentUser.id, simulatedDate);
      if (res.fineAmount > 0) {
        showToast('success', `${res.message} Overdue fine generated: ₹${res.fineAmount} (${res.overdueDays} days late).`);
      } else {
        showToast('success', `${res.message} Returned on-time with ₹0 fine.`);
      }
      refreshAll();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  const handleReserveBook = async (bookId: string) => {
    if (!currentUser) {
      setIsLoginOpen(true);
      return;
    }
    try {
      const res = await apiReserveBook(currentUser.id, bookId);
      showToast('success', res.message);
      refreshAll();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  const handleCancelReservation = async (reservationId: string) => {
    if (!currentUser) return;
    try {
      const res = await apiCancelReservation(reservationId, currentUser.id);
      showToast('success', res.message);
      refreshAll();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  // Admin Actions
  const handleAddBook = async (book: Partial<Book>) => {
    try {
      const res = await apiAddBook(book);
      showToast('success', res.message);
      refreshAll();
    } catch (err: any) {
      showToast('error', err.message);
      throw err;
    }
  };

  const handleEditBook = async (id: string, book: Partial<Book>) => {
    try {
      const res = await apiUpdateBook(id, book);
      showToast('success', res.message);
      refreshAll();
    } catch (err: any) {
      showToast('error', err.message);
      throw err;
    }
  };

  const handleDeleteBook = async (id: string) => {
    try {
      const res = await apiDeleteBook(id);
      showToast('success', res.message);
      refreshAll();
    } catch (err: any) {
      showToast('error', err.message);
      throw err;
    }
  };

  const handlePayFine = async (fineId: string) => {
    if (!currentUser || currentUser.role !== 'ADMIN') return;
    try {
      const res = await apiPayFine(fineId, currentUser.id);
      showToast('success', res.message);
      refreshAll();
    } catch (err: any) {
      showToast('error', err.message);
      throw err;
    }
  };

  const handleToggleMemberStatus = async (memberId: string, status: 'ACTIVE' | 'DEACTIVATED') => {
    if (!currentUser || currentUser.role !== 'ADMIN') return;
    try {
      const res = await apiToggleMemberStatus(memberId, status, currentUser.id);
      showToast('success', res.message);
      refreshAll();
    } catch (err: any) {
      showToast('error', err.message);
      throw err;
    }
  };

  const handleUpdateQueryStatus = async (contactId: string, status: 'NEW' | 'IN_PROGRESS' | 'RESOLVED') => {
    if (!currentUser || currentUser.role !== 'ADMIN') return;
    try {
      const res = await apiUpdateContactStatus(contactId, status, currentUser.id);
      showToast('success', res.message);
      refreshAll();
    } catch (err: any) {
      showToast('error', err.message);
      throw err;
    }
  };

  const handleSubmitContact = async (payload: {
    userId: string | null;
    name: string;
    email: string;
    subject: string;
    message: string;
  }) => {
    try {
      const res = await apiSubmitContact(payload);
      showToast('success', res.message);
      refreshAll();
    } catch (err: any) {
      showToast('error', err.message);
      throw err;
    }
  };

  const handleResetDatabase = async () => {
    try {
      const res = await apiResetDatabase();
      showToast('success', res.message);
      refreshAll();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 text-stone-900 font-sans antialiased">
      {/* Top Bar Navigation */}
      <Navbar
        currentUser={currentUser}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenLogin={() => setIsLoginOpen(true)}
        onOpenRegister={() => setIsRegisterOpen(true)}
        onLogout={handleLogout}
        onQuickSwitchUser={handleQuickSwitchUser}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'catalogue' && (
          <CatalogueView
            books={books}
            currentUser={currentUser}
            onIssueBook={handleIssueBook}
            onReserveBook={handleReserveBook}
            onPromptLogin={() => setIsLoginOpen(true)}
            isLoading={isLoading}
            onRefresh={refreshAll}
          />
        )}

        {activeTab === 'user-dashboard' && userDashboardData && (
          <UserDashboardView
            dashboardData={userDashboardData}
            onReturnBook={handleReturnBook}
            onCancelReservation={handleCancelReservation}
            onNavigateToCatalogue={() => setActiveTab('catalogue')}
            onNavigateToContact={() => setActiveTab('contact')}
            onRefresh={refreshAll}
          />
        )}

        {activeTab === 'admin-dashboard' && adminOverview && (
          <AdminDashboardView
            overview={adminOverview}
            books={books}
            onAddBook={handleAddBook}
            onEditBook={handleEditBook}
            onDeleteBook={handleDeleteBook}
            onPayFine={handlePayFine}
            onToggleMemberStatus={handleToggleMemberStatus}
            onUpdateQueryStatus={handleUpdateQueryStatus}
            onResetDatabase={handleResetDatabase}
            onRefresh={refreshAll}
          />
        )}

        {activeTab === 'contact' && (
          <ContactView
            currentUser={currentUser}
            onSubmitContact={handleSubmitContact}
          />
        )}

        {activeTab === 'demo-runner' && (
          <OasisDemoRunner onRefreshAll={refreshAll} />
        )}

        {activeTab === 'java-source' && (
          <JavaSourceExplorer />
        )}
      </main>

      {/* Toast Feedback Notification Banner */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 max-w-md animate-in slide-in-from-bottom-3 duration-200">
          <div
            className={`flex items-start gap-3 p-4 rounded-xl shadow-xl border text-xs leading-relaxed ${
              toast.type === 'success'
                ? 'bg-stone-900 text-stone-100 border-stone-800'
                : 'bg-rose-900 text-rose-100 border-rose-800'
            }`}
          >
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-300 shrink-0 mt-0.5" />
            )}
            <div className="flex-1 font-medium">{toast.message}</div>
            <button
              onClick={() => setToast(null)}
              className="text-stone-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Authentication Modals */}
      <AuthModals
        isLoginOpen={isLoginOpen}
        isRegisterOpen={isRegisterOpen}
        onCloseLogin={() => setIsLoginOpen(false)}
        onCloseRegister={() => setIsRegisterOpen(false)}
        onSwitchToRegister={() => {
          setIsLoginOpen(false);
          setIsRegisterOpen(true);
        }}
        onSwitchToLogin={() => {
          setIsRegisterOpen(false);
          setIsLoginOpen(true);
        }}
        onLogin={handleLogin}
        onRegister={handleRegister}
      />

      {/* Editorial Footer */}
      <footer className="bg-white border-t border-stone-200 mt-16 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-stone-900">LibroSphere</span>
            <span aria-hidden="true">·</span>
            <span>Oasis Infobyte Internship — Java Development Task 5</span>
          </div>
          <div className="flex items-center gap-2 font-mono text-[11px]">
            <span>Developer: <strong className="text-stone-800 font-sans">Neha Vinod Borkar</strong></span>
            <span aria-hidden="true">·</span>
            <span className="text-stone-400">Spring Boot 3.3.4 · MySQL · Spring Security</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
