package com.librosphere.repository;

import com.librosphere.entity.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    List<Reservation> findByUserId(Long userId);

    List<Reservation> findByBookIdAndStatusOrderByCreatedAtAsc(Long bookId, String status);

    boolean existsByUserIdAndBookIdAndStatusIn(Long userId, Long bookId, List<String> statuses);

    long countByBookIdAndStatus(Long bookId, String status);
}
