package com.librosphere.repository;

import com.librosphere.entity.ContactMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ContactMessageRepository extends JpaRepository<ContactMessage, Long> {

    List<ContactMessage> findByStatusOrderByCreatedAtDesc(String status);

    List<ContactMessage> findByUserIdOrderByCreatedAtDesc(Long userId);
}
