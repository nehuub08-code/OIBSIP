package com.librosphere.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Service handling overdue calculations and fine assessment based on calendar days.
 * Policy: ₹5.00 per overdue calendar day.
 */
@Service
public class FineService {

    private final BigDecimal ratePerDay;

    public FineService(@Value("${library.fines.rate-per-day:5.00}") BigDecimal ratePerDay) {
        this.ratePerDay = ratePerDay;
    }

    /**
     * Calculates fine based on calendar dates using ChronoUnit.DAYS.
     *
     * @param dueDate the agreed return deadline
     * @param returnDate the actual date the book was returned
     * @return calculated fine amount (0.00 if on-time or early)
     */
    public BigDecimal calculateOverdueFine(LocalDate dueDate, LocalDate returnDate) {
        if (dueDate == null || returnDate == null) {
            throw new IllegalArgumentException("Due date and return date cannot be null.");
        }

        if (!returnDate.isAfter(dueDate)) {
            return BigDecimal.ZERO;
        }

        long overdueDays = ChronoUnit.DAYS.between(dueDate, returnDate);
        if (overdueDays <= 0) {
            return BigDecimal.ZERO;
        }

        return ratePerDay.multiply(BigDecimal.valueOf(overdueDays));
    }

    public long getOverdueDays(LocalDate dueDate, LocalDate returnDate) {
        if (dueDate == null || returnDate == null || !returnDate.isAfter(dueDate)) {
            return 0;
        }
        return ChronoUnit.DAYS.between(dueDate, returnDate);
    }
}
