package com.librosphere.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "fines")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Fine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "book_issue_id", nullable = false)
    private BookIssue bookIssue;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "book_id", nullable = false)
    private Book book;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal amount;

    @Column(nullable = false, length = 20)
    private String status; // "UNPAID", "PAID"

    @Column(name = "calculated_timestamp", nullable = false)
    private LocalDateTime calculatedTimestamp;

    @Column(name = "paid_timestamp")
    private LocalDateTime paidTimestamp;

    @PrePersist
    protected void onCreate() {
        if (this.calculatedTimestamp == null) {
            this.calculatedTimestamp = LocalDateTime.now();
        }
        if (this.status == null) {
            this.status = "UNPAID";
        }
    }
}
