package com.librosphere.repository;

import com.librosphere.entity.BookIssue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookIssueRepository extends JpaRepository<BookIssue, Long> {

    List<BookIssue> findByUserId(Long userId);

    List<BookIssue> findByUserIdAndStatus(Long userId, String status);

    List<BookIssue> findByBookIdAndStatus(Long bookId, String status);

    long countByUserIdAndStatus(Long userId, String status);

    long countByBookIdAndStatus(Long bookId, String status);
}
