package com.librosphere;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * LibroSphere - Digital Library Management System
 * Oasis Infobyte Java Development Internship - Task 5
 * Developer: Neha Vinod Borkar
 */
@SpringBootApplication
public class LibroSphereApplication {

    public static void main(String[] args) {
        SpringApplication.run(LibroSphereApplication.class, args);
        System.out.println("==================================================");
        System.out.println("  LibroSphere Digital Library Management System   ");
        System.out.println("  Developer: Neha Vinod Borkar                   ");
        System.out.println("  Spring Boot Backend & Security Active          ");
        System.out.println("==================================================");
    }
}
