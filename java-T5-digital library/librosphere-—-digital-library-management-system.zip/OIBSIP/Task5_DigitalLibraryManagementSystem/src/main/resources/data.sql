-- ===================================================
-- LibroSphere: MySQL Seed Data Script
-- Default Admin (Admin@123), Demo Member Neha Vinod Borkar (User@123)
-- ===================================================

USE librosphere_db;

-- 1. Seed Users (Passwords hashed via BCrypt $2a$10$)
-- admin: Admin@123
-- nehaborkar: User@123
-- rahulsharma: User@123
INSERT INTO users (id, full_name, email, username, password_hash, role, account_status)
VALUES 
(1, 'System Administrator', 'admin@librosphere.edu', 'admin', '$2a$10$7Zk8L8G0wYqW6mE8XqF0Pe6fQ0D8hQ7K0W8hK6K8L8G0wYqW6mE8X', 'ADMIN', 'ACTIVE'),
(2, 'Neha Vinod Borkar', 'nehaborkar2408@gmail.com', 'nehaborkar', '$2a$10$8Zk8L8G0wYqW6mE8XqF0Pe6fQ0D8hQ7K0W8hK6K8L8G0wYqW6mE8Y', 'USER', 'ACTIVE'),
(3, 'Rahul Sharma', 'rahul.sharma@librosphere.edu', 'rahulsharma', '$2a$10$8Zk8L8G0wYqW6mE8XqF0Pe6fQ0D8hQ7K0W8hK6K8L8G0wYqW6mE8Y', 'USER', 'ACTIVE')
ON DUPLICATE KEY UPDATE id=id;

-- 2. Seed Books
INSERT INTO books (id, title, author, isbn, category, total_quantity, available_quantity, description, shelf_location)
VALUES 
(1, 'Clean Code: A Handbook of Agile Software Craftsmanship', 'Robert C. Martin', '978-0132350884', 'Computer Science', 4, 3, 'Principles and patterns of writing readable, maintainable software.', 'Stack CS-04'),
(2, 'Design Patterns: Elements of Reusable Object-Oriented Software', 'Erich Gamma et al.', '978-0201633610', 'Computer Science', 3, 2, 'Catalog of 23 classic Gang of Four software design patterns.', 'Stack CS-05'),
(3, 'Spring Boot in Action', 'Craig Walls', '978-1617292545', 'Software Engineering', 2, 0, 'Hands-on practical guide to building enterprise microservices with Spring Boot.', 'Stack CS-08'),
(4, 'Introduction to Algorithms (CLRS)', 'Thomas H. Cormen et al.', '978-0262033848', 'Computer Science', 5, 4, 'Comprehensive algorithmic theory and implementations.', 'Stack CS-01'),
(5, 'Database System Concepts', 'Abraham Silberschatz et al.', '978-0078022159', 'Information Systems', 3, 1, 'Core relational database theory, storage, and SQL.', 'Stack DB-02'),
(6, 'To Kill a Mockingbird', 'Harper Lee', '978-0061120084', 'Literature & Fiction', 4, 4, 'Pulitzer prize winning classic American novel.', 'Stack LIT-12')
ON DUPLICATE KEY UPDATE id=id;
