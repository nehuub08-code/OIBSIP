package com.librosphere;

import com.librosphere.service.FineService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Test for FineService calendar-day calculation logic.
 * Default policy: ₹5 per overdue day.
 */
class FineCalculationTest {

    private FineService fineService;

    @BeforeEach
    void setUp() {
        fineService = new FineService(new BigDecimal("5.00"));
    }

    @Test
    @DisplayName("Should return ₹0 fine when returned on the due date")
    void testReturnOnDueDateGeneratesZeroFine() {
        LocalDate due = LocalDate.of(2026, 10, 10);
        LocalDate returned = LocalDate.of(2026, 10, 10);

        BigDecimal fine = fineService.calculateOverdueFine(due, returned);
        assertEquals(BigDecimal.ZERO, fine);
        assertEquals(0, fineService.getOverdueDays(due, returned));
    }

    @Test
    @DisplayName("Should return ₹0 fine when returned before the due date")
    void testEarlyReturnGeneratesZeroFine() {
        LocalDate due = LocalDate.of(2026, 10, 10);
        LocalDate returned = LocalDate.of(2026, 10, 8);

        BigDecimal fine = fineService.calculateOverdueFine(due, returned);
        assertEquals(BigDecimal.ZERO, fine);
    }

    @Test
    @DisplayName("Should charge exactly ₹15 when returned 3 days after due date (10 Oct vs 13 Oct)")
    void testThreeDaysOverdueGeneratesFifteenRupeesFine() {
        LocalDate due = LocalDate.of(2026, 10, 10);
        LocalDate returned = LocalDate.of(2026, 10, 13);

        BigDecimal fine = fineService.calculateOverdueFine(due, returned);
        long overdueDays = fineService.getOverdueDays(due, returned);

        assertEquals(3, overdueDays);
        assertEquals(new BigDecimal("15.00"), fine);
    }

    @Test
    @DisplayName("Should reject null dates with IllegalArgumentException")
    void testNullDatesThrowException() {
        assertThrows(IllegalArgumentException.class, () -> {
            fineService.calculateOverdueFine(null, LocalDate.now());
        });
    }
}
