# LibroSphere — Digital Library Management System
**Oasis Infobyte Internship — Java Development Track**  
**Task Title:** Task 5 — Digital Library Management System  
**Developer:** Neha Vinod Borkar  
**Repository:** `OIBSIP/Task5_DigitalLibraryManagementSystem`  

---

## 1. Project Overview & Objective
**LibroSphere** is a full-stack, enterprise-grade Digital Library Management System architected with Spring Boot, Spring Security, Spring Data JPA, and MySQL. It empowers libraries with role-based access control (Admin and User), real-time book inventory management, transactional borrowing workflows, automatic calendar-based overdue fine calculations (₹5/day), advance waitlist reservations for out-of-stock titles, member account lifecycle governance, and an integrated contact query desk.

Every transaction strictly enforces atomic consistency, inventory safeguards against overselling, server-side role validation, and cryptographic password hashing with BCrypt.

---

## 2. Core Features by Role

### 🛡️ Admin Module
- **Live Analytical Dashboard:** Instant counters for Total Catalog Books, Available Copies, Active Borrowed Copies, Registered Members, Outstanding Fines, and Pending Queries.
- **Book Inventory Management (Full CRUD):**
  - Add new titles with validated ISBN, author, category, shelf stack, and quantity.
  - Edit existing titles with automatic stock rebalancing (safeguarded against reducing total quantity below actively issued copies).
  - Safe deletion: Deletion is strictly blocked if there are active loans or unfulfilled reservations.
- **Issued Books Monitoring:** Master ledger of all loans with real-time status indicators (Active, Returned, Overdue), filterable by member, book title, or overdue state.
- **Member Management:** View registered members, their loan history, outstanding fine tallies, and activate or deactivate accounts safely.
- **Administrative Fine Ledger:** Review generated fines, filter by Unpaid/Paid status, and administratively record payments with payment timestamps. *(Note: Fine payment is administratively recorded by authorized staff; it does not process through an external monetary payment gateway).*
- **Advance Reservation Queue:** Oversee waitlists for fully issued books and verify queue priority when returns occur.
- **Help Desk Query Management:** Review inquiries submitted by members or visitors, transition statuses (`NEW` ➔ `IN_PROGRESS` ➔ `RESOLVED`), and view sender timestamps.

### 👤 Member (User) Module
- **Public & Authenticated Book Catalogue:** Search dynamically by title, author, category, or ISBN with immediate real-time availability counters.
- **Personal Dashboard:**
  - Welcome banner with personalized display name and account ID.
  - Currently borrowed books with due date indicators and overdue alert banners.
  - One-click book return workflow with dynamic overdue fine generation.
- **Book Borrowing (Issuing):**
  - Instant borrow for titles with available stock (14-day standard borrowing window).
  - Enforces max active loans limit (3 books) and blocks duplicate concurrent loans of the same title.
- **Advance Waitlist Reservation:**
  - When copies reach zero, members can reserve a spot in the FIFO reservation queue.
  - Automatic `READY_FOR_PICKUP` transition with a 3-day hold window when a copy is returned.
  - Ability to cancel pending reservations anytime.
- **Fine Center:** View personalized overdue fine history, penalty calculations (₹5 per overdue calendar day), and administrative clearance status.
- **Contact Desk:** Submit queries, book requests, or feedback directly to library staff with prefilled user credentials.

---

## 3. Technology Stack

| Layer | Technologies |
|---|---|
| **Backend Framework** | Java 17, Spring Boot 3.3.4 |
| **Security & Auth** | Spring Security 6 (BCrypt PasswordEncoder, Role-Based Access Control) |
| **Data Persistence** | Spring Data JPA, Hibernate ORM |
| **Database** | MySQL 8.0+ (Production) / H2 In-Memory (Dev & Unit Testing) |
| **Build & Dependencies**| Apache Maven 3.9+ |
| **Frontend** | HTML5, Tailwind CSS, Thymeleaf, JavaScript / React SPA Companion |
| **Testing** | JUnit 5, Mockito, AssertJ, Spring Security Test |

---

## 4. Architectural & Layered Project Structure

```text
OIBSIP/Task5_DigitalLibraryManagementSystem/
├── pom.xml
├── README.md
├── src/
│   ├── main/
│   │   ├── java/com/librosphere/
│   │   │   ├── LibroSphereApplication.java
│   │   │   ├── config/
│   │   │   │   ├── SecurityConfig.java
│   │   │   │   └── DataInitializer.java
│   │   │   ├── controller/
│   │   │   │   ├── AuthController.java
│   │   │   │   ├── AdminController.java
│   │   │   │   ├── BookController.java
│   │   │   │   ├── IssueController.java
│   │   │   │   ├── ReservationController.java
│   │   │   │   ├── FineController.java
│   │   │   │   └── ContactController.java
│   │   │   ├── entity/
│   │   │   │   ├── User.java
│   │   │   │   ├── Book.java
│   │   │   │   ├── BookIssue.java
│   │   │   │   ├── Reservation.java
│   │   │   │   ├── Fine.java
│   │   │   │   └── ContactMessage.java
│   │   │   ├── repository/
│   │   │   │   ├── UserRepository.java
│   │   │   │   ├── BookRepository.java
│   │   │   │   ├── BookIssueRepository.java
│   │   │   │   ├── ReservationRepository.java
│   │   │   │   ├── FineRepository.java
│   │   │   │   └── ContactMessageRepository.java
│   │   │   ├── service/
│   │   │   │   ├── UserService.java
│   │   │   │   ├── BookService.java
│   │   │   │   ├── IssueService.java
│   │   │   │   ├── FineService.java
│   │   │   │   ├── ReservationService.java
│   │   │   │   └── ContactService.java
│   │   │   └── dto/
│   │   │       ├── RegisterDto.java
│   │   │       ├── BookDto.java
│   │   │       └── ContactDto.java
│   │   └── resources/
│   │       ├── application.properties
│   │       ├── schema.sql
│   │       └── data.sql
│   └── test/
│       └── java/com/librosphere/
│           ├── FineCalculationTest.java
│           └── BookIssueServiceTest.java
```

---

## 5. Database Schema & Relational Integrity

### Entities
1. **`users`**:
   `id` (BIGINT PK), `full_name` (VARCHAR), `email` (VARCHAR UNIQUE), `username` (VARCHAR UNIQUE), `password_hash` (VARCHAR), `role` (ENUM: ADMIN, USER), `account_status` (ENUM: ACTIVE, DEACTIVATED), `created_at` (TIMESTAMP).
2. **`books`**:
   `id` (BIGINT PK), `title` (VARCHAR), `author` (VARCHAR), `isbn` (VARCHAR UNIQUE), `category` (VARCHAR), `total_quantity` (INT), `available_quantity` (INT), `description` (TEXT), `shelf_location` (VARCHAR), `created_at` (TIMESTAMP), `updated_at` (TIMESTAMP).
3. **`book_issues`**:
   `id` (BIGINT PK), `user_id` (BIGINT FK), `book_id` (BIGINT FK), `issue_date` (DATE), `due_date` (DATE), `return_date` (DATE NULLABLE), `status` (ENUM: ACTIVE, RETURNED), `fine_amount` (DECIMAL), `created_at` (TIMESTAMP).
4. **`reservations`**:
   `id` (BIGINT PK), `user_id` (BIGINT FK), `book_id` (BIGINT FK), `reservation_date` (TIMESTAMP), `status` (ENUM: PENDING, READY_FOR_PICKUP, FULFILLED, CANCELLED), `queue_position` (INT), `expiry_date` (DATE NULLABLE), `created_at` (TIMESTAMP).
5. **`fines`**:
   `id` (BIGINT PK), `book_issue_id` (BIGINT FK), `user_id` (BIGINT FK), `book_id` (BIGINT FK), `amount` (DECIMAL), `status` (ENUM: UNPAID, PAID), `calculated_timestamp` (TIMESTAMP), `paid_timestamp` (TIMESTAMP NULLABLE).
6. **`contact_messages`**:
   `id` (BIGINT PK), `user_id` (BIGINT FK NULLABLE), `name` (VARCHAR), `email` (VARCHAR), `subject` (VARCHAR), `message` (TEXT), `status` (ENUM: NEW, IN_PROGRESS, RESOLVED), `created_at` (TIMESTAMP).

---

## 6. Business & Domain Rules

- **Loan Window:** Default 14 days from issue timestamp.
- **Maximum Active Loans:** 3 books per member simultaneously.
- **Concurrent Title Rule:** A member cannot borrow two copies of the same book at once.
- **Fine Calculation Policy:**
  - On-time return: $\text{Fine} = ₹0$.
  - Late return: $\text{Overdue Days} = \max(0, \text{Return Date} - \text{Due Date})$.
  - $\text{Fine} = \text{Overdue Days} \times ₹5.00$.
  - Calculated once at return time; stored permanently in `fines` table.
- **Advance Reservation Policy:**
  - Allowed exclusively when `available_quantity == 0`.
  - Duplicate active reservations by the same member for the same book are strictly prevented.
  - When a book is returned, if pending reservations exist, the earliest reservation is set to `READY_FOR_PICKUP` (with a 3-day hold), preventing unreserved checkout.

---

## 7. Environment Variables & First-Run Setup

Set these environment variables before launching:
```bash
export DB_URL="jdbc:mysql://localhost:3306/librosphere_db?useSSL=false&serverTimezone=UTC"
export DB_USERNAME="root"
export DB_PASSWORD="your_secure_password"
export SPRING_PROFILES_ACTIVE="prod"
```

### 🔐 Safe First-Run Admin Credentials
- **Username:** `admin`
- **Password:** `Admin@123` *(Initial setup; administrator should update password upon deployment)*
- **Email:** `admin@librosphere.edu`

### 🧑 Demo Member Credentials
- **User 1 (Developer Account):** `nehaborkar` / `User@123` (Neha Vinod Borkar)
- **User 2:** `rahulsharma` / `User@123` (Rahul Sharma)

---

## 8. Compilation & Execution Instructions

### Build with Maven:
```bash
cd OIBSIP/Task5_DigitalLibraryManagementSystem
mvn clean install
```

### Run the Spring Boot Server:
```bash
mvn spring-boot:run
```
The application will launch on `http://localhost:8080`.

### Run Automated JUnit Test Suite:
```bash
mvn test
```

---

## 9. Security Measures Implemented
1. **BCrypt Password Hashing:** 10 salt rounds applied to all passwords before database storage.
2. **Access Control:** User cannot access `/admin/**` endpoints; unauthorized cross-user return attempts return `403 Forbidden`.
3. **Database Consistency:** JPA `@Transactional` wraps borrow and return flows with row locking to eliminate race conditions on zero stock.
4. **Input Sanitization & Safe Queries:** Parameterized Spring Data queries prevent SQL injection attacks.

---

## 10. Actual Test Execution Results
| Test Case | Scenario | Expected | Result |
|---|---|---|---|
| TC-01 | User registration with matching passwords | Status 201 Created | ✅ PASS |
| TC-02 | Duplicate email registration | Status 409 Conflict | ✅ PASS |
| TC-03 | Issue book when available copy > 0 | Stock -1, Due Date +14 days | ✅ PASS |
| TC-04 | Issue book when stock = 0 | Blocked, prompt for reservation | ✅ PASS |
| TC-05 | Return book 3 days overdue | Status RETURNED, Fine ₹15 generated | ✅ PASS |
| TC-06 | Return book on time | Status RETURNED, Fine ₹0 | ✅ PASS |
| TC-07 | Non-owner return attempt | 403 Forbidden | ✅ PASS |
| TC-08 | Admin marks fine as paid | Status updated to PAID, timestamp saved | ✅ PASS |
| TC-09 | Advance reserve out-of-stock book | Queue position #1 assigned | ✅ PASS |
| TC-10 | Admin deletes book with active loan | Deletion rejected with reason | ✅ PASS |

---

## 11. Known Limitations
- Fine clearance is managed administratively in-person or via bank receipt verification rather than automated payment gateways (e.g. Razorpay/Stripe).
- Physical barcode scanner integration is simulated via ISBN text input.
