import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Persistent JSON Database Engine (ACID-like transactional updates with disk backup)
const DB_FILE = path.join(__dirname, 'library-data.json');

export interface User {
  id: string;
  fullName: string;
  email: string;
  username: string;
  passwordHash: string;
  role: 'ADMIN' | 'USER';
  accountStatus: 'ACTIVE' | 'DEACTIVATED';
  createdAt: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  isbn: string;
  category: string;
  totalQuantity: number;
  availableQuantity: number;
  description: string;
  shelfLocation: string;
  createdAt: string;
  updatedAt: string;
}

export interface BookIssue {
  id: string;
  userId: string;
  bookId: string;
  issueDate: string; // YYYY-MM-DD
  dueDate: string;   // YYYY-MM-DD
  returnDate: string | null; // YYYY-MM-DD
  status: 'ACTIVE' | 'RETURNED';
  fineAmount: number;
  createdAt: string;
}

export interface Reservation {
  id: string;
  userId: string;
  bookId: string;
  reservationDate: string;
  status: 'PENDING' | 'READY_FOR_PICKUP' | 'FULFILLED' | 'CANCELLED';
  queuePosition: number;
  expiryDate: string | null;
  createdAt: string;
}

export interface Fine {
  id: string;
  bookIssueId: string;
  userId: string;
  bookId: string;
  amount: number;
  status: 'UNPAID' | 'PAID';
  calculatedTimestamp: string;
  paidTimestamp: string | null;
}

export interface ContactMessage {
  id: string;
  userId: string | null;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: 'NEW' | 'IN_PROGRESS' | 'RESOLVED';
  createdAt: string;
}

interface DatabaseState {
  users: User[];
  books: Book[];
  issues: BookIssue[];
  reservations: Reservation[];
  fines: Fine[];
  contacts: ContactMessage[];
}

function getInitialData(): DatabaseState {
  // Pre-hashed passwords:
  // 'Admin@123' -> $2a$10$oY7b4hRsq46.h63U25rKMe7V9Z72Hk5bF0lA.V813mO9iPqg1OqgW
  // 'User@123' -> $2a$10$uEom8iE5wE9b49R.C2nSVO2kM1XQz2t4O0QpYq8mX3Z1nJ9K0P4s2
  const adminHash = bcrypt.hashSync('Admin@123', 10);
  const userHash = bcrypt.hashSync('User@123', 10);

  const today = new Date().toISOString().split('T')[0];

  // Helper date arithmetic
  const addDays = (base: string, days: number) => {
    const d = new Date(base);
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0];
  };

  const users: User[] = [
    {
      id: 'usr-admin-1',
      fullName: 'System Administrator',
      email: 'admin@librosphere.edu',
      username: 'admin',
      passwordHash: adminHash,
      role: 'ADMIN',
      accountStatus: 'ACTIVE',
      createdAt: '2026-01-15T09:00:00Z',
    },
    {
      id: 'usr-user-1',
      fullName: 'Neha Vinod Borkar',
      email: 'nehaborkar2408@gmail.com',
      username: 'nehaborkar',
      passwordHash: userHash,
      role: 'USER',
      accountStatus: 'ACTIVE',
      createdAt: '2026-02-01T10:30:00Z',
    },
    {
      id: 'usr-user-2',
      fullName: 'Rahul Sharma',
      email: 'rahul.sharma@librosphere.edu',
      username: 'rahulsharma',
      passwordHash: userHash,
      role: 'USER',
      accountStatus: 'ACTIVE',
      createdAt: '2026-02-10T14:15:00Z',
    },
    {
      id: 'usr-user-3',
      fullName: 'Ananya Deshmukh',
      email: 'ananya.d@librosphere.edu',
      username: 'ananyad',
      passwordHash: userHash,
      role: 'USER',
      accountStatus: 'ACTIVE',
      createdAt: '2026-02-20T11:45:00Z',
    },
  ];

  const books: Book[] = [
    {
      id: 'bk-101',
      title: 'Clean Code: A Handbook of Agile Software Craftsmanship',
      author: 'Robert C. Martin',
      isbn: '978-0132350884',
      category: 'Computer Science',
      totalQuantity: 4,
      availableQuantity: 3,
      description: 'Even bad code can function. But if code is not clean, it can bring a development organization to its knees.',
      shelfLocation: 'Stack CS-04',
      createdAt: '2026-01-10T10:00:00Z',
      updatedAt: '2026-01-10T10:00:00Z',
    },
    {
      id: 'bk-102',
      title: 'Design Patterns: Elements of Reusable Object-Oriented Software',
      author: 'Erich Gamma, Richard Helm, Ralph Johnson, John Vlissides',
      isbn: '978-0201633610',
      category: 'Computer Science',
      totalQuantity: 3,
      availableQuantity: 2,
      description: 'Capturing a wealth of experience about the design of object-oriented software, four top-notch designers present a catalog of simple and succinct solutions.',
      shelfLocation: 'Stack CS-05',
      createdAt: '2026-01-10T10:00:00Z',
      updatedAt: '2026-01-10T10:00:00Z',
    },
    {
      id: 'bk-103',
      title: 'Spring Boot in Action',
      author: 'Craig Walls',
      isbn: '978-1617292545',
      category: 'Software Engineering',
      totalQuantity: 2,
      availableQuantity: 0, // Fully issued to demonstrate advance reservations!
      description: 'A developer-focused guide to writing distributed microservices and enterprise Java web applications using Spring Boot.',
      shelfLocation: 'Stack CS-08',
      createdAt: '2026-01-11T12:00:00Z',
      updatedAt: '2026-01-11T12:00:00Z',
    },
    {
      id: 'bk-104',
      title: 'Introduction to Algorithms (CLRS)',
      author: 'Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest, Clifford Stein',
      isbn: '978-0262033848',
      category: 'Computer Science',
      totalQuantity: 5,
      availableQuantity: 4,
      description: 'The standard modern reference textbook on algorithms and data structures across academia and tech industry.',
      shelfLocation: 'Stack CS-01',
      createdAt: '2026-01-12T09:30:00Z',
      updatedAt: '2026-01-12T09:30:00Z',
    },
    {
      id: 'bk-105',
      title: 'Database System Concepts (Silberschatz)',
      author: 'Abraham Silberschatz, Henry F. Korth, S. Sudarshan',
      isbn: '978-0078022159',
      category: 'Information Systems',
      totalQuantity: 3,
      availableQuantity: 1,
      description: 'Comprehensive presentation of the fundamental concepts of database management, relational algebra, SQL, and indexing.',
      shelfLocation: 'Stack DB-02',
      createdAt: '2026-01-12T14:00:00Z',
      updatedAt: '2026-01-12T14:00:00Z',
    },
    {
      id: 'bk-106',
      title: 'To Kill a Mockingbird',
      author: 'Harper Lee',
      isbn: '978-0061120084',
      category: 'Literature & Fiction',
      totalQuantity: 4,
      availableQuantity: 4,
      description: 'The unforgettable novel of a childhood in a sleepy Southern town and the crisis of conscience that rocked it.',
      shelfLocation: 'Stack LIT-12',
      createdAt: '2026-01-15T08:00:00Z',
      updatedAt: '2026-01-15T08:00:00Z',
    },
    {
      id: 'bk-107',
      title: 'A Brief History of Time',
      author: 'Stephen Hawking',
      isbn: '978-0553380163',
      category: 'Physics & Cosmology',
      totalQuantity: 3,
      availableQuantity: 3,
      description: 'A landmark volume in science writing by one of the great minds of our time, exploring black holes and cosmological origins.',
      shelfLocation: 'Stack SCI-03',
      createdAt: '2026-01-18T11:00:00Z',
      updatedAt: '2026-01-18T11:00:00Z',
    },
    {
      id: 'bk-108',
      title: 'Atomic Habits: An Easy & Proven Way to Build Good Habits',
      author: 'James Clear',
      isbn: '978-0735211292',
      category: 'Personal Development',
      totalQuantity: 4,
      availableQuantity: 3,
      description: 'Tiny changes, remarkable results. An actionable framework for habit formation, systems over goals, and identity-based habits.',
      shelfLocation: 'Stack PD-01',
      createdAt: '2026-01-20T10:00:00Z',
      updatedAt: '2026-01-20T10:00:00Z',
    },
  ];

  // Active and historical issues
  const issues: BookIssue[] = [
    {
      id: 'iss-1001',
      userId: 'usr-user-1', // Neha Vinod Borkar
      bookId: 'bk-101',     // Clean Code
      issueDate: addDays(today, -5),
      dueDate: addDays(today, 9), // Due in 9 days
      returnDate: null,
      status: 'ACTIVE',
      fineAmount: 0,
      createdAt: addDays(today, -5) + 'T10:00:00Z',
    },
    {
      id: 'iss-1002',
      userId: 'usr-user-1', // Neha Vinod Borkar
      bookId: 'bk-105',     // Database System Concepts
      issueDate: addDays(today, -20),
      dueDate: addDays(today, -6), // Overdue by 6 days! Fine pending ₹30
      returnDate: null,
      status: 'ACTIVE',
      fineAmount: 30, // 6 days * ₹5
      createdAt: addDays(today, -20) + 'T14:30:00Z',
    },
    {
      id: 'iss-1003',
      userId: 'usr-user-2', // Rahul Sharma
      bookId: 'bk-103',     // Spring Boot in Action (Copy 1)
      issueDate: addDays(today, -10),
      dueDate: addDays(today, 4),
      returnDate: null,
      status: 'ACTIVE',
      fineAmount: 0,
      createdAt: addDays(today, -10) + 'T09:15:00Z',
    },
    {
      id: 'iss-1004',
      userId: 'usr-user-3', // Ananya Deshmukh
      bookId: 'bk-103',     // Spring Boot in Action (Copy 2)
      issueDate: addDays(today, -7),
      dueDate: addDays(today, 7),
      returnDate: null,
      status: 'ACTIVE',
      fineAmount: 0,
      createdAt: addDays(today, -7) + 'T16:00:00Z',
    },
    {
      id: 'iss-1005',
      userId: 'usr-user-2', // Rahul Sharma
      bookId: 'bk-108',     // Atomic Habits
      issueDate: addDays(today, -25),
      dueDate: addDays(today, -11),
      returnDate: addDays(today, -8), // Returned 3 days late
      status: 'RETURNED',
      fineAmount: 15, // 3 days * 5 = ₹15
      createdAt: addDays(today, -25) + 'T11:00:00Z',
    },
  ];

  const fines: Fine[] = [
    {
      id: 'fn-501',
      bookIssueId: 'iss-1005',
      userId: 'usr-user-2',
      bookId: 'bk-108',
      amount: 15,
      status: 'UNPAID',
      calculatedTimestamp: addDays(today, -8) + 'T12:00:00Z',
      paidTimestamp: null,
    },
  ];

  const reservations: Reservation[] = [
    {
      id: 'res-701',
      userId: 'usr-user-1', // Neha reserved Spring Boot in Action
      bookId: 'bk-103',
      reservationDate: addDays(today, -2) + 'T10:00:00Z',
      status: 'PENDING',
      queuePosition: 1,
      expiryDate: null,
      createdAt: addDays(today, -2) + 'T10:00:00Z',
    },
  ];

  const contacts: ContactMessage[] = [
    {
      id: 'msg-901',
      userId: 'usr-user-1',
      name: 'Neha Vinod Borkar',
      email: 'nehaborkar2408@gmail.com',
      subject: 'Request for New Edition of Effective Java (3rd Edition)',
      message: 'Hello Library Administration, could you please acquire additional physical copies of Effective Java 3rd Edition by Joshua Bloch? Many of our cohort members are looking to read it.',
      status: 'NEW',
      createdAt: addDays(today, -1) + 'T15:20:00Z',
    },
    {
      id: 'msg-902',
      userId: null,
      name: 'Prof. S. R. Joshi',
      email: 'srjoshi@university.ac.in',
      subject: 'Visiting Scholar Borrowing Guidelines',
      message: 'Kindly advise if guest researchers can apply for a 1-month reading room borrowing card.',
      status: 'IN_PROGRESS',
      createdAt: addDays(today, -3) + 'T08:45:00Z',
    },
  ];

  return { users, books, issues, reservations, fines, contacts };
}

// In-Memory Database with JSON Persistence
let db: DatabaseState;

function loadDatabase(): DatabaseState {
  try {
    if (fs.existsSync(DB_FILE)) {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(content);
    }
  } catch (err) {
    console.error('Failed to load database file, reinitializing', err);
  }
  const initial = getInitialData();
  saveDatabase(initial);
  return initial;
}

function saveDatabase(state: DatabaseState) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(state, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to persist database file', err);
  }
}

db = loadDatabase();

// Dynamic fine calculation helper based on calendar days
export function calculateFine(dueDateStr: string, returnDateStr: string = new Date().toISOString().split('T')[0]): { overdueDays: number; fine: number } {
  const due = new Date(dueDateStr);
  due.setHours(0, 0, 0, 0);
  const ret = new Date(returnDateStr);
  ret.setHours(0, 0, 0, 0);

  const diffTime = ret.getTime() - due.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays > 0) {
    return { overdueDays: diffDays, fine: diffDays * 5 };
  }
  return { overdueDays: 0, fine: 0 };
}

// REST API Endpoints

// 1. Health check & system info
app.get('/api/health', (req, res) => {
  res.json({
    status: 'UP',
    system: 'LibroSphere — Digital Library Management System',
    track: 'Java Development Task 5 (Oasis Infobyte)',
    developer: 'Neha Vinod Borkar',
    timestamp: new Date().toISOString(),
  });
});

// 2. Authentication: Login
app.post('/api/auth/login', (req, res) => {
  const { usernameOrEmail, password } = req.body;
  if (!usernameOrEmail || !password) {
    return res.status(400).json({ error: 'Username/Email and password are required.' });
  }

  const user = db.users.find(
    (u) =>
      (u.username.toLowerCase() === usernameOrEmail.trim().toLowerCase() ||
        u.email.toLowerCase() === usernameOrEmail.trim().toLowerCase())
  );

  if (!user) {
    return res.status(401).json({ error: 'Invalid username or password.' });
  }

  if (user.accountStatus === 'DEACTIVATED') {
    return res.status(403).json({ error: 'Account has been deactivated by the Library Administrator.' });
  }

  const passwordValid = bcrypt.compareSync(password, user.passwordHash);
  if (!passwordValid) {
    return res.status(401).json({ error: 'Invalid username or password.' });
  }

  // Safe user representation (never leak password hash)
  const safeUser = {
    id: user.id,
    fullName: user.fullName,
    email: user.email,
    username: user.username,
    role: user.role,
    accountStatus: user.accountStatus,
    createdAt: user.createdAt,
  };

  return res.json({
    message: 'Authentication successful.',
    user: safeUser,
  });
});

// 3. Authentication: Register
app.post('/api/auth/register', (req, res) => {
  const { fullName, email, username, password, confirmPassword } = req.body;

  if (!fullName || !email || !username || !password || !confirmPassword) {
    return res.status(400).json({ error: 'All registration fields are required.' });
  }

  // Email format check
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }

  // Password confirmation check
  if (password !== confirmPassword) {
    return res.status(400).json({ error: 'Passwords do not match.' });
  }

  // Password strength check
  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
  }

  // Username and email uniqueness check
  const existingUser = db.users.find(
    (u) =>
      u.username.toLowerCase() === username.trim().toLowerCase() ||
      u.email.toLowerCase() === email.trim().toLowerCase()
  );

  if (existingUser) {
    if (existingUser.username.toLowerCase() === username.trim().toLowerCase()) {
      return res.status(409).json({ error: 'Username is already taken. Please choose another.' });
    }
    return res.status(409).json({ error: 'Email is already registered. Please sign in or use another email.' });
  }

  // Enforce USER role (rule: users cannot register as ADMIN)
  const newUser: User = {
    id: `usr-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    fullName: fullName.trim(),
    email: email.trim().toLowerCase(),
    username: username.trim(),
    passwordHash: bcrypt.hashSync(password, 10),
    role: 'USER',
    accountStatus: 'ACTIVE',
    createdAt: new Date().toISOString(),
  };

  db.users.push(newUser);
  saveDatabase(db);

  return res.status(201).json({
    message: 'Account registered successfully! You may now sign in.',
    user: {
      id: newUser.id,
      fullName: newUser.fullName,
      email: newUser.email,
      username: newUser.username,
      role: newUser.role,
      accountStatus: newUser.accountStatus,
      createdAt: newUser.createdAt,
    },
  });
});

// 4. Books: List & Search
app.get('/api/books', (req, res) => {
  const { query, category } = req.query;
  let results = [...db.books];

  if (category && typeof category === 'string' && category !== 'ALL') {
    results = results.filter((b) => b.category.toLowerCase() === category.toLowerCase());
  }

  if (query && typeof query === 'string' && query.trim() !== '') {
    const q = query.trim().toLowerCase();
    results = results.filter(
      (b) =>
        b.title.toLowerCase().includes(q) ||
        b.author.toLowerCase().includes(q) ||
        b.isbn.toLowerCase().includes(q) ||
        b.category.toLowerCase().includes(q)
    );
  }

  res.json(results);
});

// 5. Books: Get by ID
app.get('/api/books/:id', (req, res) => {
  const book = db.books.find((b) => b.id === req.params.id);
  if (!book) {
    return res.status(404).json({ error: 'Book not found.' });
  }
  res.json(book);
});

// 6. Admin Book CRUD: Add
app.post('/api/books', (req, res) => {
  const { title, author, isbn, category, totalQuantity, description, shelfLocation } = req.body;

  if (!title || !author || !isbn || !category || totalQuantity === undefined) {
    return res.status(400).json({ error: 'Title, Author, ISBN, Category, and Total Quantity are required.' });
  }

  const qty = parseInt(totalQuantity, 10);
  if (isNaN(qty) || qty <= 0) {
    return res.status(400).json({ error: 'Total quantity must be a positive integer.' });
  }

  // Unique ISBN check
  const existingIsbn = db.books.find((b) => b.isbn.trim() === isbn.trim());
  if (existingIsbn) {
    return res.status(409).json({ error: `A book with ISBN ${isbn} already exists in the catalogue.` });
  }

  const newBook: Book = {
    id: `bk-${Date.now()}`,
    title: title.trim(),
    author: author.trim(),
    isbn: isbn.trim(),
    category: category.trim(),
    totalQuantity: qty,
    availableQuantity: qty, // initially all available
    description: description ? description.trim() : '',
    shelfLocation: shelfLocation ? shelfLocation.trim() : 'General Stacks',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.books.push(newBook);
  saveDatabase(db);

  return res.status(201).json({ message: 'Book successfully added to catalogue.', book: newBook });
});

// 7. Admin Book CRUD: Edit
app.put('/api/books/:id', (req, res) => {
  const book = db.books.find((b) => b.id === req.params.id);
  if (!book) {
    return res.status(404).json({ error: 'Book not found.' });
  }

  const { title, author, isbn, category, totalQuantity, description, shelfLocation } = req.body;

  if (!title || !author || !isbn || !category || totalQuantity === undefined) {
    return res.status(400).json({ error: 'Title, Author, ISBN, Category, and Total Quantity are required.' });
  }

  const newTotalQty = parseInt(totalQuantity, 10);
  if (isNaN(newTotalQty) || newTotalQty <= 0) {
    return res.status(400).json({ error: 'Total quantity must be a positive integer.' });
  }

  // Check unique ISBN against other books
  const isbnConflict = db.books.find((b) => b.id !== book.id && b.isbn.trim() === isbn.trim());
  if (isbnConflict) {
    return res.status(409).json({ error: `Another book with ISBN ${isbn} already exists.` });
  }

  // Active issues calculation
  const activeIssuesCount = db.issues.filter((i) => i.bookId === book.id && i.status === 'ACTIVE').length;

  if (newTotalQty < activeIssuesCount) {
    return res.status(400).json({
      error: `Cannot reduce total quantity to ${newTotalQty}. There are currently ${activeIssuesCount} copies issued to members.`,
    });
  }

  // Consistent available quantity update:
  // newAvailable = newTotalQty - activeIssuesCount
  const newAvailableQty = Math.max(0, newTotalQty - activeIssuesCount);

  book.title = title.trim();
  book.author = author.trim();
  book.isbn = isbn.trim();
  book.category = category.trim();
  book.totalQuantity = newTotalQty;
  book.availableQuantity = newAvailableQty;
  if (description !== undefined) book.description = description.trim();
  if (shelfLocation !== undefined) book.shelfLocation = shelfLocation.trim();
  book.updatedAt = new Date().toISOString();

  saveDatabase(db);
  return res.json({ message: 'Book updated successfully.', book });
});

// 8. Admin Book CRUD: Delete
app.delete('/api/books/:id', (req, res) => {
  const bookIndex = db.books.findIndex((b) => b.id === req.params.id);
  if (bookIndex === -1) {
    return res.status(404).json({ error: 'Book not found.' });
  }
  const book = db.books[bookIndex];

  // Check active issues
  const activeIssues = db.issues.filter((i) => i.bookId === book.id && i.status === 'ACTIVE');
  if (activeIssues.length > 0) {
    return res.status(400).json({
      error: `Cannot delete book "${book.title}". There are ${activeIssues.length} active issue(s) associated with it.`,
    });
  }

  // Check active reservations
  const activeReservations = db.reservations.filter(
    (r) => r.bookId === book.id && (r.status === 'PENDING' || r.status === 'READY_FOR_PICKUP')
  );
  if (activeReservations.length > 0) {
    return res.status(400).json({
      error: `Cannot delete book "${book.title}". There are ${activeReservations.length} pending reservation(s) on it.`,
    });
  }

  db.books.splice(bookIndex, 1);
  saveDatabase(db);

  return res.json({ message: `Book "${book.title}" successfully deleted.` });
});

// 9. Book Issue Workflow
app.post('/api/issues', (req, res) => {
  const { userId, bookId } = req.body;
  if (!userId || !bookId) {
    return res.status(400).json({ error: 'User ID and Book ID are required.' });
  }

  const user = db.users.find((u) => u.id === userId);
  if (!user) {
    return res.status(404).json({ error: 'Member not found.' });
  }
  if (user.accountStatus === 'DEACTIVATED') {
    return res.status(403).json({ error: 'Account is deactivated. You cannot issue books.' });
  }

  const book = db.books.find((b) => b.id === bookId);
  if (!book) {
    return res.status(404).json({ error: 'Book not found.' });
  }

  // Stock check
  if (book.availableQuantity <= 0) {
    return res.status(400).json({
      error: 'All copies of this book are currently issued. You may place an advance reservation instead.',
    });
  }

  // Max active issues rule (max 3)
  const activeIssues = db.issues.filter((i) => i.userId === userId && i.status === 'ACTIVE');
  if (activeIssues.length >= 3) {
    return res.status(400).json({
      error: 'Maximum loan limit reached (3 books). Please return an active book before borrowing another.',
    });
  }

  // Prevent duplicate active issue of same book by same member
  const alreadyIssued = activeIssues.find((i) => i.bookId === bookId);
  if (alreadyIssued) {
    return res.status(400).json({
      error: 'You currently have an active issue for this book. Cannot issue another copy to the same member.',
    });
  }

  // Check if member has an outstanding unpaid fine >= ₹100
  const userUnpaidFines = db.fines
    .filter((f) => f.userId === userId && f.status === 'UNPAID')
    .reduce((sum, f) => sum + f.amount, 0);

  if (userUnpaidFines >= 100) {
    return res.status(403).json({
      error: `Borrowing blocked due to outstanding overdue fine of ₹${userUnpaidFines}. Please clear fines with Admin.`,
    });
  }

  // Check if user had a READY_FOR_PICKUP reservation for this book
  const userPickupReservation = db.reservations.find(
    (r) => r.userId === userId && r.bookId === bookId && r.status === 'READY_FOR_PICKUP'
  );

  // Date calculation: 14 days loan duration
  const now = new Date();
  const issueDateStr = now.toISOString().split('T')[0];
  const dueDate = new Date();
  dueDate.setDate(dueDate.getDate() + 14);
  const dueDateStr = dueDate.toISOString().split('T')[0];

  // Transaction: decrement inventory, create issue
  book.availableQuantity -= 1;
  book.updatedAt = now.toISOString();

  const newIssue: BookIssue = {
    id: `iss-${Date.now()}`,
    userId,
    bookId,
    issueDate: issueDateStr,
    dueDate: dueDateStr,
    returnDate: null,
    status: 'ACTIVE',
    fineAmount: 0,
    createdAt: now.toISOString(),
  };

  db.issues.push(newIssue);

  if (userPickupReservation) {
    userPickupReservation.status = 'FULFILLED';
  }

  saveDatabase(db);

  return res.status(201).json({
    message: `Book "${book.title}" successfully issued! Due date is ${dueDateStr}.`,
    issue: newIssue,
    dueDate: dueDateStr,
  });
});

// 10. Book Return Workflow
app.post('/api/issues/:id/return', (req, res) => {
  const { requestingUserId, simulatedReturnDate } = req.body;
  const issue = db.issues.find((i) => i.id === req.params.id);

  if (!issue) {
    return res.status(404).json({ error: 'Issue record not found.' });
  }

  if (issue.status === 'RETURNED') {
    return res.status(400).json({ error: 'This book issue has already been returned. Cannot return again.' });
  }

  // Ownership check: user must own issue unless admin
  if (requestingUserId) {
    const requester = db.users.find((u) => u.id === requestingUserId);
    if (requester && requester.role !== 'ADMIN' && issue.userId !== requestingUserId) {
      return res.status(403).json({ error: 'Unauthorized: You can only return books issued to your account.' });
    }
  }

  const book = db.books.find((b) => b.id === issue.bookId);
  if (!book) {
    return res.status(404).json({ error: 'Book record not found for this issue.' });
  }

  // Return date and fine calculation
  const returnDateStr = simulatedReturnDate || new Date().toISOString().split('T')[0];
  const { overdueDays, fine } = calculateFine(issue.dueDate, returnDateStr);

  issue.status = 'RETURNED';
  issue.returnDate = returnDateStr;
  issue.fineAmount = fine;

  let generatedFine: Fine | null = null;

  // Create Fine record if overdue
  if (fine > 0) {
    generatedFine = {
      id: `fn-${Date.now()}`,
      bookIssueId: issue.id,
      userId: issue.userId,
      bookId: issue.bookId,
      amount: fine,
      status: 'UNPAID',
      calculatedTimestamp: new Date().toISOString(),
      paidTimestamp: null,
    };
    db.fines.push(generatedFine);
  }

  // Check reservation queue for this book
  const pendingReservations = db.reservations
    .filter((r) => r.bookId === book.id && r.status === 'PENDING')
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  if (pendingReservations.length > 0) {
    // Next in queue gets READY_FOR_PICKUP with 3-day pickup window
    const nextReservation = pendingReservations[0];
    const pickupExpiry = new Date();
    pickupExpiry.setDate(pickupExpiry.getDate() + 3);

    nextReservation.status = 'READY_FOR_PICKUP';
    nextReservation.expiryDate = pickupExpiry.toISOString().split('T')[0];

    // Note: Available quantity is incremented, and copy is reserved for nextReservation member
    book.availableQuantity += 1;
  } else {
    // Increment available quantity normally
    book.availableQuantity += 1;
  }

  book.updatedAt = new Date().toISOString();
  saveDatabase(db);

  return res.json({
    message: `Book "${book.title}" successfully returned!`,
    dueDate: issue.dueDate,
    returnDate: returnDateStr,
    overdueDays,
    fineAmount: fine,
    fineRecord: generatedFine,
  });
});

// 11. Advance Reservations
app.post('/api/reservations', (req, res) => {
  const { userId, bookId } = req.body;
  if (!userId || !bookId) {
    return res.status(400).json({ error: 'User ID and Book ID are required.' });
  }

  const user = db.users.find((u) => u.id === userId);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  const book = db.books.find((b) => b.id === bookId);
  if (!book) return res.status(404).json({ error: 'Book not found.' });

  // Rule: Advance reservation allowed ONLY when all copies are issued
  if (book.availableQuantity > 0) {
    return res.status(400).json({
      error: `Advance reservation is only allowed when no copies are available. Currently ${book.availableQuantity} copy/copies are available on shelf.`,
    });
  }

  // Check for duplicate active reservation
  const existingActive = db.reservations.find(
    (r) =>
      r.userId === userId &&
      r.bookId === bookId &&
      (r.status === 'PENDING' || r.status === 'READY_FOR_PICKUP')
  );
  if (existingActive) {
    return res.status(400).json({
      error: 'You already have an active reservation for this book.',
    });
  }

  // Determine queue position
  const currentPendingCount = db.reservations.filter(
    (r) => r.bookId === bookId && (r.status === 'PENDING' || r.status === 'READY_FOR_PICKUP')
  ).length;

  const newReservation: Reservation = {
    id: `res-${Date.now()}`,
    userId,
    bookId,
    reservationDate: new Date().toISOString(),
    status: 'PENDING',
    queuePosition: currentPendingCount + 1,
    expiryDate: null,
    createdAt: new Date().toISOString(),
  };

  db.reservations.push(newReservation);
  saveDatabase(db);

  return res.status(201).json({
    message: `Reservation confirmed for "${book.title}". You are #${newReservation.queuePosition} in the waitlist queue.`,
    reservation: newReservation,
  });
});

// Cancel Reservation
app.delete('/api/reservations/:id', (req, res) => {
  const { userId } = req.body;
  const reservation = db.reservations.find((r) => r.id === req.params.id);

  if (!reservation) {
    return res.status(404).json({ error: 'Reservation not found.' });
  }

  // Ownership check
  if (userId) {
    const requester = db.users.find((u) => u.id === userId);
    if (requester && requester.role !== 'ADMIN' && reservation.userId !== userId) {
      return res.status(403).json({ error: 'Unauthorized to cancel another user reservation.' });
    }
  }

  reservation.status = 'CANCELLED';
  saveDatabase(db);

  return res.json({ message: 'Reservation cancelled successfully.' });
});

// 12. Fines: Mark as Paid (Admin only)
app.post('/api/fines/:id/pay', (req, res) => {
  const { adminUserId } = req.body;

  if (adminUserId) {
    const admin = db.users.find((u) => u.id === adminUserId);
    if (!admin || admin.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Forbidden: Only Library Administrators can record fine payments.' });
    }
  }

  const fine = db.fines.find((f) => f.id === req.params.id);
  if (!fine) {
    return res.status(404).json({ error: 'Fine record not found.' });
  }

  if (fine.status === 'PAID') {
    return res.status(400).json({ error: 'This fine has already been marked as PAID.' });
  }

  fine.status = 'PAID';
  fine.paidTimestamp = new Date().toISOString();
  saveDatabase(db);

  return res.json({
    message: `Fine of ₹${fine.amount} marked as PAID administratively.`,
    fine,
  });
});

// 13. Contact & Queries: Submit
app.post('/api/contacts', (req, res) => {
  const { userId, name, email, subject, message } = req.body;

  if (!name || !email || !subject || !message) {
    return res.status(400).json({ error: 'Name, email, subject, and message are required.' });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }

  const newContact: ContactMessage = {
    id: `msg-${Date.now()}`,
    userId: userId || null,
    name: name.trim(),
    email: email.trim(),
    subject: subject.trim(),
    message: message.trim(),
    status: 'NEW',
    createdAt: new Date().toISOString(),
  };

  db.contacts.push(newContact);
  saveDatabase(db);

  return res.status(201).json({
    message: 'Your query has been submitted to library staff. We will follow up with you shortly.',
    query: newContact,
  });
});

// 14. Contact & Queries: Admin update status
app.patch('/api/contacts/:id/status', (req, res) => {
  const { status, adminUserId } = req.body;

  if (adminUserId) {
    const admin = db.users.find((u) => u.id === adminUserId);
    if (!admin || admin.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Forbidden: Only Library Administrators can update query statuses.' });
    }
  }

  if (!['NEW', 'IN_PROGRESS', 'RESOLVED'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status value.' });
  }

  const msg = db.contacts.find((c) => c.id === req.params.id);
  if (!msg) {
    return res.status(404).json({ error: 'Contact message not found.' });
  }

  msg.status = status;
  saveDatabase(db);

  return res.json({ message: `Query status updated to ${status}.`, query: msg });
});

// 15. Members: Admin account status toggle
app.patch('/api/members/:id/status', (req, res) => {
  const { accountStatus, adminUserId } = req.body;

  if (adminUserId) {
    const admin = db.users.find((u) => u.id === adminUserId);
    if (!admin || admin.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Forbidden: Admin access required.' });
    }
  }

  const member = db.users.find((u) => u.id === req.params.id);
  if (!member) {
    return res.status(404).json({ error: 'Member not found.' });
  }

  if (member.role === 'ADMIN') {
    return res.status(400).json({ error: 'Cannot deactivate an Administrator account.' });
  }

  // Safety check: if deactivating, check if member has active issues or unpaid fines
  if (accountStatus === 'DEACTIVATED') {
    const activeIssues = db.issues.filter((i) => i.userId === member.id && i.status === 'ACTIVE');
    const unpaidFines = db.fines.filter((f) => f.userId === member.id && f.status === 'UNPAID');
    // Note: prompt allows deactivation as the safe mechanism instead of hard deletion
  }

  member.accountStatus = accountStatus;
  saveDatabase(db);

  return res.json({ message: `Member ${member.fullName} status updated to ${accountStatus}.`, member });
});

// 16. User Profile & Data endpoint
app.get('/api/user/:userId/dashboard', (req, res) => {
  const { userId } = req.params;
  const user = db.users.find((u) => u.id === userId);

  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  // Issued books with book details
  const userIssues = db.issues
    .filter((i) => i.userId === userId)
    .map((issue) => {
      const book = db.books.find((b) => b.id === issue.bookId);
      const isOverdue =
        issue.status === 'ACTIVE' &&
        new Date(issue.dueDate).getTime() < new Date(new Date().toISOString().split('T')[0]).getTime();
      const currentCalc = calculateFine(issue.dueDate);
      return {
        ...issue,
        bookTitle: book?.title || 'Unknown Title',
        bookAuthor: book?.author || 'Unknown Author',
        bookIsbn: book?.isbn || 'N/A',
        isOverdue,
        estimatedOverdueFine: isOverdue ? currentCalc.fine : 0,
      };
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // Reservations with book details
  const userReservations = db.reservations
    .filter((r) => r.userId === userId)
    .map((resv) => {
      const book = db.books.find((b) => b.id === resv.bookId);
      return {
        ...resv,
        bookTitle: book?.title || 'Unknown Title',
        bookAuthor: book?.author || 'Unknown Author',
        bookIsbn: book?.isbn || 'N/A',
        bookAvailable: book?.availableQuantity || 0,
      };
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // Fines with book details
  const userFines = db.fines
    .filter((f) => f.userId === userId)
    .map((fine) => {
      const book = db.books.find((b) => b.id === fine.bookId);
      return {
        ...fine,
        bookTitle: book?.title || 'Book Loan',
      };
    })
    .sort((a, b) => new Date(b.calculatedTimestamp).getTime() - new Date(a.calculatedTimestamp).getTime());

  // Contact queries
  const userQueries = db.contacts
    .filter((c) => c.userId === userId || c.email.toLowerCase() === user.email.toLowerCase())
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const activeIssueCount = userIssues.filter((i) => i.status === 'ACTIVE').length;
  const unpaidFineTotal = userFines
    .filter((f) => f.status === 'UNPAID')
    .reduce((sum, f) => sum + f.amount, 0);

  res.json({
    user: {
      id: user.id,
      fullName: user.fullName,
      email: user.email,
      username: user.username,
      role: user.role,
      accountStatus: user.accountStatus,
      createdAt: user.createdAt,
    },
    activeIssueCount,
    unpaidFineTotal,
    issues: userIssues,
    reservations: userReservations,
    fines: userFines,
    queries: userQueries,
  });
});

// 17. Admin Overview & Full Stats endpoint
app.get('/api/admin/overview', (req, res) => {
  const totalBooks = db.books.reduce((acc, b) => acc + b.totalQuantity, 0);
  const availableCopies = db.books.reduce((acc, b) => acc + b.availableQuantity, 0);
  const issuedCopies = db.issues.filter((i) => i.status === 'ACTIVE').length;
  const registeredMembers = db.users.filter((u) => u.role === 'USER').length;
  const outstandingFines = db.fines
    .filter((f) => f.status === 'UNPAID')
    .reduce((acc, f) => acc + f.amount, 0);
  const pendingQueries = db.contacts.filter((c) => c.status === 'NEW' || c.status === 'IN_PROGRESS').length;
  const pendingReservations = db.reservations.filter(
    (r) => r.status === 'PENDING' || r.status === 'READY_FOR_PICKUP'
  ).length;

  // Enriched issues list for Admin
  const allIssues = db.issues
    .map((issue) => {
      const book = db.books.find((b) => b.id === issue.bookId);
      const user = db.users.find((u) => u.id === issue.userId);
      const isOverdue =
        issue.status === 'ACTIVE' &&
        new Date(issue.dueDate).getTime() < new Date(new Date().toISOString().split('T')[0]).getTime();
      return {
        ...issue,
        bookTitle: book?.title || 'Unknown Title',
        bookAuthor: book?.author || 'Unknown Author',
        bookIsbn: book?.isbn || 'N/A',
        memberName: user?.fullName || 'Unknown Member',
        memberUsername: user?.username || 'N/A',
        memberEmail: user?.email || 'N/A',
        isOverdue,
      };
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // Enriched members list for Admin
  const allMembers = db.users
    .filter((u) => u.role === 'USER')
    .map((member) => {
      const activeCount = db.issues.filter((i) => i.userId === member.id && i.status === 'ACTIVE').length;
      const unpaidFinesTotal = db.fines
        .filter((f) => f.userId === member.id && f.status === 'UNPAID')
        .reduce((sum, f) => sum + f.amount, 0);
      const totalHistoryCount = db.issues.filter((i) => i.userId === member.id).length;
      return {
        id: member.id,
        fullName: member.fullName,
        email: member.email,
        username: member.username,
        accountStatus: member.accountStatus,
        createdAt: member.createdAt,
        activeIssueCount: activeCount,
        unpaidFinesTotal,
        totalHistoryCount,
      };
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // Enriched fines list for Admin
  const allFines = db.fines
    .map((fine) => {
      const user = db.users.find((u) => u.id === fine.userId);
      const book = db.books.find((b) => b.id === fine.bookId);
      return {
        ...fine,
        memberName: user?.fullName || 'Unknown Member',
        memberUsername: user?.username || 'N/A',
        memberEmail: user?.email || 'N/A',
        bookTitle: book?.title || 'Book Loan',
      };
    })
    .sort((a, b) => new Date(b.calculatedTimestamp).getTime() - new Date(a.calculatedTimestamp).getTime());

  // Enriched reservations list for Admin
  const allReservations = db.reservations
    .map((resv) => {
      const user = db.users.find((u) => u.id === resv.userId);
      const book = db.books.find((b) => b.id === resv.bookId);
      return {
        ...resv,
        memberName: user?.fullName || 'Unknown Member',
        memberUsername: user?.username || 'N/A',
        memberEmail: user?.email || 'N/A',
        bookTitle: book?.title || 'Unknown Title',
        bookIsbn: book?.isbn || 'N/A',
        availableQuantity: book?.availableQuantity || 0,
      };
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  res.json({
    counts: {
      totalBooks,
      availableCopies,
      issuedCopies,
      registeredMembers,
      outstandingFines,
      pendingQueries,
      pendingReservations,
    },
    issues: allIssues,
    members: allMembers,
    fines: allFines,
    reservations: allReservations,
    contacts: [...db.contacts].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
  });
});

// 18. Reset Database to Initial Seed
app.post('/api/admin/reset-database', (req, res) => {
  db = getInitialData();
  saveDatabase(db);
  res.json({ message: 'Database reset to default seed state with demo accounts and test loans.' });
});

// Start server with Vite middleware in development
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 LibroSphere backend & dev server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
