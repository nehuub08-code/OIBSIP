# AI UNPACKED: From Data to Intelligent Decisions
## Complete Content Specification for Infographic (800 × 2000 px)

- **Designer:** Neha Vinod Borkar
- **Internship:** Oasis Infobyte (Track: Graphics Design)
- **Task Title:** Task 4 — Infographic
- **Target Audience:** Students, beginners in technology, and general readers
- **Tone:** Educational, clear, modern, friendly, and scientifically responsible
- **Palette Restrictions:** Maximum 4 colours
  - Deep navy: `#101828` (Primary background and headings)
  - Electric blue: `#3867FF` (Process arrows, emphasis, visual bridges)
  - Aqua: `#48D9D0` (Highlights, node connectors, secondary accents)
  - White: `#FFFFFF` (Body typography, card surfaces, high-contrast labels)

---

### Header Section
- **Kicker:** OASIS INFOBYTE INTERNSHIP · GRAPHICS DESIGN TASK 4
- **Main Title:** AI UNPACKED
- **Subtitle:** From Data to Intelligent Decisions
- **Lead Description:** Artificial Intelligence decoded in simple terms — how machines learn, where they operate, and why human judgment remains essential.

---

### Section 1: What is Artificial Intelligence?
- **Heading:** 01. WHAT IS ARTIFICIAL INTELLIGENCE?
- **Core Definition:**
  > "Artificial Intelligence (AI) refers to machine-based systems that can generate predictions, recommendations, or decisions for defined objectives."
  *(Faithfully adapted from the National Institute of Standards and Technology - NIST AI Glossary)*
- **Everyday Illustration:**
  - *Scenario:* A navigation app estimating the fastest commute route in real-time.
  - *Mechanism:* It processes live sensor data, estimates traffic density, and generates an optimized route suggestion for the driver.
- **Visual Diagram Architecture:**
  - Center Node: "AI System" core engine
  - Connected Peripheral Nodes:
    - Inputs: "Input Data" (Live conditions, maps, speeds)
    - Processing: "Pattern Analysis" (Historical vs real-time flows)
    - Outputs: "Intelligent Action" (Predictions, Recommendations, Decisions)

---

### Section 2: How Does AI Work?
- **Heading:** 02. FROM DATA TO DECISIONS
- **Subtitle:** A simplified four-step educational workflow:
- **Step 1 — COLLECT DATA:**
  - *Summary:* Text, images, sensor numbers, or audio enter the system as raw informational inputs.
  - *Visual Anchor:* Input ingestion stack with binary/data packet indicators.
- **Step 2 — LEARN PATTERNS:**
  - *Summary:* A machine-learning model trains on curated data to discover underlying mathematical patterns and statistical relationships.
  - *Visual Anchor:* Pattern recognition matrix / algorithmic transformation icon.
- **Step 3 — GENERATE OUTPUT:**
  - *Summary:* The model computes an outcome: a discrete classification, numerical forecast, ranking recommendation, or synthetic text/image.
  - *Visual Anchor:* Crisp output terminal symbol with directional action indicator.
- **Step 4 — EVALUATE & IMPROVE:**
  - *Summary:* Human engineers and domain specialists review model outputs, measure real-world performance, and refine the data or model architecture.
  - *Visual Anchor:* Human-in-the-loop audit circle with calibration controls.
- **Educational Accuracy Note:**
  *This is a foundational educational workflow. Real-world AI architectures vary across reinforcement learning, unsupervised clustering, and static rule-based systems. AI models do not magically self-improve without human-directed retraining and data maintenance.*

---

### Section 3: Meet the AI Family
- **Heading:** 03. MEET THE AI FAMILY
- **Subtitle:** Understanding the overlapping layers of modern artificial intelligence:
- **Card A — Machine Learning (ML):**
  - *Role:* The foundational branch where algorithms learn patterns directly from data to make predictions or uncover structures without being explicitly hardcoded.
  - *Real-world Example:* E-commerce demand forecasting & spam filtering.
  - *Visual Element:* Statistical trend regression & clustering scatterplot.
- **Card B — Deep Learning:**
  - *Role:* A specialized subset of Machine Learning utilizing multi-layer artificial neural networks to extract high-level representations from unstructured data.
  - *Real-world Example:* Recognizing objects in medical MRIs & autonomous vehicle perception.
  - *Visual Element:* Multi-layered interconnected neural network graph (Input → Hidden → Output layers).
- **Card C — Generative AI:**
  - *Role:* Advanced models that synthesize novel content—including coherent prose, photorealistic images, speech, or code—based on statistical distributions in training data.
  - *Real-world Example:* Drafting an initial email response or generating graphic design mockups.
  - *Visual Element:* Creative prompt-to-canvas spark matrix and document synthesis icon.
- **Scientific Accuracy Callout:**
  *Machine Learning is a subset of AI, Deep Learning is a specialized branch of Machine Learning, and Generative AI describes functional content-generation capabilities. These domains overlap rather than represent disconnected technologies.*

---

### Section 4: AI in Everyday Life
- **Heading:** 04. AI IN EVERYDAY LIFE
- **Subtitle:** Practical applications powering tools across four essential industries:
- **Application 1 — Education:**
  - Personalized learning pacing, adaptive practice problem generation, and automated feedback on student drafts.
  - *Key Benefit:* Meeting individual student learning speeds.
- **Application 2 — Healthcare:**
  - Assisting radiologists in identifying subtle lung scan anomalies, genomic sequence analysis, and drug candidate screening.
  - *Key Benefit:* Accelerated diagnostic pattern discovery for doctors.
- **Application 3 — Finance:**
  - Real-time transaction fraud detection, credit risk assessment models, and high-frequency market liquidity analysis.
  - *Key Benefit:* Millisecond detection of fraudulent payment anomalies.
- **Application 4 — Transport:**
  - Dynamic transit route estimation, sensor-based collision warning systems, and municipal traffic signal coordination.
  - *Key Benefit:* Reduced commute delays and improved transit safety.
- **Educational Scope Note:**
  *These are illustrative examples of AI application areas, not claims that every software system in these industries utilizes AI.*

---

### Section 5: Two Sides of AI (Benefits & Challenges)
- **Heading:** 05. TWO SIDES OF AI
- **Subtitle:** Balancing technological velocity with sociotechnical reality:
- **Column 1 — Potential Benefits:**
  - 1. **High-Volume Data Processing:** Rapidly parses petabytes of scientific and sensor data beyond manual capacity.
  - 2. **Repetitive Task Automation:** Automates mechanical data entry, transcription, and indexing routines.
  - 3. **Accelerated Decision Support:** Provides rapid initial forecasts and scenario modeling for human specialists.
  - 4. **Creative & Analytical Assistance:** Serves as a collaborative springboard for ideation, drafting, and programming.
- **Column 2 — Important Challenges:**
  - 1. **Algorithmic Bias:** Training data with historical disparities produces systemic bias and unfair discrimination.
  - 2. **Data Privacy Risks:** Ingestion of sensitive personal records poses severe privacy and unauthorized exposure risks.
  - 3. **Plausible Hallucinations:** Generative models can produce convincing yet completely factually incorrect information.
  - 4. **Explainability & Opacity:** Complex deep neural networks often operate as "black boxes," making auditing difficult.
- **Balanced Insight:**
  *AI does not eliminate error or ensure objective truth. It reflects the assumptions, limitations, and biases embedded in its training data.*

---

### Section 6: Use AI Wisely (Responsible AI Principles)
- **Heading:** 06. USE AI WISELY
- **Subtitle:** Four actionable principles for students, professionals, and citizens:
- **Principle 1 — CHECK THE OUTPUT:**
  - *Guidance:* Always cross-verify critical claims, statistical figures, and citations against primary authoritative sources. Never accept generated text as verified fact.
- **Principle 2 — PROTECT PRIVACY:**
  - *Guidance:* Never paste confidential passwords, student IDs, personal medical histories, or proprietary data into public AI prompts.
- **Principle 3 — LOOK FOR BIAS:**
  - *Guidance:* Actively question whether outputs favor specific demographics, omit critical perspectives, or perpetuate stereotypes.
- **Principle 4 — KEEP HUMANS INVOLVED:**
  - *Guidance:* Ensure qualified human oversight governs high-stakes decisions impacting employment, legal outcomes, or medical treatment.
- **Disclaimer:**
  *These principles represent actionable educational guidance informed by international responsible AI frameworks (NIST & UNESCO), not formal statutory legal advice.*

---

### Section 7: Final Takeaway & Footer
- **Closing Heading:** AI IS A TOOL. HUMAN JUDGMENT STILL MATTERS.
- **Closing Motto:** Understand the data. Question the output. Use intelligence responsibly.
- **Citations & Credibility Footnote:**
  1. *NIST CSRC Glossary (2023) — Artificial Intelligence Terminology*
  2. *NIST SP 1270 — Explaining Decisions Made with Artificial Intelligence*
  3. *UNESCO — AI and Education: Guidance for Policy-makers*
  4. *U.S. FDA — Digital Health & Artificial Intelligence Glossary*
- **Designer Signature:**
  - Designed by Neha Vinod Borkar · Oasis Infobyte Graphics Design Internship · Task 4
