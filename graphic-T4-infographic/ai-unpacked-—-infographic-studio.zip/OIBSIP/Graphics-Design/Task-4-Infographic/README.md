# OASIS INFOBYTE — GRAPHICS DESIGN INTERNSHIP
## TASK 4: INFOGRAPHIC — AI UNPACKED: FROM DATA TO INTELLIGENT DECISIONS

![Infographic Preview](screenshots/infographic-preview.png)

---

### Project Overview & Metadata

- **Designer Name:** Neha Vinod Borkar
- **Internship Track:** Graphics Design
- **Exact Task Title:** Infographic
- **Project Title:** AI Unpacked — How Artificial Intelligence Works
- **Repository Location:** `OIBSIP/Graphics-Design/Task-4-Infographic/`
- **Primary Design Tool:** Canva (Professional Vector & Editorial Layout) & AI Studio Infographic Engine
- **Canvas Dimensions:** `800 × 2000 pixels` (Tall portrait aspect ratio 1:2.5)
- **Export Resolution & Format:** High-resolution PNG, minimum 150 DPI (Nominal print dimensions: ~5.33 × 13.33 inches)

---

### 1. Topic, Objective & Intended Audience

- **Main Title:** `AI UNPACKED`
- **Subtitle:** `From Data to Intelligent Decisions`
- **Project Objective:** To demystify artificial intelligence for general audiences through a clean, scientifically responsible, and visually structured narrative. The infographic bridges technical abstraction and everyday intuition by walking readers through foundational definitions, learning workflows, core technology taxonomies, real-world utility, balanced sociotechnical tradeoffs, and actionable ethical safeguards.
- **Target Audience:** Secondary and tertiary students, beginners in technology, educators, and general readers seeking clarity without unnecessary jargon.
- **Editorial Tone:** Educational, clear, modern, approachable, and rigorously faithful to international standards.

---

### 2. Visual Identity & Design System

To ensure professional elegance and avoid visual clutter, the entire graphic strictly adheres to a disciplined 4-colour palette and an intentional 2-font typographic hierarchy.

#### A. Disciplined 4-Colour Palette
| Role | Color Name | Hex Code | Purpose & Application |
| :--- | :--- | :--- | :--- |
| **Primary Base** | Deep Navy | `#101828` | Main canvas background, prominent headings, container borders, and structural framing. |
| **Emphasis & Flow** | Electric Blue | `#3867FF` | Process flow arrows, active step numbers, category badges, and directional indicators. |
| **Highlights & Accents** | Aqua | `#48D9D0` | Data pulses, network nodes, focal icons, checkmarks, and key takeaways. |
| **Clarity & Contrast** | Pure White | `#FFFFFF` | Primary body typography, clean high-contrast text cards, and light information panels. |

*Zero decorative neon gradients or uncoordinated hues were introduced.*

#### B. Typographic Pairings
- **Headings & Display:** `Space Grotesk` (Bold / Semi-Bold, 600–700 weight). Engineered for geometric balance, sharp modern numerals, and high-impact scanning.
- **Body & Captions:** `Inter` / `Manrope` (Regular / Medium, 400–500 weight). Renowned for exceptional screen legibility at small sizes (12px–15px) and optical clarity.

---

### 3. Visual Flow & Information Architecture

The infographic is structured into a seamless, top-to-bottom vertical progression across seven distinct modules:

```
[ HEADER ]
AI UNPACKED — From Data to Intelligent Decisions
   │
   ▼
[ SECTION 01: WHAT IS ARTIFICIAL INTELLIGENCE? ]
NIST definition + Connected central node diagram (Data -> AI -> Decision) + Navigation app example
   │
   ▼
[ SECTION 02: FROM DATA TO DECISIONS ]
Vertical 4-step pipeline: Collect Data → Learn Patterns → Generate Output → Evaluate & Improve
   │
   ▼
[ SECTION 03: MEET THE AI FAMILY ]
3-Card Taxonomy: Machine Learning (Regression) · Deep Learning (Neural Net) · Generative AI (Content)
   │
   ▼
[ SECTION 04: AI IN EVERYDAY LIFE ]
2×2 Sector Matrix: Education · Healthcare · Finance · Transport
   │
   ▼
[ SECTION 05: TWO SIDES OF AI ]
Balanced comparative columns: 4 Potential Benefits vs 4 Important Challenges
   │
   ▼
[ SECTION 06: USE AI WISELY ]
Shield & checklist motif: 4 Actionable Ethical Principles
   │
   ▼
[ SECTION 07: FINAL TAKEAWAY & CITATIONS ]
Closing motto: "Understand the data. Question the output. Use intelligence responsibly."
Formal citations (NIST, UNESCO, FDA) + Designer signature
```

---

### 4. Mandatory Visual Elements Included

1. **Consistent Line Icons:** Unified vector stroke weight (1.5px–2px) across all modules (database cylinders, neural clusters, health caduceus, transport vehicles, shields, and audit loupes).
2. **Step-by-Step Process Flow:** A structured 4-phase sequence in Section 2 featuring connected directional arrows, badge anchors, and concise phase descriptions.
3. **Custom Illustrated Diagrams:**
   - Section 1: Central AI hub interconnected with input, analytical, and decision-making satellite nodes.
   - Section 3: 3-layer deep artificial neural network diagram illustrating Input, Hidden, and Output matrices.
4. **Balanced Comparative Panels:** Side-by-side contrast grid in Section 5 juxtaposing technological capabilities with sociotechnical risks (algorithmic bias, data privacy, hallucinations, and opacity).

---

### 5. Verified Sources & Fact-Checking

Every informational claim in this design is backed by established standards:

1. **National Institute of Standards and Technology (NIST)**  
   *AI Glossary & Core Definitions* — [https://csrc.nist.gov/glossary/term/artificial_intelligence](https://csrc.nist.gov/glossary/term/artificial_intelligence)  
   *Supported Section 1 AI definition and output classification.*
2. **NIST Special Publication (SP 1270)**  
   *Towards a Standard for Identifying and Managing Bias in Artificial Intelligence* — [https://www.nist.gov/system/files/documents/2021/10/04/explaining-decisions-made-with-artificial-intelligence-1-0.pdf](https://www.nist.gov/system/files/documents/2021/10/04/explaining-decisions-made-with-artificial-intelligence-1-0.pdf)  
   *Informed bias recognition, explainability challenges, and human oversight.*
3. **UNESCO Education Sector**  
   *AI and Education: Guidance for Policy-makers* — [https://unesdoc.unesco.org/in/rest/annotationSVC/DownloadWatermarkedAttachment/attach_import_761bcdad-d1e3-40c9-819d-03c4ac725f26?_=376709eng.pdf&from=8&to=40](https://unesdoc.unesco.org/in/rest/annotationSVC/DownloadWatermarkedAttachment/attach_import_761bcdad-d1e3-40c9-819d-03c4ac725f26?_=376709eng.pdf&from=8&to=40)  
   *Guided educational application guidelines, privacy safeguards, and ethics.*
4. **U.S. Food and Drug Administration (FDA)**  
   *Digital Health and Artificial Intelligence Glossary: Educational Resource* — [https://www.fda.gov/science-research/artificial-intelligence-and-medical-products/fda-digital-health-and-artificial-intelligence-glossary-educational-resource](https://www.fda.gov/science-research/artificial-intelligence-and-medical-products/fda-digital-health-and-artificial-intelligence-glossary-educational-resource)  
   *Verified Machine Learning vs Deep Learning distinctions and medical imaging use cases.*

---

### 6. Canva Recreation Blueprint & Step-by-Step Instructions

For direct replication or editing inside **Canva**, follow these exact specifications:

1. **Canvas Setup:**
   - Log into Canva (`canva.com`).
   - Click **Create a design** > **Custom size**.
   - Width: `800 px`, Height: `2000 px`.
   - Set Background Color to `#101828` (Deep Navy).
   - Turn on **View Settings > Show Rulers and Guides** and **Show Margins** (Set 32px safe margins on left and right).

2. **Colour Swatches to Save in Canva Kit:**
   - `#101828` (Navy Background)
   - `#3867FF` (Electric Blue)
   - `#48D9D0` (Aqua Accent)
   - `#FFFFFF` (Pure White)

3. **Section Coordinate & Height Guide:**
   - **Header:** `Y = 0 to 180px` | Title: `Space Grotesk Bold`, 42pt, Color: `#FFFFFF` | Subtitle: 18pt, Color: `#48D9D0`.
   - **Section 1 (What is AI):** `Y = 190 to 440px` | Heading: 20pt, Color: `#48D9D0` | NIST Definition card: Background `#162035`, Border 1px `#3867FF`.
   - **Section 2 (4-Step Flow):** `Y = 460 to 820px` | 4 Cards, Height 70px each, connected by vertical arrows (`#3867FF`).
   - **Section 3 (AI Family):** `Y = 840 to 1180px` | 3 Horizontal Cards (ML, Deep Learning, Generative AI), width 736px, height 96px each.
   - **Section 4 (AI Around Us):** `Y = 1200 to 1440px` | 2×2 Grid of rounded cards (356px × 100px each).
   - **Section 5 (Two Sides):** `Y = 1460 to 1710px` | 2 Side-by-side columns (Width: 356px each), Left: Potential Benefits (`#48D9D0` bullets), Right: Challenges (`#3867FF` bullets).
   - **Section 6 (Use AI Wisely):** `Y = 1730 to 1910px` | 4 Shield checklist rows with `#48D9D0` checkmark icons.
   - **Section 7 (Footer & Sources):** `Y = 1920 to 2000px` | Citations in `Inter Regular`, 9pt, Color: `#8da2c0`.

4. **Canva Element Search Keywords:**
   - Central Diagram: *"data network icon"*, *"neural nodes line"*
   - Deep Learning: *"neural network diagram"*, *"nodes connected line art"*
   - Healthcare: *"stethoscope line icon"*, *"medical cross outline"*
   - Transport: *"navigation route line icon"*, *"smart car outline"*
   - Responsible AI: *"shield check icon"*, *"privacy lock line"*

5. **Exporting from Canva:**
   - Click **Share** > **Download**.
   - File type: **PNG**.
   - Size slider: Set to **1x** (800 × 2000 px) or **2x** (1600 × 4000 px, 300 DPI equivalent for professional print).
   - Quality: High. Download as `AI-Unpacked-Infographic.png`.

---

### 7. Verification & Quality Checklist

- [x] Clear topic and title at the top (`AI UNPACKED: From Data to Intelligent Decisions`).
- [x] At least five distinct informational sections (Includes all 7 detailed thematic modules).
- [x] At least three types of visual elements (Consistent line icons, 4-step process diagram, illustrated neural network & node diagrams, balanced comparative panels).
- [x] Consistent palette of four colours or fewer (`#101828`, `#3867FF`, `#48D9D0`, `#FFFFFF`).
- [x] Clear top-to-bottom reading flow with numbered stages and connected visual anchors.
- [x] Relevant claims checked against credible sources (NIST, UNESCO, FDA).
- [x] Sources cited at the bottom of the infographic with full URLs in `sources.md`.
- [x] Canvas is exactly `800 × 2000 pixels`.
- [x] PNG is exported at high quality with target resolution (min 150 DPI) validated.
- [x] Text and source citations remain crisp and legible at full scale.
- [x] Spelling, grammar, alignment, and spacing thoroughly audited.
- [x] README and source notes complete with Canva recreation specifications.
- [x] Final deliverable files organized in the `OIBSIP` repository structure.
