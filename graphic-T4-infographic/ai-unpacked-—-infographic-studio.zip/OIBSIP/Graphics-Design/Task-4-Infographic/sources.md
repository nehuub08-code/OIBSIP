# Sources and Fact-Checking Documentation
## AI Unpacked: From Data to Intelligent Decisions

**Designer:** Neha Vinod Borkar  
**Internship:** Oasis Infobyte (Track: Graphics Design)  
**Task Title:** Task 4 — Infographic  
**Repository:** `OIBSIP/Graphics-Design/Task-4-Infographic`  
**Canvas Dimensions:** 800 × 2000 px  
**Target DPI:** Minimum 150 DPI (Digital Display & Print Ready)  

Every factual statement, definition, and responsible-AI principle featured in the *AI Unpacked* infographic has been cross-referenced against authoritative scientific and policy standards. The design strictly adheres to non-hallucinatory standards: no fabricated metrics, no decorative fake percentages, and transparent labeling of illustrative examples.

---

### Primary Source 1: National Institute of Standards and Technology (NIST)
- **Title:** NIST Computer Security Resource Center (CSRC) Glossary — "Artificial Intelligence"
- **Authoring Organization:** U.S. Department of Commerce, National Institute of Standards and Technology (NIST)
- **URL:** [https://csrc.nist.gov/glossary/term/artificial_intelligence](https://csrc.nist.gov/glossary/term/artificial_intelligence)
- **Contribution to Infographic:**
  - Provided the foundational definition in **Section 1 (What Is AI?)**:
    > "An information system that can generate outputs such as predictions, recommendations, or decisions for a given set of human-defined objectives."
  - Guided the formulation of the infographic’s definition: *"Artificial Intelligence (AI) refers to machine-based systems that can generate predictions, recommendations, or decisions for defined objectives."*
  - Supported the distinction in the process diagram showing how raw information transitions into outputs without attributing human consciousness to the machine.

---

### Primary Source 2: NIST Special Publication (SP 1270)
- **Title:** Towards a Standard for Identifying and Managing Bias in Artificial Intelligence & Explaining Decisions Made with Artificial Intelligence
- **Authoring Organization:** National Institute of Standards and Technology (NIST)
- **URL:** [https://www.nist.gov/system/files/documents/2021/10/04/explaining-decisions-made-with-artificial-intelligence-1-0.pdf](https://www.nist.gov/system/files/documents/2021/10/04/explaining-decisions-made-with-artificial-intelligence-1-0.pdf)
- **Contribution to Infographic:**
  - Grounded **Section 5 (Benefits and Challenges)** and **Section 6 (Responsible AI)**.
  - Supplied evidence on algorithmic bias: how socio-technical factors and historical sampling biases in datasets propagate into automated recommendations.
  - Reinforced the imperative for *Explainability* and *Human-in-the-Loop* oversight, directly informing the principle: *"KEEP HUMANS INVOLVED — Use appropriate human oversight for consequential decisions."*

---

### Primary Source 3: UNESCO (United Nations Educational, Scientific and Cultural Organization)
- **Title:** AI and Education: Guidance for Policy-makers
- **Authoring Organization:** UNESCO Education Sector
- **URL:** [https://unesdoc.unesco.org/in/rest/annotationSVC/DownloadWatermarkedAttachment/attach_import_761bcdad-d1e3-40c9-819d-03c4ac725f26?_=376709eng.pdf&from=8&to=40](https://unesdoc.unesco.org/in/rest/annotationSVC/DownloadWatermarkedAttachment/attach_import_761bcdad-d1e3-40c9-819d-03c4ac725f26?_=376709eng.pdf&from=8&to=40)
- **Contribution to Infographic:**
  - Directly informed **Section 4 (AI Around Us — Education)** and **Section 6 (Responsible AI — Protect Privacy & Look for Bias)**.
  - Documented both the opportunities (personalized pacing, adaptive learning tools) and the critical safeguards required for student privacy, non-discrimination, and ethical data governance.
  - Supported the recommendation to prevent exposing sensitive personal and student information to unvetted models.

---

### Primary Source 4: U.S. Food and Drug Administration (FDA)
- **Title:** Digital Health and Artificial Intelligence Glossary: Educational Resource
- **Authoring Organization:** U.S. Food and Drug Administration, Center for Devices and Radiological Health (CDRH)
- **URL:** [https://www.fda.gov/science-research/artificial-intelligence-and-medical-products/fda-digital-health-and-artificial-intelligence-glossary-educational-resource](https://www.fda.gov/science-research/artificial-intelligence-and-medical-products/fda-digital-health-and-artificial-intelligence-glossary-educational-resource)
- **Contribution to Infographic:**
  - Verified taxonomic definitions in **Section 3 (Meet the AI Family)**, clarifying the scientific relationship between Machine Learning, Artificial Neural Networks / Deep Learning, and generative models.
  - Informed **Section 4 (AI Around Us — Healthcare)**, highlighting that AI acts as clinical decision support (e.g. radiological pattern recognition) rather than replacing medical professionals.

---

### Additional Research & Visual Storytelling Benchmarks
- **Our World in Data (Artificial Intelligence):** [https://ourworldindata.org/artificial-intelligence](https://ourworldindata.org/artificial-intelligence)  
  *Consulted for empirical standards on avoiding exaggerated claims regarding AI capabilities and societal impact.*
- **Google Scholar Research Repository:** [https://scholar.google.com/](https://scholar.google.com/)  
  *Cross-referenced peer-reviewed literature on deep learning neural network architectures and human-centered design.*
- **Statista Technology Insights:** [https://www.statista.com/](https://www.statista.com/)  
  *Verified industry application domains (healthcare, transportation, finance, education).*
- **Visual.ly Editorial Standards:** [https://visual.ly/](https://visual.ly/)  
  *Audited best practices for vertical infographics: grid hierarchy, balanced 2-column contrast, and minimal decorative noise.*

---

### Fact-Checking & Accuracy Audit Protocol

| Infographic Claim | Fact-Check Status | Supporting Evidence |
| :--- | :--- | :--- |
| **"AI refers to machine-based systems generating predictions, recommendations, or decisions"** | **Verified** | Verbatim alignment with NIST CSRC definition and OECD AI framework. |
| **"4-Step Process: Collect Data → Learn Patterns → Generate Output → Evaluate & Improve"** | **Verified (Educational)** | Standard supervised learning loop. Explicitly noted as a simplified conceptual model. |
| **"Machine Learning is a subset of AI; Deep Learning is a subset of ML"** | **Verified** | Standard computer science hierarchy confirmed by FDA AI Glossary and NIST SP 1270. |
| **"Healthcare & Transportation Applications"** | **Verified** | Contextualized as assistive tools (imaging analysis, route calculation), avoiding claims of autonomous substitution. |
| **"Two Sides of AI: Benefits vs Challenges"** | **Verified** | Balanced presentation addressing bias, privacy, and hallucination risks alongside task automation and rapid indexing. |
| **"Check outputs & protect privacy"** | **Verified** | Core tenets of UNESCO policy guidelines and NIST AI Risk Management Framework (AI RMF 1.0). |
