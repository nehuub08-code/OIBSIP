import fs from 'fs';
import path from 'path';
import { Resvg } from '@resvg/resvg-js';

// Infographic Dimensions
const WIDTH = 800;
const HEIGHT = 2000;

// The 4-colour palette
// Deep Navy: #101828
// Electric Blue: #3867FF
// Aqua: #48D9D0
// White: #FFFFFF

export const generateInfographicSvg = (): string => {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${WIDTH} ${HEIGHT}" width="${WIDTH}" height="${HEIGHT}" style="background-color: #101828; font-family: 'Space Grotesk', 'Inter', -apple-system, sans-serif;">
  <defs>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;family=Space+Grotesk:wght@600;700&amp;display=swap');
      .font-title { font-family: 'Space Grotesk', sans-serif; font-weight: 700; }
      .font-heading { font-family: 'Space Grotesk', sans-serif; font-weight: 600; }
      .font-body { font-family: 'Inter', sans-serif; font-weight: 400; }
      .font-medium { font-family: 'Inter', sans-serif; font-weight: 500; }
      .font-bold { font-family: 'Inter', sans-serif; font-weight: 700; }
    </style>
    
    <!-- Subdued grid pattern -->
    <pattern id="gridPattern" width="40" height="40" patternUnits="userSpaceOnUse">
      <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#3867FF" stroke-width="0.75" stroke-opacity="0.08" />
    </pattern>

    <!-- Linear gradients restricted to the 4 palette colors -->
    <linearGradient id="cardGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#162238" />
      <stop offset="100%" stop-color="#121B2C" />
    </linearGradient>

    <linearGradient id="blueGlow" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#3867FF" />
      <stop offset="100%" stop-color="#48D9D0" />
    </linearGradient>

    <linearGradient id="stepGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#192843" />
      <stop offset="100%" stop-color="#121C2F" />
    </linearGradient>
  </defs>

  <!-- Background Base -->
  <rect width="${WIDTH}" height="${HEIGHT}" fill="#101828" />
  <rect width="${WIDTH}" height="${HEIGHT}" fill="url(#gridPattern)" />

  <!-- Outer Margins Guide (32px left and right = 736px usable width, center 400) -->

  <!-- ========================================== -->
  <!-- HEADER SECTION (y: 0 - 180)                -->
  <!-- ========================================== -->
  <g transform="translate(40, 36)">
    <!-- Top Decorative Line -->
    <rect x="0" y="0" width="720" height="3" rx="1.5" fill="url(#blueGlow)" />

    <!-- Kicker / Tag -->
    <text x="0" y="24" fill="#48D9D0" font-size="11" letter-spacing="2.5" class="font-heading">OASIS INFOBYTE INTERNSHIP · GRAPHICS DESIGN TASK 4</text>
    
    <!-- Main Title -->
    <text x="0" y="68" fill="#FFFFFF" font-size="44" letter-spacing="-1" class="font-title">AI UNPACKED</text>
    
    <!-- Subtitle -->
    <text x="0" y="96" fill="#48D9D0" font-size="18" letter-spacing="0.2" class="font-heading">From Data to Intelligent Decisions</text>
    
    <!-- Brief Hook -->
    <text x="0" y="122" fill="#FFFFFF" fill-opacity="0.82" font-size="13" class="font-body">A beginner-friendly guide to how artificial intelligence works, where it operates, and why human judgment remains vital.</text>
    
    <!-- Bottom Header Rule -->
    <line x1="0" y1="140" x2="720" y2="140" stroke="#3867FF" stroke-width="1.5" stroke-opacity="0.4" />
  </g>

  <!-- ========================================== -->
  <!-- SECTION 1: WHAT IS AI? (y: 195 - 435)      -->
  <!-- ========================================== -->
  <g transform="translate(40, 195)">
    <!-- Section Header -->
    <rect x="0" y="0" width="28" height="28" rx="6" fill="#3867FF" fill-opacity="0.2" />
    <text x="9" y="19" fill="#48D9D0" font-size="13" class="font-heading">01</text>
    <text x="38" y="20" fill="#FFFFFF" font-size="18" letter-spacing="0.5" class="font-heading">WHAT IS ARTIFICIAL INTELLIGENCE?</text>

    <!-- Definition Card -->
    <g transform="translate(0, 40)">
      <rect x="0" y="0" width="720" height="92" rx="10" fill="url(#cardGrad)" stroke="#3867FF" stroke-width="1" stroke-opacity="0.4" />
      
      <!-- NIST Reference Tag -->
      <text x="24" y="26" fill="#48D9D0" font-size="10.5" letter-spacing="1.5" class="font-heading">OFFICIAL DEFINITION (NIST CSRC STANDARD)</text>
      <text x="24" y="48" fill="#FFFFFF" font-size="13.5" class="font-medium">"Artificial Intelligence (AI) refers to machine-based systems that can generate</text>
      <text x="24" y="68" fill="#FFFFFF" font-size="13.5" class="font-medium">predictions, recommendations, or decisions for defined objectives."</text>
    </g>

    <!-- Visual Node Diagram & Example -->
    <g transform="translate(0, 142)">
      <!-- Left: Everyday Navigation Example -->
      <g transform="translate(0, 0)">
        <rect x="0" y="0" width="345" height="85" rx="8" fill="#131D31" stroke="#3867FF" stroke-width="0.8" stroke-opacity="0.3" />
        <!-- Pin / Route Icon -->
        <circle cx="28" cy="42" r="14" fill="#3867FF" fill-opacity="0.2" />
        <path d="M 28 34 C 24.5 34 22 36.5 22 40 C 22 44.5 28 50 28 50 C 28 50 34 44.5 34 40 C 34 36.5 31.5 34 28 34 Z M 28 41.5 C 27 41.5 26.2 40.7 26.2 39.8 C 26.2 38.8 27 38 28 38 C 29 38 29.8 38.8 29.8 39.8 C 29.8 40.7 29 41.5 28 41.5 Z" fill="#48D9D0" />
        
        <text x="52" y="30" fill="#48D9D0" font-size="11" class="font-heading">EVERYDAY EXAMPLE: NAVIGATION</text>
        <text x="52" y="48" fill="#FFFFFF" fill-opacity="0.9" font-size="11.5" class="font-body">A navigation app calculates a suitable route by</text>
        <text x="52" y="64" fill="#FFFFFF" fill-opacity="0.9" font-size="11.5" class="font-body">processing current speeds and historical delays.</text>
      </g>

      <!-- Right: Central AI Diagram -->
      <g transform="translate(365, 0)">
        <rect x="0" y="0" width="355" height="85" rx="8" fill="#131D31" stroke="#48D9D0" stroke-width="0.8" stroke-opacity="0.3" />
        
        <!-- Connected Diagram SVG Elements -->
        <!-- Center Hub -->
        <circle cx="178" cy="42" r="22" fill="#3867FF" fill-opacity="0.25" stroke="#48D9D0" stroke-width="1.5" />
        <text x="178" y="46" text-anchor="middle" fill="#FFFFFF" font-size="11" class="font-heading">AI SYSTEM</text>

        <!-- Node 1: Input Data (Left) -->
        <line x1="56" y1="42" x2="156" y2="42" stroke="#48D9D0" stroke-width="1.5" stroke-dasharray="3 3" />
        <circle cx="56" cy="42" r="15" fill="#162238" stroke="#3867FF" stroke-width="1.2" />
        <text x="56" y="46" text-anchor="middle" fill="#48D9D0" font-size="8.5" class="font-heading">DATA</text>

        <!-- Node 2: Decision (Right) -->
        <line x1="200" y1="42" x2="298" y2="42" stroke="#48D9D0" stroke-width="1.5" />
        <circle cx="298" cy="42" r="15" fill="#162238" stroke="#48D9D0" stroke-width="1.2" />
        <text x="298" y="46" text-anchor="middle" fill="#FFFFFF" font-size="8" class="font-heading">DECISION</text>
      </g>
    </g>
  </g>

  <!-- ========================================== -->
  <!-- SECTION 2: HOW DOES AI WORK? (y: 450 - 815)-->
  <!-- ========================================== -->
  <g transform="translate(40, 450)">
    <!-- Section Header -->
    <rect x="0" y="0" width="28" height="28" rx="6" fill="#3867FF" fill-opacity="0.2" />
    <text x="9" y="19" fill="#48D9D0" font-size="13" class="font-heading">02</text>
    <text x="38" y="20" fill="#FFFFFF" font-size="18" letter-spacing="0.5" class="font-heading">FROM DATA TO DECISIONS: HOW AI WORKS</text>
    <text x="38" y="38" fill="#FFFFFF" fill-opacity="0.65" font-size="11.5" class="font-body">A simplified four-step educational process diagram connecting inputs to evaluated outcomes.</text>

    <!-- STEP 1 -->
    <g transform="translate(0, 52)">
      <rect x="0" y="0" width="720" height="58" rx="8" fill="url(#stepGrad)" stroke="#3867FF" stroke-width="1" stroke-opacity="0.35" />
      <!-- Step Badge -->
      <rect x="14" y="13" width="72" height="32" rx="6" fill="#3867FF" />
      <text x="50" y="33" text-anchor="middle" fill="#FFFFFF" font-size="11" class="font-heading">STEP 1</text>
      <!-- Title & Text -->
      <text x="100" y="27" fill="#48D9D0" font-size="13" class="font-heading">COLLECT DATA</text>
      <text x="100" y="44" fill="#FFFFFF" fill-opacity="0.88" font-size="11.5" class="font-body">Text, images, numbers, audio, or sensor readings enter the system as raw material.</text>
      <!-- Icon Right -->
      <circle cx="680" cy="29" r="16" fill="#3867FF" fill-opacity="0.2" />
      <path d="M 674 23 L 686 23 L 686 35 L 674 35 Z M 677 26 L 683 26 M 677 29 L 683 29 M 677 32 L 681 32" stroke="#48D9D0" stroke-width="1.2" fill="none" />
    </g>

    <!-- Connector Arrow 1 -> 2 -->
    <g transform="translate(360, 110)">
      <line x1="0" y1="0" x2="0" y2="12" stroke="#3867FF" stroke-width="2" />
      <polygon points="-4,10 4,10 0,16" fill="#3867FF" />
    </g>

    <!-- STEP 2 -->
    <g transform="translate(0, 126)">
      <rect x="0" y="0" width="720" height="58" rx="8" fill="url(#stepGrad)" stroke="#3867FF" stroke-width="1" stroke-opacity="0.35" />
      <rect x="14" y="13" width="72" height="32" rx="6" fill="#3867FF" />
      <text x="50" y="33" text-anchor="middle" fill="#FFFFFF" font-size="11" class="font-heading">STEP 2</text>
      <text x="100" y="27" fill="#48D9D0" font-size="13" class="font-heading">LEARN PATTERNS</text>
      <text x="100" y="44" fill="#FFFFFF" fill-opacity="0.88" font-size="11.5" class="font-body">A machine-learning model analyzes training examples to identify underlying statistical structures.</text>
      <!-- Icon Right (Brain/Network) -->
      <circle cx="680" cy="29" r="16" fill="#3867FF" fill-opacity="0.2" />
      <circle cx="676" cy="27" r="2.5" fill="#48D9D0" />
      <circle cx="684" cy="25" r="2.5" fill="#48D9D0" />
      <circle cx="680" cy="33" r="2.5" fill="#48D9D0" />
      <line x1="676" y1="27" x2="684" y2="25" stroke="#48D9D0" stroke-width="1" />
      <line x1="676" y1="27" x2="680" y2="33" stroke="#48D9D0" stroke-width="1" />
      <line x1="684" y1="25" x2="680" y2="33" stroke="#48D9D0" stroke-width="1" />
    </g>

    <!-- Connector Arrow 2 -> 3 -->
    <g transform="translate(360, 184)">
      <line x1="0" y1="0" x2="0" y2="12" stroke="#3867FF" stroke-width="2" />
      <polygon points="-4,10 4,10 0,16" fill="#3867FF" />
    </g>

    <!-- STEP 3 -->
    <g transform="translate(0, 200)">
      <rect x="0" y="0" width="720" height="58" rx="8" fill="url(#stepGrad)" stroke="#3867FF" stroke-width="1" stroke-opacity="0.35" />
      <rect x="14" y="13" width="72" height="32" rx="6" fill="#3867FF" />
      <text x="50" y="33" text-anchor="middle" fill="#FFFFFF" font-size="11" class="font-heading">STEP 3</text>
      <text x="100" y="27" fill="#48D9D0" font-size="13" class="font-heading">GENERATE OUTPUT</text>
      <text x="100" y="44" fill="#FFFFFF" fill-opacity="0.88" font-size="11.5" class="font-body">The system produces a classification, numerical prediction, suggested choice, or generated content.</text>
      <!-- Icon Right (Spark/Output) -->
      <circle cx="680" cy="29" r="16" fill="#3867FF" fill-opacity="0.2" />
      <path d="M 680 22 L 682 27 L 687 29 L 682 31 L 680 36 L 678 31 L 673 29 L 678 27 Z" fill="#48D9D0" />
    </g>

    <!-- Connector Arrow 3 -> 4 -->
    <g transform="translate(360, 258)">
      <line x1="0" y1="0" x2="0" y2="12" stroke="#3867FF" stroke-width="2" />
      <polygon points="-4,10 4,10 0,16" fill="#3867FF" />
    </g>

    <!-- STEP 4 -->
    <g transform="translate(0, 274)">
      <rect x="0" y="0" width="720" height="58" rx="8" fill="url(#stepGrad)" stroke="#3867FF" stroke-width="1" stroke-opacity="0.35" />
      <rect x="14" y="13" width="72" height="32" rx="6" fill="#3867FF" />
      <text x="50" y="33" text-anchor="middle" fill="#FFFFFF" font-size="11" class="font-heading">STEP 4</text>
      <text x="100" y="27" fill="#48D9D0" font-size="13" class="font-heading">EVALUATE AND IMPROVE</text>
      <text x="100" y="44" fill="#FFFFFF" fill-opacity="0.88" font-size="11.5" class="font-body">People evaluate the results for accuracy, fairness, and safety, refining the model when appropriate.</text>
      <!-- Icon Right (Loop/Check) -->
      <circle cx="680" cy="29" r="16" fill="#3867FF" fill-opacity="0.2" />
      <path d="M 675 29 L 678 33 L 686 24" stroke="#48D9D0" stroke-width="1.8" fill="none" stroke-linecap="round" />
    </g>

    <!-- Scientific Accuracy Note -->
    <g transform="translate(0, 338)">
      <rect x="0" y="0" width="720" height="26" rx="5" fill="#131D31" />
      <text x="12" y="17" fill="#FFFFFF" fill-opacity="0.75" font-size="10.5" class="font-body">Accuracy note: Not all AI systems learn identically, and systems do not continuously self-improve without human guidance.</text>
    </g>
  </g>

  <!-- ========================================== -->
  <!-- SECTION 3: THE AI FAMILY (y: 835 - 1175)   -->
  <!-- ========================================== -->
  <g transform="translate(40, 835)">
    <!-- Section Header -->
    <rect x="0" y="0" width="28" height="28" rx="6" fill="#3867FF" fill-opacity="0.2" />
    <text x="9" y="19" fill="#48D9D0" font-size="13" class="font-heading">03</text>
    <text x="38" y="20" fill="#FFFFFF" font-size="18" letter-spacing="0.5" class="font-heading">MEET THE AI FAMILY</text>
    <text x="38" y="38" fill="#FFFFFF" fill-opacity="0.65" font-size="11.5" class="font-body">Key categories that work together rather than existing as disconnected technologies.</text>

    <!-- CARD 1: MACHINE LEARNING (ML) -->
    <g transform="translate(0, 50)">
      <rect x="0" y="0" width="720" height="82" rx="8" fill="url(#cardGrad)" stroke="#3867FF" stroke-width="1" stroke-opacity="0.3" />
      
      <!-- Visual Graphic: Pattern Chart (Left) -->
      <g transform="translate(16, 14)">
        <rect x="0" y="0" width="80" height="54" rx="6" fill="#111B2C" stroke="#3867FF" stroke-width="0.8" stroke-opacity="0.4" />
        <!-- Scatter Points and Regression Trendline -->
        <circle cx="15" cy="42" r="2.5" fill="#48D9D0" />
        <circle cx="28" cy="36" r="2.5" fill="#48D9D0" />
        <circle cx="42" cy="28" r="2.5" fill="#48D9D0" />
        <circle cx="56" cy="22" r="2.5" fill="#48D9D0" />
        <circle cx="68" cy="14" r="3" fill="#FFFFFF" stroke="#3867FF" stroke-width="1.5" />
        <line x1="10" y1="46" x2="72" y2="12" stroke="#3867FF" stroke-width="1.5" />
      </g>

      <!-- Content -->
      <text x="110" y="28" fill="#FFFFFF" font-size="14" class="font-heading">MACHINE LEARNING (ML)</text>
      <text x="110" y="48" fill="#FFFFFF" fill-opacity="0.85" font-size="12" class="font-body">Learns patterns from data to make predictions or identify patterns.</text>
      <text x="110" y="66" fill="#48D9D0" font-size="11.5" class="font-medium">Example: Predicting likely product demand based on past shopping trends.</text>
    </g>

    <!-- CARD 2: DEEP LEARNING -->
    <g transform="translate(0, 140)">
      <rect x="0" y="0" width="720" height="82" rx="8" fill="url(#cardGrad)" stroke="#3867FF" stroke-width="1" stroke-opacity="0.3" />
      
      <!-- Visual Graphic: Multi-Layer Neural Network (Left) -->
      <g transform="translate(16, 14)">
        <rect x="0" y="0" width="80" height="54" rx="6" fill="#111B2C" stroke="#3867FF" stroke-width="0.8" stroke-opacity="0.4" />
        <!-- Layer 1 (Input) -->
        <circle cx="16" cy="17" r="3" fill="#48D9D0" />
        <circle cx="16" cy="37" r="3" fill="#48D9D0" />
        <!-- Layer 2 (Hidden) -->
        <circle cx="40" cy="14" r="3" fill="#3867FF" />
        <circle cx="40" cy="27" r="3" fill="#3867FF" />
        <circle cx="40" cy="40" r="3" fill="#3867FF" />
        <!-- Layer 3 (Output) -->
        <circle cx="64" cy="27" r="3.5" fill="#FFFFFF" stroke="#48D9D0" stroke-width="1" />
        <!-- Synapses -->
        <line x1="16" y1="17" x2="40" y2="14" stroke="#48D9D0" stroke-opacity="0.4" stroke-width="0.8" />
        <line x1="16" y1="17" x2="40" y2="27" stroke="#48D9D0" stroke-opacity="0.4" stroke-width="0.8" />
        <line x1="16" y1="37" x2="40" y2="27" stroke="#48D9D0" stroke-opacity="0.4" stroke-width="0.8" />
        <line x1="16" y1="37" x2="40" y2="40" stroke="#48D9D0" stroke-opacity="0.4" stroke-width="0.8" />
        <line x1="40" y1="14" x2="64" y2="27" stroke="#3867FF" stroke-opacity="0.6" stroke-width="0.8" />
        <line x1="40" y1="27" x2="64" y2="27" stroke="#3867FF" stroke-opacity="0.6" stroke-width="0.8" />
        <line x1="40" y1="40" x2="64" y2="27" stroke="#3867FF" stroke-opacity="0.6" stroke-width="0.8" />
      </g>

      <!-- Content -->
      <text x="110" y="28" fill="#FFFFFF" font-size="14" class="font-heading">DEEP LEARNING</text>
      <text x="110" y="48" fill="#FFFFFF" fill-opacity="0.85" font-size="12" class="font-body">Uses multi-layer neural networks to learn complex, layered patterns.</text>
      <text x="110" y="66" fill="#48D9D0" font-size="11.5" class="font-medium">Example: Recognizing objects, faces, or medical features in digital images.</text>
    </g>

    <!-- CARD 3: GENERATIVE AI -->
    <g transform="translate(0, 230)">
      <rect x="0" y="0" width="720" height="82" rx="8" fill="url(#cardGrad)" stroke="#3867FF" stroke-width="1" stroke-opacity="0.3" />
      
      <!-- Visual Graphic: Document & Spark (Left) -->
      <g transform="translate(16, 14)">
        <rect x="0" y="0" width="80" height="54" rx="6" fill="#111B2C" stroke="#3867FF" stroke-width="0.8" stroke-opacity="0.4" />
        <!-- Document outline -->
        <rect x="22" y="10" width="28" height="34" rx="3" fill="#192843" stroke="#FFFFFF" stroke-width="1" />
        <line x1="28" y1="18" x2="44" y2="18" stroke="#48D9D0" stroke-width="1" />
        <line x1="28" y1="24" x2="44" y2="24" stroke="#FFFFFF" stroke-opacity="0.6" stroke-width="1" />
        <line x1="28" y1="30" x2="38" y2="30" stroke="#FFFFFF" stroke-opacity="0.6" stroke-width="1" />
        <!-- Generative Spark Icon -->
        <path d="M 58 15 L 60 20 L 65 22 L 60 24 L 58 29 L 56 24 L 51 22 L 56 20 Z" fill="#48D9D0" />
      </g>

      <!-- Content -->
      <text x="110" y="28" fill="#FFFFFF" font-size="14" class="font-heading">GENERATIVE AI</text>
      <text x="110" y="48" fill="#FFFFFF" fill-opacity="0.85" font-size="12" class="font-body">Creates outputs such as text, images, audio, or code based on learned patterns.</text>
      <text x="110" y="66" fill="#48D9D0" font-size="11.5" class="font-medium">Example: Drafting a first version of an email, summary, or software function.</text>
    </g>

    <!-- Overlap Accuracy Callout -->
    <g transform="translate(0, 318)">
      <rect x="0" y="0" width="720" height="24" rx="4" fill="#131D31" />
      <text x="12" y="16" fill="#FFFFFF" fill-opacity="0.75" font-size="10" class="font-body">Taxonomy note: ML is a branch of AI; Deep Learning is a subset of ML; Generative AI describes content-creation capabilities.</text>
    </g>
  </g>

  <!-- ========================================== -->
  <!-- SECTION 4: AI IN EVERYDAY LIFE (1190 - 1420)-->
  <!-- ========================================== -->
  <g transform="translate(40, 1190)">
    <!-- Section Header -->
    <rect x="0" y="0" width="28" height="28" rx="6" fill="#3867FF" fill-opacity="0.2" />
    <text x="9" y="19" fill="#48D9D0" font-size="13" class="font-heading">04</text>
    <text x="38" y="20" fill="#FFFFFF" font-size="18" letter-spacing="0.5" class="font-heading">AI IN EVERYDAY LIFE</text>
    <text x="38" y="38" fill="#FFFFFF" fill-opacity="0.65" font-size="11.5" class="font-body">Everyday assistive applications across four essential industries (illustrative examples).</text>

    <!-- 2x2 Grid Layout -->
    <!-- Card 1: Education (Top-Left) -->
    <g transform="translate(0, 50)">
      <rect x="0" y="0" width="350" height="74" rx="8" fill="url(#cardGrad)" stroke="#3867FF" stroke-width="0.8" stroke-opacity="0.3" />
      <circle cx="28" cy="37" r="15" fill="#3867FF" fill-opacity="0.2" />
      <!-- Book/Grad Icon -->
      <path d="M 20 34 L 28 30 L 36 34 L 28 38 Z M 23 37 L 23 42 C 23 44 28 45 28 45 C 28 45 33 44 33 42 L 33 37" stroke="#48D9D0" stroke-width="1.2" fill="none" />
      <text x="52" y="28" fill="#48D9D0" font-size="12.5" class="font-heading">EDUCATION</text>
      <text x="52" y="45" fill="#FFFFFF" fill-opacity="0.9" font-size="11" class="font-body">Personalized learning support and adaptive</text>
      <text x="52" y="59" fill="#FFFFFF" fill-opacity="0.9" font-size="11" class="font-body">educational assistance tailored to pacing.</text>
    </g>

    <!-- Card 2: Healthcare (Top-Right) -->
    <g transform="translate(370, 50)">
      <rect x="0" y="0" width="350" height="74" rx="8" fill="url(#cardGrad)" stroke="#3867FF" stroke-width="0.8" stroke-opacity="0.3" />
      <circle cx="28" cy="37" r="15" fill="#3867FF" fill-opacity="0.2" />
      <!-- Medical Cross Icon -->
      <path d="M 26 30 L 30 30 L 30 35 L 35 35 L 35 39 L 30 39 L 30 44 L 26 44 L 26 39 L 21 39 L 21 35 L 26 35 Z" fill="#48D9D0" />
      <text x="52" y="28" fill="#48D9D0" font-size="12.5" class="font-heading">HEALTHCARE</text>
      <text x="52" y="45" fill="#FFFFFF" fill-opacity="0.9" font-size="11" class="font-body">Assisting doctors with medical scan analysis</text>
      <text x="52" y="59" fill="#FFFFFF" fill-opacity="0.9" font-size="11" class="font-body">and diagnostic pattern detection.</text>
    </g>

    <!-- Card 3: Finance (Bottom-Left) -->
    <g transform="translate(0, 132)">
      <rect x="0" y="0" width="350" height="74" rx="8" fill="url(#cardGrad)" stroke="#3867FF" stroke-width="0.8" stroke-opacity="0.3" />
      <circle cx="28" cy="37" r="15" fill="#3867FF" fill-opacity="0.2" />
      <!-- Card / Shield Icon -->
      <path d="M 20 31 L 36 31 L 36 43 L 20 43 Z M 20 35 L 36 35" stroke="#48D9D0" stroke-width="1.2" fill="none" />
      <text x="52" y="28" fill="#48D9D0" font-size="12.5" class="font-heading">FINANCE</text>
      <text x="52" y="45" fill="#FFFFFF" fill-opacity="0.9" font-size="11" class="font-body">Real-time fraud detection, risk analysis,</text>
      <text x="52" y="59" fill="#FFFFFF" fill-opacity="0.9" font-size="11" class="font-body">and anomaly monitoring on payments.</text>
    </g>

    <!-- Card 4: Transport (Bottom-Right) -->
    <g transform="translate(370, 132)">
      <rect x="0" y="0" width="350" height="74" rx="8" fill="url(#cardGrad)" stroke="#3867FF" stroke-width="0.8" stroke-opacity="0.3" />
      <circle cx="28" cy="37" r="15" fill="#3867FF" fill-opacity="0.2" />
      <!-- Car / Route Icon -->
      <path d="M 22 38 L 24 33 L 32 33 L 34 38 Z M 20 38 L 36 38 L 36 43 L 20 43 Z" stroke="#48D9D0" stroke-width="1.2" fill="none" />
      <circle cx="24" cy="43" r="1.5" fill="#48D9D0" />
      <circle cx="32" cy="43" r="1.5" fill="#48D9D0" />
      <text x="52" y="28" fill="#48D9D0" font-size="12.5" class="font-heading">TRANSPORT</text>
      <text x="52" y="45" fill="#FFFFFF" fill-opacity="0.9" font-size="11" class="font-body">Route estimation, congestion forecasting,</text>
      <text x="52" y="59" fill="#FFFFFF" fill-opacity="0.9" font-size="11" class="font-body">and driver-assistance alert systems.</text>
    </g>
  </g>

  <!-- ========================================== -->
  <!-- SECTION 5: TWO SIDES OF AI (1435 - 1695)   -->
  <!-- ========================================== -->
  <g transform="translate(40, 1435)">
    <!-- Section Header -->
    <rect x="0" y="0" width="28" height="28" rx="6" fill="#3867FF" fill-opacity="0.2" />
    <text x="9" y="19" fill="#48D9D0" font-size="13" class="font-heading">05</text>
    <text x="38" y="20" fill="#FFFFFF" font-size="18" letter-spacing="0.5" class="font-heading">TWO SIDES OF AI: BENEFITS AND CHALLENGES</text>
    <text x="38" y="38" fill="#FFFFFF" fill-opacity="0.65" font-size="11.5" class="font-body">AI does not eliminate error or ensure perfection; consider both aspects with equal rigor.</text>

    <!-- Side-by-Side Comparison Columns -->
    <!-- Left Column: Potential Benefits -->
    <g transform="translate(0, 50)">
      <rect x="0" y="0" width="350" height="190" rx="8" fill="#131E33" stroke="#48D9D0" stroke-width="1" stroke-opacity="0.4" />
      
      <!-- Column Header -->
      <rect x="0" y="0" width="350" height="34" rx="8" fill="#3867FF" fill-opacity="0.15" />
      <circle cx="22" cy="17" r="7" fill="#48D9D0" />
      <path d="M 19 17 L 21 19 L 25 15" stroke="#101828" stroke-width="1.5" fill="none" stroke-linecap="round" />
      <text x="36" y="22" fill="#48D9D0" font-size="12" class="font-heading">POTENTIAL BENEFITS</text>

      <!-- Benefit Bullets -->
      <g transform="translate(16, 48)">
        <circle cx="4" cy="7" r="3" fill="#48D9D0" />
        <text x="14" y="10" fill="#FFFFFF" font-size="11.2" class="font-body">Helps analyze large amounts of information.</text>
      </g>
      <g transform="translate(16, 82)">
        <circle cx="4" cy="7" r="3" fill="#48D9D0" />
        <text x="14" y="10" fill="#FFFFFF" font-size="11.2" class="font-body">Can automate repetitive, mechanical tasks.</text>
      </g>
      <g transform="translate(16, 116)">
        <circle cx="4" cy="7" r="3" fill="#48D9D0" />
        <text x="14" y="10" fill="#FFFFFF" font-size="11.2" class="font-body">Can support faster predictions and decisions.</text>
      </g>
      <g transform="translate(16, 150)">
        <circle cx="4" cy="7" r="3" fill="#48D9D0" />
        <text x="14" y="10" fill="#FFFFFF" font-size="11.2" class="font-body">Can assist with learning and creative work.</text>
      </g>
    </g>

    <!-- Right Column: Important Challenges -->
    <g transform="translate(370, 50)">
      <rect x="0" y="0" width="350" height="190" rx="8" fill="#131E33" stroke="#3867FF" stroke-width="1" stroke-opacity="0.4" />
      
      <!-- Column Header -->
      <rect x="0" y="0" width="350" height="34" rx="8" fill="#3867FF" fill-opacity="0.15" />
      <circle cx="22" cy="17" r="7" fill="#3867FF" />
      <path d="M 22 13 L 22 18 M 22 21 L 22 22" stroke="#FFFFFF" stroke-width="1.5" stroke-linecap="round" />
      <text x="36" y="22" fill="#FFFFFF" font-size="12" class="font-heading">IMPORTANT CHALLENGES</text>

      <!-- Challenge Bullets -->
      <g transform="translate(16, 48)">
        <circle cx="4" cy="7" r="3" fill="#3867FF" />
        <text x="14" y="10" fill="#FFFFFF" fill-opacity="0.9" font-size="11.2" class="font-body">Biased data can lead to unfair outcomes.</text>
      </g>
      <g transform="translate(16, 82)">
        <circle cx="4" cy="7" r="3" fill="#3867FF" />
        <text x="14" y="10" fill="#FFFFFF" fill-opacity="0.9" font-size="11.2" class="font-body">Personal data may be exposed or misused.</text>
      </g>
      <g transform="translate(16, 116)">
        <circle cx="4" cy="7" r="3" fill="#3867FF" />
        <text x="14" y="10" fill="#FFFFFF" fill-opacity="0.9" font-size="11.2" class="font-body">Outputs may be inaccurate or misleading.</text>
      </g>
      <g transform="translate(16, 150)">
        <circle cx="4" cy="7" r="3" fill="#3867FF" />
        <text x="14" y="10" fill="#FFFFFF" fill-opacity="0.9" font-size="11.2" class="font-body">Complex decisions may be difficult to explain.</text>
      </g>
    </g>
  </g>

  <!-- ========================================== -->
  <!-- SECTION 6: RESPONSIBLE AI (1705 - 1880)    -->
  <!-- ========================================== -->
  <g transform="translate(40, 1705)">
    <!-- Section Header -->
    <rect x="0" y="0" width="28" height="28" rx="6" fill="#3867FF" fill-opacity="0.2" />
    <text x="9" y="19" fill="#48D9D0" font-size="13" class="font-heading">06</text>
    <text x="38" y="20" fill="#FFFFFF" font-size="18" letter-spacing="0.5" class="font-heading">USE AI WISELY: RESPONSIBLE PRINCIPLES</text>

    <!-- 4 Principles Container -->
    <g transform="translate(0, 36)">
      <rect x="0" y="0" width="720" height="124" rx="8" fill="url(#cardGrad)" stroke="#3867FF" stroke-width="1" stroke-opacity="0.3" />

      <!-- Row 1: Check Output -->
      <g transform="translate(16, 12)">
        <circle cx="12" cy="12" r="10" fill="#3867FF" fill-opacity="0.25" />
        <path d="M 8 12 L 11 15 L 16 9" stroke="#48D9D0" stroke-width="1.5" fill="none" stroke-linecap="round" />
        <text x="30" y="15" fill="#48D9D0" font-size="11.5" class="font-heading">CHECK THE OUTPUT</text>
        <text x="175" y="15" fill="#FFFFFF" fill-opacity="0.88" font-size="11.5" class="font-body">— Verify important claims against credible primary sources.</text>
      </g>

      <!-- Row 2: Protect Privacy -->
      <g transform="translate(16, 40)">
        <circle cx="12" cy="12" r="10" fill="#3867FF" fill-opacity="0.25" />
        <path d="M 8 12 L 11 15 L 16 9" stroke="#48D9D0" stroke-width="1.5" fill="none" stroke-linecap="round" />
        <text x="30" y="15" fill="#48D9D0" font-size="11.5" class="font-heading">PROTECT PRIVACY</text>
        <text x="175" y="15" fill="#FFFFFF" fill-opacity="0.88" font-size="11.5" class="font-body">— Avoid sharing sensitive personal data unnecessarily.</text>
      </g>

      <!-- Row 3: Look for Bias -->
      <g transform="translate(16, 68)">
        <circle cx="12" cy="12" r="10" fill="#3867FF" fill-opacity="0.25" />
        <path d="M 8 12 L 11 15 L 16 9" stroke="#48D9D0" stroke-width="1.5" fill="none" stroke-linecap="round" />
        <text x="30" y="15" fill="#48D9D0" font-size="11.5" class="font-heading">LOOK FOR BIAS</text>
        <text x="175" y="15" fill="#FFFFFF" fill-opacity="0.88" font-size="11.5" class="font-body">— Consider whether the result could be unfair or one-sided.</text>
      </g>

      <!-- Row 4: Keep Humans Involved -->
      <g transform="translate(16, 96)">
        <circle cx="12" cy="12" r="10" fill="#3867FF" fill-opacity="0.25" />
        <path d="M 8 12 L 11 15 L 16 9" stroke="#48D9D0" stroke-width="1.5" fill="none" stroke-linecap="round" />
        <text x="30" y="15" fill="#48D9D0" font-size="11.5" class="font-heading">KEEP HUMANS INVOLVED</text>
        <text x="175" y="15" fill="#FFFFFF" fill-opacity="0.88" font-size="11.5" class="font-body">— Use human oversight for high-stakes, consequential decisions.</text>
      </g>
    </g>
  </g>

  <!-- ========================================== -->
  <!-- SECTION 7: FINAL TAKEAWAY & FOOTER (1880-) -->
  <!-- ========================================== -->
  <g transform="translate(40, 1880)">
    <!-- Decorative Separator -->
    <rect x="0" y="0" width="720" height="2" fill="url(#blueGlow)" />

    <!-- Takeaway Headline -->
    <text x="360" y="24" text-anchor="middle" fill="#FFFFFF" font-size="15" letter-spacing="0.5" class="font-title">AI IS A TOOL. HUMAN JUDGMENT STILL MATTERS.</text>
    
    <!-- Takeaway Subtext -->
    <text x="360" y="42" text-anchor="middle" fill="#48D9D0" font-size="12" class="font-medium">Understand the data · Question the output · Use intelligence responsibly.</text>

    <!-- Source Citations Box -->
    <g transform="translate(0, 54)">
      <rect x="0" y="0" width="720" height="32" rx="4" fill="#0D1422" />
      <text x="10" y="15" fill="#FFFFFF" fill-opacity="0.6" font-size="8.8" class="font-body">Sources: NIST CSRC AI Glossary · NIST SP 1270 Bias in AI · UNESCO AI &amp; Education Guidance · U.S. FDA Digital Health Glossary</text>
      <text x="10" y="26" fill="#FFFFFF" fill-opacity="0.6" font-size="8.8" class="font-body">Designed by Neha Vinod Borkar · Oasis Infobyte Graphics Design Internship · Task 4 (Infographic)</text>
    </g>
  </g>

</svg>`;
};

// Main Execution
const outputDir = path.join(process.cwd(), 'OIBSIP', 'Graphics-Design', 'Task-4-Infographic');
const screenshotsDir = path.join(outputDir, 'screenshots');

if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}
if (!fs.existsSync(screenshotsDir)) {
  fs.mkdirSync(screenshotsDir, { recursive: true });
}

const svgContent = generateInfographicSvg();

// 1. Write the Master SVG
const svgPath = path.join(outputDir, 'AI-Unpacked-Infographic.svg');
fs.writeFileSync(svgPath, svgContent, 'utf-8');
console.log('Saved SVG to:', svgPath);

// 2. Render 800x2000 PNG (1x)
const resvg1x = new Resvg(svgContent, {
  fitTo: { mode: 'width', value: 800 },
});
const pngData1x = resvg1x.render();
const pngBuffer1x = pngData1x.asPng();

const pngPath1x = path.join(outputDir, 'AI-Unpacked-Infographic.png');
fs.writeFileSync(pngPath1x, pngBuffer1x);
console.log(`Saved 800x2000 PNG to: ${pngPath1x} (${pngBuffer1x.length} bytes)`);

// 3. Render 1600x4000 High-Res PNG (2x - 300 DPI target)
const resvg2x = new Resvg(svgContent, {
  fitTo: { mode: 'width', value: 1600 },
});
const pngData2x = resvg2x.render();
const pngBuffer2x = pngData2x.asPng();

const pngPath2x = path.join(outputDir, 'AI-Unpacked-Infographic@2x.png');
fs.writeFileSync(pngPath2x, pngBuffer2x);
console.log(`Saved 1600x4000 PNG to: ${pngPath2x} (${pngBuffer2x.length} bytes)`);

// 4. Save Preview Screenshot (for README)
const previewPath = path.join(screenshotsDir, 'infographic-preview.png');
fs.writeFileSync(previewPath, pngBuffer1x);
console.log('Saved preview screenshot to:', previewPath);
