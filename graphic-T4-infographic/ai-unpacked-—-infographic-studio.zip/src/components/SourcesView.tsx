import React from 'react';
import { ExternalLink, ShieldCheck, BookOpen } from 'lucide-react';
import { SOURCES_LIST } from '../data/infographicData';

export const SourcesView: React.FC = () => {
  return (
    <div className="max-w-5xl mx-auto py-8 px-4 sm:px-6 space-y-8">
      {/* Header */}
      <div className="bg-[#101828] border border-slate-800 rounded-xl p-6 shadow-xl">
        <div className="flex items-center gap-2 text-xs text-[#48D9D0] font-heading font-semibold uppercase tracking-wider mb-1">
          <ShieldCheck className="w-4 h-4 text-[#48D9D0]" />
          <span>Scientific Grounding & Fact-Checking</span>
        </div>
        <h2 className="text-2xl font-bold text-white font-heading tracking-tight">
          Authoritative Sources & Citation Standards
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Every statement, diagram, and principle in <em>AI Unpacked</em> is grounded in peer-reviewed scientific publications and international standards (NIST, UNESCO, FDA).
        </p>
      </div>

      {/* 4 Primary Sources Cards */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
          Primary Cited References
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {SOURCES_LIST.map((source) => (
            <div
              key={source.id}
              className="bg-[#101828] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <span className="text-[11px] font-mono text-[#48D9D0] uppercase tracking-wide">
                    {source.organization}
                  </span>
                  <a
                    href={source.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-slate-400 hover:text-white flex items-center gap-1 text-[11px]"
                  >
                    <span>Visit Source</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                <h4 className="text-base font-bold text-white font-heading mb-1">
                  {source.documentTitle}
                </h4>

                <p className="text-xs text-slate-300 leading-relaxed mb-3">
                  {source.relevance}
                </p>

                {/* Verified Quotes */}
                <div className="bg-[#162238] p-3 rounded-lg border border-slate-800 space-y-2">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Verified Excerpt:
                  </span>
                  {source.verifiedQuotes.map((q, idx) => (
                    <blockquote
                      key={idx}
                      className="text-[11.5px] italic text-slate-200 border-l-2 border-[#3867FF] pl-2.5 leading-snug"
                    >
                      "{q}"
                    </blockquote>
                  ))}
                </div>
              </div>

              {/* Section Application Tags */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center gap-1.5 flex-wrap">
                <span className="text-[10px] text-slate-400">Applied to:</span>
                {source.appliedToSections.map((sec, i) => (
                  <span
                    key={i}
                    className="text-[10px] bg-[#162238] text-[#48D9D0] px-2 py-0.5 rounded border border-[#3867FF]/30 font-medium"
                  >
                    {sec}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Fact-Check Audit Matrix */}
      <div className="bg-[#101828] border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
        <div className="flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-[#48D9D0]" />
          <h3 className="text-base font-bold text-white font-heading">
            Fact-Checking & Non-Hallucination Audit Matrix
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[11px] uppercase bg-[#162238] text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Infographic Claim</th>
                <th className="py-2.5 px-3">Audit Status</th>
                <th className="py-2.5 px-3">Evidence & Rationale</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-[11.5px]">
              <tr className="hover:bg-[#162238]/30">
                <td className="py-2.5 px-3 font-medium text-white">
                  "AI refers to machine-based systems generating predictions, recommendations, or decisions..."
                </td>
                <td className="py-2.5 px-3">
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Verified
                  </span>
                </td>
                <td className="py-2.5 px-3 text-slate-400">
                  Verbatim alignment with NIST CSRC definition and OECD recommendation on AI.
                </td>
              </tr>
              <tr className="hover:bg-[#162238]/30">
                <td className="py-2.5 px-3 font-medium text-white">
                  "Four-Step Flow: Collect Data → Learn Patterns → Generate Output → Evaluate & Improve"
                </td>
                <td className="py-2.5 px-3">
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Verified (Educational)
                  </span>
                </td>
                <td className="py-2.5 px-3 text-slate-400">
                  Standard supervised learning pipeline; includes explicit disclaimer on non-universality.
                </td>
              </tr>
              <tr className="hover:bg-[#162238]/30">
                <td className="py-2.5 px-3 font-medium text-white">
                  "ML is a branch of AI; Deep Learning is a subset of ML; GenAI describes content generation"
                </td>
                <td className="py-2.5 px-3">
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Verified Taxonomy
                  </span>
                </td>
                <td className="py-2.5 px-3 text-slate-400">
                  Conforms strictly to FDA Digital Health Glossary and NIST taxonomic hierarchies.
                </td>
              </tr>
              <tr className="hover:bg-[#162238]/30">
                <td className="py-2.5 px-3 font-medium text-white">
                  "Two Sides: Benefits vs Challenges (Bias, Privacy, Misinformation, Opacity)"
                </td>
                <td className="py-2.5 px-3">
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Verified
                  </span>
                </td>
                <td className="py-2.5 px-3 text-slate-400">
                  Balanced presentation backed by NIST SP 1270. Eliminates exaggerated claims of 100% accuracy.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
