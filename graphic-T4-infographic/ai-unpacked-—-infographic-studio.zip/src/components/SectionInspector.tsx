import React from 'react';
import { X, ExternalLink, Sliders, CheckCircle2, ChevronRight, ChevronLeft } from 'lucide-react';
import { InfographicSection } from '../types/infographic';
import { SECTIONS } from '../data/infographicData';

interface SectionInspectorProps {
  section: InfographicSection | null;
  onClose: () => void;
  onSelectSection: (section: InfographicSection) => void;
}

export const SectionInspector: React.FC<SectionInspectorProps> = ({
  section,
  onClose,
  onSelectSection,
}) => {
  if (!section) return null;

  const currentIndex = SECTIONS.findIndex((s) => s.id === section.id);
  const prevSection = currentIndex > 0 ? SECTIONS[currentIndex - 1] : null;
  const nextSection = currentIndex < SECTIONS.length - 1 ? SECTIONS[currentIndex + 1] : null;

  return (
    <div className="bg-[#101828] border border-slate-800 rounded-xl p-5 shadow-2xl flex flex-col h-full max-h-[calc(100vh-140px)] overflow-hidden">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#48D9D0] font-heading font-semibold uppercase tracking-wider mb-1">
            <span>Section {section.number}</span>
            <span>·</span>
            <span>Y: {section.yRange.start}px – {section.yRange.end}px</span>
          </div>
          <h3 className="text-lg font-bold text-white font-heading tracking-tight">
            {section.title}
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">{section.subtitle}</p>
        </div>

        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          title="Close details"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto space-y-5 py-4 pr-1 text-sm text-slate-200">
        {/* Summary */}
        <div>
          <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Overview & Core Objective
          </h4>
          <p className="text-xs leading-relaxed text-slate-300 bg-[#162238] p-3 rounded-lg border border-slate-800">
            {section.summary}
          </p>
        </div>

        {/* Key Takeaways */}
        <div>
          <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Educational Key Takeaways
          </h4>
          <ul className="space-y-2">
            {section.keyTakeaways.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-200">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#48D9D0] shrink-0 mt-0.5" />
                <span className="leading-snug">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Canva Layout Blueprint for this section */}
        <div className="bg-[#121c2d] p-3.5 rounded-lg border border-[#3867FF]/30 space-y-2.5">
          <div className="flex items-center gap-2 text-[#48D9D0] font-semibold text-xs">
            <Sliders className="w-3.5 h-3.5 text-[#3867FF]" />
            <span>Canva Coordinate Blueprint</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div>
              <span className="text-slate-400 block">Position:</span>
              <span className="font-mono text-white">{section.canvaSpecs.coordinates}</span>
            </div>
            <div>
              <span className="text-slate-400 block">Height:</span>
              <span className="font-mono text-white">{section.canvaSpecs.height}</span>
            </div>
          </div>

          <div>
            <span className="text-slate-400 text-[11px] block">Typography:</span>
            <span className="text-[11px] text-slate-200 font-mono">{section.canvaSpecs.fonts}</span>
          </div>

          <div>
            <span className="text-slate-400 text-[11px] block mb-1">Color Palette Used:</span>
            <div className="flex items-center gap-1.5">
              {section.canvaSpecs.colors.map((hex, i) => (
                <div key={i} className="flex items-center gap-1 bg-[#162238] px-1.5 py-0.5 rounded border border-slate-800 text-[10px]">
                  <span className="w-2.5 h-2.5 rounded-full border border-white/20" style={{ backgroundColor: hex }} />
                  <span className="font-mono text-slate-300">{hex}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <span className="text-slate-400 text-[11px] block mb-1">Recommended Canva Icons:</span>
            <div className="flex flex-wrap gap-1">
              {section.canvaSpecs.iconKeywords.map((kw, i) => (
                <span key={i} className="text-[10px] bg-[#162238] text-[#48D9D0] px-2 py-0.5 rounded border border-[#3867FF]/20">
                  "{kw}"
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Source Citations */}
        {section.sourceCitations.length > 0 && (
          <div>
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Verified Source Grounding
            </h4>
            <div className="space-y-2">
              {section.sourceCitations.map((cite, idx) => (
                <div key={idx} className="bg-[#141e30] p-2.5 rounded-lg border border-slate-800 text-xs">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-white">{cite.source}</span>
                    <a
                      href={cite.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#48D9D0] hover:underline flex items-center gap-1 text-[11px]"
                    >
                      <span>Open Link</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                  <p className="text-slate-400 text-[11px]">{cite.detail}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer Navigation between sections */}
      <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
        <button
          onClick={() => prevSection && onSelectSection(prevSection)}
          disabled={!prevSection}
          className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
            prevSection
              ? 'bg-[#162238] text-slate-200 hover:text-white hover:bg-[#1f2f4c]'
              : 'opacity-40 cursor-not-allowed text-slate-500'
          }`}
        >
          <ChevronLeft className="w-3.5 h-3.5" />
          <span>Previous</span>
        </button>

        <span className="text-[11px] text-slate-500 font-mono">
          {currentIndex + 1} of {SECTIONS.length}
        </span>

        <button
          onClick={() => nextSection && onSelectSection(nextSection)}
          disabled={!nextSection}
          className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
            nextSection
              ? 'bg-[#162238] text-slate-200 hover:text-white hover:bg-[#1f2f4c]'
              : 'opacity-40 cursor-not-allowed text-slate-500'
          }`}
        >
          <span>Next</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
