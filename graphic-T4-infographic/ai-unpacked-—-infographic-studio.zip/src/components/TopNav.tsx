import React from 'react';
import { Download, Sliders, BookOpen, FolderArchive } from 'lucide-react';

export type ActiveTab = 'canvas' | 'canva-guide' | 'sources' | 'files';

interface TopNavProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  onOpenExport: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  activeTab,
  onTabChange,
  onOpenExport,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#0b101b]/95 backdrop-blur-md border-b border-slate-800/80 px-6 py-3.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single Element) */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onTabChange('canvas')}
            className="text-left group flex items-center gap-2.5 focus:outline-none"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#3867FF] to-[#48D9D0] flex items-center justify-center font-bold text-white text-xs shadow-md shadow-[#3867FF]/20 group-hover:scale-105 transition-transform">
              AI
            </div>
            <div>
              <span className="text-base font-bold tracking-tight text-white font-heading block whitespace-nowrap">
                AI UNPACKED
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links (Single Line, 4 Tabs) */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          <button
            onClick={() => onTabChange('canvas')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 flex items-center gap-1.5 ${
              activeTab === 'canvas'
                ? 'text-[#48D9D0] font-semibold border-b-2 border-[#48D9D0]'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <span>Infographic Studio</span>
          </button>

          <button
            onClick={() => onTabChange('canva-guide')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 flex items-center gap-1.5 ${
              activeTab === 'canva-guide'
                ? 'text-[#48D9D0] font-semibold border-b-2 border-[#48D9D0]'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Canva Blueprint</span>
          </button>

          <button
            onClick={() => onTabChange('sources')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 flex items-center gap-1.5 ${
              activeTab === 'sources'
                ? 'text-[#48D9D0] font-semibold border-b-2 border-[#48D9D0]'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Fact-Check & Sources</span>
          </button>

          <button
            onClick={() => onTabChange('files')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 flex items-center gap-1.5 ${
              activeTab === 'files'
                ? 'text-[#48D9D0] font-semibold border-b-2 border-[#48D9D0]'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <FolderArchive className="w-3.5 h-3.5" />
            <span>Submission Files</span>
          </button>
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenExport}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-[#3867FF] to-[#254bdb] rounded-lg hover:from-[#4370ff] hover:to-[#2e55e8] active:scale-95 transition-all shadow-md shadow-[#3867FF]/25 whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5 text-[#48D9D0]" />
            <span>Export PNG (800×2000)</span>
          </button>
        </div>
      </div>
    </header>
  );
};
