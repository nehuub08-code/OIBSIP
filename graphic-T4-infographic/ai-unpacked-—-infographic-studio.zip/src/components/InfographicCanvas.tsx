import React from 'react';
import { SECTIONS } from '../data/infographicData';
import { InfographicSection } from '../types/infographic';

interface InfographicCanvasProps {
  selectedSection: InfographicSection | null;
  onSelectSection: (section: InfographicSection) => void;
  zoomLevel: number;
}

export const InfographicCanvas: React.FC<InfographicCanvasProps> = ({
  selectedSection,
  onSelectSection,
  zoomLevel,
}) => {
  const canvasWidth = 800;
  const canvasHeight = 2000;

  return (
    <div
      className="relative transition-transform duration-200 origin-top shadow-2xl rounded-lg overflow-hidden border border-slate-800 bg-[#101828]"
      style={{
        width: `${canvasWidth * zoomLevel}px`,
        height: `${canvasHeight * zoomLevel}px`,
      }}
    >
      {/* Interactive Clickable Hotspots overlayed on SVG coordinates */}
      <div
        className="absolute inset-0 pointer-events-none z-10"
        style={{ width: `${canvasWidth}px`, height: `${canvasHeight}px`, transform: `scale(${zoomLevel})`, transformOrigin: 'top left' }}
      >
        {SECTIONS.map((section) => {
          const isSelected = selectedSection?.id === section.id;
          const top = section.yRange.start;
          const height = section.yRange.end - section.yRange.start;

          return (
            <div
              key={section.id}
              onClick={() => onSelectSection(section)}
              className={`absolute left-[30px] w-[740px] pointer-events-auto cursor-pointer rounded-lg transition-all duration-200 group ${
                isSelected
                  ? 'ring-2 ring-[#48D9D0] bg-[#3867FF]/10 shadow-[0_0_20px_rgba(72,217,208,0.25)]'
                  : 'hover:ring-1 hover:ring-[#3867FF]/60 hover:bg-[#3867FF]/5'
              }`}
              style={{
                top: `${top}px`,
                height: `${height}px`,
              }}
              title={`Click to inspect ${section.title}`}
            >
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#101828]/90 text-[10px] font-medium text-[#48D9D0] border border-[#3867FF]/40 shadow-sm">
                <span>Inspect Section</span>
                <span>→</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* SVG Canvas Content (Exact 800 x 2000 vector) */}
      <div
        style={{
          width: `${canvasWidth}px`,
          height: `${canvasHeight}px`,
          transform: `scale(${zoomLevel})`,
          transformOrigin: 'top left',
        }}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox={`0 0 ${canvasWidth} ${canvasHeight}`}
          width={canvasWidth}
          height={canvasHeight}
          className="w-full h-full block select-none"
        >
          <defs>
            <style>{`
              @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@600;700&display=swap');
              .svg-title { font-family: 'Space Grotesk', system-ui, sans-serif; font-weight: 700; }
              .svg-heading { font-family: 'Space Grotesk', system-ui, sans-serif; font-weight: 600; }
              .svg-body { font-family: 'Inter', system-ui, sans-serif; font-weight: 400; }
              .svg-medium { font-family: 'Inter', system-ui, sans-serif; font-weight: 500; }
              .svg-bold { font-family: 'Inter', system-ui, sans-serif; font-weight: 700; }
            `}</style>

            <pattern id="gridPatternCanvas" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#3867FF" strokeWidth="0.75" strokeOpacity="0.08" />
            </pattern>

            <linearGradient id="cardGradCanvas" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#162238" />
              <stop offset="100%" stopColor="#121B2C" />
            </linearGradient>

            <linearGradient id="blueGlowCanvas" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3867FF" />
              <stop offset="100%" stopColor="#48D9D0" />
            </linearGradient>

            <linearGradient id="stepGradCanvas" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#192843" />
              <stop offset="100%" stopColor="#121C2F" />
            </linearGradient>
          </defs>

          {/* Background */}
          <rect width={canvasWidth} height={canvasHeight} fill="#101828" />
          <rect width={canvasWidth} height={canvasHeight} fill="url(#gridPatternCanvas)" />

          {/* ========================================== */}
          {/* HEADER SECTION (y: 36 - 180)               */}
          {/* ========================================== */}
          <g transform="translate(40, 36)">
            <rect x="0" y="0" width="720" height="3" rx="1.5" fill="url(#blueGlowCanvas)" />
            <text x="0" y="24" fill="#48D9D0" fontSize="11" letterSpacing="2.5" className="svg-heading">
              OASIS INFOBYTE INTERNSHIP · GRAPHICS DESIGN TASK 4
            </text>
            <text x="0" y="68" fill="#FFFFFF" fontSize="44" letterSpacing="-1" className="svg-title">
              AI UNPACKED
            </text>
            <text x="0" y="96" fill="#48D9D0" fontSize="18" letterSpacing="0.2" className="svg-heading">
              From Data to Intelligent Decisions
            </text>
            <text x="0" y="122" fill="#FFFFFF" fillOpacity="0.82" fontSize="13" className="svg-body">
              A beginner-friendly guide to how artificial intelligence works, where it operates, and why human judgment remains vital.
            </text>
            <line x1="0" y1="140" x2="720" y2="140" stroke="#3867FF" strokeWidth="1.5" strokeOpacity="0.4" />
          </g>

          {/* ========================================== */}
          {/* SECTION 1: WHAT IS AI? (y: 195 - 435)      */}
          {/* ========================================== */}
          <g transform="translate(40, 195)">
            <rect x="0" y="0" width="28" height="28" rx="6" fill="#3867FF" fillOpacity="0.2" />
            <text x="9" y="19" fill="#48D9D0" fontSize="13" className="svg-heading">01</text>
            <text x="38" y="20" fill="#FFFFFF" fontSize="18" letterSpacing="0.5" className="svg-heading">
              WHAT IS ARTIFICIAL INTELLIGENCE?
            </text>

            {/* NIST Definition */}
            <g transform="translate(0, 40)">
              <rect x="0" y="0" width="720" height="92" rx="10" fill="url(#cardGradCanvas)" stroke="#3867FF" strokeWidth="1" strokeOpacity="0.4" />
              <text x="24" y="26" fill="#48D9D0" fontSize="10.5" letterSpacing="1.5" className="svg-heading">
                OFFICIAL DEFINITION (NIST CSRC STANDARD)
              </text>
              <text x="24" y="48" fill="#FFFFFF" fontSize="13.5" className="svg-medium">
                "Artificial Intelligence (AI) refers to machine-based systems that can generate
              </text>
              <text x="24" y="68" fill="#FFFFFF" fontSize="13.5" className="svg-medium">
                predictions, recommendations, or decisions for defined objectives."
              </text>
            </g>

            {/* Visuals */}
            <g transform="translate(0, 142)">
              {/* Example */}
              <g transform="translate(0, 0)">
                <rect x="0" y="0" width="345" height="85" rx="8" fill="#131D31" stroke="#3867FF" strokeWidth="0.8" strokeOpacity="0.3" />
                <circle cx="28" cy="42" r="14" fill="#3867FF" fillOpacity="0.2" />
                <path d="M 28 34 C 24.5 34 22 36.5 22 40 C 22 44.5 28 50 28 50 C 28 50 34 44.5 34 40 C 34 36.5 31.5 34 28 34 Z M 28 41.5 C 27 41.5 26.2 40.7 26.2 39.8 C 26.2 38.8 27 38 28 38 C 29 38 29.8 38.8 29.8 39.8 C 29.8 40.7 29 41.5 28 41.5 Z" fill="#48D9D0" />
                <text x="52" y="30" fill="#48D9D0" fontSize="11" className="svg-heading">EVERYDAY EXAMPLE: NAVIGATION</text>
                <text x="52" y="48" fill="#FFFFFF" fillOpacity="0.9" fontSize="11.5" className="svg-body">A navigation app calculates a suitable route by</text>
                <text x="52" y="64" fill="#FFFFFF" fillOpacity="0.9" fontSize="11.5" className="svg-body">processing current speeds and historical delays.</text>
              </g>

              {/* Connected Node Diagram */}
              <g transform="translate(365, 0)">
                <rect x="0" y="0" width="355" height="85" rx="8" fill="#131D31" stroke="#48D9D0" strokeWidth="0.8" strokeOpacity="0.3" />
                <circle cx="178" cy="42" r="22" fill="#3867FF" fillOpacity="0.25" stroke="#48D9D0" strokeWidth="1.5" />
                <text x="178" y="46" textAnchor="middle" fill="#FFFFFF" fontSize="11" className="svg-heading">AI SYSTEM</text>

                <line x1="56" y1="42" x2="156" y2="42" stroke="#48D9D0" strokeWidth="1.5" strokeDasharray="3 3" />
                <circle cx="56" cy="42" r="15" fill="#162238" stroke="#3867FF" strokeWidth="1.2" />
                <text x="56" y="46" textAnchor="middle" fill="#48D9D0" fontSize="8.5" className="svg-heading">DATA</text>

                <line x1="200" y1="42" x2="298" y2="42" stroke="#48D9D0" strokeWidth="1.5" />
                <circle cx="298" cy="42" r="15" fill="#162238" stroke="#48D9D0" strokeWidth="1.2" />
                <text x="298" y="46" textAnchor="middle" fill="#FFFFFF" fontSize="8" className="svg-heading">DECISION</text>
              </g>
            </g>
          </g>

          {/* ========================================== */}
          {/* SECTION 2: HOW DOES AI WORK? (y: 450 - 815)*/}
          {/* ========================================== */}
          <g transform="translate(40, 450)">
            <rect x="0" y="0" width="28" height="28" rx="6" fill="#3867FF" fillOpacity="0.2" />
            <text x="9" y="19" fill="#48D9D0" fontSize="13" className="svg-heading">02</text>
            <text x="38" y="20" fill="#FFFFFF" fontSize="18" letterSpacing="0.5" className="svg-heading">
              FROM DATA TO DECISIONS: HOW AI WORKS
            </text>
            <text x="38" y="38" fill="#FFFFFF" fillOpacity="0.65" fontSize="11.5" className="svg-body">
              A simplified four-step educational process diagram connecting inputs to evaluated outcomes.
            </text>

            {/* STEP 1 */}
            <g transform="translate(0, 52)">
              <rect x="0" y="0" width="720" height="58" rx="8" fill="url(#stepGradCanvas)" stroke="#3867FF" strokeWidth="1" strokeOpacity="0.35" />
              <rect x="14" y="13" width="72" height="32" rx="6" fill="#3867FF" />
              <text x="50" y="33" textAnchor="middle" fill="#FFFFFF" fontSize="11" className="svg-heading">STEP 1</text>
              <text x="100" y="27" fill="#48D9D0" fontSize="13" className="svg-heading">COLLECT DATA</text>
              <text x="100" y="44" fill="#FFFFFF" fillOpacity="0.88" fontSize="11.5" className="svg-body">
                Text, images, numbers, audio, or sensor readings enter the system as raw material.
              </text>
              <circle cx="680" cy="29" r="16" fill="#3867FF" fillOpacity="0.2" />
              <path d="M 674 23 L 686 23 L 686 35 L 674 35 Z M 677 26 L 683 26 M 677 29 L 683 29 M 677 32 L 681 32" stroke="#48D9D0" strokeWidth="1.2" fill="none" />
            </g>

            {/* Arrow 1 */}
            <g transform="translate(360, 110)">
              <line x1="0" y1="0" x2="0" y2="12" stroke="#3867FF" strokeWidth="2" />
              <polygon points="-4,10 4,10 0,16" fill="#3867FF" />
            </g>

            {/* STEP 2 */}
            <g transform="translate(0, 126)">
              <rect x="0" y="0" width="720" height="58" rx="8" fill="url(#stepGradCanvas)" stroke="#3867FF" strokeWidth="1" strokeOpacity="0.35" />
              <rect x="14" y="13" width="72" height="32" rx="6" fill="#3867FF" />
              <text x="50" y="33" textAnchor="middle" fill="#FFFFFF" fontSize="11" className="svg-heading">STEP 2</text>
              <text x="100" y="27" fill="#48D9D0" fontSize="13" className="svg-heading">LEARN PATTERNS</text>
              <text x="100" y="44" fill="#FFFFFF" fillOpacity="0.88" fontSize="11.5" className="svg-body">
                A machine-learning model analyzes training examples to identify underlying statistical structures.
              </text>
              <circle cx="680" cy="29" r="16" fill="#3867FF" fillOpacity="0.2" />
              <circle cx="676" cy="27" r="2.5" fill="#48D9D0" />
              <circle cx="684" cy="25" r="2.5" fill="#48D9D0" />
              <circle cx="680" cy="33" r="2.5" fill="#48D9D0" />
              <line x1="676" y1="27" x2="684" y2="25" stroke="#48D9D0" strokeWidth="1" />
              <line x1="676" y1="27" x2="680" y2="33" stroke="#48D9D0" strokeWidth="1" />
              <line x1="684" y1="25" x2="680" y2="33" stroke="#48D9D0" strokeWidth="1" />
            </g>

            {/* Arrow 2 */}
            <g transform="translate(360, 184)">
              <line x1="0" y1="0" x2="0" y2="12" stroke="#3867FF" strokeWidth="2" />
              <polygon points="-4,10 4,10 0,16" fill="#3867FF" />
            </g>

            {/* STEP 3 */}
            <g transform="translate(0, 200)">
              <rect x="0" y="0" width="720" height="58" rx="8" fill="url(#stepGradCanvas)" stroke="#3867FF" strokeWidth="1" strokeOpacity="0.35" />
              <rect x="14" y="13" width="72" height="32" rx="6" fill="#3867FF" />
              <text x="50" y="33" textAnchor="middle" fill="#FFFFFF" fontSize="11" className="svg-heading">STEP 3</text>
              <text x="100" y="27" fill="#48D9D0" fontSize="13" className="svg-heading">GENERATE OUTPUT</text>
              <text x="100" y="44" fill="#FFFFFF" fillOpacity="0.88" fontSize="11.5" className="svg-body">
                The system produces a classification, numerical prediction, suggested choice, or generated content.
              </text>
              <circle cx="680" cy="29" r="16" fill="#3867FF" fillOpacity="0.2" />
              <path d="M 680 22 L 682 27 L 687 29 L 682 31 L 680 36 L 678 31 L 673 29 L 678 27 Z" fill="#48D9D0" />
            </g>

            {/* Arrow 3 */}
            <g transform="translate(360, 258)">
              <line x1="0" y1="0" x2="0" y2="12" stroke="#3867FF" strokeWidth="2" />
              <polygon points="-4,10 4,10 0,16" fill="#3867FF" />
            </g>

            {/* STEP 4 */}
            <g transform="translate(0, 274)">
              <rect x="0" y="0" width="720" height="58" rx="8" fill="url(#stepGradCanvas)" stroke="#3867FF" strokeWidth="1" strokeOpacity="0.35" />
              <rect x="14" y="13" width="72" height="32" rx="6" fill="#3867FF" />
              <text x="50" y="33" textAnchor="middle" fill="#FFFFFF" fontSize="11" className="svg-heading">STEP 4</text>
              <text x="100" y="27" fill="#48D9D0" fontSize="13" className="svg-heading">EVALUATE AND IMPROVE</text>
              <text x="100" y="44" fill="#FFFFFF" fillOpacity="0.88" fontSize="11.5" className="svg-body">
                People evaluate the results for accuracy, fairness, and safety, refining the model when appropriate.
              </text>
              <circle cx="680" cy="29" r="16" fill="#3867FF" fillOpacity="0.2" />
              <path d="M 675 29 L 678 33 L 686 24" stroke="#48D9D0" strokeWidth="1.8" fill="none" strokeLinecap="round" />
            </g>

            {/* Note */}
            <g transform="translate(0, 338)">
              <rect x="0" y="0" width="720" height="26" rx="5" fill="#131D31" />
              <text x="12" y="17" fill="#FFFFFF" fillOpacity="0.75" fontSize="10.5" className="svg-body">
                Accuracy note: Not all AI systems learn identically, and systems do not continuously self-improve without human guidance.
              </text>
            </g>
          </g>

          {/* ========================================== */}
          {/* SECTION 3: THE AI FAMILY (y: 835 - 1175)   */}
          {/* ========================================== */}
          <g transform="translate(40, 835)">
            <rect x="0" y="0" width="28" height="28" rx="6" fill="#3867FF" fillOpacity="0.2" />
            <text x="9" y="19" fill="#48D9D0" fontSize="13" className="svg-heading">03</text>
            <text x="38" y="20" fill="#FFFFFF" fontSize="18" letterSpacing="0.5" className="svg-heading">
              MEET THE AI FAMILY
            </text>
            <text x="38" y="38" fill="#FFFFFF" fillOpacity="0.65" fontSize="11.5" className="svg-body">
              Key categories that work together rather than existing as disconnected technologies.
            </text>

            {/* ML */}
            <g transform="translate(0, 50)">
              <rect x="0" y="0" width="720" height="82" rx="8" fill="url(#cardGradCanvas)" stroke="#3867FF" strokeWidth="1" strokeOpacity="0.3" />
              <g transform="translate(16, 14)">
                <rect x="0" y="0" width="80" height="54" rx="6" fill="#111B2C" stroke="#3867FF" strokeWidth="0.8" strokeOpacity="0.4" />
                <circle cx="15" cy="42" r="2.5" fill="#48D9D0" />
                <circle cx="28" cy="36" r="2.5" fill="#48D9D0" />
                <circle cx="42" cy="28" r="2.5" fill="#48D9D0" />
                <circle cx="56" cy="22" r="2.5" fill="#48D9D0" />
                <circle cx="68" cy="14" r="3" fill="#FFFFFF" stroke="#3867FF" strokeWidth="1.5" />
                <line x1="10" y1="46" x2="72" y2="12" stroke="#3867FF" strokeWidth="1.5" />
              </g>
              <text x="110" y="28" fill="#FFFFFF" fontSize="14" className="svg-heading">MACHINE LEARNING (ML)</text>
              <text x="110" y="48" fill="#FFFFFF" fillOpacity="0.85" fontSize="12" className="svg-body">
                Learns patterns from data to make predictions or identify patterns.
              </text>
              <text x="110" y="66" fill="#48D9D0" fontSize="11.5" className="svg-medium">
                Example: Predicting likely product demand based on past shopping trends.
              </text>
            </g>

            {/* DL */}
            <g transform="translate(0, 140)">
              <rect x="0" y="0" width="720" height="82" rx="8" fill="url(#cardGradCanvas)" stroke="#3867FF" strokeWidth="1" strokeOpacity="0.3" />
              <g transform="translate(16, 14)">
                <rect x="0" y="0" width="80" height="54" rx="6" fill="#111B2C" stroke="#3867FF" strokeWidth="0.8" strokeOpacity="0.4" />
                <circle cx="16" cy="17" r="3" fill="#48D9D0" />
                <circle cx="16" cy="37" r="3" fill="#48D9D0" />
                <circle cx="40" cy="14" r="3" fill="#3867FF" />
                <circle cx="40" cy="27" r="3" fill="#3867FF" />
                <circle cx="40" cy="40" r="3" fill="#3867FF" />
                <circle cx="64" cy="27" r="3.5" fill="#FFFFFF" stroke="#48D9D0" strokeWidth="1" />
                <line x1="16" y1="17" x2="40" y2="14" stroke="#48D9D0" strokeOpacity="0.4" strokeWidth="0.8" />
                <line x1="16" y1="17" x2="40" y2="27" stroke="#48D9D0" strokeOpacity="0.4" strokeWidth="0.8" />
                <line x1="16" y1="37" x2="40" y2="27" stroke="#48D9D0" strokeOpacity="0.4" strokeWidth="0.8" />
                <line x1="16" y1="37" x2="40" y2="40" stroke="#48D9D0" strokeOpacity="0.4" strokeWidth="0.8" />
                <line x1="40" y1="14" x2="64" y2="27" stroke="#3867FF" strokeOpacity="0.6" strokeWidth="0.8" />
                <line x1="40" y1="27" x2="64" y2="27" stroke="#3867FF" strokeOpacity="0.6" strokeWidth="0.8" />
                <line x1="40" y1="40" x2="64" y2="27" stroke="#3867FF" strokeOpacity="0.6" strokeWidth="0.8" />
              </g>
              <text x="110" y="28" fill="#FFFFFF" fontSize="14" className="svg-heading">DEEP LEARNING</text>
              <text x="110" y="48" fill="#FFFFFF" fillOpacity="0.85" fontSize="12" className="svg-body">
                Uses multi-layer neural networks to learn complex, layered patterns.
              </text>
              <text x="110" y="66" fill="#48D9D0" fontSize="11.5" className="svg-medium">
                Example: Recognizing objects, faces, or medical features in digital images.
              </text>
            </g>

            {/* GenAI */}
            <g transform="translate(0, 230)">
              <rect x="0" y="0" width="720" height="82" rx="8" fill="url(#cardGradCanvas)" stroke="#3867FF" strokeWidth="1" strokeOpacity="0.3" />
              <g transform="translate(16, 14)">
                <rect x="0" y="0" width="80" height="54" rx="6" fill="#111B2C" stroke="#3867FF" strokeWidth="0.8" strokeOpacity="0.4" />
                <rect x="22" y="10" width="28" height="34" rx="3" fill="#192843" stroke="#FFFFFF" strokeWidth="1" />
                <line x1="28" y1="18" x2="44" y2="18" stroke="#48D9D0" strokeWidth="1" />
                <line x1="28" y1="24" x2="44" y2="24" stroke="#FFFFFF" strokeOpacity="0.6" strokeWidth="1" />
                <line x1="28" y1="30" x2="38" y2="30" stroke="#FFFFFF" strokeOpacity="0.6" strokeWidth="1" />
                <path d="M 58 15 L 60 20 L 65 22 L 60 24 L 58 29 L 56 24 L 51 22 L 56 20 Z" fill="#48D9D0" />
              </g>
              <text x="110" y="28" fill="#FFFFFF" fontSize="14" className="svg-heading">GENERATIVE AI</text>
              <text x="110" y="48" fill="#FFFFFF" fillOpacity="0.85" fontSize="12" className="svg-body">
                Creates outputs such as text, images, audio, or code based on learned patterns.
              </text>
              <text x="110" y="66" fill="#48D9D0" fontSize="11.5" className="svg-medium">
                Example: Drafting a first version of an email, summary, or software function.
              </text>
            </g>

            <g transform="translate(0, 318)">
              <rect x="0" y="0" width="720" height="24" rx="4" fill="#131D31" />
              <text x="12" y="16" fill="#FFFFFF" fillOpacity="0.75" fontSize="10" className="svg-body">
                Taxonomy note: ML is a branch of AI; Deep Learning is a subset of ML; Generative AI describes content-creation capabilities.
              </text>
            </g>
          </g>

          {/* ========================================== */}
          {/* SECTION 4: AI IN EVERYDAY LIFE (1190 - 1420)*/}
          {/* ========================================== */}
          <g transform="translate(40, 1190)">
            <rect x="0" y="0" width="28" height="28" rx="6" fill="#3867FF" fillOpacity="0.2" />
            <text x="9" y="19" fill="#48D9D0" fontSize="13" className="svg-heading">04</text>
            <text x="38" y="20" fill="#FFFFFF" fontSize="18" letterSpacing="0.5" className="svg-heading">
              AI IN EVERYDAY LIFE
            </text>
            <text x="38" y="38" fill="#FFFFFF" fillOpacity="0.65" fontSize="11.5" className="svg-body">
              Everyday assistive applications across four essential industries (illustrative examples).
            </text>

            {/* 2x2 Grid */}
            <g transform="translate(0, 50)">
              <rect x="0" y="0" width="350" height="74" rx="8" fill="url(#cardGradCanvas)" stroke="#3867FF" strokeWidth="0.8" strokeOpacity="0.3" />
              <circle cx="28" cy="37" r="15" fill="#3867FF" fillOpacity="0.2" />
              <path d="M 20 34 L 28 30 L 36 34 L 28 38 Z M 23 37 L 23 42 C 23 44 28 45 28 45 C 28 45 33 44 33 42 L 33 37" stroke="#48D9D0" strokeWidth="1.2" fill="none" />
              <text x="52" y="28" fill="#48D9D0" fontSize="12.5" className="svg-heading">EDUCATION</text>
              <text x="52" y="45" fill="#FFFFFF" fillOpacity="0.9" fontSize="11" className="svg-body">Personalized learning support and adaptive</text>
              <text x="52" y="59" fill="#FFFFFF" fillOpacity="0.9" fontSize="11" className="svg-body">educational assistance tailored to pacing.</text>
            </g>

            <g transform="translate(370, 50)">
              <rect x="0" y="0" width="350" height="74" rx="8" fill="url(#cardGradCanvas)" stroke="#3867FF" strokeWidth="0.8" strokeOpacity="0.3" />
              <circle cx="28" cy="37" r="15" fill="#3867FF" fillOpacity="0.2" />
              <path d="M 26 30 L 30 30 L 30 35 L 35 35 L 35 39 L 30 39 L 30 44 L 26 44 L 26 39 L 21 39 L 21 35 L 26 35 Z" fill="#48D9D0" />
              <text x="52" y="28" fill="#48D9D0" fontSize="12.5" className="svg-heading">HEALTHCARE</text>
              <text x="52" y="45" fill="#FFFFFF" fillOpacity="0.9" fontSize="11" className="svg-body">Assisting doctors with medical scan analysis</text>
              <text x="52" y="59" fill="#FFFFFF" fillOpacity="0.9" fontSize="11" className="svg-body">and diagnostic pattern detection.</text>
            </g>

            <g transform="translate(0, 132)">
              <rect x="0" y="0" width="350" height="74" rx="8" fill="url(#cardGradCanvas)" stroke="#3867FF" strokeWidth="0.8" strokeOpacity="0.3" />
              <circle cx="28" cy="37" r="15" fill="#3867FF" fillOpacity="0.2" />
              <path d="M 20 31 L 36 31 L 36 43 L 20 43 Z M 20 35 L 36 35" stroke="#48D9D0" strokeWidth="1.2" fill="none" />
              <text x="52" y="28" fill="#48D9D0" fontSize="12.5" className="svg-heading">FINANCE</text>
              <text x="52" y="45" fill="#FFFFFF" fillOpacity="0.9" fontSize="11" className="svg-body">Real-time fraud detection, risk analysis,</text>
              <text x="52" y="59" fill="#FFFFFF" fillOpacity="0.9" fontSize="11" className="svg-body">and anomaly monitoring on payments.</text>
            </g>

            <g transform="translate(370, 132)">
              <rect x="0" y="0" width="350" height="74" rx="8" fill="url(#cardGradCanvas)" stroke="#3867FF" strokeWidth="0.8" strokeOpacity="0.3" />
              <circle cx="28" cy="37" r="15" fill="#3867FF" fillOpacity="0.2" />
              <path d="M 22 38 L 24 33 L 32 33 L 34 38 Z M 20 38 L 36 38 L 36 43 L 20 43 Z" stroke="#48D9D0" strokeWidth="1.2" fill="none" />
              <circle cx="24" cy="43" r="1.5" fill="#48D9D0" />
              <circle cx="32" cy="43" r="1.5" fill="#48D9D0" />
              <text x="52" y="28" fill="#48D9D0" fontSize="12.5" className="svg-heading">TRANSPORT</text>
              <text x="52" y="45" fill="#FFFFFF" fillOpacity="0.9" fontSize="11" className="svg-body">Route estimation, congestion forecasting,</text>
              <text x="52" y="59" fill="#FFFFFF" fillOpacity="0.9" fontSize="11" className="svg-body">and driver-assistance alert systems.</text>
            </g>
          </g>

          {/* ========================================== */}
          {/* SECTION 5: TWO SIDES OF AI (1435 - 1695)   */}
          {/* ========================================== */}
          <g transform="translate(40, 1435)">
            <rect x="0" y="0" width="28" height="28" rx="6" fill="#3867FF" fillOpacity="0.2" />
            <text x="9" y="19" fill="#48D9D0" fontSize="13" className="svg-heading">05</text>
            <text x="38" y="20" fill="#FFFFFF" fontSize="18" letterSpacing="0.5" className="svg-heading">
              TWO SIDES OF AI: BENEFITS AND CHALLENGES
            </text>
            <text x="38" y="38" fill="#FFFFFF" fillOpacity="0.65" fontSize="11.5" className="svg-body">
              AI does not eliminate error or ensure perfection; consider both aspects with equal rigor.
            </text>

            {/* Left: Benefits */}
            <g transform="translate(0, 50)">
              <rect x="0" y="0" width="350" height="190" rx="8" fill="#131E33" stroke="#48D9D0" strokeWidth="1" strokeOpacity="0.4" />
              <rect x="0" y="0" width="350" height="34" rx="8" fill="#3867FF" fillOpacity="0.15" />
              <circle cx="22" cy="17" r="7" fill="#48D9D0" />
              <path d="M 19 17 L 21 19 L 25 15" stroke="#101828" strokeWidth="1.5" fill="none" strokeLinecap="round" />
              <text x="36" y="22" fill="#48D9D0" fontSize="12" className="svg-heading">POTENTIAL BENEFITS</text>

              <g transform="translate(16, 48)">
                <circle cx="4" cy="7" r="3" fill="#48D9D0" />
                <text x="14" y="10" fill="#FFFFFF" fontSize="11.2" className="svg-body">Helps analyze large amounts of information.</text>
              </g>
              <g transform="translate(16, 82)">
                <circle cx="4" cy="7" r="3" fill="#48D9D0" />
                <text x="14" y="10" fill="#FFFFFF" fontSize="11.2" className="svg-body">Can automate repetitive, mechanical tasks.</text>
              </g>
              <g transform="translate(16, 116)">
                <circle cx="4" cy="7" r="3" fill="#48D9D0" />
                <text x="14" y="10" fill="#FFFFFF" fontSize="11.2" className="svg-body">Can support faster predictions and decisions.</text>
              </g>
              <g transform="translate(16, 150)">
                <circle cx="4" cy="7" r="3" fill="#48D9D0" />
                <text x="14" y="10" fill="#FFFFFF" fontSize="11.2" className="svg-body">Can assist with learning and creative work.</text>
              </g>
            </g>

            {/* Right: Challenges */}
            <g transform="translate(370, 50)">
              <rect x="0" y="0" width="350" height="190" rx="8" fill="#131E33" stroke="#3867FF" strokeWidth="1" strokeOpacity="0.4" />
              <rect x="0" y="0" width="350" height="34" rx="8" fill="#3867FF" fillOpacity="0.15" />
              <circle cx="22" cy="17" r="7" fill="#3867FF" />
              <path d="M 22 13 L 22 18 M 22 21 L 22 22" stroke="#FFFFFF" strokeWidth="1.5" strokeLinecap="round" />
              <text x="36" y="22" fill="#FFFFFF" fontSize="12" className="svg-heading">IMPORTANT CHALLENGES</text>

              <g transform="translate(16, 48)">
                <circle cx="4" cy="7" r="3" fill="#3867FF" />
                <text x="14" y="10" fill="#FFFFFF" fillOpacity="0.9" fontSize="11.2" className="svg-body">Biased data can lead to unfair outcomes.</text>
              </g>
              <g transform="translate(16, 82)">
                <circle cx="4" cy="7" r="3" fill="#3867FF" />
                <text x="14" y="10" fill="#FFFFFF" fillOpacity="0.9" fontSize="11.2" className="svg-body">Personal data may be exposed or misused.</text>
              </g>
              <g transform="translate(16, 116)">
                <circle cx="4" cy="7" r="3" fill="#3867FF" />
                <text x="14" y="10" fill="#FFFFFF" fillOpacity="0.9" fontSize="11.2" className="svg-body">Outputs may be inaccurate or misleading.</text>
              </g>
              <g transform="translate(16, 150)">
                <circle cx="4" cy="7" r="3" fill="#3867FF" />
                <text x="14" y="10" fill="#FFFFFF" fillOpacity="0.9" fontSize="11.2" className="svg-body">Complex decisions may be difficult to explain.</text>
              </g>
            </g>
          </g>

          {/* ========================================== */}
          {/* SECTION 6: RESPONSIBLE AI (1705 - 1880)    */}
          {/* ========================================== */}
          <g transform="translate(40, 1705)">
            <rect x="0" y="0" width="28" height="28" rx="6" fill="#3867FF" fillOpacity="0.2" />
            <text x="9" y="19" fill="#48D9D0" fontSize="13" className="svg-heading">06</text>
            <text x="38" y="20" fill="#FFFFFF" fontSize="18" letterSpacing="0.5" className="svg-heading">
              USE AI WISELY: RESPONSIBLE PRINCIPLES
            </text>

            <g transform="translate(0, 36)">
              <rect x="0" y="0" width="720" height="124" rx="8" fill="url(#cardGradCanvas)" stroke="#3867FF" strokeWidth="1" strokeOpacity="0.3" />

              <g transform="translate(16, 12)">
                <circle cx="12" cy="12" r="10" fill="#3867FF" fillOpacity="0.25" />
                <path d="M 8 12 L 11 15 L 16 9" stroke="#48D9D0" strokeWidth="1.5" fill="none" strokeLinecap="round" />
                <text x="30" y="15" fill="#48D9D0" fontSize="11.5" className="svg-heading">CHECK THE OUTPUT</text>
                <text x="175" y="15" fill="#FFFFFF" fillOpacity="0.88" fontSize="11.5" className="svg-body">— Verify important claims against credible primary sources.</text>
              </g>

              <g transform="translate(16, 40)">
                <circle cx="12" cy="12" r="10" fill="#3867FF" fillOpacity="0.25" />
                <path d="M 8 12 L 11 15 L 16 9" stroke="#48D9D0" strokeWidth="1.5" fill="none" strokeLinecap="round" />
                <text x="30" y="15" fill="#48D9D0" fontSize="11.5" className="svg-heading">PROTECT PRIVACY</text>
                <text x="175" y="15" fill="#FFFFFF" fillOpacity="0.88" fontSize="11.5" className="svg-body">— Avoid sharing sensitive personal data unnecessarily.</text>
              </g>

              <g transform="translate(16, 68)">
                <circle cx="12" cy="12" r="10" fill="#3867FF" fillOpacity="0.25" />
                <path d="M 8 12 L 11 15 L 16 9" stroke="#48D9D0" strokeWidth="1.5" fill="none" strokeLinecap="round" />
                <text x="30" y="15" fill="#48D9D0" fontSize="11.5" className="svg-heading">LOOK FOR BIAS</text>
                <text x="175" y="15" fill="#FFFFFF" fillOpacity="0.88" fontSize="11.5" className="svg-body">— Consider whether the result could be unfair or one-sided.</text>
              </g>

              <g transform="translate(16, 96)">
                <circle cx="12" cy="12" r="10" fill="#3867FF" fillOpacity="0.25" />
                <path d="M 8 12 L 11 15 L 16 9" stroke="#48D9D0" strokeWidth="1.5" fill="none" strokeLinecap="round" />
                <text x="30" y="15" fill="#48D9D0" fontSize="11.5" className="svg-heading">KEEP HUMANS INVOLVED</text>
                <text x="175" y="15" fill="#FFFFFF" fillOpacity="0.88" fontSize="11.5" className="svg-body">— Use human oversight for high-stakes, consequential decisions.</text>
              </g>
            </g>
          </g>

          {/* ========================================== */}
          {/* SECTION 7: FINAL TAKEAWAY & FOOTER (1880-) */}
          {/* ========================================== */}
          <g transform="translate(40, 1880)">
            <rect x="0" y="0" width="720" height="2" fill="url(#blueGlowCanvas)" />
            <text x="360" y="24" textAnchor="middle" fill="#FFFFFF" fontSize="15" letterSpacing="0.5" className="svg-title">
              AI IS A TOOL. HUMAN JUDGMENT STILL MATTERS.
            </text>
            <text x="360" y="42" textAnchor="middle" fill="#48D9D0" fontSize="12" className="svg-medium">
              Understand the data · Question the output · Use intelligence responsibly.
            </text>

            <g transform="translate(0, 54)">
              <rect x="0" y="0" width="720" height="32" rx="4" fill="#0D1422" />
              <text x="10" y="15" fill="#FFFFFF" fillOpacity="0.6" fontSize="8.8" className="svg-body">
                Sources: NIST CSRC AI Glossary · NIST SP 1270 Bias in AI · UNESCO AI &amp; Education Guidance · U.S. FDA Digital Health Glossary
              </text>
              <text x="10" y="26" fill="#FFFFFF" fillOpacity="0.6" fontSize="8.8" className="svg-body">
                Designed by Neha Vinod Borkar · Oasis Infobyte Graphics Design Internship · Task 4 (Infographic)
              </text>
            </g>
          </g>
        </svg>
      </div>
    </div>
  );
};
