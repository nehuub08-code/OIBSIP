import React, { useState } from 'react';
import { FileText, Download, Check, Copy, Folder, Image as ImageIcon } from 'lucide-react';

interface FileItem {
  name: string;
  path: string;
  description: string;
  type: 'markdown' | 'image' | 'svg';
  downloadUrl: string;
}

const FILES: FileItem[] = [
  {
    name: 'AI-Unpacked-Infographic.png',
    path: 'OIBSIP/Graphics-Design/Task-4-Infographic/AI-Unpacked-Infographic.png',
    description: 'Primary deliverable: Exact 800 × 2000 pixels PNG at high resolution (150+ DPI verified).',
    type: 'image',
    downloadUrl: '/OIBSIP/Graphics-Design/Task-4-Infographic/AI-Unpacked-Infographic.png',
  },
  {
    name: 'AI-Unpacked-Infographic@2x.png',
    path: 'OIBSIP/Graphics-Design/Task-4-Infographic/AI-Unpacked-Infographic@2x.png',
    description: 'Ultra High-Res 1600 × 4000 pixels PNG (300 DPI print-ready equivalent).',
    type: 'image',
    downloadUrl: '/OIBSIP/Graphics-Design/Task-4-Infographic/AI-Unpacked-Infographic@2x.png',
  },
  {
    name: 'AI-Unpacked-Infographic.svg',
    path: 'OIBSIP/Graphics-Design/Task-4-Infographic/AI-Unpacked-Infographic.svg',
    description: 'Master Vector SVG source file (compatible with Figma, Canva, Illustrator).',
    type: 'svg',
    downloadUrl: '/OIBSIP/Graphics-Design/Task-4-Infographic/AI-Unpacked-Infographic.svg',
  },
  {
    name: 'README.md',
    path: 'OIBSIP/Graphics-Design/Task-4-Infographic/README.md',
    description: 'Project documentation, designer details, checklist verification, and Canva blueprint.',
    type: 'markdown',
    downloadUrl: '/OIBSIP/Graphics-Design/Task-4-Infographic/README.md',
  },
  {
    name: 'infographic-content.md',
    path: 'OIBSIP/Graphics-Design/Task-4-Infographic/infographic-content.md',
    description: 'Full verbatim educational text content specification for all 7 infographic sections.',
    type: 'markdown',
    downloadUrl: '/OIBSIP/Graphics-Design/Task-4-Infographic/infographic-content.md',
  },
  {
    name: 'sources.md',
    path: 'OIBSIP/Graphics-Design/Task-4-Infographic/sources.md',
    description: 'Academic and regulatory source citations (NIST, UNESCO, FDA) with verified URLs.',
    type: 'markdown',
    downloadUrl: '/OIBSIP/Graphics-Design/Task-4-Infographic/sources.md',
  },
];

export const RepoFilesView: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<FileItem>(FILES[0]);
  const [fileContent, setFileContent] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);

  const loadContent = async (file: FileItem) => {
    setSelectedFile(file);
    if (file.type === 'markdown' || file.type === 'svg') {
      setLoading(true);
      try {
        const res = await fetch(file.downloadUrl);
        const text = await res.text();
        setFileContent(text);
      } catch (err) {
        console.error('Failed to load file content:', err);
        setFileContent('Error loading preview.');
      } finally {
        setLoading(false);
      }
    } else {
      setFileContent(null);
    }
  };

  const handleCopy = () => {
    if (fileContent) {
      navigator.clipboard.writeText(fileContent);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6 space-y-6">
      {/* Top Banner */}
      <div className="bg-[#101828] border border-slate-800 rounded-xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#48D9D0] font-heading font-semibold uppercase tracking-wider mb-1">
            <Folder className="w-4 h-4 text-[#48D9D0]" />
            <span>Repository Deliverables</span>
            <span>·</span>
            <span>OIBSIP Structure</span>
          </div>
          <h2 className="text-2xl font-bold text-white font-heading tracking-tight">
            Internship Submission Directory
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Location: <code className="text-[#48D9D0] font-mono text-xs">OIBSIP/Graphics-Design/Task-4-Infographic/</code>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="/OIBSIP/Graphics-Design/Task-4-Infographic/AI-Unpacked-Infographic.png"
            download="AI-Unpacked-Infographic.png"
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#3867FF] to-[#254bdb] text-white rounded-lg text-xs font-semibold shadow-md shadow-[#3867FF]/20 hover:from-[#4370ff] hover:to-[#2e55e8] transition-all"
          >
            <Download className="w-3.5 h-3.5 text-[#48D9D0]" />
            <span>Download Main PNG (800×2000)</span>
          </a>
        </div>
      </div>

      {/* Two Column Layout: File List & Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* File List */}
        <div className="space-y-2">
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Files in Repository ({FILES.length})
          </h3>
          {FILES.map((file) => {
            const isSelected = selectedFile.name === file.name;
            return (
              <div
                key={file.name}
                onClick={() => loadContent(file)}
                className={`p-3 rounded-lg border transition-all cursor-pointer flex items-start gap-3 ${
                  isSelected
                    ? 'bg-[#162238] border-[#48D9D0] shadow-md shadow-[#3867FF]/10'
                    : 'bg-[#101828] border-slate-800 hover:border-slate-700 hover:bg-[#121c2d]'
                }`}
              >
                <div className="p-2 rounded bg-[#0b101b] text-[#48D9D0] shrink-0 mt-0.5">
                  {file.type === 'image' ? (
                    <ImageIcon className="w-4 h-4 text-[#48D9D0]" />
                  ) : (
                    <FileText className="w-4 h-4 text-[#3867FF]" />
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs font-semibold text-white truncate block">
                      {file.name}
                    </span>
                    <a
                      href={file.downloadUrl}
                      download={file.name}
                      onClick={(e) => e.stopPropagation()}
                      className="text-slate-400 hover:text-white p-1"
                      title="Download file"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </a>
                  </div>
                  <p className="text-[11px] text-slate-400 line-clamp-2 mt-0.5">
                    {file.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Content Preview */}
        <div className="lg:col-span-2 bg-[#101828] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col h-[650px] overflow-hidden">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div>
              <span className="text-xs font-mono text-[#48D9D0] block">{selectedFile.path}</span>
              <span className="text-sm font-bold text-white font-heading">{selectedFile.name}</span>
            </div>

            <div className="flex items-center gap-2">
              {fileContent && (
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#162238] text-xs font-medium text-slate-300 hover:text-white transition-colors border border-slate-800"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied!' : 'Copy Text'}</span>
                </button>
              )}

              <a
                href={selectedFile.downloadUrl}
                download={selectedFile.name}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#3867FF] text-xs font-medium text-white hover:bg-[#4a77ff] transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download</span>
              </a>
            </div>
          </div>

          {/* View Container */}
          <div className="flex-1 overflow-auto bg-[#0b101b] rounded-lg p-4 border border-slate-800/80">
            {selectedFile.type === 'image' ? (
              <div className="h-full flex flex-col items-center justify-center space-y-3">
                <img
                  src={selectedFile.downloadUrl}
                  alt={selectedFile.name}
                  className="max-h-[500px] w-auto rounded border border-slate-700 shadow-md object-contain"
                />
                <p className="text-xs text-slate-400">
                  Previewing high-resolution PNG ({selectedFile.name})
                </p>
              </div>
            ) : loading ? (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                Loading content...
              </div>
            ) : (
              <pre className="text-xs font-mono text-slate-300 whitespace-pre-wrap leading-relaxed">
                {fileContent || 'Click file to inspect its content, or download directly.'}
              </pre>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
