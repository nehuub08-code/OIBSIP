import React, { useState } from 'react';
import { Copy, Check, Download, Layers, Palette, Type, SlidersHorizontal } from 'lucide-react';
import { DESIGNER_INFO, SECTIONS } from '../data/infographicData';

export const CanvaBlueprintView: React.FC = () => {
  const [copiedHex, setCopiedHex] = useState<string | null>(null);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedHex(text);
    setTimeout(() => setCopiedHex(null), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto py-8 px-4 sm:px-6 space-y-8">
      {/* Header Banner */}
      <div className="bg-[#101828] border border-slate-800 rounded-xl p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-[#48D9D0] font-heading font-semibold uppercase tracking-wider mb-1">
              <span>Canva Master Blueprint</span>
              <span>·</span>
              <span>Step-by-Step Recreation Guide</span>
            </div>
            <h2 className="text-2xl font-bold text-white font-heading tracking-tight">
              Canva Canvas Setup & Design Specifications
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Exact coordinates, hex codes, typography sizes, icon keywords, and export settings tailored for Canva.
            </p>
          </div>

          <a
            href="/OIBSIP/Graphics-Design/Task-4-Infographic/AI-Unpacked-Infographic.svg"
            download="AI-Unpacked-Infographic.svg"
            className="flex items-center gap-2 px-4 py-2.5 bg-[#162238] hover:bg-[#1d2d48] text-[#48D9D0] border border-[#3867FF]/40 rounded-lg text-xs font-semibold transition-colors shrink-0"
          >
            <Download className="w-4 h-4" />
            <span>Download Master SVG (Upload to Canva)</span>
          </a>
        </div>
      </div>

      {/* Grid: Setup Parameters & Color Kit */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Step 1: Canvas Dimensions */}
        <div className="bg-[#101828] border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
          <div className="flex items-center gap-2.5 text-white font-heading font-bold text-base">
            <div className="w-7 h-7 rounded bg-[#3867FF]/20 text-[#48D9D0] flex items-center justify-center text-xs">
              01
            </div>
            <h3>1. Canvas Dimensions & Rulers</h3>
          </div>

          <div className="space-y-3 text-xs text-slate-300">
            <div className="flex justify-between items-center py-1.5 border-b border-slate-800/80">
              <span className="text-slate-400">Canvas Width:</span>
              <span className="font-mono text-white font-semibold">800 px</span>
            </div>
            <div className="flex justify-between items-center py-1.5 border-b border-slate-800/80">
              <span className="text-slate-400">Canvas Height:</span>
              <span className="font-mono text-white font-semibold">2000 px</span>
            </div>
            <div className="flex justify-between items-center py-1.5 border-b border-slate-800/80">
              <span className="text-slate-400">Aspect Ratio:</span>
              <span className="font-mono text-white font-semibold">1 : 2.5 (Portrait)</span>
            </div>
            <div className="flex justify-between items-center py-1.5 border-b border-slate-800/80">
              <span className="text-slate-400">Margins:</span>
              <span className="font-mono text-white font-semibold">Left/Right: 32px (Usable: 736px)</span>
            </div>
            <div className="flex justify-between items-center py-1.5 border-b border-slate-800/80">
              <span className="text-slate-400">Canva Setup Action:</span>
              <span className="text-[#48D9D0]">Create a design &gt; Custom size (800 × 2000 px)</span>
            </div>
          </div>
        </div>

        {/* Step 2: 4-Color Swatch Kit */}
        <div className="bg-[#101828] border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
          <div className="flex items-center gap-2.5 text-white font-heading font-bold text-base">
            <div className="w-7 h-7 rounded bg-[#3867FF]/20 text-[#48D9D0] flex items-center justify-center text-xs">
              02
            </div>
            <div className="flex items-center gap-2">
              <Palette className="w-4 h-4 text-[#48D9D0]" />
              <h3>2. Strict 4-Colour Swatches (Max 4)</h3>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {DESIGNER_INFO.colors.map((c) => (
              <button
                key={c.hex}
                onClick={() => copyToClipboard(c.hex)}
                className="flex items-center gap-3 p-3 rounded-lg bg-[#162238] border border-slate-800 hover:border-[#3867FF]/60 transition-all text-left group"
              >
                <div
                  className="w-7 h-7 rounded-md border border-white/20 shrink-0 shadow-sm"
                  style={{ backgroundColor: c.hex }}
                />
                <div className="min-w-0 flex-1">
                  <span className="text-xs font-semibold text-white block truncate">{c.name}</span>
                  <div className="flex items-center gap-1">
                    <span className="text-[11px] font-mono text-[#48D9D0]">{c.hex}</span>
                    {copiedHex === c.hex ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3 text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>
          <p className="text-[11px] text-slate-400">
            Click any swatch to copy hex code for your Canva Brand Kit.
          </p>
        </div>
      </div>

      {/* Step 3: Typography Rules */}
      <div className="bg-[#101828] border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
        <div className="flex items-center gap-2.5 text-white font-heading font-bold text-base">
          <div className="w-7 h-7 rounded bg-[#3867FF]/20 text-[#48D9D0] flex items-center justify-center text-xs">
            03
          </div>
          <div className="flex items-center gap-2">
            <Type className="w-4 h-4 text-[#48D9D0]" />
            <h3>3. Typography Pairings & Hierarchies (Max 2 Font Families)</h3>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="bg-[#162238] p-4 rounded-lg border border-slate-800 space-y-2">
            <span className="text-xs font-bold text-[#48D9D0] block uppercase tracking-wider">
              Primary Heading Font: Space Grotesk
            </span>
            <ul className="space-y-1.5 text-slate-300">
              <li>• Main Title: <strong>44pt Bold</strong> (All Caps, #FFFFFF)</li>
              <li>• Section Titles: <strong>18pt Bold</strong> (#FFFFFF, tracking +0.5)</li>
              <li>• Card Subheads: <strong>13pt–14pt Semi-Bold</strong> (#48D9D0)</li>
              <li>• Step Badges: <strong>11pt Bold</strong> (Inside #3867FF badges)</li>
            </ul>
          </div>

          <div className="bg-[#162238] p-4 rounded-lg border border-slate-800 space-y-2">
            <span className="text-xs font-bold text-[#48D9D0] block uppercase tracking-wider">
              Body Prose Font: Inter / Manrope
            </span>
            <ul className="space-y-1.5 text-slate-300">
              <li>• Definition Text: <strong>13.5pt Medium</strong> (#FFFFFF, leading 1.4)</li>
              <li>• Card Explanations: <strong>11.5pt Regular</strong> (#FFFFFF 90% opacity)</li>
              <li>• Examples & Sub-text: <strong>11pt Regular</strong> (#48D9D0)</li>
              <li>• Citations & Footnotes: <strong>8.8pt Regular</strong> (#FFFFFF 60% opacity)</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Step 4: Vertical Section Grid Coordinates */}
      <div className="bg-[#101828] border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
        <div className="flex items-center gap-2.5 text-white font-heading font-bold text-base">
          <div className="w-7 h-7 rounded bg-[#3867FF]/20 text-[#48D9D0] flex items-center justify-center text-xs">
            04
          </div>
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#48D9D0]" />
            <h3>4. Section Positions & Layout Coordinates</h3>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[11px] uppercase bg-[#162238] text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Section</th>
                <th className="py-2.5 px-3">Y Position</th>
                <th className="py-2.5 px-3">Height</th>
                <th className="py-2.5 px-3">Key Canva Elements</th>
                <th className="py-2.5 px-3">Canva Icon Search</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
              {SECTIONS.map((s) => (
                <tr key={s.id} className="hover:bg-[#162238]/40 transition-colors">
                  <td className="py-2.5 px-3 text-white font-medium">{s.title}</td>
                  <td className="py-2.5 px-3 text-[#48D9D0]">Y: {s.yRange.start}px</td>
                  <td className="py-2.5 px-3 text-slate-300">{s.yRange.end - s.yRange.start}px</td>
                  <td className="py-2.5 px-3 font-sans text-slate-400">{s.visualElements.join(', ')}</td>
                  <td className="py-2.5 px-3 font-sans text-[#3867FF]">
                    {s.canvaSpecs.iconKeywords.slice(0, 2).map((k) => `"${k}"`).join(', ')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Step 5: Exporting from Canva */}
      <div className="bg-[#101828] border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
        <div className="flex items-center gap-2.5 text-white font-heading font-bold text-base">
          <div className="w-7 h-7 rounded bg-[#3867FF]/20 text-[#48D9D0] flex items-center justify-center text-xs">
            05
          </div>
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-[#48D9D0]" />
            <h3>5. Canva Export Protocol (150+ DPI Target)</h3>
          </div>
        </div>

        <div className="space-y-3 text-xs text-slate-300 bg-[#162238] p-4 rounded-lg border border-slate-800">
          <p>
            1. In Canva top right, click <strong>Share</strong> &gt; <strong>Download</strong>.
          </p>
          <p>
            2. File type: Select <strong>PNG</strong> (High-quality image).
          </p>
          <p>
            3. Size: Leave at <strong>1x</strong> (800 × 2000 px) for exact digital delivery, or set slider to <strong>2x</strong> (1600 × 4000 px) for professional 300 DPI print rendering.
          </p>
          <p>
            4. Ensure transparent background is <strong>unchecked</strong> so the deep navy (`#101828`) backdrop remains intact.
          </p>
          <p>
            5. Save with exact filename: <code className="text-[#48D9D0] font-mono">AI-Unpacked-Infographic.png</code>.
          </p>
        </div>
      </div>
    </div>
  );
};
