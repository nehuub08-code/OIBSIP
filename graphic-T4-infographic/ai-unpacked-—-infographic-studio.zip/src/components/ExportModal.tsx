import React from 'react';
import { X, Download, CheckCircle2, ShieldCheck, FileCheck } from 'lucide-react';
import { DESIGNER_INFO } from '../data/infographicData';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#101828] border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs text-[#48D9D0] font-heading font-semibold uppercase tracking-wider mb-1">
              <Download className="w-3.5 h-3.5" />
              <span>Export Deliverables</span>
            </div>
            <h3 className="text-xl font-bold text-white font-heading">
              Download AI Unpacked Infographic
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Verified high-resolution formats matching Oasis Infobyte Task 4 requirements.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quality Metadata Badge */}
        <div className="bg-[#162238] p-3.5 rounded-xl border border-slate-800/80 space-y-2 text-xs">
          <div className="flex items-center justify-between text-slate-300">
            <span className="text-slate-400">Designer:</span>
            <span className="font-semibold text-white">{DESIGNER_INFO.name}</span>
          </div>
          <div className="flex items-center justify-between text-slate-300">
            <span className="text-slate-400">Task Title:</span>
            <span className="font-semibold text-white">{DESIGNER_INFO.taskTitle}</span>
          </div>
          <div className="flex items-center justify-between text-slate-300">
            <span className="text-slate-400">Palette Restriction:</span>
            <span className="font-mono text-[#48D9D0]">Strict 4-Color Palette Enforced</span>
          </div>
          <div className="flex items-center justify-between text-slate-300">
            <span className="text-slate-400">Resolution Check:</span>
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Minimum 150 DPI target satisfied (300 DPI available)
            </span>
          </div>
        </div>

        {/* Export Options */}
        <div className="space-y-3">
          {/* Option 1: 800 x 2000 PNG (Standard Required) */}
          <a
            href="/OIBSIP/Graphics-Design/Task-4-Infographic/AI-Unpacked-Infographic.png"
            download="AI-Unpacked-Infographic.png"
            className="flex items-center justify-between p-4 rounded-xl bg-[#141f33] border border-[#3867FF]/40 hover:border-[#48D9D0] transition-all group"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white font-heading">
                  AI-Unpacked-Infographic.png
                </span>
                <span className="text-[10px] bg-[#3867FF]/30 text-[#48D9D0] px-2 py-0.5 rounded font-mono">
                  Primary Task File
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Exact 800 × 2000 px · High quality raster PNG (150 DPI digital standard).
              </p>
            </div>
            <div className="p-2.5 rounded-lg bg-[#3867FF] text-white group-hover:bg-[#4d7bff] transition-colors shrink-0">
              <Download className="w-4 h-4" />
            </div>
          </a>

          {/* Option 2: 1600 x 4000 PNG (2x - 300 DPI Print-Ready) */}
          <a
            href="/OIBSIP/Graphics-Design/Task-4-Infographic/AI-Unpacked-Infographic@2x.png"
            download="AI-Unpacked-Infographic@2x.png"
            className="flex items-center justify-between p-4 rounded-xl bg-[#141f33] border border-slate-800 hover:border-[#3867FF]/60 transition-all group"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white font-heading">
                  AI-Unpacked-Infographic@2x.png
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono">
                  300 DPI Print
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Ultra-crisp 1600 × 4000 px · Double resolution for large format print / poster display.
              </p>
            </div>
            <div className="p-2.5 rounded-lg bg-[#162238] text-slate-300 group-hover:bg-[#3867FF] group-hover:text-white transition-colors shrink-0">
              <Download className="w-4 h-4" />
            </div>
          </a>

          {/* Option 3: Master Vector SVG */}
          <a
            href="/OIBSIP/Graphics-Design/Task-4-Infographic/AI-Unpacked-Infographic.svg"
            download="AI-Unpacked-Infographic.svg"
            className="flex items-center justify-between p-4 rounded-xl bg-[#141f33] border border-slate-800 hover:border-[#3867FF]/60 transition-all group"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white font-heading">
                  AI-Unpacked-Infographic.svg
                </span>
                <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded font-mono">
                  Vector Source
                </span>
              </div>
              <p className="text-xs text-slate-400">
                100% vector SVG master file for Canva, Adobe Illustrator, or Figma.
              </p>
            </div>
            <div className="p-2.5 rounded-lg bg-[#162238] text-slate-300 group-hover:bg-[#3867FF] group-hover:text-white transition-colors shrink-0">
              <Download className="w-4 h-4" />
            </div>
          </a>
        </div>

        {/* Footer info */}
        <div className="flex items-center justify-between pt-2 text-[11px] text-slate-400 border-t border-slate-800">
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#48D9D0]" />
            <span>Ready for submission in OIBSIP repository</span>
          </span>
          <button
            onClick={onClose}
            className="text-xs text-slate-300 hover:text-white px-3 py-1 rounded bg-[#162238]"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
