import { InfographicSection, FactSource } from '../types/infographic';

export const DESIGNER_INFO = {
  name: 'Neha Vinod Borkar',
  internship: 'Oasis Infobyte (Track: Graphics Design)',
  taskTitle: 'Task 4 — Infographic',
  projectTitle: 'AI Unpacked — How Artificial Intelligence Works',
  repository: 'OIBSIP/Graphics-Design/Task-4-Infographic',
  dimensions: '800 × 2000 pixels',
  targetDpi: 'Minimum 150 DPI (Print ~5.33 × 13.33 in)',
  colors: [
    { name: 'Deep Navy', hex: '#101828', role: 'Primary Background & Headings' },
    { name: 'Electric Blue', hex: '#3867FF', role: 'Emphasis & Process Arrows' },
    { name: 'Aqua', hex: '#48D9D0', role: 'Secondary Highlights & Data Symbols' },
    { name: 'White', hex: '#FFFFFF', role: 'Body Text & Light Panels' },
  ],
  fonts: [
    { name: 'Space Grotesk', role: 'Headings & Numbers', weight: 'Bold (700)' },
    { name: 'Inter', role: 'Body & Descriptions', weight: 'Regular / Medium (400, 500)' },
  ],
};

export const SECTIONS: InfographicSection[] = [
  {
    id: 'header',
    number: '00',
    title: 'HEADER: AI UNPACKED',
    subtitle: 'From Data to Intelligent Decisions',
    yRange: { start: 0, end: 185 },
    summary:
      'High-impact editorial header featuring Space Grotesk headline, subline, and orientation description with clean geometric alignment.',
    keyTakeaways: [
      'Sets the educational, clear, and scientifically responsible tone.',
      'Explicitly highlights internship metadata without visual clutter.',
      'Establishes visual anchor with vibrant Electric Blue to Aqua gradient bar.',
    ],
    visualElements: ['Linear gradient banner', 'Kicker micro-text', 'Subtle grid background'],
    sourceCitations: [],
    canvaSpecs: {
      coordinates: 'X: 40px, Y: 36px (Width: 720px)',
      height: '145px',
      fonts: 'Space Grotesk Bold 44pt (#FFFFFF), Space Grotesk Medium 18pt (#48D9D0), Inter 13pt',
      colors: ['#FFFFFF', '#48D9D0', '#3867FF', '#101828'],
      iconKeywords: ['ai banner', 'tech abstract header', 'minimal line'],
    },
  },
  {
    id: 'section-1',
    number: '01',
    title: 'WHAT IS ARTIFICIAL INTELLIGENCE?',
    subtitle: 'Official NIST Definition & Everyday Illustration',
    yRange: { start: 195, end: 440 },
    summary:
      'Grounded directly in the National Institute of Standards and Technology (NIST) definition: machine-based systems generating predictions, recommendations, or decisions.',
    keyTakeaways: [
      'Machine-based systems designed for human-defined objectives.',
      'Everyday navigation example: calculating routes by combining real-time and historical transit patterns.',
      'Central system hub diagram visually demonstrating input data connecting to actionable decisions.',
    ],
    visualElements: [
      'Central AI core node with orbiting input/decision satellites',
      'Navigation map pin vector icon',
      'NIST official definition card',
    ],
    sourceCitations: [
      {
        source: 'NIST CSRC Glossary',
        url: 'https://csrc.nist.gov/glossary/term/artificial_intelligence',
        detail:
          'Definitions of artificial intelligence, predictions, recommendations, and decisions for defined objectives.',
      },
    ],
    canvaSpecs: {
      coordinates: 'X: 40px, Y: 195px (Width: 720px)',
      height: '240px',
      fonts: 'Space Grotesk 18pt, Inter 13.5pt, Inter 11.5pt',
      colors: ['#162238', '#3867FF', '#48D9D0', '#FFFFFF'],
      iconKeywords: ['location pin line icon', 'data node connected', 'cpu chip outline'],
    },
  },
  {
    id: 'section-2',
    number: '02',
    title: 'FROM DATA TO DECISIONS',
    subtitle: '4-Step Vertical Process Workflow',
    yRange: { start: 450, end: 825 },
    summary:
      'A structured 4-step vertical learning loop illustrating how raw information transforms into evaluated outputs, with an explicit educational accuracy disclaimer.',
    keyTakeaways: [
      'Step 1: Collect Data — Text, images, numbers, and signals ingested as raw material.',
      'Step 2: Learn Patterns — Machine learning models discover mathematical and statistical structures.',
      'Step 3: Generate Output — Classifications, predictions, recommendations, or synthetic media.',
      'Step 4: Evaluate & Improve — Human-in-the-loop oversight to audit accuracy, fairness, and safety.',
      'Accuracy Note: Real-world architectures vary; models do not automatically self-improve without human guidance.',
    ],
    visualElements: [
      '4 Numbered step badges with distinct line icons',
      'Directional Electric Blue process arrows',
      'Accuracy callout container',
    ],
    sourceCitations: [
      {
        source: 'NIST SP 1270: Explaining Decisions with AI',
        url: 'https://www.nist.gov/system/files/documents/2021/10/04/explaining-decisions-made-with-artificial-intelligence-1-0.pdf',
        detail: 'Supervised learning workflows and human-in-the-loop audit cycles.',
      },
    ],
    canvaSpecs: {
      coordinates: 'X: 40px, Y: 450px (Width: 720px)',
      height: '365px',
      fonts: 'Space Grotesk 18pt, Space Grotesk 13pt (Step titles), Inter 11.5pt',
      colors: ['#192843', '#3867FF', '#48D9D0', '#FFFFFF'],
      iconKeywords: ['database cylinder line', 'brain circuit line', 'sparkle icon', 'loop arrows'],
    },
  },
  {
    id: 'section-3',
    number: '03',
    title: 'MEET THE AI FAMILY',
    subtitle: 'Overlapping Categories & Taxonomy',
    yRange: { start: 835, end: 1180 },
    summary:
      'Clarifies the hierarchical relationship between Machine Learning, Deep Learning, and Generative AI with dedicated technical illustrations for each.',
    keyTakeaways: [
      'Machine Learning (ML): Learns patterns to make predictions (e.g. demand forecasting). Illustrated with scatterplot trendline.',
      'Deep Learning: Uses multi-layer artificial neural networks (e.g. medical scan recognition). Illustrated with 3-layer synaptic network.',
      'Generative AI: Synthesizes novel text, images, or code (e.g. drafting communications). Illustrated with document and spark synthesis icon.',
      'Taxonomic Integrity: ML is a branch of AI; Deep Learning is a subset of ML; GenAI describes functional generative capabilities.',
    ],
    visualElements: [
      'Regression trendline chart',
      'Multi-layer artificial neural network diagram',
      'Document & creative spark vector icon',
    ],
    sourceCitations: [
      {
        source: 'FDA Digital Health and AI Glossary',
        url: 'https://www.fda.gov/science-research/artificial-intelligence-and-medical-products/fda-digital-health-and-artificial-intelligence-glossary-educational-resource',
        detail: 'Taxonomic criteria for machine learning, artificial neural networks, and generative software.',
      },
    ],
    canvaSpecs: {
      coordinates: 'X: 40px, Y: 835px (Width: 720px)',
      height: '345px',
      fonts: 'Space Grotesk 14pt (Card titles), Inter 12pt, Inter 11.5pt',
      colors: ['#162238', '#3867FF', '#48D9D0', '#FFFFFF'],
      iconKeywords: ['scatter plot regression', 'neural network nodes', 'document creative spark'],
    },
  },
  {
    id: 'section-4',
    number: '04',
    title: 'AI IN EVERYDAY LIFE',
    subtitle: '2×2 Application Matrix Across Essential Industries',
    yRange: { start: 1190, end: 1425 },
    summary:
      'Demonstrates real-world assistive tools across Education, Healthcare, Finance, and Transportation without claiming autonomous replacement of human professionals.',
    keyTakeaways: [
      'Education: Personalized learning pace and adaptive practice exercises.',
      'Healthcare: Assisting physicians with diagnostic medical imaging anomaly detection.',
      'Finance: Millisecond transaction fraud detection and risk monitoring.',
      'Transport: Dynamic route estimation and intelligent driver-assistance alert systems.',
    ],
    visualElements: [
      '2×2 balanced card grid',
      'Graduation/Education line icon',
      'Medical cross line icon',
      'Credit card security line icon',
      'Automotive transport line icon',
    ],
    sourceCitations: [
      {
        source: 'UNESCO AI and Education Guidance',
        url: 'https://unesdoc.unesco.org/in/rest/annotationSVC/DownloadWatermarkedAttachment/attach_import_761bcdad-d1e3-40c9-819d-03c4ac725f26?_=376709eng.pdf&from=8&to=40',
        detail: 'Educational assistive models, student personalization, and ethical boundaries.',
      },
    ],
    canvaSpecs: {
      coordinates: 'X: 40px, Y: 1190px (Width: 720px)',
      height: '235px',
      fonts: 'Space Grotesk 12.5pt (Card headers), Inter 11pt',
      colors: ['#162238', '#3867FF', '#48D9D0', '#FFFFFF'],
      iconKeywords: ['graduation cap line', 'medical caduceus outline', 'credit card shield', 'car navigation line'],
    },
  },
  {
    id: 'section-5',
    number: '05',
    title: 'TWO SIDES OF AI: BENEFITS & CHALLENGES',
    subtitle: 'Balanced Comparative Columns',
    yRange: { start: 1435, end: 1695 },
    summary:
      'Rigorous side-by-side comparison balancing high-velocity automation with sociotechnical risks, rejecting uncritical techno-optimism.',
    keyTakeaways: [
      'Potential Benefits: Rapid data analysis, mechanical automation, decision speed, creative ideation assistance.',
      'Important Challenges: Algorithmic bias, data privacy exposure, plausible hallucinations, black-box opacity.',
      'Critical Perspective: AI reflects the biases and limitations of its training data; it does not eliminate human error.',
    ],
    visualElements: [
      'Dual comparison columns (350px width each)',
      'Aqua checkmark bullets for benefits',
      'Electric blue alert bullets for challenges',
    ],
    sourceCitations: [
      {
        source: 'NIST SP 1270: Managing Bias in AI',
        url: 'https://www.nist.gov/system/files/documents/2021/10/04/explaining-decisions-made-with-artificial-intelligence-1-0.pdf',
        detail: 'Systemic bias, opacity, and risk management guidelines.',
      },
    ],
    canvaSpecs: {
      coordinates: 'X: 40px, Y: 1435px (Width: 720px)',
      height: '260px',
      fonts: 'Space Grotesk 12pt (Column headers), Inter 11.2pt',
      colors: ['#131E33', '#48D9D0', '#3867FF', '#FFFFFF'],
      iconKeywords: ['check circle green', 'warning alert circle', 'balance scale outline'],
    },
  },
  {
    id: 'section-6',
    number: '06',
    title: 'USE AI WISELY: RESPONSIBLE PRINCIPLES',
    subtitle: 'Four Actionable Ethical Rules',
    yRange: { start: 1705, end: 1875 },
    summary:
      'Actionable checklist empowering students and professionals to verify claims, protect sensitive personal data, detect bias, and maintain human oversight.',
    keyTakeaways: [
      'Check the Output: Always verify critical claims against primary authoritative sources.',
      'Protect Privacy: Never input confidential or sensitive personal information into unvetted tools.',
      'Look for Bias: Question whether generated answers contain one-sided perspectives or unfair omissions.',
      'Keep Humans Involved: Retain meaningful human judgment for all high-stakes decisions.',
    ],
    visualElements: ['Shield/checklist card container', 'Aqua checkmark circles', 'Horizontal rule dividers'],
    sourceCitations: [
      {
        source: 'UNESCO Ethics of AI Recommendation',
        url: 'https://unesdoc.unesco.org/in/rest/annotationSVC/DownloadWatermarkedAttachment/attach_import_761bcdad-d1e3-40c9-819d-03c4ac725f26?_=376709eng.pdf&from=8&to=40',
        detail: 'Human agency, privacy protection, and transparent accountability.',
      },
    ],
    canvaSpecs: {
      coordinates: 'X: 40px, Y: 1705px (Width: 720px)',
      height: '170px',
      fonts: 'Space Grotesk 11.5pt, Inter 11.5pt',
      colors: ['#162238', '#48D9D0', '#3867FF', '#FFFFFF'],
      iconKeywords: ['shield checkmark', 'lock security line', 'balance scales', 'hand holding human icon'],
    },
  },
  {
    id: 'section-7',
    number: '07',
    title: 'FINAL TAKEAWAY & CITATIONS',
    subtitle: 'Closing Philosophy & Source Attribution',
    yRange: { start: 1880, end: 2000 },
    summary:
      'Memorable closing takeaway emphasizing that AI is an assistive instrument, paired with compact citations of NIST, UNESCO, and FDA references and designer attribution.',
    keyTakeaways: [
      'Closing Maxim: "AI is a tool. Human judgment still matters."',
      'Core Guidance: "Understand the data · Question the output · Use intelligence responsibly."',
      'Transparent verification via NIST, UNESCO, and FDA sources.',
      'Designed by Neha Vinod Borkar for Oasis Infobyte Graphics Design Internship.',
    ],
    visualElements: ['Gradient bottom rule', 'Space Grotesk closing display type', 'Dark citation metadata strip'],
    sourceCitations: [
      { source: 'NIST CSRC AI Glossary', url: 'https://csrc.nist.gov/glossary/term/artificial_intelligence', detail: 'AI definition' },
      { source: 'NIST SP 1270', url: 'https://www.nist.gov/system/files/documents/2021/10/04/explaining-decisions-made-with-artificial-intelligence-1-0.pdf', detail: 'Bias and Explainability' },
      { source: 'UNESCO AI & Education', url: 'https://unesdoc.unesco.org/', detail: 'Ethical education policy' },
      { source: 'FDA AI Glossary', url: 'https://www.fda.gov/', detail: 'Taxonomy of ML and DL' },
    ],
    canvaSpecs: {
      coordinates: 'X: 40px, Y: 1880px (Width: 720px)',
      height: '110px',
      fonts: 'Space Grotesk 15pt, Space Grotesk 12pt, Inter 8.8pt',
      colors: ['#0D1422', '#48D9D0', '#FFFFFF', '#3867FF'],
      iconKeywords: ['quote mark line', 'copyright watermark clean'],
    },
  },
];

export const SOURCES_LIST: FactSource[] = [
  {
    id: 'nist-glossary',
    name: 'NIST AI Terminology & Glossary',
    organization: 'National Institute of Standards and Technology (U.S. Dept of Commerce)',
    documentTitle: 'CSRC Glossary: Artificial Intelligence (2023)',
    url: 'https://csrc.nist.gov/glossary/term/artificial_intelligence',
    relevance:
      'Supplied the authoritative definition of AI as machine-based systems generating predictions, recommendations, or decisions.',
    verifiedQuotes: [
      'An information system that can generate outputs such as predictions, recommendations, or decisions for a given set of human-defined objectives.',
      'AI systems use machine and human-based data and inputs to perceive real and virtual environments, abstract such perceptions into models, and make decisions.',
    ],
    appliedToSections: ['Section 1 (What Is AI?)', 'Section 2 (From Data to Decisions)'],
  },
  {
    id: 'nist-bias-sp1270',
    name: 'NIST Special Publication SP 1270',
    organization: 'National Institute of Standards and Technology (NIST)',
    documentTitle: 'Towards a Standard for Identifying and Managing Bias in Artificial Intelligence (2022)',
    url: 'https://www.nist.gov/system/files/documents/2021/10/04/explaining-decisions-made-with-artificial-intelligence-1-0.pdf',
    relevance:
      'Informed the analysis of systemic bias, algorithmic explainability, and human-in-the-loop oversight requirements.',
    verifiedQuotes: [
      'Managing the risk of bias in AI requires a sociotechnical approach that addresses data, algorithms, and human-system interactions.',
      'Context matters: decisions generated with AI assistance require appropriate explanation and continuous monitoring.',
    ],
    appliedToSections: ['Section 5 (Two Sides of AI)', 'Section 6 (Responsible AI)'],
  },
  {
    id: 'unesco-ai-education',
    name: 'UNESCO AI and Education Guidance',
    organization: 'United Nations Educational, Scientific and Cultural Organization',
    documentTitle: 'AI and Education: Guidance for Policy-makers (2021)',
    url: 'https://unesdoc.unesco.org/in/rest/annotationSVC/DownloadWatermarkedAttachment/attach_import_761bcdad-d1e3-40c9-819d-03c4ac725f26?_=376709eng.pdf&from=8&to=40',
    relevance:
      'Guided educational use cases, student data privacy safeguards, and ethics of automated grading/pacing tools.',
    verifiedQuotes: [
      'AI in education must be centered on the protection of human agency, personal data privacy, and inclusion.',
      'Educators and students should develop critical AI literacy to evaluate AI-generated outputs thoughtfully.',
    ],
    appliedToSections: ['Section 4 (AI Around Us - Education)', 'Section 6 (Use AI Wisely)'],
  },
  {
    id: 'fda-ai-glossary',
    name: 'FDA Digital Health and AI Glossary',
    organization: 'U.S. Food and Drug Administration (CDRH)',
    documentTitle: 'Digital Health and Artificial Intelligence Glossary: Educational Resource (2023)',
    url: 'https://www.fda.gov/science-research/artificial-intelligence-and-medical-products/fda-digital-health-and-artificial-intelligence-glossary-educational-resource',
    relevance:
      'Grounded the taxonomy of Machine Learning vs Deep Learning neural networks and medical decision-support examples.',
    verifiedQuotes: [
      'Machine Learning: An AI technique that uses algorithms to parse data, learn from it, and make determinations without manual programming.',
      'Deep Learning: A subset of machine learning based on artificial neural networks with multiple layers.',
    ],
    appliedToSections: ['Section 3 (Meet the AI Family)', 'Section 4 (Healthcare Application)'],
  },
];
