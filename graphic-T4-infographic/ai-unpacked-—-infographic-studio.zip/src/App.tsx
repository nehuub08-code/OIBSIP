import React, { useState } from 'react';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  ListFilter,
  Download,
  Info,
  CheckCircle2,
  ExternalLink,
  Layers,
} from 'lucide-react';
import { TopNav, ActiveTab } from './components/TopNav';
import { InfographicCanvas } from './components/InfographicCanvas';
import { SectionInspector } from './components/SectionInspector';
import { CanvaBlueprintView } from './components/CanvaBlueprintView';
import { SourcesView } from './components/SourcesView';
import { RepoFilesView } from './components/RepoFilesView';
import { ExportModal } from './components/ExportModal';
import { SECTIONS, DESIGNER_INFO } from './data/infographicData';
import { InfographicSection } from './types/infographic';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('canvas');
  const [zoomLevel, setZoomLevel] = useState<number>(0.85); // Default to comfortable screen fit
  const [selectedSection, setSelectedSection] = useState<InfographicSection | null>(SECTIONS[1]); // Default to Section 01
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  const handleZoom = (delta: number) => {
    setZoomLevel((prev) => Math.min(Math.max(Number((prev + delta).toFixed(2)), 0.4), 1.75));
  };

  const handleFitScreen = () => {
    // 800px width fitted to typical 1000px container ~ 0.85 - 0.9
    setZoomLevel(0.85);
  };

  const handleActualSize = () => {
    setZoomLevel(1.0); // Exact 800px width
  };

  const scrollToSection = (section: InfographicSection) => {
    setSelectedSection(section);
    // Find canvas container and scroll to relative position
    const container = document.getElementById('canvas-scroll-container');
    if (container) {
      const targetY = section.yRange.start * zoomLevel;
      container.scrollTo({ top: targetY, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0b101b] text-slate-100 flex flex-col font-sans selection:bg-[#3867FF] selection:text-white">
      {/* 3-Zone Top Navigation Contract */}
      <TopNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenExport={() => setIsExportModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col">
        {activeTab === 'canvas' && (
          <div className="flex-1 flex flex-col">
            {/* Studio Workspace Toolbar */}
            <div className="border-b border-slate-800 bg-[#101828]/80 backdrop-blur px-6 py-2.5 flex flex-wrap items-center justify-between gap-4">
              {/* Left Zone: Section Quick Selector */}
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 text-xs text-slate-400">
                  <ListFilter className="w-3.5 h-3.5 text-[#48D9D0]" />
                  <span className="hidden sm:inline">Jump to Section:</span>
                </div>
                <div className="flex items-center gap-1 overflow-x-auto max-w-xl py-0.5">
                  {SECTIONS.map((sec) => (
                    <button
                      key={sec.id}
                      onClick={() => scrollToSection(sec)}
                      className={`px-2.5 py-1 text-xs rounded-md font-medium transition-all whitespace-nowrap shrink-0 ${
                        selectedSection?.id === sec.id
                          ? 'bg-[#3867FF] text-white shadow-sm shadow-[#3867FF]/30 font-semibold'
                          : 'bg-[#162238] text-slate-300 hover:text-white hover:bg-[#1e2e4c]'
                      }`}
                    >
                      <span>{sec.number}</span>
                      <span className="hidden md:inline ml-1">· {sec.title.split(':')[0]}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Right Zone: Zoom & Canvas Actions */}
              <div className="flex items-center gap-2">
                <div className="flex items-center bg-[#162238] rounded-lg p-1 border border-slate-800">
                  <button
                    onClick={() => handleZoom(-0.15)}
                    className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-700 transition-colors"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-4 h-4" />
                  </button>
                  <span className="text-xs font-mono text-slate-300 px-2 min-w-[50px] text-center">
                    {Math.round(zoomLevel * 100)}%
                  </span>
                  <button
                    onClick={() => handleZoom(0.15)}
                    className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-700 transition-colors"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </button>
                </div>

                <button
                  onClick={handleFitScreen}
                  className="px-2.5 py-1.5 text-xs rounded-lg bg-[#162238] hover:bg-[#1e2e4c] text-slate-300 hover:text-white border border-slate-800 transition-colors"
                  title="Fit to Screen width"
                >
                  Fit
                </button>

                <button
                  onClick={handleActualSize}
                  className="px-2.5 py-1.5 text-xs rounded-lg bg-[#162238] hover:bg-[#1e2e4c] text-slate-300 hover:text-white border border-slate-800 transition-colors"
                  title="100% Actual 800px Width"
                >
                  100%
                </button>

                <button
                  onClick={() => setIsExportModalOpen(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#3867FF] hover:bg-[#4a77ff] text-white transition-colors ml-2"
                >
                  <Download className="w-3.5 h-3.5 text-[#48D9D0]" />
                  <span className="hidden sm:inline">Export</span>
                </button>
              </div>
            </div>

            {/* Split Workspace: Left Canvas, Right Inspector */}
            <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
              {/* Canvas Scroll Stage */}
              <div
                id="canvas-scroll-container"
                className="flex-1 overflow-auto p-4 sm:p-8 flex justify-center bg-[#070b13] relative"
              >
                <div className="py-4">
                  <InfographicCanvas
                    selectedSection={selectedSection}
                    onSelectSection={setSelectedSection}
                    zoomLevel={zoomLevel}
                  />
                </div>
              </div>

              {/* Right Sidebar: Section Inspector & Designer Dossier */}
              <div className="w-full lg:w-[420px] xl:w-[460px] bg-[#0c121f] border-t lg:border-t-0 lg:border-l border-slate-800 p-4 sm:p-6 shrink-0 flex flex-col overflow-y-auto">
                {selectedSection ? (
                  <SectionInspector
                    section={selectedSection}
                    onClose={() => setSelectedSection(null)}
                    onSelectSection={setSelectedSection}
                  />
                ) : (
                  <div className="h-full flex flex-col justify-center items-center text-center p-8 border border-dashed border-slate-800 rounded-xl space-y-4">
                    <div className="w-12 h-12 rounded-full bg-[#3867FF]/10 text-[#48D9D0] flex items-center justify-center">
                      <Layers className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-white font-heading">
                        Interactive Section Inspector
                      </h3>
                      <p className="text-xs text-slate-400 mt-1 max-w-xs">
                        Click on any section of the 800 × 2000 px infographic on the left to inspect its learning objectives, Canva coordinates, and verified citations.
                      </p>
                    </div>
                    <button
                      onClick={() => setSelectedSection(SECTIONS[1])}
                      className="px-4 py-2 bg-[#162238] hover:bg-[#1f2f4c] text-[#48D9D0] text-xs font-semibold rounded-lg border border-[#3867FF]/30 transition-colors"
                    >
                      Inspect Section 01 (What is AI?)
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'canva-guide' && <CanvaBlueprintView />}
        {activeTab === 'sources' && <SourcesView />}
        {activeTab === 'files' && <RepoFilesView />}
      </main>

      {/* Persistent Designer & Task Attribution Footer */}
      <footer className="bg-[#080d16] border-t border-slate-800/80 px-6 py-3 text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-white">{DESIGNER_INFO.name}</span>
          <span>·</span>
          <span>{DESIGNER_INFO.internship}</span>
          <span>·</span>
          <span className="text-[#48D9D0]">{DESIGNER_INFO.taskTitle}</span>
        </div>

        <div className="flex items-center gap-4 text-[11px]">
          <span>Dimensions: 800 × 2000 px</span>
          <span>·</span>
          <span>Min 150 DPI Verified</span>
          <span>·</span>
          <span className="text-[#3867FF] font-mono">Palette: 4 Colors Max</span>
        </div>
      </footer>

      {/* Export Deliverables Modal */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
      />
    </div>
  );
}
