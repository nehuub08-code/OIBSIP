export interface InfographicSection {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  yRange: { start: number; end: number };
  summary: string;
  keyTakeaways: string[];
  visualElements: string[];
  sourceCitations: {
    source: string;
    url: string;
    detail: string;
  }[];
  canvaSpecs: {
    coordinates: string;
    height: string;
    fonts: string;
    colors: string[];
    iconKeywords: string[];
  };
}

export interface FactSource {
  id: string;
  name: string;
  organization: string;
  documentTitle: string;
  url: string;
  relevance: string;
  verifiedQuotes: string[];
  appliedToSections: string[];
}
