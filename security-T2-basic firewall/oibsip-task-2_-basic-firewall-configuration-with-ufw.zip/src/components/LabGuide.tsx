import React, { useState } from 'react';
import { Network, Server, ShieldCheck, Terminal, Copy, Check, AlertTriangle, ArrowRight } from 'lucide-react';

export const LabGuide: React.FC = () => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center gap-2 text-emerald-400 text-sm font-semibold tracking-wider uppercase mb-1">
          <Network className="w-4 h-4" />
          Virtual Machine Architecture & Safety
        </div>
        <h2 className="text-2xl font-bold text-white">VirtualBox Isolated Lab Setup Guide</h2>
        <p className="text-slate-400 text-sm mt-1">
          How to configure Ubuntu or Kali Linux in VirtualBox, isolate network traffic, prevent administrative lockout, and verify UFW safely.
        </p>
      </div>

      {/* Network Modes Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Host-Only (Recommended) */}
        <div className="p-5 rounded-xl border border-emerald-500/40 bg-slate-900/90 relative">
          <div className="absolute top-3 right-3 text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            Recommended
          </div>
          <div className="w-10 h-10 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-3">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">Host-Only Network</h3>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Creates a private virtual subnet (e.g. <code className="text-emerald-400">192.168.56.0/24</code>) between your host PC and VM. Zero internet exposure.
          </p>
          <div className="mt-4 pt-3 border-t border-slate-800 text-xs text-slate-300 space-y-1">
            <div>• Perfect for controlled firewall tests</div>
            <div>• Safe: Denied ports won&apos;t affect LAN</div>
            <div>• Enables clean client-to-target testing</div>
          </div>
        </div>

        {/* NAT Mode */}
        <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/60">
          <div className="w-10 h-10 rounded-lg bg-slate-800 text-slate-300 flex items-center justify-center mb-3">
            <Server className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">NAT Network</h3>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Allows the VM to access the outside internet through your host IP, but hides the VM behind a NAT gateway.
          </p>
          <div className="mt-4 pt-3 border-t border-slate-800 text-xs text-slate-400 space-y-1">
            <div>• Good for apt-get package downloads</div>
            <div>• Inbound traffic cannot reach VM directly without port forwarding</div>
          </div>
        </div>

        {/* Bridged Mode */}
        <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/60">
          <div className="w-10 h-10 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center mb-3">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">Bridged Adapter</h3>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Attaches the VM directly to your physical router Wi-Fi / Ethernet, acquiring a real LAN IP address.
          </p>
          <div className="mt-4 pt-3 border-t border-slate-800 text-xs text-slate-400 space-y-1">
            <div>• Exposes VM directly to your home LAN</div>
            <div>• Not recommended during raw port blocking tests</div>
          </div>
        </div>
      </div>

      {/* Step by Step Walkthrough */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-white">Step-by-Step Lab Execution</h3>

        {/* Step 1 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold font-mono">1</span>
              <h4 className="text-sm font-bold text-white">Take a VM Snapshot Before Changes</h4>
            </div>
          </div>
          <p className="text-xs text-slate-400 mb-3">
            In VirtualBox, select your Ubuntu/Kali VM, click <strong>Machine → Take Snapshot</strong>, and label it <code className="text-emerald-400">Pre-UFW-Baseline</code>. If any networking issue occurs, you can restore to this state instantly.
          </p>
        </div>

        {/* Step 2 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold font-mono">2</span>
              <h4 className="text-sm font-bold text-white">Inspect System & Check UFW Package</h4>
            </div>
            <button
              onClick={() => copyToClipboard('cat /etc/os-release && which ufw || sudo apt install -y ufw', 's2')}
              className="text-xs text-slate-400 hover:text-white flex items-center gap-1 font-mono"
            >
              {copiedCmd === 's2' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              Copy
            </button>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-xs text-slate-300">
            $ cat /etc/os-release<br />
            $ sudo apt update &amp;&amp; sudo apt install -y ufw
          </div>
        </div>

        {/* Step 3 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold font-mono">3</span>
              <h4 className="text-sm font-bold text-white">Validate & Execute ufw_configuration.sh</h4>
            </div>
            <button
              onClick={() => copyToClipboard('chmod +x ufw_configuration.sh && sudo ./ufw_configuration.sh', 's3')}
              className="text-xs text-slate-400 hover:text-white flex items-center gap-1 font-mono"
            >
              {copiedCmd === 's3' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              Copy
            </button>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-xs text-slate-300">
            $ chmod +x ufw_configuration.sh<br />
            $ bash -n ufw_configuration.sh  # (Verifies syntax without running)<br />
            $ sudo ./ufw_configuration.sh
          </div>
        </div>

        {/* Step 4 */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold font-mono">4</span>
              <h4 className="text-sm font-bold text-white">Run Empirical Traffic-Blocking Tests</h4>
            </div>
            <button
              onClick={() => copyToClipboard('sudo python3 -m http.server 80 --bind 192.168.56.101', 's4')}
              className="text-xs text-slate-400 hover:text-white flex items-center gap-1 font-mono"
            >
              {copiedCmd === 's4' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              Copy
            </button>
          </div>
          <div className="space-y-2">
            <div className="text-xs text-slate-400">On Target VM (start test listener):</div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800 font-mono text-xs text-slate-300">
              $ sudo python3 -m http.server 80 --bind &lt;TARGET_IP&gt;
            </div>
            <div className="text-xs text-slate-400">On Client Machine / Host (send probe):</div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800 font-mono text-xs text-slate-300">
              $ curl --connect-timeout 3 -v http://&lt;TARGET_IP&gt;/<br />
              <span className="text-rose-400"># Result: Connection timed out after 3001ms</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
