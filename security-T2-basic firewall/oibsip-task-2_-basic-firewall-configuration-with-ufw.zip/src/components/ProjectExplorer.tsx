import React, { useState } from 'react';
import { FileCode, FileText, Download, Copy, Check, Folder, ChevronRight, Terminal, Shield } from 'lucide-react';
import { PROJECT_FILES, ProjectFile } from '../data/projectFiles';

export const ProjectExplorer: React.FC = () => {
  const [activeFile, setActiveFile] = useState<ProjectFile>(PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([activeFile.content], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = activeFile.name;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 text-sm font-semibold tracking-wider uppercase mb-1">
              <Folder className="w-4 h-4" />
              OIBSIP Task 2 Workspace Explorer
            </div>
            <h2 className="text-2xl font-bold text-white">Repository Files & Deliverables</h2>
            <p className="text-slate-400 text-sm mt-1">
              Inspect, copy, or download the exact configuration scripts, rule tables, test matrices, and security reports.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-sm font-medium transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Copy File
                </>
              )}
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-sm font-medium transition-colors shadow-md shadow-emerald-950"
            >
              <Download className="w-4 h-4" />
              Download {activeFile.name}
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        {/* File Navigator Sidebar */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-2 mb-2 flex items-center justify-between">
            <span>Project Tree</span>
            <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-300">6 Files</span>
          </div>
          <div className="space-y-1">
            {PROJECT_FILES.map(file => {
              const isSelected = activeFile.name === file.name;
              const isScript = file.name.endsWith('.sh');
              return (
                <button
                  key={file.name}
                  onClick={() => setActiveFile(file)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg flex items-center justify-between transition-all ${
                    isSelected
                      ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-500/30'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    {isScript ? (
                      <Terminal className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <FileText className="w-4 h-4 text-slate-400 shrink-0" />
                    )}
                    <span className="text-sm font-mono truncate">{file.name}</span>
                  </div>
                  <ChevronRight
                    className={`w-4 h-4 transition-transform shrink-0 ${
                      isSelected ? 'text-emerald-400 rotate-90' : 'text-slate-600'
                    }`}
                  />
                </button>
              );
            })}
          </div>

          <div className="pt-4 mt-4 border-t border-slate-800 px-2">
            <div className="text-xs font-semibold text-slate-400 mb-2">Target File Path:</div>
            <div className="text-[11px] font-mono text-slate-500 break-all bg-slate-950 p-2 rounded border border-slate-800">
              /{activeFile.path}
            </div>
          </div>
        </div>

        {/* Code Viewer Panel */}
        <div className="lg:col-span-3 bg-slate-950 border border-slate-800 rounded-xl overflow-hidden flex flex-col">
          <div className="bg-slate-900/90 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="font-mono text-sm font-bold text-white flex items-center gap-2">
                <FileCode className="w-4 h-4 text-emerald-400" />
                {activeFile.name}
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                {activeFile.category}
              </span>
            </div>
            <span className="text-xs text-slate-400 hidden sm:inline">{activeFile.description}</span>
          </div>

          <div className="p-4 bg-slate-950 overflow-x-auto text-xs font-mono leading-relaxed text-slate-300 max-h-[520px]">
            <pre className="select-text whitespace-pre">
              <code>{activeFile.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
