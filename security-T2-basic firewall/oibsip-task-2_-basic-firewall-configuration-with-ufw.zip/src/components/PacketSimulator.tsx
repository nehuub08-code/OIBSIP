import React, { useState } from 'react';
import { Shield, ShieldAlert, ShieldCheck, Play, RefreshCw, AlertCircle, Terminal, ArrowRight, CheckCircle2, XCircle } from 'lucide-react';

interface PacketTest {
  id: string;
  name: string;
  port: number;
  proto: 'TCP' | 'UDP';
  service: string;
  expectedAction: 'ALLOW' | 'DENY';
  ruleMatched: string;
  clientCommand: string;
  explanation: string;
}

const PRESET_PACKETS: PacketTest[] = [
  {
    id: 'ssh-22',
    name: 'SSH Administration (Rule 1)',
    port: 22,
    proto: 'TCP',
    service: 'OpenSSH Server (sshd)',
    expectedAction: 'ALLOW',
    ruleMatched: 'Rule 1: ufw allow 22/tcp',
    clientCommand: 'ssh -o ConnectTimeout=3 user@192.168.56.101',
    explanation: 'Preserves remote administrative access. Whitelisted before UFW activation to prevent SSH lockout.'
  },
  {
    id: 'http-80',
    name: 'Unencrypted HTTP (Rule 2 - Required Deny)',
    port: 80,
    proto: 'TCP',
    service: 'Python3 HTTP Test Server',
    expectedAction: 'DENY',
    ruleMatched: 'Rule 2: ufw deny 80/tcp',
    clientCommand: 'curl --connect-timeout 3 -v http://192.168.56.101/',
    explanation: 'Blocks cleartext HTTP. Demonstrates negative filtering: even with a listening socket on port 80, UFW intercepts and drops the packet.'
  },
  {
    id: 'https-443',
    name: 'Encrypted HTTPS (Rule 3 - Additional Allow)',
    port: 443,
    proto: 'TCP',
    service: 'TLS Web Server (Pending daemon)',
    expectedAction: 'ALLOW',
    ruleMatched: 'Rule 3: ufw allow 443/tcp',
    clientCommand: 'curl --connect-timeout 3 -vk https://192.168.56.101/',
    explanation: 'Permits encrypted TLS traffic. Note that opening port 443 does not spawn a web daemon unless Nginx/Apache is running.'
  },
  {
    id: 'app-8080',
    name: 'Alternate App Port (Rule 4 - Additional Deny)',
    port: 8080,
    proto: 'TCP',
    service: 'Development / Tomcat Test Listener',
    expectedAction: 'DENY',
    ruleMatched: 'Rule 4: ufw deny 8080/tcp',
    clientCommand: 'nc -zv -w 3 192.168.56.101 8080',
    explanation: 'Blocks unauthorized application or staging ports commonly used by internal test tools.'
  },
  {
    id: 'ftp-21',
    name: 'FTP Service (Unlisted Port)',
    port: 21,
    proto: 'TCP',
    service: 'vsftpd Daemon',
    expectedAction: 'DENY',
    ruleMatched: 'Default Ingress Policy: DENY (Least Privilege)',
    clientCommand: 'nc -zv -w 3 192.168.56.101 21',
    explanation: 'No specific rule exists. UFW falls back to the Default-Deny Incoming baseline, dropping the connection.'
  }
];

export const PacketSimulator: React.FC = () => {
  const [selectedPacket, setSelectedPacket] = useState<PacketTest>(PRESET_PACKETS[1]); // default to HTTP 80
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulationStep, setSimulationStep] = useState<number>(0);
  const [simLog, setSimLog] = useState<string[]>([]);
  const [customPort, setCustomPort] = useState<string>('80');
  const [customProto, setCustomProto] = useState<'TCP' | 'UDP'>('TCP');

  const runSimulation = (packet: PacketTest) => {
    setIsSimulating(true);
    setSimulationStep(1);
    setSimLog([`[T+0ms] Client 192.168.56.102 generates SYN packet to 192.168.56.101:${packet.port}/${packet.proto}`]);

    setTimeout(() => {
      setSimulationStep(2);
      setSimLog(prev => [
        ...prev,
        `[T+12ms] Packet arrives at Virtual Switch (vboxnet0) and reaches Target VM NIC (enp0s8)`,
        `[T+15ms] Linux Kernel Netfilter receives packet in PREROUTING chain -> forwards to INPUT chain`
      ]);
    }, 700);

    setTimeout(() => {
      setSimulationStep(3);
      if (packet.expectedAction === 'ALLOW') {
        setSimLog(prev => [
          ...prev,
          `[T+22ms] UFW Rule Evaluation: MATCH FOUND [${packet.ruleMatched}] -> ACTION: ACCEPT`,
          `[T+28ms] Packet forwarded to local transport layer socket (Listening service: ${packet.service})`,
          `[T+35ms] Target transmits SYN-ACK response back to client`,
          `[T+42ms] Handshake ESTABLISHED! Connection status: SUCCESS`
        ]);
      } else {
        setSimLog(prev => [
          ...prev,
          `[T+22ms] UFW Rule Evaluation: MATCH FOUND [${packet.ruleMatched}] -> ACTION: DROP`,
          `[T+25ms] Netfilter kernel log recorded: [UFW BLOCK] IN=enp0s8 OUT= SRC=192.168.56.102 DST=192.168.56.101 PROTO=${packet.proto} SPT=53421 DPT=${packet.port}`,
          `[T+1000ms] Client waiting for SYN-ACK... (No response received)`,
          `[T+3000ms] Client probe timed out after 3000ms. Result: CONNECTION BLOCKED AS ENFORCED`
        ]);
      }
      setIsSimulating(false);
    }, 1500);
  };

  const handleCustomTest = () => {
    const portNum = parseInt(customPort, 10);
    if (isNaN(portNum) || portNum < 1 || portNum > 65535) return;

    let action: 'ALLOW' | 'DENY' = 'DENY';
    let ruleMatched = 'Default Ingress Policy: DENY';
    let service = 'Unknown Port Service';

    if (portNum === 22 && customProto === 'TCP') {
      action = 'ALLOW';
      ruleMatched = 'Rule 1: ufw allow 22/tcp';
      service = 'OpenSSH Server';
    } else if (portNum === 80 && customProto === 'TCP') {
      action = 'DENY';
      ruleMatched = 'Rule 2: ufw deny 80/tcp';
      service = 'HTTP Web Server';
    } else if (portNum === 443 && customProto === 'TCP') {
      action = 'ALLOW';
      ruleMatched = 'Rule 3: ufw allow 443/tcp';
      service = 'HTTPS Secure Server';
    } else if (portNum === 8080 && customProto === 'TCP') {
      action = 'DENY';
      ruleMatched = 'Rule 4: ufw deny 8080/tcp';
      service = 'Alternate App Server';
    }

    const test: PacketTest = {
      id: `custom-${portNum}`,
      name: `Custom Port ${portNum}/${customProto}`,
      port: portNum,
      proto: customProto,
      service,
      expectedAction: action,
      ruleMatched,
      clientCommand: `nc -zv -w 3 192.168.56.101 ${portNum}`,
      explanation: `Evaluating custom packet on port ${portNum} against UFW configuration table.`
    };

    setSelectedPacket(test);
    runSimulation(test);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 text-sm font-semibold tracking-wider uppercase mb-1">
              <Shield className="w-4 h-4" />
              Phase 10 Interactive Netfilter Simulation
            </div>
            <h2 className="text-2xl font-bold text-white">UFW Inbound Traffic Control Simulator</h2>
            <p className="text-slate-400 text-sm mt-1">
              Test how UFW evaluates inbound packets against the four configured rules and default deny policy.
            </p>
          </div>
          <button
            onClick={() => runSimulation(selectedPacket)}
            disabled={isSimulating}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-lg font-medium transition-all ${
              isSimulating
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/30'
            }`}
          >
            {isSimulating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Filtering Packets...
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                Inject Test Packet
              </>
            )}
          </button>
        </div>
      </div>

      {/* Preset Packet Selector Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {PRESET_PACKETS.map(packet => {
          const isSelected = selectedPacket.id === packet.id;
          const isAllow = packet.expectedAction === 'ALLOW';
          return (
            <button
              key={packet.id}
              onClick={() => {
                setSelectedPacket(packet);
                runSimulation(packet);
              }}
              className={`p-4 rounded-xl border text-left transition-all relative overflow-hidden ${
                isSelected
                  ? 'border-emerald-500/80 bg-slate-900 shadow-md ring-1 ring-emerald-500/40'
                  : 'border-slate-800 bg-slate-950/70 hover:border-slate-700 hover:bg-slate-900/50'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-mono text-sm font-bold text-white">
                  Port {packet.port}/{packet.proto}
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-xs font-semibold ${
                    isAllow
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                      : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                  }`}
                >
                  {packet.expectedAction}
                </span>
              </div>
              <div className="text-xs font-medium text-slate-300 truncate">{packet.name}</div>
              <div className="text-[11px] text-slate-500 mt-1 truncate">{packet.service}</div>
            </button>
          );
        })}
      </div>

      {/* Custom Packet Injector */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center gap-4 text-sm">
        <span className="text-slate-300 font-medium flex items-center gap-1.5">
          <Terminal className="w-4 h-4 text-emerald-400" />
          Test Any Port:
        </span>
        <div className="flex items-center gap-2">
          <label className="text-slate-400 text-xs">Port:</label>
          <input
            type="number"
            min="1"
            max="65535"
            value={customPort}
            onChange={e => setCustomPort(e.target.value)}
            className="w-24 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-white font-mono text-sm focus:outline-none focus:border-emerald-500"
          />
        </div>
        <div className="flex items-center gap-2">
          <label className="text-slate-400 text-xs">Protocol:</label>
          <select
            value={customProto}
            onChange={e => setCustomProto(e.target.value as 'TCP' | 'UDP')}
            className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-white font-mono text-sm focus:outline-none focus:border-emerald-500"
          >
            <option value="TCP">TCP</option>
            <option value="UDP">UDP</option>
          </select>
        </div>
        <button
          onClick={handleCustomTest}
          disabled={isSimulating}
          className="px-3.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition-colors"
        >
          Evaluate Custom Port
        </button>
      </div>

      {/* Visual Network & Netfilter Flow Pipeline */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <h3 className="text-base font-semibold text-white mb-4 flex items-center justify-between">
          <span>Packet Inspection Pipeline</span>
          <span className="text-xs text-slate-400 font-mono">
            Host: 192.168.56.101 (Ubuntu Target) | Client: 192.168.56.102
          </span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          {/* Node 1: Client Machine */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-950 text-center relative">
            <div className="w-10 h-10 mx-auto rounded-full bg-slate-800 flex items-center justify-center text-slate-300 mb-2">
              <Terminal className="w-5 h-5" />
            </div>
            <div className="text-sm font-semibold text-white">Client VM / Host</div>
            <div className="text-xs font-mono text-slate-400 mt-0.5">192.168.56.102</div>
            <div className="mt-3 p-2 bg-slate-900/90 rounded border border-slate-800 text-[11px] font-mono text-slate-300 text-left truncate">
              $ {selectedPacket.clientCommand}
            </div>
          </div>

          {/* Node 2: Network Switch */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-950 text-center relative">
            <div className="w-10 h-10 mx-auto rounded-full bg-slate-800 flex items-center justify-center text-slate-300 mb-2">
              <ArrowRight className="w-5 h-5" />
            </div>
            <div className="text-sm font-semibold text-white">VirtualBox Switch</div>
            <div className="text-xs font-mono text-slate-400 mt-0.5">vboxnet0 (Host-Only)</div>
            <div className="mt-3 text-[11px] text-slate-400">
              Isolated Layer 2 Segment
            </div>
          </div>

          {/* Node 3: UFW / Netfilter Ingress Barrier */}
          <div
            className={`p-4 rounded-xl border text-center transition-all ${
              selectedPacket.expectedAction === 'ALLOW'
                ? 'border-emerald-500/50 bg-emerald-950/20'
                : 'border-rose-500/50 bg-rose-950/20'
            }`}
          >
            <div
              className={`w-10 h-10 mx-auto rounded-full flex items-center justify-center mb-2 ${
                selectedPacket.expectedAction === 'ALLOW'
                  ? 'bg-emerald-500/20 text-emerald-400'
                  : 'bg-rose-500/20 text-rose-400'
              }`}
            >
              {selectedPacket.expectedAction === 'ALLOW' ? (
                <ShieldCheck className="w-5 h-5" />
              ) : (
                <ShieldAlert className="w-5 h-5" />
              )}
            </div>
            <div className="text-sm font-semibold text-white">UFW Netfilter Engine</div>
            <div
              className={`text-xs font-semibold mt-0.5 ${
                selectedPacket.expectedAction === 'ALLOW' ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {selectedPacket.expectedAction === 'ALLOW' ? 'PACKET ACCEPTED' : 'PACKET DROPPED'}
            </div>
            <div className="mt-3 text-[11px] font-mono text-slate-300 bg-slate-900/90 p-1.5 rounded border border-slate-800 truncate">
              {selectedPacket.ruleMatched}
            </div>
          </div>

          {/* Node 4: Target Service Socket */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-950 text-center relative">
            <div className="w-10 h-10 mx-auto rounded-full bg-slate-800 flex items-center justify-center text-slate-300 mb-2">
              {selectedPacket.expectedAction === 'ALLOW' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              ) : (
                <XCircle className="w-5 h-5 text-slate-500" />
              )}
            </div>
            <div className="text-sm font-semibold text-white">Local Socket</div>
            <div className="text-xs font-mono text-slate-400 mt-0.5">:{selectedPacket.port} ({selectedPacket.proto})</div>
            <div className="mt-3 text-[11px] text-slate-400">
              {selectedPacket.expectedAction === 'ALLOW' ? (
                <span className="text-emerald-400 font-medium">Traffic Reaches Daemon</span>
              ) : (
                <span className="text-rose-400 font-medium">Socket Unreachable (Blocked)</span>
              )}
            </div>
          </div>
        </div>

        {/* Explanation Card */}
        <div className="mt-5 p-4 bg-slate-950/80 rounded-lg border border-slate-800 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="text-sm">
            <span className="font-semibold text-white">Security Analyst Insight: </span>
            <span className="text-slate-300">{selectedPacket.explanation}</span>
          </div>
        </div>
      </div>

      {/* Terminal Real-Time Audit & Kernel Log Output */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden font-mono text-xs">
        <div className="bg-slate-900 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-rose-500/80" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
            <span className="text-slate-400 ml-2">Kernel Netfilter / UFW Real-Time Packet Trace</span>
          </div>
          <span className="text-slate-500 text-[11px]">/var/log/ufw.log</span>
        </div>
        <div className="p-4 space-y-1.5 max-h-56 overflow-y-auto text-slate-300">
          {simLog.length === 0 ? (
            <div className="text-slate-600 italic">
              Click &quot;Inject Test Packet&quot; above to trigger a simulated packet traversal and inspect kernel drop/accept logs.
            </div>
          ) : (
            simLog.map((line, idx) => {
              const isBlock = line.includes('[UFW BLOCK]');
              const isEstablished = line.includes('ESTABLISHED');
              return (
                <div
                  key={idx}
                  className={`leading-relaxed ${
                    isBlock
                      ? 'text-rose-400 bg-rose-950/20 px-2 py-0.5 rounded font-bold'
                      : isEstablished
                      ? 'text-emerald-400 font-bold'
                      : 'text-slate-300'
                  }`}
                >
                  {line}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
