import React, { useState } from 'react';
import { CheckCircle2, Clock, AlertCircle, FileCheck, ArrowUpRight, Copy, Check, Terminal } from 'lucide-react';

interface ChecklistItem {
  id: string;
  deliverable: string;
  status: 'Completed' | 'Ready for Lab Execution' | 'Pending Lab Session';
  evidence: string;
  actionRequired: string;
}

const CHECKLIST_ITEMS: ChecklistItem[] = [
  {
    id: 'c1',
    deliverable: 'ufw_configuration.sh created',
    status: 'Completed',
    evidence: 'Script created in OIBSIP/SecurityAnalyst/Task2_UFW_Firewall_Configuration/',
    actionRequired: 'Fully implemented with strict error handling, authorization checks, and lockout safety.'
  },
  {
    id: 'c2',
    deliverable: 'Script syntax checked (bash -n)',
    status: 'Completed',
    evidence: 'Verified via bash -n: zero syntax errors',
    actionRequired: 'Syntax verified. Script is ready for execution with sudo.'
  },
  {
    id: 'c3',
    deliverable: 'Required rules configured (SSH 22 & HTTP 80)',
    status: 'Completed',
    evidence: 'Encoded in ufw_configuration.sh and documented in firewall_rules.txt',
    actionRequired: 'Rules will be applied to kernel Netfilter when script runs in VM.'
  },
  {
    id: 'c4',
    deliverable: 'Two additional rules configured (HTTPS 443 & App 8080)',
    status: 'Completed',
    evidence: 'Included in ufw_configuration.sh and documented in firewall_rules.txt',
    actionRequired: 'Permits 443/tcp and denies 8080/tcp.'
  },
  {
    id: 'c5',
    deliverable: 'firewall_rules.txt created',
    status: 'Completed',
    evidence: 'File created with complete protocol and security justifications',
    actionRequired: 'Ready in repository.'
  },
  {
    id: 'c6',
    deliverable: 'Security analysis report completed',
    status: 'Completed',
    evidence: 'reports/firewall_security_analysis.md created',
    actionRequired: '13-section comprehensive analysis report ready.'
  },
  {
    id: 'c7',
    deliverable: 'README.md completed',
    status: 'Completed',
    evidence: 'README.md created with all 24 required sections & tables',
    actionRequired: 'Full project overview, commands, and official references ready.'
  },
  {
    id: 'c8',
    deliverable: 'Safe lab verified & snapshot prepared',
    status: 'Ready for Lab Execution',
    evidence: 'VirtualBox Host-Only lab network architecture documented',
    actionRequired: 'Take VirtualBox snapshot "Pre-UFW-Baseline" on your local VM.'
  },
  {
    id: 'c9',
    deliverable: 'UFW installed and verified in target VM',
    status: 'Ready for Lab Execution',
    evidence: 'Instructions in SCREENSHOTS_GUIDE.md & README.md',
    actionRequired: 'Execute: sudo apt update && sudo apt install -y ufw on your VM.'
  },
  {
    id: 'c10',
    deliverable: 'Denied traffic tested (curl on port 80 & 8080)',
    status: 'Ready for Lab Execution',
    evidence: 'test-results/firewall_test_results.txt template populated',
    actionRequired: 'Run python3 -m http.server 80 on target VM and probe with curl from client.'
  },
  {
    id: 'c11',
    deliverable: 'Test results documented with live output',
    status: 'Ready for Lab Execution',
    evidence: 'Format established in test-results/firewall_test_results.txt',
    actionRequired: 'Paste actual terminal timestamp and curl timeout output into the file.'
  },
  {
    id: 'c12',
    deliverable: 'Genuine screenshots captured (6 files)',
    status: 'Pending Lab Session',
    evidence: 'Placeholder guides created in screenshots/ directory',
    actionRequired: 'Follow screenshots/SCREENSHOTS_GUIDE.md to save your 6 VM screenshots.'
  },
  {
    id: 'c13',
    deliverable: 'Demo video recorded (3-5 minutes)',
    status: 'Pending Lab Session',
    evidence: 'demo/demo_video_plan.md completed with script & timeline',
    actionRequired: 'Record your 3-5 min screen walkthrough using OBS and paste unlisted link.'
  },
  {
    id: 'c14',
    deliverable: 'GitHub readiness verified (.gitignore & LICENSE)',
    status: 'Completed',
    evidence: 'Git structure, .gitignore, and MIT LICENSE files ready',
    actionRequired: 'Run git init, git add, and git commit in the project folder.'
  }
];

export const ChecklistTracker: React.FC = () => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const completedCount = CHECKLIST_ITEMS.filter(item => item.status === 'Completed').length;
  const readyCount = CHECKLIST_ITEMS.filter(item => item.status === 'Ready for Lab Execution').length;
  const pendingCount = CHECKLIST_ITEMS.filter(item => item.status === 'Pending Lab Session').length;
  const progressPercent = Math.round((completedCount / CHECKLIST_ITEMS.length) * 100);

  const copyGitCommands = () => {
    const cmds = `cd OIBSIP/SecurityAnalyst/Task2_UFW_Firewall_Configuration
git init
git add README.md ufw_configuration.sh firewall_rules.txt reports/ screenshots/ test-results/ demo/ .gitignore LICENSE
git commit -m "feat: OIBSIP Task 2 UFW firewall configuration and verification suite"`;
    navigator.clipboard.writeText(cmds);
    setCopiedIndex(999);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 text-sm font-semibold tracking-wider uppercase mb-1">
              <FileCheck className="w-4 h-4" />
              Phase 19 &amp; 20 Final Submission Audit
            </div>
            <h2 className="text-2xl font-bold text-white">OIBSIP Task 2 Submission Status</h2>
            <p className="text-slate-400 text-sm mt-1">
              Rigorous verification status tracking all deliverables, separating completed repository files from actions required on your VM.
            </p>
          </div>
          <div className="flex items-center gap-4 bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div>
              <div className="text-xs text-slate-400">Project Completion</div>
              <div className="text-xl font-bold text-emerald-400">{progressPercent}% Built</div>
            </div>
            <button
              onClick={copyGitCommands}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-md text-xs font-mono transition-colors"
            >
              {copiedIndex === 999 ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              Copy Git Push Commands
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-6">
          <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden flex">
            <div className="bg-emerald-500 h-full transition-all" style={{ width: `${(completedCount / 14) * 100}%` }} />
            <div className="bg-amber-500 h-full transition-all" style={{ width: `${(readyCount / 14) * 100}%` }} />
            <div className="bg-slate-700 h-full transition-all" style={{ width: `${(pendingCount / 14) * 100}%` }} />
          </div>
          <div className="flex items-center justify-between text-xs text-slate-400 mt-2 font-mono">
            <span className="text-emerald-400">✓ {completedCount} Completed in Repo</span>
            <span className="text-amber-400">⚡ {readyCount} Ready for VM Lab Run</span>
            <span className="text-slate-400">⌛ {pendingCount} Pending Video/Capture</span>
          </div>
        </div>
      </div>

      {/* Deliverable Items Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-950 text-slate-400 text-xs uppercase font-mono border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Deliverable</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Evidence / Artifact</th>
                <th className="py-3 px-4">Action Required for Submission</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 font-sans">
              {CHECKLIST_ITEMS.map((item, idx) => {
                const isCompleted = item.status === 'Completed';
                const isReady = item.status === 'Ready for Lab Execution';
                return (
                  <tr key={item.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3.5 px-4 font-medium text-white flex items-center gap-2">
                      {isCompleted ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : isReady ? (
                        <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-slate-500 shrink-0" />
                      )}
                      <span>{item.deliverable}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`text-xs px-2.5 py-0.5 rounded-full font-medium inline-block ${
                          isCompleted
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : isReady
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}
                      >
                        {item.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-xs font-mono text-slate-400 max-w-xs truncate">
                      {item.evidence}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-300">
                      {item.actionRequired}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
