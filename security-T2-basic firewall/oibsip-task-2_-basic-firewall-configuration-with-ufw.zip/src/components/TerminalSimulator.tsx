import React, { useState, useRef, useEffect } from 'react';
import { Terminal as TerminalIcon, CornerDownLeft, Trash2, HelpCircle } from 'lucide-react';

interface TerminalLine {
  id: number;
  type: 'input' | 'output' | 'error' | 'success';
  text: string;
}

export const TerminalSimulator: React.FC = () => {
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<TerminalLine[]>([
    { id: 1, type: 'output', text: 'Ubuntu 22.04 LTS (Jammy Jellyfish) [VirtualBox Lab VM: vboxnet0]' },
    { id: 2, type: 'output', text: 'Type a command or click a quick shortcut below to inspect and test UFW.' },
    { id: 3, type: 'input', text: 'sudo ufw status verbose' },
    {
      id: 4,
      type: 'output',
      text: `Status: active\nLogging: on (low)\nDefault: deny (incoming), allow (outgoing), disabled (routed)\nNew profiles: skip\n\nTo                         Action      From\n--                         ------      ----\n22/tcp                     ALLOW IN    Anywhere                   # OIBSIP: Permit SSH administration\n80/tcp                     DENY IN     Anywhere                   # OIBSIP: Block unencrypted HTTP\n443/tcp                    ALLOW IN    Anywhere                   # OIBSIP: Permit encrypted HTTPS\n8080/tcp                   DENY IN     Anywhere                   # OIBSIP: Block unapproved app port 8080\n22/tcp (v6)                ALLOW IN    Anywhere (v6)\n80/tcp (v6)                DENY IN     Anywhere (v6)\n443/tcp (v6)               ALLOW IN    Anywhere (v6)\n8080/tcp (v6)              DENY IN     Anywhere (v6)`
    }
  ]);

  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleCommand = (cmd: string) => {
    const trimmed = cmd.trim();
    if (!trimmed) return;

    const newHistory: TerminalLine[] = [...history, { id: Date.now(), type: 'input', text: trimmed }];

    const lower = trimmed.toLowerCase();

    if (lower === 'clear') {
      setHistory([]);
      setInput('');
      return;
    }

    if (lower === 'help') {
      newHistory.push({
        id: Date.now() + 1,
        type: 'output',
        text: `Available commands:\n  - sudo ufw status verbose\n  - bash -n ufw_configuration.sh\n  - sudo ./ufw_configuration.sh\n  - sudo ss -lntup\n  - curl -v http://192.168.56.101/\n  - sudo tail -n 20 /var/log/ufw.log\n  - cat /etc/os-release\n  - clear`
      });
    } else if (lower.includes('ufw status')) {
      newHistory.push({
        id: Date.now() + 1,
        type: 'output',
        text: `Status: active\nLogging: on (low)\nDefault: deny (incoming), allow (outgoing), disabled (routed)\n\nTo                         Action      From\n--                         ------      ----\n22/tcp                     ALLOW IN    Anywhere                   # OIBSIP: Permit SSH administration\n80/tcp                     DENY IN     Anywhere                   # OIBSIP: Block unencrypted HTTP\n443/tcp                    ALLOW IN    Anywhere                   # OIBSIP: Permit encrypted HTTPS\n8080/tcp                   DENY IN     Anywhere                   # OIBSIP: Block unapproved app port 8080`
      });
    } else if (lower.includes('bash -n')) {
      newHistory.push({
        id: Date.now() + 1,
        type: 'success',
        text: `[✓] ufw_configuration.sh syntax is valid. No syntax errors detected.`
      });
    } else if (lower.includes('ufw_configuration.sh')) {
      newHistory.push({
        id: Date.now() + 1,
        type: 'output',
        text: `[*] Phase 1/6: Verifying System Environment and Privileges...\n[✓] Administrative privilege confirmed (EUID=0).\n[✓] Detected OS: Ubuntu 22.04 LTS\n[✓] UFW is installed: ufw 0.36.1\n[*] Phase 2/6: Inspecting Current Firewall Status...\n[*] Phase 3/6: Setting default policies: Incoming=DENY, Outgoing=ALLOW\n[*] Phase 4/6: Applying rules: 22/tcp (ALLOW), 80/tcp (DENY), 443/tcp (ALLOW), 8080/tcp (DENY)\n[*] Phase 5/6: Enabling UFW firewall...\nFirewall is active and enabled on system startup\n[*] Phase 6/6: Complete. Log saved to ./ufw_setup_audit.log`
      });
    } else if (lower.includes('curl')) {
      newHistory.push({
        id: Date.now() + 1,
        type: 'error',
        text: `*   Trying 192.168.56.101:80...\n* TCP_NODELAY set\n* Connection timed out after 3001 milliseconds\n* Closing connection 0\ncurl: (28) Failed to connect to 192.168.56.101 port 80: Connection timed out\n[Firewall Verification: SYN packet dropped by UFW rule 2]`
      });
    } else if (lower.includes('ss -lntup')) {
      newHistory.push({
        id: Date.now() + 1,
        type: 'output',
        text: `Netid State  Recv-Q Send-Q Local Address:Port  Peer Address:Port Process\ntcp   LISTEN 0      128          0.0.0.0:22         0.0.0.0:*     users:(("sshd",pid=712,fd=3))\ntcp   LISTEN 0      5     192.168.56.101:80         0.0.0.0:*     users:(("python3",pid=1420,fd=4))`
      });
    } else if (lower.includes('tail') || lower.includes('ufw.log')) {
      newHistory.push({
        id: Date.now() + 1,
        type: 'output',
        text: `[Oct 29 16:14:02] [UFW BLOCK] IN=enp0s8 OUT= MAC=08:00:27:da:21:44:08:00:27:1c:99:a1:08:00 SRC=192.168.56.102 DST=192.168.56.101 LEN=60 TOS=0x00 PREC=0x00 TTL=64 ID=41922 DF PROTO=TCP SPT=48210 DPT=80 WINDOW=64240 RES=0x00 SYN URGP=0\n[Oct 29 16:14:03] [UFW BLOCK] IN=enp0s8 OUT= MAC=08:00:27:da:21:44:08:00:27:1c:99:a1:08:00 SRC=192.168.56.102 DST=192.168.56.101 LEN=60 TOS=0x00 PREC=0x00 TTL=64 ID=41923 DF PROTO=TCP SPT=48210 DPT=80 WINDOW=64240 RES=0x00 SYN URGP=0`
      });
    } else if (lower.includes('os-release')) {
      newHistory.push({
        id: Date.now() + 1,
        type: 'output',
        text: `NAME="Ubuntu"\nVERSION="22.04.4 LTS (Jammy Jellyfish)"\nID=ubuntu\nID_LIKE=debian\nPRETTY_NAME="Ubuntu 22.04.4 LTS"\nVERSION_ID="22.04"`
      });
    } else {
      newHistory.push({
        id: Date.now() + 1,
        type: 'error',
        text: `bash: ${trimmed}: command not recognized in lab simulator. Type 'help' for available commands.`
      });
    }

    setHistory(newHistory);
    setInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleCommand(input);
    }
  };

  return (
    <div className="space-y-4">
      {/* Quick Command Buttons */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs text-slate-400 font-medium">Quick Commands:</span>
        {[
          'sudo ufw status verbose',
          'bash -n ufw_configuration.sh',
          'sudo ./ufw_configuration.sh',
          'sudo ss -lntup',
          'curl -v http://192.168.56.101/',
          'sudo tail -n 20 /var/log/ufw.log',
          'clear'
        ].map(cmd => (
          <button
            key={cmd}
            onClick={() => handleCommand(cmd)}
            className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded font-mono text-xs transition-colors"
          >
            {cmd}
          </button>
        ))}
      </div>

      {/* Terminal Window */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden font-mono shadow-2xl">
        <div className="bg-slate-900 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-rose-500/80" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
            <span className="text-slate-400 text-xs ml-2 flex items-center gap-1.5">
              <TerminalIcon className="w-3.5 h-3.5 text-emerald-400" />
              analyst@oibsip-lab-vm: ~
            </span>
          </div>
          <button
            onClick={() => setHistory([])}
            className="text-slate-500 hover:text-slate-300 text-xs flex items-center gap-1"
            title="Clear terminal"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="p-4 text-xs space-y-2 min-h-[360px] max-h-[500px] overflow-y-auto">
          {history.map(line => {
            if (line.type === 'input') {
              return (
                <div key={line.id} className="flex items-center gap-2 text-white font-bold">
                  <span className="text-emerald-400">analyst@oibsip-vm:~$</span>
                  <span>{line.text}</span>
                </div>
              );
            }
            if (line.type === 'error') {
              return (
                <div key={line.id} className="text-rose-400 whitespace-pre-wrap pl-4 border-l-2 border-rose-500/40">
                  {line.text}
                </div>
              );
            }
            if (line.type === 'success') {
              return (
                <div key={line.id} className="text-emerald-400 whitespace-pre-wrap pl-4 border-l-2 border-emerald-500/40">
                  {line.text}
                </div>
              );
            }
            return (
              <div key={line.id} className="text-slate-300 whitespace-pre-wrap pl-4 border-l-2 border-slate-800">
                {line.text}
              </div>
            );
          })}
          <div ref={endRef} />
        </div>

        <div className="bg-slate-900/90 border-t border-slate-800 p-2.5 flex items-center gap-2">
          <span className="text-emerald-400 text-xs pl-2">analyst@oibsip-vm:~$</span>
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type a command (or click a quick shortcut above)..."
            className="flex-1 bg-transparent text-white text-xs focus:outline-none placeholder:text-slate-600 font-mono"
          />
          <button
            onClick={() => handleCommand(input)}
            className="p-1.5 text-slate-400 hover:text-emerald-400 transition-colors"
          >
            <CornerDownLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
