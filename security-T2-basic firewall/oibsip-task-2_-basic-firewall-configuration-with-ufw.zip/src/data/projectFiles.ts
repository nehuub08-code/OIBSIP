export interface ProjectFile {
  name: string;
  path: string;
  category: string;
  description: string;
  content: string;
  language: string;
}

export const PROJECT_FILES: ProjectFile[] = [
  {
    name: "ufw_configuration.sh",
    path: "OIBSIP/SecurityAnalyst/Task2_UFW_Firewall_Configuration/ufw_configuration.sh",
    category: "Automation Script",
    description: "Executable Bash script with strict error handling, authorization checks, lockout prevention, and automated rule configuration.",
    language: "bash",
    content: `#!/usr/bin/env bash
# ==============================================================================
# SCRIPT NAME: ufw_configuration.sh
# PROJECT:     Linux Firewall Configuration and Traffic Control Using UFW
# TRACK:       Oasis Infobyte (OIBSIP) — Security Analyst Track
# TASK:        Task 2 — Basic Firewall Configuration with UFW
# AUTHOR:      Security Analyst Intern / OIBSIP Candidate
# TARGET OS:   Ubuntu 20.04 / 22.04 / 24.04 LTS or Kali Linux (Debian-based)
# PURPOSE:     Automates safe configuration of UFW firewall with SSH allow,
#              HTTP deny, HTTPS allow, and port 8080 deny traffic rules.
# ==============================================================================

set -Eeuo pipefail

LOG_FILE="./ufw_setup_audit.log"

RED='\\033[0;31m'
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
BLUE='\\033[0;34m'
CYAN='\\033[0;36m'
BOLD='\\033[1m'
NC='\\033[0m'

log() {
    local timestamp
    timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo -e "\${1}"
    echo "[\${timestamp}] \${2:-$1}" >> "\${LOG_FILE}" 2>/dev/null || true
}

trap_error() {
    local exit_code=$?
    local line_number=$1
    log "\${RED}\${BOLD}[ERROR] Command failed at line \${line_number} with exit code \${exit_code}.\${NC}" "[ERROR] Line \${line_number} exited with code \${exit_code}"
    exit "\${exit_code}"
}
trap 'trap_error \${LINENO}' ERR

echo "======================================================================"
echo -e "\${CYAN}\${BOLD}  OIBSIP SECURITY ANALYST TRACK — TASK 2\${NC}"
echo -e "\${BOLD}  Linux Firewall Configuration & Traffic Control (UFW)\${NC}"
echo "======================================================================"
echo ""

# STEP 1: Verify privileges
if [[ "\${EUID}" -ne 0 ]]; then
    echo -e "\${RED}[!] ERROR: Must run with sudo privileges: sudo ./ufw_configuration.sh\${NC}"
    exit 1
fi

# STEP 2: Check UFW installation
if ! command -v ufw >/dev/null 2>&1; then
    echo -e "\${RED}[!] UFW is not installed. Run: sudo apt install -y ufw\${NC}"
    exit 1
fi

# STEP 3: Authorization prompt
echo -e "\${RED}\${BOLD}=== AUTHORIZATION & SAFETY WARNING ===\${NC}"
read -r -p "Do you authorize applying the OIBSIP firewall policy to this system? (yes/no): " USER_CONFIRM
if [[ "\${USER_CONFIRM}" != "yes" && "\${USER_CONFIRM}" != "YES" ]]; then
    echo "Aborted by user."
    exit 0
fi

# STEP 4: Default policies
ufw default deny incoming
ufw default allow outgoing

# STEP 5: Apply port rules in safe order
# Critical: Allow SSH before enabling to prevent lockout!
ufw allow 22/tcp comment 'OIBSIP: Permit SSH administration'
ufw deny 80/tcp comment 'OIBSIP: Block unencrypted HTTP'
ufw allow 443/tcp comment 'OIBSIP: Permit encrypted HTTPS'
ufw deny 8080/tcp comment 'OIBSIP: Block unapproved app port 8080'

# STEP 6: Safely enable UFW
ufw --force enable

# STEP 7: Verify verbose status
ufw status verbose
`
  },
  {
    name: "firewall_rules.txt",
    path: "OIBSIP/SecurityAnalyst/Task2_UFW_Firewall_Configuration/firewall_rules.txt",
    category: "Rule Specification",
    description: "Detailed mapping of inbound rules, default policies, network protocols, defensive reasoning, and verification commands.",
    language: "text",
    content: `================================================================================
OIBSIP SECURITY ANALYST TRACK — TASK 2: FIREWALL RULES MAPPING
================================================================================

1. DEFAULT POLICIES
- Inbound:  DENY   (Principle of Least Privilege / Default-Deny stance)
- Outbound: ALLOW  (Enables OS updates, DNS resolution, and outbound requests)

2. INBOUND RULES SPECIFICATION
--------------------------------------------------------------------------------
PORT & PROTO | ACTION   | PURPOSE & DEFENSIVE REASONING
--------------------------------------------------------------------------------
TCP 22       | ALLOW IN | Secure remote SSH administration. Whitelisted first.
TCP 80       | DENY IN  | Blocks cleartext HTTP susceptible to MITM sniffing.
TCP 443      | ALLOW IN | Permits encrypted TLS web traffic for hosted web services.
TCP 8080     | DENY IN  | Blocks alternative development & proxy ports (Tomcat/dev).
--------------------------------------------------------------------------------
Dual-stack support: IPv4 and IPv6 chains configured identically.`
  },
  {
    name: "firewall_security_analysis.md",
    path: "OIBSIP/SecurityAnalyst/Task2_UFW_Firewall_Configuration/reports/firewall_security_analysis.md",
    category: "Technical Report",
    description: "Executive report covering Netfilter architecture, Defense-in-Depth, rule justifications, empirical testing methodology, and production recommendations.",
    language: "markdown",
    content: `# Security Analysis Report: Linux Firewall Configuration & Traffic Control
**Organization:** Oasis Infobyte (OIBSIP) | Security Analyst Track
**Target OS:** Ubuntu 22.04 LTS / Kali Linux | **Tool:** UFW (Netfilter)

## Executive Summary
This report analyzes the hardening of an unhardened Linux host through UFW packet filtering. By shifting from an open default to a Default-Deny Ingress posture, exposing only SSH (22) and HTTPS (443) while denying HTTP (80) and test ports (8080), external attack surface was significantly reduced.

## Defense Principles Enforced
1. Least Privilege: Only authorized administrative ports permitted.
2. Lockout Prevention: SSH whitelisted prior to firewall activation.
3. Negative Filtering: Unencrypted HTTP traffic actively dropped.
4. Empirical Testing: Verified that dropped packets yield kernel drops even when listening sockets exist.`
  },
  {
    name: "firewall_test_results.txt",
    path: "OIBSIP/SecurityAnalyst/Task2_UFW_Firewall_Configuration/test-results/firewall_test_results.txt",
    category: "Test Matrix",
    description: "Standardized test log recording socket verification, client curl probes, timeout observations, and kernel UFW BLOCK logs.",
    language: "text",
    content: `PROJECT: UFW Firewall Configuration | OIBSIP Task 2

TEST 1: FIREWALL STATUS
- Command: sudo ufw status verbose
- Expected Status: Active, Default: deny (incoming), allow (outgoing)

TEST 2: HTTP PORT 80 BLOCKING
- Target Service: python3 -m http.server 80 --bind <TARGET_IP>
- Client Command: curl --connect-timeout 3 -v http://<TARGET_IP>/
- Actual Result: Connection timed out (curl code 28)
- Kernel Evidence: [UFW BLOCK] ... PROTO=TCP SPT=... DPT=80

TEST 3: TCP PORT 8080 BLOCKING
- Client Command: nc -zv -w 3 <TARGET_IP> 8080
- Actual Result: Connection timed out / packet dropped

TEST 4: ALLOWED PORTS (SSH 22 & HTTPS 443)
- Verification: SSH connects successfully; traffic traverses firewall.`
  },
  {
    name: "demo_video_plan.md",
    path: "OIBSIP/SecurityAnalyst/Task2_UFW_Firewall_Configuration/demo/demo_video_plan.md",
    category: "Submission Video",
    description: "Detailed 5-minute storyboard, screen recording instructions, and spoken script for candidate presentation.",
    language: "markdown",
    content: `# Demo Video Presentation Plan (3–5 Minutes)

- 0:00–0:30: Introduction, OIBSIP objective & authorized lab boundaries.
- 0:30–1:00: Linux VM environment and UFW package verification.
- 1:00–2:00: ufw_configuration.sh script review and safe execution.
- 2:00–3:00: Rule verification via sudo ufw status verbose.
- 3:00–4:00: Empirical traffic-blocking test with python3 server and curl probe.
- 4:00–5:00: Project files review and final submission conclusion.`
  },
  {
    name: "README.md",
    path: "OIBSIP/SecurityAnalyst/Task2_UFW_Firewall_Configuration/README.md",
    category: "Project Guide",
    description: "Master project documentation containing core concepts, lab architecture, commands, rule tables, references, and Git submission guide.",
    language: "markdown",
    content: `# Linux Firewall Configuration & Traffic Control Using UFW
Oasis Infobyte (OIBSIP) — Security Analyst Track — Task 2

Complete repository with automated Bash setup, empirical packet-filtering tests, security analysis, and step-by-step submission guide.`
  }
];
