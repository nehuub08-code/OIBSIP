import React, { useState } from 'react';
import {
  Shield,
  ShieldCheck,
  Terminal,
  FolderCode,
  Network,
  CheckSquare,
  BookOpen,
  Lock,
  ExternalLink,
  ChevronRight,
  Flame
} from 'lucide-react';
import { PacketSimulator } from './components/PacketSimulator';
import { ProjectExplorer } from './components/ProjectExplorer';
import { LabGuide } from './components/LabGuide';
import { TerminalSimulator } from './components/TerminalSimulator';
import { ChecklistTracker } from './components/ChecklistTracker';

type ActiveTab = 'simulator' | 'explorer' | 'lab' | 'terminal' | 'checklist';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('simulator');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Notification / Security Bar */}
      <div className="bg-slate-900/90 border-b border-slate-800 text-xs px-4 py-2 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-semibold text-slate-300">OIBSIP Security Analyst Track:</span>
          <span className="text-slate-400">Task 2 — Basic Firewall Configuration with UFW</span>
        </div>
        <div className="flex items-center gap-3 text-slate-400 font-mono text-[11px]">
          <span className="hidden sm:inline">Target: Ubuntu 22.04 LTS / Kali Linux</span>
          <span className="text-slate-600">|</span>
          <span className="text-emerald-400 font-semibold">Status: Default Ingress DENY Active</span>
        </div>
      </div>

      {/* Main Header */}
      <header className="border-b border-slate-800 bg-slate-900/60 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-white shadow-lg shadow-emerald-950">
              <Flame className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-white tracking-tight">
                  Linux Firewall &amp; Traffic Control Suite
                </h1>
                <span className="text-[10px] bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 px-2 py-0.5 rounded-full font-mono uppercase">
                  UFW / Netfilter
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Oasis Infobyte Internship Program • Task 2 Submission &amp; Interactive Verification Suite
              </p>
            </div>
          </div>

          {/* Quick Active Policy Badges */}
          <div className="flex flex-wrap items-center gap-1.5 font-mono text-[11px]">
            <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">
              In: <strong className="text-rose-400">DENY</strong>
            </span>
            <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">
              Out: <strong className="text-emerald-400">ALLOW</strong>
            </span>
            <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">
              SSH 22: <strong className="text-emerald-400">ALLOW</strong>
            </span>
            <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">
              HTTP 80: <strong className="text-rose-400">DENY</strong>
            </span>
            <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">
              HTTPS 443: <strong className="text-emerald-400">ALLOW</strong>
            </span>
            <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">
              App 8080: <strong className="text-rose-400">DENY</strong>
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex overflow-x-auto gap-2 border-t border-slate-800/80 pt-1">
          {[
            { id: 'simulator', label: 'Packet Filter Simulator', icon: Shield },
            { id: 'explorer', label: 'Project Files & Script', icon: FolderCode },
            { id: 'lab', label: 'VirtualBox Lab Guide', icon: Network },
            { id: 'terminal', label: 'Interactive Terminal', icon: Terminal },
            { id: 'checklist', label: 'Submission Checklist', icon: CheckSquare }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as ActiveTab)}
                className={`flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-medium border-b-2 transition-all whitespace-nowrap ${
                  isActive
                    ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8">
        {activeTab === 'simulator' && <PacketSimulator />}
        {activeTab === 'explorer' && <ProjectExplorer />}
        {activeTab === 'lab' && <LabGuide />}
        {activeTab === 'terminal' && <TerminalSimulator />}
        {activeTab === 'checklist' && <ChecklistTracker />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div>
            <div className="font-semibold text-slate-400">
              Oasis Infobyte Internship Program (OIBSIP) — Security Analyst Track
            </div>
            <div className="text-[11px] text-slate-600 mt-0.5">
              Task 2: Linux Firewall Configuration and Traffic Control Using UFW • Non-production Lab Sandbox
            </div>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <a
              href="https://help.ubuntu.com/community/UFW"
              target="_blank"
              rel="noreferrer"
              className="hover:text-emerald-400 transition-colors flex items-center gap-1"
            >
              UFW Docs <ExternalLink className="w-3 h-3" />
            </a>
            <span>•</span>
            <a
              href="https://documentation.ubuntu.com/server/how-to/security/firewalls/"
              target="_blank"
              rel="noreferrer"
              className="hover:text-emerald-400 transition-colors flex items-center gap-1"
            >
              Ubuntu Firewall <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
