# Demo Video Presentation Plan & Walkthrough Script
**Project:** Linux Firewall Configuration and Traffic Control Using UFW  
**Organization:** Oasis Infobyte (OIBSIP)  
**Track:** Security Analyst  
**Task:** Task 2 — Basic Firewall Configuration with UFW  
**Target Duration:** 3 to 5 minutes  
**Format:** Screen Recording with Voiceover (or Subtitles)  
**Status:** Plan Prepared / Video Recording Pending User VM Lab Session  

---

## Recording Guidelines for the Candidate

### Recommended Tools:
- **OBS Studio** (Free, Open-Source, cross-platform) or **SimpleScreenRecorder** on Linux.
- Screen resolution: 1080p (1920x1080).
- Terminal font size: 14pt–16pt (ensure terminal commands are crisp and readable).
- Audio: Clear microphone voiceover or concise on-screen annotation cards.

---

## Step-by-Step Video Timeline & Verbal Script

### Section 1: Introduction (0:00 – 0:30)
* **Visual on Screen:** GitHub repository folder or Title Slide displaying OIBSIP details.
* **Candidate Spoken Script:**
  > *"Hello, my name is [Your Name], and this is my submission for Task 2 of the Oasis Infobyte Security Analyst Internship Track: Basic Firewall Configuration with UFW. In this demonstration, I will configure an enterprise-style default-deny host firewall on Linux, safely whitelist remote SSH and HTTPS traffic, enforce negative filtering against unencrypted HTTP and development port 8080, and empirically verify traffic blocking using an isolated VirtualBox lab environment."*

---

### Section 2: Environment Inspection & UFW Installation (0:30 – 1:00)
* **Visual on Screen:** Terminal on Target Ubuntu/Kali VM.
* **Commands Executed:**
  ```bash
  cat /etc/os-release | grep PRETTY_NAME
  ip addr show | grep inet
  sudo ufw version
  ```
* **Candidate Spoken Script:**
  > *"First, let's verify our environment. We are running an authorized Ubuntu 22.04 LTS virtual machine connected to an isolated Host-Only network. I verify that UFW is installed and check its initial status. UFW acts as the user-space interface to Linux Netfilter. Notice that installing UFW does not automatically enable it; firewall activation must be carefully controlled."*

---

### Section 3: Safe Script Walkthrough & Execution (1:00 – 2:00)
* **Visual on Screen:** View `ufw_configuration.sh` in terminal (`cat` or `nano`), then execute.
* **Commands Executed:**
  ```bash
  bash -n ufw_configuration.sh
  sudo ./ufw_configuration.sh
  ```
* **Candidate Spoken Script:**
  > *"Next, let's inspect our automated configuration script: `ufw_configuration.sh`. Notice the defensive design: it verifies administrative privileges, displays a strict authorization prompt, and establishes our default policies: incoming traffic is DENIED, and outgoing is ALLOWED.
  Crucially, we insert the SSH permit rule on port 22 BEFORE enabling the firewall. This prevents administrative lockout. We also apply DENY rules for port 80 and port 8080, and an ALLOW rule for HTTPS on port 443. Now, let's run the script. It prompts for confirmation, applies each rule, and enables UFW."*

---

### Section 4: Firewall Rule Verification (2:00 – 3:00)
* **Visual on Screen:** Running the verbose status check on the Target VM.
* **Commands Executed:**
  ```bash
  sudo ufw status verbose
  sudo ufw status numbered
  ```
* **Candidate Spoken Script:**
  > *"Now let's examine the active firewall state using `sudo ufw status verbose`. We can see:
  - Status is active with logging enabled.
  - Default incoming is DENY, default outgoing is ALLOW.
  - Port 22/tcp is ALLOWED for remote SSH management.
  - Port 80/tcp is explicitly DENIED.
  - Port 443/tcp is ALLOWED for secure TLS web communication.
  - Port 8080/tcp is DENIED.
  Both IPv4 and IPv6 chains are protected identically."*

---

### Section 5: Empirical Traffic-Blocking Demonstration (3:00 – 4:00)
* **Visual on Screen:** Split terminal showing Target VM on the left and Client VM / Host on the right.
* **Commands Executed:**
  *Target VM:*
  ```bash
  sudo python3 -m http.server 80 --bind 192.168.56.101
  sudo ss -lntup | grep :80
  ```
  *Client VM:*
  ```bash
  curl --connect-timeout 3 -v http://192.168.56.101/
  ```
  *Target VM (Log Verification):*
  ```bash
  sudo dmesg | grep '\[UFW BLOCK\]' | tail -n 5
  ```
* **Candidate Spoken Script:**
  > *"Now for the vital scientific proof: testing whether denied traffic is genuinely blocked. On our target machine, we start an HTTP test server on port 80 and verify with `ss` that the socket is actively listening.
  From our separate client VM, we attempt a connection using `curl`. Notice the connection times out after 3 seconds: curl cannot establish the TCP handshake.
  To prove this wasn't a routing failure, we check kernel logs on the target: UFW intercepted and dropped the SYN packet on destination port 80. This confirms our firewall is actively defending the host."*

---

### Section 6: Project Deliverables & Submission Summary (4:00 – 5:00)
* **Visual on Screen:** Quick tour of repository folders (`README.md`, `firewall_security_analysis.md`, `test-results/`, and `screenshots/`).
* **Candidate Spoken Script:**
  > *"Finally, here is the project repository structure: the runnable Bash script, the comprehensive security analysis report, the empirical test results, and genuine terminal screenshots. This completes all deliverables for OIBSIP Task 2. Thank you for watching."*

---

## Submission Checklist for Demo Video
- [ ] Video uploaded as an unlisted link on YouTube or shared via Google Drive with public view access.
- [ ] Link inserted into the `demo_video_plan.md` and `README.md` before final OIBSIP submission.
