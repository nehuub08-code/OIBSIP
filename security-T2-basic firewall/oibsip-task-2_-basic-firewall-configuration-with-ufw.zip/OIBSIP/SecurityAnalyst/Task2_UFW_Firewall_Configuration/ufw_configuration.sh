#!/usr/bin/env bash
# ==============================================================================
# SCRIPT NAME: ufw_configuration.sh
# PROJECT:     Linux Firewall Configuration and Traffic Control Using UFW
# TRACK:       Oasis Infobyte (OIBSIP) — Security Analyst Track
# TASK:        Task 2 — Basic Firewall Configuration with UFW
# AUTHOR:      Security Analyst Intern / OIBSIP Candidate
# TARGET OS:   Ubuntu 20.04 / 22.04 / 24.04 LTS or Kali Linux (Debian-based)
# PURPOSE:     Automates safe configuration of UFW firewall with SSH allow,
#              HTTP deny, HTTPS allow, and port 8080 deny traffic rules.
# ==============================================================================

# Enable strict mode:
# -E: ERR trap is inherited by shell functions
# -e: Exit immediately if a command exits with a non-zero status
# -u: Treat unset variables as an error
# -o pipefail: Pipeline return status is the value of the last (rightmost) command
#              to exit with a non-zero status
set -Eeuo pipefail

# Log file for audit trail
LOG_FILE="./ufw_setup_audit.log"

# Color formatting for terminal display
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Logging helper function
log() {
    local timestamp
    timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo -e "${1}"
    echo "[${timestamp}] ${2:-$1}" >> "${LOG_FILE}" 2>/dev/null || true
}

# Error handler
trap_error() {
    local exit_code=$?
    local line_number=$1
    log "${RED}${BOLD}[ERROR] Command failed at line ${line_number} with exit code ${exit_code}.${NC}" "[ERROR] Line ${line_number} exited with code ${exit_code}"
    log "${YELLOW}Please inspect the error above, ensure you have proper permissions, and check VM console access.${NC}"
    exit "${exit_code}"
}
trap 'trap_error ${LINENO}' ERR

echo "======================================================================"
echo -e "${CYAN}${BOLD}  OIBSIP SECURITY ANALYST TRACK — TASK 2${NC}"
echo -e "${BOLD}  Linux Firewall Configuration & Traffic Control (UFW)${NC}"
echo "======================================================================"
echo ""

# ------------------------------------------------------------------------------
# STEP 1: VERIFY ENVIRONMENT & PRIVILEGES
# ------------------------------------------------------------------------------
log "${BLUE}[*] Phase 1/6: Verifying System Environment and Privileges...${NC}"

# Check for root / superuser privileges
if [[ "${EUID}" -ne 0 ]]; then
    log "${RED}[!] ERROR: This script must be executed with administrative privileges.${NC}"
    echo -e "    Please execute using: ${YELLOW}sudo ./ufw_configuration.sh${NC}"
    exit 1
fi
log "${GREEN}[✓] Administrative privilege confirmed (EUID=0).${NC}"

# Check Operating System
if [[ -f /etc/os-release ]]; then
    # shellcheck source=/dev/null
    source /etc/os-release
    log "${GREEN}[✓] Detected OS: ${PRETTY_NAME:-Linux}${NC}"
else
    log "${YELLOW}[!] Notice: /etc/os-release not detected. Proceeding with caution.${NC}"
fi

# Check if UFW is installed
if ! command -v ufw >/dev/null 2>&1; then
    log "${RED}[!] UFW (Uncomplicated Firewall) is NOT installed on this machine.${NC}"
    echo -e "    To install UFW on Debian, Ubuntu, or Kali Linux, execute:"
    echo -e "    ${YELLOW}sudo apt update && sudo apt install -y ufw${NC}"
    exit 1
fi

UFW_VER=$(ufw --version | head -n 1)
log "${GREEN}[✓] UFW is installed: ${UFW_VER}${NC}"

# Check network interfaces and SSH session status
if [[ -n "${SSH_CONNECTION:-}" || -n "${SSH_CLIENT:-}" || -n "${SSH_TTY:-}" ]]; then
    CURRENT_SSH_IP=$(echo "${SSH_CONNECTION:-local}" | awk '{print $3}')
    CURRENT_SSH_PORT=$(echo "${SSH_CONNECTION:-local}" | awk '{print $4}')
    log "${YELLOW}[!] WARNING: Active SSH session detected on port ${CURRENT_SSH_PORT:-22}!${NC}"
    log "    Applying firewall rules over remote SSH can potentially lock you out"
    log "    if port 22 or the designated management port is not correctly allowed."
else
    log "${GREEN}[✓] Running in local console/terminal or non-SSH environment.${NC}"
fi

echo ""

# ------------------------------------------------------------------------------
# STEP 2: AUTHORIZATION AND RECOVERY WARNING
# ------------------------------------------------------------------------------
echo -e "${RED}${BOLD}==================== AUTHORIZATION & SAFETY NOTICE ====================${NC}"
echo -e " 1. This script is intended ${BOLD}EXCLUSIVELY${NC} for an authorized lab environment"
echo -e "    such as an isolated VirtualBox / VMware virtual machine."
echo -e " 2. ${RED}${BOLD}NEVER${NC} run this on production servers without a verified out-of-band"
echo -e "    recovery method (e.g., hypervisor VM console, IPMI, or VNC)."
echo -e " 3. Firewall modification can interrupt network traffic immediately."
echo -e " 4. Existing custom rules will be preserved; policies will be layered safely."
echo -e "${RED}${BOLD}=======================================================================${NC}"
echo ""

# Request explicit user confirmation
read -r -p "Do you authorize applying the OIBSIP firewall policy to this system? (yes/no): " USER_CONFIRM
if [[ "${USER_CONFIRM}" != "yes" && "${USER_CONFIRM}" != "YES" ]]; then
    log "${YELLOW}[*] Operation aborted by user. No firewall rules were modified.${NC}"
    exit 0
fi

echo ""
log "${GREEN}[*] Authorization confirmed. Initializing setup audit log: ${LOG_FILE}${NC}"
echo "=== UFW Setup Execution Log - $(date) ===" > "${LOG_FILE}"

# ------------------------------------------------------------------------------
# STEP 3: INSPECT CURRENT FIREWALL STATUS
# ------------------------------------------------------------------------------
log "${BLUE}[*] Phase 2/6: Inspecting Current Firewall Status...${NC}"
CURRENT_STATUS=$(ufw status | head -n 1 || echo "unknown")
log "    Current status line: ${BOLD}${CURRENT_STATUS}${NC}"

# ------------------------------------------------------------------------------
# STEP 4: CONFIGURE DEFAULT POLICIES
# ------------------------------------------------------------------------------
log "${BLUE}[*] Phase 3/6: Applying Default Traffic Policies...${NC}"
# Default Incoming: Deny all unsolicited incoming traffic
log "    Setting default incoming policy: DENY"
ufw default deny incoming >> "${LOG_FILE}" 2>&1

# Default Outgoing: Allow established and outbound requests
log "    Setting default outgoing policy: ALLOW"
ufw default allow outgoing >> "${LOG_FILE}" 2>&1

log "${GREEN}[✓] Default policies established: Incoming = DENY | Outgoing = ALLOW${NC}"
echo ""

# ------------------------------------------------------------------------------
# STEP 5: APPLY SPECIFIC PORT RULES (IN SAFE SEQUENCE)
# ------------------------------------------------------------------------------
log "${BLUE}[*] Phase 4/6: Applying Firewall Rules...${NC}"

# RULE 1 (CRITICAL FOR MANAGEMENT): Allow SSH traffic on TCP port 22
# Must be added BEFORE enabling UFW to prevent immediate lockout!
log "    -> [1/4] Allowing SSH traffic on port 22/tcp (Remote Administration)..."
ufw allow 22/tcp comment 'OIBSIP: Permit SSH administration' >> "${LOG_FILE}" 2>&1
log "${GREEN}       [OK] Rule added: ALLOW 22/tcp${NC}"

# RULE 2 (REQUIRED BY SPEC): Deny HTTP traffic on TCP port 80
log "    -> [2/4] Denying unencrypted HTTP traffic on port 80/tcp..."
ufw deny 80/tcp comment 'OIBSIP: Block unencrypted HTTP' >> "${LOG_FILE}" 2>&1
log "${GREEN}       [OK] Rule added: DENY 80/tcp${NC}"

# RULE 3 (ADDITIONAL RULE 1): Allow HTTPS traffic on TCP port 443
log "    -> [3/4] Allowing encrypted HTTPS traffic on port 443/tcp (Secure Web)..."
ufw allow 443/tcp comment 'OIBSIP: Permit encrypted HTTPS' >> "${LOG_FILE}" 2>&1
log "${GREEN}       [OK] Rule added: ALLOW 443/tcp${NC}"

# RULE 4 (ADDITIONAL RULE 2): Deny alternate application traffic on TCP port 8080
log "    -> [4/4] Denying alternate application traffic on port 8080/tcp..."
ufw deny 8080/tcp comment 'OIBSIP: Block unapproved app port 8080' >> "${LOG_FILE}" 2>&1
log "${GREEN}       [OK] Rule added: DENY 8080/tcp${NC}"

echo ""

# ------------------------------------------------------------------------------
# STEP 6: SAFELY ENABLE UFW & VERIFY
# ------------------------------------------------------------------------------
log "${BLUE}[*] Phase 5/6: Enabling UFW with Applied Rules...${NC}"

# Use '--force' flag to enable non-interactively while rules are already configured
ufw --force enable >> "${LOG_FILE}" 2>&1
log "${GREEN}[✓] UFW firewall is now ACTIVE and enabled on system startup.${NC}"
echo ""

log "${BLUE}[*] Phase 6/6: Verifying Active Firewall Configuration...${NC}"
echo -e "${CYAN}------------------------ [sudo ufw status verbose] ------------------------${NC}"
ufw status verbose | tee -a "${LOG_FILE}"
echo -e "${CYAN}---------------------------------------------------------------------------${NC}"
echo ""

log "${GREEN}${BOLD}======================================================================${NC}"
log "${GREEN}${BOLD}  FIREWALL CONFIGURATION COMPLETED SUCCESSFULLY!                      ${NC}"
log "${GREEN}${BOLD}======================================================================${NC}"
echo -e "Audit log saved to: ${BOLD}${LOG_FILE}${NC}"
echo -e "Next Steps:"
echo -e "  1. Test HTTP port 80 blocking from client VM using: ${YELLOW}curl -v http://<TARGET_IP>/${NC}"
echo -e "  2. Test Port 8080 blocking using:                   ${YELLOW}nc -zv <TARGET_IP> 8080${NC}"
echo -e "  3. Verify SSH persistence from management machine:  ${YELLOW}ssh user@<TARGET_IP>${NC}"
echo -e "  4. Record genuine test results into:                ${BOLD}test-results/firewall_test_results.txt${NC}"
echo ""
exit 0
