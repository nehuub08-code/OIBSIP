# Security Analysis Report: Linux Firewall Configuration & Inbound Traffic Control Using UFW
**Organization:** Oasis Infobyte (OIBSIP)  
**Track:** Security Analyst  
**Task Number:** Task 2 — Basic Firewall Configuration with UFW  
**Target Operating Systems:** Ubuntu 22.04 LTS / Kali Linux  
**Author:** Security Analyst Intern  
**Date:** October 2026  

---

## 1. Executive Summary

This security report evaluates the deployment, hardening, and verification of a host-based firewall using **UFW (Uncomplicated Firewall)** on a Linux system. In modern cyber defense, unhardened host operating systems are perpetually exposed to automated port scanning, unauthorized service enumeration, brute-force exploits, and lateral movement.

By implementing an explicit **Default-Deny Ingress posture**, selectively whitelisting vital management traffic (**SSH on TCP 22**) and encrypted web traffic (**HTTPS on TCP 443**), while strictly blocking cleartext web services (**HTTP on TCP 80**) and alternative application ports (**TCP 8080**), we successfully reduce the external attack surface of the Linux host. The configuration was packaged into a repeatable, defensive Bash automation script (`ufw_configuration.sh`) engineered with failsafe checks, privilege validation, and administrative lockout protections.

---

## 2. Objective

The primary technical and operational goals of this security assessment are:
1. Construct and execute a repeatable automation script to configure UFW on a Linux operating system.
2. Establish a secure **Default Deny Incoming / Default Allow Outgoing** baseline.
3. Permit administrative remote management via SSH (port 22/tcp) while preventing lockout.
4. Enforce negative filtering on unencrypted HTTP (port 80/tcp) and unapproved application traffic (port 8080/tcp).
5. Configure positive transit for encrypted HTTPS web traffic (port 443/tcp).
6. Verify firewall state and rule evaluation ordering using verbose kernel inspection tools.
7. Execute empirical network traffic tests to prove that denied packets are intercepted and dropped even when listening sockets exist.

---

## 3. Lab Environment & Authorization

Security testing of network packet filters must be conducted strictly within authorized boundaries:
- **Hypervisor:** Oracle VM VirtualBox (v7.x)
- **Target VM:** Ubuntu 22.04 LTS (Desktop/Server) or Kali Linux 2024.x
- **Client VM / Host:** Host workstation or secondary Linux VM
- **Network Architecture:** Dedicated Host-Only Adapter (`vboxnet0`, `192.168.56.0/24`) or Internal Network
- **Pre-execution Snapshot:** A clean hypervisor snapshot named `Pre-Firewall-Baseline` was captured before script execution to guarantee zero-downtime recovery.
- **Authorization Statement:** All activities were executed within a sandboxed, non-production testbed. No public or third-party networks were scanned or modified.

---

## 4. Technical Architecture: What UFW Is

**UFW (Uncomplicated Firewall)** is a user-space command-line interface designed to streamline the administration of **Netfilter**, the Linux kernel's underlying packet filtering framework (historically accessed via `iptables` and currently via `nftables`).

While raw `iptables` syntax is intricate and prone to accidental lockouts or rule ordering bugs, UFW abstracts these mechanics into intuitive semantic rules while preserving low-level kernel capabilities:
- Integrates directly with `/etc/default/ufw` and `/etc/ufw/before.rules` / `after.rules`.
- Automatically enforces dual-stack IPv4 and IPv6 packet filtering (`/etc/ufw/ufw.conf` setting `IPV6=yes`).
- Interfaces with Linux kernel connection tracking (`conntrack`), allowing stateful inspection so that established return packets for outbound connections are seamlessly accepted without needing manual inbound rules.

---

## 5. Firewall Policy Architecture

The firewall architecture enforces a **Defense-in-Depth** model:

```
[ External Traffic ] ───▶ [ UFW / Netfilter Ingress Chain ]
                                     │
           ┌─────────────────────────┴────────────────────────┐
           ▼                                                  ▼
     [ Rule Match? ]                                     [ No Match? ]
      - Port 22/tcp  ──▶ ACCEPT (SSH Allowed)                 │
      - Port 80/tcp  ──▶ DROP / REJECT (HTTP Blocked)         ▼
      - Port 443/tcp ──▶ ACCEPT (HTTPS Allowed)       [ Default Policy: DENY ]
      - Port 8080/tcp──▶ DROP / REJECT (Blocked)              │
                                                              ▼
                                                        PACKET DROPPED
```

1. **Default Deny Incoming:** All unsolicited inbound SYN packets are dropped by default. A port without an explicit allow rule is inaccessible from outside the machine.
2. **Default Allow Outgoing:** The host can initiate connections outbound (e.g., DNS resolution to 53/udp, APT package updates on 80/443, NTP time sync on 123/udp).
3. **Stateful Connection Tracking:** When an outbound request is sent, Netfilter tracks the state as `ESTABLISHED,RELATED`. Return packets are permitted automatically.

---

## 6. Rule-by-Rule Security Reasoning

### Rule 1: Allow SSH (Port 22/tcp)
- **Command:** `sudo ufw allow 22/tcp comment 'OIBSIP: Permit SSH administration'`
- **Protocol:** TCP, Port 22
- **Action:** ACCEPT (Inbound)
- **Defense Rationale:** SSH (Secure Shell) provides encrypted remote shell administration, encrypted file transfers (SFTP/SCP), and configuration automation.
- **Critical Safety Guard:** This rule MUST be executed and verified before enabling UFW. If UFW is enabled remotely over SSH without an explicit allow rule, the active session will be severed upon connection timeout, locking out administrators.

### Rule 2: Deny HTTP (Port 80/tcp)
- **Command:** `sudo ufw deny 80/tcp comment 'OIBSIP: Block unencrypted HTTP'`
- **Protocol:** TCP, Port 80
- **Action:** DENY / DROP (Inbound)
- **Defense Rationale:** Unencrypted HTTP transmits data (including credentials, session cookies, and API parameters) in plaintext across the local area network. Restricting port 80 shields legacy unencrypted services from eavesdropping and MITM tampering.

### Rule 3: Allow HTTPS (Port 443/tcp)
- **Command:** `sudo ufw allow 443/tcp comment 'OIBSIP: Permit encrypted HTTPS'`
- **Protocol:** TCP, Port 443
- **Action:** ACCEPT (Inbound)
- **Defense Rationale:** HTTPS encapsulates HTTP traffic inside Transport Layer Security (TLS 1.2/1.3), providing confidentiality, integrity, and server authentication.
- **Key Distinguisher:** Allowing port 443 does *not* spawn a web daemon. If no web server is listening, connection attempts will yield connection refused at the transport layer, not a firewall drop.

### Rule 4: Deny Alternative Application Port (Port 8080/tcp)
- **Command:** `sudo ufw deny 8080/tcp comment 'OIBSIP: Block unapproved app port 8080'`
- **Protocol:** TCP, Port 8080
- **Action:** DENY / DROP (Inbound)
- **Defense Rationale:** Port 8080 is universally utilized by developers for testing frameworks (Tomcat, Spring Boot, Jenkins, Node.js development servers, proxy tools). These services often run in debug modes with default credentials or unauthenticated dashboards. Explicitly dropping traffic on port 8080 shields internal test endpoints from external threat actors.

---

## 7. Actual Configuration Results

Running `sudo ufw status verbose` on the target system provides the following active Netfilter configuration:

```text
Status: active
Logging: on (low)
Default: deny (incoming), allow (outgoing), disabled (routed)
New profiles: skip

To                         Action      From
--                         ------      ----
22/tcp                     ALLOW IN    Anywhere                   # OIBSIP: Permit SSH administration
80/tcp                     DENY IN     Anywhere                   # OIBSIP: Block unencrypted HTTP
443/tcp                    ALLOW IN    Anywhere                   # OIBSIP: Permit encrypted HTTPS
8080/tcp                   DENY IN     Anywhere                   # OIBSIP: Block unapproved app port 8080
22/tcp (v6)                ALLOW IN    Anywhere (v6)              # OIBSIP: Permit SSH administration
80/tcp (v6)                DENY IN     Anywhere (v6)              # OIBSIP: Block unencrypted HTTP
443/tcp (v6)               ALLOW IN    Anywhere (v6)              # OIBSIP: Permit encrypted HTTPS
8080/tcp (v6)              DENY IN     Anywhere (v6)              # OIBSIP: Block unapproved app port 8080
```

---

## 8. Traffic-Blocking Test Methodology

A common misconception in security analysis is assuming that a failed connection proves a firewall block. A connection failure can occur because:
1. No application is listening on the target port (TCP RST returned).
2. Routing or hypervisor network configuration is broken (ARP fails or no route to host).
3. The firewall packet filter is silently dropping incoming SYN packets (Timeout).

To guarantee empirical validity, our testing methodology adheres to strict verification stages:
1. **Socket Verification:** Prior to testing, verify on the target VM that an actual process is bound and listening:
   ```bash
   sudo ss -lntup | grep -E ':(22|80|443|8080)'
   ```
2. **Controlled Test Listener:** If no native daemon is listening on port 80, launch a temporary lab HTTP server bound to the lab network IP:
   ```bash
   sudo python3 -m http.server 80 --bind <TARGET_LAB_IP>
   ```
3. **Client-Side Ingress Probe:** From a separate machine on the same virtual subnet, initiate probes using `curl` and `netcat`:
   ```bash
   curl -v --connect-timeout 3 http://<TARGET_LAB_IP>/
   nc -zv -w 3 <TARGET_LAB_IP> 80
   ```
4. **Kernel Log Triangulation:** Confirm packet drop at the kernel level:
   ```bash
   sudo tail -n 20 /var/log/ufw.log | grep "DPT=80"
   ```

---

## 9. Actual Test Results & Analysis

| Target Port | Target Listening? | Client Probe | Result | Kernel Log Evidence | Security Conclusion |
|---|---|---|---|---|---|
| **TCP 22 (SSH)** | Yes (`sshd`) | `ssh user@<TARGET_IP>` | **Connected** | Session established | Traffic successfully permitted through firewall whitelist. |
| **TCP 80 (HTTP)** | Yes (`python3 http.server`) | `curl --connect-timeout 3 http://<TARGET_IP>/` | **Connection timed out** | `[UFW BLOCK] ... PROTO=TCP SPT=... DPT=80` | Firewall actively intercepted and dropped SYN packets despite active socket. |
| **TCP 8080 (Dev)** | Yes (`nc -lvp 8080`) | `nc -zv -w 3 <TARGET_IP> 8080` | **Connection timed out** | `[UFW BLOCK] ... PROTO=TCP SPT=... DPT=8080` | Restrictive rule blocked unapproved application port. |
| **TCP 443 (HTTPS)** | No service | `nc -zv -w 3 <TARGET_IP> 443` | **Connection refused** | No UFW BLOCK log | Packet reached kernel stack because port 443 is allowed; kernel responded with RST due to no listening daemon. |

---

## 10. Security Benefits

1. **Minimization of Attack Surface:** Scanning probes (e.g. `nmap -sS`) against non-whitelisted ports are dropped, preventing automated OS fingerprinting and service banner grabbing.
2. **Containment of Shadow IT / Developer Services:** Internal test services listening on 8080 or unencrypted web ports cannot be reached by external unauthorized endpoints.
3. **Stateful Integrity:** Ephemeral ports opened for outgoing client requests do not leave permanent ingress holes in the firewall.
4. **Audit Trail & Forensics:** UFW logging (`/var/log/ufw.log`) provides immediate incident response visibility into unauthorized scanning activity and brute-force attempts.

---

## 11. Limitations & Potential Misconfigurations

1. **Firewalls Do Not Inspect Layer 7 Content (Payload):**
   - An allowed port (e.g., SSH port 22 or HTTPS port 443) does not protect against application-level attacks such as SSH credential brute-forcing, SQL injection, or malicious TLS payloads.
2. **Loopback Traffic (`lo`) Exemption:**
   - By default, UFW rules in `/etc/ufw/before.rules` permit unrestricted traffic on the loopback interface (`127.0.0.1`). Local processes can still reach locally bound services even if UFW has an ingress deny rule.
3. **Port Forwarding / Docker Interception:**
   - Standard Docker installations modify `iptables` directly before UFW rules execute (`DOCKER-USER` chain). If Docker containers are published using `-p 80:80`, Docker may bypass UFW rules unless configured with `iptables: false` in `/etc/docker/daemon.json`.
4. **Administrative Lockout Risk:**
   - If administrators modify SSH to a non-standard port (e.g. 2222) and fail to update UFW rules before enabling, they will lose remote access.

---

## 12. Recommendations for Production Hardening

1. **IP Subnet Whitelisting for Administrative Access:**
   Rather than allowing SSH from `Anywhere`, restrict SSH strictly to authorized VPN subnets or jump-host IP addresses:
   ```bash
   sudo ufw delete allow 22/tcp
   sudo ufw allow from 192.168.1.50/32 to any port 22 proto tcp comment 'Restrict SSH to Admin Workstation'
   ```
2. **Rate Limiting SSH to Prevent Brute-Force Attacks:**
   Utilize UFW's built-in rate-limiting feature to block IP addresses initiating 6 or more connections within 30 seconds:
   ```bash
   sudo ufw limit 22/tcp comment 'Rate-limit SSH connections'
   ```
3. **Deploy Intrusion Prevention (Fail2ban):**
   Combine UFW with **Fail2ban** to automatically insert dynamic Netfilter drop rules when repeated authentication failures occur.
4. **Enforce Outbound Egress Filtering in High-Security Enclaves:**
   In secure database or backend nodes, restrict outgoing traffic to prevent reverse shells or unauthorized exfiltration:
   ```bash
   sudo ufw default deny outgoing
   sudo ufw allow out 53/udp comment 'DNS lookups'
   sudo ufw allow out 443/tcp comment 'Encrypted package updates'
   ```
5. **Implement Centralized Log Forwarding (SIEM):**
   Stream `/var/log/ufw.log` via Rsyslog to a centralized SIEM (Splunk, Elastic, or Wazuh) to detect scanning anomalies across infrastructure.

---

## 13. Conclusion

The implementation of UFW on Linux provides a robust, manageable first line of defense. By transitioning from an open default to a least-privilege **Default-Deny Ingress** architecture, this project systematically eliminated exposure to unencrypted HTTP and unauthorized application ports while safeguarding essential remote administration.

A firewall is an indispensable foundational pillar of network security, but it operates most effectively as part of a comprehensive Defense-in-Depth strategy encompassing robust authentication, system patching, continuous log monitoring, and principle of least privilege.
