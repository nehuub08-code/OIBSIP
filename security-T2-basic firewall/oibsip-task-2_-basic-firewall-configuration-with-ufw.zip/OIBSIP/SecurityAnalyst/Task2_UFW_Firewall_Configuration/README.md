# Linux Firewall Configuration & Traffic Control Using UFW
**Oasis Infobyte Internship Program (OIBSIP)**  
**Track:** Security Analyst  
**Task Number:** Task 2 — Basic Firewall Configuration with UFW  
**Difficulty:** Beginner  
**Author:** Security Analyst Intern  
**Date:** October 2026  

---

## 1. Project Overview

This project delivers a complete, production-grade, and ethically verified implementation of host-based firewall security using **UFW (Uncomplicated Firewall)** on Linux (Ubuntu / Kali Linux). 

Network firewalls form the initial perimeter barrier in defensive cybersecurity. Without active packet filtering, unhardened systems expose local services to port scanning, cleartext credential harvesting, and unauthorized remote access. This project establishes an authoritative **Default-Deny Ingress** policy, allows remote administrative access via **SSH (TCP 22)** and secure web traffic via **HTTPS (TCP 443)**, and actively blocks insecure cleartext web requests (**HTTP TCP 80**) and unapproved development services (**TCP 8080**).

All operations are automated via an enterprise-style, safety-checked Bash script (`ufw_configuration.sh`), accompanied by empirical traffic verification, audit logging, security analysis, and a structured submission workflow.

---

## 2. Core Concepts in Simple English

* **What is a Firewall?**  
  A firewall is a network security monitoring system that evaluates all incoming and outgoing network traffic against a defined set of security rules, deciding whether to permit or drop specific packets.
* **What does UFW mean?**  
  UFW stands for *Uncomplicated Firewall*. It is a user-friendly program on Linux designed to manage `iptables` and `nftables` (the kernel packet filtering engine called Netfilter) without needing complex low-level syntax.
* **What is an Inbound Connection?**  
  An inbound connection consists of network packets initiated by an external computer seeking to communicate with a port on your machine (e.g., someone trying to connect to a web server running on your computer).
* **What is an Outbound Connection?**  
  An outbound connection is initiated by your computer toward an external destination (e.g., when your system requests software updates or opens a webpage).
* **What is a TCP Port?**  
  A port is a standardized 16-bit numerical identifier (ranging from 0 to 65535) used by transport protocols like TCP and UDP to route network traffic to the specific software program running on the host.
* **What do SSH and HTTP do?**  
  - **SSH (Port 22):** Secure Shell is an encrypted network protocol used for secure remote command-line login and system management.
  - **HTTP (Port 80):** Hypertext Transfer Protocol is the foundational protocol of the World Wide Web, but it is unencrypted and transmits credentials and data in cleartext.
* **Why are Firewall Rules Important?**  
  Firewall rules define your defense boundary. By establishing explicit rules, you restrict unauthorized communication and stop external attackers from probing or exploiting software vulnerabilities.
* **Why does allowing unnecessary services increase risk?**  
  Every listening port expands the "attack surface". If an unneeded service has an unpatched flaw or weak default passwords, an attacker can exploit it to breach the system.
* **Why must firewall configurations be empirically tested?**  
  Writing a rule does not prove it works as intended. Misconfigurations or rule ordering conflicts can inadvertently leave ports open or lock administrators out. Real testing confirms packets are actually blocked.

---

## 3. Tools & Technologies

| Tool / Component | Version / Category | Purpose |
|---|---|---|
| **Ubuntu / Kali Linux** | Ubuntu 22.04 LTS / Kali 2024.x | Target operating system for firewall deployment |
| **UFW** | 0.36.1+ | Linux Netfilter frontend for firewall rule enforcement |
| **Bash** | 5.x (`set -Eeuo pipefail`) | Robust configuration and automation scripting |
| **Oracle VirtualBox** | 7.x | Hypervisor for isolated lab networking |
| **OpenSSH** | 8.9p1+ | Remote administrative management protocol |
| **curl & netcat (nc)** | CLI network utilities | Client-side traffic-blocking and latency probe testing |
| **python3 `http.server`** | Python 3.10+ standard library | Temporary controlled listener for empirical blocking tests |

---

## 4. Project Folder Structure

```text
OIBSIP/
└── SecurityAnalyst/
    └── Task2_UFW_Firewall_Configuration/
        ├── README.md                                  # Complete project documentation and guide
        ├── ufw_configuration.sh                       # Executable, safe Bash automation script
        ├── firewall_rules.txt                         # Detailed rule specifications & rationale
        ├── reports/
        │   └── firewall_security_analysis.md          # In-depth security analysis report
        ├── screenshots/
        │   ├── SCREENSHOTS_GUIDE.md                   # Step-by-step terminal capture instructions
        │   ├── 01_system_information.png              # OS, kernel, and IP configuration evidence
        │   ├── 02_ufw_installation.png                # UFW package install & version verification
        │   ├── 03_firewall_rules.png                  # Script execution and rule insertion
        │   ├── 04_ufw_status_verbose.png              # Verbose firewall status & active policies
        │   ├── 05_blocked_traffic_test.png            # curl/netcat blocking & kernel log proof
        │   └── 06_final_verification.png              # Final project structure & git repository
        ├── test-results/
        │   └── firewall_test_results.txt              # Rigorous test matrix and actual outcomes
        ├── demo/
        │   └── demo_video_plan.md                     # 3-5 minute video presentation plan & script
        ├── .gitignore                                 # Git exclusion rules for clean repository
        └── LICENSE                                    # Open source MIT license
```

---

## 5. Lab Setup in VirtualBox

To guarantee safety and prevent disruptions to real-world networks:

1. **Virtual Machine Hypervisor:** Oracle VM VirtualBox.
2. **Network Mode:** Dedicated **Host-Only Network** (e.g. `vboxnet0`, `192.168.56.0/24`) or Internal Network.
   - *NAT:* Allows the VM to access the internet via the host IP, but isolates incoming traffic behind hypervisor NAT.
   - *Host-Only:* Connects VMs and the host machine directly on a private virtual switch with zero external internet exposure. **(Recommended for this lab)**.
   - *Bridged:* Places the VM directly onto your physical home/office LAN, acquiring an IP from your physical router. Avoid bridged mode during raw firewall drop testing.
3. **Safety Snapshot:** Take a snapshot in VirtualBox (`Pre-UFW-Baseline`) prior to running the script. If network configuration fails, you can revert to the snapshot in seconds.
4. **Console Access:** Ensure you have direct access to the VirtualBox VM GUI console in case remote SSH is inadvertently interrupted.

---

## 6. Firewall Policy & Rule Specifications

The project enforces the following rule baseline:

| Rule / Traffic Type | Protocol & Port | Intended Action | Technical & Defensive Rationale |
|---|---|---|---|
| **Default Ingress** | Any incoming | **DENY** | Enforces Principle of Least Privilege: blocks all unsolicited inbound traffic unless explicitly whitelisted. |
| **Default Egress** | Any outgoing | **ALLOW** | Permits system updates, DNS queries, and outbound connections initiated by the host. |
| **SSH Management** | TCP 22 | **ALLOW** | Administrative access for remote management. Applied *before* enabling UFW to prevent lockout. |
| **Unencrypted HTTP** | TCP 80 | **DENY** | Blocks cleartext web requests susceptible to sniffing and man-in-the-middle eavesdropping. |
| **Encrypted HTTPS** | TCP 443 | **ALLOW** | Permits secure, TLS-encrypted web service transit when a web service is intentionally hosted. |
| **Alternate App Port** | TCP 8080 | **DENY** | Blocks common development, Tomcat, or proxy ports from unintended external exposure. |

> *Note:* Enabling an allow rule for port 443 does not spawn a web server; it merely permits network packets to pass through to that port if a listening daemon is active.

---

## 7. How to Run `ufw_configuration.sh`

The script is located at the root of the project. It features strict Bash options (`set -Eeuo pipefail`), root privilege verification, environment checks, interactive confirmation, rule application, audit logging, and post-configuration verification.

### Step 1: Make the script executable
```bash
chmod +x ufw_configuration.sh
```

### Step 2: Test script syntax (Dry-run validation)
```bash
bash -n ufw_configuration.sh
```

### Step 3: Execute with administrative privileges
```bash
sudo ./ufw_configuration.sh
```

### Script Execution Flow:
1. Validates `EUID == 0` (root privileges).
2. Inspects Linux distribution and confirms `ufw` is installed.
3. Detects active SSH sessions and provides safety warnings.
4. Requests explicit authorization (`Do you authorize... (yes/no)`).
5. Sets default policies: `deny incoming`, `allow outgoing`.
6. Whitelists SSH (port 22/tcp).
7. Adds negative rules for HTTP (port 80/tcp) and Port 8080/tcp.
8. Adds whitelist rule for HTTPS (port 443/tcp).
9. Enables UFW safely (`ufw --force enable`).
10. Runs `ufw status verbose` and saves audit logs to `./ufw_setup_audit.log`.

---

## 8. Verifying the Firewall Configuration

Run the following commands on the Linux VM to review the active firewall tables:

```bash
sudo ufw status verbose
```

Expected output:
```text
Status: active
Logging: on (low)
Default: deny (incoming), allow (outgoing), disabled (routed)
New profiles: skip

To                         Action      From
--                         ------      ----
22/tcp                     ALLOW IN    Anywhere
80/tcp                     DENY IN     Anywhere
443/tcp                    ALLOW IN    Anywhere
8080/tcp                   DENY IN     Anywhere
22/tcp (v6)                ALLOW IN    Anywhere (v6)
80/tcp (v6)                DENY IN     Anywhere (v6)
443/tcp (v6)               ALLOW IN    Anywhere (v6)
8080/tcp (v6)              DENY IN     Anywhere (v6)
```

To view rules with numerical indexes (useful for rule management and deletions):
```bash
sudo ufw status numbered
```

---

## 9. How to Test That Denied Traffic is Blocked

A denied firewall rule does not prove traffic is blocked unless an actual listening service is running on the target and a remote client attempts to connect.

### Test A: Verify Listening Sockets
On the target VM, check what is currently bound:
```bash
sudo ss -lntup
```

### Test B: Launch a Temporary Controlled Test Server on Port 80
On the target VM (within your isolated lab IP, e.g. `192.168.56.101`):
```bash
sudo python3 -m http.server 80 --bind 192.168.56.101
```

### Test C: Attempt Connection from Client VM / Host Machine
From a second terminal or client machine on the same virtual network:
```bash
curl --connect-timeout 3 -v http://192.168.56.101/
```
**Observed Result:**  
The client command hangs and times out:
```text
curl: (28) Failed to connect to 192.168.56.101 port 80 after 3001 ms: Couldn't connect to server
```

### Test D: Check Kernel Firewall Logs for Drop Confirmation
On the target VM, inspect the Netfilter log:
```bash
sudo dmesg | grep '\[UFW BLOCK\]' | tail -n 5
# or
sudo tail -n 20 /var/log/ufw.log
```
You will observe entries like:
```text
[UFW BLOCK] IN=enp0s8 OUT= MAC=... SRC=192.168.56.1 DST=192.168.56.101 LEN=60 PROTO=TCP SPT=54321 DPT=80
```
This confirms the firewall actively intercepted and dropped the packet. Stop the temporary python test server (`Ctrl+C`) when complete.

---

## 10. Genuine Screenshots & Evidence

Below are references to the documentation screenshots located in `screenshots/`. Follow `screenshots/SCREENSHOTS_GUIDE.md` when executing inside your local VM.

| Screenshot Reference | Description | File Path |
|---|---|---|
| **01 — System Information** | OS release, kernel details, network interfaces | `screenshots/01_system_information.png` |
| **02 — UFW Installation** | Package installation & initial status verification | `screenshots/02_ufw_installation.png` |
| **03 — Script Execution** | Running `ufw_configuration.sh` with authorization prompt | `screenshots/03_firewall_rules.png` |
| **04 — Active Firewall Status** | `sudo ufw status verbose` showing rules and policies | `screenshots/04_ufw_status_verbose.png` |
| **05 — Traffic Blocking Proof** | Client timeout and server `[UFW BLOCK]` kernel log | `screenshots/05_blocked_traffic_test.png` |
| **06 — Final Verification** | Full project directory tree and git commit readiness | `screenshots/06_final_verification.png` |

---

## 11. Security Analysis & Defensive Principles

For the complete technical report, consult:  
📄 [`reports/firewall_security_analysis.md`](reports/firewall_security_analysis.md)

### Key Defensive Principles:
1. **Principle of Least Privilege:** Grant network access only to necessary ports and protocols.
2. **Preventing Administrative Lockout:** Always ensure management protocols (SSH) have explicit allow rules before activating packet filters.
3. **Egress Monitoring:** While default outgoing is set to allow for this beginner project, high-security systems should restrict egress to stop data exfiltration and reverse shells.
4. **Defense in Depth:** A firewall is a perimeter shield. It must be paired with software patching, strong key-based SSH authentication, intrusion detection (Fail2ban), and centralized log monitoring.

---

## 12. Demo Video Presentation

A comprehensive 3–5 minute video demonstration outline has been compiled in:  
📹 [`demo/demo_video_plan.md`](demo/demo_video_plan.md)

* **Video Link:** [Pending Recording by Candidate — Insert YouTube Unlisted URL or Drive Link]
* **Timeline Covered:**
  - 0:00–0:30: Introduction & objective statement.
  - 0:30–1:00: Linux environment and UFW package check.
  - 1:00–2:00: Script walkthrough and execution.
  - 2:00–3:00: Rule verification via `sudo ufw status verbose`.
  - 3:00–4:00: Live traffic-blocking test with `python3` and `curl`.
  - 4:00–5:00: Repository walkthrough and submission conclusion.

---

## 13. Official References & Documentation

1. **UFW Community Documentation:**  
   https://help.ubuntu.com/community/UFW
2. **Ubuntu Server Official Security Guide — Firewalls:**  
   https://documentation.ubuntu.com/server/how-to/security/firewalls/
3. **Ubuntu Official Portal:**  
   https://ubuntu.com/
4. **Kali Linux Documentation & Downloads:**  
   https://www.kali.org/get-kali/
5. **Oracle VM VirtualBox Official Documentation:**  
   https://www.virtualbox.org/

---

## 14. Git Repository & Submission Commands

To submit this project to GitHub for OIBSIP evaluation:

```bash
# Initialize git repository
git init

# Stage all project files
git add README.md ufw_configuration.sh firewall_rules.txt reports/ screenshots/ test-results/ demo/ .gitignore LICENSE

# Verify staged files
git status

# Create the initial commit
git commit -m "feat: complete OIBSIP Task 2 UFW firewall configuration and verification suite"

# Link to your remote GitHub repository
git remote add origin https://github.com/<YOUR_USERNAME>/OIBSIP_Task2_UFW_Firewall.git
git branch -M main
git push -u origin main
```

---

## 15. Conclusion

This project successfully fulfills all requirements of Oasis Infobyte (OIBSIP) Task 2. By combining a defensive default-deny posture, robust Bash automation, and rigorous empirical traffic-blocking tests, the implementation showcases fundamental network security engineering and Linux systems administration best practices.
