# Genuine Screenshot Capture Guide — OIBSIP Task 2

To maintain academic and professional integrity under the OIBSIP guidelines, terminal screenshots must reflect your actual Linux Virtual Machine environment and must never be fabricated.

Follow this checklist to capture each required screenshot from your Ubuntu/Kali Linux VM:

### 1. `01_system_information.png`
* **What to capture:** The terminal running system identification commands showing that you are operating on a genuine Linux system.
* **Commands to run:**
  ```bash
  cat /etc/os-release
  uname -a
  whoami
  ip addr
  ```
* **Capture tip:** Keep the terminal title bar or prompt visible. Save as `01_system_information.png`.

---

### 2. `02_ufw_installation.png`
* **What to capture:** Verifying or installing UFW on Debian/Ubuntu/Kali.
* **Commands to run:**
  ```bash
  sudo apt install -y ufw
  sudo ufw version
  sudo ufw status verbose
  ```
* **Capture tip:** Shows that UFW is installed and its initial state before rule deployment. Save as `02_ufw_installation.png`.

---

### 3. `03_firewall_rules.png`
* **What to capture:** Running the configuration script `sudo ./ufw_configuration.sh` with authorization prompt and successful rule insertion.
* **Commands to run:**
  ```bash
  chmod +x ufw_configuration.sh
  sudo ./ufw_configuration.sh
  ```
* **Capture tip:** Ensure the prompt `Do you authorize... (yes/no)` and the rule additions (22/tcp allow, 80/tcp deny, 443/tcp allow, 8080/tcp deny) are displayed. Save as `03_firewall_rules.png`.

---

### 4. `04_ufw_status_verbose.png`
* **What to capture:** The active firewall status table showing verbose default policies and numbered rules.
* **Commands to run:**
  ```bash
  sudo ufw status verbose
  sudo ufw status numbered
  ```
* **Capture tip:** Confirms Default: deny (incoming), allow (outgoing), and the active rules for 22, 80, 443, and 8080. Save as `04_ufw_status_verbose.png`.

---

### 5. `05_blocked_traffic_test.png`
* **What to capture:** Real-time demonstration that denied traffic is blocked.
* **Split Terminal or Side-by-Side Windows:**
  - **Left Window (Target VM):** Running a test listener:
    ```bash
    sudo python3 -m http.server 80 --bind <TARGET_IP>
    # and in another tab:
    sudo tail -f /var/log/ufw.log
    ```
  - **Right Window (Client VM / Host):** Attempting connection:
    ```bash
    curl --connect-timeout 3 -v http://<TARGET_IP>/
    ```
* **Capture tip:** The timeout on the client and the `[UFW BLOCK]` entry in the target log visibly prove packet filtering. Save as `05_blocked_traffic_test.png`.

---

### 6. `06_final_verification.png`
* **What to capture:** Final project tree verification and Git status in terminal.
* **Commands to run:**
  ```bash
  tree -a
  git status
  ```
* **Capture tip:** Displays all required directories, scripts, reports, and logs ready for submission. Save as `06_final_verification.png`.
