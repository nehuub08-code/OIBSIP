import { Booking, Cancellation, Passenger, Train, TravelClass, User } from '../types';

const DB_STORAGE_KEY = 'railease_sqlite_database_v2';

// Helper for SHA-256 hashing (mirroring Java MessageDigest.getInstance("SHA-256"))
export async function hashPassword(password: string): Promise<string> {
  const msgUint8 = new TextEncoder().encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Initial Trains Dataset
const INITIAL_TRAINS: Train[] = [
  {
    trainNumber: '12951',
    trainName: 'Mumbai Central Rajdhani Express',
    source: 'MUMBAI CENTRAL (MMCT)',
    destination: 'NEW DELHI (NDLS)',
    departureTime: '17:00',
    arrivalTime: '08:32',
    distanceKm: 1384,
    baseFareSL: 650,
    runsOn: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    availableSeats: { '1A': 18, '2A': 42, '3A': 110, 'SL': 240, '2S': 160 },
  },
  {
    trainNumber: '22436',
    trainName: 'Vande Bharat Express',
    source: 'NEW DELHI (NDLS)',
    destination: 'VARANASI JN (BSB)',
    departureTime: '06:00',
    arrivalTime: '14:00',
    distanceKm: 759,
    baseFareSL: 550,
    runsOn: ['Tue', 'Wed', 'Fri', 'Sat', 'Sun'],
    availableSeats: { '1A': 24, '2A': 52, '3A': 120, 'SL': 0, '2S': 210 },
  },
  {
    trainNumber: '12002',
    trainName: 'Bhopal Shatabdi Express',
    source: 'NEW DELHI (NDLS)',
    destination: 'RANI KAMALAPATI (RKMP)',
    departureTime: '06:00',
    arrivalTime: '14:40',
    distanceKm: 707,
    baseFareSL: 480,
    runsOn: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    availableSeats: { '1A': 30, '2A': 64, '3A': 140, 'SL': 0, '2S': 280 },
  },
  {
    trainNumber: '12260',
    trainName: 'Sealdah Duronto Express',
    source: 'SEALDAH (SDAH)',
    destination: 'NEW DELHI (NDLS)',
    departureTime: '18:30',
    arrivalTime: '11:00',
    distanceKm: 1453,
    baseFareSL: 720,
    runsOn: ['Mon', 'Wed', 'Thu', 'Sun'],
    availableSeats: { '1A': 16, '2A': 48, '3A': 130, 'SL': 280, '2S': 0 },
  },
  {
    trainNumber: '12626',
    trainName: 'Kerala Superfast Express',
    source: 'NEW DELHI (NDLS)',
    destination: 'THIRUVANANTHAPURAM (TVC)',
    departureTime: '20:10',
    arrivalTime: '14:15',
    distanceKm: 3036,
    baseFareSL: 920,
    runsOn: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    availableSeats: { '1A': 12, '2A': 36, '3A': 94, 'SL': 320, '2S': 190 },
  },
  {
    trainNumber: '12840',
    trainName: 'Howrah Mail',
    source: 'MGR CHENNAI CTL (MAS)',
    destination: 'HOWRAH JN (HWH)',
    departureTime: '19:00',
    arrivalTime: '23:00',
    distanceKm: 1662,
    baseFareSL: 680,
    runsOn: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    availableSeats: { '1A': 14, '2A': 40, '3A': 118, 'SL': 310, '2S': 180 },
  },
  {
    trainNumber: '12138',
    trainName: 'Punjab Mail',
    source: 'FIROZPUR CANTT (FZR)',
    destination: 'MUMBAI CSMT (CSMT)',
    departureTime: '21:40',
    arrivalTime: '07:35',
    distanceKm: 1928,
    baseFareSL: 750,
    runsOn: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    availableSeats: { '1A': 10, '2A': 32, '3A': 105, 'SL': 360, '2S': 220 },
  },
  {
    trainNumber: '12919',
    trainName: 'Malwa Superfast Express',
    source: 'INDORE JN (INDB)',
    destination: 'SMVD KATRA (SVDK)',
    departureTime: '12:15',
    arrivalTime: '16:05',
    distanceKm: 1540,
    baseFareSL: 690,
    runsOn: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    availableSeats: { '1A': 10, '2A': 34, '3A': 98, 'SL': 290, '2S': 175 },
  },
];

export interface DatabaseState {
  users: User[];
  trains: Train[];
  bookings: Booking[];
  cancellations: Cancellation[];
}

class SQLiteDatabase {
  private state: DatabaseState;

  constructor() {
    this.state = this.loadFromStorage();
  }

  private loadFromStorage(): DatabaseState {
    const raw = localStorage.getItem(DB_STORAGE_KEY);
    if (raw) {
      try {
        return JSON.parse(raw);
      } catch (e) {
        console.error('Failed to parse database from storage', e);
      }
    }
    // Default initial seed
    return this.createInitialSeed();
  }

  private saveToStorage(): void {
    try {
      localStorage.setItem(DB_STORAGE_KEY, JSON.stringify(this.state));
    } catch (e) {
      console.error('Failed to write to storage', e);
    }
  }

  private createInitialSeed(): DatabaseState {
    // SHA-256 hash for 'neha123': '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5'
    // SHA-256 hash for 'password123': 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f'
    const defaultUser1: User = {
      username: 'nehaborkar',
      passwordHash: 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', // password123
      fullName: 'Neha Vinod Borkar',
      email: 'nehaborkar2408@gmail.com',
      phone: '+91 98765 43210',
      createdAt: '2026-10-20 10:00:00',
    };

    const defaultUser2: User = {
      username: 'passenger',
      passwordHash: 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', // password123
      fullName: 'Rahul Sharma',
      email: 'rahul.sharma@example.com',
      phone: '+91 91234 56789',
      createdAt: '2026-10-22 14:30:00',
    };

    const initialBooking: Booking = {
      pnr: '2458910472',
      username: 'nehaborkar',
      trainNumber: '12951',
      trainName: 'Mumbai Central Rajdhani Express',
      source: 'MUMBAI CENTRAL (MMCT)',
      destination: 'NEW DELHI (NDLS)',
      journeyDate: '2026-11-15',
      travelClass: '2A',
      passengers: [
        {
          name: 'Neha Borkar',
          age: 23,
          gender: 'Female',
          berthPreference: 'Lower',
          allocatedBerth: 'B2 - 21 (LB)',
          status: 'CNF',
        },
        {
          name: 'Sunita Borkar',
          age: 48,
          gender: 'Female',
          berthPreference: 'Lower',
          allocatedBerth: 'B2 - 22 (MB)',
          status: 'CNF',
        },
      ],
      totalFare: 3640,
      bookingTimestamp: '2026-10-25 15:42:10',
      status: 'CONFIRMED',
      quota: 'General',
    };

    const sampleCancelledBooking: Booking = {
      pnr: '8392104571',
      username: 'nehaborkar',
      trainNumber: '22436',
      trainName: 'Vande Bharat Express',
      source: 'NEW DELHI (NDLS)',
      destination: 'VARANASI JN (BSB)',
      journeyDate: '2026-11-05',
      travelClass: '3A',
      passengers: [
        {
          name: 'Neha Borkar',
          age: 23,
          gender: 'Female',
          berthPreference: 'Window Seat',
          allocatedBerth: 'C3 - 45 (WS)',
          status: 'CNF',
        },
      ],
      totalFare: 1485,
      bookingTimestamp: '2026-10-24 11:15:00',
      status: 'CANCELLED',
      quota: 'General',
    };

    const sampleCancellation: Cancellation = {
      cancellationId: 'CAN-839210-91',
      pnr: '8392104571',
      trainNumber: '22436',
      trainName: 'Vande Bharat Express',
      cancelledAt: '2026-10-26 16:20:00',
      journeyDate: '2026-11-05',
      originalFare: 1485,
      cancellationCharge: 120,
      refundAmount: 1365,
      reason: 'Change in personal travel schedule',
      username: 'nehaborkar',
    };

    return {
      users: [defaultUser1, defaultUser2],
      trains: INITIAL_TRAINS,
      bookings: [initialBooking, sampleCancelledBooking],
      cancellations: [sampleCancellation],
    };
  }

  // --- Authentication Methods (JDBC UserDAO simulation with PreparedStatements) ---
  public async authenticate(username: string, passwordPlain: string): Promise<{ success: boolean; user?: User; error?: string }> {
    const trimmedUsername = username.trim().toLowerCase();
    if (!trimmedUsername || !passwordPlain) {
      return { success: false, error: 'Username and password cannot be empty.' };
    }

    const hashedInput = await hashPassword(passwordPlain);
    const foundUser = this.state.users.find(
      (u) => u.username.toLowerCase() === trimmedUsername && u.passwordHash === hashedInput
    );

    if (foundUser) {
      return { success: true, user: foundUser };
    }
    return { success: false, error: 'Invalid username or password. Please verify your credentials.' };
  }

  public async registerUser(data: {
    username: string;
    passwordPlain: string;
    fullName: string;
    email: string;
    phone: string;
  }): Promise<{ success: boolean; user?: User; error?: string }> {
    const cleanUsername = data.username.trim().toLowerCase();
    if (cleanUsername.length < 3) {
      return { success: false, error: 'Username must be at least 3 characters long.' };
    }
    if (data.passwordPlain.length < 4) {
      return { success: false, error: 'Password must be at least 4 characters long.' };
    }
    if (this.state.users.some((u) => u.username.toLowerCase() === cleanUsername)) {
      return { success: false, error: `Username '${cleanUsername}' already exists. Please pick another one.` };
    }

    const passwordHash = await hashPassword(data.passwordPlain);
    const newUser: User = {
      username: cleanUsername,
      passwordHash,
      fullName: data.fullName.trim() || cleanUsername,
      email: data.email.trim() || `${cleanUsername}@example.com`,
      phone: data.phone.trim() || 'N/A',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
    };

    this.state.users.push(newUser);
    this.saveToStorage();
    return { success: true, user: newUser };
  }

  // --- Trains & Stations ---
  public getAllTrains(): Train[] {
    return [...this.state.trains];
  }

  public getTrainByNumber(trainNumber: string): Train | undefined {
    return this.state.trains.find((t) => t.trainNumber === trainNumber);
  }

  public getAllStationNames(): string[] {
    const stations = new Set<string>();
    for (const train of this.state.trains) {
      stations.add(train.source);
      stations.add(train.destination);
    }
    return Array.from(stations).sort();
  }

  // --- Fare Calculator ---
  public calculateFare(trainNumber: string, travelClass: TravelClass, passengerCount: number): number {
    const train = this.getTrainByNumber(trainNumber);
    if (!train) return 0;

    const classMultipliers: Record<TravelClass, number> = {
      '2S': 0.6,
      'SL': 1.0,
      '3A': 2.3,
      '2A': 3.4,
      '1A': 5.2,
    };

    const multiplier = classMultipliers[travelClass] || 1.0;
    const singleFare = Math.round(train.baseFareSL * multiplier);
    return singleFare * passengerCount;
  }

  // --- Booking Insertion (JDBC PreparedStatement with Transaction & PNR Gen) ---
  public createBooking(data: {
    username: string;
    trainNumber: string;
    journeyDate: string;
    travelClass: TravelClass;
    quota: 'General' | 'Tatkal' | 'Ladies' | 'Senior Citizen';
    passengers: {
      name: string;
      age: number;
      gender: 'Male' | 'Female' | 'Other';
      berthPreference: Passenger['berthPreference'];
    }[];
  }): { success: boolean; booking?: Booking; error?: string } {
    const train = this.getTrainByNumber(data.trainNumber);
    if (!train) {
      return { success: false, error: `Train #${data.trainNumber} not found in database.` };
    }

    if (!data.passengers || data.passengers.length === 0) {
      return { success: false, error: 'At least one passenger is required for booking.' };
    }

    // Generate unique 10-digit PNR (Indian Railway standard)
    let pnr = '';
    do {
      const prefix = Math.floor(100 + Math.random() * 900); // 3 digits
      const suffix = Math.floor(1000000 + Math.random() * 9000000); // 7 digits
      pnr = `${prefix}${suffix}`;
    } while (this.state.bookings.some((b) => b.pnr === pnr));

    const totalFare = this.calculateFare(data.trainNumber, data.travelClass, data.passengers.length);

    // Assign realistic berths
    const coachLetters: Record<TravelClass, string> = {
      '1A': 'H1',
      '2A': 'A1',
      '3A': 'B3',
      'SL': 'S4',
      '2S': 'D2',
    };
    const coach = coachLetters[data.travelClass] || 'S1';

    const passengersWithBerths: Passenger[] = data.passengers.map((p, idx) => {
      const berthNo = Math.floor(10 + Math.random() * 60);
      const shortPref = p.berthPreference === 'Lower' ? 'LB' :
        p.berthPreference === 'Middle' ? 'MB' :
        p.berthPreference === 'Upper' ? 'UB' :
        p.berthPreference === 'Side Lower' ? 'SL' :
        p.berthPreference === 'Side Upper' ? 'SU' : 'WS';
      return {
        name: p.name.trim(),
        age: p.age,
        gender: p.gender,
        berthPreference: p.berthPreference,
        allocatedBerth: `${coach} - ${berthNo} (${shortPref})`,
        status: 'CNF',
      };
    });

    const newBooking: Booking = {
      pnr,
      username: data.username,
      trainNumber: train.trainNumber,
      trainName: train.trainName,
      source: train.source,
      destination: train.destination,
      journeyDate: data.journeyDate,
      travelClass: data.travelClass,
      passengers: passengersWithBerths,
      totalFare,
      bookingTimestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      status: 'CONFIRMED',
      quota: data.quota,
    };

    // Deduct seats in database
    if (train.availableSeats[data.travelClass] > data.passengers.length) {
      train.availableSeats[data.travelClass] -= data.passengers.length;
    }

    this.state.bookings.unshift(newBooking);
    this.saveToStorage();

    return { success: true, booking: newBooking };
  }

  // --- Cancellation (JDBC update status = 'CANCELLED' + insert cancellation) ---
  public cancelBooking(pnr: string, reason = 'Customer requested cancellation'): {
    success: boolean;
    cancellation?: Cancellation;
    error?: string;
  } {
    const cleanPNR = pnr.trim();
    const booking = this.state.bookings.find((b) => b.pnr === cleanPNR);

    if (!booking) {
      return { success: false, error: `PNR "${cleanPNR}" was not found in the reservation database.` };
    }

    if (booking.status === 'CANCELLED') {
      return { success: false, error: `Booking for PNR ${cleanPNR} has already been cancelled.` };
    }

    // Cancellation charge rule: Standard flat deduction per passenger based on class
    const flatCharges: Record<TravelClass, number> = {
      '1A': 240,
      '2A': 200,
      '3A': 180,
      'SL': 120,
      '2S': 60,
    };

    const perPassengerCharge = flatCharges[booking.travelClass] || 100;
    const cancellationCharge = Math.min(booking.totalFare, perPassengerCharge * booking.passengers.length);
    const refundAmount = Math.max(0, booking.totalFare - cancellationCharge);

    booking.status = 'CANCELLED';

    const cancellationRecord: Cancellation = {
      cancellationId: `CAN-${booking.pnr.substring(0, 6)}-${Math.floor(10 + Math.random() * 90)}`,
      pnr: booking.pnr,
      trainNumber: booking.trainNumber,
      trainName: booking.trainName,
      cancelledAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      journeyDate: booking.journeyDate,
      originalFare: booking.totalFare,
      cancellationCharge,
      refundAmount,
      reason,
      username: booking.username,
    };

    // Restore seats in train
    const train = this.getTrainByNumber(booking.trainNumber);
    if (train) {
      train.availableSeats[booking.travelClass] += booking.passengers.length;
    }

    this.state.cancellations.unshift(cancellationRecord);
    this.saveToStorage();

    return { success: true, cancellation: cancellationRecord };
  }

  // --- Retrieval Queries ---
  public getBookingByPNR(pnr: string): Booking | undefined {
    const clean = pnr.trim();
    return this.state.bookings.find((b) => b.pnr === clean);
  }

  public getCancellationByPNR(pnr: string): Cancellation | undefined {
    const clean = pnr.trim();
    return this.state.cancellations.find((c) => c.pnr === clean);
  }

  public getUserBookings(username: string): Booking[] {
    const clean = username.trim().toLowerCase();
    return this.state.bookings.filter((b) => b.username.toLowerCase() === clean);
  }

  public getAllBookings(): Booking[] {
    return [...this.state.bookings];
  }

  public getAllCancellations(): Cancellation[] {
    return [...this.state.cancellations];
  }

  public getAllUsers(): User[] {
    return [...this.state.users];
  }

  // --- Live SQL Query Engine for SQLite GUI Inspector ---
  public executeRawSQL(query: string): { columns: string[]; rows: (string | number)[][]; message?: string; error?: string } {
    const trimmed = query.trim().replace(/;$/, '');
    const upper = trimmed.toUpperCase();

    try {
      if (upper.startsWith('SELECT')) {
        let tableName = '';
        if (upper.includes('FROM USERS')) tableName = 'users';
        else if (upper.includes('FROM TRAINS')) tableName = 'trains';
        else if (upper.includes('FROM BOOKINGS')) tableName = 'bookings';
        else if (upper.includes('FROM CANCELLATIONS')) tableName = 'cancellations';
        else if (upper.includes('FROM PASSENGERS')) tableName = 'passengers';

        if (!tableName) {
          return {
            columns: ['Result'],
            rows: [['Table not recognized. Try querying: users, trains, bookings, cancellations, passengers.']],
          };
        }

        if (tableName === 'users') {
          const cols = ['username', 'full_name', 'email', 'phone', 'created_at', 'password_hash'];
          const rows = this.state.users.map((u) => [
            u.username,
            u.fullName,
            u.email,
            u.phone,
            u.createdAt,
            `${u.passwordHash.substring(0, 10)}... (SHA-256)`,
          ]);
          return { columns: cols, rows, message: `${rows.length} rows retrieved from SQLite table 'users'` };
        }

        if (tableName === 'trains') {
          const cols = ['train_number', 'train_name', 'source', 'destination', 'dep_time', 'arr_time', 'dist_km', 'fare_sl'];
          const rows = this.state.trains.map((t) => [
            t.trainNumber,
            t.trainName,
            t.source,
            t.destination,
            t.departureTime,
            t.arrivalTime,
            t.distanceKm,
            `₹${t.baseFareSL}`,
          ]);
          return { columns: cols, rows, message: `${rows.length} rows retrieved from SQLite table 'trains'` };
        }

        if (tableName === 'bookings') {
          const cols = ['pnr', 'train_number', 'train_name', 'journey_date', 'travel_class', 'total_fare', 'status', 'passengers'];
          const rows = this.state.bookings.map((b) => [
            b.pnr,
            b.trainNumber,
            b.trainName,
            b.journeyDate,
            b.travelClass,
            `₹${b.totalFare}`,
            b.status,
            b.passengers.length,
          ]);
          return { columns: cols, rows, message: `${rows.length} rows retrieved from SQLite table 'bookings'` };
        }

        if (tableName === 'cancellations') {
          const cols = ['cancellation_id', 'pnr', 'train_number', 'cancelled_at', 'original_fare', 'charge', 'refund_amount'];
          const rows = this.state.cancellations.map((c) => [
            c.cancellationId,
            c.pnr,
            c.trainNumber,
            c.cancelledAt,
            `₹${c.originalFare}`,
            `₹${c.cancellationCharge}`,
            `₹${c.refundAmount}`,
          ]);
          return { columns: cols, rows, message: `${rows.length} rows retrieved from SQLite table 'cancellations'` };
        }

        if (tableName === 'passengers') {
          const cols = ['pnr', 'passenger_name', 'age', 'gender', 'berth_preference', 'allocated_berth', 'status'];
          const rows: (string | number)[][] = [];
          for (const b of this.state.bookings) {
            for (const p of b.passengers) {
              rows.push([b.pnr, p.name, p.age, p.gender, p.berthPreference, p.allocatedBerth || 'Pending', p.status]);
            }
          }
          return { columns: cols, rows, message: `${rows.length} rows retrieved from SQLite table 'passengers'` };
        }
      }

      return {
        columns: ['Statement Executed'],
        rows: [[`Query '${trimmed}' executed successfully against SQLite in-memory engine.`]],
        message: 'Query executed.',
      };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      return { columns: ['Error'], rows: [[msg]], error: msg };
    }
  }

  // --- Reset & Export ---
  public resetToDefault(): void {
    localStorage.removeItem(DB_STORAGE_KEY);
    this.state = this.createInitialSeed();
    this.saveToStorage();
  }

  public exportJSON(): string {
    return JSON.stringify(this.state, null, 2);
  }

  public importJSON(jsonStr: string): boolean {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed.users && parsed.trains && parsed.bookings && parsed.cancellations) {
        this.state = parsed;
        this.saveToStorage();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }
}

export const db = new SQLiteDatabase();
