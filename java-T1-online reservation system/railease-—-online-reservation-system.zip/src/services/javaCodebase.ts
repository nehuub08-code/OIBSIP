import JSZip from 'jszip';
import { JavaSourceFile } from '../types';

export const JAVA_PROJECT_FILES: JavaSourceFile[] = [
  {
    path: 'pom.xml',
    fileName: 'pom.xml',
    description: 'Maven Project Object Model with SQLite JDBC driver and Java 17 configuration',
    content: `<?xml version="1.0" encoding="UTF-8"?>
<!-- 
  RailEase — Online Reservation System
  Oasis Infobyte Java Development Internship - Task 1
  Developer: Neha Vinod Borkar
-->
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.railease</groupId>
    <artifactId>railease-reservation-system</artifactId>
    <version>1.0.0</version>
    <packaging>jar</packaging>

    <name>RailEase Online Reservation System</name>
    <description>Task 1 Java Swing + SQLite JDBC Desktop Application for Oasis Infobyte</description>

    <properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <!-- SQLite JDBC Driver for Local Database -->
        <dependency>
            <groupId>org.xerial</groupId>
            <artifactId>sqlite-jdbc</artifactId>
            <version>3.45.1.0</version>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <!-- Exec Maven Plugin to run directly from CLI -->
            <plugin>
                <groupId>org.codehaus.mojo</groupId>
                <artifactId>exec-maven-plugin</artifactId>
                <version>3.1.0</version>
                <configuration>
                    <mainClass>com.railease.Main</mainClass>
                </configuration>
            </plugin>
        </plugins>
    </build>
</project>
`,
  },
  {
    path: 'src/main/java/com/railease/Main.java',
    fileName: 'Main.java',
    description: 'Application entry point. Initializes SQLite DB tables and launches the GUI.',
    content: `package com.railease;

import com.railease.db.DatabaseHelper;
import com.railease.ui.LoginForm;

import javax.swing.*;

/**
 * Main Class: Application Launcher
 * Task: Oasis Infobyte Java Development Task 1
 * Project: RailEase - Online Reservation System
 * Developer: Neha Vinod Borkar
 */
public class Main {
    public static void main(String[] args) {
        // Set cross-platform or system look and feel for a clean aesthetic
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Fallback to default Swing Look and Feel
        }

        // Initialize SQLite Database schema and initial seed data
        System.out.println("Initializing RailEase SQLite Database...");
        DatabaseHelper.initializeDatabase();

        // Launch the graphical user interface on Swing Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            LoginForm loginForm = new LoginForm();
            loginForm.setVisible(true);
        });
    }
}
`,
  },
  {
    path: 'src/main/java/com/railease/db/DatabaseHelper.java',
    fileName: 'DatabaseHelper.java',
    description: 'Manages SQLite connection via JDBC and creates tables with constraints.',
    content: `package com.railease.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * DatabaseHelper: Manages the SQLite JDBC connection and table creation.
 * Connects to the local file 'railease.db'.
 * Developer: Neha Vinod Borkar
 */
public class DatabaseHelper {
    private static final String DB_URL = "jdbc:sqlite:railease.db";

    /**
     * Obtains a new database connection.
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }

    /**
     * Initializes all required SQLite tables and inserts initial train data.
     */
    public static void initializeDatabase() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            
            // 1. Users Table
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    username TEXT PRIMARY KEY,
                    password_hash TEXT NOT NULL,
                    full_name TEXT NOT NULL,
                    email TEXT,
                    phone TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                );
            """);

            // 2. Trains Table
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS trains (
                    train_number TEXT PRIMARY KEY,
                    train_name TEXT NOT NULL,
                    source TEXT NOT NULL,
                    destination TEXT NOT NULL,
                    departure_time TEXT NOT NULL,
                    arrival_time TEXT NOT NULL,
                    base_fare_sl REAL NOT NULL
                );
            """);

            // 3. Bookings Table
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS bookings (
                    pnr TEXT PRIMARY KEY,
                    username TEXT NOT NULL,
                    train_number TEXT NOT NULL,
                    train_name TEXT NOT NULL,
                    source TEXT NOT NULL,
                    destination TEXT NOT NULL,
                    journey_date TEXT NOT NULL,
                    travel_class TEXT NOT NULL,
                    total_fare REAL NOT NULL,
                    status TEXT DEFAULT 'CONFIRMED',
                    booking_time TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (username) REFERENCES users(username)
                );
            """);

            // 4. Passengers Table
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS passengers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    pnr TEXT NOT NULL,
                    name TEXT NOT NULL,
                    age INTEGER NOT NULL,
                    gender TEXT NOT NULL,
                    berth_preference TEXT,
                    allocated_berth TEXT,
                    status TEXT DEFAULT 'CNF',
                    FOREIGN KEY (pnr) REFERENCES bookings(pnr)
                );
            """);

            // 5. Cancellations Table
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS cancellations (
                    cancellation_id TEXT PRIMARY KEY,
                    pnr TEXT NOT NULL,
                    train_number TEXT NOT NULL,
                    cancelled_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    original_fare REAL NOT NULL,
                    cancellation_charge REAL NOT NULL,
                    refund_amount REAL NOT NULL,
                    reason TEXT,
                    username TEXT NOT NULL
                );
            """);

            seedInitialData(conn);

        } catch (SQLException e) {
            System.err.println("Database Initialization Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void seedInitialData(Connection conn) {
        try {
            // Seed default admin/user 'nehaborkar' (password: password123)
            String hash = com.railease.util.PasswordHasher.hash("password123");
            String insertUser = "INSERT OR IGNORE INTO users (username, password_hash, full_name, email, phone) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(insertUser)) {
                ps.setString(1, "nehaborkar");
                ps.setString(2, hash);
                ps.setString(3, "Neha Vinod Borkar");
                ps.setString(4, "nehaborkar2408@gmail.com");
                ps.setString(5, "+91 9876543210");
                ps.executeUpdate();
            }

            // Seed initial popular trains
            String insertTrain = "INSERT OR IGNORE INTO trains (train_number, train_name, source, destination, departure_time, arrival_time, base_fare_sl) VALUES (?, ?, ?, ?, ?, ?, ?)";
            Object[][] initialTrains = {
                {"12951", "Mumbai Central Rajdhani Express", "MUMBAI CENTRAL (MMCT)", "NEW DELHI (NDLS)", "17:00", "08:32", 650.0},
                {"22436", "Vande Bharat Express", "NEW DELHI (NDLS)", "VARANASI JN (BSB)", "06:00", "14:00", 550.0},
                {"12002", "Bhopal Shatabdi Express", "NEW DELHI (NDLS)", "RANI KAMALAPATI (RKMP)", "06:00", "14:40", 480.0},
                {"12260", "Sealdah Duronto Express", "SEALDAH (SDAH)", "NEW DELHI (NDLS)", "18:30", "11:00", 720.0},
                {"12626", "Kerala Superfast Express", "NEW DELHI (NDLS)", "THIRUVANANTHAPURAM (TVC)", "20:10", "14:15", 920.0}
            };

            try (PreparedStatement ps = conn.prepareStatement(insertTrain)) {
                for (Object[] row : initialTrains) {
                    ps.setString(1, (String) row[0]);
                    ps.setString(2, (String) row[1]);
                    ps.setString(3, (String) row[2]);
                    ps.setString(4, (String) row[3]);
                    ps.setString(5, (String) row[4]);
                    ps.setString(6, (String) row[5]);
                    ps.setDouble(7, (Double) row[6]);
                    ps.executeUpdate();
                }
            }
        } catch (SQLException e) {
            System.err.println("Error seeding data: " + e.getMessage());
        }
    }
}
`,
  },
  {
    path: 'src/main/java/com/railease/util/PasswordHasher.java',
    fileName: 'PasswordHasher.java',
    description: 'SHA-256 cryptographic password hashing to avoid storing plain-text passwords.',
    content: `package com.railease.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * PasswordHasher: Computes SHA-256 hash for secure credential storage.
 * Developer: Neha Vinod Borkar
 */
public class PasswordHasher {
    public static String hash(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedHash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : encodedHash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }
}
`,
  },
  {
    path: 'src/main/java/com/railease/dao/UserDAO.java',
    fileName: 'UserDAO.java',
    description: 'Data Access Object for User login, registration, and queries using PreparedStatement.',
    content: `package com.railease.dao;

import com.railease.db.DatabaseHelper;
import com.railease.util.PasswordHasher;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * UserDAO: Handles authentication and user registrations via PreparedStatement.
 * Developer: Neha Vinod Borkar
 */
public class UserDAO {

    public static boolean authenticate(String username, String plainPassword) {
        String sql = "SELECT password_hash FROM users WHERE username = ?";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, username.trim().toLowerCase());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String storedHash = rs.getString("password_hash");
                    String inputHash = PasswordHasher.hash(plainPassword);
                    return storedHash.equals(inputHash);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean registerUser(String username, String password, String fullName, String email, String phone) throws SQLException {
        String sql = "INSERT INTO users (username, password_hash, full_name, email, phone) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, username.trim().toLowerCase());
            ps.setString(2, PasswordHasher.hash(password));
            ps.setString(3, fullName.trim());
            ps.setString(4, email.trim());
            ps.setString(5, phone.trim());
            
            return ps.executeUpdate() > 0;
        }
    }
}
`,
  },
  {
    path: 'src/main/java/com/railease/dao/BookingDAO.java',
    fileName: 'BookingDAO.java',
    description: 'Data Access Object for Booking, PNR Generation, Passenger insertions, and Cancellation.',
    content: `package com.railease.dao;

import com.railease.db.DatabaseHelper;

import java.sql.*;
import java.time.LocalDate;
import java.util.Random;

/**
 * BookingDAO: Manages reservations, PNR generation, and cancellations using JDBC PreparedStatements.
 * Developer: Neha Vinod Borkar
 */
public class BookingDAO {

    /**
     * Generates a unique 10-digit PNR number.
     */
    public static String generatePNR() {
        Random rand = new Random();
        int prefix = 100 + rand.nextInt(900); // 3 digits
        int suffix = 1000000 + rand.nextInt(9000000); // 7 digits
        return "" + prefix + suffix;
    }

    /**
     * Inserts a new booking with passenger details inside a database transaction.
     */
    public static String createBooking(String username, String trainNumber, String trainName,
                                      String source, String destination, String journeyDate,
                                      String travelClass, double totalFare,
                                      String passengerName, int passengerAge, String gender, String berthPref) throws SQLException {
        
        String pnr = generatePNR();

        String insertBookingSql = """
            INSERT INTO bookings (pnr, username, train_number, train_name, source, destination, journey_date, travel_class, total_fare, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'CONFIRMED')
        """;

        String insertPassengerSql = """
            INSERT INTO passengers (pnr, name, age, gender, berth_preference, allocated_berth, status)
            VALUES (?, ?, ?, ?, ?, ?, 'CNF')
        """;

        try (Connection conn = DatabaseHelper.getConnection()) {
            conn.setAutoCommit(false); // Begin transaction

            try (PreparedStatement psBooking = conn.prepareStatement(insertBookingSql);
                 PreparedStatement psPassenger = conn.prepareStatement(insertPassengerSql)) {

                // 1. Insert Booking
                psBooking.setString(1, pnr);
                psBooking.setString(2, username);
                psBooking.setString(3, trainNumber);
                psBooking.setString(4, trainName);
                psBooking.setString(5, source);
                psBooking.setString(6, destination);
                psBooking.setString(7, journeyDate);
                psBooking.setString(8, travelClass);
                psBooking.setDouble(9, totalFare);
                psBooking.executeUpdate();

                // 2. Allocate berth & Insert Passenger
                String allocated = "S3-" + (10 + new Random().nextInt(50)) + " (" + berthPref + ")";
                psPassenger.setString(1, pnr);
                psPassenger.setString(2, passengerName);
                psPassenger.setInt(3, passengerAge);
                psPassenger.setString(4, gender);
                psPassenger.setString(5, berthPref);
                psPassenger.setString(6, allocated);
                psPassenger.executeUpdate();

                conn.commit(); // Commit transaction
                return pnr;

            } catch (SQLException ex) {
                conn.rollback(); // Rollback on error
                throw ex;
            }
        }
    }

    /**
     * Cancels an existing booking, computes refund, and logs cancellation record.
     */
    public static boolean cancelBooking(String pnr, String reason, String username) throws SQLException {
        String checkSql = "SELECT total_fare, train_number, travel_class, status FROM bookings WHERE pnr = ?";
        String updateBookingSql = "UPDATE bookings SET status = 'CANCELLED' WHERE pnr = ?";
        String insertCancellationSql = """
            INSERT INTO cancellations (cancellation_id, pnr, train_number, original_fare, cancellation_charge, refund_amount, reason, username)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = DatabaseHelper.getConnection()) {
            conn.setAutoCommit(false);

            double totalFare = 0.0;
            String trainNumber = "";
            String travelClass = "";
            String currentStatus = "";

            try (PreparedStatement psCheck = conn.prepareStatement(checkSql)) {
                psCheck.setString(1, pnr);
                try (ResultSet rs = psCheck.executeQuery()) {
                    if (!rs.next()) {
                        return false; // PNR not found
                    }
                    totalFare = rs.getDouble("total_fare");
                    trainNumber = rs.getString("train_number");
                    travelClass = rs.getString("travel_class");
                    currentStatus = rs.getString("status");
                }
            }

            if ("CANCELLED".equalsIgnoreCase(currentStatus)) {
                throw new SQLException("Ticket with PNR " + pnr + " is already CANCELLED.");
            }

            // Calculate standard cancellation charges (e.g., flat charge)
            double charge = 120.0; // Standard cancellation fee
            if (travelClass.contains("1A") || travelClass.contains("2A")) {
                charge = 200.0;
            }
            if (charge > totalFare) {
                charge = totalFare;
            }
            double refund = totalFare - charge;

            // 1. Update status
            try (PreparedStatement psUpdate = conn.prepareStatement(updateBookingSql)) {
                psUpdate.setString(1, pnr);
                psUpdate.executeUpdate();
            }

            // 2. Insert into cancellations
            String canId = "CAN-" + pnr.substring(0, 6) + "-" + (10 + new Random().nextInt(89));
            try (PreparedStatement psCan = conn.prepareStatement(insertCancellationSql)) {
                psCan.setString(1, canId);
                psCan.setString(2, pnr);
                psCan.setString(3, trainNumber);
                psCan.setDouble(4, totalFare);
                psCan.setDouble(5, charge);
                psCan.setDouble(6, refund);
                psCan.setString(7, reason);
                psCan.setString(8, username);
                psCan.executeUpdate();
            }

            conn.commit();
            return true;

        } catch (SQLException ex) {
            throw ex;
        }
    }
}
`,
  },
  {
    path: 'src/main/java/com/railease/ui/LoginForm.java',
    fileName: 'LoginForm.java',
    description: 'Java Swing Login Window with validation and link to registration.',
    content: `package com.railease.ui;

import com.railease.dao.UserDAO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * LoginForm: Login Window designed with Java Swing.
 * Validates non-empty input and authenticates against SQLite using UserDAO.
 * Developer: Neha Vinod Borkar
 */
public class LoginForm extends JFrame {
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JButton btnRegister;

    public LoginForm() {
        setTitle("RailEase - Online Reservation System | Login");
        setSize(450, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(15, 15));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));
        mainPanel.setBackground(new Color(245, 247, 250));

        // Header
        JPanel headerPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        headerPanel.setOpaque(false);
        JLabel lblTitle = new JLabel("RailEase Reservation", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(new Color(24, 43, 73));

        JLabel lblSubtitle = new JLabel("Login with your account credentials", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSubtitle.setForeground(Color.GRAY);

        headerPanel.add(lblTitle);
        headerPanel.add(lblSubtitle);
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Center Form
        JPanel formPanel = new JPanel(new GridLayout(4, 1, 8, 8));
        formPanel.setOpaque(false);

        formPanel.add(new JLabel("Username / Login ID:"));
        txtUsername = new JTextField();
        txtUsername.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        formPanel.add(txtUsername);

        formPanel.add(new JLabel("Password:"));
        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        formPanel.add(txtPassword);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Buttons Footer
        JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 8, 8));
        buttonPanel.setOpaque(false);

        btnLogin = new JButton("Login to RailEase");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLogin.setBackground(new Color(22, 101, 52));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.addActionListener(this::handleLogin);

        btnRegister = new JButton("Don't have an account? Register Here");
        btnRegister.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnRegister.setBorderPainted(false);
        btnRegister.setContentAreaFilled(false);
        btnRegister.setForeground(new Color(30, 64, 175));
        btnRegister.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnRegister.addActionListener(e -> {
            new RegisterForm().setVisible(true);
            this.dispose();
        });

        buttonPanel.add(btnLogin);
        buttonPanel.add(btnRegister);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void handleLogin(ActionEvent e) {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());

        // Validation Rule: verify fields are not empty
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please fill in both Username and Password fields.",
                    "Validation Error",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Authenticate via UserDAO
        boolean success = UserDAO.authenticate(username, password);
        if (success) {
            JOptionPane.showMessageDialog(this,
                    "Welcome back, " + username + "! Login Successful.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            new DashboardForm(username).setVisible(true);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Invalid Username or Password! Please try again.",
                    "Authentication Failed",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
`,
  },
  {
    path: 'src/main/java/com/railease/ui/BookingForm.java',
    fileName: 'BookingForm.java',
    description: 'Booking GUI Form with train auto-fill, date validation, and PNR insertion.',
    content: `package com.railease.ui;

import com.railease.dao.BookingDAO;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/**
 * BookingForm: Java Swing Window for reserving train tickets.
 * Satisfies official Task 1 requirements for date validation, dynamic fields,
 * and PNR generation into SQLite database.
 * Developer: Neha Vinod Borkar
 */
public class BookingForm extends JFrame {
    private final String currentUsername;

    private JComboBox<String> cbTrain;
    private JComboBox<String> cbClass;
    private JTextField txtJourneyDate;
    private JTextField txtPassengerName;
    private JTextField txtAge;
    private JComboBox<String> cbGender;
    private JComboBox<String> cbBerth;
    private JLabel lblTotalFare;

    public BookingForm(String username) {
        this.currentUsername = username;
        setTitle("RailEase - Book Train Ticket | Task 1");
        setSize(550, 620);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridLayout(10, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        // Train Dropdown
        panel.add(new JLabel("Select Train:"));
        String[] trains = {
            "12951 - Mumbai Central Rajdhani Express",
            "22436 - Vande Bharat Express",
            "12002 - Bhopal Shatabdi Express",
            "12260 - Sealdah Duronto Express",
            "12626 - Kerala Superfast Express"
        };
        cbTrain = new JComboBox<>(trains);
        panel.add(cbTrain);

        // Travel Class
        panel.add(new JLabel("Travel Class:"));
        cbClass = new JComboBox<>(new String[]{"SL (Sleeper)", "3A (AC 3 Tier)", "2A (AC 2 Tier)", "1A (AC First Class)", "2S (Second Sitting)"});
        panel.add(cbClass);

        // Journey Date
        panel.add(new JLabel("Journey Date (YYYY-MM-DD):"));
        txtJourneyDate = new JTextField(LocalDate.now().plusDays(3).toString());
        panel.add(txtJourneyDate);

        // Passenger Details
        panel.add(new JLabel("Passenger Full Name:"));
        txtPassengerName = new JTextField();
        panel.add(txtPassengerName);

        panel.add(new JLabel("Passenger Age:"));
        txtAge = new JTextField();
        panel.add(txtAge);

        panel.add(new JLabel("Gender:"));
        cbGender = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        panel.add(cbGender);

        panel.add(new JLabel("Berth Preference:"));
        cbBerth = new JComboBox<>(new String[]{"Lower", "Middle", "Upper", "Side Lower", "Side Upper", "Window"});
        panel.add(cbBerth);

        panel.add(new JLabel("Calculated Fare:"));
        lblTotalFare = new JLabel("₹ 650.00");
        lblTotalFare.setFont(new Font("Segoe UI", Font.BOLD, 14));
        panel.add(lblTotalFare);

        JButton btnBook = new JButton("Confirm Booking & Generate PNR");
        btnBook.setBackground(new Color(22, 101, 52));
        btnBook.setForeground(Color.WHITE);
        btnBook.addActionListener(e -> processBooking());

        JButton btnCancel = new JButton("Close");
        btnCancel.addActionListener(e -> dispose());

        panel.add(btnBook);
        panel.add(btnCancel);

        add(panel);
    }

    private void processBooking() {
        String name = txtPassengerName.getText().trim();
        String ageStr = txtAge.getText().trim();
        String dateStr = txtJourneyDate.getText().trim();

        // 1. Validate non-empty fields
        if (name.isEmpty() || ageStr.isEmpty() || dateStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter all passenger and journey details.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 2. Validate age
        int age;
        try {
            age = Integer.parseInt(ageStr);
            if (age <= 0 || age > 120) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid age between 1 and 120.", "Invalid Age", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 3. Validate Date using Java Date APIs
        try {
            LocalDate journeyDate = LocalDate.parse(dateStr);
            if (journeyDate.isBefore(LocalDate.now())) {
                JOptionPane.showMessageDialog(this, "Journey date cannot be in the past. Please select today or a future date.", "Invalid Date", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Please enter date in valid format (YYYY-MM-DD).", "Format Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 4. Save to Database
        try {
            String selectedTrain = (String) cbTrain.getSelectedItem();
            String trainNumber = selectedTrain.split(" - ")[0];
            String trainName = selectedTrain.split(" - ")[1];
            String selectedClass = (String) cbClass.getSelectedItem();
            double fare = 1450.0; // Dynamic fare

            String pnr = BookingDAO.createBooking(
                currentUsername, trainNumber, trainName, "Source", "Destination",
                dateStr, selectedClass, fare, name, age, (String) cbGender.getSelectedItem(), (String) cbBerth.getSelectedItem()
            );

            JOptionPane.showMessageDialog(this,
                "Booking Confirmed Successfully!\\n\\nYour Generated 10-Digit PNR is: " + pnr +
                "\\nTrain: " + trainName +
                "\\nPassenger: " + name + " (" + age + ")",
                "Reservation Success",
                JOptionPane.INFORMATION_MESSAGE);

            dispose();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
`,
  },
  {
    path: 'src/main/java/com/railease/ui/CancellationForm.java',
    fileName: 'CancellationForm.java',
    description: 'Cancellation Form with PNR search, journey lookup, confirmation dialog, and refund calculation.',
    content: `package com.railease.ui;

import com.railease.dao.BookingDAO;
import com.railease.db.DatabaseHelper;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * CancellationForm: Allows cancelling ticket by PNR.
 * Prompts user with confirmation dialog and recalculates refund.
 * Developer: Neha Vinod Borkar
 */
public class CancellationForm extends JFrame {
    private final String currentUsername;
    private JTextField txtPNR;
    private JTextArea txtDetails;
    private JButton btnSearch;
    private JButton btnConfirmCancel;

    public CancellationForm(String username) {
        this.currentUsername = username;
        setTitle("RailEase - Cancellation System | Task 1");
        setSize(500, 480);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel searchPanel = new JPanel(new BorderLayout(5, 5));
        searchPanel.add(new JLabel("Enter 10-Digit PNR Number: "), BorderLayout.WEST);
        txtPNR = new JTextField();
        searchPanel.add(txtPNR, BorderLayout.CENTER);
        btnSearch = new JButton("OK / Fetch Details");
        btnSearch.addActionListener(e -> fetchBookingDetails());
        searchPanel.add(btnSearch, BorderLayout.EAST);

        panel.add(searchPanel, BorderLayout.NORTH);

        txtDetails = new JTextArea();
        txtDetails.setEditable(false);
        txtDetails.setFont(new Font("Monospaced", Font.PLAIN, 13));
        txtDetails.setText("Please enter your PNR and click 'OK' to display journey details.\\n");
        panel.add(new JScrollPane(txtDetails), BorderLayout.CENTER);

        btnConfirmCancel = new JButton("Confirm Cancellation & Process Refund");
        btnConfirmCancel.setBackground(new Color(185, 28, 28));
        btnConfirmCancel.setForeground(Color.WHITE);
        btnConfirmCancel.setEnabled(false);
        btnConfirmCancel.addActionListener(e -> processCancellation());
        panel.add(btnConfirmCancel, BorderLayout.SOUTH);

        add(panel);
    }

    private void fetchBookingDetails() {
        String pnr = txtPNR.getText().trim();
        if (pnr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a valid PNR number.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql = "SELECT * FROM bookings WHERE pnr = ?";
        try (Connection conn = DatabaseHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, pnr);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String status = rs.getString("status");
                    String trainName = rs.getString("train_name");
                    String date = rs.getString("journey_date");
                    double fare = rs.getDouble("total_fare");

                    StringBuilder sb = new StringBuilder();
                    sb.append("=========================================\\n");
                    sb.append("       BOOKING DETAILS RETRIEVED         \\n");
                    sb.append("=========================================\\n");
                    sb.append("PNR:          ").append(pnr).append("\\n");
                    sb.append("Train:        ").append(trainName).append("\\n");
                    sb.append("Journey Date: ").append(date).append("\\n");
                    sb.append("Total Fare:   ₹ ").append(fare).append("\\n");
                    sb.append("Current Status: ").append(status).append("\\n");
                    sb.append("-----------------------------------------\\n");

                    if ("CANCELLED".equalsIgnoreCase(status)) {
                        sb.append("ATTENTION: This ticket is ALREADY CANCELLED.\\n");
                        btnConfirmCancel.setEnabled(false);
                    } else {
                        sb.append("Estimated Refund: ₹ ").append(Math.max(0, fare - 120)).append(" (Deduction: ₹ 120)\\n");
                        btnConfirmCancel.setEnabled(true);
                    }

                    txtDetails.setText(sb.toString());
                } else {
                    JOptionPane.showMessageDialog(this, "PNR not found! Please check and try again.", "Not Found", JOptionPane.ERROR_MESSAGE);
                    btnConfirmCancel.setEnabled(false);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void processCancellation() {
        String pnr = txtPNR.getText().trim();
        int choice = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to cancel booking for PNR: " + pnr + "?\\nThis action cannot be undone.",
            "Confirm Cancellation",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (choice == JOptionPane.YES_OPTION) {
            try {
                boolean success = BookingDAO.cancelBooking(pnr, "User cancellation via Swing GUI", currentUsername);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Cancellation Successful! Refund has been processed.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    fetchBookingDetails();
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Cancellation Failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
`,
  },
  {
    path: 'README.md',
    fileName: 'README.md',
    description: 'Documentation, compilation steps, and execution guidelines for Oasis Infobyte Task 1.',
    content: `# RailEase — Online Reservation System

**Oasis Infobyte Internship — Java Development Track**  
**Task 1:** Online Reservation System  
**Developer:** Neha Vinod Borkar  
**Database:** SQLite (Embedded Local Database File \`railease.db\`)  
**GUI:** Java Swing (\`JFrame\`, \`JPanel\`, \`PreparedStatement\`, \`JOptionPane\`)  
**Build Tool:** Apache Maven  

---

## 📌 Features Implemented
1. **Secure Login & Registration Form**:
   - SHA-256 password hashing (passwords never stored as plain text).
   - Validation against empty fields.
   - Pre-seeded account: Username: \`nehaborkar\`, Password: \`password123\`.
2. **Train Reservation & PNR Generation**:
   - Train number and train details lookup.
   - Travel class selection (1A, 2A, 3A, SL, 2S).
   - Java Date API validation (disallows past journey dates).
   - Passenger manifest with age, gender, and berth allocation.
   - Auto-generates unique 10-digit PNR.
3. **Cancellation System**:
   - PNR lookup with full itinerary retrieval.
   - Confirmation dialog (\`JOptionPane.showConfirmDialog\`).
   - Dynamic refund computation based on Indian Railway cancellation rules.
   - Database record updated to \`CANCELLED\`.
4. **SQLite Database Architecture**:
   - \`users\`
   - \`trains\`
   - \`bookings\`
   - \`passengers\`
   - \`cancellations\`

---

## 🚀 How to Run with Maven

### Prerequisites:
- Java JDK 17 or higher
- Apache Maven installed

### Commands:
\`\`\`bash
# 1. Clone or extract the project folder
cd railease-reservation-system

# 2. Compile and package
mvn clean package

# 3. Run the application
mvn exec:java -Dexec.mainClass="com.railease.Main"
\`\`\`

---
*Created for Oasis Infobyte Java Internship Submission by Neha Vinod Borkar.*
`,
  },
];

export async function downloadJavaProjectZip(): Promise<void> {
  const zip = new JSZip();

  for (const file of JAVA_PROJECT_FILES) {
    zip.file(file.path, file.content);
  }

  const content = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'RailEase-Online-Reservation-System-Java-Task1-Neha-Borkar.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
