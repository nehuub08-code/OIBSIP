export type TravelClass = '1A' | '2A' | '3A' | 'SL' | '2S';

export interface Train {
  trainNumber: string;
  trainName: string;
  source: string;
  destination: string;
  departureTime: string;
  arrivalTime: string;
  distanceKm: number;
  baseFareSL: number;
  runsOn: string[]; // e.g. ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  availableSeats: {
    '1A': number;
    '2A': number;
    '3A': number;
    'SL': number;
    '2S': number;
  };
}

export interface Passenger {
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  berthPreference: 'Lower' | 'Middle' | 'Upper' | 'Side Lower' | 'Side Upper' | 'Window Seat' | 'No Preference';
  allocatedBerth?: string;
  status: 'CNF' | 'RAC' | 'WL';
}

export interface Booking {
  pnr: string;
  username: string;
  trainNumber: string;
  trainName: string;
  source: string;
  destination: string;
  journeyDate: string; // YYYY-MM-DD
  travelClass: TravelClass;
  passengers: Passenger[];
  totalFare: number;
  bookingTimestamp: string;
  status: 'CONFIRMED' | 'CANCELLED';
  quota: 'General' | 'Tatkal' | 'Ladies' | 'Senior Citizen';
}

export interface Cancellation {
  cancellationId: string;
  pnr: string;
  trainNumber: string;
  trainName: string;
  cancelledAt: string;
  journeyDate: string;
  originalFare: number;
  cancellationCharge: number;
  refundAmount: number;
  reason: string;
  username: string;
}

export interface User {
  username: string;
  passwordHash: string; // SHA-256 hash
  fullName: string;
  email: string;
  phone: string;
  createdAt: string;
}

export interface JavaSourceFile {
  path: string;
  fileName: string;
  description: string;
  content: string;
}
