import React from 'react';
import { Booking } from '../types';
import { Printer, X, Train, ShieldCheck, Calendar, Clock, MapPin, User, CheckCircle2, AlertTriangle } from 'lucide-react';

interface TicketModalProps {
  booking: Booking | null;
  onClose: () => void;
  onCancelTicket?: (pnr: string) => void;
  isSwingTheme: boolean;
}

export const TicketModal: React.FC<TicketModalProps> = ({
  booking,
  onClose,
  onCancelTicket,
  isSwingTheme,
}) => {
  if (!booking) return null;

  const handlePrint = () => {
    window.print();
  };

  const isCancelled = booking.status === 'CANCELLED';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className={`w-full max-w-3xl rounded-xl overflow-hidden shadow-2xl border transition-all ${
        isSwingTheme ? 'bg-white border-[#7f9db9]' : 'bg-slate-900 border-slate-700'
      }`}>
        
        {/* Modal Window Header */}
        <div className={`px-5 py-3 border-b flex items-center justify-between ${
          isSwingTheme 
            ? 'bg-gradient-to-r from-[#0a246a] to-[#2563eb] text-white' 
            : 'bg-slate-800 text-slate-100'
        }`}>
          <div className="flex items-center space-x-2">
            <Train className="w-5 h-5 text-amber-300" />
            <span className="font-bold text-sm tracking-wide">
              RailEase Electronic Reservation Slip (ERS)
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="px-2.5 py-1 text-xs rounded bg-white/20 hover:bg-white/30 text-white flex items-center space-x-1.5 transition"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Slip</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded hover:bg-white/20 text-white transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Ticket Content Container */}
        <div id="printable-ticket" className="p-6 text-slate-800 dark:text-slate-200">
          
          {/* Ticket Header */}
          <div className="border-b-2 border-dashed border-slate-300 dark:border-slate-700 pb-4 mb-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center space-x-2">
                  <div className="w-7 h-7 rounded bg-amber-500 text-slate-950 font-black flex items-center justify-center text-xs">
                    RE
                  </div>
                  <div>
                    <h2 className="text-xl font-black tracking-tight text-blue-900 dark:text-blue-400">
                      RailEase — Indian Railways E-Ticket
                    </h2>
                    <p className="text-[11px] text-slate-500 font-mono">
                      IRCTC Authorized Booking Engine • Oasis Infobyte Task 1
                    </p>
                  </div>
                </div>
              </div>

              {/* Status & PNR Pill */}
              <div className="text-right">
                <div className="text-xs text-slate-500 font-semibold uppercase">10-Digit PNR Number</div>
                <div className="font-mono text-xl font-bold tracking-widest text-emerald-600 dark:text-emerald-400">
                  {booking.pnr}
                </div>
                <div className="mt-1">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold ${
                    isCancelled 
                      ? 'bg-red-100 text-red-800 border border-red-300 dark:bg-red-950/60 dark:text-red-300' 
                      : 'bg-emerald-100 text-emerald-800 border border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-300'
                  }`}>
                    {isCancelled ? <AlertTriangle className="w-3 h-3 mr-1" /> : <CheckCircle2 className="w-3 h-3 mr-1" />}
                    {booking.status}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Train & Route Details Card */}
          <div className="bg-slate-50 dark:bg-slate-800/60 rounded-lg p-4 border border-slate-200 dark:border-slate-700 mb-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <span className="text-[11px] text-slate-400 font-medium block">TRAIN DETAILS</span>
                <span className="font-bold text-sm text-blue-950 dark:text-blue-200">
                  {booking.trainNumber} - {booking.trainName}
                </span>
                <span className="text-xs block text-slate-500 mt-0.5">
                  Class: <strong>{booking.travelClass}</strong> • Quota: <strong>{booking.quota}</strong>
                </span>
              </div>

              <div>
                <span className="text-[11px] text-slate-400 font-medium block">JOURNEY DATE</span>
                <div className="flex items-center space-x-1.5 text-sm font-semibold">
                  <Calendar className="w-3.5 h-3.5 text-blue-500" />
                  <span>{booking.journeyDate}</span>
                </div>
                <span className="text-[11px] text-slate-500 block mt-0.5">
                  Booked on: {booking.bookingTimestamp}
                </span>
              </div>

              <div>
                <span className="text-[11px] text-slate-400 font-medium block">ROUTE</span>
                <div className="text-xs font-semibold flex items-center space-x-1">
                  <MapPin className="w-3 h-3 text-red-500 shrink-0" />
                  <span>{booking.source}</span>
                </div>
                <div className="text-xs font-semibold flex items-center space-x-1 mt-1">
                  <MapPin className="w-3 h-3 text-emerald-500 shrink-0" />
                  <span>{booking.destination}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Passenger Manifest */}
          <div className="mb-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
              Passenger Manifest & Berth Allocation
            </h4>
            <div className="overflow-x-auto rounded border border-slate-200 dark:border-slate-700">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold">
                  <tr>
                    <th className="py-2 px-3">#</th>
                    <th className="py-2 px-3">Passenger Name</th>
                    <th className="py-2 px-3">Age / Gender</th>
                    <th className="py-2 px-3">Berth Preference</th>
                    <th className="py-2 px-3">Coach & Berth</th>
                    <th className="py-2 px-3">Current Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                  {booking.passengers.map((p, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                      <td className="py-2 px-3 font-mono">{idx + 1}</td>
                      <td className="py-2 px-3 font-semibold">{p.name}</td>
                      <td className="py-2 px-3">{p.age} Yrs / {p.gender}</td>
                      <td className="py-2 px-3">{p.berthPreference}</td>
                      <td className="py-2 px-3 font-mono font-bold text-blue-600 dark:text-blue-400">
                        {p.allocatedBerth || 'Confirmed'}
                      </td>
                      <td className="py-2 px-3">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          isCancelled ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'
                        }`}>
                          {isCancelled ? 'CAN' : p.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Fare Summary & Barcode */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-slate-200 dark:border-slate-700 pt-3">
            <div className="space-y-1 text-xs">
              <div className="flex justify-between text-slate-500">
                <span>Base Ticket Fare ({booking.passengers.length} Pax):</span>
                <span>₹ {(booking.totalFare * 0.88).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>IRCTC Reservation & Superfast Fee:</span>
                <span>₹ {(booking.totalFare * 0.07).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>GST (5%):</span>
                <span>₹ {(booking.totalFare * 0.05).toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-sm text-slate-900 dark:text-slate-100 pt-1 border-t">
                <span>Total Amount Paid:</span>
                <span className="text-emerald-600 dark:text-emerald-400">₹ {booking.totalFare.toFixed(2)}</span>
              </div>
            </div>

            {/* Visual Barcode & Authenticity stamp */}
            <div className="flex flex-col items-center justify-center p-2 rounded bg-slate-50 dark:bg-slate-800/50 border border-dashed border-slate-300 dark:border-slate-700">
              <div className="font-mono text-center tracking-widest text-[10px] text-slate-400 mb-1">
                |||||| | |||||||||| |||| | |||||||||||| ||||
              </div>
              <div className="text-[10px] text-slate-500 font-mono text-center">
                DIGITALLY VERIFIED TICKET #{booking.pnr}
              </div>
              <div className="text-[9px] text-slate-400 text-center mt-1">
                Developer: Neha Vinod Borkar • Oasis Infobyte Task 1
              </div>
            </div>
          </div>
        </div>

        {/* Modal Actions Footer */}
        <div className={`px-6 py-3 border-t flex flex-wrap items-center justify-between gap-2 ${
          isSwingTheme ? 'bg-[#ece9d8] border-[#d4d0c8]' : 'bg-slate-800/80 border-slate-700'
        }`}>
          <div>
            {!isCancelled && onCancelTicket && (
              <button
                onClick={() => {
                  onCancelTicket(booking.pnr);
                  onClose();
                }}
                className="px-3 py-1.5 rounded text-xs font-semibold bg-red-600 hover:bg-red-700 text-white transition flex items-center space-x-1"
              >
                <span>Cancel This Ticket</span>
              </button>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="px-4 py-1.5 rounded text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white transition flex items-center space-x-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save as PDF</span>
            </button>
            <button
              onClick={onClose}
              className={`px-4 py-1.5 rounded text-xs font-semibold border transition ${
                isSwingTheme 
                  ? 'bg-white hover:bg-slate-100 text-slate-700 border-slate-400' 
                  : 'bg-slate-700 hover:bg-slate-600 text-slate-200 border-slate-600'
              }`}
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
