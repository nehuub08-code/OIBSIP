import React, { useState } from 'react';
import { db } from '../services/db';
import { Booking, Cancellation, User } from '../types';
import { 
  XCircle, Search, AlertTriangle, CheckCircle2, 
  RotateCcw, DollarSign, Train, Calendar, User as UserIcon, ShieldAlert 
} from 'lucide-react';

interface CancellationFormProps {
  currentUser: User;
  isSwingTheme: boolean;
  onViewTicket: (pnr: string) => void;
}

export const CancellationForm: React.FC<CancellationFormProps> = ({
  currentUser,
  isSwingTheme,
  onViewTicket,
}) => {
  const [pnrInput, setPnrInput] = useState('');
  const [searchedBooking, setSearchedBooking] = useState<Booking | null>(null);
  const [cancellationRecord, setCancellationRecord] = useState<Cancellation | null>(null);
  
  const [cancellationReason, setCancellationReason] = useState('Personal reasons / Plan changed');
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleSearchPNR = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);
    setCancellationRecord(null);

    const cleanPNR = pnrInput.trim();
    if (!cleanPNR) {
      setErrorMessage('Please enter a 10-digit PNR number.');
      setSearchedBooking(null);
      return;
    }

    const booking = db.getBookingByPNR(cleanPNR);
    if (!booking) {
      setErrorMessage(`PNR "${cleanPNR}" not found in SQLite database! Please check and try again.`);
      setSearchedBooking(null);
      return;
    }

    setSearchedBooking(booking);

    // If already cancelled, load its cancellation record
    if (booking.status === 'CANCELLED') {
      const rec = db.getCancellationByPNR(cleanPNR);
      if (rec) setCancellationRecord(rec);
    }
  };

  const handleConfirmCancellation = () => {
    if (!searchedBooking) return;
    setShowConfirmModal(false);
    setLoading(true);

    try {
      const result = db.cancelBooking(searchedBooking.pnr, cancellationReason);
      if (result.success && result.cancellation) {
        setCancellationRecord(result.cancellation);
        // Refresh booking state
        const updated = db.getBookingByPNR(searchedBooking.pnr);
        if (updated) setSearchedBooking(updated);
        setSuccessMessage(`Ticket for PNR ${searchedBooking.pnr} has been cancelled successfully. Refund initiated!`);
      } else {
        setErrorMessage(result.error || 'Failed to cancel reservation.');
      }
    } catch {
      setErrorMessage('Database error occurred while executing cancellation.');
    } finally {
      setLoading(false);
    }
  };

  // Quick calculate preview
  const perPassengerCharge = searchedBooking
    ? searchedBooking.travelClass === '1A' || searchedBooking.travelClass === '2A'
      ? 200
      : 120
    : 120;
  const estimatedCharge = searchedBooking ? perPassengerCharge * searchedBooking.passengers.length : 0;
  const estimatedRefund = searchedBooking ? Math.max(0, searchedBooking.totalFare - estimatedCharge) : 0;

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      {/* Form Title Banner */}
      <div className={`p-4 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
        isSwingTheme ? 'bg-[#e2e8f0] border-[#94a3b8]' : 'bg-slate-900 border-slate-800'
      }`}>
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded bg-red-700 text-white">
            <XCircle className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-base text-red-950 dark:text-red-300">
              Ticket Cancellation & Refund Portal
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
              Update Query: UPDATE bookings SET status = 'CANCELLED' WHERE pnr = ?
            </p>
          </div>
        </div>
        <div className="text-xs font-semibold px-2.5 py-1 bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300 rounded border border-red-300">
          Deduction Rules: Flat Cancellation Charge Applied
        </div>
      </div>

      {errorMessage && (
        <div className="p-3 rounded text-xs bg-red-100 border border-red-300 text-red-800 flex items-start space-x-2 dark:bg-red-950/60 dark:border-red-800 dark:text-red-300">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      {successMessage && (
        <div className="p-3 rounded text-xs bg-emerald-100 border border-emerald-300 text-emerald-800 flex items-start space-x-2 dark:bg-emerald-950/60 dark:border-emerald-800 dark:text-emerald-300">
          <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* PNR Search Card */}
      <div className={`p-5 rounded-lg border space-y-4 ${
        isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/60 border-slate-800'
      }`}>
        <form onSubmit={handleSearchPNR} className="space-y-3">
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
            Enter 10-Digit PNR Number to Fetch Journey Details <span className="text-red-500">*</span>
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                maxLength={10}
                value={pnrInput}
                onChange={(e) => setPnrInput(e.target.value)}
                placeholder="e.g. 2458910472"
                className={`w-full px-3 py-2 text-sm rounded border font-mono tracking-wider transition outline-none ${
                  isSwingTheme 
                    ? 'bg-white border-[#7f9db9] text-slate-800 focus:border-blue-600' 
                    : 'bg-slate-950 border-slate-700 text-slate-100'
                }`}
              />
            </div>
            <button
              type="submit"
              className={`px-5 py-2 rounded text-xs font-bold transition flex items-center justify-center space-x-1.5 ${
                isSwingTheme 
                  ? 'bg-[#0a246a] hover:bg-[#183a8b] text-white shadow' 
                  : 'bg-blue-600 hover:bg-blue-500 text-white'
              }`}
            >
              <Search className="w-3.5 h-3.5" />
              <span>OK / Fetch Details</span>
            </button>
          </div>
          <p className="text-[11px] text-slate-400">
            Tip: Try pre-seeded PNR <code>2458910472</code> or any newly booked ticket.
          </p>
        </form>
      </div>

      {/* Searched Booking Details */}
      {searchedBooking && (
        <div className={`p-5 rounded-lg border space-y-4 ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/60 border-slate-800'
        }`}>
          <div className="flex items-center justify-between border-b pb-2 border-slate-200 dark:border-slate-800">
            <div className="flex items-center space-x-2">
              <Train className="w-4 h-4 text-blue-500" />
              <h3 className="font-bold text-sm text-slate-800 dark:text-slate-200">
                Booking Information for PNR: <span className="font-mono text-blue-600 dark:text-blue-400">{searchedBooking.pnr}</span>
              </h3>
            </div>
            <span className={`px-2 py-0.5 rounded text-xs font-bold ${
              searchedBooking.status === 'CANCELLED' 
                ? 'bg-red-100 text-red-800 border border-red-300 dark:bg-red-950 dark:text-red-300' 
                : 'bg-emerald-100 text-emerald-800 border border-emerald-300 dark:bg-emerald-950 dark:text-emerald-300'
            }`}>
              {searchedBooking.status}
            </span>
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div className="p-3 rounded bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
              <span className="text-[10px] text-slate-400 font-bold block">TRAIN</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">{searchedBooking.trainNumber} - {searchedBooking.trainName}</span>
              <span className="text-[11px] text-slate-500 block mt-0.5">Class: {searchedBooking.travelClass}</span>
            </div>

            <div className="p-3 rounded bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
              <span className="text-[10px] text-slate-400 font-bold block">JOURNEY DATE</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">{searchedBooking.journeyDate}</span>
              <span className="text-[11px] text-slate-500 block mt-0.5">Quota: {searchedBooking.quota}</span>
            </div>

            <div className="p-3 rounded bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
              <span className="text-[10px] text-slate-400 font-bold block">ROUTE</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">{searchedBooking.source}</span>
              <span className="text-[11px] text-slate-500 block mt-0.5">to {searchedBooking.destination}</span>
            </div>

            <div className="p-3 rounded bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
              <span className="text-[10px] text-slate-400 font-bold block">TOTAL FARE PAID</span>
              <span className="text-base font-bold text-emerald-600 dark:text-emerald-400">₹ {searchedBooking.totalFare.toFixed(2)}</span>
              <span className="text-[11px] text-slate-500 block mt-0.5">{searchedBooking.passengers.length} Passenger(s)</span>
            </div>
          </div>

          {/* Passenger Manifest */}
          <div>
            <h4 className="text-xs font-bold text-slate-600 dark:text-slate-400 mb-1.5">Passengers:</h4>
            <div className="space-y-1">
              {searchedBooking.passengers.map((p, idx) => (
                <div key={idx} className="text-xs px-3 py-1.5 rounded bg-slate-100 dark:bg-slate-800 flex justify-between items-center">
                  <span>{idx + 1}. <strong>{p.name}</strong> ({p.age} Yrs / {p.gender})</span>
                  <span className="font-mono text-blue-600 dark:text-blue-400">{p.allocatedBerth || 'Berth Assigned'}</span>
                </div>
              ))}
            </div>
          </div>

          {/* If already cancelled, show cancellation slip */}
          {searchedBooking.status === 'CANCELLED' ? (
            <div className="p-4 rounded-lg bg-red-50 border border-red-200 dark:bg-red-950/40 dark:border-red-900 space-y-2">
              <div className="flex items-center space-x-2 text-red-800 dark:text-red-300 font-bold text-xs">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>THIS TICKET IS ALREADY CANCELLED</span>
              </div>
              {cancellationRecord && (
                <div className="text-xs text-red-900 dark:text-red-200 space-y-1 pt-1 border-t border-red-200 dark:border-red-800">
                  <div className="flex justify-between">
                    <span>Cancellation ID:</span>
                    <span className="font-mono font-bold">{cancellationRecord.cancellationId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cancelled At:</span>
                    <span>{cancellationRecord.cancelledAt}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cancellation Deduction Fee:</span>
                    <span>₹ {cancellationRecord.cancellationCharge.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-sm">
                    <span>Refund Initiated to Account:</span>
                    <span className="text-emerald-700 dark:text-emerald-400">₹ {cancellationRecord.refundAmount.toFixed(2)}</span>
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* Refund Estimation & Cancellation Action */
            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-4">
              <div className="p-3 rounded bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 space-y-1.5">
                <div className="font-bold flex items-center space-x-1">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>Refund Policy Calculation:</span>
                </div>
                <div className="flex justify-between">
                  <span>Original Booking Amount:</span>
                  <span>₹ {searchedBooking.totalFare.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Standard Cancellation Charge ({searchedBooking.travelClass}):</span>
                  <span>- ₹ {estimatedCharge.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold border-t border-amber-200 dark:border-amber-800 pt-1 text-sm text-emerald-700 dark:text-emerald-400">
                  <span>Net Refund Payable to Customer:</span>
                  <span>₹ {estimatedRefund.toFixed(2)}</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Reason for Cancellation:
                </label>
                <select
                  value={cancellationReason}
                  onChange={(e) => setCancellationReason(e.target.value)}
                  className={`w-full px-3 py-2 text-xs rounded border transition outline-none ${
                    isSwingTheme ? 'bg-white border-[#7f9db9] text-slate-800' : 'bg-slate-950 border-slate-700 text-slate-100'
                  }`}
                >
                  <option value="Personal reasons / Plan changed">Personal reasons / Plan changed</option>
                  <option value="Train delayed or route modified">Train delayed or route modified</option>
                  <option value="Medical emergency">Medical emergency</option>
                  <option value="Booked alternate conveyance / flight">Booked alternate conveyance / flight</option>
                  <option value="Duplicate booking made by error">Duplicate booking made by error</option>
                </select>
              </div>

              <div className="flex flex-wrap items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => onViewTicket(searchedBooking.pnr)}
                  className={`px-4 py-2 text-xs font-semibold rounded border transition ${
                    isSwingTheme ? 'bg-white border-slate-400 text-slate-700' : 'bg-slate-800 border-slate-700 text-slate-200'
                  }`}
                >
                  View Current Ticket Slip
                </button>
                <button
                  type="button"
                  onClick={() => setShowConfirmModal(true)}
                  className="px-5 py-2 text-xs font-bold rounded bg-red-600 hover:bg-red-700 text-white transition flex items-center space-x-1.5 shadow"
                >
                  <XCircle className="w-4 h-4" />
                  <span>Confirm Cancellation & Refund</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* JOptionPane.showConfirmDialog Modal Emulation */}
      {showConfirmModal && searchedBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className={`w-full max-w-md rounded-lg overflow-hidden shadow-2xl border ${
            isSwingTheme ? 'bg-[#ece9d8] border-[#7f9db9]' : 'bg-slate-900 border-slate-700 text-slate-100'
          }`}>
            <div className={`px-4 py-2 border-b flex items-center space-x-2 ${
              isSwingTheme ? 'bg-[#0a246a] text-white' : 'bg-slate-800 text-slate-200'
            }`}>
              <AlertTriangle className="w-4 h-4 text-amber-300" />
              <span className="font-bold text-xs">JOptionPane.showConfirmDialog</span>
            </div>

            <div className="p-5 text-xs space-y-3">
              <div className="flex items-start space-x-3">
                <div className="p-2 rounded-full bg-red-100 text-red-600 dark:bg-red-950/60 dark:text-red-400 shrink-0">
                  <AlertTriangle className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900 dark:text-slate-100 mb-1">
                    Confirm Ticket Cancellation?
                  </h4>
                  <p className="text-slate-600 dark:text-slate-300">
                    Are you sure you want to cancel the reservation for PNR <strong>{searchedBooking.pnr}</strong>?
                  </p>
                  <p className="mt-2 text-slate-500 font-mono text-[11px]">
                    Train: {searchedBooking.trainNumber} • Date: {searchedBooking.journeyDate}
                    <br />
                    Net Refund: <strong>₹ {estimatedRefund.toFixed(2)}</strong> (Charge: ₹ {estimatedCharge.toFixed(2)})
                  </p>
                </div>
              </div>
            </div>

            <div className={`px-4 py-3 border-t flex justify-end space-x-2 ${
              isSwingTheme ? 'bg-[#e2e0d3] border-[#d4d0c8]' : 'bg-slate-800/60 border-slate-800'
            }`}>
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className={`px-4 py-1.5 rounded text-xs font-semibold border ${
                  isSwingTheme ? 'bg-white text-slate-700 border-slate-400' : 'bg-slate-800 text-slate-300 border-slate-700'
                }`}
              >
                No / Keep Booking
              </button>
              <button
                type="button"
                onClick={handleConfirmCancellation}
                disabled={loading}
                className="px-4 py-1.5 rounded text-xs font-bold bg-red-600 hover:bg-red-700 text-white"
              >
                {loading ? 'Processing...' : 'Yes / Cancel Ticket'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
