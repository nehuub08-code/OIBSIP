import React, { useState } from 'react';
import { 
  Minus, Square, X, Train, Database, Code, BookOpen, 
  HelpCircle, Shield, RefreshCw, Sun, Moon, Sparkles, User
} from 'lucide-react';
import { User as UserType } from '../types';

interface SwingWindowFrameProps {
  title: string;
  activeTab: string;
  onTabChange: (tab: string) => void;
  currentUser: UserType | null;
  onLogout: () => void;
  isSwingTheme: boolean;
  onToggleTheme: () => void;
  onOpenAbout: () => void;
  onOpenCode: () => void;
  onResetDB: () => void;
  children: React.ReactNode;
}

export const SwingWindowFrame: React.FC<SwingWindowFrameProps> = ({
  title,
  activeTab,
  onTabChange,
  currentUser,
  onLogout,
  isSwingTheme,
  onToggleTheme,
  onOpenAbout,
  onOpenCode,
  onResetDB,
  children,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  const handleMenuClick = (menu: string) => {
    setActiveMenu(activeMenu === menu ? null : menu);
  };

  const closeMenu = () => setActiveMenu(null);

  return (
    <div className={`min-h-screen transition-colors duration-200 ${
      isSwingTheme ? 'bg-[#3b4b5e] p-2 md:p-6 text-slate-800' : 'bg-slate-900 p-2 md:p-6 text-slate-100'
    }`}>
      {/* Outer Desktop Window Container */}
      <div className={`max-w-7xl mx-auto rounded-lg overflow-hidden shadow-2xl border transition-all ${
        isSwingTheme 
          ? 'bg-[#ece9d8] border-[#7f9db9] shadow-[0_15px_35px_rgba(0,0,0,0.4)]' 
          : 'bg-slate-950/90 backdrop-blur-xl border-slate-800 shadow-2xl'
      }`}>
        
        {/* Authentic Window Title Bar */}
        <div className={`flex items-center justify-between px-3 py-2 select-none border-b ${
          isSwingTheme 
            ? 'bg-gradient-to-r from-[#0a246a] via-[#3a6ea5] to-[#a6caf0] text-white border-[#0a246a]' 
            : 'bg-slate-900 text-slate-200 border-slate-800'
        }`}>
          <div className="flex items-center space-x-2.5">
            <div className={`p-1 rounded ${isSwingTheme ? 'bg-amber-400 text-slate-900' : 'bg-emerald-600 text-white'}`}>
              <Train className="w-4 h-4" />
            </div>
            <div className="flex items-center space-x-2">
              <span className="font-semibold text-xs md:text-sm tracking-wide">
                {title}
              </span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-medium ${
                isSwingTheme ? 'bg-blue-900/60 text-blue-100 border border-blue-400/30' : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
              }`}>
                Java Swing + SQLite JDBC
              </span>
            </div>
          </div>

          {/* Window Control Buttons */}
          <div className="flex items-center space-x-1">
            <button
              onClick={onToggleTheme}
              title={`Switch to ${isSwingTheme ? 'Modern UI' : 'Java Swing Desktop Theme'}`}
              className={`px-2 py-0.5 text-xs rounded flex items-center space-x-1 transition ${
                isSwingTheme 
                  ? 'bg-white/20 hover:bg-white/30 text-white' 
                  : 'bg-slate-800 hover:bg-slate-700 text-amber-400'
              }`}
            >
              {isSwingTheme ? <Sparkles className="w-3 h-3 text-amber-300" /> : <Sun className="w-3 h-3" />}
              <span className="hidden sm:inline text-[11px] font-sans">
                {isSwingTheme ? 'Theme: Swing Classic' : 'Theme: Modern Rail'}
              </span>
            </button>
            <div className="w-[1px] h-4 bg-white/30 mx-1 hidden sm:block" />
            <button className="w-5 h-5 flex items-center justify-center rounded hover:bg-white/20 text-white/80 transition">
              <Minus className="w-3 h-3" />
            </button>
            <button className="w-5 h-5 flex items-center justify-center rounded hover:bg-white/20 text-white/80 transition">
              <Square className="w-2.5 h-2.5" />
            </button>
            <button 
              onClick={onLogout}
              title="Logout / Exit"
              className="w-5 h-5 flex items-center justify-center rounded hover:bg-red-600 text-white transition"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Java Swing Style Menu Bar */}
        <div className={`px-2 py-1 text-xs border-b flex flex-wrap items-center justify-between select-none ${
          isSwingTheme 
            ? 'bg-[#f0f0f0] border-[#d4d0c8] text-slate-800' 
            : 'bg-slate-900/90 border-slate-800 text-slate-300'
        }`}>
          <div className="flex items-center space-x-1 relative">
            {/* File Menu */}
            <div className="relative">
              <button
                onClick={() => handleMenuClick('file')}
                className={`px-2.5 py-1 rounded hover:bg-black/10 transition ${activeMenu === 'file' ? 'bg-black/15 font-semibold' : ''}`}
              >
                File
              </button>
              {activeMenu === 'file' && (
                <div 
                  className="absolute left-0 mt-1 w-48 bg-white border border-slate-300 shadow-xl rounded-md py-1 z-50 text-slate-800"
                  onMouseLeave={closeMenu}
                >
                  <button 
                    onClick={() => { onTabChange('book'); closeMenu(); }} 
                    className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white text-xs flex items-center space-x-2"
                  >
                    <span>New Reservation (Ctrl+N)</span>
                  </button>
                  <button 
                    onClick={() => { onTabChange('pnr'); closeMenu(); }} 
                    className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white text-xs flex items-center space-x-2"
                  >
                    <span>PNR Status Enquiry</span>
                  </button>
                  <button 
                    onClick={() => { onTabChange('cancel'); closeMenu(); }} 
                    className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white text-xs flex items-center space-x-2"
                  >
                    <span>Cancel Ticket</span>
                  </button>
                  <div className="border-t my-1 border-slate-200" />
                  <button 
                    onClick={() => { onLogout(); closeMenu(); }} 
                    className="w-full text-left px-3 py-1.5 hover:bg-red-600 hover:text-white text-xs flex items-center space-x-2"
                  >
                    <span>Exit / Logout</span>
                  </button>
                </div>
              )}
            </div>

            {/* Navigation Menus */}
            <button
              onClick={() => onTabChange('dashboard')}
              className={`px-2.5 py-1 rounded transition ${activeTab === 'dashboard' ? 'bg-blue-700 text-white font-medium' : 'hover:bg-black/10'}`}
            >
              Dashboard
            </button>
            <button
              onClick={() => onTabChange('book')}
              className={`px-2.5 py-1 rounded transition ${activeTab === 'book' ? 'bg-blue-700 text-white font-medium' : 'hover:bg-black/10'}`}
            >
              Book Ticket
            </button>
            <button
              onClick={() => onTabChange('cancel')}
              className={`px-2.5 py-1 rounded transition ${activeTab === 'cancel' ? 'bg-blue-700 text-white font-medium' : 'hover:bg-black/10'}`}
            >
              Cancellation
            </button>
            <button
              onClick={() => onTabChange('pnr')}
              className={`px-2.5 py-1 rounded transition ${activeTab === 'pnr' ? 'bg-blue-700 text-white font-medium' : 'hover:bg-black/10'}`}
            >
              PNR Status
            </button>
            <button
              onClick={() => onTabChange('history')}
              className={`px-2.5 py-1 rounded transition ${activeTab === 'history' ? 'bg-blue-700 text-white font-medium' : 'hover:bg-black/10'}`}
            >
              My Bookings
            </button>
            <button
              onClick={() => onTabChange('database')}
              className={`px-2.5 py-1 rounded transition flex items-center space-x-1 ${activeTab === 'database' ? 'bg-emerald-700 text-white font-medium' : 'hover:bg-black/10'}`}
            >
              <Database className="w-3 h-3 text-emerald-400" />
              <span>SQLite DB</span>
            </button>
            <button
              onClick={onOpenCode}
              className={`px-2.5 py-1 rounded transition flex items-center space-x-1 ${activeTab === 'code' ? 'bg-amber-600 text-white font-medium' : 'hover:bg-black/10 text-amber-500 font-medium'}`}
            >
              <Code className="w-3 h-3" />
              <span>Java Maven Code</span>
            </button>
          </div>

          {/* Right Status Indicator */}
          <div className="flex items-center space-x-3 py-1">
            {currentUser && (
              <div className="flex items-center space-x-1.5 text-[11px]">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Logged in: <strong className="font-semibold text-emerald-600 dark:text-emerald-400">{currentUser.fullName}</strong></span>
              </div>
            )}
            <button
              onClick={onOpenAbout}
              title="About Task 1 & Developer"
              className="flex items-center space-x-1 px-2 py-0.5 rounded bg-blue-100 hover:bg-blue-200 text-blue-900 dark:bg-slate-800 dark:text-blue-300 text-[11px] font-medium"
            >
              <HelpCircle className="w-3 h-3" />
              <span>Task 1 Info</span>
            </button>
          </div>
        </div>

        {/* Main Application Body */}
        <div className={`p-4 md:p-6 min-h-[580px] ${
          isSwingTheme 
            ? 'bg-[#f4f3ed] text-slate-800' 
            : 'bg-slate-950 text-slate-100'
        }`}>
          {children}
        </div>

        {/* Java Swing Status Bar */}
        <div className={`px-4 py-2 text-[11px] border-t flex flex-wrap items-center justify-between font-mono ${
          isSwingTheme 
            ? 'bg-[#ece9d8] border-[#d4d0c8] text-slate-600' 
            : 'bg-slate-900 border-slate-800 text-slate-400'
        }`}>
          <div className="flex items-center space-x-4">
            <span className="flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>JDBC: Connected [railease.db]</span>
            </span>
            <span className="hidden sm:inline">Engine: SQLite 3.x</span>
            <span className="hidden md:inline">Track: Oasis Infobyte Java Dev</span>
          </div>
          <div>
            Developer: <strong>Neha Vinod Borkar</strong> (Oasis Infobyte Task 1)
          </div>
        </div>
      </div>
    </div>
  );
};
