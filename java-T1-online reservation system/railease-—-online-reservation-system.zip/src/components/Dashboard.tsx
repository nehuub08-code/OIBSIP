import React, { useState } from 'react';
import { db } from '../services/db';
import { Booking, Train, User } from '../types';
import { 
  Train as TrainIcon, Ticket, XCircle, Search, Database, 
  Calendar, Clock, MapPin, ArrowRight, CheckCircle2, ShieldCheck, 
  Code, Sparkles, Plus, AlertCircle 
} from 'lucide-react';

interface DashboardProps {
  currentUser: User;
  onNavigate: (tab: string) => void;
  onViewTicket: (pnr: string) => void;
  onCancelTicket: (pnr: string) => void;
  isSwingTheme: boolean;
}

export const Dashboard: React.FC<DashboardProps> = ({
  currentUser,
  onNavigate,
  onViewTicket,
  onCancelTicket,
  isSwingTheme,
}) => {
  const allBookings = db.getAllBookings();
  const userBookings = db.getUserBookings(currentUser.username);
  const activeBookings = userBookings.filter((b) => b.status === 'CONFIRMED');
  const cancelledBookings = userBookings.filter((b) => b.status === 'CANCELLED');
  const trains = db.getAllTrains();

  // Search filter for train table
  const [searchTerm, setSearchTerm] = useState('');
  const filteredTrains = trains.filter(
    (t) =>
      t.trainName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.trainNumber.includes(searchTerm) ||
      t.source.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.destination.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Top Banner with Developer Information */}
      <div className={`p-5 rounded-lg border flex flex-col md:flex-row md:items-center justify-between gap-4 ${
        isSwingTheme 
          ? 'bg-gradient-to-r from-[#0a246a] via-[#1e3a8a] to-[#2563eb] text-white border-[#0a246a]' 
          : 'bg-slate-900 border-slate-800 text-slate-100'
      }`}>
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase bg-amber-400 text-slate-950">
              Oasis Infobyte Java Track
            </span>
            <span className="text-xs text-blue-200">Task 1: Online Reservation System</span>
          </div>
          <h1 className="text-xl md:text-2xl font-black tracking-tight mt-1">
            RailEase Reservation Dashboard
          </h1>
          <p className="text-xs text-blue-100/80 mt-0.5">
            Welcome, <strong>{currentUser.fullName}</strong> ({currentUser.username}) • SQLite JDBC Connected
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={() => onNavigate('book')}
            className="px-4 py-2 rounded text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 transition flex items-center space-x-1.5 shadow"
          >
            <Plus className="w-4 h-4" />
            <span>Book New Ticket</span>
          </button>
          <button
            onClick={() => onNavigate('code')}
            className="px-3.5 py-2 rounded text-xs font-semibold bg-white/20 hover:bg-white/30 text-white transition flex items-center space-x-1.5"
          >
            <Code className="w-4 h-4" />
            <span>View Java Source Code</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        {/* Metric 1 */}
        <div className={`p-4 rounded-lg border ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/70 border-slate-800'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase">My Active Tickets</span>
            <Ticket className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
            {activeBookings.length}
          </div>
          <span className="text-[10px] text-slate-400 font-mono">Confirmed Bookings</span>
        </div>

        {/* Metric 2 */}
        <div className={`p-4 rounded-lg border ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/70 border-slate-800'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase">Cancelled Tickets</span>
            <XCircle className="w-4 h-4 text-red-500" />
          </div>
          <div className="text-2xl font-black text-red-600 dark:text-red-400 mt-1">
            {cancelledBookings.length}
          </div>
          <span className="text-[10px] text-slate-400 font-mono">Refunded to Account</span>
        </div>

        {/* Metric 3 */}
        <div className={`p-4 rounded-lg border ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/70 border-slate-800'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase">Total Scheduled Trains</span>
            <TrainIcon className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-black text-blue-600 dark:text-blue-400 mt-1">
            {trains.length}
          </div>
          <span className="text-[10px] text-slate-400 font-mono">Rajdhani, Shatabdi, Vande Bharat</span>
        </div>

        {/* Metric 4 */}
        <div className={`p-4 rounded-lg border ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/70 border-slate-800'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase">Database Architecture</span>
            <Database className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-black text-amber-500 mt-1">
            5 Tables
          </div>
          <span className="text-[10px] text-slate-400 font-mono">SQLite (railease.db)</span>
        </div>
      </div>

      {/* Quick Access Shortcuts */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button
          onClick={() => onNavigate('book')}
          className={`p-3.5 rounded-lg border text-left transition hover:scale-[1.01] ${
            isSwingTheme 
              ? 'bg-white hover:bg-blue-50 border-slate-300' 
              : 'bg-slate-900/50 hover:bg-slate-800/80 border-slate-800'
          }`}
        >
          <div className="p-2 rounded bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-400 w-fit mb-2">
            <Plus className="w-4 h-4" />
          </div>
          <h4 className="font-bold text-xs">Book Ticket</h4>
          <p className="text-[11px] text-slate-500">Insert new reservation with PNR</p>
        </button>

        <button
          onClick={() => onNavigate('cancel')}
          className={`p-3.5 rounded-lg border text-left transition hover:scale-[1.01] ${
            isSwingTheme 
              ? 'bg-white hover:bg-red-50 border-slate-300' 
              : 'bg-slate-900/50 hover:bg-slate-800/80 border-slate-800'
          }`}
        >
          <div className="p-2 rounded bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-400 w-fit mb-2">
            <XCircle className="w-4 h-4" />
          </div>
          <h4 className="font-bold text-xs">Cancellation Form</h4>
          <p className="text-[11px] text-slate-500">Cancel ticket & claim refund</p>
        </button>

        <button
          onClick={() => onNavigate('pnr')}
          className={`p-3.5 rounded-lg border text-left transition hover:scale-[1.01] ${
            isSwingTheme 
              ? 'bg-white hover:bg-amber-50 border-slate-300' 
              : 'bg-slate-900/50 hover:bg-slate-800/80 border-slate-800'
          }`}
        >
          <div className="p-2 rounded bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400 w-fit mb-2">
            <Search className="w-4 h-4" />
          </div>
          <h4 className="font-bold text-xs">PNR Status</h4>
          <p className="text-[11px] text-slate-500">Track 10-digit PNR allocation</p>
        </button>

        <button
          onClick={() => onNavigate('database')}
          className={`p-3.5 rounded-lg border text-left transition hover:scale-[1.01] ${
            isSwingTheme 
              ? 'bg-white hover:bg-emerald-50 border-slate-300' 
              : 'bg-slate-900/50 hover:bg-slate-800/80 border-slate-800'
          }`}
        >
          <div className="p-2 rounded bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 w-fit mb-2">
            <Database className="w-4 h-4" />
          </div>
          <h4 className="font-bold text-xs">Live SQLite DB</h4>
          <p className="text-[11px] text-slate-500">Inspect tables & run raw SQL</p>
        </button>
      </div>

      {/* Two Column Layout: My Bookings & Available Trains */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left Column: Recent Bookings for Logged-In User */}
        <div className={`p-4 rounded-lg border flex flex-col justify-between ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/60 border-slate-800'
        }`}>
          <div>
            <div className="flex items-center justify-between border-b pb-2 border-slate-200 dark:border-slate-800 mb-3">
              <div className="flex items-center space-x-2">
                <Ticket className="w-4 h-4 text-blue-500" />
                <h3 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  My Recent Bookings
                </h3>
              </div>
              <button
                onClick={() => onNavigate('history')}
                className="text-[11px] text-blue-600 dark:text-blue-400 hover:underline flex items-center space-x-1"
              >
                <span>View All ({userBookings.length})</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {userBookings.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">
                <p>No bookings found for your account yet.</p>
                <button
                  onClick={() => onNavigate('book')}
                  className="mt-2 px-3 py-1 bg-blue-600 text-white rounded text-xs font-semibold"
                >
                  Book Your First Ticket Now
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {userBookings.slice(0, 3).map((b) => (
                  <div
                    key={b.pnr}
                    className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                          PNR: {b.pnr}
                        </span>
                        <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                          b.status === 'CONFIRMED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {b.status}
                        </span>
                      </div>
                      <div className="font-medium text-slate-800 dark:text-slate-200 mt-1">
                        {b.trainNumber} - {b.trainName}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Date: {b.journeyDate} • Class: {b.travelClass} • ₹{b.totalFare}
                      </div>
                    </div>

                    <div className="flex flex-col gap-1 shrink-0">
                      <button
                        onClick={() => onViewTicket(b.pnr)}
                        className="px-2.5 py-1 text-[11px] rounded bg-blue-600 hover:bg-blue-700 text-white font-medium transition"
                      >
                        View Ticket
                      </button>
                      {b.status === 'CONFIRMED' && (
                        <button
                          onClick={() => onCancelTicket(b.pnr)}
                          className="px-2.5 py-1 text-[11px] rounded bg-red-100 hover:bg-red-200 text-red-700 font-medium transition dark:bg-red-950 dark:text-red-300"
                        >
                          Cancel
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-3 mt-3 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-400 flex justify-between items-center">
            <span>PreparedStatement Transactions</span>
            <span className="font-mono">SQLite railease.db</span>
          </div>
        </div>

        {/* Right Column: Scheduled Trains Explorer */}
        <div className={`p-4 rounded-lg border flex flex-col justify-between ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/60 border-slate-800'
        }`}>
          <div>
            <div className="flex items-center justify-between border-b pb-2 border-slate-200 dark:border-slate-800 mb-3">
              <div className="flex items-center space-x-2">
                <TrainIcon className="w-4 h-4 text-emerald-500" />
                <h3 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Available Scheduled Trains
                </h3>
              </div>
              <div className="relative w-44">
                <input
                  type="text"
                  placeholder="Filter train..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`w-full px-2 py-0.5 text-xs rounded border ${
                    isSwingTheme ? 'bg-white border-slate-300' : 'bg-slate-950 border-slate-700 text-slate-100'
                  }`}
                />
              </div>
            </div>

            <div className="space-y-2 max-h-[290px] overflow-y-auto pr-1">
              {filteredTrains.map((train) => (
                <div
                  key={train.trainNumber}
                  className="p-2.5 rounded border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-xs"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-mono font-bold text-blue-700 dark:text-blue-300">
                        {train.trainNumber}
                      </span>{' '}
                      — <span className="font-semibold text-slate-800 dark:text-slate-200">{train.trainName}</span>
                    </div>
                    <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                      ₹{train.baseFareSL} <span className="font-normal text-slate-400">(Base SL)</span>
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-[11px] text-slate-500 mt-1">
                    <span>{train.source.split(' ')[0]} ➔ {train.destination.split(' ')[0]}</span>
                    <span>{train.departureTime} – {train.arrivalTime}</span>
                  </div>

                  {/* Seat badges */}
                  <div className="flex flex-wrap gap-1 mt-2 text-[10px]">
                    <span className="px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 font-mono">
                      1A: {train.availableSeats['1A']}
                    </span>
                    <span className="px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 font-mono">
                      2A: {train.availableSeats['2A']}
                    </span>
                    <span className="px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 font-mono">
                      3A: {train.availableSeats['3A']}
                    </span>
                    <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-mono">
                      SL: {train.availableSeats['SL']}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center text-[11px]">
            <span className="text-slate-400">Real-time seat allocation engine</span>
            <button
              onClick={() => onNavigate('book')}
              className="text-blue-600 dark:text-blue-400 font-semibold hover:underline"
            >
              Book Selected Train ➔
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
