import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { db } from '../services/db';
import { Booking, Passenger, Train, TravelClass, User } from '../types';
import { 
  Train as TrainIcon, Calendar, Users, Plus, Trash2, 
  CreditCard, ShieldCheck, CheckCircle2, AlertCircle, ArrowRight 
} from 'lucide-react';

interface BookingFormProps {
  currentUser: User;
  onBookingSuccess: (booking: Booking) => void;
  isSwingTheme: boolean;
}

export const BookingForm: React.FC<BookingFormProps> = ({
  currentUser,
  onBookingSuccess,
  isSwingTheme,
}) => {
  const trains = db.getAllTrains();
  const [selectedTrainNumber, setSelectedTrainNumber] = useState<string>(trains[0]?.trainNumber || '12951');
  const [travelClass, setTravelClass] = useState<TravelClass>('3A');
  const [quota, setQuota] = useState<'General' | 'Tatkal' | 'Ladies' | 'Senior Citizen'>('General');
  
  // Date default to 3 days in future
  const getInitialDate = () => {
    const d = new Date();
    d.setDate(d.getDate() + 3);
    return d.toISOString().split('T')[0];
  };
  const [journeyDate, setJourneyDate] = useState<string>(getInitialDate());

  // Passenger list
  const [passengers, setPassengers] = useState<Omit<Passenger, 'allocatedBerth' | 'status'>[]>([
    {
      name: currentUser.fullName || 'Neha Vinod Borkar',
      age: 23,
      gender: 'Female',
      berthPreference: 'Lower',
    },
  ]);

  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const selectedTrain = trains.find((t) => t.trainNumber === selectedTrainNumber) || trains[0];
  const totalFare = db.calculateFare(selectedTrainNumber, travelClass, passengers.length);

  const addPassenger = () => {
    if (passengers.length >= 6) {
      setErrorMessage('Maximum 6 passengers allowed per booking request.');
      return;
    }
    setPassengers([
      ...passengers,
      {
        name: '',
        age: 28,
        gender: 'Male',
        berthPreference: 'Lower',
      },
    ]);
  };

  const removePassenger = (index: number) => {
    if (passengers.length <= 1) {
      setErrorMessage('At least one passenger must be included.');
      return;
    }
    setPassengers(passengers.filter((_, i) => i !== index));
  };

  const updatePassenger = (index: number, field: string, value: any) => {
    const copy = [...passengers];
    copy[index] = { ...copy[index], [field]: value };
    setPassengers(copy);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // 1. Validate Journey Date (Java Date API requirements: must not be in past)
    if (!journeyDate) {
      setErrorMessage('Please select a journey date.');
      return;
    }
    const today = new Date().toISOString().split('T')[0];
    if (journeyDate < today) {
      setErrorMessage('Validation Error: Journey date cannot be in the past. Please select a valid upcoming travel date.');
      return;
    }

    // 2. Validate Passengers
    for (let i = 0; i < passengers.length; i++) {
      const p = passengers[i];
      if (!p.name.trim()) {
        setErrorMessage(`Passenger #${i + 1}: Name cannot be empty.`);
        return;
      }
      if (!p.age || p.age < 1 || p.age > 120) {
        setErrorMessage(`Passenger #${i + 1}: Please enter a valid age between 1 and 120.`);
        return;
      }
    }

    setLoading(true);
    try {
      const result = db.createBooking({
        username: currentUser.username,
        trainNumber: selectedTrain.trainNumber,
        journeyDate,
        travelClass,
        quota,
        passengers,
      });

      if (result.success && result.booking) {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
        onBookingSuccess(result.booking);
      } else {
        setErrorMessage(result.error || 'Failed to create booking in SQLite database.');
      }
    } catch {
      setErrorMessage('Database transaction error while creating reservation.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      {/* Form Title Banner */}
      <div className={`p-4 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
        isSwingTheme 
          ? 'bg-[#e2e8f0] border-[#94a3b8]' 
          : 'bg-slate-900 border-slate-800'
      }`}>
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded bg-blue-700 text-white">
            <TrainIcon className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-base text-blue-950 dark:text-blue-300">
              New Ticket Reservation Form
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
              Insert Query: INSERT INTO bookings, passengers VALUES (...)
            </p>
          </div>
        </div>
        <div className="text-xs font-semibold px-2.5 py-1 bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 rounded border border-emerald-300">
          Logged in as: {currentUser.username}
        </div>
      </div>

      {errorMessage && (
        <div className="p-3 rounded text-xs bg-red-100 border border-red-300 text-red-800 flex items-start space-x-2 dark:bg-red-950/60 dark:border-red-800 dark:text-red-300">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Step 1: Train & Journey Config */}
        <div className={`p-5 rounded-lg border space-y-4 ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/60 border-slate-800'
        }`}>
          <div className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center space-x-2 border-b pb-2 border-slate-200 dark:border-slate-800">
            <span>1. Train & Journey Details</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Train Dropdown */}
            <div>
              <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Select Train (Train No & Name) <span className="text-red-500">*</span>
              </label>
              <select
                value={selectedTrainNumber}
                onChange={(e) => setSelectedTrainNumber(e.target.value)}
                className={`w-full px-3 py-2 text-xs rounded border transition outline-none font-medium ${
                  isSwingTheme 
                    ? 'bg-white border-[#7f9db9] text-slate-800 focus:border-blue-600' 
                    : 'bg-slate-950 border-slate-700 text-slate-100'
                }`}
              >
                {trains.map((train) => (
                  <option key={train.trainNumber} value={train.trainNumber}>
                    {train.trainNumber} — {train.trainName}
                  </option>
                ))}
              </select>
            </div>

            {/* Travel Class */}
            <div>
              <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Travel Class <span className="text-red-500">*</span>
              </label>
              <div className="grid grid-cols-5 gap-1.5">
                {(['1A', '2A', '3A', 'SL', '2S'] as TravelClass[]).map((cls) => (
                  <button
                    key={cls}
                    type="button"
                    onClick={() => setTravelClass(cls)}
                    className={`py-1.5 px-2 rounded text-xs font-bold transition border ${
                      travelClass === cls
                        ? 'bg-blue-600 text-white border-blue-700 shadow-sm'
                        : isSwingTheme
                        ? 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                        : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                    }`}
                  >
                    {cls}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Route & Times display */}
          {selectedTrain && (
            <div className="p-3 rounded bg-blue-50/70 dark:bg-slate-800/50 border border-blue-200 dark:border-slate-700 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 font-bold block">FROM (ORIGIN)</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{selectedTrain.source}</span>
                <span className="text-[10px] text-slate-500 block">Dept: {selectedTrain.departureTime}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold block">TO (DESTINATION)</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{selectedTrain.destination}</span>
                <span className="text-[10px] text-slate-500 block">Arr: {selectedTrain.arrivalTime}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold block">DISTANCE & BASE FARE</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {selectedTrain.distanceKm} km • ₹{selectedTrain.baseFareSL} (SL)
                </span>
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 block font-medium">
                  Seats in {travelClass}: {selectedTrain.availableSeats[travelClass]} Avail
                </span>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Journey Date */}
            <div>
              <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Date of Journey <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={journeyDate}
                  min={new Date().toISOString().split('T')[0]}
                  onChange={(e) => setJourneyDate(e.target.value)}
                  required
                  className={`w-full px-3 py-2 text-xs rounded border transition outline-none font-mono ${
                    isSwingTheme 
                      ? 'bg-white border-[#7f9db9] text-slate-800 focus:border-blue-600' 
                      : 'bg-slate-950 border-slate-700 text-slate-100'
                  }`}
                />
              </div>
              <span className="text-[10px] text-slate-500 mt-1 block">
                Validated via Java Date APIs (past dates automatically prohibited).
              </span>
            </div>

            {/* Quota */}
            <div>
              <label className="block text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
                Reservation Quota
              </label>
              <select
                value={quota}
                onChange={(e) => setQuota(e.target.value as any)}
                className={`w-full px-3 py-2 text-xs rounded border transition outline-none ${
                  isSwingTheme ? 'bg-white border-[#7f9db9] text-slate-800' : 'bg-slate-950 border-slate-700 text-slate-100'
                }`}
              >
                <option value="General">General Quota (GN)</option>
                <option value="Tatkal">Tatkal Quota (CK)</option>
                <option value="Ladies">Ladies Quota (LD)</option>
                <option value="Senior Citizen">Senior Citizen (SS)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Step 2: Passenger Details */}
        <div className={`p-5 rounded-lg border space-y-4 ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/60 border-slate-800'
        }`}>
          <div className="flex items-center justify-between border-b pb-2 border-slate-200 dark:border-slate-800">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center space-x-2">
              <Users className="w-4 h-4 text-blue-500" />
              <span>2. Passenger Details ({passengers.length}/6)</span>
            </div>
            <button
              type="button"
              onClick={addPassenger}
              className="px-2.5 py-1 text-xs rounded font-medium bg-blue-100 text-blue-800 hover:bg-blue-200 dark:bg-blue-950 dark:text-blue-300 flex items-center space-x-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Passenger</span>
            </button>
          </div>

          <div className="space-y-3">
            {passengers.map((passenger, idx) => (
              <div 
                key={idx} 
                className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40 grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end"
              >
                <div className="sm:col-span-4">
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Passenger #{idx + 1} Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={passenger.name}
                    onChange={(e) => updatePassenger(idx, 'name', e.target.value)}
                    placeholder="Full Name as on ID"
                    required
                    className={`w-full px-2.5 py-1.5 text-xs rounded border ${
                      isSwingTheme ? 'bg-white border-slate-300 text-slate-800' : 'bg-slate-950 border-slate-700 text-slate-100'
                    }`}
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Age <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="120"
                    value={passenger.age}
                    onChange={(e) => updatePassenger(idx, 'age', parseInt(e.target.value) || 0)}
                    required
                    className={`w-full px-2.5 py-1.5 text-xs rounded border ${
                      isSwingTheme ? 'bg-white border-slate-300 text-slate-800' : 'bg-slate-950 border-slate-700 text-slate-100'
                    }`}
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Gender
                  </label>
                  <select
                    value={passenger.gender}
                    onChange={(e) => updatePassenger(idx, 'gender', e.target.value)}
                    className={`w-full px-2 py-1.5 text-xs rounded border ${
                      isSwingTheme ? 'bg-white border-slate-300 text-slate-800' : 'bg-slate-950 border-slate-700 text-slate-100'
                    }`}
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Berth Preference
                  </label>
                  <select
                    value={passenger.berthPreference}
                    onChange={(e) => updatePassenger(idx, 'berthPreference', e.target.value)}
                    className={`w-full px-2 py-1.5 text-xs rounded border ${
                      isSwingTheme ? 'bg-white border-slate-300 text-slate-800' : 'bg-slate-950 border-slate-700 text-slate-100'
                    }`}
                  >
                    <option value="Lower">Lower Berth</option>
                    <option value="Middle">Middle Berth</option>
                    <option value="Upper">Upper Berth</option>
                    <option value="Side Lower">Side Lower</option>
                    <option value="Side Upper">Side Upper</option>
                    <option value="Window Seat">Window Seat</option>
                    <option value="No Preference">No Preference</option>
                  </select>
                </div>

                <div className="sm:col-span-1 flex justify-center pb-0.5">
                  {passengers.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removePassenger(idx)}
                      title="Remove Passenger"
                      className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 rounded transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Step 3: Fare Calculation & Submit Action */}
        <div className={`p-5 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
          isSwingTheme ? 'bg-[#ece9d8] border-[#7f9db9]' : 'bg-slate-900 border-slate-800'
        }`}>
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400">
              Total Calculated Fare ({passengers.length} Passenger{passengers.length > 1 ? 's' : ''} in {travelClass}):
            </div>
            <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 flex items-center space-x-1 mt-0.5">
              <span>₹ {totalFare.toFixed(2)}</span>
              <span className="text-[11px] font-normal text-slate-500">incl. GST</span>
            </div>
            <div className="text-[10px] text-slate-400 font-mono mt-0.5">
              Automatic 10-Digit PNR generated upon database insert.
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button
              type="submit"
              disabled={loading}
              className={`px-6 py-3 rounded text-xs font-bold transition flex items-center space-x-2 ${
                isSwingTheme 
                  ? 'bg-[#15803d] hover:bg-[#166534] text-white shadow active:translate-y-0.5' 
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/30'
              }`}
            >
              {loading ? (
                <span>Executing INSERT Statement...</span>
              ) : (
                <>
                  <CreditCard className="w-4 h-4" />
                  <span>Insert Booking & Generate PNR</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
