import React, { useState } from 'react';
import { db } from '../services/db';
import { Booking, User } from '../types';
import { 
  Ticket, Search, Filter, Printer, XCircle, 
  Calendar, CheckCircle2, AlertTriangle, ArrowRight 
} from 'lucide-react';

interface BookingHistoryProps {
  currentUser: User;
  onViewTicket: (pnr: string) => void;
  onCancelTicket: (pnr: string) => void;
  onNewBooking: () => void;
  isSwingTheme: boolean;
}

export const BookingHistory: React.FC<BookingHistoryProps> = ({
  currentUser,
  onViewTicket,
  onCancelTicket,
  onNewBooking,
  isSwingTheme,
}) => {
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'CONFIRMED' | 'CANCELLED'>('ALL');
  const [searchTerm, setSearchTerm] = useState('');

  const userBookings = db.getUserBookings(currentUser.username);

  const filteredBookings = userBookings.filter((b) => {
    const matchesStatus = filterStatus === 'ALL' || b.status === filterStatus;
    const matchesSearch =
      b.pnr.includes(searchTerm) ||
      b.trainName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.trainNumber.includes(searchTerm) ||
      b.passengers.some((p) => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-5">
      {/* Header Banner */}
      <div className={`p-4 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
        isSwingTheme ? 'bg-[#e2e8f0] border-[#94a3b8]' : 'bg-slate-900 border-slate-800'
      }`}>
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded bg-blue-700 text-white">
            <Ticket className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-base text-slate-900 dark:text-slate-100">
              My Bookings & Reservation History
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
              SELECT * FROM bookings WHERE username = '{currentUser.username}'
            </p>
          </div>
        </div>

        <button
          onClick={onNewBooking}
          className="px-4 py-2 rounded text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white transition flex items-center space-x-1.5 shadow"
        >
          <span>+ New Reservation</span>
        </button>
      </div>

      {/* Filter and Search Controls */}
      <div className={`p-4 rounded-lg border flex flex-col sm:flex-row items-center justify-between gap-3 ${
        isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/60 border-slate-800'
      }`}>
        <div className="flex items-center space-x-1.5 w-full sm:w-auto">
          {(['ALL', 'CONFIRMED', 'CANCELLED'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1.5 rounded text-xs font-semibold transition border ${
                filterStatus === st
                  ? 'bg-blue-600 text-white border-blue-700'
                  : isSwingTheme
                  ? 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
            >
              {st === 'ALL' ? 'All Bookings' : st}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search PNR, train, passenger..."
            className={`w-full pl-8 pr-3 py-1.5 text-xs rounded border transition outline-none ${
              isSwingTheme ? 'bg-white border-[#7f9db9] text-slate-800' : 'bg-slate-950 border-slate-700 text-slate-100'
            }`}
          />
        </div>
      </div>

      {/* Bookings Table / Cards */}
      {filteredBookings.length === 0 ? (
        <div className={`p-10 rounded-lg border text-center space-y-3 ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/50 border-slate-800'
        }`}>
          <Ticket className="w-10 h-10 mx-auto text-slate-400" />
          <h3 className="font-bold text-sm text-slate-700 dark:text-slate-300">
            No reservations found
          </h3>
          <p className="text-xs text-slate-500">
            {searchTerm ? 'No results matched your search term.' : 'You have not booked any train tickets yet.'}
          </p>
          <button
            onClick={onNewBooking}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded"
          >
            Create Reservation Now
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredBookings.map((b) => (
            <div
              key={b.pnr}
              className={`p-4 rounded-lg border transition hover:shadow-md ${
                isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/60 border-slate-800'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                {/* Details */}
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-mono font-bold text-sm text-blue-600 dark:text-blue-400">
                      PNR: {b.pnr}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      b.status === 'CONFIRMED'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-red-100 text-red-800 border border-red-300'
                    }`}>
                      {b.status}
                    </span>
                    <span className="text-xs text-slate-400">• Booked on {b.bookingTimestamp.split(' ')[0]}</span>
                  </div>

                  <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">
                    {b.trainNumber} — {b.trainName}
                  </h3>

                  <div className="text-xs text-slate-500 flex flex-wrap gap-x-4 gap-y-1">
                    <span>From: <strong>{b.source}</strong></span>
                    <span>To: <strong>{b.destination}</strong></span>
                    <span>Date: <strong>{b.journeyDate}</strong></span>
                    <span>Class: <strong>{b.travelClass}</strong></span>
                    <span>Passengers: <strong>{b.passengers.length}</strong></span>
                  </div>

                  <div className="text-[11px] text-slate-400 pt-0.5">
                    Passengers: {b.passengers.map((p) => p.name).join(', ')}
                  </div>
                </div>

                {/* Right Fare and Action Buttons */}
                <div className="flex md:flex-col items-center md:items-end justify-between border-t md:border-t-0 pt-2 md:pt-0 gap-2 shrink-0">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Total Fare</span>
                    <span className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                      ₹ {b.totalFare.toFixed(2)}
                    </span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => onViewTicket(b.pnr)}
                      className="px-3 py-1.5 text-xs font-semibold rounded bg-blue-600 hover:bg-blue-700 text-white transition flex items-center space-x-1"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>View Ticket</span>
                    </button>

                    {b.status === 'CONFIRMED' && (
                      <button
                        onClick={() => onCancelTicket(b.pnr)}
                        className="px-3 py-1.5 text-xs font-semibold rounded bg-red-100 hover:bg-red-200 text-red-700 dark:bg-red-950 dark:text-red-300 transition flex items-center space-x-1"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Cancel</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
