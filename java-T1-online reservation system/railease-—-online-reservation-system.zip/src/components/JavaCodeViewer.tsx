import React, { useState } from 'react';
import { JAVA_PROJECT_FILES, downloadJavaProjectZip } from '../services/javaCodebase';
import { 
  Code, Download, Copy, Check, FileCode, Folder, 
  Terminal, ShieldCheck, Sparkles, BookOpen 
} from 'lucide-react';

interface JavaCodeViewerProps {
  isSwingTheme: boolean;
}

export const JavaCodeViewer: React.FC<JavaCodeViewerProps> = ({ isSwingTheme }) => {
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const selectedFile = JAVA_PROJECT_FILES[selectedFileIndex] || JAVA_PROJECT_FILES[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setDownloading(true);
    try {
      await downloadJavaProjectZip();
    } catch (err) {
      console.error('Failed to download project zip', err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className={`p-5 rounded-lg border flex flex-col md:flex-row md:items-center justify-between gap-4 ${
        isSwingTheme 
          ? 'bg-gradient-to-r from-[#0a246a] via-[#1e3a8a] to-[#2563eb] text-white border-[#0a246a]' 
          : 'bg-slate-900 border-slate-800 text-slate-100'
      }`}>
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase bg-amber-400 text-slate-950">
              Complete Java Project
            </span>
            <span className="text-xs text-blue-200">Maven • Java 17 • SQLite JDBC • Java Swing</span>
          </div>
          <h2 className="text-xl font-black tracking-tight mt-1">
            RailEase Java Swing Source Codebase
          </h2>
          <p className="text-xs text-blue-100/80 mt-0.5">
            Designed for Oasis Infobyte Task 1 Submission • Developer: <strong>Neha Vinod Borkar</strong>
          </p>
        </div>

        <button
          onClick={handleDownloadZip}
          disabled={downloading}
          className="px-5 py-2.5 rounded text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 transition flex items-center space-x-2 shadow-lg hover:shadow-xl active:scale-95 shrink-0"
        >
          <Download className="w-4 h-4" />
          <span>{downloading ? 'Packing Maven ZIP...' : 'Download Complete Java Project (.ZIP)'}</span>
        </button>
      </div>

      {/* Main Code Explorer: File Tree on left, Code editor on right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        {/* Left Column: File Navigation */}
        <div className={`lg:col-span-4 p-3 rounded-lg border flex flex-col ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/60 border-slate-800'
        }`}>
          <div className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 px-2 py-1 mb-2 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <span className="flex items-center space-x-1">
              <Folder className="w-3.5 h-3.5 text-amber-500" />
              <span>Project Files ({JAVA_PROJECT_FILES.length})</span>
            </span>
            <span className="text-[10px] text-slate-400 font-mono">railease/</span>
          </div>

          <div className="space-y-1 overflow-y-auto max-h-[500px] pr-1">
            {JAVA_PROJECT_FILES.map((file, idx) => {
              const isSelected = selectedFileIndex === idx;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFileIndex(idx)}
                  className={`w-full text-left px-2.5 py-2 rounded text-xs transition flex items-start space-x-2 ${
                    isSelected
                      ? 'bg-blue-600 text-white font-semibold shadow-sm'
                      : isSwingTheme
                      ? 'hover:bg-slate-100 text-slate-700'
                      : 'hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  <FileCode className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${isSelected ? 'text-white' : 'text-blue-500'}`} />
                  <div className="overflow-hidden">
                    <div className="font-mono text-[11px] truncate">{file.path}</div>
                    <div className={`text-[10px] truncate ${isSelected ? 'text-blue-100' : 'text-slate-400'}`}>
                      {file.description}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Maven CLI execution hints */}
          <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-xs space-y-1.5">
            <span className="font-bold text-[11px] text-slate-600 dark:text-slate-400 flex items-center space-x-1">
              <Terminal className="w-3.5 h-3.5 text-emerald-500" />
              <span>Quick Run Commands:</span>
            </span>
            <div className="p-2 rounded bg-slate-950 text-slate-200 font-mono text-[10px] select-all space-y-1">
              <div>mvn clean package</div>
              <div className="text-emerald-400">mvn exec:java -Dexec.mainClass="com.railease.Main"</div>
            </div>
          </div>
        </div>

        {/* Right Column: Code Content Viewer */}
        <div className={`lg:col-span-8 rounded-lg border overflow-hidden flex flex-col ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-950 border-slate-800'
        }`}>
          {/* Editor Header Bar */}
          <div className={`px-4 py-2.5 border-b flex items-center justify-between text-xs ${
            isSwingTheme ? 'bg-[#f1f5f9] border-[#cbd5e1]' : 'bg-slate-900 border-slate-800 text-slate-300'
          }`}>
            <div className="flex items-center space-x-2">
              <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                {selectedFile.path}
              </span>
              <span className="text-[10px] text-slate-400 hidden sm:inline">
                ({selectedFile.content.split('\n').length} lines)
              </span>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleCopy}
                className="px-2.5 py-1 text-xs rounded bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 transition flex items-center space-x-1"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied!' : 'Copy Code'}</span>
              </button>
            </div>
          </div>

          {/* Syntax Highlighted View */}
          <div className="p-4 overflow-x-auto overflow-y-auto max-h-[500px] bg-slate-950 text-slate-200 font-mono text-xs leading-relaxed">
            <pre>
              <code>{selectedFile.content}</code>
            </pre>
          </div>

          {/* File description footnote */}
          <div className="px-4 py-2 border-t border-slate-800 bg-slate-900/90 text-[11px] text-slate-400 flex justify-between items-center">
            <span>{selectedFile.description}</span>
            <span className="font-mono text-emerald-400">UTF-8 • Java 17</span>
          </div>
        </div>
      </div>
    </div>
  );
};
