import React, { useState } from 'react';
import { db } from '../services/db';
import { Booking } from '../types';
import { 
  Search, Train, Calendar, Users, CheckCircle2, 
  AlertTriangle, Printer, MapPin, XCircle 
} from 'lucide-react';

interface PNREnquiryProps {
  onViewTicket: (pnr: string) => void;
  onCancelTicket: (pnr: string) => void;
  isSwingTheme: boolean;
}

export const PNREnquiry: React.FC<PNREnquiryProps> = ({
  onViewTicket,
  onCancelTicket,
  isSwingTheme,
}) => {
  const [pnrInput, setPnrInput] = useState('');
  const [searchedBooking, setSearchedBooking] = useState<Booking | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const clean = pnrInput.trim();
    if (!clean) {
      setErrorMessage('Please enter a valid 10-digit PNR number.');
      setSearchedBooking(null);
      return;
    }

    const booking = db.getBookingByPNR(clean);
    if (!booking) {
      setErrorMessage(`No reservation found for PNR "${clean}". Please verify your 10-digit number.`);
      setSearchedBooking(null);
      return;
    }

    setSearchedBooking(booking);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      {/* Banner */}
      <div className={`p-4 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
        isSwingTheme ? 'bg-[#e2e8f0] border-[#94a3b8]' : 'bg-slate-900 border-slate-800'
      }`}>
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded bg-amber-500 text-slate-950 font-black">
            PNR
          </div>
          <div>
            <h2 className="font-bold text-base text-slate-900 dark:text-slate-100">
              Passenger Name Record (PNR) Status Enquiry
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
              SELECT * FROM bookings WHERE pnr = ?
            </p>
          </div>
        </div>
        <div className="text-xs font-semibold px-2.5 py-1 bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 rounded border border-blue-300">
          Real-time Berth Allocation & Chart Status
        </div>
      </div>

      {/* Search Input Box */}
      <div className={`p-5 rounded-lg border space-y-3 ${
        isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/60 border-slate-800'
      }`}>
        <form onSubmit={handleSearch} className="space-y-3">
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
            Enter 10-Digit PNR Number:
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              maxLength={10}
              value={pnrInput}
              onChange={(e) => setPnrInput(e.target.value)}
              placeholder="e.g. 2458910472"
              className={`w-full px-3 py-2 text-sm font-mono tracking-wider rounded border transition outline-none ${
                isSwingTheme 
                  ? 'bg-white border-[#7f9db9] text-slate-800 focus:border-blue-600' 
                  : 'bg-slate-950 border-slate-700 text-slate-100'
              }`}
            />
            <button
              type="submit"
              className="px-6 py-2 rounded text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white transition flex items-center justify-center space-x-1.5 shadow"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Get Status</span>
            </button>
          </div>
          <p className="text-[11px] text-slate-400">
            Sample test PNR: <code>2458910472</code> (Pre-seeded booking in SQLite database)
          </p>
        </form>
      </div>

      {errorMessage && (
        <div className="p-3 rounded text-xs bg-red-100 border border-red-300 text-red-800 flex items-start space-x-2 dark:bg-red-950/60 dark:border-red-800 dark:text-red-300">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Result Card */}
      {searchedBooking && (
        <div className={`p-5 rounded-lg border space-y-4 ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/60 border-slate-800'
        }`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800 gap-2">
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                PNR STATUS REPORT
              </span>
              <div className="text-lg font-black font-mono text-blue-600 dark:text-blue-400">
                {searchedBooking.pnr}
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <span className={`px-2.5 py-1 rounded text-xs font-bold flex items-center space-x-1 ${
                searchedBooking.status === 'CONFIRMED'
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300 dark:bg-emerald-950 dark:text-emerald-300'
                  : 'bg-red-100 text-red-800 border border-red-300 dark:bg-red-950 dark:text-red-300'
              }`}>
                {searchedBooking.status === 'CONFIRMED' ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mr-1" />
                ) : (
                  <AlertTriangle className="w-3.5 h-3.5 text-red-600 mr-1" />
                )}
                <span>{searchedBooking.status}</span>
              </span>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 rounded bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
              <span className="text-[10px] text-slate-400 font-bold block">TRAIN NUMBER & NAME</span>
              <span className="font-bold text-slate-800 dark:text-slate-200 text-sm">
                {searchedBooking.trainNumber} - {searchedBooking.trainName}
              </span>
              <span className="text-[11px] text-slate-500 block mt-0.5">
                Class: {searchedBooking.travelClass} • Quota: {searchedBooking.quota}
              </span>
            </div>

            <div className="p-3 rounded bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
              <span className="text-[10px] text-slate-400 font-bold block">DATE OF JOURNEY</span>
              <div className="flex items-center space-x-1 text-sm font-semibold">
                <Calendar className="w-3.5 h-3.5 text-blue-500" />
                <span>{searchedBooking.journeyDate}</span>
              </div>
              <span className="text-[11px] text-slate-500 block mt-0.5">
                Booked by: {searchedBooking.username}
              </span>
            </div>

            <div className="p-3 rounded bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
              <span className="text-[10px] text-slate-400 font-bold block">TOTAL FARE PAID</span>
              <span className="text-base font-black text-emerald-600 dark:text-emerald-400">
                ₹ {searchedBooking.totalFare.toFixed(2)}
              </span>
              <span className="text-[11px] text-slate-500 block mt-0.5">
                Chart Status: <strong className="text-blue-500">PREPARED</strong>
              </span>
            </div>
          </div>

          {/* Passenger Manifest */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
              Passenger Allocation Manifest
            </h4>
            <div className="overflow-x-auto rounded border border-slate-200 dark:border-slate-700">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold">
                  <tr>
                    <th className="py-2 px-3">#</th>
                    <th className="py-2 px-3">Passenger</th>
                    <th className="py-2 px-3">Age / Gender</th>
                    <th className="py-2 px-3">Preference</th>
                    <th className="py-2 px-3">Coach & Berth</th>
                    <th className="py-2 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                  {searchedBooking.passengers.map((p, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                      <td className="py-2 px-3 font-mono">{idx + 1}</td>
                      <td className="py-2 px-3 font-semibold">{p.name}</td>
                      <td className="py-2 px-3">{p.age} Yrs / {p.gender}</td>
                      <td className="py-2 px-3">{p.berthPreference}</td>
                      <td className="py-2 px-3 font-mono font-bold text-blue-600 dark:text-blue-400">
                        {searchedBooking.status === 'CANCELLED' ? 'CANCELLED' : (p.allocatedBerth || 'B2-14 (LB)')}
                      </td>
                      <td className="py-2 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          searchedBooking.status === 'CANCELLED' ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          {searchedBooking.status === 'CANCELLED' ? 'CAN' : p.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-end gap-2">
            {searchedBooking.status === 'CONFIRMED' && (
              <button
                type="button"
                onClick={() => onCancelTicket(searchedBooking.pnr)}
                className="px-4 py-2 text-xs font-semibold rounded bg-red-100 hover:bg-red-200 text-red-700 dark:bg-red-950 dark:text-red-300 transition flex items-center space-x-1"
              >
                <XCircle className="w-3.5 h-3.5" />
                <span>Cancel Reservation</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => onViewTicket(searchedBooking.pnr)}
              className="px-4 py-2 text-xs font-bold rounded bg-blue-600 hover:bg-blue-700 text-white transition flex items-center space-x-1.5 shadow"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>View & Print Official E-Ticket</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
