import React, { useState } from 'react';
import { db } from '../services/db';
import { User } from '../types';
import { 
  KeyRound, User as UserIcon, Lock, CheckCircle2, 
  AlertCircle, Train, ShieldCheck, UserPlus, ArrowRight, Sparkles 
} from 'lucide-react';

interface LoginFormProps {
  onLoginSuccess: (user: User) => void;
  isSwingTheme: boolean;
}

export const LoginForm: React.FC<LoginFormProps> = ({ onLoginSuccess, isSwingTheme }) => {
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [username, setUsername] = useState('nehaborkar');
  const [password, setPassword] = useState('password123');
  
  // Registration fields
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    // Rule 1: Validate non-empty
    if (!username.trim() || !password) {
      setErrorMessage('Validation Error: Username and password fields cannot be left empty.');
      return;
    }

    setLoading(true);
    try {
      const res = await db.authenticate(username, password);
      if (res.success && res.user) {
        setSuccessMessage(`Login successful! Authenticated as ${res.user.fullName}.`);
        setTimeout(() => {
          onLoginSuccess(res.user!);
        }, 350);
      } else {
        setErrorMessage(res.error || 'Invalid credentials. Please verify your login credentials.');
      }
    } catch {
      setErrorMessage('Database communication failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!username.trim() || !password.trim()) {
      setErrorMessage('Username and password are required.');
      return;
    }
    if (password.length < 4) {
      setErrorMessage('Password must be at least 4 characters long.');
      return;
    }

    setLoading(true);
    try {
      const res = await db.registerUser({
        username,
        passwordPlain: password,
        fullName: regFullName || username,
        email: regEmail,
        phone: regPhone,
      });

      if (res.success && res.user) {
        setSuccessMessage(`Account created successfully! Welcome, ${res.user.fullName}. Logging in...`);
        setTimeout(() => {
          onLoginSuccess(res.user!);
        }, 500);
      } else {
        setErrorMessage(res.error || 'Failed to create user.');
      }
    } catch {
      setErrorMessage('Failed to register user in SQLite database.');
    } finally {
      setLoading(false);
    }
  };

  const handleLoadDemo = () => {
    setUsername('nehaborkar');
    setPassword('password123');
    setErrorMessage(null);
    setSuccessMessage('Demo credentials filled: nehaborkar / password123');
  };

  return (
    <div className="flex flex-col items-center justify-center py-6 px-4">
      {/* Swing / Modern Dialog Box */}
      <div className={`w-full max-w-md rounded-lg overflow-hidden transition-all shadow-xl border ${
        isSwingTheme 
          ? 'bg-[#ece9d8] border-[#7f9db9]' 
          : 'bg-slate-900/90 border-slate-800'
      }`}>
        {/* Dialog Header */}
        <div className={`px-5 py-4 border-b flex items-center justify-between ${
          isSwingTheme 
            ? 'bg-gradient-to-r from-[#0a246a] to-[#2563eb] text-white border-[#0a246a]' 
            : 'bg-slate-800/80 text-slate-100 border-slate-700'
        }`}>
          <div className="flex items-center space-x-2.5">
            <div className="p-1.5 bg-amber-400 text-slate-900 rounded">
              <Train className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-sm tracking-wide">
                {isRegisterMode ? 'User Registration' : 'RailEase System Login'}
              </h2>
              <p className="text-[11px] text-white/80 font-mono">
                javax.swing.JFrame • SQLite JDBC Driver
              </p>
            </div>
          </div>
          <span className="text-[10px] px-2 py-0.5 bg-white/20 rounded font-semibold text-white">
            Task 1
          </span>
        </div>

        {/* Content Body */}
        <div className="p-6">
          {/* Welcome Banner */}
          <div className="mb-5 text-center">
            <h3 className={`text-lg font-bold ${isSwingTheme ? 'text-[#0a246a]' : 'text-slate-100'}`}>
              RailEase — Online Reservation System
            </h3>
            <p className={`text-xs mt-1 ${isSwingTheme ? 'text-slate-600' : 'text-slate-400'}`}>
              Oasis Infobyte Java Internship • Developed by <strong className="font-semibold text-amber-500">Neha Vinod Borkar</strong>
            </p>
          </div>

          {/* Feedback Messages */}
          {errorMessage && (
            <div className="mb-4 p-3 rounded text-xs bg-red-100 border border-red-300 text-red-800 flex items-start space-x-2 dark:bg-red-950/50 dark:border-red-800 dark:text-red-300">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="mb-4 p-3 rounded text-xs bg-emerald-100 border border-emerald-300 text-emerald-800 flex items-start space-x-2 dark:bg-emerald-950/50 dark:border-emerald-800 dark:text-emerald-300">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{successMessage}</span>
            </div>
          )}

          <form onSubmit={isRegisterMode ? handleRegister : handleLogin} className="space-y-4">
            {isRegisterMode && (
              <>
                <div>
                  <label className={`block text-xs font-semibold mb-1 ${isSwingTheme ? 'text-slate-700' : 'text-slate-300'}`}>
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={regFullName}
                    onChange={(e) => setRegFullName(e.target.value)}
                    placeholder="e.g. Neha Vinod Borkar"
                    className={`w-full px-3 py-2 text-xs rounded border transition outline-none ${
                      isSwingTheme 
                        ? 'bg-white border-[#7f9db9] text-slate-800 focus:border-blue-600 focus:ring-1 focus:ring-blue-600' 
                        : 'bg-slate-950 border-slate-700 text-slate-100 focus:border-blue-500'
                    }`}
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className={`block text-xs font-semibold mb-1 ${isSwingTheme ? 'text-slate-700' : 'text-slate-300'}`}>
                      Email ID
                    </label>
                    <input
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="neha@example.com"
                      className={`w-full px-3 py-2 text-xs rounded border transition outline-none ${
                        isSwingTheme ? 'bg-white border-[#7f9db9] text-slate-800' : 'bg-slate-950 border-slate-700 text-slate-100'
                      }`}
                    />
                  </div>
                  <div>
                    <label className={`block text-xs font-semibold mb-1 ${isSwingTheme ? 'text-slate-700' : 'text-slate-300'}`}>
                      Mobile Number
                    </label>
                    <input
                      type="tel"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      placeholder="+91 9876543210"
                      className={`w-full px-3 py-2 text-xs rounded border transition outline-none ${
                        isSwingTheme ? 'bg-white border-[#7f9db9] text-slate-800' : 'bg-slate-950 border-slate-700 text-slate-100'
                      }`}
                    />
                  </div>
                </div>
              </>
            )}

            <div>
              <label className={`block text-xs font-semibold mb-1 flex items-center justify-between ${
                isSwingTheme ? 'text-slate-700' : 'text-slate-300'
              }`}>
                <span className="flex items-center space-x-1">
                  <UserIcon className="w-3 h-3 text-blue-500" />
                  <span>Username / Login ID <span className="text-red-500">*</span></span>
                </span>
                <span className="text-[10px] text-slate-400 font-normal">javax.swing.JTextField</span>
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter username"
                required
                className={`w-full px-3 py-2 text-xs rounded border font-mono transition outline-none ${
                  isSwingTheme 
                    ? 'bg-white border-[#7f9db9] text-slate-800 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 shadow-inner' 
                    : 'bg-slate-950 border-slate-700 text-slate-100 focus:border-blue-500'
                }`}
              />
            </div>

            <div>
              <label className={`block text-xs font-semibold mb-1 flex items-center justify-between ${
                isSwingTheme ? 'text-slate-700' : 'text-slate-300'
              }`}>
                <span className="flex items-center space-x-1">
                  <Lock className="w-3 h-3 text-amber-500" />
                  <span>Password <span className="text-red-500">*</span></span>
                </span>
                <span className="text-[10px] text-slate-400 font-normal">javax.swing.JPasswordField</span>
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter account password"
                required
                className={`w-full px-3 py-2 text-xs rounded border font-mono transition outline-none ${
                  isSwingTheme 
                    ? 'bg-white border-[#7f9db9] text-slate-800 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 shadow-inner' 
                    : 'bg-slate-950 border-slate-700 text-slate-100 focus:border-blue-500'
                }`}
              />
              <p className="text-[10px] mt-1 text-slate-500 flex items-center space-x-1">
                <ShieldCheck className="w-3 h-3 text-emerald-500" />
                <span>Protected with SHA-256 password hashing before DB verification.</span>
              </p>
            </div>

            {/* Submit Action */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className={`w-full py-2.5 px-4 rounded text-xs font-bold transition flex items-center justify-center space-x-2 ${
                  isSwingTheme 
                    ? 'bg-[#0a246a] hover:bg-[#183a8b] text-white shadow active:translate-y-0.5 border border-[#0a246a]' 
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/30'
                }`}
              >
                {loading ? (
                  <span>Executing PreparedStatement SQL...</span>
                ) : isRegisterMode ? (
                  <>
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>Create Account & Register</span>
                  </>
                ) : (
                  <>
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>Login to RailEase System</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Helper Tools */}
          <div className="mt-5 pt-4 border-t border-slate-300 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
            <button
              type="button"
              onClick={handleLoadDemo}
              className="text-[11px] text-blue-600 dark:text-blue-400 hover:underline flex items-center space-x-1"
            >
              <Sparkles className="w-3 h-3" />
              <span>Fill Pre-configured Demo Account</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setIsRegisterMode(!isRegisterMode);
                setErrorMessage(null);
                setSuccessMessage(null);
              }}
              className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 hover:text-blue-600"
            >
              {isRegisterMode ? 'Already have an account? Login' : 'Need an account? Register'}
            </button>
          </div>
        </div>

        {/* Footnote */}
        <div className={`px-4 py-2 text-[10px] text-center border-t font-mono ${
          isSwingTheme ? 'bg-[#e0ded0] text-slate-600 border-[#d4d0c8]' : 'bg-slate-950 text-slate-500 border-slate-800'
        }`}>
          Oasis Infobyte Java Task 1 • Developer: Neha Vinod Borkar
        </div>
      </div>
    </div>
  );
};
