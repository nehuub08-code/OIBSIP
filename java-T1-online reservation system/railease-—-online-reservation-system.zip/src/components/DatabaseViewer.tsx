import React, { useState } from 'react';
import { db } from '../services/db';
import { 
  Database, Play, RotateCcw, Download, Table, 
  Terminal, CheckCircle2, AlertCircle, FileCode 
} from 'lucide-react';

interface DatabaseViewerProps {
  isSwingTheme: boolean;
  onRefreshTrigger?: () => void;
}

export const DatabaseViewer: React.FC<DatabaseViewerProps> = ({ isSwingTheme, onRefreshTrigger }) => {
  const [activeTable, setActiveTable] = useState<'users' | 'trains' | 'bookings' | 'passengers' | 'cancellations'>('bookings');
  const [sqlQuery, setSqlQuery] = useState('SELECT * FROM bookings;');
  const [queryResult, setQueryResult] = useState<{
    columns: string[];
    rows: (string | number)[][];
    message?: string;
    error?: string;
  } | null>(null);

  const [notification, setNotification] = useState<string | null>(null);

  const handleRunSQL = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const res = db.executeRawSQL(sqlQuery);
    setQueryResult(res);
  };

  const handleQuickQuery = (table: string) => {
    const q = `SELECT * FROM ${table};`;
    setSqlQuery(q);
    const res = db.executeRawSQL(q);
    setQueryResult(res);
  };

  const handleResetDatabase = () => {
    if (window.confirm('Reset SQLite database to original initial seed? All recent custom bookings will be restored to defaults.')) {
      db.resetToDefault();
      setNotification('Database reset to initial schema and sample seed successfully.');
      if (onRefreshTrigger) onRefreshTrigger();
      handleQuickQuery(activeTable);
      setTimeout(() => setNotification(null), 3000);
    }
  };

  const handleExportJSON = () => {
    const json = db.exportJSON();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'railease-sqlite-db-dump.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setNotification('SQLite database snapshot exported.');
    setTimeout(() => setNotification(null), 3000);
  };

  // Run initial query if null
  React.useEffect(() => {
    handleQuickQuery(activeTable);
  }, [activeTable]);

  const allUsers = db.getAllUsers();
  const allTrains = db.getAllTrains();
  const allBookings = db.getAllBookings();
  const allCancellations = db.getAllCancellations();

  return (
    <div className="space-y-5">
      {/* Banner */}
      <div className={`p-4 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
        isSwingTheme ? 'bg-[#e2e8f0] border-[#94a3b8]' : 'bg-slate-900 border-slate-800'
      }`}>
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded bg-emerald-700 text-white">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-base text-slate-900 dark:text-slate-100">
              SQLite Database Inspector & SQL Console
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
              Database URL: jdbc:sqlite:railease.db • Driver: org.xerial.sqlite-jdbc
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleExportJSON}
            className={`px-3 py-1.5 text-xs font-semibold rounded border transition flex items-center space-x-1 ${
              isSwingTheme ? 'bg-white border-slate-400 text-slate-700' : 'bg-slate-800 border-slate-700 text-slate-200'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export DB JSON</span>
          </button>
          <button
            onClick={handleResetDatabase}
            className="px-3 py-1.5 text-xs font-semibold rounded bg-red-100 hover:bg-red-200 text-red-700 dark:bg-red-950 dark:text-red-300 transition flex items-center space-x-1"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset DB</span>
          </button>
        </div>
      </div>

      {notification && (
        <div className="p-3 rounded text-xs bg-emerald-100 border border-emerald-300 text-emerald-800 flex items-center space-x-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* SQL Query Playground */}
      <div className={`p-5 rounded-lg border space-y-3 ${
        isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/60 border-slate-800'
      }`}>
        <div className="flex items-center justify-between border-b pb-2 border-slate-200 dark:border-slate-800">
          <div className="flex items-center space-x-2 text-xs font-bold text-slate-700 dark:text-slate-300">
            <Terminal className="w-4 h-4 text-emerald-500" />
            <span>SQL Query Runner (PreparedStatement Engine)</span>
          </div>
          <div className="flex items-center space-x-1">
            <span className="text-[11px] text-slate-400 mr-1">Quick Select:</span>
            {['bookings', 'trains', 'users', 'cancellations', 'passengers'].map((tbl) => (
              <button
                key={tbl}
                onClick={() => {
                  setActiveTable(tbl as any);
                  handleQuickQuery(tbl);
                }}
                className={`px-2 py-0.5 rounded text-[11px] font-mono transition ${
                  activeTable === tbl
                    ? 'bg-emerald-600 text-white font-bold'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {tbl}
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleRunSQL} className="space-y-2">
          <div className="flex gap-2">
            <input
              type="text"
              value={sqlQuery}
              onChange={(e) => setSqlQuery(e.target.value)}
              placeholder="e.g. SELECT * FROM bookings;"
              className={`w-full px-3 py-2 text-xs font-mono rounded border transition outline-none ${
                isSwingTheme ? 'bg-white border-[#7f9db9] text-slate-900' : 'bg-slate-950 border-slate-700 text-emerald-400'
              }`}
            />
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold rounded bg-emerald-600 hover:bg-emerald-700 text-white transition flex items-center space-x-1.5 shadow"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Run SQL</span>
            </button>
          </div>
        </form>

        {queryResult?.message && (
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-mono">
            {queryResult.message}
          </div>
        )}
      </div>

      {/* Query Result Grid */}
      {queryResult && (
        <div className={`p-4 rounded-lg border space-y-2 ${
          isSwingTheme ? 'bg-white border-[#cbd5e1]' : 'bg-slate-900/60 border-slate-800'
        }`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-xs font-bold text-slate-700 dark:text-slate-300">
              <Table className="w-4 h-4 text-blue-500" />
              <span>Result Set Table ({queryResult.rows.length} rows)</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">javax.swing.JTable</span>
          </div>

          <div className="overflow-x-auto rounded border border-slate-200 dark:border-slate-800 max-h-96">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold sticky top-0">
                <tr>
                  {queryResult.columns.map((col, idx) => (
                    <th key={idx} className="py-2 px-3 border-b border-slate-200 dark:border-slate-700 font-mono uppercase text-[11px]">
                      {col}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {queryResult.rows.map((row, rIdx) => (
                  <tr key={rIdx} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                    {row.map((val, cIdx) => (
                      <td key={cIdx} className="py-2 px-3 text-[11px] font-mono">
                        {String(val)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Database Schema DDL Documentation */}
      <div className={`p-4 rounded-lg border space-y-3 ${
        isSwingTheme ? 'bg-[#f8fafc] border-slate-300' : 'bg-slate-900/40 border-slate-800'
      }`}>
        <div className="flex items-center space-x-2 text-xs font-bold text-slate-700 dark:text-slate-300">
          <FileCode className="w-4 h-4 text-amber-500" />
          <span>SQLite Database Schema (Schema DDL)</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-[11px] font-mono">
          <div className="p-2.5 rounded bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
            <span className="font-bold text-blue-600 block mb-1">TABLE users ({allUsers.length} rows)</span>
            <span className="text-slate-500">username (PK), password_hash, full_name, email, phone, created_at</span>
          </div>
          <div className="p-2.5 rounded bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
            <span className="font-bold text-blue-600 block mb-1">TABLE trains ({allTrains.length} rows)</span>
            <span className="text-slate-500">train_number (PK), train_name, source, destination, dep_time, arr_time, base_fare_sl</span>
          </div>
          <div className="p-2.5 rounded bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
            <span className="font-bold text-blue-600 block mb-1">TABLE bookings ({allBookings.length} rows)</span>
            <span className="text-slate-500">pnr (PK), username, train_number, train_name, journey_date, travel_class, total_fare, status</span>
          </div>
        </div>
      </div>
    </div>
  );
};
