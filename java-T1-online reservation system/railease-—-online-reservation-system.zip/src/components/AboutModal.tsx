import React from 'react';
import { X, Award, CheckCircle2, Train, Database, Code, ShieldCheck } from 'lucide-react';

interface AboutModalProps {
  onClose: () => void;
  isSwingTheme: boolean;
}

export const AboutModal: React.FC<AboutModalProps> = ({ onClose, isSwingTheme }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className={`w-full max-w-2xl rounded-xl overflow-hidden shadow-2xl border transition-all ${
        isSwingTheme ? 'bg-white border-[#7f9db9]' : 'bg-slate-900 border-slate-700'
      }`}>
        {/* Header */}
        <div className={`px-5 py-3 border-b flex items-center justify-between ${
          isSwingTheme ? 'bg-[#0a246a] text-white' : 'bg-slate-800 text-slate-100'
        }`}>
          <div className="flex items-center space-x-2">
            <Award className="w-5 h-5 text-amber-300" />
            <span className="font-bold text-sm">Oasis Infobyte Internship — Task 1 Submission</span>
          </div>
          <button onClick={onClose} className="p-1 rounded hover:bg-white/20 text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 text-xs text-slate-700 dark:text-slate-300">
          <div className="border-b pb-3 border-slate-200 dark:border-slate-800">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 rounded bg-blue-600 text-white font-black text-xs">
                RE
              </div>
              <div>
                <h3 className="text-base font-black text-blue-950 dark:text-blue-300">
                  RailEase — Online Reservation System
                </h3>
                <p className="text-slate-500 text-[11px]">
                  Task 1: Complete Desktop Java GUI & SQLite JDBC Implementation
                </p>
              </div>
            </div>
          </div>

          {/* Project Credentials Table */}
          <div className="grid grid-cols-2 gap-3 p-3 rounded bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-xs font-mono">
            <div>
              <span className="text-slate-400 block text-[10px]">DEVELOPER NAME</span>
              <strong className="text-blue-900 dark:text-blue-200 text-sm">Neha Vinod Borkar</strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">ASSIGNED TRACK</span>
              <strong className="text-emerald-700 dark:text-emerald-400 text-sm">Java Development</strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">TASK TITLE</span>
              <span>Task 1 — Online Reservation System</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">DATABASE ENGINE</span>
              <span>SQLite JDBC (railease.db)</span>
            </div>
          </div>

          {/* Technical Specifications */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider text-[11px]">
              Technology Stack & Implementation Highlights:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span><strong>Java Swing GUI:</strong> JFrame, JPanel, JComboBox, JTextField, JOptionPane dialogs.</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span><strong>SQLite Database:</strong> Local file storage without requiring external servers.</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span><strong>PreparedStatement:</strong> Safe parameterized SQL queries preventing SQL injection.</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span><strong>SHA-256 Encryption:</strong> Passwords securely hashed; never stored in plain text.</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span><strong>Java Date APIs:</strong> Validates journey dates to prevent past date reservations.</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span><strong>10-Digit PNR System:</strong> Unique PNR generation with passenger manifest allocation.</span>
              </div>
            </div>
          </div>

          <div className="p-3 rounded bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-[11px] text-blue-900 dark:text-blue-200">
            <strong>Evaluator Note:</strong> Click <strong>"Java Maven Code"</strong> in the top menu to view the complete Java class files or download the full runnable Maven project as a <code>.ZIP</code> file ready to compile and run.
          </div>
        </div>

        {/* Footer */}
        <div className={`px-5 py-3 border-t flex justify-end ${
          isSwingTheme ? 'bg-[#ece9d8] border-[#d4d0c8]' : 'bg-slate-800 border-slate-700'
        }`}>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
