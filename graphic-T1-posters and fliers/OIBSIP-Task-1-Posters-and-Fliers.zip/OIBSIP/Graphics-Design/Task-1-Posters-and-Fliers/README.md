# PixelCraft — Two-Campaign Poster Design Collection
Designer: Neha Vinod Borkar
Track: Graphics Design
Task: Posters & Fliers