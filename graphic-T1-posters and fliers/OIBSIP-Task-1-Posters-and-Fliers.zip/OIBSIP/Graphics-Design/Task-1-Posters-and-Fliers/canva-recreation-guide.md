# Canva Recreation Guide
Exact 1080x1080 coordinates and search terms.