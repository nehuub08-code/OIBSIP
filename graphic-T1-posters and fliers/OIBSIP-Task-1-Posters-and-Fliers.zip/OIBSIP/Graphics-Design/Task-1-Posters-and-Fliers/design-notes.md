# Design Notes
Campaign A: FutureTech 2027
Campaign B: Every Drop Matters