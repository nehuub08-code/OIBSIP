import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Copy, Check, RotateCcw, History, Delete, Smartphone, Sparkles } from 'lucide-react';
import { ExpressionEvaluator } from '../utils/evaluator';
import { soundFx } from '../utils/sound';

export interface CalculationHistoryItem {
  id: string;
  expression: string;
  result: string;
  timestamp: string;
}

interface AndroidDeviceProps {
  onCalculationPerformed?: (expr: string, res: string) => void;
  interactiveRef?: React.MutableRefObject<{
    tapButton: (label: string) => void;
    reset: () => void;
    getState: () => { expression: string; result: string; isError: boolean };
  } | null>;
}

export const AndroidDevice: React.FC<AndroidDeviceProps> = ({
  onCalculationPerformed,
  interactiveRef,
}) => {
  const [expression, setExpression] = useState<string>('');
  const [result, setResult] = useState<string>('0');
  const [isResultDisplayed, setIsResultDisplayed] = useState<boolean>(false);
  const [isErrorState, setIsErrorState] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [history, setHistory] = useState<CalculationHistoryItem[]>([]);
  const [copied, setCopied] = useState<boolean>(false);
  const [deviceSkin, setDeviceSkin] = useState<'framed' | 'clean'>('framed');
  const [activeKey, setActiveKey] = useState<string | null>(null);

  const displayScrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll display to right when expression changes
  useEffect(() => {
    if (displayScrollRef.current) {
      displayScrollRef.current.scrollLeft = displayScrollRef.current.scrollWidth;
    }
  }, [result, expression]);

  const triggerKeyAnimation = (keyId: string) => {
    setActiveKey(keyId);
    setTimeout(() => {
      setActiveKey((prev) => (prev === keyId ? null : prev));
    }, 150);
  };

  // Button handlers matching Android MainActivity.java
  const handleNumber = (digit: string) => {
    soundFx.playClick('number');
    triggerKeyAnimation(digit);

    if (isErrorState) {
      resetCalculator();
      setResult(digit);
      return;
    }

    if (isResultDisplayed) {
      setExpression('');
      setResult(digit);
      setIsResultDisplayed(false);
      return;
    }

    setResult((prev) => {
      if (prev === '0') {
        return digit;
      }
      // Check if after operator we just have 0
      const lastChar = prev.charAt(prev.length - 1);
      const secondLast = prev.length >= 2 ? prev.charAt(prev.length - 2) : '';
      if (lastChar === '0' && ExpressionEvaluator.isOperator(secondLast)) {
        return prev.slice(0, -1) + digit;
      }
      return prev + digit;
    });
  };

  const handleDecimal = () => {
    soundFx.playClick('number');
    triggerKeyAnimation('.');

    if (isErrorState || isResultDisplayed) {
      setExpression('');
      setResult('0.');
      setIsResultDisplayed(false);
      setIsErrorState(false);
      return;
    }

    setResult((prev) => {
      if (prev === '' || prev === '0') {
        return '0.';
      }
      const lastChar = prev.charAt(prev.length - 1);
      if (ExpressionEvaluator.isOperator(lastChar)) {
        return prev + '0.';
      }
      if (ExpressionEvaluator.canAddDecimal(prev)) {
        return prev + '.';
      }
      return prev;
    });
  };

  const handleOperator = (op: string) => {
    soundFx.playClick('operator');
    triggerKeyAnimation(op);

    if (isErrorState) {
      resetCalculator();
      return;
    }

    if (isResultDisplayed) {
      setIsResultDisplayed(false);
    }

    setResult((prev) => {
      if (prev === '0' || prev === '') {
        if (op === '−' || op === '-') {
          return '−';
        }
        return prev;
      }

      const lastChar = prev.charAt(prev.length - 1);

      if (ExpressionEvaluator.isOperator(lastChar)) {
        // Allow negative sign after multiply or divide (e.g. 5 × −2)
        if ((lastChar === '×' || lastChar === '÷' || lastChar === '*' || lastChar === '/') && (op === '−' || op === '-')) {
          return prev + '−';
        }

        // Consecutive operator replacement
        if (prev.length >= 2) {
          const secondLast = prev.charAt(prev.length - 2);
          if (ExpressionEvaluator.isOperator(secondLast)) {
            return prev.slice(0, -2) + op;
          }
        }
        return prev.slice(0, -1) + op;
      } else if (lastChar === '.') {
        return prev.slice(0, -1) + op;
      } else {
        return prev + op;
      }
    });
  };

  const handleEquals = () => {
    soundFx.playClick('equals');
    triggerKeyAnimation('=');

    if (isErrorState || result === '0' || !result) {
      return;
    }

    if (isResultDisplayed) {
      return;
    }

    const rawExpr = result;
    setExpression(`${rawExpr} =`);

    const evalResult = ExpressionEvaluator.evaluate(rawExpr);

    if (evalResult.success) {
      const finalRes = evalResult.result;
      setResult(finalRes);
      setIsResultDisplayed(true);
      setIsErrorState(false);

      // Add to history
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setHistory((prev) => [
        {
          id: Math.random().toString(),
          expression: rawExpr,
          result: finalRes,
          timestamp: timeStr,
        },
        ...prev.slice(0, 19),
      ]);

      if (onCalculationPerformed) {
        onCalculationPerformed(rawExpr, finalRes);
      }
    } else {
      setResult('Error');
      setIsErrorState(true);
      setIsResultDisplayed(false);
    }
  };

  const handleClear = () => {
    soundFx.playClick('clear');
    triggerKeyAnimation('C');
    resetCalculator();
  };

  const handleBackspace = () => {
    soundFx.playClick('clear');
    triggerKeyAnimation('⌫');

    if (isErrorState || isResultDisplayed) {
      resetCalculator();
      return;
    }

    setResult((prev) => {
      if (prev.length <= 1 || prev === '0') {
        return '0';
      }
      return prev.slice(0, -1);
    });
  };

  const handlePlusMinus = () => {
    soundFx.playClick('number');
    triggerKeyAnimation('±');

    if (isErrorState) return;
    if (result === '0' || result === '') {
      setResult('−');
      return;
    }

    setResult((prev) => {
      // Toggle sign of last operand
      const match = prev.match(/([+\−\×\÷\-\*\/])?([−\-]?[0-9.]*)$/);
      if (!match) return prev;
      const prefix = prev.slice(0, prev.length - match[0].length);
      const op = match[1] || '';
      const num = match[2];

      if (num.startsWith('−') || num.startsWith('-')) {
        return prefix + op + num.replace(/^[−\-]/, '');
      } else {
        return prefix + op + '−' + num;
      }
    });
  };

  const handlePercent = () => {
    soundFx.playClick('operator');
    triggerKeyAnimation('%');

    if (isErrorState || result === '0') return;
    const evalRes = ExpressionEvaluator.evaluate(result);
    if (evalRes.success) {
      const val = parseFloat(evalRes.result) / 100;
      const formatted = ExpressionEvaluator.formatNumber(val);
      setResult(formatted);
      setIsResultDisplayed(true);
    }
  };

  const resetCalculator = () => {
    setExpression('');
    setResult('0');
    setIsResultDisplayed(false);
    setIsErrorState(false);
  };

  // Expose interactive methods to parent (e.g. for Automated Test Suite)
  if (interactiveRef) {
    interactiveRef.current = {
      tapButton: (label: string) => {
        switch (label) {
          case '0':
          case '1':
          case '2':
          case '3':
          case '4':
          case '5':
          case '6':
          case '7':
          case '8':
          case '9':
            handleNumber(label);
            break;
          case '.':
            handleDecimal();
            break;
          case '+':
            handleOperator('+');
            break;
          case '−':
          case '-':
            handleOperator('−');
            break;
          case '×':
          case '*':
            handleOperator('×');
            break;
          case '÷':
          case '/':
            handleOperator('÷');
            break;
          case '=':
            handleEquals();
            break;
          case 'C':
          case 'c':
            handleClear();
            break;
          case '⌫':
          case 'DEL':
            handleBackspace();
            break;
          case '±':
            handlePlusMinus();
            break;
          case '%':
            handlePercent();
            break;
          default:
            break;
        }
      },
      reset: resetCalculator,
      getState: () => ({ expression, result, isError: isErrorState }),
    };
  }

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in code editor or search input
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;

      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        handleNumber(e.key);
      } else if (e.key === '.') {
        e.preventDefault();
        handleDecimal();
      } else if (e.key === '+') {
        e.preventDefault();
        handleOperator('+');
      } else if (e.key === '-') {
        e.preventDefault();
        handleOperator('−');
      } else if (e.key === '*') {
        e.preventDefault();
        handleOperator('×');
      } else if (e.key === '/') {
        e.preventDefault();
        handleOperator('÷');
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        handleEquals();
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (e.key === 'Escape' || e.key.toLowerCase() === 'c') {
        e.preventDefault();
        handleClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [result, expression, isResultDisplayed, isErrorState]);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const getFontSize = () => {
    const len = result.length;
    if (len > 16) return 'text-2xl';
    if (len > 12) return 'text-3xl';
    if (len > 8) return 'text-4xl';
    return 'text-5xl';
  };

  return (
    <div className="flex flex-col items-center">
      {/* Device Toolbar Controls */}
      <div className="flex items-center justify-between w-full max-w-[390px] mb-3 px-2 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setDeviceSkin(deviceSkin === 'framed' ? 'clean' : 'framed')}
            className="flex items-center gap-1.5 py-1 px-2.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 transition-colors"
            title="Toggle phone chassis frame"
          >
            <Smartphone className="w-3.5 h-3.5 text-purple-400" />
            <span>{deviceSkin === 'framed' ? 'Chassis' : 'Minimal'}</span>
          </button>

          <button
            onClick={() => {
              const newState = !soundEnabled;
              setSoundEnabled(newState);
              soundFx.enabled = newState;
            }}
            className="flex items-center gap-1.5 py-1 px-2.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 transition-colors"
            title="Toggle audio click feedback"
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
                <span>Audio On</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3.5 h-3.5 text-slate-500" />
                <span>Muted</span>
              </>
            )}
          </button>
        </div>

        <button
          onClick={() => setShowHistory(!showHistory)}
          className={`flex items-center gap-1.5 py-1 px-2.5 rounded-lg border transition-colors ${
            showHistory
              ? 'bg-purple-950/70 border-purple-600 text-purple-200'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300'
          }`}
          title="Toggle calculation history"
        >
          <History className="w-3.5 h-3.5 text-purple-400" />
          <span>History ({history.length})</span>
        </button>
      </div>

      {/* Android Device Body */}
      <div
        className={`relative w-full max-w-[380px] bg-[#0B111E] text-slate-100 select-none transition-all duration-300 ${
          deviceSkin === 'framed'
            ? 'p-4 rounded-[44px] shadow-2xl ring-1 ring-slate-700/60 shadow-purple-950/20 border-4 border-slate-900'
            : 'p-4 rounded-3xl border border-slate-800 shadow-xl'
        }`}
        style={{ minHeight: '660px' }}
      >
        {/* Device Camera Punch-hole (Framed Mode) */}
        {deviceSkin === 'framed' && (
          <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-slate-950 ring-2 ring-slate-800 flex items-center justify-center pointer-events-none z-30">
            <div className="w-1.5 h-1.5 rounded-full bg-slate-900 ring-1 ring-purple-950"></div>
          </div>
        )}

        {/* Android Status Bar */}
        <div className="flex items-center justify-between text-[11px] font-medium text-slate-400 px-3 pt-1 pb-2">
          <span>12:19</span>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] tracking-wider text-slate-400 font-semibold">5G</span>
            {/* WiFi Icon SVG */}
            <svg className="w-3.5 h-3.5 fill-current text-slate-400" viewBox="0 0 24 24">
              <path d="M12 4C7.31 4 3.07 5.9 0 8.98L12 21 24 8.98C20.93 5.9 16.69 4 12 4zm0 3.5c3.67 0 7.02 1.39 9.58 3.69L12 19.34 2.42 11.19C4.98 8.89 8.33 7.5 12 7.5z" />
            </svg>
            {/* Battery Icon */}
            <div className="flex items-center">
              <div className="w-4 h-2.5 border border-slate-400 rounded-xs p-0.5 flex items-center">
                <div className="h-full bg-slate-300 rounded-[1px] w-[88%]"></div>
              </div>
              <div className="w-0.5 h-1 bg-slate-400 rounded-r-xs"></div>
            </div>
          </div>
        </div>

        {/* Top App Bar inside Android App */}
        <div className="flex items-center justify-between px-3 py-1.5 mb-2 border-b border-slate-800/60">
          <div>
            <h1 className="text-sm font-semibold tracking-wide text-slate-100 flex items-center gap-1.5">
              <span>Calcora</span>
              <span className="text-[9px] font-normal uppercase tracking-wider text-purple-400 bg-purple-950/60 px-1.5 py-0.5 rounded border border-purple-800/50">
                Task 3
              </span>
            </h1>
            <p className="text-[10px] text-slate-400">by Neha Vinod Borkar</p>
          </div>
          <button
            onClick={copyToClipboard}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 transition-colors"
            title="Copy current result"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>

        {/* Calculator Display Card */}
        <div className="relative bg-[#131D2E] border border-slate-800/80 rounded-2xl p-4 mb-4 flex flex-col justify-end min-h-[148px] shadow-inner">
          {/* Previous Expression Line */}
          <div className="text-right text-xs md:text-sm text-slate-400 font-mono tracking-wide h-6 overflow-x-auto whitespace-nowrap scrollbar-none">
            {expression || '\u00A0'}
          </div>

          {/* Current Operand / Evaluated Result Line */}
          <div
            ref={displayScrollRef}
            className={`text-right font-mono font-bold tracking-tight text-white transition-all overflow-x-auto whitespace-nowrap scrollbar-none py-1 ${getFontSize()} ${
              isErrorState ? 'text-rose-400' : 'text-slate-50'
            }`}
          >
            {result}
          </div>

          {/* Copied indicator tooltip */}
          {copied && (
            <div className="absolute top-2 left-2 text-[10px] font-medium bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-md flex items-center gap-1 animate-fade-in">
              <Check className="w-3 h-3" /> Copied to clipboard
            </div>
          )}
        </div>

        {/* History Slide-down Overlay */}
        {showHistory && (
          <div className="absolute inset-x-4 top-24 bottom-14 z-20 bg-[#0F172A]/95 backdrop-blur-md border border-slate-700/80 rounded-2xl p-3 flex flex-col shadow-2xl">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
              <span className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                <History className="w-3.5 h-3.5 text-purple-400" /> Recent Calculations
              </span>
              <button
                onClick={() => setHistory([])}
                className="text-[11px] text-rose-400 hover:text-rose-300 transition-colors"
              >
                Clear History
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {history.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-500 text-xs py-8">
                  <p>No calculations recorded yet.</p>
                  <p className="text-[10px] mt-1 text-slate-600">Perform calculations to populate history.</p>
                </div>
              ) : (
                history.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setResult(item.result);
                      setExpression(`${item.expression} =`);
                      setIsResultDisplayed(true);
                      setShowHistory(false);
                    }}
                    className="w-full text-right p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800 hover:border-purple-600/50 transition-colors block group"
                  >
                    <div className="text-[11px] text-slate-400 font-mono">{item.expression} =</div>
                    <div className="text-sm font-bold font-mono text-purple-300 group-hover:text-purple-200">
                      {item.result}
                    </div>
                  </button>
                ))
              )}
            </div>

            <button
              onClick={() => setShowHistory(false)}
              className="mt-2 w-full py-2 bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 rounded-xl transition-colors"
            >
              Close
            </button>
          </div>
        )}

        {/* Keypad Grid (4 columns x 5 rows) */}
        <div className="grid grid-cols-4 gap-2.5">
          {/* Row 1: C, ⌫, ÷, × */}
          <button
            onClick={handleClear}
            className={`h-14 rounded-2xl font-semibold text-lg transition-transform active:scale-95 flex items-center justify-center bg-[#1E293B] text-rose-400 hover:bg-[#283548] border border-rose-950/30 ${
              activeKey === 'C' ? 'ring-2 ring-rose-500 scale-95' : ''
            }`}
            title="Clear all (Escape or C)"
          >
            C
          </button>
          <button
            onClick={handleBackspace}
            className={`h-14 rounded-2xl font-medium text-lg transition-transform active:scale-95 flex items-center justify-center bg-[#1E293B] text-slate-300 hover:bg-[#283548] border border-slate-800 ${
              activeKey === '⌫' ? 'ring-2 ring-indigo-500 scale-95' : ''
            }`}
            title="Backspace (Backspace)"
          >
            ⌫
          </button>
          <button
            onClick={() => handleOperator('÷')}
            className={`h-14 rounded-2xl font-medium text-xl transition-transform active:scale-95 flex items-center justify-center bg-[#312E81] text-indigo-200 hover:bg-[#3730A3] border border-indigo-700/40 ${
              activeKey === '÷' ? 'ring-2 ring-indigo-400 scale-95' : ''
            }`}
            title="Divide (/)"
          >
            ÷
          </button>
          <button
            onClick={() => handleOperator('×')}
            className={`h-14 rounded-2xl font-medium text-xl transition-transform active:scale-95 flex items-center justify-center bg-[#312E81] text-indigo-200 hover:bg-[#3730A3] border border-indigo-700/40 ${
              activeKey === '×' ? 'ring-2 ring-indigo-400 scale-95' : ''
            }`}
            title="Multiply (*)"
          >
            ×
          </button>

          {/* Row 2: 7, 8, 9, − */}
          <button
            onClick={() => handleNumber('7')}
            className={`h-14 rounded-2xl font-medium text-xl transition-transform active:scale-95 flex items-center justify-center bg-[#182234] text-slate-100 hover:bg-[#223046] border border-slate-800/80 ${
              activeKey === '7' ? 'ring-2 ring-purple-500 scale-95' : ''
            }`}
          >
            7
          </button>
          <button
            onClick={() => handleNumber('8')}
            className={`h-14 rounded-2xl font-medium text-xl transition-transform active:scale-95 flex items-center justify-center bg-[#182234] text-slate-100 hover:bg-[#223046] border border-slate-800/80 ${
              activeKey === '8' ? 'ring-2 ring-purple-500 scale-95' : ''
            }`}
          >
            8
          </button>
          <button
            onClick={() => handleNumber('9')}
            className={`h-14 rounded-2xl font-medium text-xl transition-transform active:scale-95 flex items-center justify-center bg-[#182234] text-slate-100 hover:bg-[#223046] border border-slate-800/80 ${
              activeKey === '9' ? 'ring-2 ring-purple-500 scale-95' : ''
            }`}
          >
            9
          </button>
          <button
            onClick={() => handleOperator('−')}
            className={`h-14 rounded-2xl font-medium text-2xl transition-transform active:scale-95 flex items-center justify-center bg-[#312E81] text-indigo-200 hover:bg-[#3730A3] border border-indigo-700/40 ${
              activeKey === '−' ? 'ring-2 ring-indigo-400 scale-95' : ''
            }`}
            title="Subtract (-)"
          >
            −
          </button>

          {/* Row 3: 4, 5, 6, + */}
          <button
            onClick={() => handleNumber('4')}
            className={`h-14 rounded-2xl font-medium text-xl transition-transform active:scale-95 flex items-center justify-center bg-[#182234] text-slate-100 hover:bg-[#223046] border border-slate-800/80 ${
              activeKey === '4' ? 'ring-2 ring-purple-500 scale-95' : ''
            }`}
          >
            4
          </button>
          <button
            onClick={() => handleNumber('5')}
            className={`h-14 rounded-2xl font-medium text-xl transition-transform active:scale-95 flex items-center justify-center bg-[#182234] text-slate-100 hover:bg-[#223046] border border-slate-800/80 ${
              activeKey === '5' ? 'ring-2 ring-purple-500 scale-95' : ''
            }`}
          >
            5
          </button>
          <button
            onClick={() => handleNumber('6')}
            className={`h-14 rounded-2xl font-medium text-xl transition-transform active:scale-95 flex items-center justify-center bg-[#182234] text-slate-100 hover:bg-[#223046] border border-slate-800/80 ${
              activeKey === '6' ? 'ring-2 ring-purple-500 scale-95' : ''
            }`}
          >
            6
          </button>
          <button
            onClick={() => handleOperator('+')}
            className={`h-14 rounded-2xl font-medium text-2xl transition-transform active:scale-95 flex items-center justify-center bg-[#312E81] text-indigo-200 hover:bg-[#3730A3] border border-indigo-700/40 ${
              activeKey === '+' ? 'ring-2 ring-indigo-400 scale-95' : ''
            }`}
            title="Add (+)"
          >
            +
          </button>

          {/* Row 4: 1, 2, 3, ± */}
          <button
            onClick={() => handleNumber('1')}
            className={`h-14 rounded-2xl font-medium text-xl transition-transform active:scale-95 flex items-center justify-center bg-[#182234] text-slate-100 hover:bg-[#223046] border border-slate-800/80 ${
              activeKey === '1' ? 'ring-2 ring-purple-500 scale-95' : ''
            }`}
          >
            1
          </button>
          <button
            onClick={() => handleNumber('2')}
            className={`h-14 rounded-2xl font-medium text-xl transition-transform active:scale-95 flex items-center justify-center bg-[#182234] text-slate-100 hover:bg-[#223046] border border-slate-800/80 ${
              activeKey === '2' ? 'ring-2 ring-purple-500 scale-95' : ''
            }`}
          >
            2
          </button>
          <button
            onClick={() => handleNumber('3')}
            className={`h-14 rounded-2xl font-medium text-xl transition-transform active:scale-95 flex items-center justify-center bg-[#182234] text-slate-100 hover:bg-[#223046] border border-slate-800/80 ${
              activeKey === '3' ? 'ring-2 ring-purple-500 scale-95' : ''
            }`}
          >
            3
          </button>
          <button
            onClick={handlePlusMinus}
            className={`h-14 rounded-2xl font-medium text-lg transition-transform active:scale-95 flex items-center justify-center bg-[#1E293B] text-slate-300 hover:bg-[#283548] border border-slate-800 ${
              activeKey === '±' ? 'ring-2 ring-indigo-400 scale-95' : ''
            }`}
            title="Negate (±)"
          >
            ±
          </button>

          {/* Row 5: %, 0, ., = */}
          <button
            onClick={handlePercent}
            className={`h-14 rounded-2xl font-medium text-lg transition-transform active:scale-95 flex items-center justify-center bg-[#1E293B] text-slate-300 hover:bg-[#283548] border border-slate-800 ${
              activeKey === '%' ? 'ring-2 ring-indigo-400 scale-95' : ''
            }`}
            title="Percent (%)"
          >
            %
          </button>
          <button
            onClick={() => handleNumber('0')}
            className={`h-14 rounded-2xl font-medium text-xl transition-transform active:scale-95 flex items-center justify-center bg-[#182234] text-slate-100 hover:bg-[#223046] border border-slate-800/80 ${
              activeKey === '0' ? 'ring-2 ring-purple-500 scale-95' : ''
            }`}
          >
            0
          </button>
          <button
            onClick={handleDecimal}
            className={`h-14 rounded-2xl font-bold text-2xl transition-transform active:scale-95 flex items-center justify-center bg-[#182234] text-slate-100 hover:bg-[#223046] border border-slate-800/80 ${
              activeKey === '.' ? 'ring-2 ring-purple-500 scale-95' : ''
            }`}
            title="Decimal (.)"
          >
            .
          </button>
          <button
            onClick={handleEquals}
            className={`h-14 rounded-2xl font-bold text-2xl transition-transform active:scale-95 flex items-center justify-center bg-[#7C3AED] hover:bg-[#6D28D9] text-white shadow-lg shadow-purple-900/30 border border-purple-400/30 ${
              activeKey === '=' ? 'ring-2 ring-white scale-95' : ''
            }`}
            title="Equals (= or Enter)"
          >
            =
          </button>
        </div>

        {/* Android Navigation Bar */}
        <div className="flex items-center justify-center gap-12 pt-4 pb-1 text-slate-600">
          <div className="w-4 h-4 border-2 border-slate-600 rounded-sm rotate-45"></div>
          <div className="w-3.5 h-3.5 border-2 border-slate-600 rounded-full"></div>
          <div className="w-4 h-4 border-2 border-slate-600 rounded-xs"></div>
        </div>
      </div>
    </div>
  );
};
