import React, { useState } from 'react';
import { Copy, Check, Download, FileCode, Folder, ExternalLink, Sparkles, Terminal } from 'lucide-react';
import { ANDROID_PROJECT_FILES, AndroidFile } from '../data/androidFiles';
import { downloadAndroidProjectZip } from '../utils/zipExporter';

export const CodeExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidFile>(ANDROID_PROJECT_FILES[0]);
  const [copied, setCopied] = useState<boolean>(false);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredFiles = ANDROID_PROJECT_FILES.filter(
    (file) =>
      file.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      file.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
      file.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const handleExportZip = async () => {
    try {
      setIsExporting(true);
      await downloadAndroidProjectZip();
    } finally {
      setIsExporting(false);
    }
  };

  const getCategoryBadge = (cat: AndroidFile['category']) => {
    switch (cat) {
      case 'java':
        return 'text-amber-400 bg-amber-950/60 border-amber-800/60';
      case 'xml':
      case 'res':
        return 'text-emerald-400 bg-emerald-950/60 border-emerald-800/60';
      case 'gradle':
        return 'text-blue-400 bg-blue-950/60 border-blue-800/60';
      default:
        return 'text-purple-400 bg-purple-950/60 border-purple-800/60';
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner with Project Metadata and Download CTA */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Folder className="w-5 h-5 text-purple-400" />
            <h2 className="text-base font-semibold text-slate-100">Android Studio Project Workspace</h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Package: <span className="text-purple-300 font-mono">com.calcora.calculator</span> · Target SDK 34 · Java 8
          </p>
        </div>

        <button
          onClick={handleExportZip}
          disabled={isExporting}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl text-white bg-purple-600 hover:bg-purple-500 shadow-md shadow-purple-600/25 active:scale-95 transition-all whitespace-nowrap"
        >
          <Download className="w-4 h-4" />
          <span>{isExporting ? 'Packaging ZIP...' : 'Download Android Studio (.zip)'}</span>
        </button>
      </div>

      {/* Main Split: File Explorer & Code Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden min-h-[580px]">
        {/* Left Sidebar: File Tree */}
        <div className="lg:col-span-4 border-b lg:border-b-0 lg:border-r border-slate-800 flex flex-col bg-slate-950/40">
          <div className="p-3 border-b border-slate-800">
            <input
              type="text"
              placeholder="Search files (e.g., MainActivity, colors)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-slate-900 border border-slate-800 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-1 max-h-[520px]">
            {filteredFiles.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-2.5 rounded-xl text-xs transition-colors flex items-center justify-between group ${
                    isSelected
                      ? 'bg-purple-950/70 text-purple-200 border border-purple-800/70'
                      : 'text-slate-300 hover:bg-slate-900 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0 pr-2">
                    <FileCode
                      className={`w-4 h-4 shrink-0 ${
                        isSelected ? 'text-purple-400' : 'text-slate-500 group-hover:text-slate-300'
                      }`}
                    />
                    <div className="truncate">
                      <div className="font-medium font-mono text-[11px] truncate">{file.name}</div>
                      <div className="text-[10px] text-slate-400 truncate">{file.path}</div>
                    </div>
                  </div>

                  <span
                    className={`text-[9px] uppercase px-1.5 py-0.5 rounded border shrink-0 font-mono ${getCategoryBadge(
                      file.category
                    )}`}
                  >
                    {file.category}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Code Display Area */}
        <div className="lg:col-span-8 flex flex-col bg-[#0B111E]">
          {/* File Header Bar */}
          <div className="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-semibold text-slate-200">{selectedFile.name}</span>
                <span
                  className={`text-[9px] uppercase px-1.5 py-0.5 rounded border font-mono ${getCategoryBadge(
                    selectedFile.category
                  )}`}
                >
                  {selectedFile.category}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">{selectedFile.description}</p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800 transition-colors"
                title="Copy code to clipboard"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Syntax Highlighted Code Viewer */}
          <div className="flex-1 p-4 overflow-x-auto overflow-y-auto max-h-[500px] font-mono text-xs leading-relaxed text-slate-300 select-text">
            <pre className="tab-4">
              <code>{selectedFile.content}</code>
            </pre>
          </div>

          {/* Code Footer Status */}
          <div className="px-4 py-2 border-t border-slate-800 bg-slate-950/50 flex items-center justify-between text-[11px] text-slate-400 font-mono">
            <span>{selectedFile.path}</span>
            <span>{selectedFile.content.split('\n').length} lines · UTF-8</span>
          </div>
        </div>
      </div>
    </div>
  );
};
