import React from 'react';
import { Award, CheckCircle, Code, Smartphone, Layers, ShieldCheck, Terminal, BookOpen } from 'lucide-react';

export const InternshipReport: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Header Profile Card */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-purple-950/50 via-slate-900 to-indigo-950/40 border border-purple-800/40">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-purple-400" />
              <span className="text-xs uppercase font-semibold tracking-wider text-purple-300">
                Oasis Infobyte Internship Project Report
              </span>
            </div>
            <h1 className="text-2xl font-bold text-white mt-1">Calcora — Android Calculator Application</h1>
            <p className="text-sm text-slate-300 mt-1">
              Developed by <strong className="text-purple-200">Neha Vinod Borkar</strong> for the Android App Development Track (Task 3).
            </p>
          </div>

          <div className="flex flex-wrap gap-2 text-xs">
            <div className="px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-700 text-slate-200">
              <span className="text-slate-400">Track:</span> Android Dev
            </div>
            <div className="px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-700 text-slate-200">
              <span className="text-slate-400">Task:</span> 3 — Calculator
            </div>
            <div className="px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-700 text-slate-200">
              <span className="text-slate-400">Language:</span> Java & XML
            </div>
          </div>
        </div>
      </div>

      {/* Architecture Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="flex items-center gap-2 text-purple-400 font-semibold text-sm">
            <Code className="w-4 h-4" /> Safe Java Evaluator
          </div>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            Direct two-pass parser tokenizing numbers and respecting arithmetic precedence (multiplication/division before addition/subtraction). Zero dependence on JavaScript or insecure eval().
          </p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="flex items-center gap-2 text-indigo-400 font-semibold text-sm">
            <Layers className="w-4 h-4" /> Native XML & Constraints
          </div>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            Constructed with responsive Android ConstraintLayout and GridLayout. Custom rounded ripple drawables and high-contrast navy/purple palette for optimal legibility.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
            <ShieldCheck className="w-4 h-4" /> Error Immunity
          </div>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            Zero crashes on division by zero (5 ÷ 0 explicitly yields "Error"). Rejects multiple decimal points (e.g. 1..2), prevents malformed operator chains, and handles unary minus cleanly.
          </p>
        </div>
      </div>

      {/* Detailed Technical Specifications Table */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-purple-400" /> Technical Implementation Summary
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-medium">
                <th className="py-2.5 px-3">Requirement</th>
                <th className="py-2.5 px-3">Android Component / Class</th>
                <th className="py-2.5 px-3">Solution Strategy</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-200">Primary Display</td>
                <td className="py-2.5 px-3 font-mono text-purple-300">tvResult (TextView)</td>
                <td className="py-2.5 px-3">HorizontalScrollView wrapper with dynamic font-size scaling</td>
                <td className="py-2.5 px-3 text-emerald-400 font-semibold">Implemented</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-200">Expression History</td>
                <td className="py-2.5 px-3 font-mono text-purple-300">tvExpression (TextView)</td>
                <td className="py-2.5 px-3">Displays continuous formula and previous calculation trail</td>
                <td className="py-2.5 px-3 text-emerald-400 font-semibold">Implemented</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-200">Precedence Engine</td>
                <td className="py-2.5 px-3 font-mono text-purple-300">ExpressionEvaluator.java</td>
                <td className="py-2.5 px-3">Two-pass token evaluator evaluating ×/÷ prior to +/−</td>
                <td className="py-2.5 px-3 text-emerald-400 font-semibold">Implemented</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-200">Zero Division</td>
                <td className="py-2.5 px-3 font-mono text-purple-300">ArithmeticException</td>
                <td className="py-2.5 px-3">Strict detection (Math.abs(denominator) &lt; 1e-12) displaying "Error"</td>
                <td className="py-2.5 px-3 text-emerald-400 font-semibold">Implemented</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-200">Decimal Integrity</td>
                <td className="py-2.5 px-3 font-mono text-purple-300">canAddDecimal()</td>
                <td className="py-2.5 px-3">Inspects current numeric token to prevent duplicate decimal insertion</td>
                <td className="py-2.5 px-3 text-emerald-400 font-semibold">Implemented</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-200">Negative Numbers</td>
                <td className="py-2.5 px-3 font-mono text-purple-300">Unary minus parser</td>
                <td className="py-2.5 px-3">Supports leading minus (−5+2) and operator minus (6×−2)</td>
                <td className="py-2.5 px-3 text-emerald-400 font-semibold">Implemented</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-slate-200">Haptic Feedback</td>
                <td className="py-2.5 px-3 font-mono text-purple-300">Vibrator Service</td>
                <td className="py-2.5 px-3">12ms vibration pulse on touch matching Android keyboard tap</td>
                <td className="py-2.5 px-3 text-emerald-400 font-semibold">Implemented</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Guide for Evaluator */}
      <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
        <h2 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
          <Terminal className="w-4 h-4 text-purple-400" /> Instructions for Evaluator / Running in Android Studio
        </h2>
        <ol className="list-decimal list-inside space-y-2 text-xs text-slate-300">
          <li>
            Click the <strong className="text-purple-300">Download Android Studio (.zip)</strong> button in the top navigation bar to receive the complete project folder.
          </li>
          <li>
            Extract the archive and open Android Studio (Ladybug, Iguana, Hedgehog, or newer).
          </li>
          <li>
            Select <strong>Open an Existing Project</strong> and point to the unzipped <code className="text-purple-300 font-mono">Calcora</code> directory.
          </li>
          <li>
            Wait for Gradle Sync to complete (Gradle 8.2 with Android Gradle Plugin).
          </li>
          <li>
            Run on an Android Emulator or physical device (Min SDK 21, Target SDK 34).
          </li>
          <li>
            Alternatively, use the interactive live simulator and test runner built right into this dashboard to test every single calculation instantly.
          </li>
        </ol>
      </div>
    </div>
  );
};
