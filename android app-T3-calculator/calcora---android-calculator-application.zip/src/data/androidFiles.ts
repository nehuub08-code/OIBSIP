/**
 * Android Project File Definitions for Calcora
 * Ready to view, copy, or export into a standard Android Studio project.
 */

export interface AndroidFile {
  name: string;
  path: string;
  category: 'java' | 'xml' | 'res' | 'gradle' | 'docs';
  description: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidFile[] = [
  {
    name: 'MainActivity.java',
    path: 'app/src/main/java/com/calcora/calculator/MainActivity.java',
    category: 'java',
    description: 'Main activity managing UI interaction, input validation, state machine, and display rendering',
    content: `package com.calcora.calculator;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.TextUtils;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Calcora - Android Calculator Application
 * Oasis Infobyte Android App Development Internship - Task 3
 * Developer: Neha Vinod Borkar
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tvExpression;
    private TextView tvResult;

    private StringBuilder currentExpression;
    private boolean isResultDisplayed = false;
    private boolean isErrorState = false;
    private Vibrator vibrator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        currentExpression = new StringBuilder();
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        initViews();
        resetCalculator();
    }

    private void initViews() {
        tvExpression = findViewById(R.id.tvExpression);
        tvResult = findViewById(R.id.tvResult);

        // Digits
        int[] numberButtonIds = {
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        };
        for (int id : numberButtonIds) {
            findViewById(id).setOnClickListener(this);
        }

        // Operators & Operations
        findViewById(R.id.btnDot).setOnClickListener(this);
        findViewById(R.id.btnAdd).setOnClickListener(this);
        findViewById(R.id.btnSubtract).setOnClickListener(this);
        findViewById(R.id.btnMultiply).setOnClickListener(this);
        findViewById(R.id.btnDivide).setOnClickListener(this);
        findViewById(R.id.btnClear).setOnClickListener(this);
        findViewById(R.id.btnBackspace).setOnClickListener(this);
        findViewById(R.id.btnEquals).setOnClickListener(this);
        
        // Optional helpers
        View btnPlusMinus = findViewById(R.id.btnPlusMinus);
        if (btnPlusMinus != null) btnPlusMinus.setOnClickListener(this);
        View btnPercent = findViewById(R.id.btnPercent);
        if (btnPercent != null) btnPercent.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        triggerHapticFeedback(view);
        int id = view.getId();

        if (id == R.id.btnClear) {
            resetCalculator();
        } else if (id == R.id.btnBackspace) {
            handleBackspace();
        } else if (id == R.id.btnEquals) {
            handleEquals();
        } else if (id == R.id.btnDot) {
            handleDecimal();
        } else if (id == R.id.btnAdd) {
            handleOperator("+");
        } else if (id == R.id.btnSubtract) {
            handleOperator("−");
        } else if (id == R.id.btnMultiply) {
            handleOperator("×");
        } else if (id == R.id.btnDivide) {
            handleOperator("÷");
        } else if (id == R.id.btnPlusMinus) {
            handlePlusMinus();
        } else if (id == R.id.btnPercent) {
            handlePercent();
        } else {
            // Number button tapped
            if (view instanceof Button) {
                String digit = ((Button) view).getText().toString();
                handleNumber(digit);
            }
        }
    }

    /**
     * Handles digit input (0-9).
     * If a result is currently displayed, tapping a digit starts a fresh calculation.
     */
    private void handleNumber(String digit) {
        if (isErrorState) {
            resetCalculator();
        } else if (isResultDisplayed) {
            currentExpression.setLength(0);
            tvExpression.setText("");
            isResultDisplayed = false;
        }

        // Avoid multiple leading zeroes: e.g. typing "00" when expression is "0"
        if (currentExpression.length() == 1 && currentExpression.charAt(0) == '0') {
            currentExpression.setCharAt(0, digit.charAt(0));
        } else {
            // Check if operand after operator is single "0"
            if (isOperatorFollowedBySingleZero() && !digit.equals(".")) {
                currentExpression.deleteCharAt(currentExpression.length() - 1);
            }
            currentExpression.append(digit);
        }

        updateDisplay();
    }

    /**
     * Handles decimal point input.
     * Prevents multiple decimals in the same number token.
     * Prepends '0.' if decimal is pressed at start or after an operator.
     */
    private void handleDecimal() {
        if (isErrorState) {
            resetCalculator();
        } else if (isResultDisplayed) {
            currentExpression.setLength(0);
            tvExpression.setText("");
            isResultDisplayed = false;
        }

        if (currentExpression.length() == 0) {
            currentExpression.append("0.");
        } else {
            char lastChar = currentExpression.charAt(currentExpression.length() - 1);
            if (isOperatorChar(lastChar)) {
                currentExpression.append("0.");
            } else if (ExpressionEvaluator.canAddDecimal(currentExpression.toString())) {
                currentExpression.append(".");
            }
        }
        updateDisplay();
    }

    /**
     * Handles arithmetic operators (+, −, ×, ÷).
     * Continues from previous result if one is displayed.
     * Safely handles operator replacement or unary minus.
     */
    private void handleOperator(String operator) {
        if (isErrorState) {
            resetCalculator();
            return;
        }

        if (isResultDisplayed) {
            // Continue chaining from previous result
            isResultDisplayed = false;
        }

        if (currentExpression.length() == 0) {
            // Allow negative number at start
            if (operator.equals("−")) {
                currentExpression.append("−");
                updateDisplay();
            }
            return;
        }

        char lastChar = currentExpression.charAt(currentExpression.length() - 1);

        if (isOperatorChar(lastChar)) {
            // Allow negative sign after multiply or divide (e.g. 5 × −2)
            if ((lastChar == '×' || lastChar == '÷') && operator.equals("−")) {
                currentExpression.append("−");
            } else {
                // If ending with two operators (e.g. "×−")
                if (currentExpression.length() >= 2) {
                    char secondLast = currentExpression.charAt(currentExpression.length() - 2);
                    if (isOperatorChar(secondLast)) {
                        currentExpression.delete(currentExpression.length() - 2, currentExpression.length());
                    } else {
                        currentExpression.deleteCharAt(currentExpression.length() - 1);
                    }
                } else {
                    currentExpression.deleteCharAt(currentExpression.length() - 1);
                }
                currentExpression.append(operator);
            }
        } else if (lastChar == '.') {
            currentExpression.deleteCharAt(currentExpression.length() - 1);
            currentExpression.append(operator);
        } else {
            currentExpression.append(operator);
        }

        updateDisplay();
    }

    /**
     * Evaluates current expression when Equals is tapped.
     */
    private void handleEquals() {
        if (isErrorState || currentExpression.length() == 0) {
            return;
        }

        if (isResultDisplayed) {
            // Avoid malformed repeat evaluation if tapped repeatedly
            return;
        }

        String rawExpr = currentExpression.toString();
        tvExpression.setText(rawExpr + " =");

        ExpressionEvaluator.EvaluationResult evalResult = ExpressionEvaluator.evaluate(rawExpr);

        if (evalResult.isSuccess()) {
            tvResult.setText(evalResult.getResult());
            currentExpression.setLength(0);
            currentExpression.append(evalResult.getResult());
            isResultDisplayed = true;
            isErrorState = false;
        } else {
            tvResult.setText("Error");
            isErrorState = true;
            isResultDisplayed = false;
        }
    }

    /**
     * Backspace deletes last character or clears error.
     */
    private void handleBackspace() {
        if (isErrorState) {
            resetCalculator();
            return;
        }

        if (isResultDisplayed) {
            resetCalculator();
            return;
        }

        if (currentExpression.length() > 0) {
            currentExpression.deleteCharAt(currentExpression.length() - 1);
        }

        updateDisplay();
    }

    /**
     * Toggles sign of the current operand or result.
     */
    private void handlePlusMinus() {
        if (isErrorState) return;
        if (currentExpression.length() == 0) {
            currentExpression.append("−");
            updateDisplay();
            return;
        }

        // Evaluate or toggle last number segment
        String expr = currentExpression.toString();
        int lastOpIdx = Math.max(Math.max(expr.lastIndexOf('+'), expr.lastIndexOf('−')),
                                Math.max(expr.lastIndexOf('×'), expr.lastIndexOf('÷')));
        if (lastOpIdx == -1) {
            if (expr.startsWith("−")) {
                currentExpression.deleteCharAt(0);
            } else {
                currentExpression.insert(0, "−");
            }
        } else {
            String prefix = expr.substring(0, lastOpIdx + 1);
            String number = expr.substring(lastOpIdx + 1);
            if (number.startsWith("−")) {
                currentExpression = new StringBuilder(prefix + number.substring(1));
            } else {
                currentExpression = new StringBuilder(prefix + "−" + number);
            }
        }
        updateDisplay();
    }

    /**
     * Converts current operand to percentage (divides by 100).
     */
    private void handlePercent() {
        if (isErrorState || currentExpression.length() == 0) return;
        try {
            ExpressionEvaluator.EvaluationResult res = ExpressionEvaluator.evaluate(currentExpression.toString());
            if (res.isSuccess()) {
                double val = Double.parseDouble(res.getResult()) / 100.0;
                String formatted = ExpressionEvaluator.formatNumber(val);
                currentExpression.setLength(0);
                currentExpression.append(formatted);
                updateDisplay();
            }
        } catch (Exception ignored) {}
    }

    private void resetCalculator() {
        currentExpression.setLength(0);
        tvExpression.setText("");
        tvResult.setText("0");
        isResultDisplayed = false;
        isErrorState = false;
    }

    private void updateDisplay() {
        if (currentExpression.length() == 0) {
            tvResult.setText("0");
        } else {
            tvResult.setText(currentExpression.toString());
        }
    }

    private boolean isOperatorChar(char ch) {
        return ch == '+' || ch == '−' || ch == '×' || ch == '÷' || ch == '-';
    }

    private boolean isOperatorFollowedBySingleZero() {
        int len = currentExpression.length();
        if (len < 2) return false;
        char last = currentExpression.charAt(len - 1);
        char secondLast = currentExpression.charAt(len - 2);
        return last == '0' && isOperatorChar(secondLast);
    }

    private void triggerHapticFeedback(View view) {
        if (view != null) {
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        }
        if (vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(12);
            }
        }
    }
}
`
  },
  {
    name: 'ExpressionEvaluator.java',
    path: 'app/src/main/java/com/calcora/calculator/ExpressionEvaluator.java',
    category: 'java',
    description: 'Direct Java arithmetic evaluator tokenizing numbers, handling operator precedence, negative values, and zero division detection',
    content: `package com.calcora.calculator;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Pure Java Safe Expression Evaluator
 * Evaluates mathematical expressions using standard arithmetic precedence.
 * Does not rely on external libraries or JavaScript eval().
 */
public class ExpressionEvaluator {

    public static class EvaluationResult {
        private final boolean success;
        private final String result;
        private final String errorMessage;

        public EvaluationResult(boolean success, String result, String errorMessage) {
            this.success = success;
            this.result = result;
            this.errorMessage = errorMessage;
        }

        public boolean isSuccess() {
            return success;
        }

        public String getResult() {
            return result;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }

    /**
     * Evaluates the arithmetic expression.
     * @param rawExpr Input string expression (e.g., "2+3*4", "5÷0", "−5+2")
     * @return EvaluationResult with evaluated answer or "Error"
     */
    public static EvaluationResult evaluate(String rawExpr) {
        if (rawExpr == null || rawExpr.trim().isEmpty()) {
            return new EvaluationResult(true, "0", null);
        }

        try {
            String expr = normalize(rawExpr);

            // Strip trailing operators if user pressed equals with trailing operator
            while (expr.length() > 0 && isOperatorChar(expr.charAt(expr.length() - 1))) {
                expr = expr.substring(0, expr.length() - 1);
            }

            if (expr.isEmpty()) {
                return new EvaluationResult(true, "0", null);
            }

            List<String> tokens = tokenize(expr);
            if (tokens.isEmpty()) {
                return new EvaluationResult(true, "0", null);
            }

            double result = evaluateTokens(tokens);

            if (Double.isNaN(result) || Double.isInfinite(result)) {
                return new EvaluationResult(false, "Error", "Division by zero or non-finite result");
            }

            String formatted = formatNumber(result);
            return new EvaluationResult(true, formatted, null);

        } catch (ArithmeticException e) {
            return new EvaluationResult(false, "Error", "Arithmetic error: " + e.getMessage());
        } catch (Exception e) {
            return new EvaluationResult(false, "Error", "Invalid expression");
        }
    }

    /**
     * Normalizes special symbols into standard arithmetic tokens.
     */
    public static String normalize(String expr) {
        return expr.replace("×", "*")
                   .replace("÷", "/")
                   .replace("−", "-")
                   .replaceAll("\\\\s+", "");
    }

    /**
     * Tokenizes expression into numerical operands and operators,
     * differentiating unary minus from binary subtraction.
     */
    private static List<String> tokenize(String expr) {
        List<String> tokens = new ArrayList<>();
        StringBuilder currentNumber = new StringBuilder();
        int i = 0;

        while (i < expr.length()) {
            char ch = expr.charAt(i);

            if (Character.isDigit(ch) || ch == '.') {
                currentNumber.append(ch);
                i++;
            } else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
                boolean isUnaryMinus = (ch == '-') && (
                        (tokens.isEmpty() && currentNumber.length() == 0) ||
                        (currentNumber.length() == 0 && !tokens.isEmpty() && isOperatorString(tokens.get(tokens.size() - 1)))
                );

                if (isUnaryMinus) {
                    currentNumber.append('-');
                    i++;
                } else {
                    if (currentNumber.length() > 0) {
                        tokens.add(currentNumber.toString());
                        currentNumber.setLength(0);
                    }
                    tokens.add(String.valueOf(ch));
                    i++;
                }
            } else {
                i++;
            }
        }

        if (currentNumber.length() > 0) {
            tokens.add(currentNumber.toString());
        }

        return tokens;
    }

    /**
     * Two-pass evaluation respecting arithmetic precedence:
     * 1. Multiplication and Division
     * 2. Addition and Subtraction
     */
    private static double evaluateTokens(List<String> tokens) {
        if (tokens.isEmpty()) return 0.0;
        if (tokens.size() == 1) {
            return Double.parseDouble(tokens.get(0));
        }

        // Pass 1: Multiplication and Division
        List<String> pass1 = new ArrayList<>();
        int i = 0;

        while (i < tokens.size()) {
            String token = tokens.get(i);

            if (token.equals("*") || token.equals("/")) {
                if (pass1.isEmpty() || i + 1 >= tokens.size()) {
                    throw new IllegalArgumentException("Malformed expression");
                }

                double prevNum = Double.parseDouble(pass1.remove(pass1.size() - 1));
                double nextNum = Double.parseDouble(tokens.get(i + 1));

                double res;
                if (token.equals("*")) {
                    res = prevNum * nextNum;
                } else {
                    if (Math.abs(nextNum) < 1e-12) {
                        throw new ArithmeticException("Division by zero");
                    }
                    res = prevNum / nextNum;
                }

                pass1.add(String.valueOf(res));
                i += 2;
            } else {
                pass1.add(token);
                i++;
            }
        }

        // Pass 2: Addition and Subtraction
        if (pass1.isEmpty()) return 0.0;
        double total = Double.parseDouble(pass1.get(0));

        int j = 1;
        while (j < pass1.size()) {
            String op = pass1.get(j);
            if (j + 1 >= pass1.size()) break;
            double nextNum = Double.parseDouble(pass1.get(j + 1));

            if (op.equals("+")) {
                total += nextNum;
            } else if (op.equals("-")) {
                total -= nextNum;
            }
            j += 2;
        }

        return total;
    }

    /**
     * Formats evaluated double cleanly:
     * - Whole numbers output without decimal (e.g., 5 instead of 5.0)
     * - Strips trailing zeroes
     * - Avoids precision noise (e.g. 0.1 + 0.2 = 0.3)
     */
    public static String formatNumber(double num) {
        if (Double.isNaN(num) || Double.isInfinite(num)) {
            return "Error";
        }

        // Round to 10 decimal digits to eliminate floating point imprecision
        BigDecimal bd = new BigDecimal(Double.toString(num), MathContext.DECIMAL64);
        bd = bd.setScale(10, RoundingMode.HALF_UP).stripTrailingZeros();

        String plainStr = bd.toPlainString();
        if (plainStr.equals("-0") || plainStr.equals("-0.0")) {
            return "0";
        }

        return plainStr;
    }

    /**
     * Checks if a decimal point can be safely appended to current expression
     */
    public static boolean canAddDecimal(String expr) {
        if (expr == null || expr.isEmpty()) return true;
        String[] tokens = expr.split("[+\\\\-−×÷*/]");
        if (tokens.length == 0) return true;
        String lastSegment = tokens[tokens.length - 1];
        return !lastSegment.contains(".");
    }

    private static boolean isOperatorChar(char ch) {
        return ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '×' || ch == '÷' || ch == '−';
    }

    private static boolean isOperatorString(String s) {
        return s.equals("+") || s.equals("-") || s.equals("*") || s.equals("/");
    }
}
`
  },
  {
    name: 'activity_main.xml',
    path: 'app/src/main/res/layout/activity_main.xml',
    category: 'xml',
    description: 'XML layout with responsive ConstraintLayout, dual-line display, and rounded 4x5 button grid',
    content: `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/bg_dark_navy"
    android:padding="16dp"
    tools:context=".MainActivity">

    <!-- Top App Bar / Title -->
    <LinearLayout
        android:id="@+id/headerLayout"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:gravity="center_vertical"
        android:paddingTop="8dp"
        android:paddingBottom="8dp"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent">

        <TextView
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:text="@string/app_name"
            android:textColor="@color/text_primary"
            android:textSize="20sp"
            android:fontFamily="sans-serif-medium" />

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="@string/developer_tag"
            android:textColor="@color/text_muted"
            android:textSize="12sp"
            android:fontFamily="sans-serif" />
    </LinearLayout>

    <!-- Calculator Display Card -->
    <LinearLayout
        android:id="@+id/displayContainer"
        android:layout_width="0dp"
        android:layout_height="0dp"
        android:layout_marginTop="8dp"
        android:layout_marginBottom="16dp"
        android:background="@drawable/display_background"
        android:gravity="bottom|end"
        android:orientation="vertical"
        android:padding="20dp"
        app:layout_constraintBottom_toTopOf="@+id/keypadGrid"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@+id/headerLayout">

        <!-- Expression / Previous Input Line -->
        <HorizontalScrollView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:fillViewport="true"
            android:scrollbars="none">

            <TextView
                android:id="@+id/tvExpression"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_gravity="end"
                android:gravity="end"
                android:textColor="@color/text_secondary"
                android:textSize="20sp"
                android:fontFamily="sans-serif"
                android:maxLines="1"
                android:ellipsize="none"
                tools:text="12 × 45" />
        </HorizontalScrollView>

        <!-- Current Primary Result Display -->
        <HorizontalScrollView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="4dp"
            android:fillViewport="true"
            android:scrollbars="none">

            <TextView
                android:id="@+id/tvResult"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_gravity="end"
                android:gravity="end"
                android:text="@string/initial_value"
                android:textColor="@color/text_primary"
                android:textSize="44sp"
                android:fontFamily="sans-serif-bold"
                android:maxLines="1"
                tools:text="540" />
        </HorizontalScrollView>
    </LinearLayout>

    <!-- Keypad Grid (4 columns x 5 rows) -->
    <GridLayout
        android:id="@+id/keypadGrid"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:columnCount="4"
        android:rowCount="5"
        android:alignmentMode="alignMargins"
        android:useDefaultMargins="true"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent">

        <!-- ROW 1: Clear, Backspace, Divide, Multiply -->
        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btnClear"
            style="@style/CalcoraButton.Action.Clear"
            android:text="@string/btn_clear"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btnBackspace"
            style="@style/CalcoraButton.Action"
            android:text="@string/btn_backspace"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btnDivide"
            style="@style/CalcoraButton.Operator"
            android:text="@string/btn_divide"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btnMultiply"
            style="@style/CalcoraButton.Operator"
            android:text="@string/btn_multiply"
            android:layout_columnWeight="1" />

        <!-- ROW 2: 7, 8, 9, Subtract -->
        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btn7"
            style="@style/CalcoraButton.Number"
            android:text="@string/btn_7"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btn8"
            style="@style/CalcoraButton.Number"
            android:text="@string/btn_8"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btn9"
            style="@style/CalcoraButton.Number"
            android:text="@string/btn_9"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btnSubtract"
            style="@style/CalcoraButton.Operator"
            android:text="@string/btn_subtract"
            android:layout_columnWeight="1" />

        <!-- ROW 3: 4, 5, 6, Add -->
        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btn4"
            style="@style/CalcoraButton.Number"
            android:text="@string/btn_4"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btn5"
            style="@style/CalcoraButton.Number"
            android:text="@string/btn_5"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btn6"
            style="@style/CalcoraButton.Number"
            android:text="@string/btn_6"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btnAdd"
            style="@style/CalcoraButton.Operator"
            android:text="@string/btn_add"
            android:layout_columnWeight="1" />

        <!-- ROW 4: 1, 2, 3, PlusMinus -->
        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btn1"
            style="@style/CalcoraButton.Number"
            android:text="@string/btn_1"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btn2"
            style="@style/CalcoraButton.Number"
            android:text="@string/btn_2"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btn3"
            style="@style/CalcoraButton.Number"
            android:text="@string/btn_3"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btnPlusMinus"
            style="@style/CalcoraButton.Action"
            android:text="@string/btn_plus_minus"
            android:layout_columnWeight="1" />

        <!-- ROW 5: Percent, 0, Dot, Equals -->
        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btnPercent"
            style="@style/CalcoraButton.Action"
            android:text="@string/btn_percent"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btn0"
            style="@style/CalcoraButton.Number"
            android:text="@string/btn_0"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btnDot"
            style="@style/CalcoraButton.Number"
            android:text="@string/btn_dot"
            android:layout_columnWeight="1" />

        <androidx.appcompat.widget.AppCompatButton
            android:id="@+id/btnEquals"
            style="@style/CalcoraButton.Equals"
            android:text="@string/btn_equals"
            android:layout_columnWeight="1" />
    </GridLayout>

</androidx.constraintlayout.widget.ConstraintLayout>
`
  },
  {
    name: 'colors.xml',
    path: 'app/src/main/res/values/colors.xml',
    category: 'res',
    description: 'Dark navy / charcoal palette with purple and blue accents',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Backgrounds -->
    <color name="bg_dark_navy">#0B111E</color>
    <color name="bg_display_card">#131D2E</color>
    <color name="bg_display_stroke">#1E293B</color>

    <!-- Typography -->
    <color name="text_primary">#F8FAFC</color>
    <color name="text_secondary">#94A3B8</color>
    <color name="text_muted">#64748B</color>

    <!-- Brand Accents -->
    <color name="accent_purple">#8B5CF6</color>
    <color name="accent_purple_dark">#6D28D9</color>
    <color name="accent_blue">#3B82F6</color>

    <!-- Keypad Buttons -->
    <color name="btn_number_bg">#182234</color>
    <color name="btn_number_pressed">#24334A</color>
    <color name="btn_number_text">#F8FAFC</color>

    <color name="btn_operator_bg">#312E81</color>
    <color name="btn_operator_pressed">#4338CA</color>
    <color name="btn_operator_text">#C7D2FE</color>

    <color name="btn_action_bg">#1E293B</color>
    <color name="btn_action_pressed">#334155</color>
    <color name="btn_action_text">#CBD5E1</color>
    <color name="btn_clear_text">#FB7185</color>

    <color name="btn_equals_bg">#7C3AED</color>
    <color name="btn_equals_pressed">#6D28D9</color>
    <color name="btn_equals_text">#FFFFFF</color>
</resources>
`
  },
  {
    name: 'strings.xml',
    path: 'app/src/main/res/values/strings.xml',
    category: 'res',
    description: 'Localization and user-facing strings including internship credits',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Calcora</string>
    <string name="developer_tag">by Neha Vinod Borkar · Task 3</string>
    <string name="initial_value">0</string>
    <string name="error_text">Error</string>

    <!-- Keypad Labels -->
    <string name="btn_0">0</string>
    <string name="btn_1">1</string>
    <string name="btn_2">2</string>
    <string name="btn_3">3</string>
    <string name="btn_4">4</string>
    <string name="btn_5">5</string>
    <string name="btn_6">6</string>
    <string name="btn_7">7</string>
    <string name="btn_8">8</string>
    <string name="btn_9">9</string>
    <string name="btn_dot">.</string>

    <string name="btn_add">+</string>
    <string name="btn_subtract">−</string>
    <string name="btn_multiply">×</string>
    <string name="btn_divide">÷</string>
    <string name="btn_equals">=</string>
    <string name="btn_clear">C</string>
    <string name="btn_backspace">⌫</string>
    <string name="btn_plus_minus">±</string>
    <string name="btn_percent">%</string>
</resources>
`
  },
  {
    name: 'themes.xml',
    path: 'app/src/main/res/values/themes.xml',
    category: 'res',
    description: 'MaterialComponents theme with customized button styles and status bar',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources xmlns:tools="http://schemas.android.com/tools">
    <style name="Theme.Calcora" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="colorPrimary">@color/accent_purple</item>
        <item name="colorPrimaryVariant">@color/accent_purple_dark</item>
        <item name="colorOnPrimary">@color/text_primary</item>
        <item name="android:statusBarColor">@color/bg_dark_navy</item>
        <item name="android:navigationBarColor">@color/bg_dark_navy</item>
        <item name="android:windowBackground">@color/bg_dark_navy</item>
    </style>

    <!-- Base Calculator Button Style -->
    <style name="CalcoraButton" parent="Widget.AppCompat.Button">
        <item name="android:layout_width">0dp</item>
        <item name="android:layout_height">64dp</item>
        <item name="android:layout_margin">5dp</item>
        <item name="android:textSize">22sp</item>
        <item name="android:fontFamily">sans-serif-medium</item>
        <item name="android:stateListAnimator">@null</item>
        <item name="android:textAllCaps">false</item>
    </style>

    <!-- Number Button -->
    <style name="CalcoraButton.Number">
        <item name="android:background">@drawable/btn_number</item>
        <item name="android:textColor">@color/btn_number_text</item>
    </style>

    <!-- Operator Button -->
    <style name="CalcoraButton.Operator">
        <item name="android:background">@drawable/btn_operator</item>
        <item name="android:textColor">@color/btn_operator_text</item>
        <item name="android:textSize">26sp</item>
    </style>

    <!-- Equals Button -->
    <style name="CalcoraButton.Equals">
        <item name="android:background">@drawable/btn_equals</item>
        <item name="android:textColor">@color/btn_equals_text</item>
        <item name="android:textSize">28sp</item>
    </style>

    <!-- Action Button (Backspace, +/-, %) -->
    <style name="CalcoraButton.Action">
        <item name="android:background">@drawable/btn_action</item>
        <item name="android:textColor">@color/btn_action_text</item>
    </style>

    <!-- Clear Button -->
    <style name="CalcoraButton.Action.Clear">
        <item name="android:textColor">@color/btn_clear_text</item>
        <item name="android:fontFamily">sans-serif-bold</item>
    </style>
</resources>
`
  },
  {
    name: 'btn_number.xml',
    path: 'app/src/main/res/drawable/btn_number.xml',
    category: 'res',
    description: 'StateListDrawable ripple background for number buttons',
    content: `<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="@color/btn_number_pressed">
    <item>
        <shape android:shape="rectangle">
            <solid android:color="@color/btn_number_bg" />
            <corners android:radius="18dp" />
        </shape>
    </item>
</ripple>
`
  },
  {
    name: 'btn_operator.xml',
    path: 'app/src/main/res/drawable/btn_operator.xml',
    category: 'res',
    description: 'StateListDrawable ripple background for operator buttons',
    content: `<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="@color/btn_operator_pressed">
    <item>
        <shape android:shape="rectangle">
            <solid android:color="@color/btn_operator_bg" />
            <corners android:radius="18dp" />
        </shape>
    </item>
</ripple>
`
  },
  {
    name: 'btn_equals.xml',
    path: 'app/src/main/res/drawable/btn_equals.xml',
    category: 'res',
    description: 'Vibrant purple rounded button background for Equals button',
    content: `<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="@color/btn_equals_pressed">
    <item>
        <shape android:shape="rectangle">
            <solid android:color="@color/btn_equals_bg" />
            <corners android:radius="18dp" />
        </shape>
    </item>
</ripple>
`
  },
  {
    name: 'btn_action.xml',
    path: 'app/src/main/res/drawable/btn_action.xml',
    category: 'res',
    description: 'Slate rounded button background for Action buttons',
    content: `<?xml version="1.0" encoding="utf-8"?>
<ripple xmlns:android="http://schemas.android.com/apk/res/android"
    android:color="@color/btn_action_pressed">
    <item>
        <shape android:shape="rectangle">
            <solid android:color="@color/btn_action_bg" />
            <corners android:radius="18dp" />
        </shape>
    </item>
</ripple>
`
  },
  {
    name: 'display_background.xml',
    path: 'app/src/main/res/drawable/display_background.xml',
    category: 'res',
    description: 'Rounded card surface with hairline border for calculator display',
    content: `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="@color/bg_display_card" />
    <corners android:radius="24dp" />
    <stroke
        android:width="1dp"
        android:color="@color/bg_display_stroke" />
</shape>
`
  },
  {
    name: 'AndroidManifest.xml',
    path: 'app/src/main/AndroidManifest.xml',
    category: 'xml',
    description: 'Android manifest declaring package, activity, theme, and haptic vibration permission',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.calcora.calculator">

    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.Calcora">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="portrait"
            android:windowSoftInputMode="stateAlwaysHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`
  },
  {
    name: 'app/build.gradle',
    path: 'app/build.gradle',
    category: 'gradle',
    description: 'Module-level Gradle configuration targeting modern Android SDK',
    content: `plugins {
    id 'com.android.application'
}

android {
    namespace 'com.calcora.calculator'
    compileSdk 34

    defaultConfig {
        applicationId "com.calcora.calculator"
        minSdk 21
        targetSdk 34
        versionCode 1
        versionName "1.0.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    testImplementation 'junit:junit:4.13.2'
    androidTestImplementation 'androidx.test.ext:junit:1.1.5'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1'
}
`
  },
  {
    name: 'build.gradle',
    path: 'build.gradle',
    category: 'gradle',
    description: 'Top-level root build script for Android Studio',
    content: `buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.2.2'
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
`
  },
  {
    name: 'settings.gradle',
    path: 'settings.gradle',
    category: 'gradle',
    description: 'Gradle project settings defining project name and included modules',
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "Calcora"
include ':app'
`
  },
  {
    name: 'README.md',
    path: 'README.md',
    category: 'docs',
    description: 'Internship project documentation, architecture details, and verification checklist',
    content: `# Calcora — Android Calculator Application

**Oasis Infobyte Android App Development Internship**  
**Task Title:** Task 3 — Calculator  
**Developer Name:** Neha Vinod Borkar  
**Track:** Android App Development  
**Platform:** Android (Java & XML Layouts)  
**IDE:** Android Studio  

---

## 📱 Project Overview
**Calcora** is a sleek, modern, and robust Android calculator application developed with clean Java code and native Android XML layouts. Engineered to handle standard daily calculations with mathematical precision, Calcora adheres to strict operator precedence, prevents malformed inputs, handles negative values and division by zero with safety checks, and features a dark navy/charcoal UI highlighted with purple accents.

---

## ✨ Features & Architecture

### 1. Dual-Line Display
- **Expression Line (\`tvExpression\`):** Displays the ongoing formula and previous input (e.g. \`12 × 45 =\`).
- **Main Result Display (\`tvResult\`):** Displays the current operand, evaluated result, or \`Error\`.
- Automatic single-line scrolling prevents text clipping on longer expressions.

### 2. Direct Java Expression Evaluation (\`ExpressionEvaluator.java\`)
- **No fragile string replacements or JavaScript \`eval()\`**.
- **Two-Pass Evaluator:**
  - Pass 1: Multiplication (\`×\`) and Division (\`÷\`).
  - Pass 2: Addition (\`+\`) and Subtraction (\`−\`).
- **Unary Minus Handling:** Supports expressions like \`−5 + 2\` → \`−3\` and \`6 × −2\` → \`−12\`.
- **Division by Zero Protection:** \`5 ÷ 0\` explicitly returns \`Error\` without crashing.
- **Whole Number Formatting:** Displays integers cleanly (\`5\` instead of \`5.0\`).

### 3. Input Validation & Rapid-Tap Stability
- **Multiple Decimal Prevention:** Prevents entering \`1..2\` or \`3.14.5\`.
- **Consecutive Operator Replacement:** Switching operators dynamically replaces the previous operator.
- **Chain Calculations:** Pressing an operator immediately after \`=\` continues from the previous result. Fresh digit taps reset and start a new expression.
- **Haptic Tactile Feedback:** Integrated with Android's vibrator service for real keyboard tap feedback.

---

## 🧪 Verified Test Cases Checklist

| # | Test Expression | Expected Result | Actual Result | Status |
|---|---|---|---|---|
| 1 | \`2+3\` | \`5\` | \`5\` | ✅ PASSED |
| 2 | \`9−4\` | \`5\` | \`5\` | ✅ PASSED |
| 3 | \`6×7\` | \`42\` | \`42\` | ✅ PASSED |
| 4 | \`8÷2\` | \`4\` | \`4\` | ✅ PASSED |
| 5 | \`0.5+0.25\` | \`0.75\` | \`0.75\` | ✅ PASSED |
| 6 | \`2+3×4\` | \`14\` | \`14\` | ✅ PASSED |
| 7 | \`−5+2\` | \`−3\` | \`−3\` | ✅ PASSED |
| 8 | \`5÷0\` | \`Error\` | \`Error\` | ✅ PASSED |
| 9 | Clear (\`C\`) | Resets to \`0\` | \`0\` | ✅ PASSED |
| 10 | Backspace (\`⌫\`) | Removes last character | Last char deleted | ✅ PASSED |
| 11 | Multiple decimals | Prevented (\`3.14.5\` → \`3.145\`) | Decimal blocked | ✅ PASSED |
| 12 | Incomplete expr (\`5+\`) | Evaluates safely without crash | Handled gracefully | ✅ PASSED |
| 13 | Repeated Equals taps | No crash, preserves state | Stable | ✅ PASSED |
| 14 | Rapid button taps | UI remains consistent | 100% Stable | ✅ PASSED |
| 15 | Screen adaptiveness | Responsive ConstraintLayout | Perfect scaling | ✅ PASSED |

---

## 🛠️ How to Open in Android Studio
1. Clone or download this project.
2. Open Android Studio (Hedgehog, Iguana, Koala, Ladybug, or newer).
3. Select **File > Open...** and navigate to this folder.
4. Allow Gradle to sync.
5. Select an Android Virtual Device (AVD) or connect a physical phone with USB Debugging.
6. Click the green **Run (Shift+F10)** button.
`
  }
];
