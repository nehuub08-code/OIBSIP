import React, { useState, useRef } from 'react';
import { Download, Sparkles, Smartphone, ShieldCheck, Code, BookOpen, CheckCircle, ExternalLink } from 'lucide-react';
import { AndroidDevice } from './components/AndroidDevice';
import { TestRunner } from './components/TestRunner';
import { CodeExplorer } from './components/CodeExplorer';
import { InternshipReport } from './components/InternshipReport';
import { downloadAndroidProjectZip } from './utils/zipExporter';

type ActiveTab = 'simulator' | 'tests' | 'code' | 'report';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('simulator');
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [lastCalculation, setLastCalculation] = useState<{ expr: string; res: string } | null>(null);

  const deviceRef = useRef<{
    tapButton: (label: string) => void;
    reset: () => void;
    getState: () => { expression: string; result: string; isError: boolean };
  } | null>(null);

  const handleSimulateSequence = async (sequence: string[]) => {
    if (!deviceRef.current) return;
    deviceRef.current.reset();
    for (const key of sequence) {
      await new Promise((r) => setTimeout(r, 90));
      deviceRef.current.tapButton(key);
    }
  };

  const handleDownload = async () => {
    try {
      setIsDownloading(true);
      await downloadAndroidProjectZip();
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#070B14] text-slate-100 flex flex-col">
      {/* Top Bar Contract (3 Zones, strictly 1 row) */}
      <header className="sticky top-0 z-50 bg-[#0B111E]/90 backdrop-blur-md border-b border-slate-800/80 px-6 py-3.5 flex items-center justify-between gap-8">
        {/* Zone 1: Single text wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setActiveTab('simulator')}
            className="text-lg font-bold tracking-tight text-white hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 flex items-center gap-2"
          >
            <span className="w-7 h-7 rounded-lg bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-xs font-black shadow-sm">
              C
            </span>
            <span>Calcora</span>
          </button>
          <span className="text-xs text-slate-400 hidden sm:inline-block">· Android Studio Calculator</span>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="flex items-center gap-6 text-xs sm:text-sm font-medium text-slate-400">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
              activeTab === 'simulator'
                ? 'text-white border-b-2 border-purple-500 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            App Simulator
          </button>
          <button
            onClick={() => setActiveTab('tests')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
              activeTab === 'tests'
                ? 'text-white border-b-2 border-purple-500 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            Test Suite (15/15)
          </button>
          <button
            onClick={() => setActiveTab('code')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
              activeTab === 'code'
                ? 'text-white border-b-2 border-purple-500 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            Android Studio Code
          </button>
          <button
            onClick={() => setActiveTab('report')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
              activeTab === 'report'
                ? 'text-white border-b-2 border-purple-500 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            Internship Report
          </button>
        </nav>

        {/* Zone 3: Primary Action Button */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={handleDownload}
            disabled={isDownloading}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-500 rounded-lg shadow-sm shadow-purple-600/30 transition-all active:scale-95 whitespace-nowrap shrink-0 flex items-center gap-1.5"
            title="Download full project folder ready for Android Studio"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isDownloading ? 'Packaging...' : 'Download Project (.zip)'}</span>
            <span className="sm:hidden">.ZIP</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {/* Tab 1: Simulator */}
        {activeTab === 'simulator' && (
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
            {/* Left: Device Simulator Canvas */}
            <div className="xl:col-span-6 flex flex-col items-center justify-center p-4 rounded-3xl bg-slate-950/60 border border-slate-800/80">
              <AndroidDevice
                interactiveRef={deviceRef}
                onCalculationPerformed={(expr, res) => setLastCalculation({ expr, res })}
              />
            </div>

            {/* Right: Quick Features, Keypad Guide & Instant Test Triggers */}
            <div className="xl:col-span-6 space-y-5">
              {/* Internship Header Card */}
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
                <div className="flex items-center justify-between">
                  <div className="text-xs uppercase font-semibold text-purple-400 tracking-wider">
                    Oasis Infobyte Internship · Task 3
                  </div>
                  <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded-md">
                    Target SDK 34 · Java 8
                  </span>
                </div>
                <h2 className="text-lg font-bold text-white mt-1">Calcora Android Application</h2>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Developed by <strong className="text-slate-200">Neha Vinod Borkar</strong>. Native Android calculator with clean Java logic, XML constraint layout, zero-eval arithmetic parsing, and full division-by-zero protection.
                </p>

                {lastCalculation && (
                  <div className="mt-3 p-2.5 rounded-xl bg-purple-950/30 border border-purple-800/40 text-xs font-mono flex items-center justify-between">
                    <span className="text-slate-400">Last Evaluated:</span>
                    <span className="text-purple-300 font-bold">
                      {lastCalculation.expr} = {lastCalculation.res}
                    </span>
                  </div>
                )}
              </div>

              {/* Quick Test Bench Triggers */}
              <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-purple-400" /> Quick Math Verification Bench
                  </h3>
                  <button
                    onClick={() => setActiveTab('tests')}
                    className="text-[11px] text-purple-400 hover:text-purple-300 font-medium transition-colors"
                  >
                    View All 15 Tests →
                  </button>
                </div>
                <p className="text-[11px] text-slate-400">
                  Tap any preset below to simulate keystrokes on the Android device in real time:
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1">
                  {[
                    { label: '2 + 3 × 4', seq: ['2', '+', '3', '×', '4', '='], exp: '14 (Precedence)' },
                    { label: '5 ÷ 0', seq: ['5', '÷', '0', '='], exp: 'Error (Division by Zero)' },
                    { label: '0.5 + 0.25', seq: ['0', '.', '5', '+', '0', '.', '2', '5', '='], exp: '0.75 (Decimals)' },
                    { label: '−5 + 2', seq: ['−', '5', '+', '2', '='], exp: '−3 (Unary Minus)' },
                    { label: '6 × 7', seq: ['6', '×', '7', '='], exp: '42 (Multiplication)' },
                    { label: '8 ÷ 2', seq: ['8', '÷', '2', '='], exp: '4 (Clean Integer)' },
                  ].map((testItem, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSimulateSequence(testItem.seq)}
                      className="p-2.5 rounded-xl bg-slate-950/60 hover:bg-slate-800 border border-slate-800/80 hover:border-purple-600/50 text-left transition-colors group"
                    >
                      <div className="text-xs font-semibold font-mono text-purple-300 group-hover:text-purple-200">
                        {testItem.label}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{testItem.exp}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Physical Keyboard Shortcuts Guide */}
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 space-y-2">
                <span className="font-semibold text-slate-300 block">Keyboard Shortcuts Supported:</span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-mono">
                  <div className="bg-slate-950 p-1.5 rounded border border-slate-800">
                    <span className="text-purple-300">0 - 9</span> : Digits
                  </div>
                  <div className="bg-slate-950 p-1.5 rounded border border-slate-800">
                    <span className="text-purple-300">+ - * /</span> : Operators
                  </div>
                  <div className="bg-slate-950 p-1.5 rounded border border-slate-800">
                    <span className="text-purple-300">Enter / =</span> : Equals
                  </div>
                  <div className="bg-slate-950 p-1.5 rounded border border-slate-800">
                    <span className="text-purple-300">Esc / C</span> : Clear
                  </div>
                </div>
              </div>

              {/* View Source Code CTA */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/40 to-slate-900 border border-purple-900/40 flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-200">Android Studio Project Files Ready</div>
                  <div className="text-[11px] text-slate-400">
                    Includes MainActivity.java, ExpressionEvaluator.java, activity_main.xml, drawables & gradle.
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('code')}
                  className="px-3 py-1.5 text-xs font-medium bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 border border-purple-500/40 rounded-lg transition-colors whitespace-nowrap"
                >
                  Inspect Code →
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Test Suite */}
        {activeTab === 'tests' && (
          <TestRunner onSimulateSequence={handleSimulateSequence} />
        )}

        {/* Tab 3: Code Explorer */}
        {activeTab === 'code' && <CodeExplorer />}

        {/* Tab 4: Internship Report */}
        {activeTab === 'report' && <InternshipReport />}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-800/80 bg-[#0B111E] py-4 px-6 text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div>
          <span>Calcora · Oasis Infobyte Task 3 Calculator</span>
          <span className="mx-2">·</span>
          <span>Developer: Neha Vinod Borkar</span>
        </div>
        <div className="flex items-center gap-4 text-slate-400">
          <span>Java & XML Native Android</span>
          <span aria-hidden="true">·</span>
          <span>Target SDK 34</span>
        </div>
      </footer>
    </div>
  );
}
