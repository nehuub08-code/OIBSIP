/**
 * Safe Arithmetic Expression Evaluator for Calcora
 * Matches the logic in Android's com.calcora.calculator.ExpressionEvaluator.java
 * 
 * Features:
 * - Proper operator precedence (× and ÷ before + and −)
 * - Safe division by zero detection (returns "Error")
 * - Support for negative numbers / unary minus (e.g. "-5+2" -> "-3", "6×-2" -> "-12")
 * - Prevents multiple decimals in single numbers
 * - Clean whole-number representation (5 instead of 5.0)
 * - Trailing zero stripping
 */

export interface EvaluationResult {
  success: boolean;
  result: string;
  error?: string;
}

export class ExpressionEvaluator {
  /**
   * Normalizes expression operators: replaces standard symbols with uniform operators
   */
  public static normalize(expr: string): string {
    return expr
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/−/g, '-')
      .replace(/\s+/g, '');
  }

  /**
   * Evaluates an arithmetic expression string safely
   */
  public static evaluate(rawExpr: string): EvaluationResult {
    try {
      const expr = this.normalize(rawExpr);
      if (!expr || expr.length === 0) {
        return { success: true, result: '0' };
      }

      // Check if expression ends with an operator (e.g., "5+")
      // If it ends with an operator, strip it for soft evaluation or reject if strict
      const cleanExpr = expr.replace(/[+\-*/]+$/, '');
      if (!cleanExpr) {
        return { success: true, result: '0' };
      }

      const tokens = this.tokenize(cleanExpr);
      if (tokens.length === 0) {
        return { success: true, result: '0' };
      }

      const val = this.evaluateTokens(tokens);

      if (isNaN(val) || !isFinite(val)) {
        return { success: false, result: 'Error', error: 'Division by zero or invalid operation' };
      }

      const formatted = this.formatNumber(val);
      return { success: true, result: formatted };
    } catch (e: any) {
      if (e.message === 'DIV_ZERO') {
        return { success: false, result: 'Error', error: 'Division by zero' };
      }
      return { success: false, result: 'Error', error: e.message || 'Invalid expression' };
    }
  }

  /**
   * Tokenizes expression into numbers and operators, handling unary minus
   */
  private static tokenize(expr: string): string[] {
    const tokens: string[] = [];
    let currentNumber = '';
    let i = 0;

    while (i < expr.length) {
      const ch = expr.charAt(i);

      if ((ch >= '0' && ch <= '9') || ch === '.') {
        currentNumber += ch;
        i++;
      } else if (ch === '+' || ch === '-' || ch === '*' || ch === '/') {
        // Check for unary minus:
        // A minus is unary if it's at the very beginning of expression,
        // or immediately preceded by another operator (e.g., "6*-2" or "-5+2")
        const isUnaryMinus = ch === '-' && (
          tokens.length === 0 && currentNumber.length === 0 ||
          (currentNumber.length === 0 && tokens.length > 0 && ['+', '-', '*', '/'].includes(tokens[tokens.length - 1]))
        );

        if (isUnaryMinus) {
          currentNumber += '-';
          i++;
        } else {
          if (currentNumber.length > 0) {
            tokens.push(currentNumber);
            currentNumber = '';
          }
          tokens.push(ch);
          i++;
        }
      } else {
        // Skip unrecognized characters
        i++;
      }
    }

    if (currentNumber.length > 0) {
      tokens.push(currentNumber);
    }

    return tokens;
  }

  /**
   * Two-pass evaluation respecting standard arithmetic precedence:
   * Pass 1: Multiplication (*) and Division (/)
   * Pass 2: Addition (+) and Subtraction (-)
   */
  private static evaluateTokens(tokens: string[]): number {
    if (tokens.length === 0) return 0;
    if (tokens.length === 1) {
      const num = parseFloat(tokens[0]);
      if (isNaN(num)) throw new Error('Invalid number');
      return num;
    }

    // Pass 1: Handle * and /
    const pass1Tokens: string[] = [];
    let i = 0;

    while (i < tokens.length) {
      const token = tokens[i];

      if (token === '*' || token === '/') {
        if (pass1Tokens.length === 0 || i + 1 >= tokens.length) {
          throw new Error('Malformed expression');
        }

        const prevNum = parseFloat(pass1Tokens.pop()!);
        const nextNum = parseFloat(tokens[i + 1]);

        if (isNaN(prevNum) || isNaN(nextNum)) {
          throw new Error('Malformed operands');
        }

        let res = 0;
        if (token === '*') {
          res = prevNum * nextNum;
        } else {
          if (Math.abs(nextNum) < 1e-12) {
            throw new Error('DIV_ZERO');
          }
          res = prevNum / nextNum;
        }

        pass1Tokens.push(res.toString());
        i += 2; // skip operator and next number
      } else {
        pass1Tokens.push(token);
        i++;
      }
    }

    // Pass 2: Handle + and -
    if (pass1Tokens.length === 0) return 0;
    let total = parseFloat(pass1Tokens[0]);
    if (isNaN(total)) throw new Error('Malformed expression');

    let j = 1;
    while (j < pass1Tokens.length) {
      const op = pass1Tokens[j];
      if (j + 1 >= pass1Tokens.length) break;
      const nextNum = parseFloat(pass1Tokens[j + 1]);

      if (isNaN(nextNum)) throw new Error('Malformed operand');

      if (op === '+') {
        total += nextNum;
      } else if (op === '-') {
        total -= nextNum;
      }

      j += 2;
    }

    return total;
  }

  /**
   * Formats numbers cleanly:
   * 5.0 -> "5"
   * 0.7500 -> "0.75"
   * Handles precision issues gracefully (e.g., 0.1 + 0.2 -> 0.3)
   */
  public static formatNumber(num: number): string {
    if (isNaN(num) || !isFinite(num)) {
      return 'Error';
    }

    // Round to 10 decimal places to eliminate floating point quirks like 0.30000000000000004
    const rounded = Math.round(num * 1e10) / 1e10;

    // Check if it's an integer
    if (Number.isInteger(rounded)) {
      return rounded.toString();
    }

    // Convert to string and remove trailing zeroes
    let str = rounded.toString();
    if (str.includes('.')) {
      str = str.replace(/(\.\d*?[1-9])0+$/g, '$1').replace(/\.0+$/, '');
    }

    // Prevent scientific notation for reasonable values
    if (str.includes('e')) {
      const parsed = parseFloat(str);
      return parsed.toLocaleString('en-US', { maximumFractionDigits: 8 }).replace(/,/g, '');
    }

    return str;
  }

  /**
   * Helper to check if adding a decimal point is valid in current expression
   */
  public static canAddDecimal(expr: string): boolean {
    if (!expr) return true;
    // Look at the last number segment after the last operator (+, −, ×, ÷, -, *, /)
    const segments = expr.split(/[+\−\×\÷\-\*\/]/);
    const lastSegment = segments[segments.length - 1];
    return !lastSegment.includes('.');
  }

  /**
   * Helper to check if last character is an operator
   */
  public static isOperator(char: string): boolean {
    return ['+', '−', '×', '÷', '-', '*', '/'].includes(char);
  }
}
