# Calcora — Android Calculator Application

**Oasis Infobyte Android App Development Internship**  
**Task Title:** Task 3 — Calculator  
**Developer Name:** Neha Vinod Borkar  
**Track:** Android App Development  
**Platform:** Android (Java & XML Layouts)  
**IDE:** Android Studio  

---

## 📱 Project Overview
**Calcora** is a sleek, modern, and robust Android calculator application developed with clean Java code and native Android XML layouts. Engineered to handle standard daily calculations with mathematical precision, Calcora adheres to strict operator precedence, prevents malformed inputs, handles negative values and division by zero with safety checks, and features a dark navy/charcoal UI highlighted with purple accents.

---

## ✨ Features & Architecture

### 1. Dual-Line Display
- **Expression Line (`tvExpression`):** Displays the ongoing formula and previous input (e.g. `12 × 45 =`).
- **Main Result Display (`tvResult`):** Displays the current operand, evaluated result, or `Error`.
- Automatic single-line scrolling prevents text clipping on longer expressions.

### 2. Direct Java Expression Evaluation (`ExpressionEvaluator.java`)
- **No fragile string replacements or JavaScript `eval()`**.
- **Two-Pass Evaluator:**
  - Pass 1: Multiplication (`×`) and Division (`÷`).
  - Pass 2: Addition (`+`) and Subtraction (`−`).
- **Unary Minus Handling:** Supports expressions like `−5 + 2` → `−3` and `6 × −2` → `−12`.
- **Division by Zero Protection:** `5 ÷ 0` explicitly returns `Error` without crashing.
- **Whole Number Formatting:** Displays integers cleanly (`5` instead of `5.0`).

### 3. Input Validation & Rapid-Tap Stability
- **Multiple Decimal Prevention:** Prevents entering `1..2` or `3.14.5`.
- **Consecutive Operator Replacement:** Switching operators dynamically replaces the previous operator.
- **Chain Calculations:** Pressing an operator immediately after `=` continues from the previous result. Fresh digit taps reset and start a new expression.
- **Haptic Tactile Feedback:** Integrated with Android's vibrator service for real keyboard tap feedback.

---

## 🧪 Verified Test Cases Checklist

| # | Test Expression | Expected Result | Actual Result | Status |
|---|---|---|---|---|
| 1 | `2+3` | `5` | `5` | ✅ PASSED |
| 2 | `9−4` | `5` | `5` | ✅ PASSED |
| 3 | `6×7` | `42` | `42` | ✅ PASSED |
| 4 | `8÷2` | `4` | `4` | ✅ PASSED |
| 5 | `0.5+0.25` | `0.75` | `0.75` | ✅ PASSED |
| 6 | `2+3×4` | `14` | `14` | ✅ PASSED |
| 7 | `−5+2` | `−3` | `−3` | ✅ PASSED |
| 8 | `5÷0` | `Error` | `Error` | ✅ PASSED |
| 9 | Clear (`C`) | Resets to `0` | `0` | ✅ PASSED |
| 10 | Backspace (`⌫`) | Removes last character | Last char deleted | ✅ PASSED |
| 11 | Multiple decimals | Prevented (`3.14.5` → `3.145`) | Decimal blocked | ✅ PASSED |
| 12 | Incomplete expr (`5+`) | Evaluates safely without crash | Handled gracefully | ✅ PASSED |
| 13 | Repeated Equals taps | No crash, preserves state | Stable | ✅ PASSED |
| 14 | Rapid button taps | UI remains consistent | 100% Stable | ✅ PASSED |
| 15 | Screen adaptiveness | Responsive ConstraintLayout | Perfect scaling | ✅ PASSED |

---

## 🛠️ How to Open in Android Studio
1. Clone or download this project.
2. Open Android Studio (Hedgehog, Iguana, Koala, Ladybug, or newer).
3. Select **File > Open...** and navigate to this folder.
4. Allow Gradle to sync.
5. Select an Android Virtual Device (AVD) or connect a physical phone with USB Debugging.
6. Click the green **Run (Shift+F10)** button.
