package com.calcora.calculator;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Calcora - Android Calculator Application
 * Oasis Infobyte Android App Development Internship - Task 3
 * Developer: Neha Vinod Borkar
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tvExpression;
    private TextView tvResult;

    private StringBuilder currentExpression;
    private boolean isResultDisplayed = false;
    private boolean isErrorState = false;
    private Vibrator vibrator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        currentExpression = new StringBuilder();
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        initViews();
        resetCalculator();
    }

    private void initViews() {
        tvExpression = findViewById(R.id.tvExpression);
        tvResult = findViewById(R.id.tvResult);

        // Digits
        int[] numberButtonIds = {
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        };
        for (int id : numberButtonIds) {
            findViewById(id).setOnClickListener(this);
        }

        // Operators & Operations
        findViewById(R.id.btnDot).setOnClickListener(this);
        findViewById(R.id.btnAdd).setOnClickListener(this);
        findViewById(R.id.btnSubtract).setOnClickListener(this);
        findViewById(R.id.btnMultiply).setOnClickListener(this);
        findViewById(R.id.btnDivide).setOnClickListener(this);
        findViewById(R.id.btnClear).setOnClickListener(this);
        findViewById(R.id.btnBackspace).setOnClickListener(this);
        findViewById(R.id.btnEquals).setOnClickListener(this);
        
        // Optional helpers
        View btnPlusMinus = findViewById(R.id.btnPlusMinus);
        if (btnPlusMinus != null) btnPlusMinus.setOnClickListener(this);
        View btnPercent = findViewById(R.id.btnPercent);
        if (btnPercent != null) btnPercent.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        triggerHapticFeedback(view);
        int id = view.getId();

        if (id == R.id.btnClear) {
            resetCalculator();
        } else if (id == R.id.btnBackspace) {
            handleBackspace();
        } else if (id == R.id.btnEquals) {
            handleEquals();
        } else if (id == R.id.btnDot) {
            handleDecimal();
        } else if (id == R.id.btnAdd) {
            handleOperator("+");
        } else if (id == R.id.btnSubtract) {
            handleOperator("−");
        } else if (id == R.id.btnMultiply) {
            handleOperator("×");
        } else if (id == R.id.btnDivide) {
            handleOperator("÷");
        } else if (id == R.id.btnPlusMinus) {
            handlePlusMinus();
        } else if (id == R.id.btnPercent) {
            handlePercent();
        } else {
            // Number button tapped
            if (view instanceof Button) {
                String digit = ((Button) view).getText().toString();
                handleNumber(digit);
            }
        }
    }

    private void handleNumber(String digit) {
        if (isErrorState) {
            resetCalculator();
        } else if (isResultDisplayed) {
            currentExpression.setLength(0);
            tvExpression.setText("");
            isResultDisplayed = false;
        }

        if (currentExpression.length() == 1 && currentExpression.charAt(0) == '0') {
            currentExpression.setCharAt(0, digit.charAt(0));
        } else {
            if (isOperatorFollowedBySingleZero() && !digit.equals(".")) {
                currentExpression.deleteCharAt(currentExpression.length() - 1);
            }
            currentExpression.append(digit);
        }

        updateDisplay();
    }

    private void handleDecimal() {
        if (isErrorState) {
            resetCalculator();
        } else if (isResultDisplayed) {
            currentExpression.setLength(0);
            tvExpression.setText("");
            isResultDisplayed = false;
        }

        if (currentExpression.length() == 0) {
            currentExpression.append("0.");
        } else {
            char lastChar = currentExpression.charAt(currentExpression.length() - 1);
            if (isOperatorChar(lastChar)) {
                currentExpression.append("0.");
            } else if (ExpressionEvaluator.canAddDecimal(currentExpression.toString())) {
                currentExpression.append(".");
            }
        }
        updateDisplay();
    }

    private void handleOperator(String operator) {
        if (isErrorState) {
            resetCalculator();
            return;
        }

        if (isResultDisplayed) {
            isResultDisplayed = false;
        }

        if (currentExpression.length() == 0) {
            if (operator.equals("−")) {
                currentExpression.append("−");
                updateDisplay();
            }
            return;
        }

        char lastChar = currentExpression.charAt(currentExpression.length() - 1);

        if (isOperatorChar(lastChar)) {
            if ((lastChar == '×' || lastChar == '÷') && operator.equals("−")) {
                currentExpression.append("−");
            } else {
                if (currentExpression.length() >= 2) {
                    char secondLast = currentExpression.charAt(currentExpression.length() - 2);
                    if (isOperatorChar(secondLast)) {
                        currentExpression.delete(currentExpression.length() - 2, currentExpression.length());
                    } else {
                        currentExpression.deleteCharAt(currentExpression.length() - 1);
                    }
                } else {
                    currentExpression.deleteCharAt(currentExpression.length() - 1);
                }
                currentExpression.append(operator);
            }
        } else if (lastChar == '.') {
            currentExpression.deleteCharAt(currentExpression.length() - 1);
            currentExpression.append(operator);
        } else {
            currentExpression.append(operator);
        }

        updateDisplay();
    }

    private void handleEquals() {
        if (isErrorState || currentExpression.length() == 0) {
            return;
        }

        if (isResultDisplayed) {
            return;
        }

        String rawExpr = currentExpression.toString();
        tvExpression.setText(rawExpr + " =");

        ExpressionEvaluator.EvaluationResult evalResult = ExpressionEvaluator.evaluate(rawExpr);

        if (evalResult.isSuccess()) {
            tvResult.setText(evalResult.getResult());
            currentExpression.setLength(0);
            currentExpression.append(evalResult.getResult());
            isResultDisplayed = true;
            isErrorState = false;
        } else {
            tvResult.setText("Error");
            isErrorState = true;
            isResultDisplayed = false;
        }
    }

    private void handleBackspace() {
        if (isErrorState || isResultDisplayed) {
            resetCalculator();
            return;
        }

        if (currentExpression.length() > 0) {
            currentExpression.deleteCharAt(currentExpression.length() - 1);
        }

        updateDisplay();
    }

    private void handlePlusMinus() {
        if (isErrorState) return;
        if (currentExpression.length() == 0) {
            currentExpression.append("−");
            updateDisplay();
            return;
        }

        String expr = currentExpression.toString();
        int lastOpIdx = Math.max(Math.max(expr.lastIndexOf('+'), expr.lastIndexOf('−')),
                                Math.max(expr.lastIndexOf('×'), expr.lastIndexOf('÷')));
        if (lastOpIdx == -1) {
            if (expr.startsWith("−")) {
                currentExpression.deleteCharAt(0);
            } else {
                currentExpression.insert(0, "−");
            }
        } else {
            String prefix = expr.substring(0, lastOpIdx + 1);
            String number = expr.substring(lastOpIdx + 1);
            if (number.startsWith("−")) {
                currentExpression = new StringBuilder(prefix + number.substring(1));
            } else {
                currentExpression = new StringBuilder(prefix + "−" + number);
            }
        }
        updateDisplay();
    }

    private void handlePercent() {
        if (isErrorState || currentExpression.length() == 0) return;
        try {
            ExpressionEvaluator.EvaluationResult res = ExpressionEvaluator.evaluate(currentExpression.toString());
            if (res.isSuccess()) {
                double val = Double.parseDouble(res.getResult()) / 100.0;
                String formatted = ExpressionEvaluator.formatNumber(val);
                currentExpression.setLength(0);
                currentExpression.append(formatted);
                updateDisplay();
            }
        } catch (Exception ignored) {}
    }

    private void resetCalculator() {
        currentExpression.setLength(0);
        tvExpression.setText("");
        tvResult.setText("0");
        isResultDisplayed = false;
        isErrorState = false;
    }

    private void updateDisplay() {
        if (currentExpression.length() == 0) {
            tvResult.setText("0");
        } else {
            tvResult.setText(currentExpression.toString());
        }
    }

    private boolean isOperatorChar(char ch) {
        return ch == '+' || ch == '−' || ch == '×' || ch == '÷' || ch == '-';
    }

    private boolean isOperatorFollowedBySingleZero() {
        int len = currentExpression.length();
        if (len < 2) return false;
        char last = currentExpression.charAt(len - 1);
        char secondLast = currentExpression.charAt(len - 2);
        return last == '0' && isOperatorChar(secondLast);
    }

    private void triggerHapticFeedback(View view) {
        if (view != null) {
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        }
        if (vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(12);
            }
        }
    }
}
