package com.calcora.calculator;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Pure Java Safe Expression Evaluator
 * Evaluates mathematical expressions using standard arithmetic precedence.
 * Does not rely on external libraries or JavaScript eval().
 */
public class ExpressionEvaluator {

    public static class EvaluationResult {
        private final boolean success;
        private final String result;
        private final String errorMessage;

        public EvaluationResult(boolean success, String result, String errorMessage) {
            this.success = success;
            this.result = result;
            this.errorMessage = errorMessage;
        }

        public boolean isSuccess() {
            return success;
        }

        public String getResult() {
            return result;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }

    public static EvaluationResult evaluate(String rawExpr) {
        if (rawExpr == null || rawExpr.trim().isEmpty()) {
            return new EvaluationResult(true, "0", null);
        }

        try {
            String expr = normalize(rawExpr);

            // Strip trailing operators if user pressed equals with trailing operator
            while (expr.length() > 0 && isOperatorChar(expr.charAt(expr.length() - 1))) {
                expr = expr.substring(0, expr.length() - 1);
            }

            if (expr.isEmpty()) {
                return new EvaluationResult(true, "0", null);
            }

            List<String> tokens = tokenize(expr);
            if (tokens.isEmpty()) {
                return new EvaluationResult(true, "0", null);
            }

            double result = evaluateTokens(tokens);

            if (Double.isNaN(result) || Double.isInfinite(result)) {
                return new EvaluationResult(false, "Error", "Division by zero or non-finite result");
            }

            String formatted = formatNumber(result);
            return new EvaluationResult(true, formatted, null);

        } catch (ArithmeticException e) {
            return new EvaluationResult(false, "Error", "Arithmetic error: " + e.getMessage());
        } catch (Exception e) {
            return new EvaluationResult(false, "Error", "Invalid expression");
        }
    }

    public static String normalize(String expr) {
        return expr.replace("×", "*")
                   .replace("÷", "/")
                   .replace("−", "-")
                   .replaceAll("\\s+", "");
    }

    private static List<String> tokenize(String expr) {
        List<String> tokens = new ArrayList<>();
        StringBuilder currentNumber = new StringBuilder();
        int i = 0;

        while (i < expr.length()) {
            char ch = expr.charAt(i);

            if (Character.isDigit(ch) || ch == '.') {
                currentNumber.append(ch);
                i++;
            } else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
                boolean isUnaryMinus = (ch == '-') && (
                        (tokens.isEmpty() && currentNumber.length() == 0) ||
                        (currentNumber.length() == 0 && !tokens.isEmpty() && isOperatorString(tokens.get(tokens.size() - 1)))
                );

                if (isUnaryMinus) {
                    currentNumber.append('-');
                    i++;
                } else {
                    if (currentNumber.length() > 0) {
                        tokens.add(currentNumber.toString());
                        currentNumber.setLength(0);
                    }
                    tokens.add(String.valueOf(ch));
                    i++;
                }
            } else {
                i++;
            }
        }

        if (currentNumber.length() > 0) {
            tokens.add(currentNumber.toString());
        }

        return tokens;
    }

    private static double evaluateTokens(List<String> tokens) {
        if (tokens.isEmpty()) return 0.0;
        if (tokens.size() == 1) {
            return Double.parseDouble(tokens.get(0));
        }

        // Pass 1: Multiplication and Division
        List<String> pass1 = new ArrayList<>();
        int i = 0;

        while (i < tokens.size()) {
            String token = tokens.get(i);

            if (token.equals("*") || token.equals("/")) {
                if (pass1.isEmpty() || i + 1 >= tokens.size()) {
                    throw new IllegalArgumentException("Malformed expression");
                }

                double prevNum = Double.parseDouble(pass1.remove(pass1.size() - 1));
                double nextNum = Double.parseDouble(tokens.get(i + 1));

                double res;
                if (token.equals("*")) {
                    res = prevNum * nextNum;
                } else {
                    if (Math.abs(nextNum) < 1e-12) {
                        throw new ArithmeticException("Division by zero");
                    }
                    res = prevNum / nextNum;
                }

                pass1.add(String.valueOf(res));
                i += 2;
            } else {
                pass1.add(token);
                i++;
            }
        }

        // Pass 2: Addition and Subtraction
        if (pass1.isEmpty()) return 0.0;
        double total = Double.parseDouble(pass1.get(0));

        int j = 1;
        while (j < pass1.size()) {
            String op = pass1.get(j);
            if (j + 1 >= pass1.size()) break;
            double nextNum = Double.parseDouble(pass1.get(j + 1));

            if (op.equals("+")) {
                total += nextNum;
            } else if (op.equals("-")) {
                total -= nextNum;
            }
            j += 2;
        }

        return total;
    }

    public static String formatNumber(double num) {
        if (Double.isNaN(num) || Double.isInfinite(num)) {
            return "Error";
        }

        BigDecimal bd = new BigDecimal(Double.toString(num), MathContext.DECIMAL64);
        bd = bd.setScale(10, RoundingMode.HALF_UP).stripTrailingZeros();

        String plainStr = bd.toPlainString();
        if (plainStr.equals("-0") || plainStr.equals("-0.0")) {
            return "0";
        }

        return plainStr;
    }

    public static boolean canAddDecimal(String expr) {
        if (expr == null || expr.isEmpty()) return true;
        String[] tokens = expr.split("[+\\-−×÷*/]");
        if (tokens.length == 0) return true;
        String lastSegment = tokens[tokens.length - 1];
        return !lastSegment.contains(".");
    }

    private static boolean isOperatorChar(char ch) {
        return ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '×' || ch == '÷' || ch == '−';
    }

    private static boolean isOperatorString(String s) {
        return s.equals("+") || s.equals("-") || s.equals("*") || s.equals("/");
    }
}
