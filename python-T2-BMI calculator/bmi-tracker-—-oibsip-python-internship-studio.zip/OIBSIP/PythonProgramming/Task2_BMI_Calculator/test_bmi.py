"""
Automated Unit and Integration Tests for BMI Tracker
OIBSIP Python Programming Internship - Task 2

Tests covered:
1. Core BMI formula calculations
2. Boundary classifications (< 18.5, == 18.5, == 25.0, == 30.0)
3. Input validation logic (empty strings, zero, negative, non-numeric)
4. SQLite database CRUD operations and multi-user isolation
"""

import os
import unittest
import tempfile
import sqlite3

# Local modules
import bmi_calculator
import database


class TestBMICalculation(unittest.TestCase):
    """Test standard formula calculations and boundary conditions."""

    def test_standard_example(self):
        """User requirement: weight = 60 kg, height = 1.65 m -> BMI = 22.04"""
        bmi = bmi_calculator.calculate_bmi(60.0, 1.65)
        self.assertEqual(bmi, 22.04)
        cat, _, _ = bmi_calculator.classify_bmi(bmi)
        self.assertEqual(cat, "Normal")

    def test_just_below_18_5(self):
        """Underweight boundary: 18.49 should be 'Underweight'"""
        cat, color, _ = bmi_calculator.classify_bmi(18.49)
        self.assertEqual(cat, "Underweight")
        self.assertEqual(color, "#2563EB")

    def test_exact_18_5(self):
        """Normal boundary start: 18.5 should be 'Normal'"""
        cat, color, _ = bmi_calculator.classify_bmi(18.5)
        self.assertEqual(cat, "Normal")
        self.assertEqual(color, "#16A34A")

    def test_just_below_25_0(self):
        """Normal boundary end: 24.99 should be 'Normal'"""
        cat, color, _ = bmi_calculator.classify_bmi(24.99)
        self.assertEqual(cat, "Normal")
        self.assertEqual(color, "#16A34A")

    def test_exact_25_0(self):
        """Overweight boundary start: 25.0 should be 'Overweight'"""
        cat, color, _ = bmi_calculator.classify_bmi(25.0)
        self.assertEqual(cat, "Overweight")
        self.assertEqual(color, "#D97706")

    def test_just_below_30_0(self):
        """Overweight boundary end: 29.99 should be 'Overweight'"""
        cat, color, _ = bmi_calculator.classify_bmi(29.99)
        self.assertEqual(cat, "Overweight")
        self.assertEqual(color, "#D97706")

    def test_exact_30_0(self):
        """Obese boundary start: 30.0 should be 'Obese'"""
        cat, color, _ = bmi_calculator.classify_bmi(30.0)
        self.assertEqual(cat, "Obese")
        self.assertEqual(color, "#DC2626")

    def test_severely_obese(self):
        """Obese category above 30: 38.5 should be 'Obese'"""
        cat, color, _ = bmi_calculator.classify_bmi(38.5)
        self.assertEqual(cat, "Obese")
        self.assertEqual(color, "#DC2626")

    def test_invalid_zero_height(self):
        """Zero height must raise ValueError."""
        with self.assertRaises(ValueError):
            bmi_calculator.calculate_bmi(65.0, 0.0)

    def test_invalid_negative_height(self):
        """Negative height must raise ValueError."""
        with self.assertRaises(ValueError):
            bmi_calculator.calculate_bmi(65.0, -1.65)

    def test_invalid_negative_weight(self):
        """Negative weight must raise ValueError."""
        with self.assertRaises(ValueError):
            bmi_calculator.calculate_bmi(-65.0, 1.70)


class TestInputValidation(unittest.TestCase):
    """Test input validation for user name, weight, and height inputs."""

    def test_valid_input(self):
        """Legitimate inputs should pass validation."""
        is_valid, msg, w, h = bmi_calculator.validate_inputs("Aarav Sharma", "70", "1.75")
        self.assertTrue(is_valid)
        self.assertEqual(msg, "")
        self.assertEqual(w, 70.0)
        self.assertEqual(h, 1.75)

    def test_empty_user_name(self):
        """Empty or whitespace name must fail validation."""
        is_valid, msg, _, _ = bmi_calculator.validate_inputs("", "65", "1.70")
        self.assertFalse(is_valid)
        self.assertIn("user name cannot be empty", msg.lower())

        is_valid, msg, _, _ = bmi_calculator.validate_inputs("    ", "65", "1.70")
        self.assertFalse(is_valid)

    def test_non_numeric_weight(self):
        """Text or non-numeric weight must fail validation."""
        is_valid, msg, _, _ = bmi_calculator.validate_inputs("John", "seventy", "1.75")
        self.assertFalse(is_valid)
        self.assertIn("numeric", msg.lower())

    def test_zero_weight(self):
        """Zero weight must fail validation."""
        is_valid, msg, _, _ = bmi_calculator.validate_inputs("John", "0", "1.75")
        self.assertFalse(is_valid)
        self.assertIn("greater than 0", msg.lower())

    def test_negative_weight(self):
        """Negative weight must fail validation."""
        is_valid, msg, _, _ = bmi_calculator.validate_inputs("John", "-60", "1.75")
        self.assertFalse(is_valid)
        self.assertIn("greater than 0", msg.lower())

    def test_non_numeric_height(self):
        """Text or non-numeric height must fail validation."""
        is_valid, msg, _, _ = bmi_calculator.validate_inputs("John", "65", "1m70")
        self.assertFalse(is_valid)
        self.assertIn("numeric", msg.lower())

    def test_zero_height(self):
        """Zero height must fail validation."""
        is_valid, msg, _, _ = bmi_calculator.validate_inputs("John", "65", "0")
        self.assertFalse(is_valid)
        self.assertIn("greater than 0", msg.lower())

    def test_negative_height(self):
        """Negative height must fail validation."""
        is_valid, msg, _, _ = bmi_calculator.validate_inputs("John", "65", "-1.60")
        self.assertFalse(is_valid)
        self.assertIn("greater than 0", msg.lower())

    def test_height_in_centimeters_caught(self):
        """Entering centimeters (> 3.0 m, like 175) should return a helpful conversion hint."""
        is_valid, msg, _, _ = bmi_calculator.validate_inputs("John", "65", "175")
        self.assertFalse(is_valid)
        self.assertIn("centimeters", msg.lower())
        self.assertIn("1.75", msg)


class TestDatabaseOperations(unittest.TestCase):
    """Test SQLite database initialization, insertion, isolation, and retrieval."""

    def setUp(self):
        """Create a temporary SQLite database file for isolation between test runs."""
        self.temp_db_fd, self.temp_db_path = tempfile.mkstemp(suffix=".db")
        database.init_db(self.temp_db_path)

    def tearDown(self):
        """Clean up temporary database file."""
        os.close(self.temp_db_fd)
        if os.path.exists(self.temp_db_path):
            os.remove(self.temp_db_path)

    def test_table_created(self):
        """Verify bmi_records table exists with proper schema."""
        with sqlite3.connect(self.temp_db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='bmi_records'")
            self.assertIsNotNone(cursor.fetchone())

    def test_save_and_retrieve_record(self):
        """Verify inserting a record and retrieving it by user name."""
        rec_id = database.save_record(
            user_name="Neha Borkar",
            weight_kg=58.0,
            height_m=1.62,
            bmi=22.10,
            category="Normal",
            recorded_at="2026-10-28 10:00:00",
            db_path=self.temp_db_path
        )
        self.assertGreater(rec_id, 0)

        history = database.get_user_history("Neha Borkar", db_path=self.temp_db_path)
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]["user_name"], "Neha Borkar")
        self.assertEqual(history[0]["weight_kg"], 58.0)
        self.assertEqual(history[0]["height_m"], 1.62)
        self.assertEqual(history[0]["bmi"], 22.10)
        self.assertEqual(history[0]["category"], "Normal")

    def test_multi_user_isolation(self):
        """Ensure User A cannot view User B's history records."""
        # Insert records for two distinct users
        database.save_record("Aditi", 50.0, 1.55, 20.81, "Normal", db_path=self.temp_db_path)
        database.save_record("Rahul", 85.0, 1.75, 27.76, "Overweight", db_path=self.temp_db_path)
        database.save_record("Aditi", 51.0, 1.55, 21.23, "Normal", db_path=self.temp_db_path)

        aditi_history = database.get_user_history("Aditi", db_path=self.temp_db_path)
        rahul_history = database.get_user_history("Rahul", db_path=self.temp_db_path)

        self.assertEqual(len(aditi_history), 2)
        self.assertEqual(len(rahul_history), 1)

        # Verify only matching user names are returned
        for item in aditi_history:
            self.assertEqual(item["user_name"], "Aditi")

        self.assertEqual(rahul_history[0]["user_name"], "Rahul")

    def test_user_with_no_history(self):
        """Querying a user that does not exist should return an empty list without crashing."""
        history = database.get_user_history("NonExistentUser", db_path=self.temp_db_path)
        self.assertEqual(history, [])

    def test_newest_records_ordered_first(self):
        """Ensure records are ordered by recorded_at DESC (newest first)."""
        database.save_record("Priya", 60.0, 1.60, 23.44, "Normal", recorded_at="2026-10-01 08:00:00", db_path=self.temp_db_path)
        database.save_record("Priya", 62.0, 1.60, 24.22, "Normal", recorded_at="2026-10-15 09:30:00", db_path=self.temp_db_path)
        database.save_record("Priya", 59.0, 1.60, 23.05, "Normal", recorded_at="2026-10-28 12:00:00", db_path=self.temp_db_path)

        history = database.get_user_history("Priya", db_path=self.temp_db_path)
        self.assertEqual(len(history), 3)
        self.assertEqual(history[0]["recorded_at"], "2026-10-28 12:00:00")
        self.assertEqual(history[1]["recorded_at"], "2026-10-15 09:30:00")
        self.assertEqual(history[2]["recorded_at"], "2026-10-01 08:00:00")

    def test_delete_record(self):
        """Test deleting a record by its unique ID."""
        rec_id = database.save_record("Kunal", 72.0, 1.70, 24.91, "Normal", db_path=self.temp_db_path)
        deleted = database.delete_record(rec_id, db_path=self.temp_db_path)
        self.assertTrue(deleted)

        history = database.get_user_history("Kunal", db_path=self.temp_db_path)
        self.assertEqual(len(history), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
