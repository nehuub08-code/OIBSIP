"""
Command-Line Interface (CLI) Demo for BMI Tracker
OIBSIP Python Programming Internship - Task 2 (Phase 1)

This standalone script demonstrates the complete BMI calculation,
classification, input validation, and SQLite database storage
directly in the terminal without requiring any desktop GUI or display server.
"""

import sys
import bmi_calculator
import database


def print_banner():
    print("=" * 64)
    print("   BMI TRACKER — PERSONAL BMI CALCULATOR (CLI VERSION)")
    print("   Oasis Infobyte (OIBSIP) Python Programming Internship")
    print("=" * 64)


def handle_calculate():
    print("\n--- 1. Calculate & Save BMI ---")
    user_name = input("Enter your Full Name: ").strip()
    weight_str = input("Enter Weight in kg (e.g. 68.5): ").strip()
    height_str = input("Enter Height in meters (e.g. 1.72): ").strip()

    is_valid, err_msg, weight_kg, height_m = bmi_calculator.validate_inputs(
        user_name, weight_str, height_str
    )

    if not is_valid:
        print(f"\n[Validation Error]: {err_msg}")
        return

    bmi = bmi_calculator.calculate_bmi(weight_kg, height_m)
    category, color, advice = bmi_calculator.classify_bmi(bmi)
    min_w, max_w = bmi_calculator.get_healthy_weight_range(height_m)

    rec_id = database.save_record(user_name, weight_kg, height_m, bmi, category)

    print("\n" + "-" * 40)
    print(f" Calculation Result for {user_name}:")
    print(f" BMI Value   : {bmi:.2f}")
    print(f" Category    : {category}")
    print(f" Assessment  : {advice}")
    print(f" Ideal Weight: {min_w} kg – {max_w} kg for {height_m:.2f} m")
    print(f" Record ID   : #{rec_id} (Saved to SQLite database)")
    print("-" * 40)


def handle_view_history():
    print("\n--- 2. View User History ---")
    user_name = input("Enter Name of profile to query: ").strip()
    if not user_name:
        print("[Error]: User name cannot be empty.")
        return

    records = database.get_user_history(user_name)
    if not records:
        print(f"\nNo historical records found for user '{user_name}'.")
        return

    print(f"\nFound {len(records)} record(s) for '{user_name}' (Newest first):")
    print("-" * 75)
    print(f"{'ID':<6} {'Date & Time':<20} {'Weight':<10} {'Height':<10} {'BMI':<8} {'Category':<15}")
    print("-" * 75)
    for r in records:
        print(
            f"{r['id']:<6} {r['recorded_at']:<20} {r['weight_kg']:<10.1f} "
            f"{r['height_m']:<10.2f} {r['bmi']:<8.2f} {r['category']:<15}"
        )
    print("-" * 75)


def handle_show_profiles():
    print("\n--- 3. Registered Profiles in Database ---")
    users = database.get_all_users()
    if not users:
        print("No profiles stored yet in database.")
        return
    print(f"Total profiles: {len(users)}")
    for i, u in enumerate(users, start=1):
        count = len(database.get_user_history(u))
        print(f"  {i}. {u} ({count} record{'s' if count != 1 else ''})")


def main():
    database.init_db()
    print_banner()

    while True:
        print("\nChoose an option:")
        print("  1. Calculate and save BMI")
        print("  2. View user history")
        print("  3. List all user profiles")
        print("  4. Exit")

        choice = input("\nEnter choice (1-4): ").strip()

        if choice == "1":
            handle_calculate()
        elif choice == "2":
            handle_view_history()
        elif choice == "3":
            handle_show_profiles()
        elif choice == "4":
            print("\nExiting BMI Tracker CLI. Thank you!")
            break
        else:
            print("[Invalid]: Please enter a number between 1 and 4.")


if __name__ == "__main__":
    main()
