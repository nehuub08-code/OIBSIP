"""
BMI Tracker — Personal BMI Calculator
Oasis Infobyte (OIBSIP) Python Programming Internship - Task 2

A desktop GUI application built using Python's Tkinter, SQLite3, and Matplotlib.

Features:
- Validates user input (name, weight > 0, height > 0)
- Calculates BMI using metric formula: weight_kg / (height_m ** 2)
- Classifies BMI into WHO adult categories (Underweight, Normal, Overweight, Obese)
- Visualizes results with clear, accessible colour-coding and advice
- Stores calculation history per user profile in a local SQLite database
- Interactive history table using ttk.Treeview
- Historical BMI trend line chart using Matplotlib
"""

import sys
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Optional

# Local modules
import bmi_calculator
import database
import history_chart

# Try importing Matplotlib Tkinter backend for embedding
try:
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
    MATPLOTLIB_TK_AVAILABLE = True
except ImportError:
    MATPLOTLIB_TK_AVAILABLE = False


class BMITrackerApp:
    """
    Main Application Window for the BMI Tracker desktop application.
    """

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("BMI Tracker — Personal BMI Calculator (OIBSIP Task 2)")
        self.root.geometry("640x720")
        self.root.minsize(580, 650)
        self.root.configure(bg="#F8FAFC")

        # Initialize SQLite database schema
        try:
            database.init_db()
        except Exception as e:
            messagebox.showerror(
                "Database Initialization Error",
                f"Failed to initialize local SQLite database:\n{str(e)}"
            )

        # Configure TTK styles
        self._setup_styles()

        # Build GUI components
        self._create_header()
        self._create_input_card()
        self._create_action_buttons()
        self._create_result_card()
        self._create_footer_actions()

    def _setup_styles(self):
        """Configure modern clean ttk widget styling."""
        style = ttk.Style()
        style.theme_use("clam")

        # Entry fields
        style.configure("TEntry", padding=6, font=("Segoe UI", 10))

        # Labels
        style.configure("TLabel", background="#F8FAFC", font=("Segoe UI", 10))
        style.configure("Header.TLabel", font=("Segoe UI", 16, "bold"), foreground="#0F172A", background="#F8FAFC")
        style.configure("Subheader.TLabel", font=("Segoe UI", 9), foreground="#64748B", background="#F8FAFC")
        style.configure("FieldLabel.TLabel", font=("Segoe UI", 10, "bold"), foreground="#1E293B", background="#FFFFFF")

        # Buttons
        style.configure(
            "Primary.TButton",
            font=("Segoe UI", 10, "bold"),
            background="#2563EB",
            foreground="#FFFFFF",
            padding=8
        )
        style.map("Primary.TButton", background=[("active", "#1D4ED8")])

        style.configure(
            "Secondary.TButton",
            font=("Segoe UI", 9, "bold"),
            background="#E2E8F0",
            foreground="#1E293B",
            padding=6
        )
        style.map("Secondary.TButton", background=[("active", "#CBD5E1")])

    def _create_header(self):
        """Application title banner and task details."""
        header_frame = tk.Frame(self.root, bg="#F8FAFC", pady=14)
        header_frame.pack(fill="x", padx=24)

        title = ttk.Label(
            header_frame,
            text="BMI Tracker — Personal BMI Calculator",
            style="Header.TLabel"
        )
        title.pack(anchor="w")

        subtitle = ttk.Label(
            header_frame,
            text="Oasis Infobyte (OIBSIP) Python Programming Internship · Task 2",
            style="Subheader.TLabel"
        )
        subtitle.pack(anchor="w", pady=(2, 0))

    def _create_input_card(self):
        """Card containing input fields for user name, weight, and height."""
        self.input_card = tk.Frame(
            self.root,
            bg="#FFFFFF",
            highlightbackground="#E2E8F0",
            highlightthickness=1,
            padx=20,
            pady=16
        )
        self.input_card.pack(fill="x", padx=24, pady=(0, 12))

        # 1. User Name Field
        lbl_name = ttk.Label(self.input_card, text="Full Name / User Profile:", style="FieldLabel.TLabel")
        lbl_name.grid(row=0, column=0, sticky="w", pady=(0, 4))

        self.name_var = tk.StringVar()
        self.entry_name = ttk.Entry(self.input_card, textvariable=self.name_var, font=("Segoe UI", 10), width=36)
        self.entry_name.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 12))
        self.entry_name.focus()

        # 2. Weight Field (kg)
        lbl_weight = ttk.Label(self.input_card, text="Weight (kg):", style="FieldLabel.TLabel")
        lbl_weight.grid(row=2, column=0, sticky="w", pady=(0, 4))

        self.weight_var = tk.StringVar()
        self.entry_weight = ttk.Entry(self.input_card, textvariable=self.weight_var, font=("Segoe UI", 10), width=18)
        self.entry_weight.grid(row=3, column=0, sticky="w", padx=(0, 12), pady=(0, 4))

        weight_hint = tk.Label(self.input_card, text="e.g. 68.5", font=("Segoe UI", 8), fg="#94A3B8", bg="#FFFFFF")
        weight_hint.grid(row=4, column=0, sticky="w", pady=(0, 8))

        # 3. Height Field (m)
        lbl_height = ttk.Label(self.input_card, text="Height (m):", style="FieldLabel.TLabel")
        lbl_height.grid(row=2, column=1, sticky="w", pady=(0, 4))

        self.height_var = tk.StringVar()
        self.entry_height = ttk.Entry(self.input_card, textvariable=self.height_var, font=("Segoe UI", 10), width=18)
        self.entry_height.grid(row=3, column=1, sticky="w", pady=(0, 4))

        height_hint = tk.Label(self.input_card, text="e.g. 1.72 (m, not cm)", font=("Segoe UI", 8), fg="#94A3B8", bg="#FFFFFF")
        height_hint.grid(row=4, column=1, sticky="w", pady=(0, 8))

    def _create_action_buttons(self):
        """Action buttons row: Calculate BMI & Clear."""
        btn_frame = tk.Frame(self.root, bg="#F8FAFC")
        btn_frame.pack(fill="x", padx=24, pady=(0, 14))

        btn_calc = tk.Button(
            btn_frame,
            text="Calculate & Save BMI",
            font=("Segoe UI", 10, "bold"),
            bg="#2563EB",
            fg="#FFFFFF",
            activebackground="#1D4ED8",
            activeforeground="#FFFFFF",
            relief="flat",
            padx=16,
            pady=8,
            cursor="hand2",
            command=self.on_calculate_bmi
        )
        btn_calc.pack(side="left", padx=(0, 10))

        btn_clear = tk.Button(
            btn_frame,
            text="Clear Fields",
            font=("Segoe UI", 9),
            bg="#F1F5F9",
            fg="#475569",
            activebackground="#E2E8F0",
            relief="flat",
            padx=12,
            pady=8,
            cursor="hand2",
            command=self.on_clear_inputs
        )
        btn_clear.pack(side="left")

    def _create_result_card(self):
        """Card displaying the calculated BMI, category badge, and health tips."""
        self.result_card = tk.Frame(
            self.root,
            bg="#FFFFFF",
            highlightbackground="#E2E8F0",
            highlightthickness=1,
            padx=20,
            pady=16
        )
        self.result_card.pack(fill="both", expand=True, padx=24, pady=(0, 14))

        card_title = tk.Label(
            self.result_card,
            text="Calculation Summary",
            font=("Segoe UI", 11, "bold"),
            fg="#334155",
            bg="#FFFFFF"
        )
        card_title.pack(anchor="w", pady=(0, 8))

        # BMI Metric Display Frame
        metric_frame = tk.Frame(self.result_card, bg="#F8FAFC", padx=16, pady=12)
        metric_frame.pack(fill="x", pady=(0, 10))

        self.lbl_bmi_number = tk.Label(
            metric_frame,
            text="--.--",
            font=("Segoe UI", 32, "bold"),
            fg="#64748B",
            bg="#F8FAFC"
        )
        self.lbl_bmi_number.pack(side="left", padx=(0, 16))

        info_subframe = tk.Frame(metric_frame, bg="#F8FAFC")
        info_subframe.pack(side="left", fill="both", expand=True)

        self.lbl_category_badge = tk.Label(
            info_subframe,
            text="Awaiting Input",
            font=("Segoe UI", 11, "bold"),
            fg="#475569",
            bg="#E2E8F0",
            padx=10,
            pady=3
        )
        self.lbl_category_badge.pack(anchor="w", pady=(0, 4))

        self.lbl_feedback = tk.Label(
            info_subframe,
            text="Enter your profile details above and click 'Calculate & Save BMI'.",
            font=("Segoe UI", 9),
            fg="#64748B",
            bg="#F8FAFC",
            wraplength=340,
            justify="left"
        )
        self.lbl_feedback.pack(anchor="w")

        # Healthy weight recommendation
        self.lbl_healthy_range = tk.Label(
            self.result_card,
            text="",
            font=("Segoe UI", 9, "italic"),
            fg="#0F766E",
            bg="#FFFFFF"
        )
        self.lbl_healthy_range.pack(anchor="w", pady=(0, 6))

        # Adult Screening Disclaimer
        lbl_disclaimer = tk.Label(
            self.result_card,
            text=bmi_calculator.MEDICAL_DISCLAIMER,
            font=("Segoe UI", 8),
            fg="#94A3B8",
            bg="#FFFFFF",
            wraplength=480,
            justify="left"
        )
        lbl_disclaimer.pack(anchor="w", pady=(8, 0))

    def _create_footer_actions(self):
        """Footer buttons: View History & Show BMI Trend."""
        footer_frame = tk.Frame(self.root, bg="#F8FAFC")
        footer_frame.pack(fill="x", padx=24, pady=(0, 16))

        btn_history = tk.Button(
            footer_frame,
            text="📋 View History Table",
            font=("Segoe UI", 10, "bold"),
            bg="#0F172A",
            fg="#FFFFFF",
            activebackground="#334155",
            activeforeground="#FFFFFF",
            relief="flat",
            padx=14,
            pady=8,
            cursor="hand2",
            command=self.on_view_history
        )
        btn_history.pack(side="left", padx=(0, 10))

        btn_trend = tk.Button(
            footer_frame,
            text="📈 Show BMI Trend Chart",
            font=("Segoe UI", 10, "bold"),
            bg="#0284C7",
            fg="#FFFFFF",
            activebackground="#0369A1",
            activeforeground="#FFFFFF",
            relief="flat",
            padx=14,
            pady=8,
            cursor="hand2",
            command=self.on_show_trend
        )
        btn_trend.pack(side="left")

    def on_calculate_bmi(self):
        """Validate input, compute BMI, update display, and save to SQLite."""
        user_name = self.name_var.get()
        weight_str = self.weight_var.get()
        height_str = self.height_var.get()

        is_valid, err_msg, weight_kg, height_m = bmi_calculator.validate_inputs(
            user_name, weight_str, height_str
        )

        if not is_valid:
            messagebox.showerror("Input Validation Error", err_msg)
            return

        try:
            bmi = bmi_calculator.calculate_bmi(weight_kg, height_m)
            category, color, advice = bmi_calculator.classify_bmi(bmi)
            min_w, max_w = bmi_calculator.get_healthy_weight_range(height_m)

            # Update UI labels
            self.lbl_bmi_number.config(text=f"{bmi:.2f}", fg=color)
            self.lbl_category_badge.config(
                text=f"● {category.upper()}",
                fg="#FFFFFF",
                bg=color
            )
            self.lbl_feedback.config(text=advice, fg="#1E293B")
            self.lbl_healthy_range.config(
                text=f"Estimated healthy weight range for height {height_m:.2f}m: {min_w} kg – {max_w} kg"
            )

            # Save to SQLite database
            rec_id = database.save_record(user_name, weight_kg, height_m, bmi, category)
            messagebox.showinfo(
                "Calculation Saved",
                f"Calculation successful!\n\n"
                f"User: {user_name.strip()}\n"
                f"BMI: {bmi:.2f} ({category})\n"
                f"Saved to database (Record #{rec_id})."
            )
        except Exception as e:
            messagebox.showerror("Processing Error", f"Failed to calculate or save record:\n{str(e)}")

    def on_clear_inputs(self):
        """Reset input fields and results."""
        self.weight_var.set("")
        self.height_var.set("")
        self.lbl_bmi_number.config(text="--.--", fg="#64748B")
        self.lbl_category_badge.config(text="Awaiting Input", fg="#475569", bg="#E2E8F0")
        self.lbl_feedback.config(
            text="Enter your profile details above and click 'Calculate & Save BMI'.",
            fg="#64748B"
        )
        self.lbl_healthy_range.config(text="")
        self.entry_weight.focus()

    def on_view_history(self):
        """Open a dedicated window showing historical records for the entered profile."""
        user_name = self.name_var.get().strip()
        if not user_name:
            messagebox.showwarning(
                "User Name Required",
                "Please enter a user name in the 'Full Name / User Profile' field\n"
                "to view that user's specific history."
            )
            self.entry_name.focus()
            return

        try:
            records = database.get_user_history(user_name)
        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to retrieve history:\n{str(e)}")
            return

        HistoryWindow(self.root, user_name, records, on_records_changed=self._refresh_history)

    def _refresh_history(self, user_name: str):
        """Callback to reload records when one is deleted."""
        pass

    def on_show_trend(self):
        """Open a modal window with Matplotlib trend chart."""
        user_name = self.name_var.get().strip()
        if not user_name:
            messagebox.showwarning(
                "User Name Required",
                "Please enter a user name to view their BMI progress trend."
            )
            self.entry_name.focus()
            return

        if not MATPLOTLIB_TK_AVAILABLE:
            messagebox.showerror(
                "Matplotlib Missing",
                "Matplotlib is required for trend charts.\n\n"
                "Install it using:\npip install matplotlib"
            )
            return

        try:
            records = database.get_user_history(user_name)
        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to load records:\n{str(e)}")
            return

        if len(records) < 2:
            messagebox.showinfo(
                "Trend Notice: Insufficient Records",
                f"User '{user_name}' currently has {len(records)} record(s).\n\n"
                "At least 2 historical calculations are needed to plot a trend line.\n"
                "Calculate and save another record to enable the visual trend!"
            )
            return

        TrendChartWindow(self.root, user_name, records)


class HistoryWindow(tk.Toplevel):
    """
    Sub-window displaying a table (ttk.Treeview) of past records for a user.
    """

    def __init__(self, parent, user_name: str, records: list, on_records_changed=None):
        super().__init__(parent)
        self.user_name = user_name
        self.records = records
        self.on_records_changed = on_records_changed

        self.title(f"BMI History — {user_name}")
        self.geometry("720x460")
        self.minsize(620, 380)
        self.configure(bg="#F8FAFC")

        self._build_ui()

    def _build_ui(self):
        # Header
        top_bar = tk.Frame(self, bg="#F8FAFC", padx=16, pady=12)
        top_bar.pack(fill="x")

        tk.Label(
            top_bar,
            text=f"Historical Records for '{self.user_name}'",
            font=("Segoe UI", 13, "bold"),
            fg="#0F172A",
            bg="#F8FAFC"
        ).pack(side="left")

        self.lbl_count = tk.Label(
            top_bar,
            text=f"Total: {len(self.records)} entry/entries (Newest first)",
            font=("Segoe UI", 9),
            fg="#64748B",
            bg="#F8FAFC"
        )
        self.lbl_count.pack(side="right")

        # Table frame
        tree_frame = tk.Frame(self, bg="#FFFFFF", padx=16)
        tree_frame.pack(fill="both", expand=True)

        columns = ("id", "date", "weight", "height", "bmi", "category")
        self.tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="browse")

        self.tree.heading("id", text="ID")
        self.tree.heading("date", text="Date & Time")
        self.tree.heading("weight", text="Weight (kg)")
        self.tree.heading("height", text="Height (m)")
        self.tree.heading("bmi", text="BMI")
        self.tree.heading("category", text="Category")

        self.tree.column("id", width=50, anchor="center")
        self.tree.column("date", width=160, anchor="center")
        self.tree.column("weight", width=100, anchor="center")
        self.tree.column("height", width=100, anchor="center")
        self.tree.column("bmi", width=90, anchor="center")
        self.tree.column("category", width=130, anchor="center")

        # Scrollbar
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self._populate_rows()

        # Bottom actions
        action_bar = tk.Frame(self, bg="#F8FAFC", padx=16, pady=12)
        action_bar.pack(fill="x")

        btn_delete = tk.Button(
            action_bar,
            text="Delete Selected Record",
            font=("Segoe UI", 9),
            bg="#EF4444",
            fg="#FFFFFF",
            relief="flat",
            padx=12,
            pady=6,
            cursor="hand2",
            command=self.on_delete_selected
        )
        btn_delete.pack(side="left")

        btn_close = tk.Button(
            action_bar,
            text="Close Window",
            font=("Segoe UI", 9),
            bg="#E2E8F0",
            fg="#1E293B",
            relief="flat",
            padx=12,
            pady=6,
            cursor="hand2",
            command=self.destroy
        )
        btn_close.pack(side="right")

    def _populate_rows(self):
        """Populate Treeview with user records."""
        for item in self.tree.get_children():
            self.tree.delete(item)

        if not self.records:
            self.tree.insert("", "end", values=("-", "No records found for this user", "-", "-", "-", "-"))
            return

        for r in self.records:
            self.tree.insert(
                "",
                "end",
                values=(
                    r["id"],
                    r["recorded_at"],
                    f"{r['weight_kg']:.1f}",
                    f"{r['height_m']:.2f}",
                    f"{r['bmi']:.2f}",
                    r["category"]
                )
            )

    def on_delete_selected(self):
        """Delete currently highlighted record."""
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo("Select Record", "Please select a row in the table to delete.")
            return

        item = self.tree.item(selected[0])
        val = item["values"]
        rec_id = val[0]

        if rec_id == "-":
            return

        confirm = messagebox.askyesno(
            "Confirm Deletion",
            f"Are you sure you want to delete record #{rec_id}?"
        )
        if confirm:
            try:
                database.delete_record(int(rec_id))
                self.records = [r for r in self.records if r["id"] != int(rec_id)]
                self._populate_rows()
                self.lbl_count.config(text=f"Total: {len(self.records)} entry/entries (Newest first)")
                if self.on_records_changed:
                    self.on_records_changed(self.user_name)
            except Exception as e:
                messagebox.showerror("Delete Failed", f"Could not delete record:\n{str(e)}")


class TrendChartWindow(tk.Toplevel):
    """
    Sub-window embedding a Matplotlib trend chart into a Tkinter window.
    """

    def __init__(self, parent, user_name: str, records: list):
        super().__init__(parent)
        self.title(f"BMI History Trend — {user_name}")
        self.geometry("860x580")
        self.minsize(740, 500)
        self.configure(bg="#FFFFFF")

        self._render_chart(user_name, records)

    def _render_chart(self, user_name: str, records: list):
        try:
            fig = history_chart.create_trend_figure(records, user_name)
            canvas = FigureCanvasTkAgg(fig, master=self)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.pack(side="bottom", fill="x")
        except Exception as e:
            messagebox.showerror("Chart Error", f"Unable to generate trend chart:\n{str(e)}")


def main():
    """Application entry point."""
    root = tk.Tk()
    app = BMITrackerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
