"""
BMI History Visualization Module using Matplotlib
OIBSIP Python Programming Internship - Task 2

This module provides:
1. Chronological time-series plotting of user BMI measurements
2. Horizontal WHO threshold reference lines (18.5, 25.0, 30.0)
3. Shaded visual reference zones for Underweight, Normal, Overweight, Obese
4. Embeddable Figure generation for Tkinter GUI (FigureCanvasTkAgg)
5. Informative handling for users with fewer than 2 records
"""

from datetime import datetime
from typing import List, Dict, Any, Optional

try:
    import matplotlib
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    from matplotlib.figure import Figure
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False


def create_trend_figure(records: List[Dict[str, Any]], user_name: str) -> Any:
    """
    Generate a Matplotlib Figure object representing the user's BMI trend.
    Returns a Figure instance suitable for embedding in a Tkinter canvas
    or displaying in a standalone window.

    Requirements addressed:
    - Chronological sorting of dates on the X-axis
    - BMI values on the Y-axis
    - Line plot with marked points ('-o')
    - Horizontal reference lines for BMI 18.5, 25, 30
    - Informative display if records < 2

    Args:
        records: List of record dicts containing 'recorded_at', 'bmi', 'weight_kg'
        user_name: Profile name being plotted

    Returns:
        matplotlib.figure.Figure: Configured figure
    """
    if not MATPLOTLIB_AVAILABLE:
        raise ImportError(
            "Matplotlib is not installed. Run 'pip install matplotlib' to enable trend charts."
        )

    # Use a clean, modern aesthetic
    fig = Figure(figsize=(8.5, 5.2), dpi=100)
    ax = fig.add_subplot(111)

    # Check for sufficient records
    if len(records) < 2:
        ax.text(
            0.5, 0.5,
            f"Insufficient records for '{user_name}'.\n\n"
            f"You currently have {len(records)} record(s).\n"
            "At least 2 historical calculations are needed\n"
            "to plot a meaningful trend line over time.\n\n"
            "Calculate and save another BMI reading to view your trend!",
            horizontalalignment='center',
            verticalalignment='center',
            transform=ax.transAxes,
            fontsize=12,
            color='#475569',
            fontweight='medium',
            bbox=dict(boxstyle='round,pad=1', facecolor='#F1F5F9', edgecolor='#CBD5E1')
        )
        ax.set_title(f"BMI History Trend — {user_name}", fontsize=14, fontweight='bold', pad=15)
        ax.set_xticks([])
        ax.set_yticks([])
        fig.tight_layout()
        return fig

    # 1. Sort records chronologically (oldest to newest)
    sorted_records = sorted(records, key=lambda r: r['recorded_at'])

    dates = []
    bmis = []
    weights = []

    for r in sorted_records:
        try:
            dt = datetime.strptime(r['recorded_at'], "%Y-%m-%d %H:%M:%S")
        except ValueError:
            try:
                dt = datetime.fromisoformat(r['recorded_at'])
            except Exception:
                dt = datetime.now()
        dates.append(dt)
        bmis.append(float(r['bmi']))
        weights.append(float(r['weight_kg']))

    # 2. Determine Y-axis limits dynamically with margin
    min_bmi = min(bmis)
    max_bmi = max(bmis)
    y_bottom = max(14.0, min(min_bmi - 2.0, 17.0))
    y_top = max(34.0, max(max_bmi + 2.5, 31.0))

    ax.set_ylim(y_bottom, y_top)

    # 3. Reference category threshold lines and background zones
    # Background zones with soft accessible colors
    ax.axhspan(y_bottom, 18.5, color='#DBEAFE', alpha=0.45, label='Underweight (<18.5)')
    ax.axhspan(18.5, 25.0, color='#DCFCE7', alpha=0.45, label='Normal Range (18.5–24.9)')
    ax.axhspan(25.0, 30.0, color='#FEF3C7', alpha=0.45, label='Overweight (25–29.9)')
    ax.axhspan(30.0, y_top, color='#FEE2E2', alpha=0.45, label='Obese (≥30.0)')

    # Clear threshold marker lines
    ax.axhline(18.5, color='#2563EB', linestyle='--', linewidth=1.2, alpha=0.7)
    ax.axhline(25.0, color='#16A34A', linestyle='--', linewidth=1.2, alpha=0.7)
    ax.axhline(30.0, color='#DC2626', linestyle='--', linewidth=1.2, alpha=0.7)

    # 4. Plot the user's BMI trajectory
    ax.plot(
        dates, bmis,
        color='#0F172A',
        linewidth=2.2,
        marker='o',
        markersize=6.5,
        markerfacecolor='#2563EB',
        markeredgecolor='#0F172A',
        markeredgewidth=1.2,
        label=f"BMI Track ({user_name})",
        zorder=5
    )

    # 5. Add value annotations above each data point
    for d, b, w in zip(dates, bmis, weights):
        ax.annotate(
            f"{b:.1f}\n({w:.0f}kg)",
            (d, b),
            textcoords="offset points",
            xytext=(0, 10),
            ha='center',
            fontsize=8.5,
            fontweight='semibold',
            color='#1E293B',
            bbox=dict(boxstyle='round,pad=0.2', facecolor='white', edgecolor='#E2E8F0', alpha=0.85),
            zorder=6
        )

    # 6. Formatting titles, grid, and date axes
    ax.set_title(f"BMI Progress & Category History: {user_name}", fontsize=13, fontweight='bold', pad=14, color='#0F172A')
    ax.set_xlabel("Recorded Date & Time", fontsize=10, fontweight='semibold', labelpad=10, color='#334155')
    ax.set_ylabel("Body Mass Index (BMI)", fontsize=10, fontweight='semibold', labelpad=10, color='#334155')

    ax.grid(True, linestyle=':', alpha=0.6, color='#94A3B8')

    # Date formatting on X axis
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %d\n%H:%M'))
    fig.autofmt_xdate(rotation=0, ha='center')

    # Legend placement
    ax.legend(
        loc='upper left',
        bbox_to_anchor=(1.02, 1.0),
        borderaxespad=0,
        fontsize=8.5,
        frameon=True,
        facecolor='white',
        edgecolor='#CBD5E1'
    )

    fig.tight_layout()
    return fig


def show_standalone_trend_chart(records: List[Dict[str, Any]], user_name: str) -> None:
    """
    Open the trend chart in a standalone Matplotlib popup window.
    Useful for testing or running without the Tkinter GUI.
    """
    if not MATPLOTLIB_AVAILABLE:
        print("Error: Matplotlib is not installed. Please run: pip install matplotlib")
        return

    fig = create_trend_figure(records, user_name)
    plt.show()
