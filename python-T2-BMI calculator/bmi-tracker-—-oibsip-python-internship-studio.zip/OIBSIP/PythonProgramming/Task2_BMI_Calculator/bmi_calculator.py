"""
BMI Calculator Logic and Validation Module
OIBSIP Python Programming Internship - Task 2

This module handles:
1. Standard Body Mass Index (BMI) calculations
2. World Health Organization (WHO) category classification
3. Robust input validation and error reporting
4. Educational and clinical health disclaimers
"""

from typing import Tuple, Optional


def calculate_bmi(weight_kg: float, height_m: float) -> float:
    """
    Calculate Body Mass Index (BMI) using the standard metric formula:
    BMI = weight (kg) / (height (m) ** 2)

    Args:
        weight_kg: Weight in kilograms (e.g., 68.5)
        height_m: Height in meters (e.g., 1.72)

    Returns:
        The calculated BMI rounded to 2 decimal places.

    Raises:
        ValueError: If height is zero or negative, or weight is negative.
    """
    if height_m <= 0:
        raise ValueError("Height must be greater than zero.")
    if weight_kg <= 0:
        raise ValueError("Weight must be greater than zero.")

    bmi = weight_kg / (height_m ** 2)
    return round(bmi, 2)


def classify_bmi(bmi: float) -> Tuple[str, str, str]:
    """
    Classify a given BMI value into adult categories as specified by the task
    and standard WHO / health guidelines.

    Category Thresholds:
    - Underweight: BMI below 18.5 (< 18.5)
    - Normal:      BMI from 18.5 up to, but not including, 25 (18.5 <= BMI < 25.0)
    - Overweight:  BMI from 25 up to, but not including, 30 (25.0 <= BMI < 30.0)
    - Obese:       BMI of 30 or higher (BMI >= 30.0)

    Args:
        bmi: Body Mass Index value (float)

    Returns:
        Tuple containing:
        - Category name (str)
        - Hex color code for GUI display (str)
        - Educational summary description (str)
    """
    if bmi < 18.5:
        category = "Underweight"
        color = "#2563EB"  # Accessible Royal Blue
        description = "Below standard weight range. Consider consulting a nutritionist."
    elif bmi < 25.0:
        category = "Normal"
        color = "#16A34A"  # Accessible Forest Green
        description = "Within the healthy reference weight range for adults."
    elif bmi < 30.0:
        category = "Overweight"
        color = "#D97706"  # Accessible Amber/Orange
        description = "Above standard weight range. Regular exercise is recommended."
    else:
        category = "Obese"
        color = "#DC2626"  # Accessible Crimson Red
        description = "Significantly above reference range. Medical consultation advised."

    return category, color, description


def validate_inputs(user_name: str, weight_str: str, height_str: str) -> Tuple[bool, str, Optional[float], Optional[float]]:
    """
    Validate user inputs before processing or database insertion.

    Validation Rules:
    1. User name must not be empty or contain only whitespace.
    2. Weight must be a valid numeric float greater than 0.
    3. Height must be a valid numeric float greater than 0.
    4. Plausibility sanity checks:
       - Height entered in centimeters (> 3.0 m) triggers a helpful conversion hint.
       - Extreme weights (< 10 kg or > 500 kg) warn the user without silently crashing.

    Args:
        user_name: Name entered by the user
        weight_str: Weight string from entry field
        height_str: Height string from entry field

    Returns:
        Tuple of (is_valid: bool, error_message: str, weight_val: float, height_val: float)
    """
    # 1. User name check
    clean_name = user_name.strip()
    if not clean_name:
        return False, "Please enter your name. The user name cannot be empty.", None, None

    if len(clean_name) > 60:
        return False, "User name is too long. Please keep it under 60 characters.", None, None

    # 2. Weight numeric validation
    if not weight_str.strip():
        return False, "Weight field is empty. Please enter your weight in kilograms (kg).", None, None

    try:
        weight_val = float(weight_str.strip())
    except ValueError:
        return False, f"Invalid weight: '{weight_str}'. Weight must be a numeric value (e.g., 65.5).", None, None

    if weight_val <= 0:
        return False, "Weight must be strictly greater than 0 kg.", None, None

    if weight_val < 10 or weight_val > 500:
        return False, f"Weight of {weight_val} kg is outside the plausible adult range (10 kg - 500 kg). Please verify.", None, None

    # 3. Height numeric validation
    if not height_str.strip():
        return False, "Height field is empty. Please enter your height in meters (e.g., 1.70).", None, None

    try:
        height_val = float(height_str.strip())
    except ValueError:
        return False, f"Invalid height: '{height_str}'. Height must be a numeric value in meters (e.g., 1.65).", None, None

    if height_val <= 0:
        return False, "Height must be strictly greater than 0 meters.", None, None

    # Common beginner pitfall: typing height in centimeters (e.g., 165 instead of 1.65)
    if height_val > 3.0:
        converted_height = height_val / 100.0
        return False, (
            f"Height entered ({height_val}) appears to be in centimeters.\n"
            f"Please enter height in meters (e.g., {converted_height:.2f} m instead of {height_val:g} cm)."
        ), None, None

    if height_val < 0.5:
        return False, f"Height of {height_val} m is unusually low for adult calculations. Please verify your height.", None, None

    return True, "", weight_val, height_val


def get_healthy_weight_range(height_m: float) -> Tuple[float, float]:
    """
    Calculate the healthy weight range (BMI 18.5 to 24.99) for a given height.
    Formula: weight = BMI * (height ** 2)

    Args:
        height_m: Height in meters

    Returns:
        Tuple of (min_healthy_weight, max_healthy_weight) rounded to 1 decimal place.
    """
    min_weight = 18.5 * (height_m ** 2)
    max_weight = 24.9 * (height_m ** 2)
    return round(min_weight, 1), round(max_weight, 1)


# Medical disclaimer text for GUI and reports
MEDICAL_DISCLAIMER = (
    "Note: BMI is an anthropometric screening indicator, not a comprehensive clinical diagnostic tool. "
    "It does not differentiate between fat mass and muscle mass (athletes may have high BMI with low body fat). "
    "These adult thresholds are not intended for pediatric evaluation or specific medical diagnoses. "
    "Always consult a qualified healthcare professional for medical assessments."
)
