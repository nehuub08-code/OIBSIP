"""
SQLite Database Module for BMI Tracker
OIBSIP Python Programming Internship - Task 2

This module handles:
1. Automated SQLite database initialization and table schema creation.
2. Secure parameterized SQL INSERT operations (preventing SQL injection).
3. Filtered retrieval of historical records by user name (newest first).
4. Safe connection management with Python's context manager (with sqlite3.connect).
"""

import os
import sqlite3
from datetime import datetime
from typing import List, Dict, Any, Optional

# Default database filename in the same directory as this module
DB_FILENAME = "bmi_history.db"


def get_db_path(custom_path: Optional[str] = None) -> str:
    """
    Get the absolute path to the SQLite database file.
    Ensures the database file is saved locally in the project directory
    regardless of the current working directory from where the script is executed.
    """
    if custom_path:
        return custom_path
    base_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_dir, DB_FILENAME)


def init_db(db_path: Optional[str] = None) -> None:
    """
    Initialize the SQLite database and create the 'bmi_records' table if it doesn't exist.

    Table Schema:
    - id: INTEGER PRIMARY KEY AUTOINCREMENT (Unique serial identifier for each record)
    - user_name: TEXT NOT NULL (Profile name of the user)
    - weight_kg: REAL NOT NULL (User's weight in kilograms)
    - height_m: REAL NOT NULL (User's height in meters)
    - bmi: REAL NOT NULL (Calculated Body Mass Index)
    - category: TEXT NOT NULL (Assigned BMI category: Underweight, Normal, Overweight, Obese)
    - recorded_at: TEXT NOT NULL (ISO timestamp: YYYY-MM-DD HH:MM:SS)

    Why SQL CREATE TABLE IF NOT EXISTS?
    It guarantees safety on application launch: if the file or table exists, existing
    records remain untouched; if not, it seamlessly creates the schema.
    """
    path = get_db_path(db_path)
    with sqlite3.connect(path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS bmi_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_name TEXT NOT NULL,
                weight_kg REAL NOT NULL,
                height_m REAL NOT NULL,
                bmi REAL NOT NULL,
                category TEXT NOT NULL,
                recorded_at TEXT NOT NULL
            )
            """
        )
        # Create an index on user_name for fast lookups in multi-user environments
        cursor.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_bmi_user
            ON bmi_records (user_name)
            """
        )
        conn.commit()


def save_record(
    user_name: str,
    weight_kg: float,
    height_m: float,
    bmi: float,
    category: str,
    recorded_at: Optional[str] = None,
    db_path: Optional[str] = None
) -> int:
    """
    Insert a new valid BMI calculation into the SQLite database.

    IMPORTANT SECURITY NOTE (Parameterized Queries):
    We use placeholders (?) instead of Python string formatting (f-strings).
    This completely prevents SQL Injection attacks by ensuring user input is
    treated strictly as data values, not executable SQL syntax.

    Args:
        user_name: Name of the user profile
        weight_kg: Measured weight in kilograms
        height_m: Measured height in meters
        bmi: Calculated BMI
        category: Classified BMI category
        recorded_at: Optional custom timestamp string (defaults to current local time)
        db_path: Optional custom database path (useful for testing)

    Returns:
        The generated record id (int)
    """
    if recorded_at is None:
        recorded_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    clean_name = user_name.strip()
    path = get_db_path(db_path)

    with sqlite3.connect(path) as conn:
        cursor = conn.cursor()
        query = """
            INSERT INTO bmi_records (user_name, weight_kg, height_m, bmi, category, recorded_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """
        cursor.execute(query, (clean_name, weight_kg, height_m, bmi, category, recorded_at))
        conn.commit()
        return cursor.lastrowid


def get_user_history(user_name: str, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Fetch all historical records for a specific user name, ordered newest first.

    Case-insensitive matching is performed (e.g. 'Rahul' matches 'rahul') to ensure
    consistent profile retrieval for users typing with varied capitalization.

    Args:
        user_name: The user's name
        db_path: Optional custom database path

    Returns:
        A list of record dictionaries with keys:
        ['id', 'user_name', 'weight_kg', 'height_m', 'bmi', 'category', 'recorded_at']
    """
    clean_name = user_name.strip()
    path = get_db_path(db_path)

    with sqlite3.connect(path) as conn:
        conn.row_factory = sqlite3.Row  # Enables column-access by dictionary key
        cursor = conn.cursor()
        query = """
            SELECT id, user_name, weight_kg, height_m, bmi, category, recorded_at
            FROM bmi_records
            WHERE LOWER(TRIM(user_name)) = LOWER(TRIM(?))
            ORDER BY datetime(recorded_at) DESC, id DESC
        """
        cursor.execute(query, (clean_name,))
        rows = cursor.fetchall()
        return [dict(row) for row in rows]


def get_all_users(db_path: Optional[str] = None) -> List[str]:
    """
    Retrieve a list of all distinct user profile names currently stored in the database.
    Useful for profile dropdowns or autocomplete in GUI.
    """
    path = get_db_path(db_path)
    with sqlite3.connect(path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT DISTINCT user_name
            FROM bmi_records
            ORDER BY user_name ASC
            """
        )
        rows = cursor.fetchall()
        return [r[0] for r in rows if r[0]]


def delete_record(record_id: int, db_path: Optional[str] = None) -> bool:
    """
    Delete a specific record by its primary key ID.
    Returns True if a row was deleted, False otherwise.
    """
    path = get_db_path(db_path)
    with sqlite3.connect(path) as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM bmi_records WHERE id = ?", (record_id,))
        conn.commit()
        return cursor.rowcount > 0
