# BMI Tracker — Personal BMI Calculator
### Oasis Infobyte (OIBSIP) Python Programming Internship — Task 2

A desktop graphical application that calculates Body Mass Index (BMI) from a user's weight and height, categorizes the result according to adult health thresholds, stores historical calculations for multiple named profiles in an SQLite database, and visualizes progress over time with Matplotlib trend charts.

---

## 1. Project Overview

Body Mass Index (BMI) is a recognized screening tool used by healthcare and fitness organizations worldwide to assess whether an adult has a healthy body weight in proportion to their height.

This project was developed as part of the **Oasis Infobyte Internship in Python Programming (OIBSIP)** under **Task 2: BMI Calculator**. It provides a desktop application with a clean Tkinter graphical interface, input validation, local database persistence, and trend visualization.

---

## 2. Objectives

- Develop a modular Python application following clean code and software engineering principles.
- Implement the standard metric BMI calculation formula rounded to two decimal places.
- Classify BMI values into four adult categories (Underweight, Normal, Overweight, Obese) with visual color cues.
- Safeguard against runtime crashes through thorough input validation (preventing non-numeric values, negative numbers, or empty entries).
- Implement persistent, multi-user historical record storage using Python's built-in `sqlite3` library with parameterized queries to prevent SQL injection.
- Visualize individual user historical trends using `matplotlib`, displaying category reference thresholds.
- Maintain automated unit tests covering calculations, boundary conditions, input sanitization, and database isolation.

---

## 3. Features

1. **User Profile Support**: Enter your name to calculate and track your personal BMI records over multiple sessions.
2. **Instant Calculation & Classification**: Computes BMI and immediately provides color-coded feedback (Blue, Green, Orange, Red) and practical health guidance.
3. **Healthy Weight Recommendation**: Calculates the target healthy weight range (BMI 18.5 – 24.9) specifically tailored to the user's height.
4. **Input Sanitization & Error Handling**: Rejects negative numbers, zero values, letters, empty fields, and provides intelligent hints (such as detecting height entered in centimeters instead of meters).
5. **SQLite Database Storage**: Automatically creates and maintains `bmi_history.db` locally.
6. **History Explorer**: A dedicated window built with `ttk.Treeview` to view all previous calculations for the active user, sorted with newest entries first.
7. **BMI Trend Chart**: Visualizes progress chronologically with a line plot, data point markers, and horizontal WHO category threshold lines.
8. **Multi-User Privacy Isolation**: Historical queries only return records matching the entered profile name.
9. **Zero-Setup CLI Mode**: Includes a terminal CLI script (`cli_demo.py`) for environments without a desktop display server.

---

## 4. BMI Formula & Logic

The application uses the internationally recognized metric formula:

$$\text{BMI} = \frac{\text{Weight (kg)}}{\text{Height (m)}^2}$$

### Worked Example:
- **Weight**: 60.0 kg
- **Height**: 1.65 m
- **Calculation**: $\text{BMI} = \frac{60.0}{1.65^2} = \frac{60.0}{2.7225} \approx 22.04$

Result: **22.04** (Classified as **Normal**).

---

## 5. BMI Category Thresholds

| Category | BMI Range | Visual Display | Assessment & Action |
| :--- | :--- | :--- | :--- |
| **Underweight** | $\text{BMI} < 18.5$ | Royal Blue (`#2563EB`) | Below standard weight range; nutritional consultation advised. |
| **Normal** | $18.5 \le \text{BMI} < 25.0$ | Forest Green (`#16A34A`) | Healthy adult weight range; maintain balanced lifestyle. |
| **Overweight** | $25.0 \le \text{BMI} < 30.0$ | Amber Orange (`#D97706`) | Above standard weight range; regular physical exercise advised. |
| **Obese** | $\text{BMI} \ge 30.0$ | Crimson Red (`#DC2626`) | Significantly elevated; medical consultation advised. |

> **Important Clinical Note**: BMI is an anthropometric screening indicator, not a complete diagnostic test. It does not measure body fat directly and does not distinguish between lean muscle tissue and adipose tissue. Athletes and bodybuilders may have high BMI due to increased muscle density. Furthermore, pediatric populations (children/teens) require age-and-gender percentile curves (CDC/WHO growth charts), not adult cutoff thresholds.

---

## 6. Technologies Used

- **Python 3.8+**: Core programming language.
- **Tkinter & TTK**: Built-in Python graphical user interface toolkit used for window management, styling, and the `ttk.Treeview` data table.
- **SQLite3**: Built-in ACID-compliant relational database engine used for local, zero-configuration data storage.
- **Matplotlib**: Used for plotting historical BMI trend lines, reference bands, and date-axis formatting.
- **Unittest**: Python standard testing framework for unit and integration testing.

---

## 7. Folder Structure

```text
OIBSIP/
└── PythonProgramming/
    └── Task2_BMI_Calculator/
        ├── main.py              # Tkinter GUI desktop application
        ├── bmi_calculator.py    # Core formula, category classification & validation
        ├── database.py          # SQLite database schema & parameterized queries
        ├── history_chart.py     # Matplotlib trend line plotting & thresholds
        ├── cli_demo.py          # Standalone command-line demo (no GUI required)
        ├── test_bmi.py          # 26 automated unit and integration tests
        ├── requirements.txt     # External Python dependencies (matplotlib)
        ├── .gitignore           # Ignores database files (*.db), caches, and venv
        └── README.md            # Complete project documentation
```

---

## 8. Installation Instructions

### Prerequisites
1. Ensure Python 3.8 or higher is installed on your computer:
   ```bash
   python --version
   ```

2. *(Linux users only)* On Ubuntu or Debian, verify that Python Tkinter is installed:
   ```bash
   sudo apt-get update
   sudo apt-get install python3-tk
   ```
   *(Windows and macOS Python installers from python.org include Tkinter by default).*

### Setup Virtual Environment (Recommended)
```bash
# Navigate to the project directory
cd OIBSIP/PythonProgramming/Task2_BMI_Calculator

# Create a virtual environment named 'venv'
python -m venv venv

# Activate the virtual environment:
# On Windows:
venv\Scripts\activate
# On macOS / Linux:
source venv/bin/activate

# Install required external dependencies:
pip install -r requirements.txt
```

---

## 9. How to Run the Application

### 1. Launch the Desktop GUI Application
```bash
python main.py
```

### 2. Launch the Terminal CLI Demonstration (Headless / No Display)
```bash
python cli_demo.py
```

### 3. Execute the Automated Test Suite
```bash
python test_bmi.py
```

---

## 10. How Records Are Stored

Records are stored in a local SQLite database named `bmi_history.db` within the project folder.

### Database Schema (`bmi_records` table)

| Column Name | SQL Data Type | Description |
| :--- | :--- | :--- |
| `id` | `INTEGER PRIMARY KEY AUTOINCREMENT` | Unique identifier for each record |
| `user_name` | `TEXT NOT NULL` | Profile name of the user |
| `weight_kg` | `REAL NOT NULL` | Recorded weight in kilograms |
| `height_m` | `REAL NOT NULL` | Recorded height in meters |
| `bmi` | `REAL NOT NULL` | Calculated BMI rounded to 2 decimal places |
| `category` | `TEXT NOT NULL` | Assigned category (Underweight/Normal/Overweight/Obese) |
| `recorded_at`| `TEXT NOT NULL` | Timestamp formatted as `YYYY-MM-DD HH:MM:SS` |

### Parameterized SQL Queries (Security)
To prevent SQL Injection vulnerabilities, all queries use parameter placeholders (`?`):
```python
# Safe parameterized query
cursor.execute(
    "INSERT INTO bmi_records (user_name, weight_kg, height_m, bmi, category, recorded_at) VALUES (?, ?, ?, ?, ?, ?)",
    (user_name, weight_kg, height_m, bmi, category, recorded_at)
)
```

---

## 11. How to View History and Trends

1. Enter your name in the **Full Name / User Profile** field.
2. Click **"View History Table"**:
   - Opens a window showing your historical records with timestamp, weight, height, BMI, and category.
   - Shows the newest entries at the top.
   - Allows selecting and deleting an unwanted entry.
3. Click **"Show BMI Trend Chart"**:
   - Requires at least 2 historical calculations for the active profile.
   - Generates an interactive Matplotlib chart displaying your BMI trajectory over time against the standard threshold boundary lines (18.5, 25.0, 30.0).

---

## 12. Example Usage Walkthrough

1. **Profile Setup**: Type `Aditi Sharma` in the User Profile field.
2. **First Measurement**:
   - Enter `54.0` in Weight (kg).
   - Enter `1.62` in Height (m).
   - Click **Calculate & Save BMI**.
   - Output: `BMI: 20.58` · Category: `NORMAL` (Green badge).
3. **Second Measurement (e.g., after 2 months)**:
   - Enter `56.5` in Weight (kg).
   - Enter `1.62` in Height (m).
   - Click **Calculate & Save BMI**.
   - Output: `BMI: 21.53` · Category: `NORMAL`.
4. **View History**: Click **View History Table** to verify both records appear chronologically.
5. **View Trend**: Click **Show BMI Trend Chart** to view the connected trajectory showing healthy maintenance within the green zone.

---

## 13. Testing Instructions & Results

The project includes an automated test suite in `test_bmi.py`. To run all tests:

```bash
python test_bmi.py
```

### Verified Test Cases (26 Tests Passed):
- `test_standard_example`: Weight 60 kg, height 1.65 m correctly evaluates to 22.04 (Normal).
- `test_just_below_18_5`: 18.49 evaluates to Underweight.
- `test_exact_18_5`: 18.50 evaluates to Normal.
- `test_just_below_25_0`: 24.99 evaluates to Normal.
- `test_exact_25_0`: 25.00 evaluates to Overweight.
- `test_just_below_30_0`: 29.99 evaluates to Overweight.
- `test_exact_30_0`: 30.00 evaluates to Obese.
- `test_severely_obese`: 38.5 evaluates to Obese.
- `test_empty_user_name`: Rejects empty or whitespace-only names.
- `test_non_numeric_weight` & `test_non_numeric_height`: Rejects alphabetical characters.
- `test_zero_weight` & `test_zero_height`: Rejects zero values.
- `test_negative_weight` & `test_negative_height`: Rejects negative values.
- `test_height_in_centimeters_caught`: Detects inputs > 3.0 m and prompts conversion.
- `test_save_and_retrieve_record`: Verifies SQLite insertion and querying.
- `test_multi_user_isolation`: Confirms User A cannot view User B's records.
- `test_newest_records_ordered_first`: Verifies DESC order sorting.
- `test_delete_record`: Verifies deletion by primary key.

---

## 14. Limitations & Privacy Notes

- **Privacy**: The database file `bmi_history.db` contains personal health metrics. It is excluded from version control via `.gitignore` and should never be uploaded to public repositories.
- **Profile Identification**: For simplicity in this beginner internship project, user identification is name-based rather than credential-authenticated. Two people using identical names will access the same records.
- **Medical Scope**: This application provides screening numbers only. Clinical decisions should always involve comprehensive assessments (e.g., body composition analysis, blood pressure, lipid panels).

---

## 15. Future Improvements

- Add password-protected profile accounts or PIN authentication.
- Provide toggle for Imperial units (pounds / inches) with automatic metric conversion.
- Export historical records to PDF reports or CSV spreadsheets.
- Add target weight goal planning and daily calorie recommendation guidelines.

---

## 16. Acknowledgment

Developed for the **Oasis Infobyte Internship Program (OIBSIP)** under the **Python Programming Track — Task 2: BMI Calculator**. Sincere gratitude to Oasis Infobyte for providing practical project-based learning opportunities for engineering students.
