# Oasis Infobyte (OIBSIP) — Python Programming Internship

Welcome to my repository for the **Oasis Infobyte Virtual Internship Program (OIBSIP)** in **Python Programming**.

This repository contains my submissions for the assigned internship tasks.

---

## Repository Structure

```text
OIBSIP/
└── PythonProgramming/
    └── Task2_BMI_Calculator/
        ├── main.py              # Tkinter Desktop GUI application
        ├── bmi_calculator.py    # Metric BMI calculation, classification & input validation
        ├── database.py          # SQLite database interface & parameterized SQL queries
        ├── history_chart.py     # Matplotlib trend line plotting & WHO threshold bands
        ├── cli_demo.py          # Command-line interface demo (runs without GUI)
        ├── test_bmi.py          # Automated unit test suite (26 tests passing)
        ├── requirements.txt     # External dependencies (matplotlib)
        ├── .gitignore           # Ignores database files (*.db), caches, and virtual envs
        └── README.md            # In-depth Task 2 documentation
```

---

## Task 2: BMI Calculator (Desktop GUI & Tracker)

- **Track**: Python Programming
- **Task**: Task 2 — BMI Calculator
- **Technologies**: Python 3, Tkinter, SQLite3, Matplotlib, Unittest

### Highlights
1. **Accurate Formula**: Calculates $\text{BMI} = \frac{\text{Weight (kg)}}{\text{Height (m)}^2}$ rounded to 2 decimal places.
2. **WHO Category Classification**: Underweight ($<18.5$), Normal ($18.5 - 24.9$), Overweight ($25.0 - 29.9$), and Obese ($\ge 30.0$).
3. **Desktop Tkinter GUI**: Card-based interface with color-coded feedback and healthy weight range calculation.
4. **SQLite Multi-User Persistence**: Saves calculations per user with parameterized queries to prevent SQL injection.
5. **Interactive History**: View past calculations in a `ttk.Treeview` table, ordered newest first.
6. **Matplotlib Trend Line**: Visualizes BMI trajectory over time with horizontal threshold reference lines.
7. **26 Automated Tests**: Complete verification of boundary calculations, sanitization, and database isolation.

For full setup, installation instructions, formula walkthroughs, and viva guides, please see:
👉 **[`OIBSIP/PythonProgramming/Task2_BMI_Calculator/README.md`](PythonProgramming/Task2_BMI_Calculator/README.md)**

---

### Quick Start
```bash
# Navigate to Task 2 directory
cd PythonProgramming/Task2_BMI_Calculator

# Install dependencies (Matplotlib)
pip install -r requirements.txt

# Run the Desktop Application
python main.py

# Run the Automated Test Suite (26 Tests)
python test_bmi.py
```

---

### Acknowledgment
Sincere gratitude to **Oasis Infobyte (OIBSIP)** for providing this practical internship opportunity to apply software engineering and Python programming skills.
