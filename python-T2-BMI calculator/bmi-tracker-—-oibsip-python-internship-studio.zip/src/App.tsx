import React, { useState, useEffect } from 'react';
import JSZip from 'jszip';
import { BMIRecord } from './types';
import { INITIAL_RECORDS } from './data/defaultData';
import { TkinterSimulator } from './components/TkinterSimulator';
import { CodeExplorer } from './components/CodeExplorer';
import { TestRunner } from './components/TestRunner';
import { TheoryMentor } from './components/TheoryMentor';
import {
  Monitor,
  FileCode2,
  CheckCircle2,
  GraduationCap,
  Download,
  FolderArchive
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'code' | 'tests' | 'mentor'>('simulator');
  const [projectFiles, setProjectFiles] = useState<Record<string, string>>({});
  const [isZipping, setIsZipping] = useState<boolean>(false);

  // Persistent records state
  const [records, setRecords] = useState<BMIRecord[]>(() => {
    try {
      const stored = localStorage.getItem('oibsip_bmi_records_v1');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Failed to parse records from localStorage:', e);
    }
    return INITIAL_RECORDS;
  });

  // Save records to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('oibsip_bmi_records_v1', JSON.stringify(records));
    } catch (e) {
      console.warn('Failed to save records to localStorage:', e);
    }
  }, [records]);

  // Fetch project files
  useEffect(() => {
    fetch('/api/project-files')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.files) {
          setProjectFiles(data.files);
        }
      })
      .catch((err) => console.error('Failed to load project files:', err));
  }, []);

  const handleAddRecord = (newRec: Omit<BMIRecord, 'id'>) => {
    const nextId = records.length > 0 ? Math.max(...records.map((r) => r.id)) + 1 : 1;
    setRecords((prev) => [{ ...newRec, id: nextId }, ...prev]);
  };

  const handleDeleteRecord = (id: number) => {
    setRecords((prev) => prev.filter((r) => r.id !== id));
  };

  const handleDownloadFullZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();
      const folder = zip.folder('OIBSIP')?.folder('PythonProgramming')?.folder('Task2_BMI_Calculator');

      if (folder && Object.keys(projectFiles).length > 0) {
        for (const [name, content] of Object.entries(projectFiles)) {
          folder.file(name, content);
        }
      }

      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'OIBSIP_Task2_BMI_Calculator.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to create zip:', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans">
      {/* Top Bar Contract: Zone 1 (Wordmark) — Zone 2 (Nav Links) — Zone 3 (Primary Action) */}
      <header className="sticky top-0 z-40 flex items-center justify-between gap-8 border-b border-slate-200 bg-white/95 px-6 py-3.5 backdrop-blur-xs">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="/"
          className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span className="h-2 w-2 rounded-full bg-blue-600 inline-block" />
          <span>BMI Tracker · OIBSIP Studio</span>
        </a>

        {/* Zone 2: 4 single-line nav links/tabs */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-600">
          <button
            type="button"
            onClick={() => setActiveTab('simulator')}
            className={`cursor-pointer whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'simulator'
                ? 'text-blue-600 border-b-2 border-blue-600 pb-0.5'
                : 'hover:text-slate-900'
            }`}
          >
            Tkinter Desktop Simulator
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('code')}
            className={`cursor-pointer whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'code'
                ? 'text-blue-600 border-b-2 border-blue-600 pb-0.5'
                : 'hover:text-slate-900'
            }`}
          >
            Source Code Files
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('tests')}
            className={`cursor-pointer whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'tests'
                ? 'text-blue-600 border-b-2 border-blue-600 pb-0.5'
                : 'hover:text-slate-900'
            }`}
          >
            Test Runner (26 Tests)
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('mentor')}
            className={`cursor-pointer whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'mentor'
                ? 'text-blue-600 border-b-2 border-blue-600 pb-0.5'
                : 'hover:text-slate-900'
            }`}
          >
            Student Theory &amp; Viva Guide
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={handleDownloadFullZip}
            disabled={isZipping || Object.keys(projectFiles).length === 0}
            className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-slate-800 transition-colors disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <FolderArchive className="h-3.5 w-3.5" />
            <span>{isZipping ? 'Zipping...' : 'Download Project (.ZIP)'}</span>
          </button>
        </div>
      </header>

      {/* Mobile Tab Bar */}
      <div className="flex md:hidden border-b border-slate-200 bg-white px-4 py-2 overflow-x-auto gap-2">
        <button
          onClick={() => setActiveTab('simulator')}
          className={`px-3 py-1.5 text-xs rounded-md whitespace-nowrap font-medium ${
            activeTab === 'simulator' ? 'bg-blue-600 text-white' : 'text-slate-700 bg-slate-100'
          }`}
        >
          Simulator
        </button>
        <button
          onClick={() => setActiveTab('code')}
          className={`px-3 py-1.5 text-xs rounded-md whitespace-nowrap font-medium ${
            activeTab === 'code' ? 'bg-blue-600 text-white' : 'text-slate-700 bg-slate-100'
          }`}
        >
          Code Files
        </button>
        <button
          onClick={() => setActiveTab('tests')}
          className={`px-3 py-1.5 text-xs rounded-md whitespace-nowrap font-medium ${
            activeTab === 'tests' ? 'bg-blue-600 text-white' : 'text-slate-700 bg-slate-100'
          }`}
        >
          Unit Tests (26)
        </button>
        <button
          onClick={() => setActiveTab('mentor')}
          className={`px-3 py-1.5 text-xs rounded-md whitespace-nowrap font-medium ${
            activeTab === 'mentor' ? 'bg-blue-600 text-white' : 'text-slate-700 bg-slate-100'
          }`}
        >
          Viva Guide
        </button>
      </div>

      {/* Main Workspace Body */}
      <main className="flex-1 py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        {/* Project Context Kicker */}
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-200/80 pb-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
              <span>Oasis Infobyte Internship</span>
              <span>·</span>
              <span>Python Programming Track</span>
              <span>·</span>
              <span className="font-semibold text-slate-700">Task 2: BMI Calculator</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 mt-1">
              {activeTab === 'simulator' && 'Interactive Tkinter Desktop GUI Simulator'}
              {activeTab === 'code' && 'OIBSIP Submission Codebase & File Tree'}
              {activeTab === 'tests' && 'Python Automated Unit Tests Verification'}
              {activeTab === 'mentor' && 'Second-Year Engineering Viva & Architecture Guide'}
            </h1>
          </div>

          <div className="flex items-center gap-1.5 text-xs font-mono text-slate-500">
            <span className="rounded bg-slate-200/70 px-2 py-0.5 text-slate-700">Python 3.10+</span>
            <span className="rounded bg-slate-200/70 px-2 py-0.5 text-slate-700">Tkinter</span>
            <span className="rounded bg-slate-200/70 px-2 py-0.5 text-slate-700">SQLite3</span>
            <span className="rounded bg-slate-200/70 px-2 py-0.5 text-slate-700">Matplotlib</span>
          </div>
        </div>

        {/* Tab 1: Simulator */}
        {activeTab === 'simulator' && (
          <TkinterSimulator
            records={records}
            onAddRecord={handleAddRecord}
            onDeleteRecord={handleDeleteRecord}
          />
        )}

        {/* Tab 2: Code Explorer */}
        {activeTab === 'code' && (
          <CodeExplorer initialFiles={projectFiles} />
        )}

        {/* Tab 3: Test Runner */}
        {activeTab === 'tests' && (
          <TestRunner />
        )}

        {/* Tab 4: Student Theory & Viva Guide */}
        {activeTab === 'mentor' && (
          <TheoryMentor />
        )}
      </main>

      {/* Quiet Clean Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>
            Oasis Infobyte (OIBSIP) Python Programming Internship · Task 2 BMI Calculator
          </p>
          <p className="font-mono text-[11px] text-slate-400">
            Repository Path: <code className="text-slate-600">OIBSIP/PythonProgramming/Task2_BMI_Calculator/</code>
          </p>
        </div>
      </footer>
    </div>
  );
}
