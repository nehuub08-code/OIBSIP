import React, { useState } from 'react';
import { BMIRecord } from '../types';
import { X, ZoomIn, ZoomOut, RotateCcw, Download, Info } from 'lucide-react';

interface TrendChartModalProps {
  userName: string;
  records: BMIRecord[];
  isOpen: boolean;
  onClose: () => void;
}

export const TrendChartModal: React.FC<TrendChartModalProps> = ({
  userName,
  records,
  isOpen,
  onClose,
}) => {
  const [hoveredPoint, setHoveredPoint] = useState<{
    date: string;
    bmi: number;
    weight: number;
    category: string;
    x: number;
    y: number;
  } | null>(null);

  if (!isOpen) return null;

  // Filter for matching user name
  const userRecords = records.filter(
    (r) => r.user_name.trim().toLowerCase() === userName.trim().toLowerCase()
  );

  // Chronological order (oldest to newest for plotting)
  const sortedRecords = [...userRecords].sort(
    (a, b) => new Date(a.recorded_at).getTime() - new Date(b.recorded_at).getTime()
  );

  const hasInsufficientData = sortedRecords.length < 2;

  // SVG Chart Dimensions
  const width = 740;
  const height = 400;
  const padding = { top: 40, right: 140, bottom: 60, left: 60 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  // Calculate dynamic Y-axis bounds (BMI range)
  const bmiValues = sortedRecords.map((r) => r.bmi);
  const minBmi = Math.min(...(bmiValues.length ? bmiValues : [18.5]));
  const maxBmi = Math.max(...(bmiValues.length ? bmiValues : [25.0]));
  const yMin = Math.max(14.0, Math.floor(Math.min(minBmi - 2.0, 16.0)));
  const yMax = Math.max(34.0, Math.ceil(Math.max(maxBmi + 2.5, 32.0)));

  // Coordinate scales
  const getY = (bmi: number) => {
    return padding.top + chartHeight - ((bmi - yMin) / (yMax - yMin)) * chartHeight;
  };

  const getX = (index: number) => {
    if (sortedRecords.length <= 1) return padding.left + chartWidth / 2;
    return padding.left + (index / (sortedRecords.length - 1)) * chartWidth;
  };

  // Build SVG path for line
  const points = sortedRecords.map((r, i) => ({
    x: getX(i),
    y: getY(r.bmi),
    record: r,
  }));

  const pathD = points.reduce((acc, curr, idx) => {
    return idx === 0 ? `M ${curr.x} ${curr.y}` : `${acc} L ${curr.x} ${curr.y}`;
  }, '');

  // Category bands
  const yUnderweightTop = getY(18.5);
  const yNormalTop = getY(25.0);
  const yOverweightTop = getY(30.0);
  const yChartBottom = getY(yMin);
  const yChartTop = getY(yMax);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
      <div className="w-full max-w-4xl overflow-hidden rounded-xl border border-slate-300 bg-white shadow-2xl">
        {/* Matplotlib Window Titlebar */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-100 px-4 py-2.5">
          <div className="flex items-center gap-2">
            <span className="h-3 w-3 rounded-full bg-rose-400" />
            <span className="h-3 w-3 rounded-full bg-amber-400" />
            <span className="h-3 w-3 rounded-full bg-emerald-400" />
            <span className="ml-2 font-mono text-xs font-semibold text-slate-700">
              FigureCanvasTkAgg — Matplotlib: BMI Progress ({userName})
            </span>
          </div>
          <button
            onClick={onClose}
            className="rounded p-1 text-slate-500 hover:bg-slate-200 hover:text-slate-800"
            title="Close Chart"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Matplotlib Simulated Toolbar */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-4 py-2 text-xs text-slate-600">
          <div className="flex items-center gap-1 font-mono">
            <span className="text-slate-400 mr-2 text-[11px]">NavigationToolbar2Tk:</span>
            <button className="flex items-center gap-1 rounded px-2 py-1 hover:bg-slate-200 text-slate-700">
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Reset</span>
            </button>
            <button className="flex items-center gap-1 rounded px-2 py-1 hover:bg-slate-200 text-slate-700">
              <ZoomIn className="h-3.5 w-3.5" />
              <span>Zoom</span>
            </button>
            <button className="flex items-center gap-1 rounded px-2 py-1 hover:bg-slate-200 text-slate-700">
              <ZoomOut className="h-3.5 w-3.5" />
              <span>Pan</span>
            </button>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-[11px] text-slate-500 font-mono">
              X: Date/Time · Y: BMI Value
            </span>
          </div>
        </div>

        {/* Chart Content Area */}
        <div className="p-6 bg-white flex flex-col items-center">
          {hasInsufficientData ? (
            <div className="my-10 flex max-w-md flex-col items-center rounded-xl border border-slate-200 bg-slate-50 p-8 text-center">
              <div className="mb-4 rounded-full bg-amber-100 p-3 text-amber-600">
                <Info className="h-6 w-6" />
              </div>
              <h4 className="text-base font-semibold text-slate-800">
                Insufficient Historical Records for &quot;{userName}&quot;
              </h4>
              <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                You currently have <strong>{sortedRecords.length} record(s)</strong>.
                At least <strong>2 records</strong> recorded on different dates are required
                to calculate and visualize a meaningful BMI trend line.
              </p>
              <div className="mt-4 rounded-lg bg-white p-3 text-left border border-slate-200 text-xs text-slate-700 font-mono w-full">
                💡 <span className="font-semibold">Tip for testing:</span> Select preset profile &quot;Aditi Sharma&quot; or &quot;Rahul Verma&quot; to inspect an active multi-month progress trend chart.
              </div>
            </div>
          ) : (
            <div className="relative w-full overflow-x-auto">
              <svg viewBox={`0 0 ${width} ${height}`} className="w-full max-w-full font-mono text-[11px] select-none">
                <defs>
                  {/* Subtle shadows and markers */}
                  <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
                    <feDropShadow dx="0" dy="1" stdDeviation="1" floodColor="#0F172A" floodOpacity="0.15" />
                  </filter>
                </defs>

                {/* 1. Category Background Reference Zones */}
                {/* Obese Zone: above 30.0 */}
                <rect
                  x={padding.left}
                  y={yChartTop}
                  width={chartWidth}
                  height={Math.max(0, yOverweightTop - yChartTop)}
                  fill="#FEE2E2"
                  opacity="0.4"
                />
                {/* Overweight Zone: 25.0 to 30.0 */}
                <rect
                  x={padding.left}
                  y={yOverweightTop}
                  width={chartWidth}
                  height={Math.max(0, yNormalTop - yOverweightTop)}
                  fill="#FEF3C7"
                  opacity="0.4"
                />
                {/* Normal Zone: 18.5 to 25.0 */}
                <rect
                  x={padding.left}
                  y={yNormalTop}
                  width={chartWidth}
                  height={Math.max(0, yUnderweightTop - yNormalTop)}
                  fill="#DCFCE7"
                  opacity="0.4"
                />
                {/* Underweight Zone: below 18.5 */}
                <rect
                  x={padding.left}
                  y={yUnderweightTop}
                  width={chartWidth}
                  height={Math.max(0, yChartBottom - yUnderweightTop)}
                  fill="#DBEAFE"
                  opacity="0.4"
                />

                {/* 2. Grid Lines */}
                {[15, 18.5, 20, 22, 25, 28, 30, 32].map((bmiVal) => {
                  if (bmiVal < yMin || bmiVal > yMax) return null;
                  const y = getY(bmiVal);
                  const isBoundary = bmiVal === 18.5 || bmiVal === 25.0 || bmiVal === 30.0;
                  return (
                    <g key={bmiVal}>
                      <line
                        x1={padding.left}
                        y1={y}
                        x2={padding.left + chartWidth}
                        y2={y}
                        stroke={isBoundary ? '#64748B' : '#E2E8F0'}
                        strokeWidth={isBoundary ? 1.2 : 0.8}
                        strokeDasharray={isBoundary ? '4 3' : '2 2'}
                      />
                      <text
                        x={padding.left - 8}
                        y={y + 4}
                        textAnchor="end"
                        className={`text-[10px] ${isBoundary ? 'font-bold fill-slate-800' : 'fill-slate-500'}`}
                      >
                        {bmiVal.toFixed(1)}
                      </text>
                    </g>
                  );
                })}

                {/* 3. Horizontal Reference Line Labels (Legend Right) */}
                <g transform={`translate(${padding.left + chartWidth + 12}, 0)`}>
                  {/* Obese label */}
                  <text x="0" y={yOverweightTop - 12} className="text-[10px] font-bold fill-rose-700">
                    Obese (≥30.0)
                  </text>
                  <line x1="0" y1={yOverweightTop} x2="16" y2={yOverweightTop} stroke="#DC2626" strokeWidth="1.5" strokeDasharray="3 2" />

                  {/* Overweight label */}
                  <text x="0" y={yNormalTop - 12} className="text-[10px] font-bold fill-amber-700">
                    Overweight (25–29.9)
                  </text>
                  <line x1="0" y1={yNormalTop} x2="16" y2={yNormalTop} stroke="#D97706" strokeWidth="1.5" strokeDasharray="3 2" />

                  {/* Normal label */}
                  <text x="0" y={yUnderweightTop - 12} className="text-[10px] font-bold fill-emerald-700">
                    Normal (18.5–24.9)
                  </text>
                  <line x1="0" y1={yUnderweightTop} x2="16" y2={yUnderweightTop} stroke="#16A34A" strokeWidth="1.5" strokeDasharray="3 2" />

                  {/* Underweight label */}
                  <text x="0" y={yUnderweightTop + 16} className="text-[10px] font-bold fill-blue-700">
                    Underweight (&lt;18.5)
                  </text>
                </g>

                {/* 4. Chart Title and Axis Labels */}
                <text
                  x={padding.left + chartWidth / 2}
                  y="22"
                  textAnchor="middle"
                  className="text-xs font-bold fill-slate-900"
                >
                  BMI History Trend — {userName} (Chronological)
                </text>

                {/* Y Axis Label */}
                <text
                  transform={`rotate(-90, 16, ${padding.top + chartHeight / 2})`}
                  x="16"
                  y={padding.top + chartHeight / 2}
                  textAnchor="middle"
                  className="text-[10px] font-bold fill-slate-600"
                >
                  Body Mass Index (BMI)
                </text>

                {/* X Axis Line */}
                <line
                  x1={padding.left}
                  y1={padding.top + chartHeight}
                  x2={padding.left + chartWidth}
                  y2={padding.top + chartHeight}
                  stroke="#475569"
                  strokeWidth="1.5"
                />

                {/* Y Axis Line */}
                <line
                  x1={padding.left}
                  y1={padding.top}
                  x2={padding.left}
                  y2={padding.top + chartHeight}
                  stroke="#475569"
                  strokeWidth="1.5"
                />

                {/* 5. Date Ticks on X-Axis */}
                {points.map((pt, i) => {
                  const dateStr = pt.record.recorded_at.split(' ')[0];
                  const timeStr = pt.record.recorded_at.split(' ')[1]?.slice(0, 5) || '';
                  return (
                    <g key={pt.record.id} transform={`translate(${pt.x}, ${padding.top + chartHeight + 16})`}>
                      <line x1="0" y1="-16" x2="0" y2="-10" stroke="#475569" strokeWidth="1" />
                      <text x="0" y="0" textAnchor="middle" className="text-[9px] fill-slate-600">
                        {dateStr.slice(5)}
                      </text>
                      <text x="0" y="11" textAnchor="middle" className="text-[8px] fill-slate-400">
                        {timeStr}
                      </text>
                    </g>
                  );
                })}

                {/* 6. BMI Data Trajectory Line */}
                <path
                  d={pathD}
                  fill="none"
                  stroke="#0F172A"
                  strokeWidth="2.5"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                />

                {/* 7. Data Points and Value Badges */}
                {points.map((pt) => {
                  const isHovered = hoveredPoint?.date === pt.record.recorded_at;
                  return (
                    <g key={pt.record.id}>
                      {/* Outer halo */}
                      <circle
                        cx={pt.x}
                        cy={pt.y}
                        r={isHovered ? 8 : 5}
                        fill="#2563EB"
                        stroke="#0F172A"
                        strokeWidth="1.5"
                        className="cursor-pointer transition-all"
                        onMouseEnter={() =>
                          setHoveredPoint({
                            date: pt.record.recorded_at,
                            bmi: pt.record.bmi,
                            weight: pt.record.weight_kg,
                            category: pt.record.category,
                            x: pt.x,
                            y: pt.y,
                          })
                        }
                        onMouseLeave={() => setHoveredPoint(null)}
                      />
                      {/* Label badge above point */}
                      <rect
                        x={pt.x - 24}
                        y={pt.y - 24}
                        width="48"
                        height="16"
                        rx="3"
                        fill="#FFFFFF"
                        stroke="#CBD5E1"
                        strokeWidth="1"
                        filter="url(#shadow)"
                      />
                      <text
                        x={pt.x}
                        y={pt.y - 12}
                        textAnchor="middle"
                        className="text-[9px] font-bold fill-slate-800 pointer-events-none"
                      >
                        {pt.record.bmi.toFixed(1)}
                      </text>
                    </g>
                  );
                })}

                {/* 8. Interactive Tooltip Overlay */}
                {hoveredPoint && (
                  <g transform={`translate(${hoveredPoint.x + 10}, ${hoveredPoint.y - 45})`}>
                    <rect
                      x="0"
                      y="0"
                      width="135"
                      height="50"
                      rx="4"
                      fill="#0F172A"
                      className="opacity-95"
                    />
                    <text x="8" y="15" className="text-[9px] font-bold fill-white">
                      Date: {hoveredPoint.date}
                    </text>
                    <text x="8" y="29" className="text-[9px] fill-slate-200">
                      BMI: {hoveredPoint.bmi.toFixed(2)} ({hoveredPoint.category})
                    </text>
                    <text x="8" y="42" className="text-[9px] fill-slate-300">
                      Weight: {hoveredPoint.weight} kg
                    </text>
                  </g>
                )}
              </svg>
            </div>
          )}
        </div>

        {/* Chart Legend / Clinical Explanation Footer */}
        <div className="flex flex-col sm:flex-row items-center justify-between border-t border-slate-200 bg-slate-50 px-6 py-3 text-xs text-slate-600 gap-2">
          <p className="text-[11px] text-slate-500">
            <strong>Matplotlib Note:</strong> Reference lines at 18.5, 25.0, 30.0 mark WHO standard screening boundaries.
          </p>
          <button
            onClick={onClose}
            className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800"
          >
            Close Chart
          </button>
        </div>
      </div>
    </div>
  );
};
