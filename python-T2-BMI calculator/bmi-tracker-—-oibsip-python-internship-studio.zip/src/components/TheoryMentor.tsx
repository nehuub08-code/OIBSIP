import React, { useState } from 'react';
import {
  BookOpen,
  Code2,
  Database,
  LineChart,
  HelpCircle,
  GitBranch,
  ChevronDown,
  ChevronRight,
  Lightbulb,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';
import { VIVA_QUESTIONS } from '../data/defaultData';

export const TheoryMentor: React.FC = () => {
  const [openVivaIndex, setOpenVivaIndex] = useState<number | null>(0);

  const sections = [
    {
      title: '1. The BMI Mathematical Formula',
      icon: Code2,
      content: (
        <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
          <p>
            The Body Mass Index uses the metric formula:
          </p>
          <div className="rounded-md bg-slate-900 p-3 font-mono text-emerald-300 text-xs">
            BMI = weight_in_kg / (height_in_meters ** 2)
          </div>
          <p>
            <strong>Why <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">** 2</code> instead of <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">^ 2</code>?</strong>
          </p>
          <p>
            In Python, the caret symbol <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">^</code> is the bitwise XOR operator, not exponentiation. Writing <code className="font-mono">1.65 ^ 2</code> causes a <code className="font-mono text-rose-600">TypeError: unsupported operand type(s) for ^: &apos;float&apos; and &apos;int&apos;</code>. The double asterisk <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">**</code> is Python&apos;s exponentiation operator.
          </p>
          <p>
            <strong>Worked Example:</strong> If weight = 60 kg and height = 1.65 m:
          </p>
          <div className="rounded-md bg-slate-50 p-2.5 border border-slate-200 font-mono text-[11px] text-slate-800">
            height ** 2 = 1.65 * 1.65 = 2.7225<br />
            BMI = 60 / 2.7225 = 22.03856...<br />
            round(22.03856, 2) = <strong>22.04</strong>
          </div>
        </div>
      ),
    },
    {
      title: '2. Category Classification & Chained Comparisons',
      icon: Lightbulb,
      content: (
        <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
          <p>
            The task requires four precise non-overlapping adult categories:
          </p>
          <ul className="list-disc pl-5 space-y-1 font-mono text-[11px]">
            <li><strong>Underweight:</strong> BMI &lt; 18.5</li>
            <li><strong>Normal:</strong> 18.5 &le; BMI &lt; 25.0</li>
            <li><strong>Overweight:</strong> 25.0 &le; BMI &lt; 30.0</li>
            <li><strong>Obese:</strong> BMI &ge; 30.0</li>
          </ul>
          <p>
            In Python, we write this cleanly using chained conditions:
          </p>
          <div className="rounded-md bg-slate-900 p-3 font-mono text-emerald-300 text-xs">
            {`if bmi < 18.5:
    return "Underweight"
elif bmi < 25.0:       # Python checks: 18.5 <= bmi < 25.0
    return "Normal"
elif bmi < 30.0:       # Python checks: 25.0 <= bmi < 30.0
    return "Overweight"
else:
    return "Obese"`}
          </div>
        </div>
      ),
    },
    {
      title: '3. SQLite Security: Preventing SQL Injection',
      icon: Database,
      content: (
        <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
          <p>
            SQL Injection occurs when user input is treated as SQL code instead of data.
          </p>
          <div className="rounded-md bg-rose-50 border border-rose-200 p-3 text-rose-800">
            <strong>❌ Insecure (Concatenation):</strong><br />
            <code className="font-mono text-[11px]">cursor.execute(f&quot;SELECT * FROM records WHERE name = &apos;&#123;user_name&#125;&apos;&quot;)</code><br />
            If a user enters <code className="font-mono text-[11px]">&apos; OR 1=1; --</code>, this leaks other people&apos;s medical records!
          </div>
          <div className="rounded-md bg-emerald-50 border border-emerald-200 p-3 text-emerald-800">
            <strong>✅ Secure (Parameterized Query with ?):</strong><br />
            <code className="font-mono text-[11px]">cursor.execute(&quot;SELECT * FROM records WHERE user_name = ?&quot;, (user_name,))</code><br />
            SQLite treats the placeholder value strictly as raw literal text, rendering SQL injection impossible.
          </div>
        </div>
      ),
    },
    {
      title: '4. Tkinter Event Loop & ttk.Treeview Architecture',
      icon: BookOpen,
      content: (
        <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
          <p>
            Tkinter applications are event-driven:
          </p>
          <ol className="list-decimal pl-5 space-y-1">
            <li><strong>Window Initialization:</strong> <code className="font-mono">root = tk.Tk()</code> creates the main desktop window.</li>
            <li><strong>Widget Creation:</strong> Labels, Entry fields, and Buttons are instantiated and attached to parent frames.</li>
            <li><strong>Event Binding:</strong> Buttons take a callback function, e.g. <code className="font-mono">command=self.on_calculate_bmi</code>.</li>
            <li><strong>Main Event Loop:</strong> Calling <code className="font-mono">root.mainloop()</code> blocks terminal execution and continuously handles OS window refresh, mouse clicks, and keyboard strokes.</li>
            <li><strong>ttk.Treeview:</strong> Provides multi-column spreadsheet-like tables for displaying multi-user database records.</li>
          </ol>
        </div>
      ),
    },
    {
      title: '5. Matplotlib Embedding in Desktop GUI',
      icon: LineChart,
      content: (
        <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
          <p>
            Rather than calling <code className="font-mono">plt.show()</code> (which blocks Tkinter or opens an unlinked OS window), we embed the figure directly:
          </p>
          <div className="rounded-md bg-slate-900 p-3 font-mono text-emerald-300 text-xs">
            {`from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

fig = history_chart.create_trend_figure(records, user_name)
canvas = FigureCanvasTkAgg(fig, master=history_window)
canvas.draw()
canvas.get_tk_widget().pack(fill="both", expand=True)`}
          </div>
          <p>
            This embeds the graph right inside the desktop application window with native controls.
          </p>
        </div>
      ),
    },
    {
      title: '6. Medical Context & Screening Disclaimer',
      icon: ShieldAlert,
      content: (
        <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
          <p>
            It is crucial for any health software to understand its diagnostic boundaries:
          </p>
          <ul className="list-disc pl-5 space-y-1.5">
            <li><strong>Screening vs Diagnosis:</strong> BMI is a general population screening proxy, not a blood test, DEXA scan, or cardiovascular assessment.</li>
            <li><strong>Muscle Mass vs Fat Tissue:</strong> Dense skeletal muscle weighs more than adipose fat tissue. An athletic rugby player or bodybuilder can have a BMI &gt; 30 (Obese classification) while possessing very low body fat.</li>
            <li><strong>Age Caveat:</strong> Adult cutoffs (18.5, 25.0, 30.0) apply only to individuals age 19+. Children and adolescents must use age-and-gender percentiles (CDC/WHO growth charts).</li>
          </ul>
        </div>
      ),
    },
    {
      title: '7. GitHub Submission Guide for Oasis Infobyte',
      icon: GitBranch,
      content: (
        <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
          <p>
            Follow these exact Git commands to submit Task 2 to your Oasis Infobyte repository:
          </p>
          <div className="rounded-md bg-slate-950 p-3 font-mono text-emerald-400 text-xs space-y-1">
            <div># 1. Clone or navigate to your OIBSIP repository</div>
            <div>cd OIBSIP</div>
            <div className="pt-1"># 2. Add the Task 2 folder files</div>
            <div>git status</div>
            <div>git add PythonProgramming/Task2_BMI_Calculator/</div>
            <div className="pt-1"># 3. Commit with a professional message</div>
            <div>git commit -m &quot;feat: complete OIBSIP Task 2 BMI Calculator with Tkinter, SQLite, and Matplotlib&quot;</div>
            <div className="pt-1"># 4. Push to your GitHub remote repository</div>
            <div>git push origin main</div>
          </div>
          <p className="text-slate-500 text-[11px]">
            Notice that <code className="font-mono">bmi_history.db</code> is kept in <code className="font-mono">.gitignore</code> so private database records are never committed to your public Git repository!
          </p>
        </div>
      ),
    },
  ];

  return (
    <div className="w-full max-w-5xl mx-auto space-y-8">
      {/* Intro card */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-xs">
        <h3 className="text-base font-bold text-slate-900">
          Computer Engineering Student Mentor &amp; Theory Guide
        </h3>
        <p className="text-xs text-slate-600 mt-1 leading-relaxed">
          Designed for second-year engineering students preparing for the Oasis Infobyte evaluation, viva voice, and technical interviews.
        </p>
      </div>

      {/* Concept Breakdown Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sections.map((sec, idx) => {
          const Icon = sec.icon;
          return (
            <div
              key={idx}
              className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-100">
                  <div className="rounded-md bg-blue-50 p-1.5 text-blue-600">
                    <Icon className="h-4 w-4" />
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 font-mono">
                    {sec.title}
                  </h4>
                </div>
                {sec.content}
              </div>
            </div>
          );
        })}
      </div>

      {/* Viva / Interview Questions Accordion */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-xs">
        <div className="border-b border-slate-200 bg-slate-50 p-5">
          <div className="flex items-center gap-2">
            <HelpCircle className="h-5 w-5 text-indigo-600" />
            <h4 className="text-sm font-bold text-slate-900">
              Oasis Infobyte Internship Viva &amp; Interview Questions (Q&amp;A)
            </h4>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Key questions evaluators ask about Python, Tkinter, SQLite, and software architecture.
          </p>
        </div>

        <div className="divide-y divide-slate-100">
          {VIVA_QUESTIONS.map((item, idx) => {
            const isOpen = openVivaIndex === idx;
            return (
              <div key={idx} className="transition-colors">
                <button
                  type="button"
                  onClick={() => setOpenVivaIndex(isOpen ? null : idx)}
                  className="w-full flex items-center justify-between p-4 text-left hover:bg-slate-50 cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                      {item.topic}
                    </span>
                    <span className="text-xs font-semibold text-slate-800">
                      Q{idx + 1}: {item.question}
                    </span>
                  </div>
                  {isOpen ? (
                    <ChevronDown className="h-4 w-4 text-slate-400 shrink-0" />
                  ) : (
                    <ChevronRight className="h-4 w-4 text-slate-400 shrink-0" />
                  )}
                </button>

                {isOpen && (
                  <div className="px-5 pb-4 pt-1 text-xs text-slate-600 leading-relaxed bg-slate-50/50 border-t border-slate-100 font-sans">
                    <div className="rounded-lg bg-white p-3 border border-slate-200/80 text-slate-800">
                      <strong className="text-indigo-900 block mb-1">Answer:</strong>
                      {item.answer}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
