import React, { useState } from 'react';
import { BMIRecord } from '../types';
import { HistoryModal } from './HistoryModal';
import { TrendChartModal } from './TrendChartModal';
import {
  Activity,
  Calculator,
  RotateCcw,
  Table,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  User,
  Scale,
  Ruler,
  Info
} from 'lucide-react';

interface TkinterSimulatorProps {
  records: BMIRecord[];
  onAddRecord: (record: Omit<BMIRecord, 'id'>) => void;
  onDeleteRecord: (id: number) => void;
}

export const TkinterSimulator: React.FC<TkinterSimulatorProps> = ({
  records,
  onAddRecord,
  onDeleteRecord,
}) => {
  // Input states
  const [userName, setUserName] = useState<string>('Aditi Sharma');
  const [weightStr, setWeightStr] = useState<string>('60.0');
  const [heightStr, setHeightStr] = useState<string>('1.65');

  // Calculation output states
  const [bmiResult, setBmiResult] = useState<number | null>(22.04);
  const [categoryResult, setCategoryResult] = useState<'Underweight' | 'Normal' | 'Overweight' | 'Obese' | null>('Normal');
  const [feedbackAdvice, setFeedbackAdvice] = useState<string>(
    'Within the healthy reference weight range for adults.'
  );
  const [healthyWeightRange, setHealthyWeightRange] = useState<string>(
    'Estimated healthy weight range for height 1.65m: 50.4 kg – 67.8 kg'
  );

  // Modals
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [isTrendOpen, setIsTrendOpen] = useState<boolean>(false);

  // Simulated tkinter.messagebox
  const [dialog, setDialog] = useState<{
    type: 'error' | 'info' | 'warning';
    title: string;
    message: string;
  } | null>(null);

  // Quick profiles for testing
  const quickProfiles = ['Aditi Sharma', 'Rahul Verma', 'Neha Borkar'];

  // Handle Calculate & Save BMI
  const handleCalculate = () => {
    // 1. Validation
    const cleanName = userName.trim();
    if (!cleanName) {
      setDialog({
        type: 'error',
        title: 'Input Validation Error',
        message: 'Please enter your name. The user name cannot be empty.',
      });
      return;
    }

    if (!weightStr.trim()) {
      setDialog({
        type: 'error',
        title: 'Input Validation Error',
        message: 'Weight field is empty. Please enter your weight in kilograms (kg).',
      });
      return;
    }

    const weightVal = parseFloat(weightStr.trim());
    if (isNaN(weightVal)) {
      setDialog({
        type: 'error',
        title: 'Input Validation Error',
        message: `Invalid weight: '${weightStr}'. Weight must be a numeric value (e.g., 65.5).`,
      });
      return;
    }

    if (weightVal <= 0) {
      setDialog({
        type: 'error',
        title: 'Input Validation Error',
        message: 'Weight must be strictly greater than 0 kg.',
      });
      return;
    }

    if (!heightStr.trim()) {
      setDialog({
        type: 'error',
        title: 'Input Validation Error',
        message: 'Height field is empty. Please enter your height in meters (e.g., 1.70).',
      });
      return;
    }

    const heightVal = parseFloat(heightStr.trim());
    if (isNaN(heightVal)) {
      setDialog({
        type: 'error',
        title: 'Input Validation Error',
        message: `Invalid height: '${heightStr}'. Height must be a numeric value in meters (e.g., 1.65).`,
      });
      return;
    }

    if (heightVal <= 0) {
      setDialog({
        type: 'error',
        title: 'Input Validation Error',
        message: 'Height must be strictly greater than 0 meters.',
      });
      return;
    }

    // Common beginner mistake: height in cm (e.g. 165 cm)
    if (heightVal > 3.0) {
      const suggested = (heightVal / 100).toFixed(2);
      setDialog({
        type: 'warning',
        title: 'Height Sanity Check',
        message: `Height (${heightVal}) appears to be in centimeters.\nPlease enter in meters (e.g. ${suggested} m instead of ${heightVal} cm).`,
      });
      return;
    }

    // 2. BMI Calculation: weight / (height ** 2)
    const rawBmi = weightVal / (heightVal * heightVal);
    const calculatedBmi = Math.round(rawBmi * 100) / 100;

    // 3. Category Classification
    let cat: 'Underweight' | 'Normal' | 'Overweight' | 'Obese' = 'Normal';
    let advice = '';

    if (calculatedBmi < 18.5) {
      cat = 'Underweight';
      advice = 'Below standard weight range. Consider consulting a nutritionist.';
    } else if (calculatedBmi < 25.0) {
      cat = 'Normal';
      advice = 'Within the healthy reference weight range for adults.';
    } else if (calculatedBmi < 30.0) {
      cat = 'Overweight';
      advice = 'Above standard weight range. Regular physical activity is recommended.';
    } else {
      cat = 'Obese';
      advice = 'Significantly above reference range. Medical consultation advised.';
    }

    // Healthy weight range
    const minW = (18.5 * (heightVal * heightVal)).toFixed(1);
    const maxW = (24.9 * (heightVal * heightVal)).toFixed(1);

    setBmiResult(calculatedBmi);
    setCategoryResult(cat);
    setFeedbackAdvice(advice);
    setHealthyWeightRange(`Estimated healthy weight range for height ${heightVal.toFixed(2)}m: ${minW} kg – ${maxW} kg`);

    // 4. Save to Database
    const now = new Date();
    const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

    onAddRecord({
      user_name: cleanName,
      weight_kg: weightVal,
      height_m: heightVal,
      bmi: calculatedBmi,
      category: cat,
      recorded_at: formattedDate,
    });

    setDialog({
      type: 'info',
      title: 'Calculation Saved (tkinter.messagebox)',
      message: `Calculation successful!\n\nUser: ${cleanName}\nBMI: ${calculatedBmi.toFixed(2)} (${cat})\nRecord committed to local SQLite database!`,
    });
  };

  const handleClear = () => {
    setWeightStr('');
    setHeightStr('');
    setBmiResult(null);
    setCategoryResult(null);
    setFeedbackAdvice('Enter your profile details above and click Calculate.');
    setHealthyWeightRange('');
  };

  const getCategoryStyles = () => {
    switch (categoryResult) {
      case 'Underweight':
        return {
          textColor: 'text-blue-600',
          bgBadge: 'bg-blue-600 text-white',
          border: 'border-blue-200',
        };
      case 'Normal':
        return {
          textColor: 'text-emerald-600',
          bgBadge: 'bg-emerald-600 text-white',
          border: 'border-emerald-200',
        };
      case 'Overweight':
        return {
          textColor: 'text-amber-600',
          bgBadge: 'bg-amber-600 text-white',
          border: 'border-amber-200',
        };
      case 'Obese':
        return {
          textColor: 'text-rose-600',
          bgBadge: 'bg-rose-600 text-white',
          border: 'border-rose-200',
        };
      default:
        return {
          textColor: 'text-slate-600',
          bgBadge: 'bg-slate-200 text-slate-700',
          border: 'border-slate-200',
        };
    }
  };

  const categoryStyle = getCategoryStyles();

  // Count user records
  const userRecordCount = records.filter(
    (r) => r.user_name.trim().toLowerCase() === userName.trim().toLowerCase()
  ).length;

  return (
    <div className="relative mx-auto w-full max-w-3xl">
      {/* Desktop Window Container (Tkinter GUI Frame) */}
      <div className="overflow-hidden rounded-xl border border-slate-300 bg-white shadow-xl">
        {/* Tkinter OS Window Titlebar */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-100 px-4 py-2.5 select-none">
          <div className="flex items-center gap-2">
            <span className="h-3 w-3 rounded-full bg-rose-400" />
            <span className="h-3 w-3 rounded-full bg-amber-400" />
            <span className="h-3 w-3 rounded-full bg-emerald-400" />
            <span className="ml-2 font-mono text-xs font-semibold text-slate-700">
              BMI Tracker — Personal BMI Calculator (OIBSIP Task 2)
            </span>
          </div>
          <div className="text-[11px] font-mono text-slate-500">
            Tkinter clam · 640x720
          </div>
        </div>

        {/* Inner Tkinter Application Area */}
        <div className="bg-[#F8FAFC] p-6 space-y-4">
          {/* Header Banner */}
          <div className="border-b border-slate-200 pb-3">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold tracking-tight text-slate-900">
                  BMI Tracker — Personal BMI Calculator
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Oasis Infobyte (OIBSIP) Python Programming Internship · Task 2
                </p>
              </div>
              <div className="hidden sm:block text-right">
                <span className="text-[11px] font-mono text-slate-500 block">
                  Active User Records: <strong className="text-slate-800">{userRecordCount}</strong>
                </span>
                <span className="text-[11px] text-slate-400">
                  Storage: SQLite (<code className="font-mono">bmi_history.db</code>)
                </span>
              </div>
            </div>

            {/* Quick Profile Selector */}
            <div className="mt-3 flex items-center gap-2 flex-wrap">
              <span className="text-xs text-slate-500 font-medium">Quick Profiles:</span>
              {quickProfiles.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setUserName(p)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                    userName === p
                      ? 'bg-slate-900 text-white'
                      : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* Input Card */}
          <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-xs">
            <div className="space-y-4">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  Full Name / User Profile:
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <User className="h-4 w-4" />
                  </div>
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="Enter your name (e.g., Aditi Sharma)"
                    className="w-full rounded-md border border-slate-300 py-2 pl-9 pr-3 text-sm text-slate-900 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                  />
                </div>
              </div>

              {/* Weight and Height Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Weight */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-800">
                      Weight (kg):
                    </label>
                    <span className="text-[10px] text-slate-400">Standard metric</span>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Scale className="h-4 w-4" />
                    </div>
                    <input
                      type="text"
                      value={weightStr}
                      onChange={(e) => setWeightStr(e.target.value)}
                      placeholder="e.g. 60.0"
                      className="w-full rounded-md border border-slate-300 py-2 pl-9 pr-3 text-sm text-slate-900 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                    />
                  </div>
                  <p className="mt-1 text-[11px] text-slate-400">e.g. 60.0 kg (greater than 0)</p>
                </div>

                {/* Height */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-800">
                      Height (m):
                    </label>
                    <span className="text-[10px] text-slate-400">In meters</span>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Ruler className="h-4 w-4" />
                    </div>
                    <input
                      type="text"
                      value={heightStr}
                      onChange={(e) => setHeightStr(e.target.value)}
                      placeholder="e.g. 1.65"
                      className="w-full rounded-md border border-slate-300 py-2 pl-9 pr-3 text-sm text-slate-900 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                    />
                  </div>
                  <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
                    <span>e.g. 1.65 (not 165 cm)</span>
                    {parseFloat(heightStr) > 3.0 && (
                      <button
                        type="button"
                        onClick={() => {
                          const converted = (parseFloat(heightStr) / 100).toFixed(2);
                          setHeightStr(converted);
                        }}
                        className="text-blue-600 underline font-medium hover:text-blue-700"
                      >
                        Convert cm → m?
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center gap-3">
                <button
                  type="button"
                  onClick={handleCalculate}
                  className="flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white shadow-xs hover:bg-blue-700 transition-colors cursor-pointer"
                >
                  <Calculator className="h-4 w-4" />
                  <span>Calculate &amp; Save BMI</span>
                </button>
                <button
                  type="button"
                  onClick={handleClear}
                  className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span>Clear Fields</span>
                </button>
              </div>
            </div>
          </div>

          {/* Results Display Card */}
          <div className="rounded-lg border border-slate-200 bg-white p-5 shadow-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
              Calculation Summary &amp; Category
            </h3>

            <div className="flex flex-col sm:flex-row sm:items-center gap-6 rounded-lg bg-slate-50 p-4 border border-slate-100">
              {/* BMI Big Number */}
              <div className="flex items-baseline gap-2">
                <span className={`text-4xl sm:text-5xl font-black font-mono tracking-tight ${categoryStyle.textColor}`}>
                  {bmiResult !== null ? bmiResult.toFixed(2) : '--.--'}
                </span>
                <span className="text-xs font-mono text-slate-400">kg/m²</span>
              </div>

              {/* Category & Feedback */}
              <div className="space-y-1.5 flex-1 border-t sm:border-t-0 sm:border-l border-slate-200 pt-3 sm:pt-0 sm:pl-6">
                <div>
                  <span className={`inline-block rounded-md px-2.5 py-1 text-xs font-bold uppercase tracking-wide ${categoryStyle.bgBadge}`}>
                    {categoryResult ? `● ${categoryResult}` : 'Awaiting Input'}
                  </span>
                </div>
                <p className="text-xs font-medium text-slate-800 leading-snug">
                  {feedbackAdvice}
                </p>
                {healthyWeightRange && (
                  <p className="text-[11px] text-teal-700 font-medium">
                    {healthyWeightRange}
                  </p>
                )}
              </div>
            </div>

            {/* Medical Screening Note */}
            <div className="mt-4 flex items-start gap-2 rounded-md bg-slate-50 p-3 border border-slate-200/60 text-[11px] text-slate-500 leading-relaxed">
              <Info className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
              <p>
                <strong>Clinical Screening Note:</strong> BMI is an anthropometric screening indicator, not a complete medical diagnosis. It does not measure body fat percentage directly and does not distinguish muscle from adipose tissue. Adult categories are not calibrated for children or teenagers.
              </p>
            </div>
          </div>

          {/* Footer Actions (History & Trend) */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={() => {
                  if (!userName.trim()) {
                    setDialog({
                      type: 'warning',
                      title: 'User Name Required',
                      message: 'Please enter a user name to view matching history records.',
                    });
                    return;
                  }
                  setIsHistoryOpen(true);
                }}
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-semibold text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <Table className="h-4 w-4" />
                <span>View History Table ({userRecordCount})</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (!userName.trim()) {
                    setDialog({
                      type: 'warning',
                      title: 'User Name Required',
                      message: 'Please enter a user name to view the BMI trend chart.',
                    });
                    return;
                  }
                  setIsTrendOpen(true);
                }}
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 rounded-lg bg-sky-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-sky-700 transition-colors cursor-pointer"
              >
                <TrendingUp className="h-4 w-4" />
                <span>Show BMI Trend Chart</span>
              </button>
            </div>

            <div className="text-[11px] font-mono text-slate-400 text-center sm:text-right">
              SQLite: <span className="text-slate-600 font-semibold">{records.length}</span> total entries
            </div>
          </div>
        </div>
      </div>

      {/* Simulated tkinter.messagebox Modal */}
      {dialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md overflow-hidden rounded-lg border border-slate-300 bg-white shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 bg-slate-100 px-4 py-2 text-xs font-bold text-slate-700 font-mono">
              <span>{dialog.title}</span>
            </div>
            <div className="p-5 flex items-start gap-3">
              {dialog.type === 'error' && (
                <div className="rounded-full bg-rose-100 p-2 text-rose-600 shrink-0">
                  <AlertTriangle className="h-5 w-5" />
                </div>
              )}
              {dialog.type === 'warning' && (
                <div className="rounded-full bg-amber-100 p-2 text-amber-600 shrink-0">
                  <HelpCircle className="h-5 w-5" />
                </div>
              )}
              {dialog.type === 'info' && (
                <div className="rounded-full bg-emerald-100 p-2 text-emerald-600 shrink-0">
                  <CheckCircle2 className="h-5 w-5" />
                </div>
              )}
              <div className="space-y-1">
                <p className="text-xs text-slate-800 whitespace-pre-line leading-relaxed">
                  {dialog.message}
                </p>
              </div>
            </div>
            <div className="flex justify-end border-t border-slate-200 bg-slate-50 px-4 py-2.5">
              <button
                type="button"
                onClick={() => setDialog(null)}
                className="rounded-md bg-slate-900 px-4 py-1.5 text-xs font-semibold text-white hover:bg-slate-800"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sub-modals for History and Trend */}
      <HistoryModal
        userName={userName}
        records={records}
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onDeleteRecord={onDeleteRecord}
      />

      <TrendChartModal
        userName={userName}
        records={records}
        isOpen={isTrendOpen}
        onClose={() => setIsTrendOpen(false)}
      />
    </div>
  );
};
