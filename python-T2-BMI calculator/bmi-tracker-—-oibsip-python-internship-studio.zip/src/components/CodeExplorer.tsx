import React, { useState, useEffect } from 'react';
import JSZip from 'jszip';
import {
  FileCode,
  Copy,
  Check,
  Download,
  FolderArchive,
  Terminal,
  FileText,
  Database,
  LineChart,
  Code
} from 'lucide-react';

interface CodeExplorerProps {
  initialFiles?: Record<string, string>;
}

export const CodeExplorer: React.FC<CodeExplorerProps> = ({ initialFiles }) => {
  const [files, setFiles] = useState<Record<string, string>>(initialFiles || {});
  const [activeFileName, setActiveFileName] = useState<string>('README.md');
  const [copied, setCopied] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'preview' | 'raw'>('preview');

  // Fetch files from server if not already provided
  useEffect(() => {
    if (!initialFiles || Object.keys(initialFiles).length === 0) {
      fetch('/api/project-files')
        .then((res) => res.json())
        .then((data) => {
          if (data && data.files) {
            setFiles(data.files);
          }
        })
        .catch((err) => console.error('Failed to load project files:', err));
    }
  }, [initialFiles]);

  const fileMeta: Record<string, { desc: string; icon: any }> = {
    'main.py': {
      desc: 'Tkinter Desktop GUI application with color-coded results, treeview history, and embedded matplotlib chart.',
      icon: Terminal,
    },
    'bmi_calculator.py': {
      desc: 'Core business logic: BMI metric formula, WHO adult categories, input validation, and healthy weight ranges.',
      icon: Code,
    },
    'database.py': {
      desc: 'SQLite3 database module with automated schema creation, parameterized queries, and profile isolation.',
      icon: Database,
    },
    'history_chart.py': {
      desc: 'Matplotlib module for plotting chronological BMI trend lines with WHO reference threshold bands (18.5, 25, 30).',
      icon: LineChart,
    },
    'cli_demo.py': {
      desc: 'Phase 1 command-line interface demonstrating calculation, validation, and database storage without GUI.',
      icon: Terminal,
    },
    'test_bmi.py': {
      desc: 'Automated test suite (26 tests) covering exact boundaries (18.5, 25, 30), sanitization, and SQLite transactions.',
      icon: FileCode,
    },
    'requirements.txt': {
      desc: 'External package dependencies list (matplotlib) and documentation of Python standard library modules.',
      icon: FileText,
    },
    'README.md': {
      desc: 'Complete Oasis Infobyte internship submission documentation, folder structure, formulas, and usage guide.',
      icon: FileText,
    },
    '.gitignore': {
      desc: 'Git rules to keep personal health data (*.db) private locally and ignore bytecode and virtual environments.',
      icon: FileText,
    },
  };

  const fileList = Object.keys(files).length > 0
    ? Object.keys(files)
    : [
        'main.py',
        'bmi_calculator.py',
        'database.py',
        'history_chart.py',
        'cli_demo.py',
        'test_bmi.py',
        'requirements.txt',
        'README.md',
        '.gitignore',
      ];

  const currentContent = files[activeFileName] || '# File loading or empty';

  const handleCopy = () => {
    navigator.clipboard.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSingle = () => {
    const blob = new Blob([currentContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();
      const folder = zip.folder('OIBSIP')?.folder('PythonProgramming')?.folder('Task2_BMI_Calculator');

      if (folder) {
        for (const [name, content] of Object.entries(files)) {
          folder.file(name, content);
        }
      }

      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'OIBSIP_Task2_BMI_Calculator_Submission.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('ZIP generation failed:', e);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto rounded-xl border border-slate-200 bg-white shadow-xs overflow-hidden">
      {/* Header bar */}
      <div className="border-b border-slate-200 bg-slate-50 p-4 sm:flex sm:items-center sm:justify-between">
        <div>
          <h3 className="text-base font-bold text-slate-900">
            Source Code Explorer &amp; Submission Package
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Path: <code className="font-mono text-slate-700 bg-slate-200/60 px-1 py-0.5 rounded">OIBSIP/PythonProgramming/Task2_BMI_Calculator/</code>
          </p>
        </div>

        <div className="mt-3 sm:mt-0 flex items-center gap-2">
          <button
            type="button"
            onClick={handleDownloadZip}
            disabled={isZipping || Object.keys(files).length === 0}
            className="flex items-center gap-2 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-emerald-700 transition-colors disabled:opacity-50 cursor-pointer"
          >
            <FolderArchive className="h-4 w-4" />
            <span>{isZipping ? 'Generating ZIP...' : 'Download Project ZIP'}</span>
          </button>
        </div>
      </div>

      {/* File Navigation Tabs */}
      <div className="flex border-b border-slate-200 bg-slate-100/70 overflow-x-auto scrollbar-thin">
        {fileList.map((fName) => {
          const isActive = fName === activeFileName;
          const Icon = fileMeta[fName]?.icon || FileCode;
          return (
            <button
              key={fName}
              onClick={() => setActiveFileName(fName)}
              className={`flex items-center gap-2 px-4 py-2.5 text-xs font-mono whitespace-nowrap border-b-2 transition-colors cursor-pointer ${
                isActive
                  ? 'border-blue-600 bg-white font-bold text-blue-700 shadow-2xs'
                  : 'border-transparent text-slate-600 hover:bg-slate-200/50 hover:text-slate-900'
              }`}
            >
              <Icon className="h-3.5 w-3.5 shrink-0" />
              <span>{fName}</span>
            </button>
          );
        })}
      </div>

      {/* Active File Meta Subtitle */}
      <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50/50 px-5 py-2.5 text-xs">
        <div className="text-slate-600 truncate max-w-xl">
          <span className="font-mono font-semibold text-slate-900">{activeFileName}</span>
          <span className="mx-2 text-slate-300">·</span>
          <span className="text-slate-500">{fileMeta[activeFileName]?.desc || 'Source file'}</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {activeFileName === 'README.md' && (
            <div className="flex items-center rounded-md bg-slate-200/70 p-0.5 text-[11px] font-sans mr-2">
              <button
                onClick={() => setViewMode('preview')}
                className={`px-2 py-0.5 rounded font-medium transition-colors ${
                  viewMode === 'preview' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Formatted View
              </button>
              <button
                onClick={() => setViewMode('raw')}
                className={`px-2 py-0.5 rounded font-medium transition-colors ${
                  viewMode === 'raw' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Raw Markdown
              </button>
            </div>
          )}
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 transition-colors"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
          <button
            onClick={handleDownloadSingle}
            className="flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Download</span>
          </button>
        </div>
      </div>

      {/* Code or Formatted Preview Area */}
      {activeFileName === 'README.md' && viewMode === 'preview' ? (
        <div className="max-h-160 overflow-y-auto p-8 font-sans text-slate-800 bg-white leading-relaxed">
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="border-b border-slate-200 pb-4">
              <span className="text-xs font-mono font-bold text-blue-600 uppercase tracking-wider block mb-1">
                Oasis Infobyte (OIBSIP) · Python Programming Track
              </span>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
                BMI Tracker — Personal BMI Calculator (Task 2)
              </h1>
              <p className="mt-2 text-sm text-slate-600 leading-normal">
                A desktop graphical application that calculates Body Mass Index (BMI) from weight and height, categorizes the result, stores historical calculations for multiple named profiles in an SQLite database, and visualizes progress over time with Matplotlib trend charts.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="rounded-lg bg-slate-50 p-3 border border-slate-200">
                <span className="text-slate-400 block text-[10px]">Language</span>
                <span className="font-bold text-slate-900">Python 3.10+</span>
              </div>
              <div className="rounded-lg bg-slate-50 p-3 border border-slate-200">
                <span className="text-slate-400 block text-[10px]">GUI Toolkit</span>
                <span className="font-bold text-slate-900">Tkinter &amp; ttk</span>
              </div>
              <div className="rounded-lg bg-slate-50 p-3 border border-slate-200">
                <span className="text-slate-400 block text-[10px]">Database</span>
                <span className="font-bold text-slate-900">SQLite3</span>
              </div>
              <div className="rounded-lg bg-slate-50 p-3 border border-slate-200">
                <span className="text-slate-400 block text-[10px]">Charts</span>
                <span className="font-bold text-slate-900">Matplotlib</span>
              </div>
            </div>

            <section className="space-y-3">
              <h2 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-2">
                1. BMI Formula &amp; Math
              </h2>
              <p className="text-xs text-slate-700">
                The standard metric formula is defined as:
              </p>
              <div className="rounded-md bg-slate-900 p-4 font-mono text-emerald-300 text-xs text-center">
                BMI = weight (kg) / [height (m)]²
              </div>
              <p className="text-xs text-slate-600">
                Example: 60 kg weight and 1.65 m height produces <strong>22.04</strong> (Normal Category).
              </p>
            </section>

            <section className="space-y-3">
              <h2 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-2">
                2. Category Thresholds &amp; Color Scheme
              </h2>
              <div className="overflow-x-auto rounded-lg border border-slate-200">
                <table className="w-full text-left text-xs font-sans">
                  <thead className="bg-slate-100 font-semibold text-slate-700 border-b border-slate-200">
                    <tr>
                      <th className="p-2.5">Category</th>
                      <th className="p-2.5">BMI Range</th>
                      <th className="p-2.5">Visual Color</th>
                      <th className="p-2.5">Assessment &amp; Clinical Guidance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                    <tr className="bg-blue-50/40">
                      <td className="p-2.5 font-bold text-blue-700">Underweight</td>
                      <td className="p-2.5">&lt; 18.5</td>
                      <td className="p-2.5">Royal Blue (#2563EB)</td>
                      <td className="p-2.5 font-sans">Below standard weight range. Nutritional guidance advised.</td>
                    </tr>
                    <tr className="bg-emerald-50/40">
                      <td className="p-2.5 font-bold text-emerald-700">Normal</td>
                      <td className="p-2.5">18.5 – 24.99</td>
                      <td className="p-2.5">Forest Green (#16A34A)</td>
                      <td className="p-2.5 font-sans">Healthy adult reference weight range. Maintain balanced routine.</td>
                    </tr>
                    <tr className="bg-amber-50/40">
                      <td className="p-2.5 font-bold text-amber-700">Overweight</td>
                      <td className="p-2.5">25.0 – 29.99</td>
                      <td className="p-2.5">Amber Orange (#D97706)</td>
                      <td className="p-2.5 font-sans">Above standard range. Regular physical activity recommended.</td>
                    </tr>
                    <tr className="bg-rose-50/40">
                      <td className="p-2.5 font-bold text-rose-700">Obese</td>
                      <td className="p-2.5">&ge; 30.0</td>
                      <td className="p-2.5">Crimson Red (#DC2626)</td>
                      <td className="p-2.5 font-sans">Significantly elevated. Medical assessment advised.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </section>

            <section className="space-y-3">
              <h2 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-2">
                3. Quick Setup &amp; Execution Commands
              </h2>
              <div className="rounded-lg bg-slate-950 p-4 font-mono text-xs text-emerald-400 space-y-2">
                <div># 1. Navigate to Task 2 folder</div>
                <div>cd OIBSIP/PythonProgramming/Task2_BMI_Calculator</div>
                <div className="pt-1"># 2. Install external dependency (Matplotlib)</div>
                <div>pip install -r requirements.txt</div>
                <div className="pt-1"># 3. Launch desktop Tkinter GUI application</div>
                <div>python main.py</div>
                <div className="pt-1"># 4. Or launch headless terminal CLI demo</div>
                <div>python cli_demo.py</div>
                <div className="pt-1"># 5. Run full automated test suite (26 tests)</div>
                <div>python test_bmi.py</div>
              </div>
            </section>

            <section className="space-y-3">
              <h2 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-2">
                4. Database Schema (SQLite3)
              </h2>
              <p className="text-xs text-slate-700">
                Table <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">bmi_records</code> stores every valid calculation with parameterized query protection:
              </p>
              <div className="rounded-md bg-slate-50 border border-slate-200 p-3 font-mono text-[11px] text-slate-800">
                id INTEGER PRIMARY KEY AUTOINCREMENT<br />
                user_name TEXT NOT NULL<br />
                weight_kg REAL NOT NULL<br />
                height_m REAL NOT NULL<br />
                bmi REAL NOT NULL<br />
                category TEXT NOT NULL<br />
                recorded_at TEXT NOT NULL
              </div>
            </section>
          </div>
        </div>
      ) : (
        <div className="relative max-h-128 overflow-y-auto bg-slate-950 font-mono text-xs text-slate-100">
          <div className="flex p-4">
            {/* Line Numbers */}
            <div className="select-none pr-4 text-right text-slate-600 font-mono text-xs leading-5 border-r border-slate-800">
              {currentContent.split('\n').map((_, i) => (
                <div key={i}>{i + 1}</div>
              ))}
            </div>
            {/* Code text */}
            <pre className="pl-4 font-mono text-xs text-slate-200 overflow-x-auto leading-5">
              <code>{currentContent}</code>
            </pre>
          </div>
        </div>
      )}

      {/* Footer Info */}
      <div className="flex items-center justify-between border-t border-slate-200 bg-slate-50 px-4 py-2 text-[11px] text-slate-500 font-mono">
        <span>Lines: {currentContent.split('\n').length}</span>
        <span>Size: {(currentContent.length / 1024).toFixed(1)} KB</span>
      </div>
    </div>
  );
};
