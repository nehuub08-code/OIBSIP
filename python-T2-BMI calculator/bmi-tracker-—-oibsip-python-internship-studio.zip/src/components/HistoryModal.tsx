import React, { useState } from 'react';
import { BMIRecord } from '../types';
import { X, Trash2, Download, Table, AlertCircle } from 'lucide-react';

interface HistoryModalProps {
  userName: string;
  records: BMIRecord[];
  isOpen: boolean;
  onClose: () => void;
  onDeleteRecord: (id: number) => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  userName,
  records,
  isOpen,
  onClose,
  onDeleteRecord,
}) => {
  const [selectedId, setSelectedId] = useState<number | null>(null);

  if (!isOpen) return null;

  // Filter for matching user name (case insensitive)
  const userRecords = records.filter(
    (r) => r.user_name.trim().toLowerCase() === userName.trim().toLowerCase()
  );

  // Newest first
  const sortedRecords = [...userRecords].sort(
    (a, b) => new Date(b.recorded_at).getTime() - new Date(a.recorded_at).getTime()
  );

  const getCategoryClass = (category: string) => {
    switch (category) {
      case 'Underweight':
        return 'text-blue-600 font-semibold';
      case 'Normal':
        return 'text-emerald-600 font-semibold';
      case 'Overweight':
        return 'text-amber-600 font-semibold';
      case 'Obese':
        return 'text-rose-600 font-semibold';
      default:
        return 'text-slate-700';
    }
  };

  const handleExportCSV = () => {
    if (sortedRecords.length === 0) return;
    const headers = ['ID', 'User Name', 'Weight (kg)', 'Height (m)', 'BMI', 'Category', 'Recorded At'];
    const rows = sortedRecords.map((r) => [
      r.id,
      `"${r.user_name}"`,
      r.weight_kg,
      r.height_m,
      r.bmi,
      `"${r.category}"`,
      `"${r.recorded_at}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${userName.trim()}_bmi_history.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
      <div className="w-full max-w-3xl overflow-hidden rounded-xl border border-slate-300 bg-white shadow-2xl">
        {/* Tkinter Window Titlebar */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-100 px-4 py-2.5">
          <div className="flex items-center gap-2">
            <span className="h-3 w-3 rounded-full bg-rose-400" />
            <span className="h-3 w-3 rounded-full bg-amber-400" />
            <span className="h-3 w-3 rounded-full bg-emerald-400" />
            <span className="ml-2 font-mono text-xs font-semibold text-slate-700">
              ttk.Treeview — BMI History: {userName || 'All Users'}
            </span>
          </div>
          <button
            onClick={onClose}
            className="rounded p-1 text-slate-500 hover:bg-slate-200 hover:text-slate-800"
            title="Close Window"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Header information */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 py-3">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              Profile: {userName || 'Unknown'}
            </h3>
            <p className="text-xs text-slate-500">
              Showing {sortedRecords.length} historical record{sortedRecords.length === 1 ? '' : 's'} (newest first)
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCSV}
              disabled={sortedRecords.length === 0}
              className="flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-50"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Treeview Table */}
        <div className="max-h-80 overflow-y-auto">
          {sortedRecords.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center text-slate-500">
              <AlertCircle className="mb-2 h-8 w-8 text-slate-400" />
              <p className="text-sm font-medium text-slate-700">No records found for &quot;{userName}&quot;</p>
              <p className="mt-1 text-xs text-slate-500 max-w-sm">
                Enter your weight and height in the main window and click &quot;Calculate &amp; Save BMI&quot; to create your first record.
              </p>
            </div>
          ) : (
            <table className="w-full text-left text-xs font-mono">
              <thead className="sticky top-0 border-b border-slate-200 bg-slate-100 text-slate-600">
                <tr>
                  <th className="py-2.5 px-4 font-semibold">ID</th>
                  <th className="py-2.5 px-4 font-semibold">Date &amp; Time</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Weight (kg)</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Height (m)</th>
                  <th className="py-2.5 px-4 font-semibold text-right">BMI</th>
                  <th className="py-2.5 px-4 font-semibold">Category</th>
                  <th className="py-2.5 px-4 font-semibold text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sortedRecords.map((r) => {
                  const isSelected = selectedId === r.id;
                  return (
                    <tr
                      key={r.id}
                      onClick={() => setSelectedId(r.id)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-blue-50/80 text-blue-900' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="py-2.5 px-4 text-slate-500">#{r.id}</td>
                      <td className="py-2.5 px-4 text-slate-700">{r.recorded_at}</td>
                      <td className="py-2.5 px-4 text-right tabular-nums text-slate-800">
                        {r.weight_kg.toFixed(1)}
                      </td>
                      <td className="py-2.5 px-4 text-right tabular-nums text-slate-800">
                        {r.height_m.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-bold tabular-nums text-slate-900">
                        {r.bmi.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-4">
                        <span className={getCategoryClass(r.category)}>
                          {r.category}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteRecord(r.id);
                          }}
                          className="rounded p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600"
                          title="Delete Record"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-slate-200 bg-slate-50 px-6 py-3">
          <span className="text-xs text-slate-500 font-mono">
            SQLite Table: <code className="bg-slate-200/70 px-1 py-0.5 rounded text-slate-700">bmi_records</code> · Parameterized Query
          </span>
          <button
            onClick={onClose}
            className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800"
          >
            Close Window
          </button>
        </div>
      </div>
    </div>
  );
};
