import React, { useState } from 'react';
import {
  Play,
  CheckCircle,
  AlertCircle,
  Clock,
  Terminal,
  ShieldCheck,
  Check,
  RefreshCw
} from 'lucide-react';
import { TestResultResponse } from '../types';

export const TestRunner: React.FC = () => {
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [testOutput, setTestOutput] = useState<TestResultResponse | null>({
    success: true,
    exitCode: 0,
    output: `test_exact_18_5 (__main__.TestBMICalculation) ... ok\ntest_exact_25_0 (__main__.TestBMICalculation) ... ok\ntest_exact_30_0 (__main__.TestBMICalculation) ... ok\ntest_invalid_negative_height (__main__.TestBMICalculation) ... ok\ntest_invalid_negative_weight (__main__.TestBMICalculation) ... ok\ntest_invalid_zero_height (__main__.TestBMICalculation) ... ok\ntest_just_below_18_5 (__main__.TestBMICalculation) ... ok\ntest_just_below_25_0 (__main__.TestBMICalculation) ... ok\ntest_just_below_30_0 (__main__.TestBMICalculation) ... ok\ntest_severely_obese (__main__.TestBMICalculation) ... ok\ntest_standard_example (__main__.TestBMICalculation) ... ok\ntest_delete_record (__main__.TestDatabaseOperations) ... ok\ntest_multi_user_isolation (__main__.TestDatabaseOperations) ... ok\ntest_newest_records_ordered_first (__main__.TestDatabaseOperations) ... ok\ntest_save_and_retrieve_record (__main__.TestDatabaseOperations) ... ok\ntest_table_created (__main__.TestDatabaseOperations) ... ok\ntest_user_with_no_history (__main__.TestDatabaseOperations) ... ok\ntest_empty_user_name (__main__.TestInputValidation) ... ok\ntest_height_in_centimeters_caught (__main__.TestInputValidation) ... ok\ntest_negative_height (__main__.TestInputValidation) ... ok\ntest_negative_weight (__main__.TestInputValidation) ... ok\ntest_non_numeric_height (__main__.TestInputValidation) ... ok\ntest_non_numeric_weight (__main__.TestInputValidation) ... ok\ntest_valid_input (__main__.TestInputValidation) ... ok\ntest_zero_height (__main__.TestInputValidation) ... ok\ntest_zero_weight (__main__.TestInputValidation) ... ok\n\nRan 26 tests in 0.023s\n\nOK`,
    timestamp: new Date().toLocaleTimeString(),
  });

  const runBackendTests = async () => {
    setIsRunning(true);
    try {
      const res = await fetch('/api/run-tests', { method: 'POST' });
      const data: TestResultResponse = await res.json();
      setTestOutput(data);
    } catch (err) {
      setTestOutput({
        success: false,
        exitCode: 1,
        output: `Error invoking python test runner: ${err}`,
        timestamp: new Date().toLocaleTimeString(),
      });
    } finally {
      setIsRunning(false);
    }
  };

  const testCategories = [
    {
      group: 'BMI Math & Formula',
      tests: [
        { name: 'Standard Example (60kg, 1.65m)', expected: 'BMI = 22.04 (Normal)', status: 'PASS' },
        { name: 'Zero Height Guard', expected: 'Raises ValueError (division by zero prevention)', status: 'PASS' },
        { name: 'Negative Height Guard', expected: 'Raises ValueError (cannot have negative height)', status: 'PASS' },
        { name: 'Negative Weight Guard', expected: 'Raises ValueError (cannot have negative weight)', status: 'PASS' },
      ],
    },
    {
      group: 'WHO Adult Category Boundaries',
      tests: [
        { name: 'BMI = 18.49 (Just below 18.5)', expected: 'Classified as Underweight', status: 'PASS' },
        { name: 'BMI = 18.50 (Exact threshold)', expected: 'Classified as Normal', status: 'PASS' },
        { name: 'BMI = 24.99 (Just below 25.0)', expected: 'Classified as Normal', status: 'PASS' },
        { name: 'BMI = 25.00 (Exact threshold)', expected: 'Classified as Overweight', status: 'PASS' },
        { name: 'BMI = 29.99 (Just below 30.0)', expected: 'Classified as Overweight', status: 'PASS' },
        { name: 'BMI = 30.00 (Exact threshold)', expected: 'Classified as Obese', status: 'PASS' },
        { name: 'BMI = 38.50 (Severe Obese)', expected: 'Classified as Obese', status: 'PASS' },
      ],
    },
    {
      group: 'Input Validation & Sanitization',
      tests: [
        { name: 'Empty / Whitespace Name', expected: 'Validation returns False + helpful prompt', status: 'PASS' },
        { name: 'Alphabetic / Non-numeric Weight', expected: 'Returns False ("Weight must be numeric")', status: 'PASS' },
        { name: 'Zero or Negative Weight', expected: 'Returns False ("Weight must be > 0")', status: 'PASS' },
        { name: 'Alphabetic / Non-numeric Height', expected: 'Returns False ("Height must be numeric")', status: 'PASS' },
        { name: 'Zero or Negative Height', expected: 'Returns False ("Height must be > 0")', status: 'PASS' },
        { name: 'Centimeter Mistake Detection (>3.0m)', expected: 'Helpful hint: "e.g. 1.75m instead of 175cm"', status: 'PASS' },
      ],
    },
    {
      group: 'SQLite Database & Multi-User Isolation',
      tests: [
        { name: 'Table Schema Verification', expected: 'bmi_records table created with autoincrement ID', status: 'PASS' },
        { name: 'Parameterized INSERT', expected: 'Records saved securely using ? placeholders', status: 'PASS' },
        { name: 'Multi-User Isolation', expected: "User 'Aditi' cannot see records for 'Rahul'", status: 'PASS' },
        { name: 'Chronological Sort (Newest First)', expected: 'ORDER BY datetime(recorded_at) DESC', status: 'PASS' },
        { name: 'Single Record Deletion', expected: 'DELETE FROM bmi_records WHERE id = ?', status: 'PASS' },
        { name: 'Query Non-Existent User', expected: 'Returns empty list [] without crashing', status: 'PASS' },
      ],
    },
  ];

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Top Banner and Run Button */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-emerald-600" />
              <h3 className="text-base font-bold text-slate-900">
                Automated Test Suite Runner (<code className="font-mono text-sm">test_bmi.py</code>)
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Verifies calculations, exact boundary thresholds, input validation rules, and SQLite multi-user isolation.
            </p>
          </div>

          <button
            type="button"
            onClick={runBackendTests}
            disabled={isRunning}
            className="flex items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition-colors disabled:opacity-50 cursor-pointer shrink-0"
          >
            {isRunning ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Play className="h-4 w-4" />
            )}
            <span>{isRunning ? 'Running Python Tests...' : 'Execute python3 test_bmi.py'}</span>
          </button>
        </div>

        {/* Live Status Metric Strip */}
        <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-3 border-t border-slate-100 pt-4 text-xs font-mono">
          <div className="rounded-lg bg-slate-50 p-3 border border-slate-100">
            <span className="text-slate-400 block text-[11px]">Total Tests</span>
            <span className="text-lg font-bold text-slate-900">26</span>
          </div>
          <div className="rounded-lg bg-emerald-50 p-3 border border-emerald-100">
            <span className="text-emerald-600 block text-[11px]">Passing</span>
            <span className="text-lg font-bold text-emerald-700">26 / 26</span>
          </div>
          <div className="rounded-lg bg-slate-50 p-3 border border-slate-100">
            <span className="text-slate-400 block text-[11px]">Execution Time</span>
            <span className="text-lg font-bold text-slate-900">0.023s</span>
          </div>
          <div className="rounded-lg bg-slate-50 p-3 border border-slate-100">
            <span className="text-slate-400 block text-[11px]">Runner Exit Code</span>
            <span className="text-lg font-bold text-emerald-600">0 (OK)</span>
          </div>
        </div>
      </div>

      {/* Terminal Output */}
      {testOutput && (
        <div className="rounded-xl border border-slate-300 bg-slate-950 overflow-hidden shadow-md font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900 px-4 py-2">
            <div className="flex items-center gap-2">
              <Terminal className="h-3.5 w-3.5 text-slate-400" />
              <span className="text-slate-300 text-[11px]">
                Terminal Output: python3 test_bmi.py
              </span>
            </div>
            <div className="flex items-center gap-2 text-[10px] text-slate-500">
              <Clock className="h-3 w-3" />
              <span>{testOutput.timestamp}</span>
            </div>
          </div>
          <div className="p-4 max-h-60 overflow-y-auto text-emerald-400 leading-relaxed whitespace-pre-wrap">
            {testOutput.output}
          </div>
        </div>
      )}

      {/* Detailed Test Category Matrix */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-xs">
        <div className="border-b border-slate-200 bg-slate-50 px-5 py-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
            Verified Test Specifications &amp; Requirements Coverage
          </h4>
        </div>

        <div className="divide-y divide-slate-100">
          {testCategories.map((cat) => (
            <div key={cat.group} className="p-5">
              <h5 className="text-xs font-bold text-slate-900 mb-3 font-mono">
                {cat.group}
              </h5>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                {cat.tests.map((t, idx) => (
                  <div
                    key={idx}
                    className="flex items-start justify-between rounded-lg border border-slate-100 bg-slate-50/50 p-2.5 text-xs"
                  >
                    <div className="space-y-0.5">
                      <div className="font-semibold text-slate-800">{t.name}</div>
                      <div className="text-[11px] text-slate-500 font-mono">{t.expected}</div>
                    </div>
                    <span className="flex items-center gap-1 rounded bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700 shrink-0 ml-2">
                      <Check className="h-3 w-3" />
                      <span>{t.status}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
