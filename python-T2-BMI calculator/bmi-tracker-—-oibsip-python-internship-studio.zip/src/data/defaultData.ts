import { BMIRecord, VivaQuestion } from '../types';

export const INITIAL_RECORDS: BMIRecord[] = [
  {
    id: 1,
    user_name: 'Aditi Sharma',
    weight_kg: 56.5,
    height_m: 1.63,
    bmi: 21.27,
    category: 'Normal',
    recorded_at: '2026-08-15 09:30:00',
  },
  {
    id: 2,
    user_name: 'Aditi Sharma',
    weight_kg: 58.0,
    height_m: 1.63,
    bmi: 21.83,
    category: 'Normal',
    recorded_at: '2026-09-10 10:15:00',
  },
  {
    id: 3,
    user_name: 'Aditi Sharma',
    weight_kg: 59.2,
    height_m: 1.63,
    bmi: 22.28,
    category: 'Normal',
    recorded_at: '2026-10-05 08:45:00',
  },
  {
    id: 4,
    user_name: 'Aditi Sharma',
    weight_kg: 60.0,
    height_m: 1.63,
    bmi: 22.58,
    category: 'Normal',
    recorded_at: '2026-10-28 11:20:00',
  },
  {
    id: 5,
    user_name: 'Rahul Verma',
    weight_kg: 84.0,
    height_m: 1.74,
    bmi: 27.75,
    category: 'Overweight',
    recorded_at: '2026-09-01 18:00:00',
  },
  {
    id: 6,
    user_name: 'Rahul Verma',
    weight_kg: 82.5,
    height_m: 1.74,
    bmi: 27.25,
    category: 'Overweight',
    recorded_at: '2026-10-01 18:30:00',
  },
  {
    id: 7,
    user_name: 'Rahul Verma',
    weight_kg: 80.0,
    height_m: 1.74,
    bmi: 26.42,
    category: 'Overweight',
    recorded_at: '2026-10-27 19:15:00',
  },
];

export const VIVA_QUESTIONS: VivaQuestion[] = [
  {
    topic: 'Python Arithmetic',
    question: 'Why does Python use `**` instead of `^` for calculating height squared?',
    answer: 'In Python, the `**` operator denotes exponentiation (e.g. `1.65 ** 2` = 2.7225), whereas `^` is the bitwise XOR (exclusive OR) operator. Using `1.65 ^ 2` would raise a TypeError because floats cannot undergo bitwise operations in Python.',
  },
  {
    topic: 'Conditional Logic',
    question: 'How does Python handle chained comparisons like `18.5 <= bmi < 25.0`?',
    answer: 'Python natively supports chained comparisons. `18.5 <= bmi < 25.0` evaluates as `(18.5 <= bmi) and (bmi < 25.0)` without evaluating `bmi` twice. This prevents subtle off-by-one errors and keeps the classification code clean and readable.',
  },
  {
    topic: 'Database Security',
    question: 'Why must we use parameterized queries with `?` instead of f-strings in SQLite?',
    answer: 'Concatenating user input with f-strings (e.g., `f"SELECT * FROM users WHERE name = \'{name}\'"`) creates SQL Injection vulnerabilities. If an input contains quotes or commands (e.g. `\' OR 1=1; --`), an attacker can tamper with the query. Parameterized placeholders `?` instruct SQLite to treat user values strictly as raw literal data.',
  },
  {
    topic: 'GUI Architecture',
    question: 'What is `root.mainloop()` in Tkinter and why does the program pause there?',
    answer: '`root.mainloop()` starts Tkinter\'s event loop. It continuously listens for OS events like mouse clicks, key presses, and window resizes, and dispatches them to assigned callback handlers (like `command=self.on_calculate_bmi`). Without `mainloop()`, the window would flash and terminate instantly.',
  },
  {
    topic: 'Data Visualization',
    question: 'How is Matplotlib embedded directly into a Tkinter window instead of opening a separate window?',
    answer: 'We use `FigureCanvasTkAgg` from `matplotlib.backends.backend_tkagg`. It bridges a Matplotlib `Figure` object into a Tkinter canvas widget using `canvas = FigureCanvasTkAgg(fig, master=self)` and calls `canvas.get_tk_widget().pack()`.',
  },
  {
    topic: 'Health & Science Context',
    question: 'Why is BMI considered a screening measure rather than a clinical health diagnosis?',
    answer: 'BMI only accounts for total body mass relative to height squared. It cannot distinguish between skeletal muscle mass, bone density, and adipose fat tissue. An athlete with high muscle mass may have an "Overweight" or "Obese" BMI despite excellent cardiovascular health.',
  },
  {
    topic: 'Software Engineering',
    question: 'Why did we separate `bmi_calculator.py`, `database.py`, and `history_chart.py` into separate modules?',
    answer: 'This follows the Single Responsibility Principle (SRP) and Model-View-Controller (MVC) separation. The calculation logic (Model) has zero UI dependencies, allowing it to be tested in automated unit tests (`test_bmi.py`) and reused across CLI (`cli_demo.py`) and GUI (`main.py`).',
  },
  {
    topic: 'Database Schema Design',
    question: 'What does `id INTEGER PRIMARY KEY AUTOINCREMENT` do in SQLite?',
    answer: 'It defines a surrogate primary key. Every newly inserted row automatically receives a unique, incrementing integer ID. This enables precise operations like `DELETE FROM bmi_records WHERE id = ?` without ambiguity.',
  },
];
