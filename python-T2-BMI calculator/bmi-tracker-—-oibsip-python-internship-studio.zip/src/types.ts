export interface BMIRecord {
  id: number;
  user_name: string;
  weight_kg: number;
  height_m: number;
  bmi: number;
  category: 'Underweight' | 'Normal' | 'Overweight' | 'Obese';
  recorded_at: string;
}

export interface ProjectFile {
  name: string;
  path: string;
  language: string;
  description: string;
  content: string;
}

export interface TestResultResponse {
  success: boolean;
  exitCode: number;
  output: string;
  timestamp: string;
}

export interface VivaQuestion {
  question: string;
  answer: string;
  topic: string;
}
