import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { exec } from 'child_process';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: Run the actual Python test suite
  app.post('/api/run-tests', (req, res) => {
    const scriptPath = path.join(__dirname, 'OIBSIP', 'PythonProgramming', 'Task2_BMI_Calculator', 'test_bmi.py');
    exec(`python3 "${scriptPath}"`, { cwd: __dirname }, (error, stdout, stderr) => {
      const output = (stdout || '') + (stderr || '');
      const passed = !error || error.code === 0;
      res.json({
        success: passed,
        exitCode: error ? error.code : 0,
        output: output,
        timestamp: new Date().toISOString()
      });
    });
  });

  // API Route: Get project files contents
  app.get('/api/project-files', (req, res) => {
    const baseDir = path.join(__dirname, 'OIBSIP', 'PythonProgramming', 'Task2_BMI_Calculator');
    const files = [
      'main.py',
      'bmi_calculator.py',
      'database.py',
      'history_chart.py',
      'cli_demo.py',
      'test_bmi.py',
      'requirements.txt',
      'README.md',
      '.gitignore'
    ];

    const result: Record<string, string> = {};
    for (const f of files) {
      const filePath = path.join(baseDir, f);
      if (fs.existsSync(filePath)) {
        result[f] = fs.readFileSync(filePath, 'utf-8');
      }
    }

    res.json({
      baseDir: 'OIBSIP/PythonProgramming/Task2_BMI_Calculator',
      files: result
    });
  });

  // Setup Vite dev server or serve production build
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
