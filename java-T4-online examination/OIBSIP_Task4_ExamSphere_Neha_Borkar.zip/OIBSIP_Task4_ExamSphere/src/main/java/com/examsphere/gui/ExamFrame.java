package com.examsphere.gui;

import com.examsphere.model.ExamSession;
import com.examsphere.model.Question;
import com.examsphere.model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * Main application window utilizing CardLayout for screen orchestration.
 * Manages transitions between Login, Profile, Instructions, Exam, and Result screens.
 */
public class ExamFrame extends JFrame {

    public static final String SCREEN_LOGIN = "LOGIN";
    public static final String SCREEN_PROFILE = "PROFILE";
    public static final String SCREEN_INSTRUCTIONS = "INSTRUCTIONS";
    public static final String SCREEN_EXAM = "EXAM";
    public static final String SCREEN_RESULT = "RESULT";

    private final CardLayout cardLayout;
    private final JPanel containerPanel;

    private User currentUser;
    private ExamSession activeSession;
    private List<Question> questionBank;

    private LoginPanel loginPanel;
    private ProfilePanel profilePanel;
    private InstructionsPanel instructionsPanel;
    private ExamPanel examPanel;
    private ResultPanel resultPanel;

    public ExamFrame() {
        setTitle("ExamSphere — Online Examination System [Oasis Infobyte Task 4]");
        setSize(960, 680);
        setMinimumSize(new Dimension(840, 580));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        // Initialize default user and question bank
        this.currentUser = new User("oasis_student", "Password@123", "Neha Vinod Borkar");
        this.questionBank = initializeQuestions();

        this.cardLayout = new CardLayout();
        this.containerPanel = new JPanel(cardLayout);

        initializeScreens();
        setupWindowClosingInterceptor();

        add(containerPanel, BorderLayout.CENTER);
        showScreen(SCREEN_LOGIN);
    }

    private void initializeScreens() {
        loginPanel = new LoginPanel(this);
        profilePanel = new ProfilePanel(this);
        instructionsPanel = new InstructionsPanel(this);
        examPanel = new ExamPanel(this);
        resultPanel = new ResultPanel(this);

        containerPanel.add(loginPanel, SCREEN_LOGIN);
        containerPanel.add(profilePanel, SCREEN_PROFILE);
        containerPanel.add(instructionsPanel, SCREEN_INSTRUCTIONS);
        containerPanel.add(examPanel, SCREEN_EXAM);
        containerPanel.add(resultPanel, SCREEN_RESULT);
    }

    private void setupWindowClosingInterceptor() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                handleWindowCloseRequest();
            }
        });
    }

    private void handleWindowCloseRequest() {
        if (activeSession != null && !activeSession.isSubmitted()) {
            int option = JOptionPane.showConfirmDialog(
                ExamFrame.this,
                "An examination is currently in progress.\nAre you sure you want to quit? Your exam will be automatically submitted.",
                "Confirm Exit During Exam",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
            );

            if (option == JOptionPane.YES_OPTION) {
                // Submit through single guarded method before exiting
                if (examPanel != null) {
                    examPanel.submitExam(ExamSession.SubmissionType.WINDOW_CLOSED);
                }
                dispose();
                System.exit(0);
            }
        } else {
            int option = JOptionPane.showConfirmDialog(
                ExamFrame.this,
                "Are you sure you want to exit ExamSphere?",
                "Confirm Application Exit",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
            );
            if (option == JOptionPane.YES_OPTION) {
                dispose();
                System.exit(0);
            }
        }
    }

    public void showScreen(String screenName) {
        cardLayout.show(containerPanel, screenName);
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    public List<Question> getQuestionBank() {
        return questionBank;
    }

    public ExamSession getActiveSession() {
        return activeSession;
    }

    public void setActiveSession(ExamSession session) {
        this.activeSession = session;
    }

    public ProfilePanel getProfilePanel() {
        return profilePanel;
    }

    public InstructionsPanel getInstructionsPanel() {
        return instructionsPanel;
    }

    public ExamPanel getExamPanel() {
        return examPanel;
    }

    public ResultPanel getResultPanel() {
        return resultPanel;
    }

    private List<Question> initializeQuestions() {
        List<Question> list = new ArrayList<>();
        list.add(new Question(1,
            "What does the Java Virtual Machine (JVM) use to execute bytecode on the underlying operating system?",
            new String[]{
                "JIT Compiler & Bytecode Interpreter",
                "C++ Macro Preprocessor",
                "Direct Kernel Syscall Interceptor",
                "Python C-API Runtime Bridge"
            }, 0,
            "The JVM Execution Engine combines an Interpreter (which interprets bytecode line-by-line) and a Just-In-Time (JIT) Compiler (which compiles hot spots into native machine code)."));

        list.add(new Question(2,
            "Which Java memory region is specifically responsible for storing class object instances created with the 'new' keyword?",
            new String[]{
                "Heap Memory",
                "Call Stack Memory",
                "CPU Register Cache",
                "Instruction Pointer Buffer"
            }, 0,
            "All Java class instances and array objects are allocated in the Heap memory space, which is managed and cleaned up automatically by the Garbage Collector."));

        list.add(new Question(3,
            "Which Java keyword is applied to a class to prevent it from being subclassed, or to a method to prevent overriding?",
            new String[]{
                "final",
                "static",
                "abstract",
                "volatile"
            }, 0,
            "The 'final' keyword on a class prevents inheritance (subclassing), on a method prevents overriding in subclasses, and on a variable creates an immutable constant reference."));

        list.add(new Question(4,
            "On which specific thread must all Java Swing GUI components be instantiated, modified, and repainted to ensure thread safety?",
            new String[]{
                "Event Dispatch Thread (EDT)",
                "Main Application Bootstrap Thread",
                "Garbage Collector Daemon Thread",
                "Common ForkJoinPool Worker Thread"
            }, 0,
            "Java Swing is intentionally single-threaded for rendering. All GUI construction and state modifications must be executed on the Event Dispatch Thread (EDT) via SwingUtilities.invokeLater()."));

        list.add(new Question(5,
            "What is the average time complexity for retrieving a value by its key in a standard java.util.HashMap?",
            new String[]{
                "O(1)",
                "O(log n)",
                "O(n)",
                "O(n log n)"
            }, 0,
            "Assuming a well-distributed hash code implementation with minimal bucket collisions, HashMap achieves O(1) constant average time complexity for get() and put() operations."));

        list.add(new Question(6,
            "What is the primary role of the CardLayout layout manager in Java Swing applications?",
            new String[]{
                "Managing multiple panels where only one panel is visible at a time like cards in a deck",
                "Arranging components in a flexible two-dimensional grid of rows and columns",
                "Placing components in five directional zones (North, South, East, West, Center)",
                "Flowing components horizontally and wrapping them onto subsequent lines"
            }, 0,
            "CardLayout treats each child component as a card. Only one card is visible at any given time, making it ideal for step-by-step wizards and multi-screen apps without creating multiple JFrames."));

        list.add(new Question(7,
            "Which block in Java exception handling is guaranteed to execute whether an exception is thrown or caught (unless System.exit is invoked)?",
            new String[]{
                "finally",
                "catch",
                "throw",
                "throws"
            }, 0,
            "The 'finally' block is executed immediately after the try/catch blocks complete, ensuring critical cleanup (closing file handles, database connections, sockets) always occurs."));

        list.add(new Question(8,
            "Why should an exam countdown timer calculate remaining time using System.nanoTime() instead of simply decrementing a counter every tick?",
            new String[]{
                "Timer callbacks may drift or be delayed by OS scheduling or busy EDT queues, so elapsed monotonic time ensures exact precision",
                "System.nanoTime() automatically prevents students from clicking Next too quickly",
                "javax.swing.Timer can only fire up to 10 times before expiring",
                "Decrementing an integer variable causes race conditions on 64-bit JVMs"
            }, 0,
            "Timer events can experience jitter or delays if the CPU or EDT is temporarily occupied. Calculating remaining time from (startNanoTime + duration - currentNanoTime) guarantees real-world temporal accuracy."));

        list.add(new Question(9,
            "Which interface in the Java Collections Framework rejects duplicate elements and provides no guaranteed order by default?",
            new String[]{
                "Set",
                "List",
                "Queue",
                "Deque"
            }, 0,
            "The java.util.Set interface models the mathematical set abstraction: duplicate elements are prohibited, and standard implementations like HashSet do not guarantee any order of elements."));

        list.add(new Question(10,
            "Which Swing class is designed to execute long-running tasks asynchronously while safely publishing intermediate results to the EDT?",
            new String[]{
                "SwingWorker",
                "ThreadFactory",
                "ExecutorCompletionService",
                "ScheduledThreadPool"
            }, 0,
            "SwingWorker<T, V> is a specialized class that performs computation in a background thread and provides hooks like publish()/process() and done() to safely update GUI controls on the EDT."));

        return list;
    }
}
