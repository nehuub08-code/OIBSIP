package com.examsphere.gui;

import com.examsphere.model.ExamSession;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * InstructionsPanel displays examination rules, duration, marking scheme,
 * and starts the active session when the candidate is ready.
 */
public class InstructionsPanel extends JPanel {

    private final ExamFrame parentFrame;
    private JLabel candidateGreetingLabel;

    public InstructionsPanel(ExamFrame frame) {
        this.parentFrame = frame;
        setLayout(new BorderLayout());
        setBackground(new Color(248, 250, 252));

        buildUI();
    }

    private void buildUI() {
        JPanel contentCard = new JPanel();
        contentCard.setLayout(new BoxLayout(contentCard, BoxLayout.Y_AXIS));
        contentCard.setBackground(Color.WHITE);
        contentCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(226, 232, 240), 1),
            new EmptyBorder(32, 40, 32, 40)
        ));

        // Heading
        JLabel titleLabel = new JLabel("Online Examination Instructions");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(new Color(15, 23, 42));

        candidateGreetingLabel = new JLabel("Candidate: Neha Vinod Borkar");
        candidateGreetingLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        candidateGreetingLabel.setForeground(new Color(71, 85, 105));

        // Details grid
        JPanel specsPanel = new JPanel(new GridLayout(4, 2, 12, 10));
        specsPanel.setBackground(new Color(248, 250, 252));
        specsPanel.setBorder(new EmptyBorder(16, 20, 16, 20));

        specsPanel.add(createSpecItem("Subject / Track:", "Java Development (Task 4)"));
        specsPanel.add(createSpecItem("Total Questions:", "10 Multiple Choice Questions"));
        specsPanel.add(createSpecItem("Duration Allowed:", "30 Minutes (Countdown Timer)"));
        specsPanel.add(createSpecItem("Total Marks:", "10 Marks (1 mark each)"));
        specsPanel.add(createSpecItem("Marking Scheme:", "+1 for Correct, 0 for Incorrect"));
        specsPanel.add(createSpecItem("Negative Marking:", "None (0 penalty)"));
        specsPanel.add(createSpecItem("Unanswered Questions:", "0 marks (No penalty)"));
        specsPanel.add(createSpecItem("Submission Mechanism:", "Manual or Automatic on Expiry"));

        // Rules area
        JTextArea rulesText = new JTextArea();
        rulesText.setEditable(false);
        rulesText.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        rulesText.setForeground(new Color(51, 65, 85));
        rulesText.setBackground(Color.WHITE);
        rulesText.setLineWrap(true);
        rulesText.setWrapStyleWord(true);
        rulesText.setText(
            "1. Each question presents 4 mutually exclusive options using standard radio buttons.
" +
            "2. You may navigate freely between questions using the Next and Previous buttons without losing answers.
" +
            "3. An accurate countdown timer continuously displays remaining time computed using System.nanoTime().
" +
            "4. When the countdown reaches 00:00, the exam is automatically submitted with zero data loss.
" +
            "5. You can submit early via 'Submit Exam'; a confirmation prompt will ask you to confirm.
" +
            "6. Closing the window during an active exam will prompt to submit before termination."
        );

        // Buttons
        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        actionRow.setBackground(Color.WHITE);

        JButton backButton = new JButton("<- Back to Profile");
        backButton.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        backButton.setBackground(new Color(241, 245, 249));
        backButton.setFocusPainted(false);
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backButton.addActionListener(e -> parentFrame.showScreen(ExamFrame.SCREEN_PROFILE));

        JButton startButton = new JButton("Start Examination Now");
        startButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        startButton.setBackground(new Color(22, 101, 52));
        startButton.setForeground(Color.WHITE);
        startButton.setFocusPainted(false);
        startButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        startButton.addActionListener(e -> startExam());

        actionRow.add(backButton);
        actionRow.add(startButton);

        contentCard.add(titleLabel);
        contentCard.add(Box.createVerticalStrut(4));
        contentCard.add(candidateGreetingLabel);
        contentCard.add(Box.createVerticalStrut(18));
        contentCard.add(specsPanel);
        contentCard.add(Box.createVerticalStrut(18));
        contentCard.add(rulesText);
        contentCard.add(Box.createVerticalStrut(24));
        contentCard.add(actionRow);

        JPanel outer = new JPanel(new GridBagLayout());
        outer.setBackground(new Color(248, 250, 252));
        outer.add(contentCard);

        add(outer, BorderLayout.CENTER);
    }

    private JPanel createSpecItem(String label, String value) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        p.setBackground(new Color(248, 250, 252));
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lbl.setForeground(new Color(71, 85, 105));
        JLabel val = new JLabel(value);
        val.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        val.setForeground(new Color(15, 23, 42));
        p.add(lbl);
        p.add(val);
        return p;
    }

    public void refreshDetails() {
        candidateGreetingLabel.setText("Candidate: " + parentFrame.getCurrentUser().getDisplayName());
    }

    private void startExam() {
        // Prevent simultaneous duplicate sessions
        if (parentFrame.getActiveSession() != null && !parentFrame.getActiveSession().isSubmitted()) {
            JOptionPane.showMessageDialog(this, "An active session already exists.", "Session Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Standard 30 minutes duration (1800 seconds)
        int durationSeconds = 30 * 60;
        ExamSession session = new ExamSession(parentFrame.getCurrentUser(), parentFrame.getQuestionBank(), durationSeconds);
        parentFrame.setActiveSession(session);

        // Initialize exam panel with this session
        parentFrame.getExamPanel().initializeSession(session);
        parentFrame.showScreen(ExamFrame.SCREEN_EXAM);
    }
}
