package com.examsphere.model;

/**
 * Encapsulates an individual Multiple Choice Question (MCQ).
 * Keeps answer key separated from GUI presentations.
 */
public class Question {

    private final int id;
    private final String questionText;
    private final String[] options;
    private final int correctAnswerIndex; // 0, 1, 2, or 3
    private final String explanation;

    public Question(int id, String questionText, String[] options, int correctAnswerIndex, String explanation) {
        if (options == null || options.length != 4) {
            throw new IllegalArgumentException("Each question must contain exactly 4 options.");
        }
        if (correctAnswerIndex < 0 || correctAnswerIndex >= 4) {
            throw new IllegalArgumentException("Correct answer index must be between 0 and 3.");
        }
        this.id = id;
        this.questionText = questionText;
        this.options = options.clone();
        this.correctAnswerIndex = correctAnswerIndex;
        this.explanation = explanation != null ? explanation : "";
    }

    public int getId() {
        return id;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String[] getOptions() {
        return options.clone();
    }

    public int getCorrectAnswerIndex() {
        return correctAnswerIndex;
    }

    public String getExplanation() {
        return explanation;
    }

    public boolean isCorrect(int selectedIndex) {
        return this.correctAnswerIndex == selectedIndex;
    }
}
