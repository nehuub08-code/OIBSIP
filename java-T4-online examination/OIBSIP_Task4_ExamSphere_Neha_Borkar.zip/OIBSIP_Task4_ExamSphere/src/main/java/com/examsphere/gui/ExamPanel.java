package com.examsphere.gui;

import com.examsphere.model.ExamSession;
import com.examsphere.model.Question;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * ExamPanel renders the examination environment:
 * - One MCQ at a time with 4 radio buttons inside a ButtonGroup
 * - Real-time countdown timer utilizing System.nanoTime() for drift-free accuracy
 * - Next, Previous, and Submit controls with answer state preservation
 * - Question palette for visual status and direct jump navigation
 * - Single, guarded submission ensuring no double submissions
 */
public class ExamPanel extends JPanel {

    private final ExamFrame parentFrame;
    private ExamSession session;
    private int currentQuestionIndex = 0;

    private JLabel studentNameLabel;
    private JLabel questionIndexLabel;
    private JLabel timerLabel;
    private JProgressBar examProgressBar;

    private JTextArea questionArea;
    private JRadioButton[] optionButtons;
    private ButtonGroup optionGroup;

    private JButton prevButton;
    private JButton nextButton;
    private JButton submitButton;

    private JButton[] paletteButtons;

    private Timer countdownTimer;
    private final AtomicBoolean submissionGuarded = new AtomicBoolean(false);

    public ExamPanel(ExamFrame frame) {
        this.parentFrame = frame;
        setLayout(new BorderLayout());
        setBackground(new Color(248, 250, 252));

        buildUI();
    }

    private void buildUI() {
        // Top Bar: Candidate name, progress indicator, countdown timer
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(Color.WHITE);
        topBar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(226, 232, 240)),
            new EmptyBorder(14, 24, 14, 24)
        ));

        studentNameLabel = new JLabel("Candidate: Neha Vinod Borkar");
        studentNameLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        studentNameLabel.setForeground(new Color(15, 23, 42));

        questionIndexLabel = new JLabel("Question 1 of 10");
        questionIndexLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        questionIndexLabel.setForeground(new Color(100, 116, 139));

        JPanel leftMeta = new JPanel(new GridLayout(2, 1, 0, 2));
        leftMeta.setBackground(Color.WHITE);
        leftMeta.add(studentNameLabel);
        leftMeta.add(questionIndexLabel);

        // Timer badge
        timerLabel = new JLabel("Time Remaining: 30:00");
        timerLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        timerLabel.setForeground(new Color(37, 99, 235));

        topBar.add(leftMeta, BorderLayout.WEST);
        topBar.add(timerLabel, BorderLayout.EAST);

        // Center Content Area: Question + Options + Palette
        JPanel centerPanel = new JPanel(new BorderLayout(20, 0));
        centerPanel.setBackground(new Color(248, 250, 252));
        centerPanel.setBorder(new EmptyBorder(20, 24, 20, 24));

        // Question card
        JPanel questionCard = new JPanel(new BorderLayout(0, 16));
        questionCard.setBackground(Color.WHITE);
        questionCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(226, 232, 240), 1),
            new EmptyBorder(24, 28, 24, 28)
        ));

        questionArea = new JTextArea();
        questionArea.setFont(new Font("Segoe UI", Font.BOLD, 16));
        questionArea.setForeground(new Color(15, 23, 42));
        questionArea.setWrapStyleWord(true);
        questionArea.setLineWrap(true);
        questionArea.setEditable(false);
        questionArea.setBackground(Color.WHITE);
        questionArea.setBorder(null);

        // Radio button options
        JPanel optionsPanel = new JPanel(new GridLayout(4, 1, 0, 12));
        optionsPanel.setBackground(Color.WHITE);
        optionGroup = new ButtonGroup();
        optionButtons = new JRadioButton[4];

        for (int i = 0; i < 4; i++) {
            optionButtons[i] = new JRadioButton();
            optionButtons[i].setFont(new Font("Segoe UI", Font.PLAIN, 14));
            optionButtons[i].setForeground(new Color(51, 65, 85));
            optionButtons[i].setBackground(Color.WHITE);
            optionButtons[i].setFocusPainted(false);
            final int optIndex = i;
            optionButtons[i].addActionListener(e -> {
                if (session != null) {
                    session.recordAnswer(currentQuestionIndex, optIndex);
                    updatePaletteStatus();
                }
            });
            optionGroup.add(optionButtons[i]);
            optionsPanel.add(optionButtons[i]);
        }

        questionCard.add(questionArea, BorderLayout.NORTH);
        questionCard.add(optionsPanel, BorderLayout.CENTER);

        // Right side: Question Palette
        JPanel rightPaletteCard = new JPanel(new BorderLayout(0, 12));
        rightPaletteCard.setBackground(Color.WHITE);
        rightPaletteCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(226, 232, 240), 1),
            new EmptyBorder(16, 16, 16, 16)
        ));
        rightPaletteCard.setPreferredSize(new Dimension(200, 0));

        JLabel paletteTitle = new JLabel("Question Palette");
        paletteTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        paletteTitle.setForeground(new Color(15, 23, 42));

        JPanel gridPanel = new JPanel(new GridLayout(5, 2, 6, 6));
        gridPanel.setBackground(Color.WHITE);
        paletteButtons = new JButton[10];
        for (int i = 0; i < 10; i++) {
            final int qIndex = i;
            paletteButtons[i] = new JButton(String.valueOf(i + 1));
            paletteButtons[i].setFont(new Font("Segoe UI", Font.BOLD, 12));
            paletteButtons[i].setFocusPainted(false);
            paletteButtons[i].setBackground(new Color(241, 245, 249));
            paletteButtons[i].setCursor(new Cursor(Cursor.HAND_CURSOR));
            paletteButtons[i].addActionListener(e -> jumpToQuestion(qIndex));
            gridPanel.add(paletteButtons[i]);
        }

        rightPaletteCard.add(paletteTitle, BorderLayout.NORTH);
        rightPaletteCard.add(gridPanel, BorderLayout.CENTER);

        centerPanel.add(questionCard, BorderLayout.CENTER);
        centerPanel.add(rightPaletteCard, BorderLayout.EAST);

        // Bottom Action Bar
        JPanel bottomBar = new JPanel(new BorderLayout());
        bottomBar.setBackground(Color.WHITE);
        bottomBar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(226, 232, 240)),
            new EmptyBorder(14, 24, 14, 24)
        ));

        JPanel navControls = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        navControls.setBackground(Color.WHITE);

        prevButton = new JButton("<- Previous");
        prevButton.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        prevButton.setBackground(new Color(241, 245, 249));
        prevButton.setFocusPainted(false);
        prevButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        prevButton.addActionListener(e -> navigatePrevious());

        nextButton = new JButton("Next ->");
        nextButton.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        nextButton.setBackground(new Color(241, 245, 249));
        nextButton.setFocusPainted(false);
        nextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        nextButton.addActionListener(e -> navigateNext());

        navControls.add(prevButton);
        navControls.add(nextButton);

        submitButton = new JButton("Submit Exam");
        submitButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        submitButton.setBackground(new Color(220, 38, 38));
        submitButton.setForeground(Color.WHITE);
        submitButton.setFocusPainted(false);
        submitButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        submitButton.addActionListener(e -> confirmManualSubmission());

        bottomBar.add(navControls, BorderLayout.WEST);
        bottomBar.add(submitButton, BorderLayout.EAST);

        add(topBar, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(bottomBar, BorderLayout.SOUTH);
    }

    public void initializeSession(ExamSession examSession) {
        this.session = examSession;
        this.currentQuestionIndex = 0;
        this.submissionGuarded.set(false);

        studentNameLabel.setText("Candidate: " + session.getUser().getDisplayName());

        // Start countdown timer with exact monotonic nanoTime tracking
        startCountdownTimer();

        // Render first question
        renderQuestion(0);
        updatePaletteStatus();
    }

    private void startCountdownTimer() {
        if (countdownTimer != null && countdownTimer.isRunning()) {
            countdownTimer.stop();
        }

        countdownTimer = new Timer(1000, e -> {
            long remainingSeconds = session.calculateRemainingSeconds();

            if (remainingSeconds <= 0) {
                timerLabel.setText("Time Remaining: 00:00");
                timerLabel.setForeground(new Color(220, 38, 38));
                // Automatically submit the exam upon timer expiration
                submitExam(ExamSession.SubmissionType.AUTO_TIME_EXPIRED);
            } else {
                long minutes = remainingSeconds / 60;
                long seconds = remainingSeconds % 60;
                String timeFormatted = String.format("%02d:%02d", minutes, seconds);
                timerLabel.setText("Time Remaining: " + timeFormatted);

                if (remainingSeconds < 300) { // Under 5 minutes warning
                    timerLabel.setForeground(new Color(220, 38, 38));
                } else {
                    timerLabel.setForeground(new Color(37, 99, 235));
                }
            }
        });
        countdownTimer.setInitialDelay(0);
        countdownTimer.start();
    }

    private void renderQuestion(int index) {
        if (session == null || index < 0 || index >= session.getQuestions().size()) return;

        currentQuestionIndex = index;
        Question q = session.getQuestions().get(index);

        questionIndexLabel.setText("Question " + (index + 1) + " of " + session.getQuestions().size());
        questionArea.setText((index + 1) + ". " + q.getQuestionText());

        // Clear previous radio selection state
        optionGroup.clearSelection();

        String[] options = q.getOptions();
        for (int i = 0; i < 4; i++) {
            optionButtons[i].setText("  " + (char)('A' + i) + ")  " + options[i]);
        }

        // Restore any previously recorded answer for this question
        Integer savedAnswer = session.getRecordedAnswer(index);
        if (savedAnswer != null && savedAnswer >= 0 && savedAnswer < 4) {
            optionButtons[savedAnswer].setSelected(true);
        }

        // Manage navigation button states
        prevButton.setEnabled(currentQuestionIndex > 0);
        nextButton.setEnabled(currentQuestionIndex < session.getQuestions().size() - 1);

        updatePaletteHighlight();
    }

    private void navigatePrevious() {
        if (currentQuestionIndex > 0) {
            renderQuestion(currentQuestionIndex - 1);
        }
    }

    private void navigateNext() {
        if (currentQuestionIndex < session.getQuestions().size() - 1) {
            renderQuestion(currentQuestionIndex + 1);
        }
    }

    private void jumpToQuestion(int targetIndex) {
        renderQuestion(targetIndex);
    }

    private void updatePaletteStatus() {
        if (session == null) return;
        for (int i = 0; i < paletteButtons.length; i++) {
            Integer ans = session.getRecordedAnswer(i);
            if (ans != null) {
                // Answered: Emerald green background
                paletteButtons[i].setBackground(new Color(220, 252, 231));
                paletteButtons[i].setForeground(new Color(22, 101, 52));
            } else {
                paletteButtons[i].setBackground(new Color(241, 245, 249));
                paletteButtons[i].setForeground(new Color(51, 65, 85));
            }
        }
        updatePaletteHighlight();
    }

    private void updatePaletteHighlight() {
        for (int i = 0; i < paletteButtons.length; i++) {
            if (i == currentQuestionIndex) {
                paletteButtons[i].setBorder(BorderFactory.createLineBorder(new Color(37, 99, 235), 2));
            } else {
                paletteButtons[i].setBorder(BorderFactory.createLineBorder(new Color(203, 213, 225), 1));
            }
        }
    }

    private void confirmManualSubmission() {
        int unansweredCount = session.getUnansweredCount();
        String message = "Are you sure you want to submit your examination?";
        if (unansweredCount > 0) {
            message += "\n\nNotice: You have " + unansweredCount + " unanswered question(s).";
        }

        int choice = JOptionPane.showConfirmDialog(
            this,
            message,
            "Confirm Exam Submission",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (choice == JOptionPane.YES_OPTION) {
            submitExam(ExamSession.SubmissionType.MANUAL);
        }
    }

    /**
     * Guarded single-submission handler.
     * Prevents race conditions between manual button clicks and timer events.
     */
    public synchronized void submitExam(ExamSession.SubmissionType submissionType) {
        if (!submissionGuarded.compareAndSet(false, true)) {
            // Exam already finalized, reject duplicate submission attempt
            return;
        }

        // Stop timer immediately
        if (countdownTimer != null) {
            countdownTimer.stop();
        }

        // Finalize session calculations
        session.finalizeExam(submissionType);

        if (submissionType == ExamSession.SubmissionType.AUTO_TIME_EXPIRED) {
            JOptionPane.showMessageDialog(
                this,
                "Time has expired! Your examination has been automatically submitted.",
                "Time Expired",
                JOptionPane.INFORMATION_MESSAGE
            );
        }

        // Populate result panel and switch card
        parentFrame.getResultPanel().displayResult(session);
        parentFrame.showScreen(ExamFrame.SCREEN_RESULT);
    }
}
