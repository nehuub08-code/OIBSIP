package com.examsphere.gui;

import com.examsphere.model.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * LoginPanel handles user authentication.
 * Rejects empty fields, validates credentials against the User store,
 * and advances to ProfilePanel upon success.
 */
public class LoginPanel extends JPanel {

    private final ExamFrame parentFrame;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JLabel errorLabel;
    private JButton loginButton;

    public LoginPanel(ExamFrame frame) {
        this.parentFrame = frame;
        setLayout(new GridBagLayout());
        setBackground(new Color(248, 250, 252));

        buildUI();
    }

    private void buildUI() {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(226, 232, 240), 1),
            new EmptyBorder(32, 40, 32, 40)
        ));
        card.setPreferredSize(new Dimension(440, 480));

        // Header Title
        JLabel titleLabel = new JLabel("ExamSphere");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titleLabel.setForeground(new Color(15, 23, 42));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitleLabel = new JLabel("Online Examination System — Oasis Infobyte Task 4");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitleLabel.setForeground(new Color(100, 116, 139));
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Error message area
        errorLabel = new JLabel(" ");
        errorLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        errorLabel.setForeground(new Color(220, 38, 38));
        errorLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Username Field
        JLabel userLabel = new JLabel("Username");
        userLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        userLabel.setForeground(new Color(51, 65, 85));
        userLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        usernameField = new JTextField("oasis_student", 20);
        usernameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        usernameField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        usernameField.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Password Field
        JLabel passLabel = new JLabel("Password");
        passLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        passLabel.setForeground(new Color(51, 65, 85));
        passLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        passwordField = new JPasswordField("Password@123", 20);
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passwordField.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Login Action Button
        loginButton = new JButton("Sign In to Portal");
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBackground(new Color(37, 99, 235));
        loginButton.setFocusPainted(false);
        loginButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        loginButton.addActionListener(e -> attemptLogin());

        // Enter key listeners
        KeyAdapter enterKeyAdapter = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    attemptLogin();
                }
            }
        };
        usernameField.addKeyListener(enterKeyAdapter);
        passwordField.addKeyListener(enterKeyAdapter);

        // Demo credentials hint
        JLabel hintLabel = new JLabel("<html><center><font color='#64748b'>Demo Credentials:<br/><b>oasis_student</b> / <b>Password@123</b></font></center></html>");
        hintLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        hintLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Assemble panel with spacing
        card.add(titleLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(subtitleLabel);
        card.add(Box.createVerticalStrut(16));
        card.add(errorLabel);
        card.add(Box.createVerticalStrut(12));
        card.add(userLabel);
        card.add(Box.createVerticalStrut(6));
        card.add(usernameField);
        card.add(Box.createVerticalStrut(14));
        card.add(passLabel);
        card.add(Box.createVerticalStrut(6));
        card.add(passwordField);
        card.add(Box.createVerticalStrut(24));
        card.add(loginButton);
        card.add(Box.createVerticalStrut(16));
        card.add(hintLabel);

        add(card);
    }

    private void attemptLogin() {
        String enteredUsername = usernameField.getText().trim();
        String enteredPassword = new String(passwordField.getPassword());

        errorLabel.setText(" ");

        if (enteredUsername.isEmpty() || enteredPassword.isEmpty()) {
            errorLabel.setText("Username and password cannot be empty.");
            return;
        }

        User user = parentFrame.getCurrentUser();
        if (user.validateCredentials(enteredUsername, enteredPassword)) {
            errorLabel.setText(" ");
            // Clear password field for security
            passwordField.setText("");
            // Update profile panel with authenticated user details
            parentFrame.getProfilePanel().refreshUserData();
            // Switch to profile update screen
            parentFrame.showScreen(ExamFrame.SCREEN_PROFILE);
        } else {
            errorLabel.setText("Invalid username or password. Please try again.");
            passwordField.setText("");
            passwordField.requestFocusInWindow();
        }
    }

    public void resetForm() {
        usernameField.setText("oasis_student");
        passwordField.setText("");
        errorLabel.setText(" ");
    }
}
