package com.examsphere.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Tracks an active examination session:
 * - Candidate reference
 * - List of questions
 * - Student answers map (questionIndex -> optionIndex)
 * - Monotonic start time via System.nanoTime() for precise remaining time calculations
 * - Finalization and scoring calculations
 */
public class ExamSession {

    public enum SubmissionType {
        MANUAL,
        AUTO_TIME_EXPIRED,
        WINDOW_CLOSED
    }

    private final User user;
    private final List<Question> questions;
    private final Map<Integer, Integer> recordedAnswers;
    private final int durationSeconds;

    private final long startNanoTime;
    private long endNanoTime;
    private boolean submitted = false;
    private SubmissionType submissionType;

    private int score = 0;
    private int correctCount = 0;
    private int incorrectCount = 0;
    private int unansweredCount = 0;

    public ExamSession(User user, List<Question> questions, int durationSeconds) {
        this.user = user;
        this.questions = questions;
        this.durationSeconds = durationSeconds;
        this.recordedAnswers = new HashMap<>();
        this.startNanoTime = System.nanoTime();
    }

    public synchronized void recordAnswer(int questionIndex, int optionIndex) {
        if (!submitted) {
            recordedAnswers.put(questionIndex, optionIndex);
        }
    }

    public synchronized Integer getRecordedAnswer(int questionIndex) {
        return recordedAnswers.get(questionIndex);
    }

    public long calculateRemainingSeconds() {
        if (submitted) return 0;
        long elapsedNanos = System.nanoTime() - startNanoTime;
        long elapsedSeconds = elapsedNanos / 1_000_000_000L;
        long remaining = durationSeconds - elapsedSeconds;
        return Math.max(0, remaining);
    }

    public long getTimeTakenSeconds() {
        long end = submitted ? endNanoTime : System.nanoTime();
        return Math.max(0, (end - startNanoTime) / 1_000_000_000L);
    }

    public synchronized void finalizeExam(SubmissionType type) {
        if (this.submitted) return;

        this.submitted = true;
        this.endNanoTime = System.nanoTime();
        this.submissionType = type;

        // Calculate score from answer key
        score = 0;
        correctCount = 0;
        incorrectCount = 0;
        unansweredCount = 0;

        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            Integer ans = recordedAnswers.get(i);

            if (ans == null) {
                unansweredCount++;
            } else if (q.isCorrect(ans)) {
                correctCount++;
                score += 1; // 1 mark per correct answer
            } else {
                incorrectCount++;
            }
        }
    }

    public int getUnansweredCount() {
        if (submitted) return unansweredCount;
        int count = 0;
        for (int i = 0; i < questions.size(); i++) {
            if (!recordedAnswers.containsKey(i)) {
                count++;
            }
        }
        return count;
    }

    public User getUser() {
        return user;
    }

    public List<Question> getQuestions() {
        return questions;
    }

    public int getTotalQuestions() {
        return questions.size();
    }

    public boolean isSubmitted() {
        return submitted;
    }

    public SubmissionType getSubmissionType() {
        return submissionType;
    }

    public int getScore() {
        return score;
    }

    public int getCorrectCount() {
        return correctCount;
    }

    public int getIncorrectCount() {
        return incorrectCount;
    }

    public double getPercentage() {
        if (questions.isEmpty()) return 0.0;
        return ((double) score / questions.size()) * 100.0;
    }
}
