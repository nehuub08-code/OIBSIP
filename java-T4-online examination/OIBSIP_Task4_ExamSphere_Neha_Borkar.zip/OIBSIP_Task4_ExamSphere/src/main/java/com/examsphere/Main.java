package com.examsphere;

import com.examsphere.gui.ExamFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * ExamSphere — Online Examination System
 * Oasis Infobyte Java Development Task 4
 *
 * Developer: Neha Vinod Borkar
 * Track: Java Development
 *
 * Entry point for launching the ExamSphere Swing desktop application.
 * Ensures all Swing components are constructed on the Event Dispatch Thread (EDT).
 */
public class Main {

    public static void main(String[] args) {
        // Schedule GUI instantiation on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            try {
                // Apply modern Nimbus or platform System Look and Feel
                boolean nimbusFound = false;
                for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        UIManager.setLookAndFeel(info.getClassName());
                        nimbusFound = true;
                        break;
                    }
                }
                if (!nimbusFound) {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                }
            } catch (ClassNotFoundException | InstantiationException |
                     IllegalAccessException | UnsupportedLookAndFeelException e) {
                System.err.println("Notice: Defaulting to standard Swing Look & Feel (" + e.getMessage() + ")");
            }

            // Create and display the main application window
            ExamFrame examFrame = new ExamFrame();
            examFrame.setVisible(true);
        });
    }
}
