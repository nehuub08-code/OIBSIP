package com.examsphere.model;

/**
 * Represents an authenticated user in the ExamSphere system.
 * Supports updating display name and password in memory.
 */
public class User {

    private final String username;
    private String password;
    private String displayName;

    public User(String username, String password, String displayName) {
        this.username = username;
        this.password = password;
        this.displayName = displayName;
    }

    public boolean validateCredentials(String user, String pass) {
        if (user == null || pass == null) return false;
        return this.username.trim().equalsIgnoreCase(user.trim()) && this.password.equals(pass);
    }

    public String getUsername() {
        return username;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        if (displayName != null && !displayName.trim().isEmpty()) {
            this.displayName = displayName.trim();
        }
    }

    public void setPassword(String newPassword) {
        if (newPassword != null && !newPassword.trim().isEmpty()) {
            this.password = newPassword;
        }
    }
}
