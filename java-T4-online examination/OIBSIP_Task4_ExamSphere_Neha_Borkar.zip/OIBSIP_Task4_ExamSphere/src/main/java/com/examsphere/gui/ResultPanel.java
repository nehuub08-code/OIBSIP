package com.examsphere.gui;

import com.examsphere.model.ExamSession;
import com.examsphere.model.Question;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * ResultPanel displays:
 * - Candidate name, exam title, and final score tally
 * - Breakdown: Correct, Incorrect, Unanswered, Time Taken, Submission Type
 * - Comprehensive question-by-question review with explanations
 * - Logout button that clears the active session and returns to login
 */
public class ResultPanel extends JPanel {

    private final ExamFrame parentFrame;
    private JLabel candidateNameLabel;
    private JLabel scoreBadgeLabel;
    private JLabel percentageLabel;
    private JLabel timeTakenLabel;
    private JLabel submissionModeLabel;
    private JLabel correctCountLabel;
    private JLabel incorrectCountLabel;
    private JLabel unansweredCountLabel;

    private JPanel questionsReviewContainer;
    private JScrollPane scrollPane;

    public ResultPanel(ExamFrame frame) {
        this.parentFrame = frame;
        setLayout(new BorderLayout());
        setBackground(new Color(248, 250, 252));

        buildUI();
    }

    private void buildUI() {
        // Top Summary Card
        JPanel topSummary = new JPanel();
        topSummary.setLayout(new BoxLayout(topSummary, BoxLayout.Y_AXIS));
        topSummary.setBackground(Color.WHITE);
        topSummary.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(226, 232, 240)),
            new EmptyBorder(20, 28, 20, 28)
        ));

        JLabel titleLabel = new JLabel("Examination Result Summary");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(new Color(15, 23, 42));

        candidateNameLabel = new JLabel("Candidate: Neha Vinod Borkar");
        candidateNameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        candidateNameLabel.setForeground(new Color(71, 85, 105));

        // Metric badges row
        JPanel metricRow = new JPanel(new GridLayout(1, 5, 12, 0));
        metricRow.setBackground(Color.WHITE);
        metricRow.setBorder(new EmptyBorder(12, 0, 4, 0));

        scoreBadgeLabel = createMetricBadge("Score", "0 / 10", new Color(37, 99, 235));
        percentageLabel = createMetricBadge("Percentage", "0%", new Color(15, 23, 42));
        correctCountLabel = createMetricBadge("Correct", "0", new Color(22, 101, 52));
        incorrectCountLabel = createMetricBadge("Incorrect", "0", new Color(220, 38, 38));
        unansweredCountLabel = createMetricBadge("Unanswered", "0", new Color(202, 138, 4));

        metricRow.add(scoreBadgeLabel.getParent());
        metricRow.add(percentageLabel.getParent());
        metricRow.add(correctCountLabel.getParent());
        metricRow.add(incorrectCountLabel.getParent());
        metricRow.add(unansweredCountLabel.getParent());

        // Secondary metadata
        JPanel metaRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 4));
        metaRow.setBackground(Color.WHITE);

        timeTakenLabel = new JLabel("Time Taken: 00:00");
        timeTakenLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        timeTakenLabel.setForeground(new Color(100, 116, 139));

        submissionModeLabel = new JLabel("Submission: Manual");
        submissionModeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        submissionModeLabel.setForeground(new Color(100, 116, 139));

        metaRow.add(timeTakenLabel);
        metaRow.add(new JLabel("•"));
        metaRow.add(submissionModeLabel);

        topSummary.add(titleLabel);
        topSummary.add(Box.createVerticalStrut(4));
        topSummary.add(candidateNameLabel);
        topSummary.add(Box.createVerticalStrut(10));
        topSummary.add(metricRow);
        topSummary.add(Box.createVerticalStrut(6));
        topSummary.add(metaRow);

        // Center: Question Review ScrollPane
        questionsReviewContainer = new JPanel();
        questionsReviewContainer.setLayout(new BoxLayout(questionsReviewContainer, BoxLayout.Y_AXIS));
        questionsReviewContainer.setBackground(new Color(248, 250, 252));
        questionsReviewContainer.setBorder(new EmptyBorder(16, 24, 16, 24));

        scrollPane = new JScrollPane(questionsReviewContainer);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        // Bottom Action Bar: Logout and Retake options
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        bottomBar.setBackground(Color.WHITE);
        bottomBar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(226, 232, 240)));

        JButton logoutButton = new JButton("Logout & Return to Login");
        logoutButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        logoutButton.setBackground(new Color(15, 23, 42));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutButton.addActionListener(e -> performLogout());

        bottomBar.add(logoutButton);

        add(topSummary, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomBar, BorderLayout.SOUTH);
    }

    private JLabel createMetricBadge(String title, String val, Color color) {
        JPanel box = new JPanel(new GridLayout(2, 1, 0, 2));
        box.setBackground(new Color(248, 250, 252));
        box.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(226, 232, 240), 1),
            new EmptyBorder(8, 12, 8, 12)
        ));

        JLabel t = new JLabel(title);
        t.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        t.setForeground(new Color(100, 116, 139));

        JLabel v = new JLabel(val);
        v.setFont(new Font("Segoe UI", Font.BOLD, 16));
        v.setForeground(color);

        box.add(t);
        box.add(v);
        return v;
    }

    public void displayResult(ExamSession session) {
        candidateNameLabel.setText("Candidate: " + session.getUser().getDisplayName() + " (" + session.getUser().getUsername() + ")");
        scoreBadgeLabel.setText(session.getScore() + " / " + session.getTotalQuestions());
        percentageLabel.setText(session.getPercentage() + "%");
        correctCountLabel.setText(String.valueOf(session.getCorrectCount()));
        incorrectCountLabel.setText(String.valueOf(session.getIncorrectCount()));
        unansweredCountLabel.setText(String.valueOf(session.getUnansweredCount()));

        long seconds = session.getTimeTakenSeconds();
        timeTakenLabel.setText("Time Taken: " + String.format("%02d min %02d sec", seconds / 60, seconds % 60));

        String subDesc = switch (session.getSubmissionType()) {
            case AUTO_TIME_EXPIRED -> "Automatic (Time Expired)";
            case WINDOW_CLOSED -> "Submitted on Window Close";
            default -> "Manual Submission by Candidate";
        };
        submissionModeLabel.setText("Submission: " + subDesc);

        // Populate question-by-question breakdown
        questionsReviewContainer.removeAll();

        for (int i = 0; i < session.getQuestions().size(); i++) {
            Question q = session.getQuestions().get(i);
            Integer studentAns = session.getRecordedAnswer(i);
            boolean isAnswered = studentAns != null;
            boolean isCorrect = isAnswered && studentAns == q.getCorrectAnswerIndex();

            JPanel itemCard = new JPanel();
            itemCard.setLayout(new BoxLayout(itemCard, BoxLayout.Y_AXIS));
            itemCard.setBackground(Color.WHITE);
            itemCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(14, 16, 14, 16)
            ));
            itemCard.setAlignmentX(Component.LEFT_ALIGNMENT);

            // Question header
            String statusBadge;
            Color statusColor;
            if (!isAnswered) {
                statusBadge = "[NOT ANSWERED]";
                statusColor = new Color(202, 138, 4);
            } else if (isCorrect) {
                statusBadge = "[CORRECT]";
                statusColor = new Color(22, 101, 52);
            } else {
                statusBadge = "[INCORRECT]";
                statusColor = new Color(220, 38, 38);
            }

            JLabel qTitle = new JLabel("Question " + (i + 1) + ": " + q.getQuestionText() + "  " + statusBadge);
            qTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
            qTitle.setForeground(statusColor);

            String studentAnsText = isAnswered
                ? (char)('A' + studentAns) + ") " + q.getOptions()[studentAns]
                : "Not Answered";
            JLabel studentLbl = new JLabel("Your Answer: " + studentAnsText);
            studentLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            studentLbl.setForeground(isCorrect ? new Color(22, 101, 52) : new Color(220, 38, 38));

            String correctAnsText = (char)('A' + q.getCorrectAnswerIndex()) + ") " + q.getOptions()[q.getCorrectAnswerIndex()];
            JLabel correctLbl = new JLabel("Correct Answer: " + correctAnsText);
            correctLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
            correctLbl.setForeground(new Color(15, 23, 42));

            JLabel explanationLbl = new JLabel("<html><font color='#64748b'>Explanation: " + q.getExplanation() + "</font></html>");
            explanationLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));

            itemCard.add(qTitle);
            itemCard.add(Box.createVerticalStrut(4));
            itemCard.add(studentLbl);
            itemCard.add(Box.createVerticalStrut(2));
            itemCard.add(correctLbl);
            itemCard.add(Box.createVerticalStrut(4));
            itemCard.add(explanationLbl);

            questionsReviewContainer.add(itemCard);
            questionsReviewContainer.add(Box.createVerticalStrut(10));
        }

        questionsReviewContainer.revalidate();
        questionsReviewContainer.repaint();
    }

    private void performLogout() {
        int choice = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to log out?\nYour session will be cleared and you will return to the login screen.",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (choice == JOptionPane.YES_OPTION) {
            // Clear active session to ensure answers are never leaked into future attempts
            parentFrame.setActiveSession(null);
            parentFrame.getLoginPanel().resetForm();
            parentFrame.showScreen(ExamFrame.SCREEN_LOGIN);
        }
    }
}
