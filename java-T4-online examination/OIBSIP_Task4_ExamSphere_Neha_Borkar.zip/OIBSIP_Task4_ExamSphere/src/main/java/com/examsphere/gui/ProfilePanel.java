package com.examsphere.gui;

import com.examsphere.model.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * ProfilePanel allows the candidate to update their Display Name
 * and optionally update their password prior to commencing the examination.
 */
public class ProfilePanel extends JPanel {

    private final ExamFrame parentFrame;

    private JLabel currentUsernameLabel;
    private JTextField displayNameField;
    private JPasswordField newPasswordField;
    private JPasswordField confirmPasswordField;
    private JLabel statusMessageLabel;

    public ProfilePanel(ExamFrame frame) {
        this.parentFrame = frame;
        setLayout(new GridBagLayout());
        setBackground(new Color(248, 250, 252));

        buildUI();
    }

    private void buildUI() {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(226, 232, 240), 1),
            new EmptyBorder(32, 40, 32, 40)
        ));
        card.setPreferredSize(new Dimension(520, 560));

        JLabel titleLabel = new JLabel("Candidate Profile");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(new Color(15, 23, 42));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitleLabel = new JLabel("Verify and update your details before beginning the examination.");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitleLabel.setForeground(new Color(100, 116, 139));
        subtitleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        statusMessageLabel = new JLabel(" ");
        statusMessageLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        statusMessageLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Username (Read-Only)
        JLabel userHeader = new JLabel("Account Username");
        userHeader.setFont(new Font("Segoe UI", Font.BOLD, 13));
        userHeader.setForeground(new Color(51, 65, 85));
        userHeader.setAlignmentX(Component.LEFT_ALIGNMENT);

        currentUsernameLabel = new JLabel("oasis_student");
        currentUsernameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        currentUsernameLabel.setForeground(new Color(71, 85, 105));
        currentUsernameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Display Name
        JLabel nameHeader = new JLabel("Full Display Name *");
        nameHeader.setFont(new Font("Segoe UI", Font.BOLD, 13));
        nameHeader.setForeground(new Color(51, 65, 85));
        nameHeader.setAlignmentX(Component.LEFT_ALIGNMENT);

        displayNameField = new JTextField(25);
        displayNameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        displayNameField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        displayNameField.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Password change section
        JLabel pwdHeader = new JLabel("Change Password (Leave blank to keep existing password)");
        pwdHeader.setFont(new Font("Segoe UI", Font.BOLD, 12));
        pwdHeader.setForeground(new Color(100, 116, 139));
        pwdHeader.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel newPwdLabel = new JLabel("New Password");
        newPwdLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        newPwdLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        newPasswordField = new JPasswordField(20);
        newPasswordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        newPasswordField.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel confirmPwdLabel = new JLabel("Confirm New Password");
        confirmPwdLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        confirmPwdLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        confirmPasswordField = new JPasswordField(20);
        confirmPasswordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        confirmPasswordField.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Buttons row
        JPanel buttonRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonRow.setBackground(Color.WHITE);
        buttonRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        buttonRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));

        JButton saveButton = new JButton("Save Profile");
        saveButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        saveButton.setBackground(new Color(241, 245, 249));
        saveButton.setForeground(new Color(15, 23, 42));
        saveButton.setFocusPainted(false);
        saveButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        saveButton.addActionListener(e -> saveProfile());

        JButton proceedButton = new JButton("Proceed to Exam Instructions ->");
        proceedButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        proceedButton.setBackground(new Color(37, 99, 235));
        proceedButton.setForeground(Color.WHITE);
        proceedButton.setFocusPainted(false);
        proceedButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        proceedButton.addActionListener(e -> proceedToInstructions());

        buttonRow.add(saveButton);
        buttonRow.add(proceedButton);

        card.add(titleLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(subtitleLabel);
        card.add(Box.createVerticalStrut(14));
        card.add(statusMessageLabel);
        card.add(Box.createVerticalStrut(12));
        card.add(userHeader);
        card.add(Box.createVerticalStrut(4));
        card.add(currentUsernameLabel);
        card.add(Box.createVerticalStrut(14));
        card.add(nameHeader);
        card.add(Box.createVerticalStrut(6));
        card.add(displayNameField);
        card.add(Box.createVerticalStrut(18));
        card.add(pwdHeader);
        card.add(Box.createVerticalStrut(10));
        card.add(newPwdLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(newPasswordField);
        card.add(Box.createVerticalStrut(10));
        card.add(confirmPwdLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(confirmPasswordField);
        card.add(Box.createVerticalStrut(22));
        card.add(buttonRow);

        add(card);
    }

    public void refreshUserData() {
        User user = parentFrame.getCurrentUser();
        currentUsernameLabel.setText(user.getUsername());
        displayNameField.setText(user.getDisplayName());
        newPasswordField.setText("");
        confirmPasswordField.setText("");
        statusMessageLabel.setText(" ");
    }

    private boolean saveProfile() {
        String newName = displayNameField.getText().trim();
        if (newName.isEmpty()) {
            statusMessageLabel.setForeground(new Color(220, 38, 38));
            statusMessageLabel.setText("Display name cannot be empty.");
            return false;
        }

        String newPassword = new String(newPasswordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());

        if (!newPassword.isEmpty() || !confirmPassword.isEmpty()) {
            if (newPassword.length() < 6) {
                statusMessageLabel.setForeground(new Color(220, 38, 38));
                statusMessageLabel.setText("New password must be at least 6 characters long.");
                return false;
            }
            if (!newPassword.equals(confirmPassword)) {
                statusMessageLabel.setForeground(new Color(220, 38, 38));
                statusMessageLabel.setText("Passwords do not match. Please re-enter.");
                return false;
            }
            parentFrame.getCurrentUser().setPassword(newPassword);
        }

        parentFrame.getCurrentUser().setDisplayName(newName);
        newPasswordField.setText("");
        confirmPasswordField.setText("");
        statusMessageLabel.setForeground(new Color(22, 101, 52));
        statusMessageLabel.setText("Profile updated successfully!");
        return true;
    }

    private void proceedToInstructions() {
        if (saveProfile()) {
            parentFrame.getInstructionsPanel().refreshDetails();
            parentFrame.showScreen(ExamFrame.SCREEN_INSTRUCTIONS);
        }
    }
}
