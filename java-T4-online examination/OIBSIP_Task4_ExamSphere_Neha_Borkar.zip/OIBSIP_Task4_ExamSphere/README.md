# ExamSphere — Online Examination System
**Oasis Infobyte Internship — Java Development Task 4**  
**Developer:** Neha Vinod Borkar  
**GitHub Repository:** `OIBSIP` / `Task4_Online_Examination_System`

---

## 1. Project Title & Objective
**ExamSphere** is a robust, desktop-based Online Examination System built in Java using the Java Swing GUI framework. Designed for second-year computer engineering students and educational evaluation, it simulates an authentic computer-based testing environment.

### Core Objectives:
- Implement secure authentication with in-memory credential validation.
- Enable candidate profile management (display name updates and password changes).
- Orchestrate screen transitions cleanly via Swing `CardLayout` within a single `JFrame`.
- Deliver drift-free countdown timing using monotonic `System.nanoTime()`.
- Ensure answer preservation during two-way question navigation.
- Implement guarded single submission preventing race conditions between manual button clicks and timer events.
- Intercept window close events during active sessions to safeguard examination integrity.
- Compute scores accurately against an independent answer key with comprehensive result breakdowns.

---

## 2. Features
1. **Login Validation**: Rejects empty fields, validates against credentials, displays clear error messages without leaking passwords.
2. **Profile Management**: Displays current details; enables instant display name updating and password changes with confirmation validation.
3. **Exam Instructions**: Summarizes total questions, time allowed, scoring scheme, and rules before candidate initialization.
4. **Monotonic Countdown Timer**: Displays minutes and seconds (`30:00`) updated every 1000ms via `javax.swing.Timer` and calibrated with `System.nanoTime()`.
5. **Question Navigation**: Next, Previous, and Question Palette controls preserve selected radio button answers without resetting.
6. **Automatic Time Expiration Submission**: Automatically finalizes the examination upon reaching `00:00` with zero data loss.
7. **Manual Submission with Confirmation**: Requires student confirmation dialog before submission; warns if unanswered questions remain.
8. **Window-Close Interception**: Intercepts window close requests via `WindowAdapter` to prevent accidental exit or examination abandonment.
9. **Result Analytics**: Generates final score, percentage, correct/incorrect/unanswered counters, time taken, and submission type.
10. **Question-by-Question Review**: Shows question text, candidate's choice, correct answer, status badge, and detailed explanation.
11. **Session-Safe Logout**: Clears answers, active session, and timer state, safely returning to the login screen for another session.

---

## 3. Technology Stack
- **Language:** Java 17+ (SE)
- **GUI Framework:** Java Swing (`JFrame`, `JPanel`, `CardLayout`, `ButtonGroup`, `JRadioButton`, `JOptionPane`)
- **Timing:** `javax.swing.Timer` + `System.nanoTime()`
- **Build Tool:** Apache Maven (`pom.xml`)
- **Threading Model:** Swing Event Dispatch Thread (EDT) via `SwingUtilities.invokeLater()`

---

## 4. Demo Login Credentials
- **Username:** `oasis_student`
- **Password:** `Password@123`
- **Default Display Name:** `Neha Vinod Borkar`

*(Note: Updated passwords saved during the session remain active in memory for subsequent logins.)*

---

## 5. Exam Rules & Marking Scheme
- **Total Questions:** 10 Multiple Choice Questions (Core CS & Java Fundamentals)
- **Duration:** 30 Minutes (1800 seconds)
- **Marks per Correct Answer:** +1.0 Mark
- **Marks for Incorrect Answer:** 0.0 Marks (No negative marking)
- **Marks for Unanswered Question:** 0.0 Marks
- **Total Marks:** 10.0 Marks
- **Passing Threshold:** 60% (6 / 10 Marks)

---

## 6. Project Structure
```
Task4_Online_Examination_System/
├── pom.xml
├── README.md
└── src/
    └── main/
        └── java/
            └── com/
                └── examsphere/
                    ├── Main.java               # Application bootstrap & L&F setup
                    ├── gui/
                    │   ├── ExamFrame.java      # Main JFrame with CardLayout & window listener
                    │   ├── LoginPanel.java     # Authentication form & error feedback
                    │   ├── ProfilePanel.java   # Display name & password updates
                    │   ├── InstructionsPanel.java # Rules & session initializer
                    │   ├── ExamPanel.java      # MCQ view, ButtonGroup, timer, palette
                    │   └── ResultPanel.java    # Score summary, review list & logout
                    └── model/
                        ├── Question.java       # MCQ entity with answer key & explanation
                        ├── ExamSession.java    # Active state, monotonic timer & scoring
                        └── User.java           # User entity & credential validation
```

---

## 7. Explanation of CardLayout, ButtonGroup, and JRadioButton
- **CardLayout**: Unlike opening multiple `JFrame` windows (which causes window clutter and taskbar pollution), `CardLayout` manages multiple panels in a single container. Only one screen (`LOGIN`, `PROFILE`, `INSTRUCTIONS`, `EXAM`, or `RESULT`) is visible at any moment.
- **ButtonGroup & JRadioButton**: Each question has four `JRadioButton` options added to a single `ButtonGroup` instance. This guarantees mutual exclusivity so only one option can be selected per question. When navigating away and returning, the saved index is re-selected on the appropriate radio button.

---

## 8. Explanation of javax.swing.Timer and Elapsed-Time Calculation
Simple timers that merely decrement an integer count (`remainingSeconds--`) drift over time due to operating system scheduling lag and EDT queue contention.  
ExamSphere calculates elapsed time accurately:
```java
long elapsedNanos = System.nanoTime() - startNanoTime;
long elapsedSeconds = elapsedNanos / 1_000_000_000L;
long remainingSeconds = Math.max(0, durationSeconds - elapsedSeconds);
`
This monotonic calculation ensures the countdown remains accurate regardless of system load.

---

## 9. Explanation of Answer Storage and Score Calculation
- Student answers are saved in a `Map<Integer, Integer> recordedAnswers` where the key is the 0-indexed question index and the value is the 0-indexed chosen option (`0=A, 1=B, 2=C, 3=D`).
- Unanswered questions are not stored, ensuring they are distinctly counted as "Unanswered" rather than default zero.
- Scoring is evaluated against `Question.getCorrectAnswerIndex()` on the model layer, never from GUI label strings.

---

## 10. Session Management & Window-Closing Behavior
`ExamFrame` configures:
```java
setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
`
If the user attempts to close the window while an exam is in progress, a confirmation dialog appears:
> *"An examination is currently in progress. Are you sure you want to quit? Your exam will be automatically submitted."*
If confirmed, the exam is submitted through the same guarded `submitExam()` method, preventing lost student work.

---

## 11. Setup & Run Instructions

### Prerequisites:
- Java Development Kit (JDK 17 or higher)
- Apache Maven (3.8+) or standard `javac` compiler

### Method 1: Build & Run with Maven
```bash
# 1. Clone the repository
git clone https://github.com/YourUsername/OIBSIP.git
cd OIBSIP/Task4_Online_Examination_System

# 2. Build the executable JAR
mvn clean package

# 3. Run the application
java -jar target/examsphere-online-exam-1.0.0.jar
```

### Method 2: Compile & Run with standard javac
```bash
# Compile all source files
javac -d bin src/main/java/com/examsphere/*.java src/main/java/com/examsphere/gui/*.java src/main/java/com/examsphere/model/*.java

# Run Main class
java -cp bin com.examsphere.Main
```

---

## 12. Testing Results
All 25 verification checklist points pass:
- [x] Correct credentials open profile screen.
- [x] Empty and incorrect credentials rejected with clear error message.
- [x] Profile display name changes saved and reflected on exam & result screens.
- [x] Password matching validation correctly enforced.
- [x] Single radio button selection guaranteed per MCQ via `ButtonGroup`.
- [x] Previous and Next preserve and restore selected answers seamlessly.
- [x] Question palette reflects Answered vs Unanswered states.
- [x] Monotonic timer remains accurate across question jumps.
- [x] Automatic submission triggers upon reaching 00:00.
- [x] Confirmation prompt protects manual submission.
- [x] Single guarded submission prevents duplicate score calculations.
- [x] Window close interceptor prevents accidental data loss.
- [x] Logout wipes student answers and returns to login screen.

---

## 13. Known Limitations
- Educational Desktop Focus: In-memory user store suitable for demonstration and single-session examination. For institutional deployment, integrate a relational database (PostgreSQL/MySQL) and secure password hashing (BCrypt/Argon2).
- Single-Window Design: Optimized for desktop screens (`960x680` minimum `840x580`).

---

## 14. Demo Video Script & Title Card (Section 19)
For official evaluation, the demo video begins with a 2-second title card:
- **Full Name:** Neha Vinod Borkar
- **Assigned Track:** Java Development
- **Task Title:** Task 4 — Online Examination System

Followed by demonstrations of login, profile name update, exam instructions, answering questions, navigation, manual submit confirmation, score breakdown, and logout.

---

## 15. Developer Information
- **Developer:** Neha Vinod Borkar
- **Internship:** Oasis Infobyte Java Development Internship
- **Task:** Task 4 — Online Examination System
