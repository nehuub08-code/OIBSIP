/**
 * @license
 * Tribute to Dr. A. P. J. Abdul Kalam
 * Vanilla JavaScript (Interactive features & Accessibility)
 * Oasis Infobyte Internship — Level 2, Task 2: Tribute Page
 * Student: Neha Vinod Borkar
 */

document.addEventListener('DOMContentLoaded', () => {
  // --------------------------------------------------------------------------
  // 1. Mobile Navigation & Accessibility
  // --------------------------------------------------------------------------
  const mobileToggle = document.getElementById('mobileNavToggle');
  const navLinks = document.getElementById('primaryNavLinks');

  if (mobileToggle && navLinks) {
    mobileToggle.addEventListener('click', () => {
      const isExpanded = mobileToggle.getAttribute('aria-expanded') === 'true';
      mobileToggle.setAttribute('aria-expanded', String(!isExpanded));
      navLinks.classList.toggle('mobile-open');
    });

    // Close mobile nav when clicking a link
    navLinks.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        if (navLinks.classList.contains('mobile-open')) {
          navLinks.classList.remove('mobile-open');
          mobileToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });

    // Close mobile nav with Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && navLinks.classList.contains('mobile-open')) {
        navLinks.classList.remove('mobile-open');
        mobileToggle.setAttribute('aria-expanded', 'false');
        mobileToggle.focus();
      }
    });
  }

  // --------------------------------------------------------------------------
  // 2. Active Navigation Spy on Scroll
  // --------------------------------------------------------------------------
  const sections = document.querySelectorAll('section[id]');
  const allNavLinks = document.querySelectorAll('.nav-link');

  const updateActiveNavLink = () => {
    const scrollY = window.pageYOffset;

    sections.forEach(current => {
      const sectionHeight = current.offsetHeight;
      const sectionTop = current.offsetTop - 120;
      const sectionId = current.getAttribute('id');

      if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
        allNavLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
          }
        });
      }
    });
  };

  window.addEventListener('scroll', updateActiveNavLink, { passive: true });

  // --------------------------------------------------------------------------
  // 3. Biography Chapter Navigation Sidebar
  // --------------------------------------------------------------------------
  const chapterButtons = document.querySelectorAll('.chapter-nav-btn');
  const chapters = document.querySelectorAll('.bio-chapter');

  chapterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-chapter');
      const targetEl = document.getElementById(targetId);

      if (targetEl) {
        chapterButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // --------------------------------------------------------------------------
  // 4. Achievements Filter
  // --------------------------------------------------------------------------
  const achievementFilterBtns = document.querySelectorAll('.achievements-section .filter-btn');
  const achievementArticles = document.querySelectorAll('.achievement-article');

  achievementFilterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      achievementFilterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filterValue = btn.getAttribute('data-filter');

      achievementArticles.forEach(article => {
        const category = article.getAttribute('data-category');
        if (filterValue === 'all' || category === filterValue) {
          article.style.display = 'flex';
        } else {
          article.style.display = 'none';
        }
      });
    });
  });

  // --------------------------------------------------------------------------
  // 5. Timeline Filter
  // --------------------------------------------------------------------------
  const timelineFilterBtns = document.querySelectorAll('.timeline-filter-btn');
  const timelineEntries = document.querySelectorAll('.timeline-entry');

  timelineFilterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      timelineFilterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.getAttribute('data-era');

      timelineEntries.forEach(entry => {
        const era = entry.getAttribute('data-era');
        if (filter === 'all' || era === filter) {
          entry.style.display = 'block';
        } else {
          entry.style.display = 'none';
        }
      });
    });
  });

  // --------------------------------------------------------------------------
  // 6. Interactive Verified Quotes Explorer
  // --------------------------------------------------------------------------
  const quotesData = [
    {
      quote: "Dream, dream, dream. Dreams transform into thoughts and thoughts result in action.",
      source: "Address to Students, Vigyan Bhavan",
      context: "Documented in 'Wings of Fire' (1999) · The core tenet of Dr. Kalam's educational philosophy."
    },
    {
      quote: "If you want to shine like a sun, first burn like a sun.",
      source: "Address to the Nation, 2004",
      context: "Official speech on perseverance and relentless self-discipline delivered to Indian youth."
    },
    {
      quote: "Learning gives creativity, creativity leads to thinking, thinking provides knowledge, knowledge makes you great.",
      source: "Keynote Address, National Children's Science Congress",
      context: "Dr. Kalam's 4-stage educational paradigm presented to young researchers."
    },
    {
      quote: "Confidence and hard work is the best medicine to kill the disease called failure. It will make you a successful person.",
      source: "Interaction with College Students, Hyderabad",
      context: "Reflecting on the initial 1979 SLV-3 failure and how ISRO recovered to succeed in 1980."
    },
    {
      quote: "Where there is righteousness in the heart, there is beauty in the character. When there is beauty in the character, there is harmony in the home.",
      source: "European Parliament Address, Strasbourg (2007)",
      context: "Ancient hymn recited by Dr. Kalam during his historic presidential address to European leaders."
    },
    {
      quote: "Look at the sky. We are not alone. The whole universe is friendly to us and conspires only to give the best to those who dream and work.",
      source: "Wings of Fire: An Autobiography",
      context: "Chapter reflections on human potential, courage, and scientific ambition."
    }
  ];

  let currentQuoteIndex = 0;
  const quoteBody = document.getElementById('activeQuoteBody');
  const quoteSource = document.getElementById('activeQuoteSource');
  const quoteContext = document.getElementById('activeQuoteContext');
  const quoteIndexLabel = document.getElementById('quoteIndexLabel');
  const prevQuoteBtn = document.getElementById('prevQuoteBtn');
  const nextQuoteBtn = document.getElementById('nextQuoteBtn');

  const renderQuote = (index) => {
    if (!quoteBody) return;
    const item = quotesData[index];
    quoteBody.textContent = `“${item.quote}”`;
    quoteSource.textContent = item.source;
    quoteContext.textContent = item.context;
    if (quoteIndexLabel) {
      quoteIndexLabel.textContent = `${index + 1} of ${quotesData.length}`;
    }
  };

  if (prevQuoteBtn && nextQuoteBtn) {
    prevQuoteBtn.addEventListener('click', () => {
      currentQuoteIndex = (currentQuoteIndex - 1 + quotesData.length) % quotesData.length;
      renderQuote(currentQuoteIndex);
    });

    nextQuoteBtn.addEventListener('click', () => {
      currentQuoteIndex = (currentQuoteIndex + 1) % quotesData.length;
      renderQuote(currentQuoteIndex);
    });
  }

  // --------------------------------------------------------------------------
  // 7. Title Card Modal & Demo Video Helper
  // --------------------------------------------------------------------------
  const openModalBtn = document.getElementById('openTitleCardModal');
  const closeModalBtn = document.getElementById('closeTitleCardModal');
  const modalOverlay = document.getElementById('titleCardModal');
  const modalTimerFill = document.getElementById('modalTimerFill');

  if (openModalBtn && modalOverlay) {
    openModalBtn.addEventListener('click', () => {
      modalOverlay.classList.add('active');
      modalOverlay.setAttribute('aria-hidden', 'false');
      // Trigger animation replay for timer bar
      if (modalTimerFill) {
        modalTimerFill.style.animation = 'none';
        modalTimerFill.offsetHeight; // trigger reflow
        modalTimerFill.style.animation = 'fillTimer 2s linear forwards';
      }
    });

    const closeModal = () => {
      modalOverlay.classList.remove('active');
      modalOverlay.setAttribute('aria-hidden', 'true');
    };

    if (closeModalBtn) {
      closeModalBtn.addEventListener('click', closeModal);
    }

    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) {
        closeModal();
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modalOverlay.classList.contains('active')) {
        closeModal();
      }
    });
  }

  // --------------------------------------------------------------------------
  // 8. Back to Top Smooth Scroll
  // --------------------------------------------------------------------------
  const backToTopBtn = document.getElementById('backToTopBtn');
  if (backToTopBtn) {
    backToTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
});
