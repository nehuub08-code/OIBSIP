# Oasis Infobyte Internship — Web Development & Designing
## Level 2 — Task 2: Tribute Page
### A Curatorial Tribute to Dr. A. P. J. Abdul Kalam (1931–2015)

---

### Project Overview

This project is a curatorial, museum-grade editorial tribute website dedicated to **Dr. Avul Pakir Jainulabdeen Abdul Kalam** (15 October 1931 – 27 July 2015), the 11th President of the Republic of India, pioneer aerospace scientist, and inspiring teacher.

Created for the **Oasis Infobyte Internship in Web Development & Designing** (Task 2 of Level 2), the application avoids generic AI landing page templates, repetitive card clones, and unverified internet quotes. Instead, it adheres to human-crafted editorial typography, balanced color harmonies (deep midnight blue, archival parchment, muted gold, and restrained saffron), and verified historical narratives.

---

### Candidate & Submission Information

- **Intern Name**: Neha Vinod Borkar
- **Assigned Track**: Web Development & Designing
- **Task Title**: Level 2 — Task 2: Tribute Page
- **Internship Organization**: Oasis Infobyte (OIBSIP)
- **Target Repository**: `OIBSIP`
- **Target Directory**: `Level 2 Tribute Page`

---

### Mandatory Demo Video Requirements

As specified in Section 17 & 18 of the task requirements:
The first **two seconds** of the video recording clearly display:
1. **Full Name**: Neha Vinod Borkar
2. **Assigned Track**: Web Development & Designing
3. **Task Title**: Level 2 — Task 2: Tribute Page

To make this seamless during screen recording:
- A dedicated title card file `title-card.html` is included in the project root. Open `title-card.html` in your browser for a distraction-free, 2-second animated title card with clear typography, high contrast, and progress timer.
- Additionally, an **"Internship Card"** modal is integrated directly into the tribute website header for quick preview.

---

### Key Website Sections

1. **Header & Navigation Bar**:
   - Single-element wordmark for Dr. A. P. J. Abdul Kalam.
   - 6 single-line navigation links (Home, Biography, Achievements, Timeline, Books & Ideas, Legacy).
   - "Internship Card" action button and fully accessible mobile hamburger toggle.
2. **Hero Masthead**:
   - Full name, concise historical role description (Aerospace Scientist, 11th President of India, Educator).
   - Museum-grade archival vector portrait with fine rimless glasses and midnight bandhgala coat.
   - Verified quotation from his Vigyan Bhavan address documented in *Wings of Fire*.
   - Operational curatorial ribbon highlighting birthplace, tenure, highest national honor, and title.
3. **Biography Section (Editorial Long-Form)**:
   - Sticky chapter navigation on desktop:
     - *Chapter I: Roots on the Coast of Rameswaram (1931–1954)*
     - *Chapter II: The Aeronautical Calling & Early Research (1955–1969)*
     - *Chapter III: ISRO & The Historic Ascent of SLV-III (1969–1982)*
     - *Chapter IV: Defending the Republic & The IGMDP (1982–1999)*
     - *Chapter V: The People's President at Rashtrapati Bhavan (2002–2007)*
     - *Chapter VI: The Final Lecture: Teacher to the End (2007–2015)*
   - Drop caps, authentic marginalia, and pull quotes bounded by hairline rules.
4. **Achievements & Scientific Contributions**:
   - Filterable categories: All Contributions, Space & Satellite, Strategic Defence, Healthcare Tech, National Vision.
   - Featured full-width technical blueprint showcase for the SLV-3 Rocket and Rohini Satellite (RS-1, 18 July 1980).
   - Balanced historical descriptions acknowledging collaborative national team achievements (IGMDP, Kalam-Raju Stent with Dr. Soma Raju, PURA, Kalam-Raju Health Tablet).
5. **Interactive Life Timeline**:
   - Filterable by era: All Milestones, Early Life & Education, Space & Defence, Presidency, Academic & Later Years.
   - Responsive two-column alternating timeline on desktop and single-rail layout on mobile.
   - Verified milestones from his birth in 1931 to his final lecture at IIM Shillong on 27 July 2015.
6. **Books & Ideas**:
   - Curated showcase of major published works with original thematic analyses:
     - *Wings of Fire* (1999) — Autobiography co-authored with Arun Tiwari.
     - *India 2020* (1998) — Strategic national development roadmap with Y. S. Rajan.
     - *Ignited Minds* (2002) — Manifesto dedicated to empowering young minds.
7. **Legacy & Verified Quotations (The Kalam Doctrine)**:
   - Interactive quote explorer allowing visitors to step through 6 verified historical statements with exact speech context, source, and year.
   - The 4 Pillars of Kalam's philosophy: Scientific Temper, Leadership Through Failure, Uncompromising Simplicity, and Sacred Trust in Youth.
8. **Footer & Acknowledgements**:
   - Respectful tribute statement and complete site directory.
   - Comprehensive source acknowledgements (President of India Archive, ISRO, DRDO).
   - Non-affiliation notice clarifying that this is an educational student project.
   - Accessible "Back to Top" smooth scroll.

---

### Technologies Used

- **HTML5**: Semantic elements (`<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<aside>`, `<figure>`, `<footer>`, `<dialog>`-pattern modal).
- **CSS3**: Native CSS custom properties (tokens), Flexbox, CSS Grid, media queries for responsive layouts, print and `prefers-reduced-motion` accessibility support.
- **Vanilla JavaScript**: Lightweight DOM manipulation for mobile navigation, active section scrollspy, category filtering, interactive quote explorer, and accessible keyboard event handling.
- **Scalable Vector Graphics (SVG)**: Custom-crafted, high-resolution vector illustrations for the archival portrait, rocket blueprint, commemorative emblem, and book covers to guarantee zero broken images and lightning-fast loading.

*Note*: As required by the task brief, no React, Bootstrap, Tailwind, or frontend frameworks are utilized in the website bundle.

---

### Project Structure

```text
Level 2 Tribute Page/
├── index.html               # Main tribute website entry point (Semantic HTML5)
├── style.css                # Museum & editorial stylesheet (Pure CSS3)
├── script.js                # Interactive logic & accessibility handlers (Vanilla JS)
├── title-card.html          # Mandatory 2-second demo video opening card
├── README.md                # Project documentation and review guide
└── assets/                  # Locally stored SVG graphics
    ├── kalam-portrait.svg       # Archival vector portrait of Dr. Kalam
    ├── slv3-mission.svg         # Technical schematic of SLV-3 & Rohini satellite
    ├── presidential-seal.svg    # National commemorative honors seal
    ├── youth-education.svg      # Ignited minds & educational mentorship artwork
    ├── book-wings-of-fire.svg   # Wings of Fire typographic cover reproduction
    ├── book-india-2020.svg      # India 2020 typographic cover reproduction
    └── book-ignited-minds.svg   # Ignited Minds typographic cover reproduction
```

---

### How to Run Locally

Because the project is written in pure vanilla HTML5, CSS3, and JavaScript, it has **zero required build steps or dependencies**:

#### Option A: Direct Browser Launch (Simplest)
1. Clone or download the repository folder.
2. Double-click `index.html` (or right-click and choose *Open with Google Chrome / Firefox / Edge / Safari*).
3. The tribute page runs instantly with complete functionality.

#### Option B: Local Development Server (Optional)
If you prefer running via a local HTTP server:
```bash
# Using Python 3
python3 -m http.server 3000

# Using Node.js npx
npx serve .
```
Then navigate to `http://localhost:3000` in your web browser.

#### Running the Demo Video Title Card:
Open `title-card.html` directly in your browser or click **"Internship Card"** in the navigation header of `index.html`.

---

### Verification & Testing Checklist

- [x] **Semantic HTML5**: Valid hierarchy (`h1` -> `h2` -> `h3`), landmark tags, accessible form/tab roles.
- [x] **No Frameworks**: 100% pure HTML, CSS, and Vanilla JavaScript.
- [x] **Responsive Layout Tested**:
  - Mobile Small: 360px & 390px (iPhone, Samsung Galaxy)
  - Tablet: 768px (iPad portrait)
  - Laptop: 1024px
  - Desktop: 1440px+
- [x] **Zero Broken Images**: All graphics are custom, self-contained SVGs stored locally in `assets/`.
- [x] **Interactive Controls**:
  - Smooth scrolling navigation with header offset.
  - Category filters for Achievements.
  - Chronological filters for Timeline.
  - Interactive carousel for verified historical quotations.
  - Chapter sidebar scrollspy for Biography.
- [x] **Accessibility**:
  - Skip link (`Skip to main editorial content`).
  - WCAG AA contrast ratio compliance on all text surfaces.
  - Clear keyboard focus indicators (`outline: 2px solid #C5A059`).
  - Mobile menu keyboard toggle (`Escape` key close, `aria-expanded`).
  - Respect for `prefers-reduced-motion`.
- [x] **Demo Video Opening**: Title card includes Neha Vinod Borkar, Web Development & Designing, and Level 2 — Task 2: Tribute Page.

---

### Image Credits & Historical Sources

1. **Dr. Kalam's Official Speeches & Texts**:
   - *Wings of Fire: An Autobiography*, Universities Press, 1999 (with Arun Tiwari).
   - *Ignited Minds: Unleashing the Power Within India*, Penguin Viking, 2002.
   - *India 2020: A Vision for the New Millennium*, Penguin India, 1998 (with Y. S. Rajan).
2. **Official Archival Repositories**:
   - President of India Official Portal: [rashtrapatibhavan.gov.in](https://rashtrapatibhavan.gov.in)
   - Indian Space Research Organisation (ISRO): [isro.gov.in](https://www.isro.gov.in)
   - Defence Research & Development Organisation (DRDO): [drdo.gov.in](https://www.drdo.gov.in)
3. **Illustrations & Vector Graphics**:
   - Original museum-grade vector assets created specifically for this student tribute project in SVG format.
