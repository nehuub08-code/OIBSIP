export const EMOJI_MAP: Record<string, string> = {
  ":smile:": "😄",
  ":heart:": "❤️",
  ":thumbsup:": "👍",
  ":laughing:": "😆",
  ":fire:": "🔥",
  ":cry:": "😢",
  ":rocket:": "🚀",
  ":tada:": "🎉",
  ":wink:": "😉",
  ":star:": "⭐",
  ":clap:": "👏",
  ":100:": "💯",
  ":coffee:": "☕",
  ":eyes:": "👀",
  ":check:": "✅",
};

/**
 * Converts emoji shortcodes into Unicode emojis without altering raw text or interpreting HTML.
 */
export function convertEmojiShortcodes(text: string): string {
  let result = text;
  for (const [code, emoji] of Object.entries(EMOJI_MAP)) {
    result = result.replaceAll(code, emoji);
  }
  return result;
}

/**
 * Returns formatted current UTC server time formatted as [HH:MM]
 */
export function getServerTimestamp(): string {
  const now = new Date();
  const hours = String(now.getUTCHours()).padStart(2, "0");
  const minutes = String(now.getUTCMinutes()).padStart(2, "0");
  return `${hours}:${minutes}`;
}
