/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { ChatProvider } from "./context/ChatContext";
import { Navigation, NavTab } from "./components/Navigation";
import { ChatView } from "./components/ChatView";
import { DualWindowTester } from "./components/DualWindowTester";
import { CodeExplorer } from "./components/CodeExplorer";
import { MentorshipGuide } from "./components/MentorshipGuide";
import { TestRunner } from "./components/TestRunner";
import { ExportModal } from "./components/ExportModal";
import { SocketSandbox } from "./components/SocketSandbox";

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>("chat");
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [showSandbox, setShowSandbox] = useState(false);

  return (
    <ChatProvider>
      <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans">
        {/* Top Bar Navigation following Top Bar Contract */}
        <Navigation
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          onOpenExportModal={() => setIsExportModalOpen(true)}
        />

        {/* Main Content Area */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 space-y-4">
          {currentTab === "chat" && (
            <div className="space-y-4">
              {/* Optional collapsible Phase 1 Socket Sandbox Banner */}
              <div className="flex items-center justify-between px-4 py-2.5 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900 shadow-2xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold">Phase 1 & 2 Learning Module:</span>
                  <span className="hidden sm:inline text-blue-700">
                    Want to see how low-level TCP sockets work under the hood?
                  </span>
                </div>
                <button
                  onClick={() => setShowSandbox(!showSandbox)}
                  className="font-semibold text-blue-700 hover:text-blue-900 underline text-xs cursor-pointer"
                >
                  {showSandbox ? "Hide TCP Simulator" : "Explore TCP Sockets"}
                </button>
              </div>

              {showSandbox && <SocketSandbox />}

              {/* Real-Time Live Chat Application */}
              <ChatView />
            </div>
          )}

          {currentTab === "dual" && <DualWindowTester />}

          {currentTab === "code" && (
            <div className="space-y-4">
              <CodeExplorer />
            </div>
          )}

          {currentTab === "guide" && <MentorshipGuide />}

          {currentTab === "tests" && (
            <div className="space-y-4">
              <TestRunner />
            </div>
          )}
        </main>

        {/* Export Project Modal */}
        <ExportModal
          isOpen={isExportModalOpen}
          onClose={() => setIsExportModalOpen(false)}
        />
      </div>
    </ChatProvider>
  );
}
