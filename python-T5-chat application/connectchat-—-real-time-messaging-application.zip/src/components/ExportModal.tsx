import React, { useState } from "react";
import { X, Download, Check, Terminal, FolderCheck, ShieldCheck } from "lucide-react";
import JSZip from "jszip";
import { PROJECT_FILES } from "../data/projectFiles";

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    setIsExporting(true);
    try {
      const zip = new JSZip();
      const folder = zip.folder("OIBSIP_Task5_ConnectChat");

      PROJECT_FILES.forEach((file) => {
        folder?.file(file.path, file.content);
      });

      const blob = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "ConnectChat_OIBSIP_Task5.zip";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Failed to generate zip:", err);
    } finally {
      setIsExporting(false);
    }
  };

  const setupCommands = `cd OIBSIP/PythonProgramming/Task5_Chat_Application/
python -m venv .venv
source .venv/bin/activate  # (Windows: .venv\\Scripts\\activate)
python -m pip install -r requirements.txt
cp .env.example .env
python app.py`;

  const handleCopyCmd = () => {
    navigator.clipboard.writeText(setupCommands);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-xl border border-slate-200 relative animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
            <Download className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Export ConnectChat for OIBSIP Submission
            </h3>
            <p className="text-xs text-slate-500">
              Download the complete Python project package ready for GitHub or internship evaluation.
            </p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Included Files Checklist */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5 text-xs">
            <span className="font-bold text-slate-800 block mb-1">
              What is included in the package:
            </span>
            <div className="grid grid-cols-2 gap-1 text-slate-600 font-mono text-[11px]">
              <span className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600" /> app.py
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600" /> auth.py
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600" /> chat.py
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600" /> database.py
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600" /> templates/ & static/
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600" /> tests/ (17 tests)
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600" /> requirements.txt
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600" /> README.md & .env
              </span>
            </div>
          </div>

          {/* Terminal Setup Commands */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700">Quick Local Run Commands:</span>
              <button
                onClick={handleCopyCmd}
                className="text-blue-600 hover:text-blue-800 font-medium flex items-center gap-1 text-[11px]"
              >
                {copiedCmd ? <Check className="w-3 h-3 text-green-600" /> : null}
                <span>{copiedCmd ? "Copied to clipboard!" : "Copy commands"}</span>
              </button>
            </div>

            <div className="bg-slate-900 text-slate-200 rounded-lg p-3 font-mono text-xs overflow-x-auto border border-slate-800">
              <pre>{setupCommands}</pre>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 justify-end pt-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg"
            >
              Close
            </button>
            <button
              onClick={handleDownloadZip}
              disabled={isExporting}
              className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1.5 shadow-sm transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>{isExporting ? "Packaging ZIP..." : "Download Complete Project (.zip)"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
