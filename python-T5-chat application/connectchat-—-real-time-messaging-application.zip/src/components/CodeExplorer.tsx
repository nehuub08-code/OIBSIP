import React, { useState } from "react";
import { Folder, FileCode, Copy, Check, Download, Info, ChevronRight, FileText } from "lucide-react";
import JSZip from "jszip";
import { PROJECT_FILES, ProjectFile } from "../data/projectFiles";

export const CodeExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<ProjectFile>(PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  // Group files by category
  const categories = Array.from(new Set(PROJECT_FILES.map((f) => f.category)));

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsExporting(true);
    try {
      const zip = new JSZip();
      const folder = zip.folder("OIBSIP_Task5_ConnectChat");

      PROJECT_FILES.forEach((file) => {
        folder?.file(file.path, file.content);
      });

      const blob = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "ConnectChat_OIBSIP_Task5.zip";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Failed to generate zip:", err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner & Export Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-violet-100 text-violet-700">
              <FileCode className="w-5 h-5" />
            </span>
            <h2 className="text-base font-bold text-slate-900">
              Complete Python & Flask Project Explorer
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            Browse all files located at <code className="font-mono bg-slate-100 px-1 py-0.5 rounded text-slate-700">OIBSIP/PythonProgramming/Task5_Chat_Application/</code>.
            Each file includes detailed mentorship notes explaining the architecture line-by-line.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1.5 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? "Copied!" : "Copy File Content"}</span>
          </button>

          <button
            onClick={handleDownloadZip}
            disabled={isExporting}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1.5 shadow-sm transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isExporting ? "Zipping..." : "Download Project .zip"}</span>
          </button>
        </div>
      </div>

      {/* Main Split: File Tree on left, Code & Explanations on right */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 h-[calc(100vh-230px)] min-h-[500px]">
        {/* Left: File Tree */}
        <div className="md:col-span-4 lg:col-span-3 bg-white border border-slate-200 rounded-xl overflow-y-auto p-3 shadow-sm">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2 px-1">
            Project Tree
          </span>

          <div className="space-y-4">
            {categories.map((cat) => (
              <div key={cat} className="space-y-1">
                <span className="text-xs font-semibold text-slate-700 flex items-center gap-1 px-1">
                  <Folder className="w-3.5 h-3.5 text-amber-500" />
                  <span>{cat}</span>
                </span>

                <div className="pl-3 space-y-0.5 border-l border-slate-200 ml-2">
                  {PROJECT_FILES.filter((f) => f.category === cat).map((file) => {
                    const isSelected = selectedFile.path === file.path;
                    return (
                      <button
                        key={file.path}
                        onClick={() => setSelectedFile(file)}
                        className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-xs font-mono transition-colors text-left ${
                          isSelected
                            ? "bg-violet-50 text-violet-800 font-semibold"
                            : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                        }`}
                      >
                        <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSelected ? "text-violet-600" : "text-slate-400"}`} />
                        <span className="truncate">{file.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Code Viewer & Architectural Explanation */}
        <div className="md:col-span-8 lg:col-span-9 flex flex-col bg-slate-900 text-slate-100 rounded-xl overflow-hidden shadow-sm border border-slate-800">
          {/* Header Bar */}
          <div className="px-4 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 font-mono text-xs text-slate-300">
              <span className="text-violet-400 font-semibold">{selectedFile.path}</span>
              <span className="text-slate-600">·</span>
              <span className="text-slate-400">{selectedFile.language.toUpperCase()}</span>
            </div>

            <div className="text-[11px] text-slate-400">
              {selectedFile.content.split("\n").length} lines
            </div>
          </div>

          {/* Educational Explanation Box */}
          <div className="px-4 py-2.5 bg-slate-800/80 border-b border-slate-800 flex items-start gap-2.5 text-xs text-slate-300">
            <Info className="w-4 h-4 text-violet-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-violet-300">Architecture Rationale: </span>
              <span>{selectedFile.explanation}</span>
            </div>
          </div>

          {/* Code Editor Body */}
          <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed text-slate-200 bg-slate-900">
            <pre className="table w-full">
              {selectedFile.content.split("\n").map((line, idx) => (
                <div key={idx} className="table-row hover:bg-slate-800/40">
                  <span className="table-cell select-none text-right pr-4 text-slate-600 text-[11px] tabular-nums w-10">
                    {idx + 1}
                  </span>
                  <span className="table-cell whitespace-pre">{line}</span>
                </div>
              ))}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
