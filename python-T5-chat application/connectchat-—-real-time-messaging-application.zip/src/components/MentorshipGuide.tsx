import React, { useState } from "react";
import { BookOpen, HelpCircle, ShieldAlert, Cpu, Database, Network, ChevronDown, ChevronRight, CheckCircle2, Play } from "lucide-react";

interface QuestionCard {
  id: number;
  title: string;
  category: "Networking" | "Security" | "Backend" | "Internship Demo";
  analogy: string;
  simpleExplanation: string;
  codeSnippet?: string;
  keyTakeaway: string;
}

const QUESTIONS: QuestionCard[] = [
  {
    id: 1,
    title: "1. What is a Client and a Server?",
    category: "Networking",
    analogy: "Think of a restaurant: The Client is the customer placing orders, while the Server is the kitchen that prepares and delivers the meals.",
    simpleExplanation: "In web applications, the 'Client' is the program running on your device (such as your web browser or a mobile phone). It renders the graphical user interface, captures clicks and keyboard presses, and sends requests. The 'Server' is a centralized computer program running in the cloud (or on your computer as 127.0.0.1) that listens for incoming requests, validates permissions, interacts with the SQLite database, and decides what information to send back.",
    keyTakeaway: "Clients request services and display visuals; the Server is the authoritative brain that manages data, enforces security, and controls state."
  },
  {
    id: 2,
    title: "2. How do Sockets Enable Real-Time Communication?",
    category: "Networking",
    analogy: "Traditional HTTP is like sending postcards back and forth: you have to send a letter and wait for a reply every single time. A Socket is like an active phone call: once connected, both parties can talk and listen at the same exact time without hanging up.",
    simpleExplanation: "A 'Socket' is an endpoint of a persistent two-way communication link between two programs over a network. While standard HTTP requests are 'stateless' (the server closes the connection as soon as a web page finishes loading), a WebSocket (or raw TCP socket) keeps the channel open indefinitely. This means the server can instantly 'push' new messages to the client the millisecond they arrive, rather than forcing the browser to constantly refresh or poll.",
    codeSnippet: `# In chat.py: The server actively pushes data without waiting for a request!
@socketio.on('send_message')
def handle_send_message(data):
    emit('receive_message', data, to=data['room'])`,
    keyTakeaway: "Sockets transform the web from request-pull into instant server-push."
  },
  {
    id: 3,
    title: "3. Why does Real-Time Chat need Concurrent Event Handling?",
    category: "Backend",
    analogy: "Imagine a post office with only one teller who takes 10 minutes to help each person. If customer #1 has an issue, everyone else stands waiting in line. Concurrency gives the post office multiple windows so hundreds of people can be helped at once.",
    simpleExplanation: "In a chat app, Alice might be typing, Bob might be reading history, and Charlie might be joining a new room all at the same second. If Python executed code purely sequentially (synchronous single-threaded), the server would freeze while one user was reading the database or waiting for a network packet. Concurrency (achieved via multithreading in our basic socket server or the event-driven async loop in Flask-SocketIO) ensures that no single user blocks anyone else.",
    keyTakeaway: "Concurrency prevents the server from freezing when handling simultaneous user connections."
  },
  {
    id: 4,
    title: "4. How do Flask and Socket.IO Work Together?",
    category: "Backend",
    analogy: "Flask is the receptionist who greets visitors at the door and shows them to their seats (handling HTTP web pages and logins), while Socket.IO is the live intercom system in the auditorium connecting everyone together.",
    simpleExplanation: "Flask is a lightweight Python web framework specialized in serving HTML templates, processing form submissions (POST /login, POST /register), and managing secure session cookies. However, Flask by itself only speaks request-response HTTP. Flask-SocketIO wraps the Flask application, adding WebSocket event listeners like @socketio.on('send_message') that run on the same server without clashing.",
    codeSnippet: `# In app.py:
app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")`,
    keyTakeaway: "Flask manages traditional web pages and sessions; SocketIO manages the live message stream."
  },
  {
    id: 5,
    title: "5. How do Registration and Login Sessions Work?",
    category: "Security",
    analogy: "Registration is signing up for a gym membership and receiving an account card. Login is showing that card at the front desk, where you get a wristband (the session cookie) that lets you use all the equipment without proving your identity at every machine.",
    simpleExplanation: "During registration, the user submits a username and password. The server checks that the username is not already taken, hashes the password, and writes a row into the 'users' table in SQLite. When logging in, the server looks up the user, verifies the password hash, and stores 'user_id' in Flask's session object. Flask signs this session with a secret key (SECRET_KEY) and stores it in an HTTP cookie in the user's browser.",
    keyTakeaway: "Sessions prevent users from having to send their password with every single chat message."
  },
  {
    id: 6,
    title: "6. Why are Passwords Hashed (and never stored in Plaintext)?",
    category: "Security",
    analogy: "A hash is like a meat grinder: you can turn a steak into ground beef easily (one-way), but no one can reconstruct the original steak from the ground beef. When you type your password, the server grinds it and checks if the meat matches what is stored on file.",
    simpleExplanation: "If an attacker or rogue administrator steals your SQLite database file and passwords were saved in plaintext, every user account would immediately be compromised. With cryptographic hashing (like Werkzeug's PBKDF2-SHA256), a mathematical one-way function converts the password into an unrecognizable 64+ character string plus a random 'salt'. When a user logs in, their entered password is run through the exact same algorithm: if the resulting hash matches the database, the password is correct!",
    codeSnippet: `# In auth.py:
from werkzeug.security import generate_password_hash, check_password_hash
# Registration:
pw_hash = generate_password_hash("MySecret123")  # 'pbkdf2:sha256:600000$...'
# Login verification:
is_valid = check_password_hash(pw_hash, "MySecret123")  # Returns True`,
    keyTakeaway: "Storing plaintext passwords is the #1 database sin. Hashing ensures passwords cannot be read even if the database is leaked."
  },
  {
    id: 7,
    title: "7. How does SQLite Store Messages and Prevent SQL Injection?",
    category: "Backend",
    analogy: "SQL injection is like someone putting a fake name on a package: 'Deliver to Alice, then burn down the post office'. If the mailman blindly follows whatever is written, disaster strikes. Parameterized queries put the name in a sealed plastic bag so it is treated strictly as letters, never as a command.",
    simpleExplanation: "SQLite stores data in structured tables on your disk. To prevent SQL Injection (where an attacker types `'; DROP TABLE users; --`), we NEVER concatenate strings into SQL queries. We use parameterized queries with '?' placeholders: cursor.execute('INSERT INTO messages (room_id, user_id, message_text) VALUES (?, ?, ?)', (room_id, user_id, text)). SQLite treats the '?' values strictly as pure data.",
    keyTakeaway: "Parameterized queries with '?' placeholders guarantee user inputs can never execute as SQL commands."
  },
  {
    id: 8,
    title: "8. How do Rooms Isolate Conversations?",
    category: "Networking",
    analogy: "Think of a school with multiple classrooms. Each room has closed doors. When someone speaks in the 'Math' room, only the students in the Math room hear the lecture; students in the 'History' room hear nothing.",
    simpleExplanation: "In Flask-SocketIO, a 'room' is a server-side broadcasting namespace. When a user switches to a room, the server executes `join_room(room_name)`. When someone sends a message to that room, the server issues `emit('receive_message', data, to=room_name)`. Socket.IO inspects which client sockets have joined that specific room tag and sends network packets ONLY to those sockets.",
    keyTakeaway: "Rooms prevent network traffic and sensitive discussions from leaking to unintended recipients."
  },
  {
    id: 9,
    title: "9. How is Message History Retrieved and Kept Chronological?",
    category: "Backend",
    analogy: "Reading a book from Chapter 1 to Chapter 10: you want to read older events first so the conversation makes sense.",
    simpleExplanation: "When a user joins a room, the server retrieves recent messages using an SQL subquery: it selects the top 50 messages ordered by ID descending (to get the newest 50), and then inverts the order to ascending so the oldest message appears at the top and the newest at the bottom.",
    codeSnippet: `-- In database.py:
SELECT m.*, u.username as sender FROM (
    SELECT * FROM messages WHERE room_id = ? ORDER BY id DESC LIMIT 50
) m JOIN users u ON m.user_id = u.id ORDER BY m.id ASC;`,
    keyTakeaway: "Chronological history gives new joiners full context of ongoing discussions."
  },
  {
    id: 10,
    title: "10. How do Server Timestamps and Disconnects Work?",
    category: "Networking",
    analogy: "A court reporter stamps every piece of evidence with the official courtroom clock, rather than asking the defendant what time their personal watch showed.",
    simpleExplanation: "Clients might have incorrect clock times or be located in different time zones across the world. To maintain a single source of truth, ConnectChat generates timestamps strictly on the server using UTC time (`datetime.now(timezone.utc)`). When a client abruptly closes their browser tab, the underlying TCP connection breaks. The server detects the TCP FIN packet, triggers the `@socketio.on('disconnect')` event handler, and broadcasts a clean system alert to other room members.",
    keyTakeaway: "Never trust client timestamps; the server is the authoritative clock."
  },
  {
    id: 11,
    title: "11. How are Emoji Shortcodes Converted Safely?",
    category: "Backend",
    analogy: "A search-and-replace dictionary in a text editor: replacing every occurrence of 'lol' with 'laugh out loud'.",
    simpleExplanation: "The application maintains a mapping table EMOJI_MAP containing codes like ':fire:' mapped to '🔥'. When a message arrives, Python's string replacement swaps every recognized code with its corresponding Unicode character. If a code is not in the dictionary (e.g. ':unknown_code:'), it is left completely untouched. Critically, message text is never parsed as HTML, ensuring that `<script>` tags cannot be hidden inside emojis.",
    keyTakeaway: "Emoji conversion is a clean string transformation that preserves text safety."
  },
  {
    id: 12,
    title: "12. Why is this Application NOT End-to-End Encrypted?",
    category: "Security",
    analogy: "In an End-to-End Encrypted (E2EE) system, Alice puts her letter in a titanium lockbox that only Bob has the key to. The postal worker (the server) carries the box but has no way to open it. In ConnectChat, Alice sends an open postcard to the server, and the server reads it, saves a copy in its notebook (SQLite), and passes it to Bob.",
    simpleExplanation: "End-to-End Encryption requires asymmetric public/private key cryptography (such as the Signal Protocol or Double Ratchet algorithm) where client devices generate private keys that NEVER leave the phone or browser. In ConnectChat, the server can read, inspect, and store the full message text in SQLite. Furthermore, in basic local development, messages travel over unencrypted HTTP. Claiming a basic chat app is 'end-to-end encrypted' is deceptive and false.",
    keyTakeaway: "Always be transparent: ConnectChat is an authenticated client-server messaging app, NOT an end-to-end encrypted cipher system."
  },
  {
    id: 13,
    title: "13. How to Demonstrate the Project for Internship Evaluation",
    category: "Internship Demo",
    analogy: "A pilot's pre-flight checklist: 5 clear steps that guarantee a smooth flight in front of your evaluator.",
    simpleExplanation: "Follow this exact checklist when presenting your project: 1) Explain the Phase 1 TCP socket foundation and Phase 2 Flask-SocketIO transition. 2) Show the registration form and explain password hashing. 3) Open two browser windows side by side (Alice and Bob) and send messages in real-time. 4) Switch Bob to another room and demonstrate room isolation and the unread notification badge. 5) Run the 17 automated tests to demonstrate code reliability.",
    keyTakeaway: "Follow the 3-minute demonstration script in the README for a flawless internship evaluation."
  }
];

export const MentorshipGuide: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [expandedId, setExpandedId] = useState<number | null>(1);

  const categories = ["All", "Networking", "Security", "Backend", "Internship Demo"];

  const filteredQuestions = selectedCategory === "All"
    ? QUESTIONS
    : QUESTIONS.filter((q) => q.category === selectedCategory);

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Mentor Hero Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white p-6 rounded-2xl shadow-md border border-indigo-950">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-blue-300 uppercase tracking-wider">
              OIBSIP Engineering Mentor
            </span>
            <h1 className="text-xl md:text-2xl font-bold tracking-tight">
              Beginner-Friendly Concept Explanations
            </h1>
            <p className="text-xs text-blue-100 max-w-2xl leading-relaxed">
              Curated specifically for 2nd-year Computer Engineering students. Understand how every piece of
              ConnectChat works with real-world analogies, code walkthroughs, and clear answers to evaluation questions.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-xs border border-white/15 px-4 py-3 rounded-xl text-center shrink-0">
            <span className="text-xs text-blue-200 block">Internship Track</span>
            <span className="text-base font-bold text-white block">Task 5 — Chat App</span>
            <span className="text-[11px] text-emerald-300 font-medium">13 Core Concepts</span>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
              selectedCategory === cat
                ? "bg-slate-900 text-white shadow-xs"
                : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-50"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Accordion List of Questions */}
      <div className="space-y-3">
        {filteredQuestions.map((q) => {
          const isOpen = expandedId === q.id;

          return (
            <div
              key={q.id}
              className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs transition-all"
            >
              <button
                onClick={() => setExpandedId(isOpen ? null : q.id)}
                className="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50/80 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                    q.category === "Security" ? "bg-red-50 text-red-700" :
                    q.category === "Networking" ? "bg-blue-50 text-blue-700" :
                    q.category === "Backend" ? "bg-violet-50 text-violet-700" : "bg-emerald-50 text-emerald-700"
                  }`}>
                    {q.id}
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 truncate">
                    {q.title}
                  </h3>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-[11px] font-medium text-slate-400 hidden sm:inline">
                    {q.category}
                  </span>
                  {isOpen ? (
                    <ChevronDown className="w-4 h-4 text-slate-500" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-slate-500" />
                  )}
                </div>
              </button>

              {isOpen && (
                <div className="px-5 pb-5 pt-1 space-y-4 border-t border-slate-100 text-xs sm:text-sm">
                  {/* Real Life Analogy Box */}
                  <div className="p-3.5 rounded-lg bg-amber-50/70 border border-amber-200 text-amber-950">
                    <span className="font-bold text-xs text-amber-800 uppercase tracking-wider block mb-1">
                      💡 Real-Life Analogy
                    </span>
                    <p className="leading-relaxed">{q.analogy}</p>
                  </div>

                  {/* Simple Explanation */}
                  <div className="space-y-1">
                    <span className="font-bold text-xs text-slate-800 uppercase tracking-wider block">
                      Engineering Explanation
                    </span>
                    <p className="text-slate-700 leading-relaxed text-xs sm:text-sm">
                      {q.simpleExplanation}
                    </p>
                  </div>

                  {/* Code snippet if present */}
                  {q.codeSnippet && (
                    <div className="bg-slate-900 text-slate-200 rounded-lg p-3 font-mono text-xs overflow-x-auto border border-slate-800">
                      <pre>{q.codeSnippet}</pre>
                    </div>
                  )}

                  {/* Key Takeaway */}
                  <div className="flex items-start gap-2 text-xs bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-slate-700 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0 mt-0.5" />
                    <span><strong>Key takeaway for evaluator:</strong> {q.keyTakeaway}</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
