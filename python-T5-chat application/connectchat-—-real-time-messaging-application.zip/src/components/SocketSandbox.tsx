import React, { useState } from "react";
import { Terminal, Network, ArrowRight, Play, CheckCircle2, RotateCcw } from "lucide-react";

export const SocketSandbox: React.FC = () => {
  const [step, setStep] = useState<number>(0);

  const steps = [
    {
      title: "Step 1: Socket Creation (socket.socket)",
      code: "server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)",
      desc: "Allocates a network endpoint in the operating system. AF_INET indicates IPv4 addressing; SOCK_STREAM specifies reliable, connection-oriented TCP (Transmission Control Protocol).",
      status: "Socket File Descriptor created (unbound).",
    },
    {
      title: "Step 2: Port Binding (bind)",
      code: 'server.bind(("127.0.0.1", 9000))',
      desc: "Assigns the socket to a local network interface IP (127.0.0.1 loopback) and Port number 9000 so the OS knows which application should receive traffic directed to port 9000.",
      status: "Socket assigned to 127.0.0.1:9000.",
    },
    {
      title: "Step 3: Passive Listening (listen)",
      code: "server.listen(5)",
      desc: "Puts the socket into passive mode waiting for incoming client connection requests. The backlog argument (5) defines the queue length of pending connections.",
      status: "Server listening... Ready for incoming TCP SYN packets.",
    },
    {
      title: "Step 4: TCP 3-Way Handshake & Accept (accept)",
      code: "client_sock, client_addr = server.accept()",
      desc: "The OS completes the 3-Way Handshake (SYN → SYN-ACK → ACK). The accept() call blocks until a client connects, then returns a dedicated new socket for that specific client.",
      status: "Handshake completed with client (127.0.0.1:54320).",
    },
    {
      title: "Step 5: Multithreaded Worker Spawn",
      code: "threading.Thread(target=handle_client, args=(client_sock,)).start()",
      desc: "To prevent blocking other incoming connections, Python spawns a concurrent background thread. This thread manages the recv() and sendall() buffer loop for this user.",
      status: "Worker thread active. Real-time message exchange initiated.",
    },
  ];

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="p-1.5 rounded-lg bg-blue-100 text-blue-700">
            <Network className="w-4 h-4" />
          </span>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Phase 1 & 2: Low-Level TCP Socket Lifecycle Simulator
            </h3>
            <p className="text-xs text-slate-500">
              Step through the exact operating system calls used in <code className="font-mono bg-slate-100 px-1 py-0.5 rounded text-slate-700">networking/socket_server_basic.py</code>.
            </p>
          </div>
        </div>

        <button
          onClick={() => setStep((prev) => (prev < steps.length - 1 ? prev + 1 : 0))}
          className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1.5 shadow-sm transition-colors"
        >
          {step === steps.length - 1 ? (
            <>
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Simulator</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5" />
              <span>Next Step ({step + 1}/{steps.length})</span>
            </>
          )}
        </button>
      </div>

      {/* Visual Step Timeline */}
      <div className="grid grid-cols-5 gap-2">
        {steps.map((s, idx) => (
          <div
            key={idx}
            className={`p-2 rounded-lg border text-xs transition-all ${
              idx === step
                ? "bg-blue-50 border-blue-500 font-semibold text-blue-900 ring-2 ring-blue-500/20"
                : idx < step
                ? "bg-slate-50 border-slate-200 text-slate-700"
                : "bg-slate-50/50 border-slate-100 text-slate-400 opacity-60"
            }`}
          >
            <div className="flex items-center gap-1 text-[11px] mb-1">
              {idx < step ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              ) : (
                <span className="w-4 h-4 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center text-[10px] font-bold">
                  {idx + 1}
                </span>
              )}
              <span className="truncate">Step {idx + 1}</span>
            </div>
            <span className="text-[10px] block truncate">{s.title.split(":")[1] || s.title}</span>
          </div>
        ))}
      </div>

      {/* Active Step Details */}
      <div className="bg-slate-900 text-slate-200 rounded-xl p-4 font-mono text-xs border border-slate-800 space-y-3">
        <div className="flex items-center justify-between text-slate-400 text-[11px] border-b border-slate-800 pb-2">
          <span>{steps[step].title}</span>
          <span className="text-emerald-400">STATUS: {steps[step].status}</span>
        </div>

        <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-blue-400">
          <pre>{steps[step].code}</pre>
        </div>

        <p className="text-slate-300 font-sans text-xs leading-relaxed">
          {steps[step].desc}
        </p>
      </div>
    </div>
  );
};
