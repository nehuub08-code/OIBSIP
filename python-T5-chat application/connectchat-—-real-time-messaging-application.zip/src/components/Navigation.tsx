import React from "react";
import { MessageSquare, SplitSquareVertical, Code2, BookOpen, CheckCircle2, Download, UserCheck } from "lucide-react";
import { useChat } from "../context/ChatContext";

export type NavTab = "chat" | "dual" | "code" | "guide" | "tests";

interface NavigationProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenExportModal: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  currentTab,
  onSelectTab,
  onOpenExportModal,
}) => {
  const { currentUser, setCurrentUser, users } = useChat();

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text wordmark with icon */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onSelectTab("chat")}
              className="flex items-center gap-2.5 text-left focus:outline-none"
            >
              <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-sm font-bold text-lg">
                ⚡
              </div>
              <div>
                <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap block leading-tight">
                  ConnectChat
                </span>
                <span className="text-[11px] font-medium text-slate-500 whitespace-nowrap block">
                  OIBSIP Task 5
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: 5 single-line clean navigation links */}
          <nav className="hidden md:flex items-center gap-1 text-sm font-medium">
            <button
              onClick={() => onSelectTab("chat")}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === "chat"
                  ? "bg-slate-100 text-slate-900 font-semibold"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
              }`}
            >
              <MessageSquare className="w-4 h-4 text-blue-600" />
              <span>Live Chat</span>
            </button>

            <button
              onClick={() => onSelectTab("dual")}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === "dual"
                  ? "bg-slate-100 text-slate-900 font-semibold"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
              }`}
            >
              <SplitSquareVertical className="w-4 h-4 text-emerald-600" />
              <span>Dual Window</span>
            </button>

            <button
              onClick={() => onSelectTab("code")}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === "code"
                  ? "bg-slate-100 text-slate-900 font-semibold"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
              }`}
            >
              <Code2 className="w-4 h-4 text-violet-600" />
              <span>Codebase</span>
            </button>

            <button
              onClick={() => onSelectTab("guide")}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === "guide"
                  ? "bg-slate-100 text-slate-900 font-semibold"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
              }`}
            >
              <BookOpen className="w-4 h-4 text-amber-600" />
              <span>Student Guide</span>
            </button>

            <button
              onClick={() => onSelectTab("tests")}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === "tests"
                  ? "bg-slate-100 text-slate-900 font-semibold"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
              }`}
            >
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              <span>Test Suite (17)</span>
            </button>
          </nav>

          {/* Zone 3: 1 primary action + Active user switcher */}
          <div className="flex items-center gap-3 shrink-0">
            {/* User switcher */}
            <div className="hidden sm:flex items-center gap-2 pl-3 border-l border-slate-200">
              <span className="text-xs text-slate-500 whitespace-nowrap">User:</span>
              <select
                value={currentUser.id}
                onChange={(e) => {
                  const selected = users.find((u) => u.id === Number(e.target.value));
                  if (selected) setCurrentUser(selected);
                }}
                className="text-xs font-medium text-slate-800 bg-slate-100 border border-slate-200 rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
              >
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.username} ({u.role || "User"})
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={onOpenExportModal}
              className="px-3.5 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Code (.zip)</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
