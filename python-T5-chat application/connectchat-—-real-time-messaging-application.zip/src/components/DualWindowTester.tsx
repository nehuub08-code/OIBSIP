import React from "react";
import { Users, Sparkles, CheckCircle2, SplitSquareVertical, ArrowRightLeft } from "lucide-react";
import { useChat } from "../context/ChatContext";
import { ChatView } from "./ChatView";

export const DualWindowTester: React.FC = () => {
  const {
    users,
    currentUser,
    setCurrentUser,
    window2User,
    setWindow2User,
    activeRoom,
    setActiveRoom,
    window2Room,
    setWindow2Room,
    sendMessage,
    createRoom,
  } = useChat();

  const handleSimulateExchange = () => {
    // Window 1 (Alice) sends a message
    sendMessage("Hey Bob! Testing bidirectional messaging :rocket: :fire:", activeRoom, currentUser);

    setTimeout(() => {
      // Window 2 (Bob) replies in the same room
      sendMessage("Hi Alice! Message received in real-time with zero lag :thumbsup: :tada:", activeRoom, window2User);
    }, 600);
  };

  const handleTestIsolation = () => {
    // Set Window 1 to #general and Window 2 to #python-dev
    setActiveRoom("general");
    setWindow2Room("python-dev");

    setTimeout(() => {
      sendMessage("Secret message in #general! Bob should NOT see this in #python-dev :eyes:", "general", currentUser);
    }, 400);
  };

  return (
    <div className="space-y-4">
      {/* Top Test Bench Controls */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-700">
              <SplitSquareVertical className="w-5 h-5" />
            </span>
            <h2 className="text-base font-bold text-slate-900">
              Interactive Dual-Window Evaluation Rig
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            Simulates two separate authenticated browser sessions side-by-side. Test multi-user real-time
            delivery, room isolation, and background unread badges directly on one screen.
          </p>
        </div>

        {/* Quick Scenario Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleSimulateExchange}
            className="px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Simulate 2-Way Exchange</span>
          </button>

          <button
            onClick={handleTestIsolation}
            className="px-3 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg flex items-center gap-1.5 transition-colors"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Verify Room Isolation</span>
          </button>
        </div>
      </div>

      {/* Side-by-side Dual Chat Windows */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Window 1 */}
        <div className="space-y-2">
          <div className="flex items-center justify-between px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-lg text-xs font-semibold text-blue-900">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-600"></span>
              <span>Window 1: Client Session A</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-normal">Active User:</span>
              <select
                value={currentUser.id}
                onChange={(e) => {
                  const u = users.find((x) => x.id === Number(e.target.value));
                  if (u) setCurrentUser(u);
                }}
                className="bg-white border border-blue-200 rounded px-2 py-0.5 font-medium text-slate-800 focus:outline-none"
              >
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.username}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <ChatView
            customUser={currentUser}
            customActiveRoom={activeRoom}
            onRoomChange={setActiveRoom}
            isCompact={true}
          />
        </div>

        {/* Window 2 */}
        <div className="space-y-2">
          <div className="flex items-center justify-between px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-lg text-xs font-semibold text-emerald-900">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
              <span>Window 2: Client Session B</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-normal">Active User:</span>
              <select
                value={window2User.id}
                onChange={(e) => {
                  const u = users.find((x) => x.id === Number(e.target.value));
                  if (u) setWindow2User(u);
                }}
                className="bg-white border border-emerald-200 rounded px-2 py-0.5 font-medium text-slate-800 focus:outline-none"
              >
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.username}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <ChatView
            customUser={window2User}
            customActiveRoom={window2Room}
            onRoomChange={setWindow2Room}
            isCompact={true}
          />
        </div>
      </div>
    </div>
  );
};
