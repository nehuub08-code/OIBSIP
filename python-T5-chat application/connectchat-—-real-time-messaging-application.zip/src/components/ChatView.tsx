import React, { useState, useRef, useEffect } from "react";
import { Hash, Plus, Send, ShieldAlert, Wifi, WifiOff, X, Sparkles, Smile, ArrowRight } from "lucide-react";
import { useChat } from "../context/ChatContext";
import { EMOJI_MAP } from "../utils/emoji";

interface ChatViewProps {
  customUser?: any;
  customActiveRoom?: string;
  onRoomChange?: (room: string) => void;
  isCompact?: boolean;
}

export const ChatView: React.FC<ChatViewProps> = ({
  customUser,
  customActiveRoom,
  onRoomChange,
  isCompact = false,
}) => {
  const {
    currentUser: contextUser,
    rooms,
    messages,
    activeRoom: contextActiveRoom,
    setActiveRoom: contextSetActiveRoom,
    unreadCounts,
    latestNotification,
    clearNotification,
    sendMessage,
    createRoom,
    connectionStatus,
    simulateDisconnect,
  } = useChat();

  const user = customUser || contextUser;
  const activeRoom = customActiveRoom || contextActiveRoom;
  const setActiveRoom = onRoomChange || contextSetActiveRoom;

  const [inputMessage, setInputMessage] = useState("");
  const [showCreateRoom, setShowCreateRoom] = useState(false);
  const [newRoomName, setNewRoomName] = useState("");
  const [roomError, setRoomError] = useState("");

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Filter messages for active room
  const roomMessages = messages.filter(
    (m) => m.roomName.toLowerCase() === activeRoom.toLowerCase()
  );

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [roomMessages.length, activeRoom]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    sendMessage(inputMessage, activeRoom, user);
    setInputMessage("");
  };

  const handleCreateRoomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRoomError("");
    const res = createRoom(newRoomName, user.id);
    if (res.success) {
      setActiveRoom(newRoomName.trim().toLowerCase());
      setNewRoomName("");
      setShowCreateRoom(false);
    } else {
      setRoomError(res.error || "Failed to create room.");
    }
  };

  const handleAddEmoji = (code: string) => {
    setInputMessage((prev) => (prev ? `${prev} ${code} ` : `${code} `));
  };

  const handleTestXSSPayload = () => {
    setInputMessage("<script>alert('Security Verified: Safe textContent Rendering!')</script>");
  };

  return (
    <div className={`flex bg-slate-50 border border-slate-200 rounded-xl overflow-hidden shadow-sm ${isCompact ? "h-[540px]" : "h-[calc(100vh-120px)]"}`}>
      {/* Sidebar: Rooms List */}
      <aside className={`${isCompact ? "w-52" : "w-64"} bg-white border-r border-slate-200 flex flex-col shrink-0`}>
        {/* Sidebar Header */}
        <div className="p-3.5 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">Rooms</span>
            <span className="text-[11px] font-mono bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
              {rooms.length}
            </span>
          </div>
          <button
            onClick={() => setShowCreateRoom(!showCreateRoom)}
            className="text-xs font-medium text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 px-2 py-1 rounded flex items-center gap-1 transition-colors"
            title="Create New Room"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New</span>
          </button>
        </div>

        {/* Inline Create Room Form */}
        {showCreateRoom && (
          <div className="p-3 bg-slate-50 border-b border-slate-200">
            <form onSubmit={handleCreateRoomSubmit} className="space-y-2">
              <input
                type="text"
                placeholder="room-name"
                value={newRoomName}
                onChange={(e) => setNewRoomName(e.target.value)}
                maxLength={30}
                className="w-full text-xs px-2.5 py-1.5 bg-white border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                autoFocus
              />
              {roomError && <p className="text-[11px] text-red-600">{roomError}</p>}
              <div className="flex gap-1.5 justify-end">
                <button
                  type="button"
                  onClick={() => {
                    setShowCreateRoom(false);
                    setRoomError("");
                  }}
                  className="text-[11px] text-slate-600 hover:text-slate-800 px-2 py-1"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="text-[11px] font-medium text-white bg-blue-600 hover:bg-blue-700 px-2.5 py-1 rounded"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Rooms Navigation List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {rooms.map((room) => {
            const isActive = room.name.toLowerCase() === activeRoom.toLowerCase();
            const unread = unreadCounts[room.name] || 0;

            return (
              <button
                key={room.id}
                onClick={() => setActiveRoom(room.name)}
                className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs font-medium transition-colors text-left group ${
                  isActive
                    ? "bg-blue-50 text-blue-700 font-semibold"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                }`}
              >
                <div className="flex items-center gap-1.5 min-w-0">
                  <Hash className={`w-3.5 h-3.5 shrink-0 ${isActive ? "text-blue-600" : "text-slate-400"}`} />
                  <span className="truncate">{room.name}</span>
                </div>
                {unread > 0 && !isActive && (
                  <span className="bg-blue-600 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full tabular-nums">
                    {unread}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* User Badge & Connection Telemetry */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 min-w-0">
            {user.avatar ? (
              <img
                src={user.avatar}
                alt={user.username}
                referrerPolicy="no-referrer"
                className="w-7 h-7 rounded-full object-cover border border-slate-300 shrink-0"
              />
            ) : (
              <div className="w-7 h-7 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                {user.username.charAt(0).toUpperCase()}
              </div>
            )}
            <div className="min-w-0">
              <span className="font-semibold text-slate-800 block truncate">{user.username}</span>
              <span className="text-[10px] text-slate-500 block truncate">{user.role || "Online"}</span>
            </div>
          </div>

          <button
            onClick={() => simulateDisconnect(connectionStatus === "connected")}
            className="text-[11px] text-slate-500 hover:text-slate-800 p-1 rounded"
            title={connectionStatus === "connected" ? "Simulate Network Drop" : "Reconnect Network"}
          >
            {connectionStatus === "connected" ? (
              <div className="flex items-center gap-1 text-emerald-600">
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>
                <span className="text-[10px] font-medium hidden sm:inline">Online</span>
              </div>
            ) : (
              <div className="flex items-center gap-1 text-red-600">
                <span className="w-2 h-2 rounded-full bg-red-500 inline-block"></span>
                <span className="text-[10px] font-medium">Offline</span>
              </div>
            )}
          </button>
        </div>
      </aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col bg-white min-w-0">
        {/* Room Header */}
        <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between bg-white shrink-0">
          <div className="flex items-center gap-2">
            <Hash className="w-5 h-5 text-slate-400" />
            <div>
              <h2 className="text-sm font-bold text-slate-900 leading-tight">
                {activeRoom}
              </h2>
              <p className="text-[11px] text-slate-500">
                Public Room · SQLite Persisted · UTC Time
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleTestXSSPayload}
              className="text-[11px] font-medium text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 px-2 py-1 rounded flex items-center gap-1 transition-colors"
              title="Inject malicious script to verify DOM textContent XSS immunity"
            >
              <ShieldAlert className="w-3 h-3 text-amber-600" />
              <span>Test XSS Payload</span>
            </button>
          </div>
        </div>

        {/* In-App Notification Banner */}
        {latestNotification && latestNotification.room !== activeRoom && (
          <div className="bg-blue-50 border-b border-blue-200 px-4 py-2 flex items-center justify-between text-xs text-blue-900">
            <div className="flex items-center gap-2 truncate">
              <span className="font-semibold text-blue-700">#{latestNotification.room}:</span>
              <span className="truncate">
                {latestNotification.sender}: {latestNotification.text}
              </span>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={() => setActiveRoom(latestNotification.room)}
                className="font-semibold underline hover:text-blue-950 flex items-center gap-1 text-xs"
              >
                <span>Switch to room</span>
                <ArrowRight className="w-3 h-3" />
              </button>
              <button onClick={clearNotification} className="text-blue-500 hover:text-blue-800">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Message Feed Container */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/50">
          {roomMessages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mb-2">
                <Hash className="w-6 h-6" />
              </div>
              <p className="text-sm font-medium text-slate-600">No messages in #{activeRoom} yet</p>
              <p className="text-xs text-slate-400 max-w-sm mt-1">
                Be the first to start the real-time conversation or test emoji shortcodes like :fire: and :rocket:.
              </p>
            </div>
          ) : (
            roomMessages.map((msg) => {
              const isSent = msg.sender === user.username;

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col max-w-[80%] ${
                    isSent ? "ml-auto items-end" : "mr-auto items-start"
                  }`}
                >
                  {/* Sender & Timestamp Header */}
                  <div className="flex items-baseline gap-2 mb-1 px-1 text-[11px]">
                    <span className="font-semibold text-slate-700">
                      {isSent ? "You" : msg.sender}
                    </span>
                    <span className="font-mono text-slate-400 tabular-nums text-[10px]">
                      [{msg.timestamp}]
                    </span>
                  </div>

                  {/* Message Bubble - STRICT textContent rendering for XSS immunity */}
                  <div
                    className={`px-3.5 py-2 rounded-2xl text-xs sm:text-sm leading-relaxed break-words whitespace-pre-wrap shadow-xs ${
                      isSent
                        ? "bg-blue-600 text-white rounded-tr-xs"
                        : "bg-white text-slate-800 border border-slate-200 rounded-tl-xs"
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Emoji Quick Bar */}
        <div className="px-4 py-1.5 bg-white border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto text-xs">
          <span className="text-[11px] font-medium text-slate-400 whitespace-nowrap flex items-center gap-1">
            <Smile className="w-3.5 h-3.5 text-slate-400" />
            <span>Shortcodes:</span>
          </span>
          <div className="flex gap-1">
            {Object.entries(EMOJI_MAP).slice(0, 8).map(([code, emoji]) => (
              <button
                key={code}
                type="button"
                onClick={() => handleAddEmoji(code)}
                className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-mono whitespace-nowrap transition-colors"
                title={`Click to insert ${code}`}
              >
                {emoji} {code}
              </button>
            ))}
          </div>
        </div>

        {/* Message Input Footer */}
        <footer className="p-3 bg-white border-t border-slate-200">
          <form onSubmit={handleSend} className="flex gap-2 items-center">
            <div className="relative flex-1">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder={`Message #${activeRoom}...`}
                maxLength={2000}
                disabled={connectionStatus !== "connected"}
                className="w-full text-xs sm:text-sm pl-3 pr-16 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 disabled:bg-slate-100 disabled:text-slate-400"
              />
              <span
                className={`absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-mono tabular-nums ${
                  inputMessage.length > 1900 ? "text-red-500 font-bold" : "text-slate-400"
                }`}
              >
                {inputMessage.length}/2000
              </span>
            </div>

            <button
              type="submit"
              disabled={!inputMessage.trim() || connectionStatus !== "connected"}
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-medium text-xs rounded-lg transition-colors flex items-center gap-1.5 shrink-0 shadow-sm"
            >
              <span>Send</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </footer>
      </main>
    </div>
  );
};
