export interface User {
  id: number;
  username: string;
  avatar?: string;
  isOnline: boolean;
  role?: string;
}

export interface Message {
  id: number;
  roomId: string;
  roomName: string;
  sender: string;
  userId: number;
  text: string;
  timestamp: string; // [HH:MM]
  isSystem?: boolean;
}

export interface Room {
  id: number;
  name: string;
  createdBy?: number;
  creatorName?: string;
  createdAt?: string;
  unreadCount?: number;
}

export interface TestResult {
  id: number;
  name: string;
  category: "auth" | "chat" | "security";
  description: string;
  status: "pending" | "running" | "passed" | "failed";
  durationMs: number;
  details: string;
  assertion: string;
}
