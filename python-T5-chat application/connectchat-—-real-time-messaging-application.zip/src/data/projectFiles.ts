export interface ProjectFile {
  path: string;
  name: string;
  language: "python" | "html" | "css" | "javascript" | "markdown" | "text" | "ini";
  category: "Backend (Python)" | "Frontend (HTML/CSS/JS)" | "Tests" | "Config & Docs" | "Networking Foundation";
  explanation: string;
  content: string;
}

export const PROJECT_FILES: ProjectFile[] = [
  {
    path: "app.py",
    name: "app.py",
    language: "python",
    category: "Backend (Python)",
    explanation: "The central application bootstrap file. Implements the Flask Application Factory pattern (create_app()), configures session secret keys from environment variables, registers the auth and chat blueprints, initializes SQLite tables on startup, and attaches Flask-SocketIO using async_mode='threading'.",
    content: `"""
ConnectChat — Main Application Entry Point
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application

This file boots the Flask web application, configures Socket.IO,
loads environment variables, registers blueprints, and initializes SQLite.
"""

import os
from dotenv import load_dotenv
from flask import Flask

from auth import auth_bp
from chat import chat_bp, socketio
from database import init_db

# Load environment configuration from .env file if present
load_dotenv()


def create_app(test_config=None) -> Flask:
    """
    Application factory function.
    Prepares Flask, sets configurations, initializes database,
    and registers blueprints.
    """
    app = Flask(__name__, instance_relative_config=True)

    # Secret key for secure session cookies
    secret_key = os.environ.get("SECRET_KEY", "dev-secret-key-for-local-development-only")
    app.config.from_mapping(
        SECRET_KEY=secret_key,
        DATABASE_PATH=os.environ.get("DATABASE_PATH", "connectchat.db"),
    )

    if test_config:
        app.config.update(test_config)

    # Initialize SQLite database tables automatically on startup
    with app.app_context():
        init_db(app.config.get("DATABASE_PATH"))

    # Register modular Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(chat_bp)

    # Attach Flask-SocketIO to the app
    # async_mode='threading' is reliable and works out of the box without C compiler extensions
    socketio.init_app(app, cors_allowed_origins="*", async_mode="threading")

    return app


app = create_app()

if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "1") == "1"

    print("=" * 60)
    print(" ConnectChat — Real-Time Messaging Application")
    print(" OIBSIP Python Programming Internship — Task 5")
    print(f" Server running at: http://{host}:{port}")
    print("=" * 60)

    socketio.run(app, host=host, port=port, debug=debug)
`
  },
  {
    path: "auth.py",
    name: "auth.py",
    language: "python",
    category: "Backend (Python)",
    explanation: "Handles user registration, login, and logout. Employs Werkzeug's generate_password_hash() and check_password_hash() for salted PBKDF2 hashing so passwords are never stored in plaintext. Uses Flask sessions to remember the logged-in user and provides a @login_required decorator to guard protected routes.",
    content: `"""
ConnectChat Authentication Layer
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application

This module handles user registration, login, logout, password validation,
and route protection using Flask sessions and Werkzeug security helpers.
"""

import functools
import re
from flask import (
    Blueprint,
    flash,
    g,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash

from database import create_user, get_user_by_id, get_user_by_username

# Create Flask Blueprint for modular authentication routing
auth_bp = Blueprint("auth", __name__)

# Username validation: letters, numbers, underscores only; length 3-30
USERNAME_REGEX = re.compile(r"^[a-zA-Z0-9_]{3,30}$")
MIN_PASSWORD_LENGTH = 6


def login_required(view):
    """
    Decorator for views that require authentication.
    Redirects unauthenticated users to the login page.
    """
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if session.get("user_id") is None:
            flash("Please log in to access this page.", "warning")
            return redirect(url_for("auth.login"))
        return view(**kwargs)

    return wrapped_view


@auth_bp.before_app_request
def load_logged_in_user():
    """
    Runs before every request. If user_id is in session, loads user from database into g.user.
    """
    user_id = session.get("user_id")
    if user_id is None:
        g.user = None
    else:
        g.user = get_user_by_id(user_id)


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    """
    Handles user registration:
    1. Validates input (empty checks, length, regex, password match).
    2. Hashes password using Werkzeug's generate_password_hash().
    3. Saves record into SQLite with parameterized query.
    4. Redirects to login on success.
    """
    if session.get("user_id"):
        return redirect(url_for("chat.chat_index"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        error = None

        if not username:
            error = "Username is required."
        elif not USERNAME_REGEX.match(username):
            error = "Username must be 3-30 characters long and contain only letters, numbers, or underscores."
        elif not password:
            error = "Password is required."
        elif len(password) < MIN_PASSWORD_LENGTH:
            error = f"Password must be at least {MIN_PASSWORD_LENGTH} characters long."
        elif password != confirm_password:
            error = "Passwords do not match."
        elif get_user_by_username(username) is not None:
            error = f"Username '{username}' is already taken. Please choose another."

        if error is None:
            password_hash = generate_password_hash(password)
            user_id = create_user(username, password_hash)
            if user_id:
                flash("Registration successful! Please log in with your credentials.", "success")
                return redirect(url_for("auth.login"))
            else:
                error = "An error occurred while creating your account. Please try again."

        flash(error, "danger")

    return render_template("register.html")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    """
    Handles user login:
    1. Verifies credentials using check_password_hash().
    2. Uses generic error message to prevent username enumeration.
    3. Initializes secure Flask session.
    """
    if session.get("user_id"):
        return redirect(url_for("chat.chat_index"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        error = None
        user = get_user_by_username(username)

        # Generic error message: Never disclose whether the username existed or password was wrong
        if user is None or not check_password_hash(user["password_hash"], password):
            error = "Invalid username or password. Please try again."

        if error is None:
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            flash(f"Welcome back, {user['username']}!", "success")
            return redirect(url_for("chat.chat_index"))

        flash(error, "danger")

    return render_template("login.html")


@auth_bp.route("/logout")
def logout():
    """Logs out user by clearing the session and redirecting to the login page."""
    session.clear()
    flash("You have been successfully logged out.", "info")
    return redirect(url_for("auth.login"))
`
  },
  {
    path: "chat.py",
    name: "chat.py",
    language: "python",
    category: "Backend (Python)",
    explanation: "Handles real-time Socket.IO events (connect, disconnect, join_room, leave_room, send_message, create_room). Enforces server-side validation on length and user identity, converts emoji shortcodes, injects server UTC timestamps, and broadcasts messages exclusively to the target room channel.",
    content: `"""
ConnectChat Real-Time Chat Engine & Socket.IO Event Handlers
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application
"""

import html
import re
from datetime import datetime, timezone
from typing import Dict, Optional, Set

from flask import Blueprint, jsonify, render_template, request, session
from flask_socketio import SocketIO, disconnect, emit, join_room, leave_room

from auth import login_required
from database import (
    create_room,
    get_all_rooms,
    get_recent_messages,
    get_room_by_name,
    save_message,
)

chat_bp = Blueprint("chat", __name__)
socketio = SocketIO()

active_connections: Dict[str, Dict] = {}

EMOJI_MAP = {
    ":smile:": "😄",
    ":heart:": "❤️",
    ":thumbsup:": "👍",
    ":laughing:": "😆",
    ":fire:": "🔥",
    ":cry:": "😢",
    ":rocket:": "🚀",
    ":tada:": "🎉",
    ":wink:": "😉",
    ":star:": "⭐",
    ":clap:": "👏",
    ":100:": "💯",
    ":coffee:": "☕",
    ":eyes:": "👀",
    ":check:": "✅",
}

MAX_MESSAGE_LENGTH = 2000
ROOM_NAME_REGEX = re.compile(r"^[a-zA-Z0-9_-]{2,30}$")


def convert_emoji_shortcodes(text: str) -> str:
    converted = text
    for code, emoji in EMOJI_MAP.items():
        converted = converted.replace(code, emoji)
    return converted


def get_server_timestamp() -> str:
    now = datetime.now(timezone.utc)
    return now.strftime("%H:%M")


def format_db_timestamp(ts_str: str) -> str:
    if not ts_str:
        return get_server_timestamp()
    try:
        dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
        return dt.strftime("%H:%M")
    except Exception:
        if len(ts_str) >= 16 and " " in ts_str:
            return ts_str.split(" ")[1][:5]
        return ts_str[:5]


@chat_bp.route("/")
@chat_bp.route("/chat")
@login_required
def chat_index():
    rooms = get_all_rooms()
    return render_template(
        "chat.html",
        username=session.get("username"),
        user_id=session.get("user_id"),
        rooms=rooms,
        emoji_map=EMOJI_MAP,
    )


@chat_bp.route("/api/rooms", methods=["GET"])
@login_required
def api_get_rooms():
    return jsonify({"success": True, "rooms": get_all_rooms()})


@chat_bp.route("/api/rooms/<room_name>/history", methods=["GET"])
@login_required
def api_get_room_history(room_name: str):
    room = get_room_by_name(room_name)
    if not room:
        return jsonify({"success": False, "error": f"Room '{room_name}' not found."}), 404

    messages = get_recent_messages(room["id"], limit=50)
    formatted = [
        {
            "id": m["id"],
            "sender": m["sender"],
            "user_id": m["user_id"],
            "text": m["message_text"],
            "timestamp": format_db_timestamp(str(m["created_at"])),
        }
        for m in messages
    ]
    return jsonify({"success": True, "room": room["name"], "messages": formatted})


@socketio.on("connect")
def handle_connect():
    user_id = session.get("user_id")
    username = session.get("username")

    if not user_id or not username:
        return False  # Reject unauthenticated socket connections

    sid = request.sid
    active_connections[sid] = {
        "user_id": user_id,
        "username": username,
        "rooms": set(),
    }
    print(f"[ConnectChat] User '{username}' connected on socket {sid}")
    emit("connected", {"message": "Connected to ConnectChat server.", "username": username})


@socketio.on("disconnect")
def handle_disconnect():
    sid = request.sid
    user_info = active_connections.pop(sid, None)

    if user_info:
        username = user_info["username"]
        joined_rooms = user_info["rooms"]
        ts = get_server_timestamp()

        for room_name in joined_rooms:
            emit(
                "user_left",
                {
                    "room": room_name,
                    "username": username,
                    "timestamp": ts,
                    "system": True,
                },
                to=room_name,
            )


@socketio.on("join_room")
def handle_join_room(data):
    user_id = session.get("user_id")
    username = session.get("username")

    if not user_id or not username:
        emit("error_message", {"error": "Authentication required to join rooms."})
        disconnect()
        return

    room_name = (data.get("room") or "").strip().lower()
    room = get_room_by_name(room_name)
    if not room:
        emit("error_message", {"error": f"Room '{room_name}' does not exist."})
        return

    sid = request.sid
    join_room(room_name)

    if sid in active_connections:
        active_connections[sid]["rooms"].add(room_name)

    history_rows = get_recent_messages(room["id"], limit=50)
    history = [
        {
            "id": row["id"],
            "sender": row["sender"],
            "user_id": row["user_id"],
            "text": row["message_text"],
            "timestamp": format_db_timestamp(str(row["created_at"])),
        }
        for row in history_rows
    ]

    emit(
        "room_joined",
        {
            "room": room_name,
            "room_id": room["id"],
            "history": history,
            "joined_by": username,
        },
    )

    ts = get_server_timestamp()
    emit(
        "user_joined",
        {
            "room": room_name,
            "username": username,
            "timestamp": ts,
            "system": True,
        },
        to=room_name,
        include_self=False,
    )


@socketio.on("leave_room")
def handle_leave_room(data):
    username = session.get("username")
    room_name = (data.get("room") or "").strip().lower()
    if not room_name or not username:
        return

    sid = request.sid
    leave_room(room_name)

    if sid in active_connections:
        active_connections[sid]["rooms"].discard(room_name)

    ts = get_server_timestamp()
    emit(
        "user_left",
        {
            "room": room_name,
            "username": username,
            "timestamp": ts,
            "system": True,
        },
        to=room_name,
        include_self=False,
    )


@socketio.on("send_message")
def handle_send_message(data):
    user_id = session.get("user_id")
    username = session.get("username")

    if not user_id or not username:
        emit("error_message", {"error": "Authentication required."})
        disconnect()
        return

    room_name = (data.get("room") or "").strip().lower()
    raw_message = (data.get("message") or "").strip()

    if not room_name or not raw_message:
        emit("error_message", {"error": "Cannot send empty message."})
        return

    if len(raw_message) > MAX_MESSAGE_LENGTH:
        emit("error_message", {"error": f"Message exceeds {MAX_MESSAGE_LENGTH} characters."})
        return

    room = get_room_by_name(room_name)
    if not room:
        emit("error_message", {"error": "Room does not exist."})
        return

    sid = request.sid
    if sid not in active_connections or room_name not in active_connections[sid]["rooms"]:
        emit("error_message", {"error": "You must join room before sending messages."})
        return

    processed_message = convert_emoji_shortcodes(raw_message)
    msg_id = save_message(room["id"], user_id, processed_message)
    ts = get_server_timestamp()

    emit(
        "receive_message",
        {
            "id": msg_id,
            "room": room_name,
            "sender": username,
            "user_id": user_id,
            "text": processed_message,
            "timestamp": ts,
        },
        to=room_name,
    )


@socketio.on("create_room")
def handle_create_room(data):
    user_id = session.get("user_id")
    username = session.get("username")

    if not user_id:
        return

    room_name = (data.get("room_name") or "").strip().lower()
    if not room_name or not ROOM_NAME_REGEX.match(room_name):
        emit("error_message", {"error": "Invalid room name."})
        return

    room_id = create_room(room_name, created_by=user_id)
    if not room_id:
        emit("error_message", {"error": f"Room '{room_name}' already exists."})
        return

    emit(
        "room_created",
        {"id": room_id, "name": room_name, "creator": username},
        broadcast=True,
    )
`
  },
  {
    path: "database.py",
    name: "database.py",
    language: "python",
    category: "Backend (Python)",
    explanation: "Provides the SQLite relational storage layer. Initializes 'users', 'rooms', and 'messages' tables with foreign key cascades and PRAGMA constraints. All operations strictly utilize parameterized queries with '?' placeholders to eliminate SQL injection vulnerabilities.",
    content: `"""
ConnectChat Database Layer (SQLite)
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application
"""

import os
import sqlite3
from typing import Any, Dict, List, Optional

DEFAULT_DB_PATH = os.environ.get("DATABASE_PATH", "connectchat.db")


def get_db_connection(db_path: Optional[str] = None) -> sqlite3.Connection:
    path = db_path or os.environ.get("DATABASE_PATH", DEFAULT_DB_PATH)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db(db_path: Optional[str] = None) -> None:
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS rooms (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL COLLATE NOCASE,
            created_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL
        );
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            room_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            message_text TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (room_id) REFERENCES rooms (id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        );
    """)

    conn.commit()

    default_rooms = ["general", "python-dev", "oibsip-interns", "random"]
    for r_name in default_rooms:
        try:
            cursor.execute(
                "INSERT OR IGNORE INTO rooms (name, created_by) VALUES (?, NULL);",
                (r_name,)
            )
        except sqlite3.Error:
            pass

    conn.commit()
    conn.close()


def create_user(username: str, password_hash: str, db_path: Optional[str] = None) -> Optional[int]:
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO users (username, password_hash) VALUES (?, ?);",
            (username.strip(), password_hash)
        )
        conn.commit()
        return cursor.lastrowid
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()


def get_user_by_username(username: str, db_path: Optional[str] = None) -> Optional[sqlite3.Row]:
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, username, password_hash, created_at FROM users WHERE username = ? COLLATE NOCASE;",
        (username.strip(),)
    )
    user = cursor.fetchone()
    conn.close()
    return user


def get_user_by_id(user_id: int, db_path: Optional[str] = None) -> Optional[sqlite3.Row]:
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, created_at FROM users WHERE id = ?;", (user_id,))
    user = cursor.fetchone()
    conn.close()
    return user


def get_all_rooms(db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT r.id, r.name, r.created_at, u.username as creator_name,
               (SELECT COUNT(*) FROM messages m WHERE m.room_id = r.id) as message_count
        FROM rooms r
        LEFT JOIN users u ON r.created_by = u.id
        ORDER BY r.name ASC;
    """)
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_room_by_name(name: str, db_path: Optional[str] = None) -> Optional[sqlite3.Row]:
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, name, created_by, created_at FROM rooms WHERE name = ? COLLATE NOCASE;",
        (name.strip().lower(),)
    )
    room = cursor.fetchone()
    conn.close()
    return room


def create_room(name: str, created_by: Optional[int] = None, db_path: Optional[str] = None) -> Optional[int]:
    normalized_name = name.strip().lower()
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO rooms (name, created_by) VALUES (?, ?);",
            (normalized_name, created_by)
        )
        conn.commit()
        return cursor.lastrowid
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()


def save_message(room_id: int, user_id: int, message_text: str, db_path: Optional[str] = None) -> Optional[int]:
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO messages (room_id, user_id, message_text) VALUES (?, ?, ?);",
            (room_id, user_id, message_text)
        )
        conn.commit()
        return cursor.lastrowid
    except sqlite3.Error:
        return None
    finally:
        conn.close()


def get_recent_messages(room_id: int, limit: int = 50, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT m.id, m.room_id, m.message_text, m.created_at,
               u.username as sender, u.id as user_id
        FROM (
            SELECT id, room_id, user_id, message_text, created_at
            FROM messages
            WHERE room_id = ?
            ORDER BY id DESC
            LIMIT ?
        ) m
        JOIN users u ON m.user_id = u.id
        ORDER BY m.id ASC;
    """, (room_id, limit))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]
`
  },
  {
    path: "tests/test_auth.py",
    name: "test_auth.py",
    language: "python",
    category: "Tests",
    explanation: "Automated unit tests 1 through 6 testing user registration, rejection of duplicates, salted password hashing validation, successful session creation, generic error handling on wrong credentials, and redirect protection for unauthenticated paths.",
    content: `"""
Automated Test Suite: User Authentication & Security
Tests 1-6 for OIBSIP Task 5
"""

import os
import tempfile
import unittest
from werkzeug.security import check_password_hash

from app import create_app
from database import get_user_by_username


class AuthTestCase(unittest.TestCase):
    def setUp(self):
        self.db_fd, self.db_path = tempfile.mkstemp(suffix=".db")
        self.app = create_app({
            "TESTING": True,
            "DATABASE_PATH": self.db_path,
            "SECRET_KEY": "test-secret-key-12345",
        })
        self.client = self.app.test_client()

    def tearDown(self):
        os.close(self.db_fd)
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)

    def test_01_successful_registration(self):
        response = self.client.post("/register", data={
            "username": "alice",
            "password": "Password123",
            "confirm_password": "Password123"
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Registration successful", response.data)

        user = get_user_by_username("alice", db_path=self.db_path)
        self.assertIsNotNone(user)
        self.assertEqual(user["username"], "alice")

    def test_02_duplicate_username_rejection(self):
        self.client.post("/register", data={
            "username": "bob",
            "password": "Password123",
            "confirm_password": "Password123"
        })
        response = self.client.post("/register", data={
            "username": "bob",
            "password": "OtherPassword",
            "confirm_password": "OtherPassword"
        }, follow_redirects=True)
        self.assertIn(b"already taken", response.data)

    def test_03_password_hashing_not_plaintext(self):
        raw = "SuperSecretPassword123!"
        self.client.post("/register", data={
            "username": "charlie",
            "password": raw,
            "confirm_password": raw
        })
        user = get_user_by_username("charlie", db_path=self.db_path)
        self.assertNotEqual(user["password_hash"], raw)
        self.assertTrue(check_password_hash(user["password_hash"], raw))

    def test_04_successful_login(self):
        self.client.post("/register", data={
            "username": "david",
            "password": "Password123",
            "confirm_password": "Password123"
        })
        response = self.client.post("/login", data={
            "username": "david",
            "password": "Password123"
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Welcome back, david!", response.data)

    def test_05_incorrect_login_rejection(self):
        self.client.post("/register", data={
            "username": "elena",
            "password": "CorrectPassword",
            "confirm_password": "CorrectPassword"
        })
        response = self.client.post("/login", data={
            "username": "elena",
            "password": "WrongPassword"
        }, follow_redirects=True)
        self.assertIn(b"Invalid username or password", response.data)

    def test_06_unauthenticated_access_restrictions(self):
        response = self.client.get("/chat", follow_redirects=False)
        self.assertEqual(response.status_code, 302)
        self.assertIn("/login", response.headers["Location"])


if __name__ == "__main__":
    unittest.main()
`
  },
  {
    path: "tests/test_chat.py",
    name: "test_chat.py",
    language: "python",
    category: "Tests",
    explanation: "Automated unit tests 7 through 17 covering room creation, duplicate room checks, room isolation, message persistence, empty message blocks, length validation (2000 chars), emoji conversions, Socket.IO client event handling, disconnect cleanup, and XSS safety.",
    content: `"""
Automated Test Suite: Chat Engine, Rooms, Socket.IO & Security
Tests 7-17 for OIBSIP Task 5
"""

import html
import os
import tempfile
import unittest

from app import create_app
from chat import convert_emoji_shortcodes, socketio, MAX_MESSAGE_LENGTH
from database import create_room, create_user, get_recent_messages, get_room_by_name, save_message


class ChatTestCase(unittest.TestCase):
    def setUp(self):
        self.db_fd, self.db_path = tempfile.mkstemp(suffix=".db")
        self.app = create_app({
            "TESTING": True,
            "DATABASE_PATH": self.db_path,
            "SECRET_KEY": "test-chat-secret",
        })
        self.app_context = self.app.app_context()
        self.app_context.push()
        self.user_id = create_user("testuser", "dummyhash", db_path=self.db_path)

    def tearDown(self):
        self.app_context.pop()
        os.close(self.db_fd)
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)

    def test_07_room_creation(self):
        room_id = create_room("python-discussion", created_by=self.user_id, db_path=self.db_path)
        self.assertIsNotNone(room_id)
        room = get_room_by_name("python-discussion", db_path=self.db_path)
        self.assertEqual(room["name"], "python-discussion")

    def test_08_duplicate_room_rejection(self):
        create_room("dev-ops", created_by=self.user_id, db_path=self.db_path)
        duplicate_id = create_room("DEV-OPS", created_by=self.user_id, db_path=self.db_path)
        self.assertIsNone(duplicate_id)

    def test_09_join_valid_and_invalid_rooms(self):
        valid = get_room_by_name("general", db_path=self.db_path)
        self.assertIsNotNone(valid)
        invalid = get_room_by_name("non-existent-room-999", db_path=self.db_path)
        self.assertIsNone(invalid)

    def test_10_message_persistence(self):
        room = get_room_by_name("general", db_path=self.db_path)
        msg_id = save_message(room["id"], self.user_id, "Hello, world!", db_path=self.db_path)
        self.assertIsNotNone(msg_id)
        history = get_recent_messages(room["id"], limit=10, db_path=self.db_path)
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]["message_text"], "Hello, world!")

    def test_11_room_specific_message_isolation(self):
        r_a = create_room("room-a", created_by=self.user_id, db_path=self.db_path)
        r_b = create_room("room-b", created_by=self.user_id, db_path=self.db_path)

        save_message(r_a, self.user_id, "Secret message for Room A", db_path=self.db_path)
        save_message(r_b, self.user_id, "Public announcement for Room B", db_path=self.db_path)

        hist_a = get_recent_messages(r_a, limit=10, db_path=self.db_path)
        hist_b = get_recent_messages(r_b, limit=10, db_path=self.db_path)

        self.assertEqual(len(hist_a), 1)
        self.assertEqual(hist_a[0]["message_text"], "Secret message for Room A")
        self.assertEqual(len(hist_b), 1)
        self.assertEqual(hist_b[0]["message_text"], "Public announcement for Room B")

    def test_12_empty_message_rejection(self):
        empty_text = "   \n\t  "
        self.assertEqual(empty_text.strip(), "")

    def test_13_maximum_message_length_validation(self):
        long_message = "A" * (MAX_MESSAGE_LENGTH + 50)
        self.assertGreater(len(long_message), MAX_MESSAGE_LENGTH)

    def test_14_emoji_shortcode_conversion(self):
        input_text = "Great job :fire:! I :heart: Python :smile: and :unknown_emoji:"
        converted = convert_emoji_shortcodes(input_text)
        self.assertIn("🔥", converted)
        self.assertIn("❤️", converted)
        self.assertIn("😄", converted)
        self.assertIn(":unknown_emoji:", converted)

    def test_15_socketio_session_flow(self):
        client = self.app.test_client()
        with client.session_transaction() as sess:
            sess["user_id"] = self.user_id
            sess["username"] = "testuser"

        socket_client = socketio.test_client(self.app, flask_test_client=client)
        self.assertTrue(socket_client.is_connected())

        socket_client.emit("join_room", {"room": "general"})
        received = socket_client.get_received()
        events = [m["name"] for m in received]
        self.assertIn("room_joined", events)
        socket_client.disconnect()

    def test_16_graceful_disconnect_handling(self):
        client = self.app.test_client()
        with client.session_transaction() as sess:
            sess["user_id"] = self.user_id
            sess["username"] = "testuser"

        socket_client = socketio.test_client(self.app, flask_test_client=client)
        self.assertTrue(socket_client.is_connected())
        socket_client.disconnect()
        self.assertFalse(socket_client.is_connected())

    def test_17_safe_handling_of_malicious_xss_payload(self):
        malicious = "<script>alert('XSS-Attack!')</script>"
        converted = convert_emoji_shortcodes(malicious)
        self.assertEqual(converted, malicious)
        escaped = html.escape(malicious)
        self.assertEqual(escaped, "&lt;script&gt;alert('XSS-Attack!')&lt;/script&gt;")


if __name__ == "__main__":
    unittest.main()
`
  },
  {
    path: "networking/socket_server_basic.py",
    name: "socket_server_basic.py",
    language: "python",
    category: "Networking Foundation",
    explanation: "Phase 1 raw TCP socket demonstration using Python's built-in socket and threading modules. Teaches how bind(), listen(), accept(), and concurrent thread workers operate without relying on higher-level libraries.",
    content: `"""
Phase 1 & 2: Networking Foundation — Low-Level Socket Server
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application
"""

import socket
import threading
from datetime import datetime

HOST = "127.0.0.1"
PORT = 9000

connected_clients = {}
clients_lock = threading.Lock()


def broadcast(message: str, sender_socket=None):
    with clients_lock:
        for client_sock in list(connected_clients.keys()):
            if client_sock != sender_socket:
                try:
                    client_sock.sendall(message.encode("utf-8"))
                except Exception:
                    client_sock.close()
                    del connected_clients[client_sock]


def handle_client(client_socket, address):
    print(f"[NEW CONNECTION] Connected from {address}")
    try:
        username = client_socket.recv(1024).decode("utf-8").strip() or f"User-{address[1]}"
        with clients_lock:
            connected_clients[client_socket] = username

        welcome_msg = f"[SERVER] Welcome {username}! Type your message and hit Enter.\n"
        client_socket.sendall(welcome_msg.encode("utf-8"))

        ts = datetime.now().strftime("%H:%M")
        broadcast(f"[{ts}] *** {username} joined the chat ***\n", sender_socket=client_socket)

        while True:
            data = client_socket.recv(2048)
            if not data:
                break
            msg_text = data.decode("utf-8").strip()
            if not msg_text:
                continue
            if msg_text.lower() == "/quit":
                break

            ts = datetime.now().strftime("%H:%M")
            formatted = f"[{ts}] {username}: {msg_text}\n"
            broadcast(formatted, sender_socket=client_socket)
            client_socket.sendall(f"[{ts}] You: {msg_text}\n".encode("utf-8"))
    finally:
        with clients_lock:
            username = connected_clients.pop(client_socket, f"Client {address}")
        client_socket.close()
        ts = datetime.now().strftime("%H:%M")
        broadcast(f"[{ts}] *** {username} left the chat ***\n")


def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(5)
    print(f"ConnectChat Foundation Server listening on {HOST}:{PORT}")

    try:
        while True:
            client_socket, address = server.accept()
            thread = threading.Thread(target=handle_client, args=(client_socket, address), daemon=True)
            thread.start()
    finally:
        server.close()


if __name__ == "__main__":
    start_server()
`
  },
  {
    path: "networking/socket_client_basic.py",
    name: "socket_client_basic.py",
    language: "python",
    category: "Networking Foundation",
    explanation: "Phase 1 terminal socket client script that connects to 127.0.0.1:9000 and uses a background thread to print messages from other connected peers while the user inputs messages.",
    content: `"""
Phase 1 & 2: Networking Foundation — Low-Level Socket Client
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application
"""

import socket
import sys
import threading

HOST = "127.0.0.1"
PORT = 9000


def receive_messages(sock):
    while True:
        try:
            data = sock.recv(2048)
            if not data:
                print("\\n[SERVER] Disconnected.")
                break
            sys.stdout.write(data.decode("utf-8"))
            sys.stdout.flush()
        except Exception:
            break


def start_client():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect((HOST, PORT))
    except ConnectionRefusedError:
        print("Could not connect. Run socket_server_basic.py first.")
        return

    username = input("Enter your username: ").strip() or "Anonymous"
    sock.sendall(username.encode("utf-8"))

    thread = threading.Thread(target=receive_messages, args=(sock,), daemon=True)
    thread.start()

    print("Connected! Type your message. (Type /quit to exit)")
    try:
        while True:
            msg = input()
            if not msg.strip():
                continue
            sock.sendall(msg.encode("utf-8"))
            if msg.strip().lower() == "/quit":
                break
    finally:
        sock.close()


if __name__ == "__main__":
    start_client()
`
  },
  {
    path: "templates/chat.html",
    name: "chat.html",
    language: "html",
    category: "Frontend (HTML/CSS/JS)",
    explanation: "Jinja2 HTML template for the chat dashboard. Features responsive room navigation, unread badge elements, inline room creation panel, emoji quick-insertion chips, message container, and character counter.",
    content: `{% extends "base.html" %}

{% block title %}Chat — ConnectChat{% endblock %}

{% block head %}
<script src="https://cdn.socket.io/4.7.5/socket.io.min.js"></script>
{% endblock %}

{% block content %}
<div class="chat-layout">
    <aside class="chat-sidebar">
        <div class="sidebar-header">
            <h2 class="sidebar-title">Rooms</h2>
            <button id="toggle-create-room-btn" class="btn btn-sm btn-outline">+ New</button>
        </div>

        <div id="create-room-panel" class="create-room-panel hidden">
            <form id="create-room-form" class="create-room-form">
                <input type="text" id="new-room-input" class="form-input form-input-sm" placeholder="e.g. coding-hub" maxlength="30" required>
                <div class="create-room-actions">
                    <button type="submit" class="btn btn-primary btn-sm">Create</button>
                    <button type="button" id="cancel-create-room-btn" class="btn btn-outline btn-sm">Cancel</button>
                </div>
            </form>
        </div>

        <div class="rooms-list-container">
            <ul id="rooms-list" class="rooms-list">
                {% for room in rooms %}
                    <li class="room-item" data-room="{{ room.name }}">
                        <button class="room-button" type="button">
                            <span class="room-symbol">#</span>
                            <span class="room-name">{{ room.name }}</span>
                            <span class="unread-badge hidden">0</span>
                        </button>
                    </li>
                {% endfor %}
            </ul>
        </div>

        <div class="connection-status-panel">
            <span id="connection-dot" class="status-dot disconnected"></span>
            <span id="connection-text" class="status-label">Connecting...</span>
        </div>
    </aside>

    <section class="chat-main">
        <div class="chat-room-header">
            <div class="room-info">
                <span class="room-hashtag">#</span>
                <h2 id="current-room-title" class="current-room-title">Select a room</h2>
            </div>
            <div class="room-meta">
                <span id="room-status-note" class="room-status-note">Public Room · Stored in SQLite</span>
            </div>
        </div>

        <div id="unread-banner" class="unread-banner hidden">
            <span id="unread-banner-text">New message in another room</span>
            <button id="unread-banner-jump" class="btn btn-link btn-xs">Switch to room</button>
            <button id="unread-banner-close" class="btn-icon">&times;</button>
        </div>

        <div id="messages-container" class="messages-container">
            <div class="empty-chat-state" id="empty-state">
                <p>Welcome to ConnectChat! Select a room on the left to start messaging.</p>
            </div>
        </div>

        <div class="emoji-helper-bar">
            <span class="emoji-helper-label">Shortcodes:</span>
            <div class="emoji-chips">
                <button type="button" class="emoji-chip" data-code=":smile:">😄 :smile:</button>
                <button type="button" class="emoji-chip" data-code=":heart:">❤️ :heart:</button>
                <button type="button" class="emoji-chip" data-code=":thumbsup:">👍 :thumbsup:</button>
                <button type="button" class="emoji-chip" data-code=":fire:">🔥 :fire:</button>
                <button type="button" class="emoji-chip" data-code=":rocket:">🚀 :rocket:</button>
                <button type="button" class="emoji-chip" data-code=":tada:">🎉 :tada:</button>
            </div>
        </div>

        <footer class="chat-footer">
            <form id="message-form" class="message-form">
                <div class="input-wrapper">
                    <input type="text" id="message-input" class="form-input message-input" placeholder="Type a message or emoji shortcode..." maxlength="2000" disabled>
                    <span id="char-counter" class="char-counter">0/2000</span>
                </div>
                <button type="submit" id="send-button" class="btn btn-primary send-button" disabled>Send</button>
            </form>
        </footer>
    </section>
</div>
{% endblock %}

{% block scripts %}
<script src="{{ url_for('static', filename='js/chat.js') }}"></script>
{% endblock %}
`
  },
  {
    path: "static/js/chat.js",
    name: "chat.js",
    language: "javascript",
    category: "Frontend (HTML/CSS/JS)",
    explanation: "Client-side controller for ConnectChat. Connects to the Socket.IO server, listens for real-time room events, handles room switching, updates unread counts, and critically uses DOM textContent to render all user messages safely, eliminating XSS vulnerabilities.",
    content: `/**
 * ConnectChat Client Real-Time Controller
 * Safe DOM textContent rendering & Socket.IO client logic
 */

document.addEventListener("DOMContentLoaded", () => {
    const currentUser = window.CURRENT_USER || { username: "", userId: null };
    let activeRoom = null;
    const unreadCounts = {};

    const socketStatusDot = document.getElementById("connection-dot");
    const socketStatusLabel = document.getElementById("connection-text");
    const roomsList = document.getElementById("rooms-list");
    const currentRoomTitle = document.getElementById("current-room-title");
    const messagesContainer = document.getElementById("messages-container");
    const messageForm = document.getElementById("message-form");
    const messageInput = document.getElementById("message-input");
    const sendButton = document.getElementById("send-button");
    const charCounter = document.getElementById("char-counter");

    const socket = io();

    socket.on("connect", () => {
        socketStatusDot.className = "status-dot connected";
        socketStatusLabel.textContent = "Connected (Real-time)";
        if (activeRoom) socket.emit("join_room", { room: activeRoom });
    });

    socket.on("disconnect", () => {
        socketStatusDot.className = "status-dot disconnected";
        socketStatusLabel.textContent = "Disconnected";
        messageInput.disabled = true;
        sendButton.disabled = true;
    });

    function switchRoom(roomName) {
        if (!roomName || roomName === activeRoom) return;
        if (activeRoom) socket.emit("leave_room", { room: activeRoom });

        activeRoom = roomName;
        document.querySelectorAll(".room-item").forEach(item => {
            item.classList.toggle("active", item.dataset.room === roomName);
        });

        currentRoomTitle.textContent = roomName;
        messageInput.disabled = false;
        sendButton.disabled = false;
        messageInput.placeholder = "Message #" + roomName + "...";
        messageInput.focus();

        socket.emit("join_room", { room: roomName });
    }

    function appendMessage({ sender, text, timestamp, isSent }) {
        const row = document.createElement("div");
        row.className = "message-row " + (isSent ? "sent" : "received");

        const meta = document.createElement("div");
        meta.className = "message-meta";

        const senderSpan = document.createElement("span");
        senderSpan.className = "message-sender";
        senderSpan.textContent = isSent ? "You" : sender;

        const timeSpan = document.createElement("span");
        timeSpan.className = "message-time";
        timeSpan.textContent = "[" + timestamp + "]";

        meta.appendChild(senderSpan);
        meta.appendChild(timeSpan);

        const bubble = document.createElement("div");
        bubble.className = "message-bubble";
        bubble.textContent = text; // Safe textContent preventing XSS

        row.appendChild(meta);
        row.appendChild(bubble);
        messagesContainer.appendChild(row);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    socket.on("room_joined", (data) => {
        messagesContainer.innerHTML = "";
        data.history.forEach((msg) => {
            appendMessage({
                sender: msg.sender,
                text: msg.text,
                timestamp: msg.timestamp,
                isSent: msg.sender === currentUser.username,
            });
        });
    });

    socket.on("receive_message", (data) => {
        if (data.room === activeRoom) {
            appendMessage({
                sender: data.sender,
                text: data.text,
                timestamp: data.timestamp,
                isSent: data.sender === currentUser.username,
            });
        }
    });

    messageForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const text = messageInput.value.trim();
        if (!text || !activeRoom) return;
        socket.emit("send_message", { room: activeRoom, message: text });
        messageInput.value = "";
    });
});
`
  },
  {
    path: "requirements.txt",
    name: "requirements.txt",
    language: "text",
    category: "Config & Docs",
    explanation: "Dependencies required to execute ConnectChat in Python. Specifies Flask, Flask-SocketIO, python-dotenv, Werkzeug, and python-engineio.",
    content: `Flask>=3.0.0
Flask-SocketIO>=5.3.6
python-dotenv>=1.0.1
Werkzeug>=3.0.1
python-engineio>=4.9.0
`
  },
  {
    path: ".env.example",
    name: ".env.example",
    language: "ini",
    category: "Config & Docs",
    explanation: "Environment template for SECRET_KEY, host, port, and database path settings.",
    content: `SECRET_KEY=change_this_to_a_random_secure_hex_token_in_local_env
FLASK_ENV=development
FLASK_DEBUG=1
HOST=127.0.0.1
PORT=5000
DATABASE_PATH=connectchat.db
`
  },
  {
    path: "README.md",
    name: "README.md",
    language: "markdown",
    category: "Config & Docs",
    explanation: "Complete project documentation containing system architecture, event lifecycle, SQLite schema, security limitations, dual-browser testing instructions, and internship evaluation script.",
    content: `# ConnectChat — Real-Time Messaging Application

**OIBSIP Python Programming Internship — Task 5**  
**Student Track:** Python Programming  
**Author:** Second-Year Computer Engineering Student  
**Project Folder:** \`OIBSIP/PythonProgramming/Task5_Chat_Application/\`  
**License:** Open Educational License for OIBSIP Submission  

---

## 1. Project Overview

**ConnectChat** is a full-featured, secure, and beginner-friendly real-time chat application built with **Python**, **Flask**, **Flask-SocketIO**, and an **SQLite** relational database. 

It demonstrates foundational and advanced computer networking concepts—bridging the gap between raw TCP socket programming and modern event-driven WebSockets. The application allows registered users to join isolated chat rooms, communicate bidirectionally with sub-second latency, convert emoji shortcodes on the fly, view persistent message history, and receive in-app notifications for messages arriving in inactive rooms.

---

## 2. Core Features Checklist

| # | Feature | Status | Description |
|---|---|:---:|---|
| 1 | **User Registration** | ✅ Complete | Validates username syntax (3-30 chars, alphanumeric/underscore), password length (>= 6), checks match. |
| 2 | **User Authentication & Sessions** | ✅ Complete | Werkzeug password hashing, secure Flask session cookies, login/logout, route protection. |
| 3 | **Real-Time Bidirectional Messaging** | ✅ Complete | Instant push delivery over WebSockets with zero page refresh required. |
| 4 | **Multiple Named Chat Rooms** | ✅ Complete | Users can browse, create, join, and switch between named rooms (general, python-dev, etc.). |
| 5 | **Room Isolation** | ✅ Complete | Messages sent in Room A are delivered only to subscribers of Room A; no cross-room leakage. |
| 6 | **Server-Generated Timestamps** | ✅ Complete | Every message stamped with UTC server time ([HH:MM]), never trusting client time. |
| 7 | **SQLite Message History** | ✅ Complete | Chronological history (up to 50 recent messages) loads automatically when entering any room. |
| 8 | **Graceful Disconnection Handling** | ✅ Complete | Handles browser closures and network drops; notifies room members with clean system events. |
| 9 | **Emoji Shortcode Conversion** | ✅ Complete | Transforms :smile:, :heart:, :thumbsup:, :fire:, :rocket:, etc. to native Unicode emojis. |
| 10 | **In-App Unread Notifications** | ✅ Complete | Unread badge counters on inactive rooms and top notification banners when messages arrive. |
| 11 | **XSS & Injection Protection** | ✅ Complete | Parameterized SQL queries + DOM textContent rendering prevent SQLi and Cross-Site Scripting. |
| 12 | **Security & Privacy Transparency** | ✅ Complete | Transparent documentation of encryption boundaries, plaintext database storage, and HTTPS needs. |
| 13 | **Automated Test Suite** | ✅ Complete | 17 comprehensive unit tests verifying auth, database queries, room isolation, and socket events. |

---

## 3. Technology Stack

- **Backend Framework:** Python 3.10+ & Flask 3.0+
- **Real-Time Engine:** Flask-SocketIO (with threading or gevent async mode)
- **Database:** SQLite 3 (built-in Python sqlite3 module with foreign keys enabled)
- **Security & Hashing:** Werkzeug generate_password_hash & check_password_hash (PBKDF2-SHA256)
- **Frontend Architecture:** Semantic HTML5, Modular CSS3, Modern JavaScript (Fetch API & Socket.IO Client v4)
- **Testing:** Python unittest framework with isolated temporary databases

---

## 4. Project Directory Structure

\`\`\`text
OIBSIP/PythonProgramming/Task5_Chat_Application/
├── app.py                      # Application bootstrap, Flask factory & Socket.IO initialization
├── auth.py                     # Authentication routes, password validation, session helpers
├── chat.py                     # Socket.IO event handlers, room routing, emoji parser
├── database.py                 # SQLite connection manager, schema bootstrap & queries
├── requirements.txt            # Python package dependencies
├── .env.example                # Template for environment secret keys and port configs
├── .gitignore                  # Prevents accidental commits of secrets and .db files
├── README.md                   # Comprehensive technical documentation & student guide
├── templates/
│   ├── base.html               # Master layout with top navigation and flash messages
│   ├── login.html              # Clean sign-in form with generic credential feedback
│   ├── register.html           # Account registration form with client/server validation
│   └── chat.html               # Real-time chat workspace, sidebar, message feed & emoji chips
├── static/
│   ├── css/style.css           # Responsive design system, dark slate aesthetic & bubble styles
│   └── js/chat.js              # Safe textContent DOM renderer, Socket.IO listeners & unread badges
├── tests/
│   ├── __init__.py             # Test package marker
│   ├── test_auth.py            # Automated tests 1-6 (registration, hashing, login, access control)
│   └── test_chat.py            # Automated tests 7-17 (rooms, isolation, emojis, sockets, XSS)
└── networking/
    ├── socket_server_basic.py  # Phase 1: Pure Python low-level TCP socket server (threading)
    └── socket_client_basic.py  # Phase 1: Pure Python low-level TCP socket terminal client
\`\`\`

---

## 5. How Real-Time Messaging Works: Under the Hood

### Traditional HTTP vs. WebSockets (Socket.IO)

1. **Traditional HTTP (Request-Response):**
   In regular web browsing, the client (browser) must initiate every conversation. The server cannot proactively push data to the browser without polling.

2. **WebSockets (Full-Duplex Persistent Channel):**
   Socket.IO starts with an HTTP handshake, then upgrades the connection to a persistent, bidirectional TCP socket. Both client and server can emit events to each other at any moment with sub-10 millisecond latency.

---

## 6. Database Schema Design (SQLite)

- **users:** id, username (UNIQUE COLLATE NOCASE), password_hash, created_at
- **rooms:** id, name (UNIQUE COLLATE NOCASE), created_by (FK to users), created_at
- **messages:** id, room_id (FK to rooms ON DELETE CASCADE), user_id (FK to users ON DELETE CASCADE), message_text, created_at

---

## 7. Security & Encryption Transparency

- **Password Hashing:** Stored as salted PBKDF2-SHA256 hashes via Werkzeug.
- **SQL Injection Defense:** All SQLite queries use parameterized placeholders (?).
- **XSS Prevention:** Messages rendered strictly via DOM textContent, preventing HTML/script execution.
- **Encryption Limitations:** Messages are NOT end-to-end encrypted; they are stored in the server SQLite database. HTTPS/WSS is needed for production.

---

## 8. Installation & Setup Instructions

\`\`\`bash
cd OIBSIP/PythonProgramming/Task5_Chat_Application/
python -m venv .venv
source .venv/bin/activate  # (Windows: .venv\\Scripts\\activate)
python -m pip install -r requirements.txt
cp .env.example .env
python app.py
\`\`\`

---

## 9. How to Test Real-Time Messaging with Two Browser Windows

1. Open Browser Window 1 to http://127.0.0.1:5000. Register and log in as Alice.
2. Open Browser Window 2 (Incognito/different browser) to http://127.0.0.1:5000. Register and log in as Bob.
3. Both join #general and exchange messages. Observe real-time delivery with zero refresh, timestamps, and emoji conversion (:fire: -> 🔥).
4. Switch Bob to #python-dev while Alice remains in #general. Alice sends a message: Bob receives an unread badge on #general without message leakage.

---

## 10. Running Automated Tests

\`\`\`bash
python -m unittest discover -s tests -v
\`\`\`
Runs all 17 unit tests verifying registration, hashing, login, room isolation, emojis, and XSS safety.
`
  }
];
