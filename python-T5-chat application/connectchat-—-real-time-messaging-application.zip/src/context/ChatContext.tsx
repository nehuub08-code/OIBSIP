import React, { createContext, useContext, useEffect, useState } from "react";
import { Message, Room, User } from "../types/chat";
import { convertEmojiShortcodes, getServerTimestamp } from "../utils/emoji";

// Pre-seeded users with realistic avatars and profiles
export const INITIAL_USERS: User[] = [
  {
    id: 1,
    username: "alice",
    avatar: "/src/assets/images/avatar_alice_1793216024708.jpg",
    isOnline: true,
    role: "Computer Eng Student",
  },
  {
    id: 2,
    username: "bob",
    avatar: "/src/assets/images/avatar_bob_1793216025432.jpg",
    isOnline: true,
    role: "OIBSIP Intern",
  },
  {
    id: 3,
    username: "charlie",
    isOnline: true,
    role: "Peer Reviewer",
  },
];

export const INITIAL_ROOMS: Room[] = [
  { id: 1, name: "general", createdBy: 1, creatorName: "alice" },
  { id: 2, name: "python-dev", createdBy: 2, creatorName: "bob" },
  { id: 3, name: "oibsip-interns", createdBy: 1, creatorName: "alice" },
  { id: 4, name: "random", createdBy: 3, creatorName: "charlie" },
];

export const INITIAL_MESSAGES: Message[] = [
  {
    id: 1,
    roomId: "1",
    roomName: "general",
    sender: "alice",
    userId: 1,
    text: "Welcome to ConnectChat! :wave: Testing real-time messaging for OIBSIP Task 5.",
    timestamp: "12:15",
  },
  {
    id: 2,
    roomId: "1",
    roomName: "general",
    sender: "bob",
    userId: 2,
    text: "Hey Alice! The Flask-SocketIO event loop is blazing fast :rocket: :fire:",
    timestamp: "12:16",
  },
  {
    id: 3,
    roomId: "2",
    roomName: "python-dev",
    sender: "bob",
    userId: 2,
    text: "Anyone working on parameterized SQLite queries today? :coffee:",
    timestamp: "12:20",
  },
  {
    id: 4,
    roomId: "3",
    roomName: "oibsip-interns",
    sender: "charlie",
    userId: 3,
    text: "Make sure to run all 17 automated tests before submitting your report :check: :100:",
    timestamp: "12:22",
  },
];

interface ChatContextType {
  currentUser: User;
  setCurrentUser: (user: User) => void;
  users: User[];
  rooms: Room[];
  messages: Message[];
  activeRoom: string;
  setActiveRoom: (room: string) => void;
  unreadCounts: Record<string, number>;
  latestNotification: { room: string; sender: string; text: string } | null;
  clearNotification: () => void;
  sendMessage: (text: string, customRoom?: string, customUser?: User) => boolean;
  createRoom: (name: string, createdByUserId?: number) => { success: boolean; error?: string };
  registerUser: (username: string, password: string) => { success: boolean; error?: string };
  resetDatabase: () => void;
  // Dual-window specific states
  window2User: User;
  setWindow2User: (user: User) => void;
  window2Room: string;
  setWindow2Room: (room: string) => void;
  window2Unreads: Record<string, number>;
  connectionStatus: "connected" | "connecting" | "disconnected";
  simulateDisconnect: (disconnected: boolean) => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

const BROADCAST_CHANNEL_NAME = "connectchat_channel_v1";
const STORAGE_PREFIX = "connectchat_v1_";

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}users`);
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<User>(() => users[0] || INITIAL_USERS[0]);
  const [window2User, setWindow2User] = useState<User>(() => users[1] || INITIAL_USERS[1]);

  const [rooms, setRooms] = useState<Room[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}rooms`);
    return saved ? JSON.parse(saved) : INITIAL_ROOMS;
  });

  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}messages`);
    return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
  });

  const [activeRoom, setActiveRoomState] = useState<string>("general");
  const [window2Room, setWindow2RoomState] = useState<string>("general");

  const [unreadCounts, setUnreadCounts] = useState<Record<string, number>>({});
  const [window2Unreads, setWindow2Unreads] = useState<Record<string, number>>({});

  const [latestNotification, setLatestNotification] = useState<{
    room: string;
    sender: string;
    text: string;
  } | null>(null);

  const [connectionStatus, setConnectionStatus] = useState<"connected" | "connecting" | "disconnected">("connected");

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}users`, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}rooms`, JSON.stringify(rooms));
  }, [rooms]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}messages`, JSON.stringify(messages));
  }, [messages]);

  // Real-time cross-tab broadcast synchronization
  useEffect(() => {
    if (typeof window === "undefined" || !("BroadcastChannel" in window)) return;
    const channel = new BroadcastChannel(BROADCAST_CHANNEL_NAME);

    channel.onmessage = (event) => {
      const data = event.data;
      if (!data) return;

      if (data.type === "NEW_MESSAGE") {
        const msg: Message = data.payload;
        setMessages((prev) => {
          if (prev.some((m) => m.id === msg.id)) return prev;
          return [...prev, msg];
        });

        // Update unreads for current user if in different room and not sent by current user
        if (msg.roomName !== activeRoom && msg.sender !== currentUser.username) {
          setUnreadCounts((prev) => ({
            ...prev,
            [msg.roomName]: (prev[msg.roomName] || 0) + 1,
          }));
          setLatestNotification({
            room: msg.roomName,
            sender: msg.sender,
            text: msg.text,
          });
        }

        // Update unreads for window 2 user
        if (msg.roomName !== window2Room && msg.sender !== window2User.username) {
          setWindow2Unreads((prev) => ({
            ...prev,
            [msg.roomName]: (prev[msg.roomName] || 0) + 1,
          }));
        }
      } else if (data.type === "NEW_ROOM") {
        const newR: Room = data.payload;
        setRooms((prev) => {
          if (prev.some((r) => r.name.toLowerCase() === newR.name.toLowerCase())) return prev;
          return [...prev, newR];
        });
      } else if (data.type === "NEW_USER") {
        const newU: User = data.payload;
        setUsers((prev) => {
          if (prev.some((u) => u.username.toLowerCase() === newU.username.toLowerCase())) return prev;
          return [...prev, newU];
        });
      }
    };

    return () => {
      channel.close();
    };
  }, [activeRoom, window2Room, currentUser.username, window2User.username]);

  const setActiveRoom = (room: string) => {
    setActiveRoomState(room);
    setUnreadCounts((prev) => ({
      ...prev,
      [room]: 0,
    }));
    if (latestNotification?.room === room) {
      setLatestNotification(null);
    }
  };

  const setWindow2Room = (room: string) => {
    setWindow2RoomState(room);
    setWindow2Unreads((prev) => ({
      ...prev,
      [room]: 0,
    }));
  };

  const clearNotification = () => setLatestNotification(null);

  const simulateDisconnect = (disconnected: boolean) => {
    setConnectionStatus(disconnected ? "disconnected" : "connected");
  };

  const sendMessage = (text: string, customRoom?: string, customUser?: User): boolean => {
    const trimmed = text.trim();
    if (!trimmed) return false;
    if (trimmed.length > 2000) return false;

    const targetRoomName = customRoom || activeRoom;
    const author = customUser || currentUser;

    const matchedRoom = rooms.find((r) => r.name.toLowerCase() === targetRoomName.toLowerCase());
    if (!matchedRoom) return false;

    // Convert emoji shortcodes
    const processedText = convertEmojiShortcodes(trimmed);
    const ts = getServerTimestamp();

    const newMessage: Message = {
      id: Date.now() + Math.floor(Math.random() * 1000),
      roomId: String(matchedRoom.id),
      roomName: matchedRoom.name,
      sender: author.username,
      userId: author.id,
      text: processedText,
      timestamp: ts,
    };

    setMessages((prev) => [...prev, newMessage]);

    // Handle in-app notifications
    // If sent by Window 1 author, update Window 2 unread if Window 2 is in another room
    if (author.username === currentUser.username) {
      if (matchedRoom.name !== window2Room) {
        setWindow2Unreads((prev) => ({
          ...prev,
          [matchedRoom.name]: (prev[matchedRoom.name] || 0) + 1,
        }));
      }
    } else if (author.username === window2User.username) {
      if (matchedRoom.name !== activeRoom) {
        setUnreadCounts((prev) => ({
          ...prev,
          [matchedRoom.name]: (prev[matchedRoom.name] || 0) + 1,
        }));
        setLatestNotification({
          room: matchedRoom.name,
          sender: author.username,
          text: processedText,
        });
      }
    }

    // Broadcast across actual browser tabs
    if (typeof window !== "undefined" && "BroadcastChannel" in window) {
      const channel = new BroadcastChannel(BROADCAST_CHANNEL_NAME);
      channel.postMessage({ type: "NEW_MESSAGE", payload: newMessage });
      channel.close();
    }

    return true;
  };

  const createRoom = (name: string, createdByUserId?: number): { success: boolean; error?: string } => {
    const normalized = name.trim().toLowerCase();
    if (!normalized) {
      return { success: false, error: "Room name cannot be empty." };
    }
    if (!/^[a-zA-Z0-9_-]{2,30}$/.test(normalized)) {
      return {
        success: false,
        error: "Room name must be 2-30 characters long and contain only letters, numbers, hyphens, or underscores.",
      };
    }
    if (rooms.some((r) => r.name.toLowerCase() === normalized)) {
      return { success: false, error: `A room named '${normalized}' already exists.` };
    }

    const creatorId = createdByUserId || currentUser.id;
    const creator = users.find((u) => u.id === creatorId);

    const newRoom: Room = {
      id: rooms.length > 0 ? Math.max(...rooms.map((r) => r.id)) + 1 : 1,
      name: normalized,
      createdBy: creatorId,
      creatorName: creator?.username || "unknown",
      createdAt: new Date().toISOString(),
    };

    setRooms((prev) => [...prev, newRoom]);

    if (typeof window !== "undefined" && "BroadcastChannel" in window) {
      const channel = new BroadcastChannel(BROADCAST_CHANNEL_NAME);
      channel.postMessage({ type: "NEW_ROOM", payload: newRoom });
      channel.close();
    }

    return { success: true };
  };

  const registerUser = (username: string, password: string): { success: boolean; error?: string } => {
    const trimmed = username.trim();
    if (!trimmed) {
      return { success: false, error: "Username is required." };
    }
    if (!/^[a-zA-Z0-9_]{3,30}$/.test(trimmed)) {
      return {
        success: false,
        error: "Username must be 3-30 characters with letters, numbers, or underscores.",
      };
    }
    if (!password || password.length < 6) {
      return { success: false, error: "Password must be at least 6 characters." };
    }
    if (users.some((u) => u.username.toLowerCase() === trimmed.toLowerCase())) {
      return { success: false, error: `Username '${trimmed}' is already taken.` };
    }

    const newUser: User = {
      id: users.length > 0 ? Math.max(...users.map((u) => u.id)) + 1 : 1,
      username: trimmed,
      isOnline: true,
      role: "Registered User",
    };

    setUsers((prev) => [...prev, newUser]);
    setCurrentUser(newUser);

    if (typeof window !== "undefined" && "BroadcastChannel" in window) {
      const channel = new BroadcastChannel(BROADCAST_CHANNEL_NAME);
      channel.postMessage({ type: "NEW_USER", payload: newUser });
      channel.close();
    }

    return { success: true };
  };

  const resetDatabase = () => {
    localStorage.removeItem(`${STORAGE_PREFIX}users`);
    localStorage.removeItem(`${STORAGE_PREFIX}rooms`);
    localStorage.removeItem(`${STORAGE_PREFIX}messages`);
    setUsers(INITIAL_USERS);
    setCurrentUser(INITIAL_USERS[0]);
    setWindow2User(INITIAL_USERS[1]);
    setRooms(INITIAL_ROOMS);
    setMessages(INITIAL_MESSAGES);
    setActiveRoomState("general");
    setWindow2RoomState("general");
    setUnreadCounts({});
    setWindow2Unreads({});
    setLatestNotification(null);
  };

  return (
    <ChatContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        users,
        rooms,
        messages,
        activeRoom,
        setActiveRoom,
        unreadCounts,
        latestNotification,
        clearNotification,
        sendMessage,
        createRoom,
        registerUser,
        resetDatabase,
        window2User,
        setWindow2User,
        window2Room,
        setWindow2Room,
        window2Unreads,
        connectionStatus,
        simulateDisconnect,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error("useChat must be used within a ChatProvider");
  }
  return context;
};
