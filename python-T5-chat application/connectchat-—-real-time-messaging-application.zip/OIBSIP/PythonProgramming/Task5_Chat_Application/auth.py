"""
ConnectChat Authentication Layer
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application

This module handles user registration, login, logout, password validation,
and route protection using Flask sessions and Werkzeug security helpers.
"""

import functools
import re
from flask import (
    Blueprint,
    flash,
    g,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash

from database import create_user, get_user_by_id, get_user_by_username

# Create Flask Blueprint for modular authentication routing
auth_bp = Blueprint("auth", __name__)

# Username validation: letters, numbers, underscores only; length 3-30
USERNAME_REGEX = re.compile(r"^[a-zA-Z0-9_]{3,30}$")
MIN_PASSWORD_LENGTH = 6


def login_required(view):
    """
    Decorator for views that require authentication.
    Redirects unauthenticated users to the login page.
    """
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if session.get("user_id") is None:
            flash("Please log in to access this page.", "warning")
            return redirect(url_for("auth.login"))
        return view(**kwargs)

    return wrapped_view


@auth_bp.before_app_request
def load_logged_in_user():
    """
    Runs before every request. If user_id is in session, loads user from database into g.user.
    """
    user_id = session.get("user_id")
    if user_id is None:
        g.user = None
    else:
        g.user = get_user_by_id(user_id)


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    """
    Handles user registration:
    1. Validates input (empty checks, length, regex, password match).
    2. Hashes password using Werkzeug's generate_password_hash().
    3. Saves record into SQLite with parameterized query.
    4. Redirects to login on success.
    """
    # If already logged in, redirect to chat
    if session.get("user_id"):
        return redirect(url_for("chat.chat_index"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        error = None

        # 1. Validation checks
        if not username:
            error = "Username is required."
        elif not USERNAME_REGEX.match(username):
            error = "Username must be 3-30 characters long and contain only letters, numbers, or underscores."
        elif not password:
            error = "Password is required."
        elif len(password) < MIN_PASSWORD_LENGTH:
            error = f"Password must be at least {MIN_PASSWORD_LENGTH} characters long."
        elif password != confirm_password:
            error = "Passwords do not match."
        elif get_user_by_username(username) is not None:
            error = f"Username '{username}' is already taken. Please choose another."

        if error is None:
            # 2. Hash password securely (PBKDF2-SHA256 with random salt)
            password_hash = generate_password_hash(password)

            # 3. Store in SQLite database
            user_id = create_user(username, password_hash)
            if user_id:
                flash("Registration successful! Please log in with your credentials.", "success")
                return redirect(url_for("auth.login"))
            else:
                error = "An error occurred while creating your account. Please try again."

        flash(error, "danger")

    return render_template("register.html")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    """
    Handles user login:
    1. Verifies credentials using check_password_hash().
    2. Uses generic error message to prevent username enumeration.
    3. Initializes secure Flask session.
    """
    if session.get("user_id"):
        return redirect(url_for("chat.chat_index"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        error = None
        user = get_user_by_username(username)

        # Generic message: Never disclose whether the username existed or password was wrong
        if user is None or not check_password_hash(user["password_hash"], password):
            error = "Invalid username or password. Please try again."

        if error is None:
            # Clear previous session data and regenerate
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            flash(f"Welcome back, {user['username']}!", "success")
            return redirect(url_for("chat.chat_index"))

        flash(error, "danger")

    return render_template("login.html")


@auth_bp.route("/logout")
def logout():
    """
    Logs out user by clearing the session and redirecting to the login page.
    """
    username = session.get("username")
    session.clear()
    flash(f"You have been successfully logged out.", "info")
    return redirect(url_for("auth.login"))
