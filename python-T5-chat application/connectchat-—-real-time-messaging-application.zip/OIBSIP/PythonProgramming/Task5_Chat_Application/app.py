"""
ConnectChat — Main Application Entry Point
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application

This file boots the Flask web application, configures Socket.IO,
loads environment variables, registers blueprints, and initializes SQLite.
"""

import os
from dotenv import load_dotenv
from flask import Flask

from auth import auth_bp
from chat import chat_bp, socketio
from database import init_db

# Load environment configuration from .env file if present
load_dotenv()


def create_app(test_config=None) -> Flask:
    """
    Application factory function.
    Prepares Flask, sets configurations, initializes database,
    and registers blueprints.
    """
    app = Flask(__name__, instance_relative_config=True)

    # Secret key for secure session cookies
    secret_key = os.environ.get("SECRET_KEY", "dev-secret-key-for-local-development-only")
    app.config.from_mapping(
        SECRET_KEY=secret_key,
        DATABASE_PATH=os.environ.get("DATABASE_PATH", "connectchat.db"),
    )

    if test_config:
        app.config.update(test_config)

    # Initialize SQLite database tables automatically on startup
    with app.app_context():
        init_db(app.config.get("DATABASE_PATH"))

    # Register modular Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(chat_bp)

    # Attach Flask-SocketIO to the app
    # async_mode='threading' is reliable and works out of the box without C compiler extensions
    socketio.init_app(app, cors_allowed_origins="*", async_mode="threading")

    return app


app = create_app()

if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "1") == "1"

    print("=" * 60)
    print(" ConnectChat — Real-Time Messaging Application")
    print(" OIBSIP Python Programming Internship — Task 5")
    print(f" Server running at: http://{host}:{port}")
    print("=" * 60)

    socketio.run(app, host=host, port=port, debug=debug)
