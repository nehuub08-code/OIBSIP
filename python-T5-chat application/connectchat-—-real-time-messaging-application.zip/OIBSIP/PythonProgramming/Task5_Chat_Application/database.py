"""
ConnectChat Database Layer (SQLite)
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application

This module handles all database operations using Python's built-in sqlite3.
Key principles:
1. Parameterized queries (? placeholders) to completely prevent SQL injection.
2. Safe transactions and connection management using context managers.
3. Foreign key constraints enabled via 'PRAGMA foreign_keys = ON'.
4. Automatic table schema initialization on first startup.
"""

import os
import sqlite3
from datetime import datetime
from typing import Any, Dict, List, Optional

# Default database filename (can be overridden via environment or testing)
DEFAULT_DB_PATH = os.environ.get("DATABASE_PATH", "connectchat.db")


def get_db_connection(db_path: Optional[str] = None) -> sqlite3.Connection:
    """
    Creates and returns a connection to the SQLite database.
    Enables foreign keys and sets row_factory to sqlite3.Row for dict-like column access.
    """
    path = db_path or os.environ.get("DATABASE_PATH", DEFAULT_DB_PATH)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db(db_path: Optional[str] = None) -> None:
    """
    Initializes database tables if they do not already exist.
    Also seeds standard default rooms ('general', 'random', 'tech-talk').
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    # 1. Users Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)

    # 2. Rooms Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS rooms (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL COLLATE NOCASE,
            created_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL
        );
    """)

    # 3. Messages Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            room_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            message_text TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (room_id) REFERENCES rooms (id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        );
    """)

    conn.commit()

    # Seed default rooms if none exist
    default_rooms = ["general", "python-dev", "oibsip-interns", "random"]
    for r_name in default_rooms:
        try:
            cursor.execute(
                "INSERT OR IGNORE INTO rooms (name, created_by) VALUES (?, NULL);",
                (r_name,)
            )
        except sqlite3.Error:
            pass

    conn.commit()
    conn.close()


# ============================================================================
# USER OPERATIONS
# ============================================================================

def create_user(username: str, password_hash: str, db_path: Optional[str] = None) -> Optional[int]:
    """
    Inserts a new user record.
    Returns the newly created user ID, or None if the username already exists.
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO users (username, password_hash) VALUES (?, ?);",
            (username.strip(), password_hash)
        )
        conn.commit()
        user_id = cursor.lastrowid
        return user_id
    except sqlite3.IntegrityError:
        # Duplicate username or constraint violation
        return None
    finally:
        conn.close()


def get_user_by_username(username: str, db_path: Optional[str] = None) -> Optional[sqlite3.Row]:
    """
    Fetches a user row by case-insensitive username.
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, username, password_hash, created_at FROM users WHERE username = ? COLLATE NOCASE;",
        (username.strip(),)
    )
    user = cursor.fetchone()
    conn.close()
    return user


def get_user_by_id(user_id: int, db_path: Optional[str] = None) -> Optional[sqlite3.Row]:
    """
    Fetches a user row by their numeric ID.
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, username, created_at FROM users WHERE id = ?;",
        (user_id,)
    )
    user = cursor.fetchone()
    conn.close()
    return user


# ============================================================================
# ROOM OPERATIONS
# ============================================================================

def get_all_rooms(db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Retrieves all available chat rooms ordered alphabetically by name.
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT r.id, r.name, r.created_at, u.username as creator_name,
               (SELECT COUNT(*) FROM messages m WHERE m.room_id = r.id) as message_count
        FROM rooms r
        LEFT JOIN users u ON r.created_by = u.id
        ORDER BY r.name ASC;
    """)
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_room_by_name(name: str, db_path: Optional[str] = None) -> Optional[sqlite3.Row]:
    """
    Finds a room by its case-insensitive name.
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, name, created_by, created_at FROM rooms WHERE name = ? COLLATE NOCASE;",
        (name.strip().lower(),)
    )
    room = cursor.fetchone()
    conn.close()
    return room


def create_room(name: str, created_by: Optional[int] = None, db_path: Optional[str] = None) -> Optional[int]:
    """
    Creates a new room. Name is normalized to lower case.
    Returns the new room ID, or None if the room already exists.
    """
    normalized_name = name.strip().lower()
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO rooms (name, created_by) VALUES (?, ?);",
            (normalized_name, created_by)
        )
        conn.commit()
        return cursor.lastrowid
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()


# ============================================================================
# MESSAGE OPERATIONS
# ============================================================================

def save_message(room_id: int, user_id: int, message_text: str, db_path: Optional[str] = None) -> Optional[int]:
    """
    Saves a chat message into the database.
    Returns the generated message ID.
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO messages (room_id, user_id, message_text) VALUES (?, ?, ?);",
            (room_id, user_id, message_text)
        )
        conn.commit()
        return cursor.lastrowid
    except sqlite3.Error as e:
        print(f"Database error while saving message: {e}")
        return None
    finally:
        conn.close()


def get_recent_messages(room_id: int, limit: int = 50, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Loads the most recent messages for a room up to the specified limit,
    returning them in chronological order (oldest to newest).
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT m.id, m.room_id, m.message_text, m.created_at,
               u.username as sender, u.id as user_id
        FROM (
            SELECT id, room_id, user_id, message_text, created_at
            FROM messages
            WHERE room_id = ?
            ORDER BY id DESC
            LIMIT ?
        ) m
        JOIN users u ON m.user_id = u.id
        ORDER BY m.id ASC;
    """, (room_id, limit))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]
