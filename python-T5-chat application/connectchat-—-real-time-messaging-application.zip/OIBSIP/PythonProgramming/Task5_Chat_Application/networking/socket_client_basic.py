"""
Phase 1 & 2: Networking Foundation — Low-Level Socket Client
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application

This client script connects to the raw socket server:
1. Connects to 127.0.0.1:9000.
2. Prompts user for their username and sends it.
3. Launches a background receiver thread to listen for messages from other clients.
4. Main thread reads user input and transmits it over the socket.
"""

import socket
import sys
import threading

HOST = "127.0.0.1"
PORT = 9000


def receive_messages(sock):
    """Continuously listens for incoming data from the server."""
    while True:
        try:
            data = sock.recv(2048)
            if not data:
                print("\n[SERVER] Disconnected from server.")
                break
            # Print incoming server message
            sys.stdout.write(data.decode("utf-8"))
            sys.stdout.flush()
        except Exception:
            break


def start_client():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect((HOST, PORT))
    except ConnectionRefusedError:
        print(f"Could not connect to server at {HOST}:{PORT}. Please run socket_server_basic.py first.")
        return

    username = input("Enter your username: ").strip() or "Anonymous"
    sock.sendall(username.encode("utf-8"))

    # Spawn thread to listen for incoming messages while user is typing
    receiver_thread = threading.Thread(target=receive_messages, args=(sock,), daemon=True)
    receiver_thread.start()

    print(f"Connected! Type your messages below. (Type /quit to exit)")
    try:
        while True:
            msg = input()
            if not msg.strip():
                continue
            sock.sendall(msg.encode("utf-8"))
            if msg.strip().lower() == "/quit":
                break
    except KeyboardInterrupt:
        pass
    finally:
        sock.close()
        print("\nSession ended.")


if __name__ == "__main__":
    start_client()
