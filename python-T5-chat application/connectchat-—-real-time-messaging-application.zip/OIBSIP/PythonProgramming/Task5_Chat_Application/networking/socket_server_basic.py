"""
Phase 1 & 2: Networking Foundation — Low-Level Socket Server
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application

This beginner-friendly script demonstrates fundamental socket networking
using Python's built-in 'socket' and 'threading' libraries (no external packages needed).

What happens step-by-step:
1. socket.socket(): Creates a TCP stream socket (IPv4 + TCP).
2. bind(): Associates the socket with an IP (127.0.0.1) and Port (9000).
3. listen(): Puts the server into passive listening mode waiting for clients.
4. accept(): Blocks until a client connects, returning a new client socket.
5. threading.Thread(): Spawns a background worker so multiple clients can chat concurrently.
"""

import socket
import threading
from datetime import datetime

HOST = "127.0.0.1"
PORT = 9000

# Thread-safe list of active client sockets and their usernames
connected_clients = {}
clients_lock = threading.Lock()


def broadcast(message: str, sender_socket=None):
    """Broadcasts a text message to all connected clients except sender."""
    with clients_lock:
        for client_sock in list(connected_clients.keys()):
            if client_sock != sender_socket:
                try:
                    client_sock.sendall(message.encode("utf-8"))
                except Exception:
                    # Client connection lost, remove
                    client_sock.close()
                    del connected_clients[client_sock]


def handle_client(client_socket, address):
    """Runs in a separate thread for each connected client."""
    print(f"[NEW CONNECTION] Connected from {address}")
    try:
        # First message received is the client's chosen username
        username = client_socket.recv(1024).decode("utf-8").strip()
        if not username:
            username = f"User-{address[1]}"

        with clients_lock:
            connected_clients[client_socket] = username

        welcome_msg = f"[SERVER] Welcome {username}! Type your message and hit Enter.\n"
        client_socket.sendall(welcome_msg.encode("utf-8"))

        # Announce joining
        ts = datetime.now().strftime("%H:%M")
        join_msg = f"[{ts}] *** {username} joined the chat ***\n"
        broadcast(join_msg, sender_socket=client_socket)

        # Main message loop
        while True:
            data = client_socket.recv(2048)
            if not data:
                # Socket closed by client
                break

            msg_text = data.decode("utf-8").strip()
            if not msg_text:
                continue

            if msg_text.lower() == "/quit":
                break

            ts = datetime.now().strftime("%H:%M")
            formatted = f"[{ts}] {username}: {msg_text}\n"
            print(formatted.strip())

            # Send back to all other clients
            broadcast(formatted, sender_socket=client_socket)

            # Echo back to sender for confirmation
            client_socket.sendall(f"[{ts}] You: {msg_text}\n".encode("utf-8"))

    except ConnectionResetError:
        print(f"[DISCONNECT] Connection abruptly lost for {address}")
    finally:
        with clients_lock:
            username = connected_clients.pop(client_socket, f"Client {address}")
        client_socket.close()

        ts = datetime.now().strftime("%H:%M")
        leave_msg = f"[{ts}] *** {username} left the chat ***\n"
        broadcast(leave_msg)
        print(f"[DISCONNECTED] {username} disconnected.")


def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # Allow instant port re-use after stopping
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    server.bind((HOST, PORT))
    server.listen(5)
    print("=" * 60)
    print(f" ConnectChat Foundation Server listening on {HOST}:{PORT}")
    print(" Press Ctrl+C to stop.")
    print("=" * 60)

    try:
        while True:
            client_socket, address = server.accept()
            # Handle client concurrently in a new thread
            thread = threading.Thread(target=handle_client, args=(client_socket, address), daemon=True)
            thread.start()
    except KeyboardInterrupt:
        print("\n[SHUTDOWN] Server stopping.")
    finally:
        server.close()


if __name__ == "__main__":
    start_server()
