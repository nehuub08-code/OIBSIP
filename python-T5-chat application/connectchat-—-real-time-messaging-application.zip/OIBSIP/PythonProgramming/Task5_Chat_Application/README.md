# ConnectChat — Real-Time Messaging Application

**OIBSIP Python Programming Internship — Task 5**  
**Student Track:** Python Programming  
**Author:** Second-Year Computer Engineering Student  
**Project Folder:** `OIBSIP/PythonProgramming/Task5_Chat_Application/`  
**License:** Open Educational License for OIBSIP Submission  

---

## 1. Project Overview

**ConnectChat** is a full-featured, secure, and beginner-friendly real-time chat application built with **Python**, **Flask**, **Flask-SocketIO**, and an **SQLite** relational database. 

It demonstrates foundational and advanced computer networking concepts—bridging the gap between raw TCP socket programming and modern event-driven WebSockets. The application allows registered users to join isolated chat rooms, communicate bidirectionally with sub-second latency, convert emoji shortcodes on the fly, view persistent message history, and receive in-app notifications for messages arriving in inactive rooms.

---

## 2. Core Features Checklist

| # | Feature | Status | Description |
|---|---|:---:|---|
| 1 | **User Registration** | ✅ Complete | Validates username syntax (3-30 chars, alphanumeric/underscore), password length ($\ge 6$), checks match. |
| 2 | **User Authentication & Sessions** | ✅ Complete | Werkzeug password hashing, secure Flask session cookies, login/logout, route protection. |
| 3 | **Real-Time Bidirectional Messaging** | ✅ Complete | Instant push delivery over WebSockets with zero page refresh required. |
| 4 | **Multiple Named Chat Rooms** | ✅ Complete | Users can browse, create, join, and switch between named rooms (`general`, `python-dev`, etc.). |
| 5 | **Room Isolation** | ✅ Complete | Messages sent in Room A are delivered **only** to subscribers of Room A; no cross-room leakage. |
| 6 | **Server-Generated Timestamps** | ✅ Complete | Every message stamped with UTC server time (`[HH:MM]`), never trusting client time. |
| 7 | **SQLite Message History** | ✅ Complete | Chronological history (up to 50 recent messages) loads automatically when entering any room. |
| 8 | **Graceful Disconnection Handling** | ✅ Complete | Handles browser closures and network drops; notifies room members with clean system events. |
| 9 | **Emoji Shortcode Conversion** | ✅ Complete | Transforms `:smile:`, `:heart:`, `:thumbsup:`, `:fire:`, `:rocket:`, etc. to native Unicode emojis. |
| 10 | **In-App Unread Notifications** | ✅ Complete | Unread badge counters on inactive rooms and top notification banners when messages arrive. |
| 11 | **XSS & Injection Protection** | ✅ Complete | Parameterized SQL queries + DOM `textContent` rendering prevent SQLi and Cross-Site Scripting. |
| 12 | **Security & Privacy Transparency** | ✅ Complete | Transparent documentation of encryption boundaries, plaintext database storage, and HTTPS needs. |
| 13 | **Automated Test Suite** | ✅ Complete | 17 comprehensive unit tests verifying auth, database queries, room isolation, and socket events. |

---

## 3. Technology Stack

- **Backend Framework:** Python 3.10+ & Flask 3.0+
- **Real-Time Engine:** Flask-SocketIO (with `threading` or `gevent` async mode)
- **Database:** SQLite 3 (built-in Python `sqlite3` module with foreign keys enabled)
- **Security & Hashing:** Werkzeug `generate_password_hash` & `check_password_hash` (PBKDF2-SHA256)
- **Frontend Architecture:** Semantic HTML5, Modular CSS3, Modern JavaScript (Fetch API & Socket.IO Client v4)
- **Testing:** Python `unittest` framework with isolated temporary databases

---

## 4. Project Directory Structure

```text
OIBSIP/PythonProgramming/Task5_Chat_Application/
├── app.py                      # Application bootstrap, Flask factory & Socket.IO initialization
├── auth.py                     # Authentication routes, password validation, session helpers
├── chat.py                     # Socket.IO event handlers, room routing, emoji parser
├── database.py                 # SQLite connection manager, schema bootstrap & queries
├── requirements.txt            # Python package dependencies
├── .env.example                # Template for environment secret keys and port configs
├── .gitignore                  # Prevents accidental commits of secrets and .db files
├── README.md                   # Comprehensive technical documentation & student guide
├── templates/
│   ├── base.html               # Master layout with top navigation and flash messages
│   ├── login.html              # Clean sign-in form with generic credential feedback
│   ├── register.html           # Account registration form with client/server validation
│   └── chat.html               # Real-time chat workspace, sidebar, message feed & emoji chips
├── static/
│   ├── css/style.css           # Responsive design system, dark slate aesthetic & bubble styles
│   └── js/chat.js              # Safe textContent DOM renderer, Socket.IO listeners & unread badges
├── tests/
│   ├── __init__.py             # Test package marker
│   ├── test_auth.py            # Automated tests 1-6 (registration, hashing, login, access control)
│   └── test_chat.py            # Automated tests 7-17 (rooms, isolation, emojis, sockets, XSS)
└── networking/
    ├── socket_server_basic.py  # Phase 1: Pure Python low-level TCP socket server (threading)
    └── socket_client_basic.py  # Phase 1: Pure Python low-level TCP socket terminal client
```

---

## 5. How Real-Time Messaging Works: Under the Hood

### Traditional HTTP vs. WebSockets (Socket.IO)

1. **Traditional HTTP (Request-Response):**
   In regular web browsing, the client (browser) must initiate every conversation:
   $$\text{Browser} \xrightarrow{\quad\text{GET /messages}\quad} \text{Server} \xrightarrow{\quad\text{Response JSON}\quad} \text{Browser}$$
   The server cannot proactively push data to the browser. Chat applications using old polling had to query the server every 1-2 seconds, creating massive server load and noticeable lag.

2. **WebSockets (Full-Duplex Persistent Channel):**
   Socket.IO starts with an HTTP handshake, then immediately upgrades the connection to a **persistent, bidirectional TCP socket**:
   $$\text{Browser} \xleftrightarrow[\quad\text{Full-Duplex Real-Time Stream}\quad]{\quad\text{Single TCP Connection}\quad} \text{Server}$$
   Both client and server can emit events to each other at any moment with sub-10 millisecond latency.

### Socket.IO Event Flow Matrix

```text
 Client (Browser)                                    Server (Flask-SocketIO)
      │                                                         │
      │ ──── 1. connect (WebSocket Handshake + Session Cookie)─>│ (Authenticates user from session)
      │ <─── 2. connected (ack) ────────────────────────────────│
      │                                                         │
      │ ──── 3. join_room {"room": "general"} ─────────────────>│ (Adds SID to room channel)
      │ <─── 4. room_joined {"history": [50 msgs]} ─────────────│ (Queries SQLite chronologically)
      │                                                         │
      │ ──── 5. send_message {"room": "general", "message"} ───>│ (Validates, converts emojis,
      │                                                         │  saves to SQLite, generates UTC ts)
      │ <─── 6. receive_message (Broadcast to room members) ────│
      │                                                         │
      │ ──── 7. disconnect (Window closed / tab exited) ───────>│ (Leaves room, alerts other users)
```

---

## 6. Database Schema Design (SQLite)

The application uses three relational tables with foreign keys and strict constraints:

### `users` Table
| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | Unique user identifier |
| `username` | `TEXT` | `UNIQUE NOT NULL COLLATE NOCASE` | Case-insensitive username |
| `password_hash` | `TEXT` | `NOT NULL` | Werkzeug salted PBKDF2-SHA256 hash |
| `created_at` | `TIMESTAMP` | `DEFAULT CURRENT_TIMESTAMP` | Account creation timestamp |

### `rooms` Table
| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | Unique room identifier |
| `name` | `TEXT` | `UNIQUE NOT NULL COLLATE NOCASE` | Unique room channel name |
| `created_by` | `INTEGER` | `REFERENCES users(id) ON DELETE SET NULL` | Creator user ID |
| `created_at` | `TIMESTAMP` | `DEFAULT CURRENT_TIMESTAMP` | Room creation timestamp |

### `messages` Table
| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `INTEGER` | `PRIMARY KEY AUTOINCREMENT` | Unique message identifier |
| `room_id` | `INTEGER` | `REFERENCES rooms(id) ON DELETE CASCADE` | Associated chat room |
| `user_id` | `INTEGER` | `REFERENCES users(id) ON DELETE CASCADE` | Author user ID |
| `message_text` | `TEXT` | `NOT NULL` | Stored message content |
| `created_at` | `TIMESTAMP` | `DEFAULT CURRENT_TIMESTAMP` | Server insertion timestamp |

---

## 7. Security, Passwords & Encryption Limitations

As an engineering intern, it is vital to be transparent about what security guarantees exist and what limitations remain:

### What IS Implemented:
1. **Password Hashing:** Passwords are never stored in plaintext. They are hashed with a unique cryptographic salt using Werkzeug (`generate_password_hash`). Even if someone steals the database file, they cannot reverse the hashes into plaintext passwords.
2. **SQL Injection Defense:** All SQLite queries use parameterized placeholders (`?`). User inputs are passed as separate data parameters, never concatenated directly into SQL strings.
3. **Cross-Site Scripting (XSS) Prevention:**
   - In HTML templates, Jinja2 auto-escapes all variables by default.
   - In JavaScript (`chat.js`), incoming messages are inserted into the DOM strictly via `element.textContent = text`, NOT `innerHTML`. A payload like `<script>alert('xss')</script>` is safely displayed as literal characters and never executed.
4. **Credential Enumeration Protection:** The login endpoint returns a generic message (`"Invalid username or password"`) so attackers cannot determine whether an account exists.
5. **Session Verification on Sockets:** Unauthenticated clients cannot emit or receive chat messages.

### What is NOT Implemented (Important Limitations):
1. **No End-to-End Encryption (E2EE):**
   - ConnectChat is **not** end-to-end encrypted like Signal or WhatsApp.
   - Messages are stored in plaintext inside the server's `connectchat.db` SQLite database.
   - The server administrator or anyone with filesystem access can view the stored conversation history.
2. **Local Development Transport Security:**
   - On `http://127.0.0.1:5000`, communication travels over unencrypted HTTP and WS. In a production cloud deployment, reverse proxies (like Nginx or Cloudflare) with **HTTPS** and **WSS** (Secure WebSockets) are required to protect data in transit across the public internet.
3. **Public Room Model:**
   - Any registered user can join any existing room. Private invitation-only rooms or direct 1-on-1 private messaging require future role-based authorization tables.

---

## 8. Installation & Setup Instructions

Follow these exact steps to run ConnectChat locally on your computer:

### Step 1: Clone or Navigate to the Directory
```bash
cd OIBSIP/PythonProgramming/Task5_Chat_Application/
```

### Step 2: Create a Python Virtual Environment
Creating an isolated environment keeps project packages separate from your global system:

- **macOS / Linux:**
  ```bash
  python3 -m venv .venv
  source .venv/bin/activate
  ```

- **Windows (Command Prompt):**
  ```cmd
  python -m venv .venv
  .venv\Scripts\activate.bat
  ```

- **Windows (PowerShell):**
  ```powershell
  python -m venv .venv
  .venv\Scripts\Activate.ps1
  ```

### Step 3: Install Required Dependencies
```bash
python -m pip install -r requirements.txt
```

### Step 4: Configure Local Environment
Copy the example environment file and customize your secret key:
```bash
cp .env.example .env
```
*(On Windows: `copy .env.example .env`)*

You can generate a cryptographically strong secret key using Python:
```bash
python -c "import secrets; print(secrets.token_hex(32))"
```
Paste this token as `SECRET_KEY` inside your `.env` file.

### Step 5: Start the Application
```bash
python app.py
```

The terminal will display:
```text
============================================================
 ConnectChat — Real-Time Messaging Application
 OIBSIP Python Programming Internship — Task 5
 Server running at: http://127.0.0.1:5000
============================================================
```

---

## 9. How to Test Real-Time Messaging with Two Browser Windows

To verify multi-user real-time communication:

1. Open **Browser Window 1** (e.g. Chrome) to `http://127.0.0.1:5000`.
   - Click **Register** and create user **Alice** (password: `Password123`).
   - Log in as **Alice**.
   - Select room `#general`.

2. Open **Browser Window 2** (e.g. Chrome Incognito or Firefox) to `http://127.0.0.1:5000`.
   - Click **Register** and create user **Bob** (password: `Password123`).
   - Log in as **Bob**.
   - Select room `#general`.

3. **Send Messages in Real-Time:**
   - In Alice's window, type: `Hello Bob! :wave: :rocket:` and click **Send**.
   - Watch Bob's window: the message appears instantly with the converted emoji, sender name `Alice`, and server timestamp `[HH:MM]`.
   - In Bob's window, type: `Hi Alice! Great to connect :fire: :thumbsup:` and click **Send**.
   - Both windows receive the updates without refreshing!

4. **Test Room Isolation & In-App Notifications:**
   - In Bob's window, switch to `#python-dev`.
   - In Alice's window, stay in `#general` and send a message.
   - Observe Bob's window: the message does **not** leak into `#python-dev`. Instead, an unread badge indicator appears beside `#general` in the sidebar, and a notification banner appears at the top!
   - When Bob clicks on `#general`, the unread counter automatically resets.

---

## 10. Running the Automated Tests

ConnectChat includes 17 automated tests verifying every aspect of authentication, database consistency, room isolation, and socket events.

Run all tests with detailed verbosity:
```bash
python -m unittest discover -s tests -v
```

Expected output:
```text
test_01_successful_registration (test_auth.AuthTestCase) ... ok
test_02_duplicate_username_rejection (test_auth.AuthTestCase) ... ok
test_03_password_hashing_not_plaintext (test_auth.AuthTestCase) ... ok
test_04_successful_login (test_auth.AuthTestCase) ... ok
test_05_incorrect_login_rejection (test_auth.AuthTestCase) ... ok
test_06_unauthenticated_access_restrictions (test_auth.AuthTestCase) ... ok
test_07_room_creation (test_chat.ChatTestCase) ... ok
test_08_duplicate_room_rejection (test_chat.ChatTestCase) ... ok
test_09_join_valid_and_invalid_rooms (test_chat.ChatTestCase) ... ok
test_10_message_persistence (test_chat.ChatTestCase) ... ok
test_11_room_specific_message_isolation (test_chat.ChatTestCase) ... ok
test_12_empty_message_rejection (test_chat.ChatTestCase) ... ok
test_13_maximum_message_length_validation (test_chat.ChatTestCase) ... ok
test_14_emoji_shortcode_conversion (test_chat.ChatTestCase) ... ok
test_15_socketio_session_flow (test_chat.ChatTestCase) ... ok
test_16_graceful_disconnect_handling (test_chat.ChatTestCase) ... ok
test_17_safe_handling_of_malicious_xss_payload (test_chat.ChatTestCase) ... ok

----------------------------------------------------------------------
Ran 17 tests in 0.421s

OK
```

---

## 11. Internship Demonstration Script (For Evaluator Review)

When presenting ConnectChat to your internship mentor or evaluator, follow this 3-minute demonstration script:

1. **Architecture Introduction (30 seconds):**
   *"Good morning/afternoon. For Task 5, I built ConnectChat using Python, Flask-SocketIO, and SQLite. In Phase 1, I built a pure TCP socket client/server using Python's standard library to understand socket handshakes and concurrency. In Phase 2, I migrated to Flask-SocketIO to provide an event-driven web architecture."*

2. **Security & Authentication Walkthrough (45 seconds):**
   *"Show the registration page. Register a user 'alice'. Highlight that Werkzeug salted password hashing prevents plaintext storage, and demonstrate that entering an incorrect password gives a generic error to prevent username enumeration."*

3. **Live Dual-Window Real-Time Chat (60 seconds):**
   *"Place two browser windows side by side (Alice and Bob). Send messages back and forth. Point out that messages appear with zero page refresh, showing server-generated UTC timestamps and automatic emoji conversion (:fire: -> 🔥)."*

4. **Room Isolation & Unread Badges (30 seconds):**
   *"Create a new room called #project-review. Move Bob into #project-review while Alice remains in #general. Send a message from Alice. Demonstrate that Bob's chat feed remains completely isolated, and show the unread message badge incrementing in Bob's sidebar."*

5. **Transparency & Conclusion (15 seconds):**
   *"Conclude by explaining that messages are stored in SQLite with parameterized queries, that XSS is prevented by DOM textContent rendering, and explain that production deployment would add HTTPS/WSS encryption."*

---

## 12. Known Limitations & Future Roadmap

- **Direct Messaging (DMs):** Currently supports public chat rooms; 1-on-1 private messaging channels can be added with an additional participant relationship table.
- **Media Uploads:** Currently supports text and emoji shortcodes; file and image attachment handling via S3/Blob storage can be added in a future update.
- **Typing Indicators:** Real-time `"Alice is typing..."` broadcasts can be added using a lightweight 2-second debounce timer on `input` events.
