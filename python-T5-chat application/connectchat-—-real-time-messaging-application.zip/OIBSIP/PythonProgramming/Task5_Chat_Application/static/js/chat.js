/**
 * ConnectChat Client Real-Time Controller
 * Author: OIBSIP Python Programming Intern
 * Task: Task 5 — Real-Time Chat Application
 *
 * Core functionalities:
 * 1. Socket.IO connection lifecycle management.
 * 2. Room switching, history rendering, and room creation.
 * 3. Safe message rendering using textContent (Strict XSS protection).
 * 4. Background message notifications (unread badge & banner).
 * 5. Emoji shortcode quick-insert chips.
 */

document.addEventListener("DOMContentLoaded", () => {
    // Current authenticated user provided from session via chat.html
    const currentUser = window.CURRENT_USER || { username: "", userId: null };

    // Active room state
    let activeRoom = null;
    const unreadCounts = {};

    // DOM Elements
    const socketStatusDot = document.getElementById("connection-dot");
    const socketStatusLabel = document.getElementById("connection-text");
    const roomsList = document.getElementById("rooms-list");
    const currentRoomTitle = document.getElementById("current-room-title");
    const messagesContainer = document.getElementById("messages-container");
    const messageForm = document.getElementById("message-form");
    const messageInput = document.getElementById("message-input");
    const sendButton = document.getElementById("send-button");
    const charCounter = document.getElementById("char-counter");
    const emptyState = document.getElementById("empty-state");

    // Room creation elements
    const toggleCreateRoomBtn = document.getElementById("toggle-create-room-btn");
    const createRoomPanel = document.getElementById("create-room-panel");
    const createRoomForm = document.getElementById("create-room-form");
    const newRoomInput = document.getElementById("new-room-input");
    const cancelCreateRoomBtn = document.getElementById("cancel-create-room-btn");

    // Unread notification banner
    const unreadBanner = document.getElementById("unread-banner");
    const unreadBannerText = document.getElementById("unread-banner-text");
    const unreadBannerJump = document.getElementById("unread-banner-jump");
    const unreadBannerClose = document.getElementById("unread-banner-close");
    let unreadTargetRoom = null;

    // =========================================================================
    // 1. SOCKET.IO CONNECTION
    // =========================================================================
    const socket = io({
        reconnection: true,
        reconnectionAttempts: 10,
        reconnectionDelay: 1000,
    });

    socket.on("connect", () => {
        socketStatusDot.className = "status-dot connected";
        socketStatusLabel.textContent = "Connected (Real-time)";
        console.log("[ConnectChat] Socket connected:", socket.id);

        // If user already had a selected room before reconnect, re-join it
        if (activeRoom) {
            socket.emit("join_room", { room: activeRoom });
        }
    });

    socket.on("disconnect", () => {
        socketStatusDot.className = "status-dot disconnected";
        socketStatusLabel.textContent = "Disconnected (Reconnecting...)";
        messageInput.disabled = true;
        sendButton.disabled = true;
    });

    socket.on("connect_error", (err) => {
        socketStatusDot.className = "status-dot disconnected";
        socketStatusLabel.textContent = "Connection failed";
        console.error("[ConnectChat] Connect error:", err);
    });

    // =========================================================================
    // 2. ROOM SWITCHING & CREATION
    // =========================================================================
    function switchRoom(roomName) {
        if (!roomName || roomName === activeRoom) return;

        // Leave previous room if joined
        if (activeRoom) {
            socket.emit("leave_room", { room: activeRoom });
        }

        activeRoom = roomName;

        // Update active UI state on sidebar
        document.querySelectorAll(".room-item").forEach(item => {
            if (item.dataset.room === roomName) {
                item.classList.add("active");
                // Clear unread count for this room
                clearUnreadForRoom(roomName);
            } else {
                item.classList.remove("active");
            }
        });

        // Update room header
        currentRoomTitle.textContent = roomName;
        messageInput.disabled = false;
        sendButton.disabled = false;
        messageInput.placeholder = `Message #${roomName}...`;
        messageInput.focus();

        // Clear messages container while loading history
        messagesContainer.innerHTML = '<div class="empty-chat-state"><p>Loading room messages...</p></div>';

        // Emit join_room to server
        socket.emit("join_room", { room: roomName });
    }

    function clearUnreadForRoom(roomName) {
        unreadCounts[roomName] = 0;
        const badge = document.querySelector(`.room-item[data-room="${roomName}"] .unread-badge`);
        if (badge) {
            badge.textContent = "0";
            badge.classList.add("hidden");
        }
        if (unreadTargetRoom === roomName) {
            unreadBanner.classList.add("hidden");
        }
    }

    function incrementUnreadForRoom(roomName, sender) {
        unreadCounts[roomName] = (unreadCounts[roomName] || 0) + 1;
        const badge = document.querySelector(`.room-item[data-room="${roomName}"] .unread-badge`);
        if (badge) {
            badge.textContent = unreadCounts[roomName];
            badge.classList.remove("hidden");
        }

        // Show top notification banner
        unreadTargetRoom = roomName;
        unreadBannerText.textContent = `New message in #${roomName} from ${sender}`;
        unreadBanner.classList.remove("hidden");
    }

    // Bind existing room buttons
    roomsList.addEventListener("click", (e) => {
        const roomBtn = e.target.closest(".room-item");
        if (roomBtn) {
            const roomName = roomBtn.dataset.room;
            switchRoom(roomName);
        }
    });

    // Toggle inline create room panel
    toggleCreateRoomBtn.addEventListener("click", () => {
        createRoomPanel.classList.toggle("hidden");
        if (!createRoomPanel.classList.contains("hidden")) {
            newRoomInput.focus();
        }
    });

    cancelCreateRoomBtn.addEventListener("click", () => {
        createRoomPanel.classList.add("hidden");
        newRoomInput.value = "";
    });

    // Handle Create Room submit
    createRoomForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const roomName = newRoomInput.value.trim().toLowerCase();
        if (!roomName) return;

        socket.emit("create_room", { room_name: roomName });
        createRoomPanel.classList.add("hidden");
        newRoomInput.value = "";
    });

    // When server broadcasts room_created
    socket.on("room_created", (data) => {
        // Check if room already exists in DOM
        if (document.querySelector(`.room-item[data-room="${data.name}"]`)) {
            return;
        }

        const li = document.createElement("li");
        li.className = "room-item";
        li.dataset.room = data.name;

        li.innerHTML = `
            <button class="room-button" type="button">
                <span class="room-symbol">#</span>
                <span class="room-name"></span>
                <span class="unread-badge hidden">0</span>
            </button>
        `;
        // Safe textContent assignment
        li.querySelector(".room-name").textContent = data.name;

        roomsList.appendChild(li);

        // If this client created it, automatically switch to it
        if (data.creator === currentUser.username) {
            switchRoom(data.name);
        }
    });

    // =========================================================================
    // 3. SAFE MESSAGE RENDERING (XSS-IMMUNE)
    // =========================================================================
    function appendMessage({ sender, text, timestamp, isSent }) {
        if (emptyState && emptyState.parentNode) {
            emptyState.remove();
        }

        const row = document.createElement("div");
        row.className = `message-row ${isSent ? "sent" : "received"}`;

        const meta = document.createElement("div");
        meta.className = "message-meta";

        const senderSpan = document.createElement("span");
        senderSpan.className = "message-sender";
        senderSpan.textContent = isSent ? "You" : sender;

        const timeSpan = document.createElement("span");
        timeSpan.className = "message-time";
        timeSpan.textContent = `[${timestamp}]`;

        meta.appendChild(senderSpan);
        meta.appendChild(timeSpan);

        const bubble = document.createElement("div");
        bubble.className = "message-bubble";
        // CRITICAL SECURITY RULE: textContent is safe from XSS injection
        bubble.textContent = text;

        row.appendChild(meta);
        row.appendChild(bubble);

        messagesContainer.appendChild(row);
        scrollToBottom();
    }

    function appendSystemMessage(text, timestamp) {
        const sys = document.createElement("div");
        sys.className = "message-system";
        sys.textContent = `[${timestamp}] ${text}`;
        messagesContainer.appendChild(sys);
        scrollToBottom();
    }

    function scrollToBottom() {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // =========================================================================
    // 4. REAL-TIME SOCKET EVENT RECEIVERS
    // =========================================================================
    // Room joined & message history received
    socket.on("room_joined", (data) => {
        messagesContainer.innerHTML = "";
        if (!data.history || data.history.length === 0) {
            messagesContainer.innerHTML = `
                <div class="empty-chat-state" id="empty-state">
                    <p>No messages yet in <strong>#${data.room}</strong>. Be the first to say hello!</p>
                </div>
            `;
            return;
        }

        data.history.forEach((msg) => {
            appendMessage({
                sender: msg.sender,
                text: msg.text,
                timestamp: msg.timestamp,
                isSent: msg.sender === currentUser.username,
            });
        });
        scrollToBottom();
    });

    // Inbound chat message
    socket.on("receive_message", (data) => {
        if (data.room === activeRoom) {
            appendMessage({
                sender: data.sender,
                text: data.text,
                timestamp: data.timestamp,
                isSent: data.sender === currentUser.username,
            });
        } else {
            // Message arrived for another room while user is elsewhere
            if (data.sender !== currentUser.username) {
                incrementUnreadForRoom(data.room, data.sender);
            }
        }
    });

    // User joined announcement
    socket.on("user_joined", (data) => {
        if (data.room === activeRoom) {
            appendSystemMessage(`${data.username} entered the room.`, data.timestamp);
        }
    });

    // User left announcement
    socket.on("user_left", (data) => {
        if (data.room === activeRoom) {
            appendSystemMessage(`${data.username} left the room.`, data.timestamp);
        }
    });

    // Server-side validation errors
    socket.on("error_message", (data) => {
        alert(data.error || "An error occurred with the chat server.");
    });

    // =========================================================================
    // 5. SENDING MESSAGES & EMOJI SHORTCODES
    // =========================================================================
    messageInput.addEventListener("input", () => {
        const len = messageInput.value.length;
        charCounter.textContent = `${len}/2000`;
        if (len > 2000) {
            charCounter.style.color = "var(--danger)";
            sendButton.disabled = true;
        } else {
            charCounter.style.color = "var(--text-muted)";
            sendButton.disabled = len === 0;
        }
    });

    messageForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const text = messageInput.value.trim();

        if (!text || !activeRoom) return;
        if (text.length > 2000) {
            alert("Message cannot exceed 2000 characters.");
            return;
        }

        // Emit message payload to server
        socket.emit("send_message", {
            room: activeRoom,
            message: text,
        });

        messageInput.value = "";
        charCounter.textContent = "0/2000";
        sendButton.disabled = true;
        messageInput.focus();
    });

    // Emoji shortcode quick chips
    document.querySelectorAll(".emoji-chip").forEach((chip) => {
        chip.addEventListener("click", () => {
            const code = chip.dataset.code;
            if (!code || messageInput.disabled) return;
            messageInput.value = messageInput.value ? `${messageInput.value} ${code} ` : `${code} `;
            messageInput.dispatchEvent(new Event("input"));
            messageInput.focus();
        });
    });

    // Unread banner click handler
    unreadBannerJump.addEventListener("click", () => {
        if (unreadTargetRoom) {
            switchRoom(unreadTargetRoom);
        }
    });

    unreadBannerClose.addEventListener("click", () => {
        unreadBanner.classList.add("hidden");
    });

    // Auto-select first room in list if available
    const firstRoom = document.querySelector(".room-item");
    if (firstRoom) {
        switchRoom(firstRoom.dataset.room);
    }
});
