"""
Automated Test Suite: User Authentication & Security
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application

Tests included:
1. Successful user registration.
2. Duplicate username rejection.
3. Password hashes stored instead of plaintext passwords.
4. Successful login.
5. Incorrect login rejection (generic error, no enumeration).
6. Unauthenticated access restrictions on protected routes.
"""

import os
import tempfile
import unittest
from werkzeug.security import check_password_hash

from app import create_app
from database import get_db_connection, get_user_by_username


class AuthTestCase(unittest.TestCase):
    def setUp(self):
        """Creates a temporary isolated SQLite database for each test."""
        self.db_fd, self.db_path = tempfile.mkstemp(suffix=".db")
        self.app = create_app({
            "TESTING": True,
            "DATABASE_PATH": self.db_path,
            "SECRET_KEY": "test-secret-key-12345",
        })
        self.client = self.app.test_client()

    def tearDown(self):
        """Closes and unlinks the temporary database."""
        os.close(self.db_fd)
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)

    def test_01_successful_registration(self):
        """Test 1: User can register with valid username and matching passwords."""
        response = self.client.post("/register", data={
            "username": "alice",
            "password": "Password123",
            "confirm_password": "Password123"
        }, follow_redirects=True)

        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Registration successful", response.data)

        # Verify user exists in database
        user = get_user_by_username("alice", db_path=self.db_path)
        self.assertIsNotNone(user)
        self.assertEqual(user["username"], "alice")

    def test_02_duplicate_username_rejection(self):
        """Test 2: System rejects registration with an existing username."""
        # First registration
        self.client.post("/register", data={
            "username": "bob",
            "password": "Password123",
            "confirm_password": "Password123"
        })

        # Duplicate registration attempt
        response = self.client.post("/register", data={
            "username": "bob",
            "password": "OtherPassword",
            "confirm_password": "OtherPassword"
        }, follow_redirects=True)

        self.assertIn(b"already taken", response.data)

    def test_03_password_hashing_not_plaintext(self):
        """Test 3: Plaintext password is NEVER stored in SQLite."""
        raw_password = "SuperSecretPassword123!"
        self.client.post("/register", data={
            "username": "charlie",
            "password": raw_password,
            "confirm_password": raw_password
        })

        user = get_user_by_username("charlie", db_path=self.db_path)
        self.assertIsNotNone(user)

        # Database must NOT contain the plaintext string
        self.assertNotEqual(user["password_hash"], raw_password)
        # Password hash must be verified with Werkzeug's check_password_hash
        self.assertTrue(check_password_hash(user["password_hash"], raw_password))
        self.assertTrue(user["password_hash"].startswith("pbkdf2:") or user["password_hash"].startswith("scrypt:"))

    def test_04_successful_login(self):
        """Test 4: User can log in with correct credentials and establish a session."""
        self.client.post("/register", data={
            "username": "david",
            "password": "Password123",
            "confirm_password": "Password123"
        })

        response = self.client.post("/login", data={
            "username": "david",
            "password": "Password123"
        }, follow_redirects=True)

        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Welcome back, david!", response.data)

        # Check session
        with self.client.session_transaction() as sess:
            self.assertEqual(sess.get("username"), "david")
            self.assertIsNotNone(sess.get("user_id"))

    def test_05_incorrect_login_rejection(self):
        """Test 5: System rejects incorrect password with generic error message."""
        self.client.post("/register", data={
            "username": "elena",
            "password": "CorrectPassword",
            "confirm_password": "CorrectPassword"
        })

        response = self.client.post("/login", data={
            "username": "elena",
            "password": "WrongPassword"
        }, follow_redirects=True)

        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Invalid username or password", response.data)

        # Session should not be authenticated
        with self.client.session_transaction() as sess:
            self.assertIsNone(sess.get("user_id"))

    def test_06_unauthenticated_access_restrictions(self):
        """Test 6: Protected /chat route redirects unauthenticated users to /login."""
        response = self.client.get("/chat", follow_redirects=False)
        self.assertEqual(response.status_code, 302)
        self.assertIn("/login", response.headers["Location"])


if __name__ == "__main__":
    unittest.main()
