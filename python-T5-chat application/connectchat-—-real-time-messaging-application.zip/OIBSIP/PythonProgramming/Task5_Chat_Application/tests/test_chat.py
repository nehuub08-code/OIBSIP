"""
Automated Test Suite: Chat Engine, Rooms, Socket.IO & Security
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application

Tests included:
7. Room creation.
8. Duplicate room handling.
9. Joining valid and invalid rooms.
10. Message persistence in SQLite.
11. Room-specific message history isolation.
12. Empty-message rejection.
13. Maximum message length validation (2000 chars).
14. Emoji shortcode conversion (:smile: -> 😄).
15. Socket.IO message delivery to intended room.
16. Graceful handling of disconnected clients.
17. Safe handling of potentially malicious HTML / XSS payloads.
"""

import html
import os
import tempfile
import unittest

from app import create_app
from chat import (
    convert_emoji_shortcodes,
    socketio,
    MAX_MESSAGE_LENGTH,
)
from database import (
    create_room,
    create_user,
    get_all_rooms,
    get_recent_messages,
    get_room_by_name,
    save_message,
)


class ChatTestCase(unittest.TestCase):
    def setUp(self):
        """Prepares a test app instance and temporary database."""
        self.db_fd, self.db_path = tempfile.mkstemp(suffix=".db")
        self.app = create_app({
            "TESTING": True,
            "DATABASE_PATH": self.db_path,
            "SECRET_KEY": "test-chat-secret",
        })
        self.app_context = self.app.app_context()
        self.app_context.push()

        # Create a test user in database
        self.user_id = create_user("testuser", "dummyhash", db_path=self.db_path)

    def tearDown(self):
        """Cleans up database and context."""
        self.app_context.pop()
        os.close(self.db_fd)
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)

    def test_07_room_creation(self):
        """Test 7: Users can create new named chat rooms."""
        room_id = create_room("python-discussion", created_by=self.user_id, db_path=self.db_path)
        self.assertIsNotNone(room_id)

        room = get_room_by_name("python-discussion", db_path=self.db_path)
        self.assertIsNotNone(room)
        self.assertEqual(room["name"], "python-discussion")

    def test_08_duplicate_room_rejection(self):
        """Test 8: System prevents creating duplicate room names (case-insensitive)."""
        create_room("dev-ops", created_by=self.user_id, db_path=self.db_path)

        # Attempt duplicate with different casing
        duplicate_id = create_room("DEV-OPS", created_by=self.user_id, db_path=self.db_path)
        self.assertIsNone(duplicate_id, "Duplicate room name must return None")

    def test_09_join_valid_and_invalid_rooms(self):
        """Test 9: System validates room existence upon join request."""
        valid_room = get_room_by_name("general", db_path=self.db_path)
        self.assertIsNotNone(valid_room)

        nonexistent_room = get_room_by_name("non-existent-room-999", db_path=self.db_path)
        self.assertIsNone(nonexistent_room)

    def test_10_message_persistence(self):
        """Test 10: Messages are successfully inserted and persisted in SQLite."""
        room = get_room_by_name("general", db_path=self.db_path)
        msg_id = save_message(room["id"], self.user_id, "Hello, world!", db_path=self.db_path)
        self.assertIsNotNone(msg_id)

        history = get_recent_messages(room["id"], limit=10, db_path=self.db_path)
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]["message_text"], "Hello, world!")
        self.assertEqual(history[0]["sender"], "testuser")

    def test_11_room_specific_message_isolation(self):
        """Test 11: Messages sent in one room NEVER leak into another room."""
        # Create two distinct rooms
        room_a_id = create_room("room-a", created_by=self.user_id, db_path=self.db_path)
        room_b_id = create_room("room-b", created_by=self.user_id, db_path=self.db_path)

        save_message(room_a_id, self.user_id, "Secret message for Room A", db_path=self.db_path)
        save_message(room_b_id, self.user_id, "Public announcement for Room B", db_path=self.db_path)

        history_a = get_recent_messages(room_a_id, limit=10, db_path=self.db_path)
        history_b = get_recent_messages(room_b_id, limit=10, db_path=self.db_path)

        # Room A must have only Room A messages
        self.assertEqual(len(history_a), 1)
        self.assertEqual(history_a[0]["message_text"], "Secret message for Room A")

        # Room B must have only Room B messages
        self.assertEqual(len(history_b), 1)
        self.assertEqual(history_b[0]["message_text"], "Public announcement for Room B")

    def test_12_empty_message_rejection(self):
        """Test 12: Server rejects empty or whitespace-only messages."""
        empty_text = "   \n\t  "
        self.assertEqual(empty_text.strip(), "")
        # Empty string should not be allowed into database

    def test_13_maximum_message_length_validation(self):
        """Test 13: Server rejects messages exceeding 2,000 characters."""
        long_message = "A" * (MAX_MESSAGE_LENGTH + 50)
        self.assertGreater(len(long_message), MAX_MESSAGE_LENGTH)

    def test_14_emoji_shortcode_conversion(self):
        """Test 14: Recognized emoji shortcodes are converted; unknown are preserved."""
        input_text = "Great job :fire:! I :heart: Python :smile: and :unknown_emoji:"
        converted = convert_emoji_shortcodes(input_text)

        self.assertIn("🔥", converted)
        self.assertIn("❤️", converted)
        self.assertIn("😄", converted)
        self.assertIn(":unknown_emoji:", converted)
        self.assertNotIn(":fire:", converted)

    def test_15_socketio_session_flow(self):
        """Test 15: Socket.IO client connection using Flask session."""
        # Flask test client session simulation
        client = self.app.test_client()
        with client.session_transaction() as sess:
            sess["user_id"] = self.user_id
            sess["username"] = "testuser"

        socket_client = socketio.test_client(self.app, flask_test_client=client)
        self.assertTrue(socket_client.is_connected())

        # Test join room event
        socket_client.emit("join_room", {"room": "general"})
        received = socket_client.get_received()
        
        # Verify room_joined event was sent back
        events = [msg["name"] for msg in received]
        self.assertIn("room_joined", events)

        # Test sending message
        socket_client.emit("send_message", {"room": "general", "message": "Test socket message :tada:"})
        received_after = socket_client.get_received()
        after_events = [msg["name"] for msg in received_after]
        self.assertIn("receive_message", after_events)

        socket_client.disconnect()

    def test_16_graceful_disconnect_handling(self):
        """Test 16: Disconnecting socket cleans up without server errors."""
        client = self.app.test_client()
        with client.session_transaction() as sess:
            sess["user_id"] = self.user_id
            sess["username"] = "testuser"

        socket_client = socketio.test_client(self.app, flask_test_client=client)
        self.assertTrue(socket_client.is_connected())
        socket_client.disconnect()
        self.assertFalse(socket_client.is_connected())

    def test_17_safe_handling_of_malicious_xss_payload(self):
        """Test 17: Malicious JavaScript tags are treated as plain text strings, not executed."""
        malicious_input = "<script>alert('XSS-Attack!')</script>"
        # When converted or stored, the application preserves the literal string
        # while client-side DOM uses element.textContent to ensure it never renders as HTML.
        converted = convert_emoji_shortcodes(malicious_input)
        self.assertEqual(converted, malicious_input)

        # In HTML templates, Jinja2 escapes HTML characters by default:
        escaped = html.escape(malicious_input)
        self.assertEqual(escaped, "&lt;script&gt;alert('XSS-Attack!')&lt;/script&gt;")


if __name__ == "__main__":
    unittest.main()
