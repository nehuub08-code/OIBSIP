"""
ConnectChat Real-Time Chat Engine & Socket.IO Event Handlers
Author: OIBSIP Python Programming Intern
Task: Task 5 — Real-Time Chat Application

This module handles:
1. Web routes for the chat dashboard.
2. Real-time bidirectional Socket.IO event processing.
3. Chat room isolation, membership tracking, and history replay.
4. Server-side validation (length, non-empty, authenticated session).
5. Server-generated UTC timestamps.
6. Emoji shortcode conversion (:smile: -> 😄).
7. Graceful connection and disconnection lifecycle management.
"""

import html
import re
from datetime import datetime, timezone
from typing import Dict, Optional, Set

from flask import (
    Blueprint,
    abort,
    jsonify,
    render_template,
    request,
    session,
)
from flask_socketio import SocketIO, disconnect, emit, join_room, leave_room

from auth import login_required
from database import (
    create_room,
    get_all_rooms,
    get_recent_messages,
    get_room_by_name,
    save_message,
)

# Blueprint for chat HTML endpoints
chat_bp = Blueprint("chat", __name__)

# SocketIO instance will be bound in app.py
socketio = SocketIO()

# In-memory session tracking for active connections:
# Mapping of socket sid -> { "user_id": int, "username": str, "rooms": set() }
active_connections: Dict[str, Dict] = {}

# Emoji shortcode dictionary mapping
EMOJI_MAP = {
    ":smile:": "😄",
    ":heart:": "❤️",
    ":thumbsup:": "👍",
    ":laughing:": "😆",
    ":fire:": "🔥",
    ":cry:": "😢",
    ":rocket:": "🚀",
    ":tada:": "🎉",
    ":wink:": "😉",
    ":star:": "⭐",
    ":clap:": "👏",
    ":100:": "💯",
    ":coffee:": "☕",
    ":eyes:": "👀",
    ":check:": "✅",
}

# Maximum message length constraint
MAX_MESSAGE_LENGTH = 2000
MAX_ROOM_NAME_LENGTH = 30
ROOM_NAME_REGEX = re.compile(r"^[a-zA-Z0-9_-]{2,30}$")


def convert_emoji_shortcodes(text: str) -> str:
    """
    Replaces recognized emoji shortcodes (:smile:, :heart:, etc.) with Unicode emojis.
    Unknown shortcodes are left intact.
    Does NOT interpret message text as HTML.
    """
    converted = text
    for code, emoji in EMOJI_MAP.items():
        converted = converted.replace(code, emoji)
    return converted


def get_server_timestamp() -> str:
    """
    Generates a standardized UTC server timestamp.
    Example: '14:35' for compact display and '2026-10-28 14:35:12 UTC' for metadata.
    """
    now = datetime.now(timezone.utc)
    return now.strftime("%H:%M")


def format_db_timestamp(ts_str: str) -> str:
    """
    Formats an SQLite timestamp string into a clean [HH:MM] format.
    """
    if not ts_str:
        return get_server_timestamp()
    try:
        dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
        return dt.strftime("%H:%M")
    except Exception:
        # Fallback to simple slice if already in string representation
        if len(ts_str) >= 16 and " " in ts_str:
            return ts_str.split(" ")[1][:5]
        return ts_str[:5]


# ============================================================================
# HTTP ROUTES
# ============================================================================

@chat_bp.route("/")
@chat_bp.route("/chat")
@login_required
def chat_index():
    """
    Renders the main ConnectChat dashboard.
    Only accessible to authenticated users.
    """
    rooms = get_all_rooms()
    return render_template(
        "chat.html",
        username=session.get("username"),
        user_id=session.get("user_id"),
        rooms=rooms,
        emoji_map=EMOJI_MAP,
    )


@chat_bp.route("/api/rooms", methods=["GET"])
@login_required
def api_get_rooms():
    """Returns JSON list of all available rooms."""
    return jsonify({"success": True, "rooms": get_all_rooms()})


@chat_bp.route("/api/rooms/<room_name>/history", methods=["GET"])
@login_required
def api_get_room_history(room_name: str):
    """
    Returns message history for a specific room up to 50 messages.
    """
    room = get_room_by_name(room_name)
    if not room:
        return jsonify({"success": False, "error": f"Room '{room_name}' not found."}), 404

    messages = get_recent_messages(room["id"], limit=50)
    formatted = [
        {
            "id": m["id"],
            "sender": m["sender"],
            "user_id": m["user_id"],
            "text": m["message_text"],
            "timestamp": format_db_timestamp(str(m["created_at"])),
        }
        for m in messages
    ]
    return jsonify({"success": True, "room": room["name"], "messages": formatted})


# ============================================================================
# SOCKET.IO EVENT HANDLERS
# ============================================================================

@socketio.on("connect")
def handle_connect():
    """
    Lifecycle event: client initiates WebSocket connection.
    Authenticates connection via existing Flask session.
    If unauthenticated, rejects connection immediately.
    """
    user_id = session.get("user_id")
    username = session.get("username")

    if not user_id or not username:
        # Reject unauthenticated socket connections
        return False

    sid = request.sid
    active_connections[sid] = {
        "user_id": user_id,
        "username": username,
        "rooms": set(),
    }
    print(f"[ConnectChat] User '{username}' connected on socket {sid}")
    emit("connected", {"message": "Connected to ConnectChat server.", "username": username})


@socketio.on("disconnect")
def handle_disconnect():
    """
    Lifecycle event: client disconnects (page close, network drop, tab closed).
    Leaves all joined rooms and broadcasts user_left notification.
    """
    sid = request.sid
    user_info = active_connections.pop(sid, None)

    if user_info:
        username = user_info["username"]
        joined_rooms = user_info["rooms"]
        ts = get_server_timestamp()

        for room_name in joined_rooms:
            emit(
                "user_left",
                {
                    "room": room_name,
                    "username": username,
                    "timestamp": ts,
                    "system": True,
                },
                to=room_name,
            )
        print(f"[ConnectChat] User '{username}' disconnected.")


@socketio.on("join_room")
def handle_join_room(data):
    """
    Event: user joins a specific room.
    Validates room existence, subscribes socket to the room,
    sends back the latest 50 messages, and broadcasts 'user_joined' to other members.
    """
    user_id = session.get("user_id")
    username = session.get("username")

    if not user_id or not username:
        emit("error_message", {"error": "Authentication required to join rooms."})
        disconnect()
        return

    room_name = (data.get("room") or "").strip().lower()
    if not room_name:
        emit("error_message", {"error": "Room name is required."})
        return

    room = get_room_by_name(room_name)
    if not room:
        emit("error_message", {"error": f"Room '{room_name}' does not exist."})
        return

    sid = request.sid
    # Join Socket.IO room channel
    join_room(room_name)

    # Track in active_connections
    if sid in active_connections:
        active_connections[sid]["rooms"].add(room_name)

    # Load recent 50 messages from SQLite
    history_rows = get_recent_messages(room["id"], limit=50)
    history = [
        {
            "id": row["id"],
            "sender": row["sender"],
            "user_id": row["user_id"],
            "text": row["message_text"],
            "timestamp": format_db_timestamp(str(row["created_at"])),
        }
        for row in history_rows
    ]

    # Emit message history only to the newly joined client
    emit(
        "room_joined",
        {
            "room": room_name,
            "room_id": room["id"],
            "history": history,
            "joined_by": username,
        },
    )

    # Broadcast notification to other users in this room
    ts = get_server_timestamp()
    emit(
        "user_joined",
        {
            "room": room_name,
            "username": username,
            "timestamp": ts,
            "system": True,
        },
        to=room_name,
        include_self=False,
    )


@socketio.on("leave_room")
def handle_leave_room(data):
    """
    Event: user explicitly leaves a room.
    Unsubscribes socket from room and notifies others.
    """
    username = session.get("username")
    room_name = (data.get("room") or "").strip().lower()

    if not room_name or not username:
        return

    sid = request.sid
    leave_room(room_name)

    if sid in active_connections:
        active_connections[sid]["rooms"].discard(room_name)

    ts = get_server_timestamp()
    emit(
        "user_left",
        {
            "room": room_name,
            "username": username,
            "timestamp": ts,
            "system": True,
        },
        to=room_name,
        include_self=False,
    )


@socketio.on("send_message")
def handle_send_message(data):
    """
    Event: user transmits a message to a room.
    1. Enforces authentication from session (never client data).
    2. Validates non-empty message and maximum length (2000 chars).
    3. Converts emoji shortcodes.
    4. Generates server UTC timestamp.
    5. Saves to SQLite database.
    6. Broadcasts 'receive_message' to everyone in that room.
    """
    user_id = session.get("user_id")
    username = session.get("username")

    if not user_id or not username:
        emit("error_message", {"error": "Authentication required to send messages."})
        disconnect()
        return

    room_name = (data.get("room") or "").strip().lower()
    raw_message = (data.get("message") or "").strip()

    # Server-side validation
    if not room_name:
        emit("error_message", {"error": "Room target is missing."})
        return

    if not raw_message:
        emit("error_message", {"error": "Cannot send an empty message."})
        return

    if len(raw_message) > MAX_MESSAGE_LENGTH:
        emit("error_message", {
            "error": f"Message exceeds maximum allowed length ({MAX_MESSAGE_LENGTH} characters)."
        })
        return

    # Verify room exists in database
    room = get_room_by_name(room_name)
    if not room:
        emit("error_message", {"error": f"Room '{room_name}' does not exist."})
        return

    # Check that client has joined the room
    sid = request.sid
    if sid not in active_connections or room_name not in active_connections[sid]["rooms"]:
        emit("error_message", {"error": f"You must join '{room_name}' before sending messages."})
        return

    # Convert emoji shortcodes (:fire: -> 🔥, etc.)
    processed_message = convert_emoji_shortcodes(raw_message)

    # Save to SQLite database
    msg_id = save_message(room["id"], user_id, processed_message)
    if not msg_id:
        emit("error_message", {"error": "Failed to save message to database."})
        return

    # Server-generated timestamp
    ts = get_server_timestamp()

    # Broadcast to ALL members in this room (including sender)
    emit(
        "receive_message",
        {
            "id": msg_id,
            "room": room_name,
            "sender": username,
            "user_id": user_id,
            "text": processed_message,
            "timestamp": ts,
        },
        to=room_name,
    )


@socketio.on("create_room")
def handle_create_room(data):
    """
    Event: user creates a new chat room.
    Validates room name, inserts into SQLite, and broadcasts room_created event to all clients.
    """
    user_id = session.get("user_id")
    username = session.get("username")

    if not user_id or not username:
        emit("error_message", {"error": "Authentication required to create rooms."})
        return

    room_name = (data.get("room_name") or "").strip().lower()

    if not room_name:
        emit("error_message", {"error": "Room name cannot be empty."})
        return

    if not ROOM_NAME_REGEX.match(room_name):
        emit("error_message", {
            "error": "Room name must be 2-30 characters with letters, numbers, hyphens, or underscores."
        })
        return

    # Create in database
    room_id = create_room(room_name, created_by=user_id)
    if not room_id:
        emit("error_message", {"error": f"A room named '{room_name}' already exists."})
        return

    # Broadcast new room to all connected sockets so room lists update live
    emit(
        "room_created",
        {
            "id": room_id,
            "name": room_name,
            "creator": username,
        },
        broadcast=True,
    )
