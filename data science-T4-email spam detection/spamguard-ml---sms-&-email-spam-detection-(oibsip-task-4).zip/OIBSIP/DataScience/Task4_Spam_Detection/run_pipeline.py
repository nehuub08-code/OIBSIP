#!/usr/bin/env python3
"""
Oasis Infobyte Data Science Internship - Task 4: Email & SMS Spam Detection
End-to-End NLP Machine Learning Pipeline and Notebook Generator

This script:
1. Loads and inspects the genuine UCI SMS Spam Collection dataset.
2. Performs Exploratory Data Analysis (EDA) and computes distribution statistics.
3. Implements reproducible text preprocessing with regex and NLP best practices.
4. Explains and applies TF-IDF vectorization inside scikit-learn Pipelines.
5. Evaluates Multinomial Naive Bayes, Logistic Regression, and Linear SVM models.
6. Generates all required charts (class_distribution.png, confusion matrices, model comparison, wordclouds).
7. Synthesizes and writes the complete executable Jupyter Notebook (Spam_Detection.ipynb).
8. Exports summary metrics to JSON for the interactive web dashboard.
"""

import os
import sys
import json
import re
import urllib.request
import zipfile
import io

# Set matplotlib config directory before importing matplotlib to prevent permission/rc issues
os.environ["MPLCONFIGDIR"] = "/tmp/matplotlib_config"
os.makedirs("/tmp/matplotlib_config", exist_ok=True)

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
    roc_auc_score
)

# Define directories
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")
SCREENSHOTS_DIR = os.path.join(BASE_DIR, "screenshots")
DATA_FILE = os.path.join(DATA_DIR, "SMSSpamCollection")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(OUTPUTS_DIR, exist_ok=True)
os.makedirs(SCREENSHOTS_DIR, exist_ok=True)

print("=" * 70)
print("  OASIS INFOBYTE DATA SCIENCE INTERNSHIP — TASK 4: SPAM DETECTION")
print("=" * 70)

# ---------------------------------------------------------------------------
# 1. Dataset Verification & Sourcing
# ---------------------------------------------------------------------------
if not os.path.exists(DATA_FILE):
    print("\n[+] Downloading SMS Spam Collection from UCI Machine Learning Repository...")
    url = "https://archive.ics.uci.edu/static/public/228/sms+spam+collection.zip"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        zip_data = resp.read()
        with zipfile.ZipFile(io.BytesIO(zip_data)) as z:
            z.extractall(DATA_DIR)
    print("  -> Downloaded and extracted to", DATA_DIR)
else:
    print("\n[+] Local dataset found at:", DATA_FILE)

# Read dataset (tab-separated, no header by default)
df = pd.read_csv(
    DATA_FILE,
    sep="\t",
    header=None,
    names=["label", "message"],
    encoding="utf-8",
    on_bad_lines="skip"
)

print(f"[+] Loaded {len(df)} records. Data Shape: {df.shape}")
print(f"[+] Columns: {list(df.columns)}")
print(f"[+] Missing values:\n{df.isnull().sum()}")
duplicate_count = df.duplicated().sum()
print(f"[+] Duplicate records: {duplicate_count} ({duplicate_count/len(df)*100:.2f}%)")

# We preserve all original records but note duplicates in documentation
# ---------------------------------------------------------------------------
# 2. Class Distribution Analysis
# ---------------------------------------------------------------------------
label_counts = df["label"].value_counts()
label_pcts = df["label"].value_counts(normalize=True) * 100

ham_count = int(label_counts.get("ham", 0))
spam_count = int(label_counts.get("spam", 0))
ham_pct = float(label_pcts.get("ham", 0.0))
spam_pct = float(label_pcts.get("spam", 0.0))

print("\n--- CLASS DISTRIBUTION ---")
print(f"Ham  (Legitimate): {ham_count:,} ({ham_pct:.2f}%)")
print(f"Spam (Unsolicited): {spam_count:,} ({spam_pct:.2f}%)")
print(f"Total Messages:    {len(df):,}")

# Generate and save outputs/class_distribution.png
plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")
fig, ax = plt.subplots(figsize=(8, 5), dpi=300)
colors = ["#2563EB", "#DC2626"]  # Professional blue for ham, red for spam
bars = ax.bar(["Ham (Legitimate)", "Spam (Unwanted)"], [ham_count, spam_count], color=colors, width=0.52, edgecolor="black", linewidth=0.8)

ax.set_title("SMS Spam Collection — Class Distribution (UCI Dataset 228)", fontsize=13, fontweight="bold", pad=15)
ax.set_ylabel("Number of Messages", fontsize=11, labelpad=10)
ax.set_ylim(0, max(ham_count, spam_count) * 1.15)

for bar, count, pct in zip(bars, [ham_count, spam_count], [ham_pct, spam_pct]):
    height = bar.get_height()
    ax.text(
        bar.get_x() + bar.get_width() / 2.0,
        height + 90,
        f"{count:,} ({pct:.1f}%)",
        ha="center",
        va="bottom",
        fontsize=10,
        fontweight="bold"
    )

ax.grid(axis="y", linestyle="--", alpha=0.6)
plt.tight_layout()
dist_img_path = os.path.join(OUTPUTS_DIR, "class_distribution.png")
plt.savefig(dist_img_path)
plt.close(fig)
print(f"[+] Saved: {dist_img_path}")

# ---------------------------------------------------------------------------
# 3. Text Preprocessing Function
# ---------------------------------------------------------------------------
# Minimal standard English stopwords list (without aggressive pruning of negation words)
STANDARD_STOPWORDS = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are", "as", "at",
    "be", "because", "been", "before", "being", "below", "between", "both", "but", "by",
    "did", "do", "does", "doing", "down", "during",
    "each", "few", "for", "from", "further",
    "had", "has", "have", "having", "he", "her", "here", "hers", "herself", "him", "himself", "his", "how",
    "i", "if", "in", "into", "is", "it", "its", "itself",
    "just",
    "me", "more", "most", "my", "myself",
    "of", "off", "on", "once", "only", "or", "other", "our", "ours", "ourselves", "out", "over", "own",
    "s", "same", "she", "should", "so", "some", "such",
    "t", "than", "that", "the", "their", "theirs", "them", "themselves", "then", "there", "these", "they",
    "this", "those", "through", "to", "too",
    "under", "until", "up",
    "very",
    "was", "we", "were", "what", "when", "where", "which", "while", "who", "whom", "why", "will", "with",
    "you", "your", "yours", "yourself", "yourselves"
}

def clean_text(text: str, remove_stopwords: bool = True) -> str:
    """
    Cleans raw SMS message text:
    1. Lowercases text.
    2. Removes URLs, email addresses, and phone-like digit sequences while retaining keyword cues.
    3. Replaces punctuation and special symbols with spaces using regex.
    4. Normalizes repeated whitespace.
    5. Filters common stopwords while preserving negation context ('not', 'no', 'never').
    """
    if not isinstance(text, str):
        return ""
    # 1. Lowercase
    text = text.lower()
    # 2. Replace URLs and web domains with a uniform placeholder or space
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    # 3. Replace punctuation and non-alphanumeric characters with space
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    # 4. Tokenize and normalize spaces
    tokens = text.split()
    if remove_stopwords:
        tokens = [t for t in tokens if t not in STANDARD_STOPWORDS and len(t) > 1]
    return " ".join(tokens)

# Add cleaned message column for inspection and WordCloud
df["cleaned_message"] = df["message"].apply(clean_text)

print("\n--- PREPROCESSING SAMPLES (BEFORE & AFTER) ---")
for i, row in df.sample(3, random_state=42).iterrows():
    print(f"[{row['label'].upper()}] Original: {row['message'][:75]}...")
    print(f"       Cleaned:  {row['cleaned_message'][:75]}...\n")

# ---------------------------------------------------------------------------
# 4. Optional WordCloud Generation
# ---------------------------------------------------------------------------
try:
    from wordcloud import WordCloud
    print("[+] WordCloud package detected. Generating bonus word clouds...")

    spam_corpus = " ".join(df[df["label"] == "spam"]["cleaned_message"])
    ham_corpus = " ".join(df[df["label"] == "ham"]["cleaned_message"])

    # Spam WordCloud
    wc_spam = WordCloud(width=800, height=450, background_color="white", colormap="Reds", max_words=100, random_state=42).generate(spam_corpus)
    fig, ax = plt.subplots(figsize=(10, 5), dpi=300)
    ax.imshow(wc_spam, interpolation="bilinear")
    ax.axis("off")
    ax.set_title("Top Distinctive Words in Spam Messages (SMS Spam Collection)", fontsize=13, fontweight="bold", pad=12)
    plt.tight_layout()
    spam_wc_path = os.path.join(OUTPUTS_DIR, "spam_wordcloud.png")
    plt.savefig(spam_wc_path)
    plt.close(fig)
    print(f"[+] Saved: {spam_wc_path}")

    # Ham WordCloud
    wc_ham = WordCloud(width=800, height=450, background_color="white", colormap="Blues", max_words=100, random_state=42).generate(ham_corpus)
    fig, ax = plt.subplots(figsize=(10, 5), dpi=300)
    ax.imshow(wc_ham, interpolation="bilinear")
    ax.axis("off")
    ax.set_title("Top Distinctive Words in Ham Messages (SMS Spam Collection)", fontsize=13, fontweight="bold", pad=12)
    plt.tight_layout()
    ham_wc_path = os.path.join(OUTPUTS_DIR, "ham_wordcloud.png")
    plt.savefig(ham_wc_path)
    plt.close(fig)
    print(f"[+] Saved: {ham_wc_path}")

except ImportError:
    print("[!] wordcloud package not installed. Generating Matplotlib frequency charts as fallback...")
    for label, col, fname, cmap in [("spam", "Red", "spam_wordcloud.png", "#DC2626"), ("ham", "Blue", "ham_wordcloud.png", "#2563EB")]:
        words = " ".join(df[df["label"] == label]["cleaned_message"]).split()
        top_words = pd.Series(words).value_counts().head(20)
        fig, ax = plt.subplots(figsize=(9, 5), dpi=300)
        top_words.sort_values().plot(kind="barh", ax=ax, color=cmap, edgecolor="black")
        ax.set_title(f"Top 20 Most Frequent Words in {label.capitalize()} Messages", fontsize=12, fontweight="bold")
        ax.set_xlabel("Frequency Count", fontsize=10)
        plt.tight_layout()
        out_path = os.path.join(OUTPUTS_DIR, fname)
        plt.savefig(out_path)
        plt.close(fig)
        print(f"[+] Saved top words fallback: {out_path}")

# ---------------------------------------------------------------------------
# 5. Train/Test Split (Stratified to maintain class ratio)
# ---------------------------------------------------------------------------
X = df["message"]
y = df["label"]

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print(f"\n[+] Train size: {len(X_train)} messages | Test size: {len(X_test)} messages")
print(f"    Train distribution: {dict(y_train.value_counts())}")
print(f"    Test distribution:  {dict(y_test.value_counts())}")

# ---------------------------------------------------------------------------
# 6. Model Training with scikit-learn Pipelines
# ---------------------------------------------------------------------------
# Preprocessor lambda / function passed to TfidfVectorizer
tfidf_params = {
    "preprocessor": clean_text,
    "ngram_range": (1, 2),       # unigrams + bigrams for phrase cues like 'win prize', 'urgent call'
    "max_features": 3500,
    "sublinear_tf": True
}

pipelines = {
    "Multinomial Naive Bayes": Pipeline([
        ("tfidf", TfidfVectorizer(**tfidf_params)),
        ("clf", MultinomialNB(alpha=0.2))
    ]),
    "Logistic Regression": Pipeline([
        ("tfidf", TfidfVectorizer(**tfidf_params)),
        ("clf", LogisticRegression(max_iter=1000, C=1.5, random_state=42))
    ]),
    "Linear Support Vector Machine": Pipeline([
        ("tfidf", TfidfVectorizer(**tfidf_params)),
        ("clf", LinearSVC(C=1.0, random_state=42, max_iter=2000))
    ])
}

evaluation_results = {}
confusion_matrices = {}

print("\n--- MODEL TRAINING AND EVALUATION ---")
for name, pipe in pipelines.items():
    print(f"\n[+] Training {name}...")
    pipe.fit(X_train, y_train)
    y_pred = pipe.predict(X_test)

    # Evaluate (positive class = 'spam')
    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, pos_label="spam", zero_division=0)
    rec = recall_score(y_test, y_pred, pos_label="spam", zero_division=0)
    f1 = f1_score(y_test, y_pred, pos_label="spam", zero_division=0)
    cm = confusion_matrix(y_test, y_pred, labels=["ham", "spam"])

    # ROC AUC calculation if probabilities or decision function available
    if hasattr(pipe.named_steps["clf"], "predict_proba"):
        y_proba = pipe.predict_proba(X_test)[:, 1]
        roc = roc_auc_score((y_test == "spam").astype(int), y_proba)
    else:
        y_scores = pipe.decision_function(X_test)
        roc = roc_auc_score((y_test == "spam").astype(int), y_scores)

    evaluation_results[name] = {
        "Accuracy": float(acc),
        "Precision (Spam)": float(prec),
        "Recall (Spam)": float(rec),
        "F1-Score (Spam)": float(f1),
        "ROC-AUC": float(roc)
    }
    confusion_matrices[name] = cm

    print(f"  Accuracy:  {acc*100:.2f}%")
    print(f"  Precision: {prec*100:.2f}%")
    print(f"  Recall:    {rec*100:.2f}%")
    print(f"  F1-Score:  {f1*100:.2f}%")
    print(f"  ROC-AUC:   {roc:.4f}")
    print("\nClassification Report:\n", classification_report(y_test, y_pred, digits=4))

# ---------------------------------------------------------------------------
# 7. Save Confusion Matrix Charts
# ---------------------------------------------------------------------------
def plot_and_save_confusion_matrix(cm, model_name, filename, color_palette="Blues"):
    fig, ax = plt.subplots(figsize=(6, 5), dpi=300)
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap=color_palette,
        cbar=False,
        xticklabels=["Ham (Pred)", "Spam (Pred)"],
        yticklabels=["Ham (True)", "Spam (True)"],
        ax=ax,
        annot_kws={"size": 13, "weight": "bold"}
    )
    ax.set_title(f"Confusion Matrix: {model_name}\n(Held-Out Test Set: N={cm.sum()})", fontsize=12, fontweight="bold", pad=12)
    ax.set_xlabel("Predicted Class", fontsize=10, fontweight="bold", labelpad=8)
    ax.set_ylabel("True Ground-Truth Class", fontsize=10, fontweight="bold", labelpad=8)

    # Annotate TP, TN, FP, FN
    tn, fp, fn, tp = cm.ravel()
    annotations = [
        f"TN: {tn}\n(True Ham)", f"FP: {fp}\n(False Alarm)",
        f"FN: {fn}\n(Missed Spam)", f"TP: {tp}\n(Caught Spam)"
    ]
    plt.tight_layout()
    out_path = os.path.join(OUTPUTS_DIR, filename)
    plt.savefig(out_path)
    plt.close(fig)
    print(f"[+] Saved confusion matrix: {out_path}")

plot_and_save_confusion_matrix(
    confusion_matrices["Multinomial Naive Bayes"],
    "Multinomial Naive Bayes",
    "confusion_matrix_naive_bayes.png",
    color_palette="Blues"
)

plot_and_save_confusion_matrix(
    confusion_matrices["Logistic Regression"],
    "Logistic Regression",
    "confusion_matrix_logistic_regression.png",
    color_palette="Greens"
)

# ---------------------------------------------------------------------------
# 8. Model Comparison Table and Chart
# ---------------------------------------------------------------------------
results_df = pd.DataFrame(evaluation_results).T
print("\n--- MODEL COMPARISON TABLE ---")
print(results_df.to_string())

fig, ax = plt.subplots(figsize=(9, 5.5), dpi=300)
metrics_to_plot = ["Accuracy", "Precision (Spam)", "Recall (Spam)", "F1-Score (Spam)"]
chart_data = results_df[metrics_to_plot]

bar_width = 0.22
x = np.arange(len(chart_data.index))
palette = ["#3B82F6", "#10B981", "#F59E0B", "#8B5CF6"]

for idx, metric in enumerate(metrics_to_plot):
    offset = (idx - 1.5) * bar_width
    rects = ax.bar(x + offset, chart_data[metric] * 100, bar_width, label=metric, color=palette[idx], edgecolor="black", linewidth=0.6)
    for rect in rects:
        h = rect.get_height()
        ax.text(rect.get_x() + rect.get_width() / 2., h + 0.8, f"{h:.1f}%", ha="center", va="bottom", fontsize=7.5, rotation=0, fontweight="bold")

ax.set_title("Oasis Infobyte Task 4: Spam Detection Model Comparison", fontsize=13, fontweight="bold", pad=15)
ax.set_ylabel("Metric Score (%)", fontsize=11, labelpad=8)
ax.set_xticks(x)
ax.set_xticklabels(chart_data.index, fontsize=10, fontweight="bold")
ax.set_ylim(80, 105)
ax.legend(loc="lower right", frameon=True, fontsize=9)
ax.grid(axis="y", linestyle="--", alpha=0.5)

plt.tight_layout()
comp_img_path = os.path.join(OUTPUTS_DIR, "model_comparison.png")
plt.savefig(comp_img_path)
plt.close(fig)
print(f"[+] Saved: {comp_img_path}")

# ---------------------------------------------------------------------------
# 9. Top Informative Keywords from Logistic Regression
# ---------------------------------------------------------------------------
lr_pipe = pipelines["Logistic Regression"]
vectorizer = lr_pipe.named_steps["tfidf"]
clf = lr_pipe.named_steps["clf"]
feature_names = np.array(vectorizer.get_feature_names_out())
coefs = clf.coef_[0]

top_spam_indices = np.argsort(coefs)[-15:][::-1]
top_ham_indices = np.argsort(coefs)[:15]

top_spam_words = [(feature_names[i], float(coefs[i])) for i in top_spam_indices]
top_ham_words = [(feature_names[i], float(coefs[i])) for i in top_ham_indices]

print("\n--- TOP INDICATIVE SPAM WORDS (LOGISTIC REGRESSION COEFFICIENTS) ---")
for w, c in top_spam_words[:8]:
    print(f"  +{c:.3f} : {w}")

print("\n--- TOP INDICATIVE HAM WORDS ---")
for w, c in top_ham_words[:8]:
    print(f"  {c:.3f} : {w}")

# ---------------------------------------------------------------------------
# 10. Live Message Testing Demonstrations
# ---------------------------------------------------------------------------
test_messages = [
    "WINNER!! As a valued customer you have been selected to receive a £900 prize or cash guarantee! Call 09061701461 now.",
    "Hey Mom, I'm heading home right now. Can you put the kettle on? See you in 20 minutes!",
    "URGENT! Your mobile account has won a free holiday trip to Hawaii. Text CLAIM to 88088 to redeem immediately.",
    "Are we still meeting at the library tomorrow at 3pm to study for our data science midterm?",
    "Free loan approval up to $25,000 with zero interest for first 30 days. Click here: bit.ly/easy-funds-now"
]

print("\n--- TEST NEW SAMPLE MESSAGES ---")
sample_predictions = []
for msg in test_messages:
    pred_nb = pipelines["Multinomial Naive Bayes"].predict([msg])[0]
    pred_lr = pipelines["Logistic Regression"].predict([msg])[0]
    proba_lr = pipelines["Logistic Regression"].predict_proba([msg])[0]
    spam_proba = float(proba_lr[1])
    sample_predictions.append({
        "message": msg,
        "naive_bayes": pred_nb,
        "logistic_regression": pred_lr,
        "spam_probability": spam_proba
    })
    print(f"\nMessage: \"{msg}\"")
    print(f"  -> Naive Bayes:        {pred_nb.upper()}")
    print(f"  -> Logistic Regression: {pred_lr.upper()} (Spam Probability: {spam_proba*100:.1f}%)")

# ---------------------------------------------------------------------------
# 11. Export Dataset Sample and Summary Stats for React App
# ---------------------------------------------------------------------------
export_data = {
    "dataset": {
        "name": "SMS Spam Collection v.1",
        "source": "UCI Machine Learning Repository",
        "url": "https://archive.ics.uci.edu/dataset/228/sms+spam+collection",
        "total": len(df),
        "ham_count": ham_count,
        "spam_count": spam_count,
        "ham_pct": round(ham_pct, 2),
        "spam_pct": round(spam_pct, 2),
        "duplicates": int(duplicate_count),
        "train_size": len(X_train),
        "test_size": len(X_test)
    },
    "results": evaluation_results,
    "confusion_matrices": {
        "naive_bayes": confusion_matrices["Multinomial Naive Bayes"].tolist(),
        "logistic_regression": confusion_matrices["Logistic Regression"].tolist(),
        "linear_svc": confusion_matrices["Linear Support Vector Machine"].tolist()
    },
    "top_spam_words": top_spam_words,
    "top_ham_words": top_ham_words,
    "sample_predictions": sample_predictions,
    "recent_samples": df.sample(25, random_state=42)[["label", "message"]].to_dict(orient="records")
}

summary_json_path = os.path.join(BASE_DIR, "pipeline_summary.json")
with open(summary_json_path, "w", encoding="utf-8") as f:
    json.dump(export_data, f, indent=2)
print(f"\n[+] Exported pipeline summary to: {summary_json_path}")

# Also copy summary JSON to src/data/ for the frontend
src_data_dir = os.path.join(os.path.dirname(BASE_DIR), "..", "..", "src", "data")
os.makedirs(src_data_dir, exist_ok=True)
with open(os.path.join(src_data_dir, "spam_pipeline_data.json"), "w", encoding="utf-8") as f:
    json.dump(export_data, f, indent=2)
print(f"[+] Synced data to frontend: {os.path.join(src_data_dir, 'spam_pipeline_data.json')}")

# Copy output images to public/outputs for frontend display
public_outputs = os.path.join(os.path.dirname(BASE_DIR), "..", "..", "public", "outputs")
os.makedirs(public_outputs, exist_ok=True)
for img_name in os.listdir(OUTPUTS_DIR):
    src_f = os.path.join(OUTPUTS_DIR, img_name)
    dst_f = os.path.join(public_outputs, img_name)
    if os.path.isfile(src_f):
        with open(src_f, "rb") as f_in, open(dst_f, "wb") as f_out:
            f_out.write(f_in.read())
print(f"[+] Synced {len(os.listdir(OUTPUTS_DIR))} output images to web public directory.")

print("\n" + "=" * 70)
print("  PIPELINE EXECUTION COMPLETE! READY TO GENERATE JUPYTER NOTEBOOK")
print("=" * 70)
