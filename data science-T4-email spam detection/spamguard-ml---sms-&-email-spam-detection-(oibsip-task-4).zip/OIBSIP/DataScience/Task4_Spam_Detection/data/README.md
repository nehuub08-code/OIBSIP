# Dataset Documentation: SMS Spam Collection v.1

## Overview
This directory contains the dataset used for **Oasis Infobyte Data Science Internship Task 4: Email / SMS Spam Detection**.

Although commonly referred to under "Email Spam Detection" internship topics, this public benchmark consists of **SMS text messages** rather than MIME/SMTP emails. In line with rigorous data science ethics, the dataset scope is explicitly identified as **SMS Spam Collection**.

---

## Dataset Provenance & Metadata

| Field | Detail |
| :--- | :--- |
| **Dataset Name** | SMS Spam Collection v.1 |
| **Primary Repository** | UCI Machine Learning Repository (Dataset ID: 228) |
| **Permanent DOI/URL** | [https://archive.ics.uci.edu/dataset/228/sms+spam+collection](https://archive.ics.uci.edu/dataset/228/sms+spam+collection) |
| **Direct Archive URL** | `https://archive.ics.uci.edu/static/public/228/sms+spam+collection.zip` |
| **Donors / Creators** | Tiago A. Almeida (UFSCar) and José María Gómez Hidalgo (R&D Department, Optenet) |
| **Citation** | Almeida, T.A., Gómez Hidalgo, J.M., Yamakami, A. *Contributions to the Study of SMS Spam Filtering: New Collection and Results.* ACM DOCENG'11, 2011. |
| **License / Terms** | Creative Commons Attribution 4.0 International (CC BY 4.0) / Free for research |
| **Total Records** | 5,574 messages |
| **File Format** | Plain text, UTF-8, tab-separated (`\t`) with two columns per record |

---

## File Structure & Mapping

The file `SMSSpamCollection` has one message per line, formatted as:
```text
<label>\t<message>
```

- **`label`**: Target binary class:
  - `ham`: Legitimate, non-spam personal or transactional message (4,827 instances, ~86.6%)
  - `spam`: Unsolicited commercial advertisement, scam, lottery claim, or phishing attempt (747 instances, ~13.4%)
- **`message`**: Raw text of the SMS message.

### Included Corpora Breakdown
1. **425 SMS Spam** manually harvested from the UK Grumbletext website (complaints about mobile spam).
2. **450 SMS Ham** from Caroline Tagg's PhD thesis at Birmingham University.
3. **3,375 SMS Ham** from the National University of Singapore (NUS) SMS Corpus.
4. **1,324 SMS (1,002 Ham, 322 Spam)** from the SMS Spam Corpus v.0.1 Big.

---

## How to Obtain or Refresh the Dataset

If you are cloning this repository or reproducing in a clean environment, execute:

```bash
# Automatic download using curl and unzip
mkdir -p data
curl -L -o data/smsspamcollection.zip https://archive.ics.uci.edu/static/public/228/sms+spam+collection.zip
unzip -o data/smsspamcollection.zip -d data/
rm data/smsspamcollection.zip
```

Alternatively, the Python script and Jupyter notebook automatically download and verify the archive if the `SMSSpamCollection` file is not detected locally.
