# Oasis Infobyte Data Science Internship (OIBSIP)
## Task 4: Email & SMS Spam Detection using Machine Learning

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Scikit-Learn](https://img.shields.io/badge/scikit--learn-v1.3%2B-orange.svg)](https://scikit-learn.org/)
[![Pandas](https://img.shields.io/badge/pandas-v2.0%2B-150458.svg)](https://pandas.pydata.org/)
[![License: CC BY 4.0](https://img.shields.io/badge/License-CC_BY_4.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)

---

## 1. Project Overview & Objective

Unsolicited communications (spam) pose severe security threats—ranging from deceptive phishing schemes and credential harvesting to financial fraud. The objective of **Oasis Infobyte Internship Task 4** is to develop a complete, reproducible, and explainable Machine Learning classification solution capable of categorizing incoming textual messages as either:
- **`Ham`**: Legitimate, benign personal or transactional correspondence.
- **`Spam`**: Unsolicited advertisements, fraudulent prize claims, or malicious phishing vectors.

This project implements an end-to-end NLP workflow: data inspection, text preprocessing, TF-IDF feature extraction inside scikit-learn Pipelines (preventing data leakage), training multiple classifiers (**Multinomial Naive Bayes**, **Logistic Regression**, and **Linear SVM**), evaluating performance using industry-standard metrics (Accuracy, Precision, Recall, F1-Score, and Confusion Matrices), and testing on novel real-world messages.

---

## 2. Dataset Sourcing & Scope Disclosure

> **Important Dataset Scope Disclosure:**  
> The benchmark used for this task is the renowned **UCI Machine Learning Repository: SMS Spam Collection**. While fundamental NLP and text classification principles apply across both mediums, this dataset contains **SMS text messages** rather than raw email structures (MIME headers, DKIM signatures, or HTML bodies). To preserve scientific integrity, this project explicitly references the dataset by its true title and characteristics.

### Dataset Metadata
- **Dataset Name:** SMS Spam Collection v.1
- **Primary Source:** [UCI Machine Learning Repository (Dataset ID: 228)](https://archive.ics.uci.edu/dataset/228/sms+spam+collection)
- **Direct Archive URL:** `https://archive.ics.uci.edu/static/public/228/sms+spam+collection.zip`
- **Donors:** Tiago A. Almeida (Federal University of São Carlos) & José María Gómez Hidalgo (Optenet)
- **License:** Creative Commons Attribution 4.0 International (CC BY 4.0)
- **Size:** 5,572 records across 2 columns (`label` and `message`)
- **Class Breakdown:**
  - `ham`: 4,825 messages (86.59%)
  - `spam`: 747 messages (13.41%)

---

## 3. Technology Stack

- **Language:** Python 3.10+
- **Data Manipulation:** `pandas`, `numpy`
- **Natural Language Processing:** Python built-in `re` (Regular Expressions), `scikit-learn`
- **Machine Learning Algorithms:** `MultinomialNB`, `LogisticRegression`, `LinearSVC`, `Pipeline`
- **Evaluation:** `accuracy_score`, `precision_score`, `recall_score`, `f1_score`, `confusion_matrix`, `classification_report`, `roc_auc_score`
- **Visualization:** `matplotlib`, `seaborn`, `wordcloud` (optional)
- **Notebook Environment:** `jupyter`, `ipykernel`

---

## 4. Project Directory Structure

```text
OIBSIP/
└── DataScience/
    └── Task4_Spam_Detection/
        ├── Spam_Detection.ipynb                  # Complete interactive Jupyter Notebook
        ├── README.md                             # Comprehensive project documentation
        ├── requirements.txt                      # Project Python dependencies
        ├── run_pipeline.py                       # Automated training & evaluation runner
        ├── build_notebook.py                     # Programmatic notebook builder
        ├── data/
        │   ├── README.md                         # Detailed dataset provenance and schema
        │   ├── SMSSpamCollection                 # Raw UCI dataset (tab-separated)
        │   └── readme                            # Original dataset donor documentation
        ├── outputs/
        │   ├── class_distribution.png            # Class balance bar chart
        │   ├── confusion_matrix_naive_bayes.png  # Naive Bayes confusion matrix heatmap
        │   ├── confusion_matrix_logistic_regression.png # Logistic Regression confusion matrix heatmap
        │   ├── model_comparison.png              # Multi-metric comparative bar chart
        │   ├── spam_wordcloud.png                # High frequency spam tokens visualization
        │   └── ham_wordcloud.png                 # High frequency ham tokens visualization
        └── screenshots/
            └── README.md                         # Verification checklist and execution notes
```

---

## 5. Installation & Setup Instructions

### Step 1: Clone the Repository & Navigate to Task Directory
```bash
git clone https://github.com/<your-username>/OIBSIP.git
cd OIBSIP/DataScience/Task4_Spam_Detection
```

### Step 2: Create and Activate a Virtual Environment
```bash
python3 -m venv venv

# On Linux/macOS:
source venv/bin/activate

# On Windows:
venv\Scripts\activate
```

### Step 3: Install Required Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Run the Automated Pipeline or Launch Jupyter Notebook
```bash
# Option A: Run the end-to-end Python pipeline to train models and generate all charts:
python3 run_pipeline.py

# Option B: Launch Jupyter to interactively inspect and run the notebook:
jupyter notebook Spam_Detection.ipynb
```

---

## 6. Text Preprocessing & TF-IDF Vectorization

### Text Cleaning Pipeline
Raw text is cleansed through a modular, deterministic regex pipeline:
1. **Case Normalization:** Converts text to lowercase to collapse identical words with varying capitalizations (`"FREE"` $\rightarrow$ `"free"`).
2. **URL & Link Removal:** Strips web domains (`http://`, `www.*`) to prevent vocabulary bloat from ephemeral URLs.
3. **Punctuation & Symbol Cleaning:** Removes special characters (`[^a-z0-9\s]`) while preserving whitespace delimiters.
4. **Context-Preserving Stopword Filtering:** Filters out generic linguistic glue words (`the`, `is`, `at`) while **strictly preserving negation words** (`not`, `no`, `never`) that invert semantic intent.

### Why Classifiers Need TF-IDF
Machine learning estimators calculate numerical distances and dot products; they cannot directly ingest strings of characters. **TF-IDF (Term Frequency–Inverse Document Frequency)** assigns each term $t$ in message $d$ a weight:

$$\text{TF-IDF}(t, d, D) = \text{TF}(t, d) \times \text{IDF}(t, D)$$

- **Term Frequency (TF):** Measures how frequently term $t$ occurs in the document.
- **Inverse Document Frequency (IDF):** Dampens weights of terms that occur universally across documents while amplifying terms uniquely indicative of specific classes (e.g., `"claim"`, `"prize"`).

### Preventing Data Leakage
To ensure that test evaluations represent true generalization to unseen messages, TF-IDF vectorization is encapsulated inside a scikit-learn `Pipeline`. The vocabulary and document frequencies are computed **strictly on `X_train`**; test data is only transformed using the fitted weights.

---

## 7. Model Training & Genuine Evaluation Results

The dataset was split using **stratified sampling** (80% training, 20% test, $N_{\text{test}} = 1,115$).

### Quantitative Performance Comparison

| Model | Accuracy | Precision (Spam) | Recall (Spam) | F1-Score (Spam) | ROC-AUC |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Multinomial Naive Bayes** | **98.21%** | 99.24% | 87.25% | **92.86%** | **0.9874** |
| **Logistic Regression** | **97.67%** | **100.00%** | 82.55% | **90.44%** | **0.9866** |
| **Linear Support Vector Machine** | **98.48%** | 97.83% | **90.60%** | **94.08%** | **0.9871** |

*(Spam is designated as the positive class for precision, recall, and F1-score).*

---

## 8. Diagnostic Visualizations

### Class Distribution
Due to the authentic nature of communication, the dataset exhibits class imbalance ($86.59\%$ Ham vs. $13.41\%$ Spam). A dummy classifier predicting only "ham" would achieve $86.59\%$ accuracy but $0\%$ spam recall.

![Class Distribution](outputs/class_distribution.png)

### Confusion Matrices
Both models demonstrated remarkable precision on held-out test messages ($N = 1,115$):
- **Multinomial Naive Bayes:** Correctly classified 965 out of 966 ham messages with only **1 false alarm** and successfully detected 130 spam messages.
- **Logistic Regression:** Achieved **0 false alarms** (100% precision on spam), capturing 123 spam messages with zero legitimate messages misclassified!

| Multinomial Naive Bayes | Logistic Regression |
| :---: | :---: |
| ![CM Naive Bayes](outputs/confusion_matrix_naive_bayes.png) | ![CM Logistic Regression](outputs/confusion_matrix_logistic_regression.png) |

### Comparative Model Summary
All three models achieved $>97.5\%$ accuracy and $>90\%$ F1-score on spam detection:

![Model Comparison](outputs/model_comparison.png)

### Frequent Term Visualizations (Bonus)
The top distinguishing terms in spam messages emphasize urgency, financial rewards, and prompt replies:

| Spam Frequent Terms | Ham Frequent Terms |
| :---: | :---: |
| ![Spam Terms](outputs/spam_wordcloud.png) | ![Ham Terms](outputs/ham_wordcloud.png) |

---

## 9. Critical Analysis: Why is Recall Particularly Important for Spam Detection?

In spam classification ($\text{Positive} = \text{Spam}$, $\text{Negative} = \text{Ham}$):

1. **The Cost of Low Recall (High False Negatives):**
   When recall is low, real spam messages slip through into the recipient's primary inbox. Users are exposed to phishing lures, malware download links, and social engineering attacks.
2. **The Cost of Low Precision (High False Positives):**
   When precision is low, benign messages (job offers, two-factor authentication codes, flight updates) are flagged as spam and hidden in quarantine. Missing an important email can cause irreparable professional or financial damage.
3. **The Engineering Trade-off:**
   While users despise spam reaching their inbox (requiring solid **recall**), they tolerate occasional junk far more than having critical life communications silently deleted (demanding near-perfect **precision**). Hence, modern spam filters tune decision thresholds to ensure precision remains $>99\%$ while maximizing recall.

---

## 10. Sample Live Predictions

Using the fitted **Logistic Regression** pipeline on unseen test prompts:

| Sample Message | True Intent | Predicted Class | Spam Risk Score |
| :--- | :---: | :---: | :---: |
| *"WINNER!! As a valued customer you have won a £900 prize! Call 09061701461 now."* | Spam | 🔴 **SPAM** | **87.0%** |
| *"Hey Mom, I'm heading home right now. Can you put the kettle on? See you in 20 minutes!"* | Ham | 🟢 **HAM** | **1.7%** |
| *"URGENT! Your mobile account has won a free trip. Text CLAIM to 88088 to redeem immediately."* | Spam | 🔴 **SPAM** | **96.7%** |
| *"Are we still meeting at the library tomorrow at 3pm to study for our data science midterm?"* | Ham | 🟢 **HAM** | **2.5%** |
| *"Free loan approval up to $25,000 with zero interest for first 30 days. Click here: bit.ly/easy-funds"* | Spam | 🔴 **SPAM** | **35.9%** |

---

## 11. Real-World Limitations & Future Work

1. **Corpus Scope:** The dataset consists of short SMS messages (160 character limits) rather than multi-part MIME email threads containing HTML markup and server headers.
2. **Adversarial Noise:** Modern cybercriminals intentionally bypass TF-IDF tokenizers using character substitution (`Fr33`, `w!n`), Unicode lookalikes, or OCR-evading image spam.
3. **Concept Drift:** Scam strategies shift rapidly over time (e.g. cryptocurrency scams did not exist when this corpus was collected). Production spam filters require continuous online retraining.
4. **Future Enhancements:**
   - Incorporating sub-word tokenization (BPE or WordPiece) to withstand misspelled words.
   - Fine-tuning lightweight Transformer architectures (e.g., DistilBERT) for nuanced contextual semantic analysis.

---

## 12. Internship Submission Checklist (Task 4)

- [x] Suitable public spam dataset obtained (UCI SMS Spam Collection, 5,572 rows)
- [x] Data loaded, verified, and inspected
- [x] Spam/ham counts (4,825 vs 747) and percentages (86.59% vs 13.41%) calculated
- [x] Text preprocessing explained and implemented (case folding, regex symbol cleaning, negation-aware stopword removal)
- [x] TF-IDF mathematically formulated and explained
- [x] Train/test split completed (80/20 stratified) without data leakage
- [x] Multinomial Naive Bayes trained
- [x] Logistic Regression trained
- [x] Linear SVM trained as bonus classifier
- [x] Accuracy, precision, recall, F1-score, and confusion matrices computed
- [x] Recall importance and asymmetry of classification errors analyzed in depth
- [x] High-resolution charts generated and saved to `outputs/`
- [x] Interactive inference tested on realistic unseen messages
- [x] Clean, commented, executable Jupyter Notebook (`Spam_Detection.ipynb`) created
- [x] Comprehensive, production-grade `README.md` and `requirements.txt` provided

---

## 13. Git Submission Commands

To commit and stage this project within your internship repository:

```bash
git add OIBSIP/DataScience/Task4_Spam_Detection/
git commit -m "feat(task4): complete SMS/Email spam detection NLP project with EDA, Naive Bayes, Logistic Regression, and evaluation"
```
