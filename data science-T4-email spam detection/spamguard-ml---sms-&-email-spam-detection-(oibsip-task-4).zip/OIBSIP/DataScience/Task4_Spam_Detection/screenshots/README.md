# Notebook Execution & Evaluation Screenshots

This directory is designated for high-resolution visual evidence of the Jupyter Notebook execution, model metrics, interactive tests, and submission verification for Oasis Infobyte Data Science Internship Task 4.

## Screenshot Index

Once the notebook is executed interactively in Jupyter or VS Code, export snapshots into this directory:

| Screenshot File | Description | Checkpoint Covered |
| :--- | :--- | :--- |
| `01_dataset_inspection.png` | DataFrame overview, column types, class distribution counts | Section 2 & 3 |
| `02_preprocessing_tfidf.png` | Text cleaning before/after and TF-IDF pipeline formulation | Section 4 & 5 |
| `03_model_training_nb.png` | Multinomial Naive Bayes classification report & confusion matrix | Section 7 & 8 |
| `04_model_training_lr.png` | Logistic Regression classification report & confusion matrix | Section 7 & 8 |
| `05_model_comparison_eval.png` | Side-by-side performance comparison metrics table and bar chart | Section 8 & 12 |
| `06_interactive_inference.png` | Live message classification test with custom ham and spam examples | Section 15 |

All primary charts generated during automated execution are preserved in high-resolution PNG format inside the [`outputs/`](../outputs/) directory.
