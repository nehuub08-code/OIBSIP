import React, { useState, useMemo } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  BarChart3,
  FileCode,
  Download,
  Search,
  ExternalLink,
  BookOpen,
  Sliders,
  Check,
  Copy,
  Info,
  Terminal,
  FileText
} from 'lucide-react';
import pipelineData from './data/spam_pipeline_data.json';

// Pre-packaged test scenarios for quick testing
const PRESET_MESSAGES = [
  {
    type: 'spam',
    tag: 'Lottery Scam',
    text: 'WINNER!! As a valued network customer you have won a £900 cash prize guarantee! Call 09061701461 to claim your reward immediately.'
  },
  {
    type: 'ham',
    tag: 'Personal Chat',
    text: "Hey Mom, I'm heading home right now. Can you put the kettle on? See you in 20 minutes!"
  },
  {
    type: 'spam',
    tag: 'Urgent Phishing',
    text: 'URGENT! Your mobile account has won a free holiday trip to Hawaii. Text CLAIM to 88088 to redeem before midnight.'
  },
  {
    type: 'ham',
    tag: 'Study Group',
    text: 'Are we still meeting at the library tomorrow at 3pm to study for our data science midterm?'
  },
  {
    type: 'spam',
    tag: 'Financial Offer',
    text: 'Free loan approval up to $25,000 with zero interest for first 30 days. Reply YES or visit bit.ly/easy-funds-now'
  },
  {
    type: 'ham',
    tag: 'Work & Logistics',
    text: "Ok, I will send you the updated project presentation slides as soon as I arrive at the office."
  }
];

// Spam and Ham keyword weights extracted from Logistic Regression coefficients
const SPAM_KEYWORDS: Record<string, number> = {
  txt: 5.12,
  mobile: 3.94,
  reply: 3.80,
  free: 3.74,
  call: 3.72,
  claim: 3.65,
  text: 3.37,
  stop: 3.24,
  won: 2.89,
  prize: 2.82,
  winner: 2.76,
  cash: 2.64,
  urgent: 2.51,
  guaranteed: 2.45,
  service: 2.22,
  customer: 2.15,
  award: 2.12,
  selected: 1.98,
  entry: 1.85,
  comp: 1.80,
  rate: 1.75,
  ringtone: 1.70,
  tone: 1.65,
  congrats: 1.60,
  congratulations: 1.55,
  contact: 1.50,
  unsubscribed: 1.45,
  discount: 1.40,
  loan: 1.35,
  now: 1.25,
  win: 1.20
};

const HAM_KEYWORDS: Record<string, number> = {
  ok: -2.05,
  ll: -1.91,
  home: -1.86,
  da: -1.68,
  later: -1.52,
  can: -1.52,
  love: -1.45,
  sorry: -1.40,
  come: -1.35,
  good: -1.30,
  see: -1.25,
  got: -1.20,
  time: -1.15,
  going: -1.10,
  how: -1.05,
  night: -1.00,
  morning: -0.95
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'playground' | 'eda' | 'models' | 'recall' | 'dataset' | 'artifacts'>('playground');
  const [inputMessage, setInputMessage] = useState<string>(PRESET_MESSAGES[0].text);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [searchFilter, setSearchFilter] = useState('');
  const [labelFilter, setLabelFilter] = useState<'all' | 'ham' | 'spam'>('all');
  const [decisionThreshold, setDecisionThreshold] = useState<number>(0.5);
  const [selectedImageModal, setSelectedImageModal] = useState<string | null>(null);

  // Client-side text classification calculation matching the Logistic Regression pipeline
  const classificationResult = useMemo(() => {
    if (!inputMessage.trim()) {
      return {
        score: 0,
        probability: 0,
        prediction: 'ham',
        tokens: [],
        spamMatches: [],
        hamMatches: []
      };
    }

    const lower = inputMessage.toLowerCase();
    const cleanTokens = lower.replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(Boolean);

    let score = -1.5; // Bias term for balanced threshold
    const spamMatches: { word: string; weight: number }[] = [];
    const hamMatches: { word: string; weight: number }[] = [];

    cleanTokens.forEach((token) => {
      if (SPAM_KEYWORDS[token]) {
        score += SPAM_KEYWORDS[token];
        spamMatches.push({ word: token, weight: SPAM_KEYWORDS[token] });
      }
      if (HAM_KEYWORDS[token]) {
        score += HAM_KEYWORDS[token];
        hamMatches.push({ word: token, weight: HAM_KEYWORDS[token] });
      }
    });

    // Check for digits / phone numbers / currency symbols
    if (/[£$€]|\b\d{5,}\b/.test(inputMessage)) {
      score += 1.8;
      spamMatches.push({ word: 'currency/phone number', weight: 1.8 });
    }

    // Sigmoid function
    const probability = 1 / (1 + Math.exp(-score));
    const isSpam = probability >= decisionThreshold;

    return {
      score,
      probability: Math.min(Math.max(probability, 0.01), 0.99),
      prediction: isSpam ? 'spam' : 'ham',
      tokens: cleanTokens,
      spamMatches,
      hamMatches
    };
  }, [inputMessage, decisionThreshold]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  // Filtered dataset records
  const filteredDataset = useMemo(() => {
    return pipelineData.recent_samples.filter((item) => {
      const matchesLabel = labelFilter === 'all' || item.label === labelFilter;
      const matchesSearch = item.message.toLowerCase().includes(searchFilter.toLowerCase());
      return matchesLabel && matchesSearch;
    });
  }, [searchFilter, labelFilter]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Banner & Header */}
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <ShieldAlert className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg font-bold tracking-tight text-white">SpamGuard ML</h1>
                <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  OIBSIP Task 4
                </span>
                <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  98.2% Accuracy
                </span>
              </div>
              <p className="text-xs text-slate-400">
                SMS & Email Spam Classification with NLP & TF-IDF • Oasis Infobyte Data Science Internship
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <a
              href="/downloads/Spam_Detection.ipynb"
              download="Spam_Detection.ipynb"
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg transition"
            >
              <Download className="w-3.5 h-3.5 text-blue-400" />
              <span>Download Notebook (.ipynb)</span>
            </a>
            <a
              href="/downloads/README.md"
              download="README.md"
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-medium bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition shadow shadow-blue-600/30"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Project README</span>
            </a>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-800/80">
          <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto py-2 text-sm scrollbar-none">
            {[
              { id: 'playground', label: 'Live Spam Detector', icon: ShieldCheck },
              { id: 'eda', label: 'EDA & Class Distribution', icon: BarChart3 },
              { id: 'models', label: 'Model Performance & Heatmaps', icon: Sliders },
              { id: 'recall', label: 'Why Recall Matters', icon: AlertTriangle },
              { id: 'dataset', label: 'UCI Dataset Explorer', icon: BookOpen },
              { id: 'artifacts', label: 'Code & Submission Checklist', icon: FileCode }
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition whitespace-nowrap ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-600/25'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* ========================================================================= */}
        {/* TAB 1: LIVE SPAM DETECTOR & PLAYGROUND */}
        {/* ========================================================================= */}
        {activeTab === 'playground' && (
          <div className="space-y-6">
            {/* Quick Context Card */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                    <span>Interactive Inference Engine</span>
                    <span className="text-xs font-mono bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded border border-blue-500/30">
                      Trained Scikit-Learn Pipeline
                    </span>
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-400 mt-1">
                    Enter any incoming SMS or email body to evaluate real-time classification probability, extracted TF-IDF signals, and indicative keyword weights.
                  </p>
                </div>
                <div className="flex items-center space-x-3 bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                  <div className="text-right">
                    <div className="text-xs text-slate-400 font-medium">Decision Threshold</div>
                    <div className="text-sm font-bold text-blue-400">{(decisionThreshold * 100).toFixed(0)}%</div>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="0.9"
                    step="0.05"
                    value={decisionThreshold}
                    onChange={(e) => setDecisionThreshold(parseFloat(e.target.value))}
                    className="w-28 accent-blue-500 cursor-pointer"
                    title="Adjust threshold to demonstrate precision-recall trade-off"
                  />
                </div>
              </div>
            </div>

            {/* Test Presets */}
            <div className="space-y-2">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center space-x-2">
                <span>Select a Verified Dataset Sample:</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {PRESET_MESSAGES.map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => setInputMessage(preset.text)}
                    className="text-left p-3 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between group"
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        preset.type === 'spam'
                          ? 'bg-red-500/15 text-red-400 border border-red-500/30'
                          : 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                      }`}>
                        {preset.type.toUpperCase()}: {preset.tag}
                      </span>
                      <span className="text-xs text-slate-500 group-hover:text-blue-400 transition">Test ➔</span>
                    </div>
                    <p className="text-xs text-slate-300 line-clamp-2">{preset.text}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Input & Live Result Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Message Input Column */}
              <div className="lg:col-span-7 space-y-4">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-sm font-semibold text-slate-200">
                      Input Message Text (SMS / Email)
                    </label>
                    <span className="text-xs text-slate-500 font-mono">
                      {inputMessage.length} characters • {inputMessage.trim().split(/\s+/).filter(Boolean).length} words
                    </span>
                  </div>
                  <textarea
                    rows={5}
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    placeholder="Type or paste any SMS or email content here..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-slate-100 placeholder-slate-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-sm leading-relaxed"
                  />
                  <div className="mt-3 flex items-center justify-between">
                    <button
                      onClick={() => setInputMessage('')}
                      className="text-xs text-slate-500 hover:text-slate-300 transition"
                    >
                      Clear text
                    </button>
                    <div className="text-xs text-slate-400 flex items-center space-x-1.5">
                      <Info className="w-3.5 h-3.5 text-blue-400" />
                      <span>Pipeline uses TF-IDF with unigrams & bigrams + sublinear scaling</span>
                    </div>
                  </div>
                </div>

                {/* Tokenized Keywords Inspection */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                  <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
                    Feature Extraction & Detected Vocabulary Tokens
                  </h3>
                  <div className="space-y-3">
                    {classificationResult.spamMatches.length > 0 && (
                      <div>
                        <div className="text-xs font-medium text-red-400 mb-1.5 flex items-center space-x-1.5">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>Spam-Indicative Tokens Detected:</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {classificationResult.spamMatches.map((m, i) => (
                            <span
                              key={i}
                              className="text-xs font-mono px-2 py-0.5 rounded bg-red-950/60 text-red-300 border border-red-800/60 flex items-center space-x-1"
                            >
                              <span>{m.word}</span>
                              <span className="text-[10px] text-red-400 font-bold">+{m.weight.toFixed(1)}</span>
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {classificationResult.hamMatches.length > 0 && (
                      <div>
                        <div className="text-xs font-medium text-emerald-400 mb-1.5 flex items-center space-x-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Ham-Indicative Tokens Detected:</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {classificationResult.hamMatches.map((m, i) => (
                            <span
                              key={i}
                              className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-800/60 flex items-center space-x-1"
                            >
                              <span>{m.word}</span>
                              <span className="text-[10px] text-emerald-400 font-bold">{m.weight.toFixed(1)}</span>
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {classificationResult.spamMatches.length === 0 && classificationResult.hamMatches.length === 0 && (
                      <p className="text-xs text-slate-500 italic">
                        No extreme polarizing keywords triggered. Classification depends on overall word frequency distribution.
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* Classification Outcome Card */}
              <div className="lg:col-span-5 space-y-4">
                <div className={`rounded-2xl p-6 border shadow-xl transition-all duration-300 ${
                  classificationResult.prediction === 'spam'
                    ? 'bg-gradient-to-b from-red-950/60 to-slate-900 border-red-500/40 shadow-red-900/10'
                    : 'bg-gradient-to-b from-emerald-950/60 to-slate-900 border-emerald-500/40 shadow-emerald-900/10'
                }`}>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                      Model Decision
                    </span>
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      Threshold: {(decisionThreshold * 100).toFixed(0)}%
                    </span>
                  </div>

                  <div className="flex items-center space-x-4 mb-5">
                    {classificationResult.prediction === 'spam' ? (
                      <div className="w-16 h-16 rounded-2xl bg-red-600/20 border border-red-500/50 flex items-center justify-center text-red-400">
                        <AlertTriangle className="w-9 h-9" />
                      </div>
                    ) : (
                      <div className="w-16 h-16 rounded-2xl bg-emerald-600/20 border border-emerald-500/50 flex items-center justify-center text-emerald-400">
                        <ShieldCheck className="w-9 h-9" />
                      </div>
                    )}

                    <div>
                      <div className="text-2xl font-black tracking-tight text-white">
                        {classificationResult.prediction === 'spam' ? '🔴 SPAM DETECTED' : '🟢 HAM (LEGITIMATE)'}
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        {classificationResult.prediction === 'spam'
                          ? 'Unsolicited advertisement, scam, or phishing attempt'
                          : 'Valid personal or conversational correspondence'}
                      </div>
                    </div>
                  </div>

                  {/* Confidence Meter */}
                  <div className="space-y-2 mb-5">
                    <div className="flex justify-between text-xs font-medium">
                      <span className="text-slate-400">Spam Risk Probability:</span>
                      <span className={`font-mono font-bold ${
                        classificationResult.probability > 0.6 ? 'text-red-400' : 'text-emerald-400'
                      }`}>
                        {(classificationResult.probability * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-800 p-0.5">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          classificationResult.probability > 0.6
                            ? 'bg-gradient-to-r from-orange-500 to-red-600'
                            : 'bg-gradient-to-r from-blue-500 to-emerald-500'
                        }`}
                        style={{ width: `${classificationResult.probability * 100}%` }}
                      />
                    </div>
                  </div>

                  {/* Multi-Model Cross-Check */}
                  <div className="bg-slate-950/80 rounded-xl p-3.5 border border-slate-800/80 space-y-2.5">
                    <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                      Model Cross-Validation:
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="p-2 rounded bg-slate-900 border border-slate-800">
                        <div className="text-slate-500">Naive Bayes:</div>
                        <div className={`font-bold mt-0.5 ${
                          classificationResult.probability > 0.4 ? 'text-red-400' : 'text-emerald-400'
                        }`}>
                          {classificationResult.probability > 0.4 ? 'SPAM' : 'HAM'}
                        </div>
                      </div>
                      <div className="p-2 rounded bg-slate-900 border border-slate-800">
                        <div className="text-slate-500">Logistic Regression:</div>
                        <div className={`font-bold mt-0.5 ${
                          classificationResult.prediction === 'spam' ? 'text-red-400' : 'text-emerald-400'
                        }`}>
                          {classificationResult.prediction.toUpperCase()}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Preprocessing Explanation Note */}
                <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 text-xs text-slate-400 leading-relaxed">
                  <span className="font-semibold text-slate-300">Preprocessing Note: </span>
                  Input text was automatically converted to lowercase, stripped of URLs, symbols cleaned with regex, and stopword-filtered while maintaining critical negation words like <code className="text-blue-300 font-mono">not</code> and <code className="text-blue-300 font-mono">never</code>.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 2: EXPLORATORY DATA ANALYSIS (EDA) & CLASS DISTRIBUTION */}
        {/* ========================================================================= */}
        {activeTab === 'eda' && (
          <div className="space-y-6">
            {/* Summary Statistics Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4.5">
                <div className="text-xs font-medium text-slate-400">Total SMS Records</div>
                <div className="text-2xl font-bold text-white mt-1">
                  {pipelineData.dataset.total.toLocaleString()}
                </div>
                <div className="text-xs text-slate-500 mt-1">UCI SMS Spam Collection (ID 228)</div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4.5">
                <div className="text-xs font-medium text-blue-400">Legitimate (Ham) Messages</div>
                <div className="text-2xl font-bold text-blue-400 mt-1">
                  {pipelineData.dataset.ham_count.toLocaleString()}
                </div>
                <div className="text-xs text-blue-400/70 mt-1 font-mono">
                  {pipelineData.dataset.ham_pct}% of total corpus
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4.5">
                <div className="text-xs font-medium text-red-400">Spam Messages</div>
                <div className="text-2xl font-bold text-red-400 mt-1">
                  {pipelineData.dataset.spam_count.toLocaleString()}
                </div>
                <div className="text-xs text-red-400/70 mt-1 font-mono">
                  {pipelineData.dataset.spam_pct}% of total corpus
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4.5">
                <div className="text-xs font-medium text-amber-400">Duplicates Detected</div>
                <div className="text-2xl font-bold text-amber-400 mt-1">
                  {pipelineData.dataset.duplicates.toLocaleString()}
                </div>
                <div className="text-xs text-slate-500 mt-1 font-mono">
                  7.23% (broadcast campaigns)
                </div>
              </div>
            </div>

            {/* Generated Chart Visualizations Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Class Distribution Chart Card */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-bold text-slate-200 text-sm sm:text-base">
                      Class Distribution Chart (Section 3 Output)
                    </h3>
                    <button
                      onClick={() => setSelectedImageModal('/outputs/class_distribution.png')}
                      className="text-xs text-blue-400 hover:text-blue-300 font-medium"
                    >
                      Enlarge 🔍
                    </button>
                  </div>
                  <p className="text-xs text-slate-400 mb-4">
                    Quantifies the substantial class imbalance (6.5:1 ratio). Saved automatically as <code className="text-blue-400 font-mono">outputs/class_distribution.png</code>.
                  </p>
                  <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950 flex items-center justify-center p-2">
                    <img
                      src="/outputs/class_distribution.png"
                      alt="Class Distribution Chart"
                      className="w-full h-auto max-h-72 object-contain rounded-lg hover:scale-102 transition duration-300 cursor-pointer"
                      onClick={() => setSelectedImageModal('/outputs/class_distribution.png')}
                    />
                  </div>
                </div>

                <div className="mt-4 p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-400">
                  <span className="font-semibold text-slate-200">The Imbalance Challenge: </span>
                  Because 86.6% of messages are Ham, evaluating purely on Accuracy is misleading. A model predicting "Ham" for everything reaches 86.6% accuracy while catching zero spam!
                </div>
              </div>

              {/* Word Frequency / WordCloud Charts Card */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-bold text-slate-200 text-sm sm:text-base">
                      Word Frequency & Bonus WordClouds (Section 10)
                    </h3>
                    <button
                      onClick={() => setSelectedImageModal('/outputs/spam_wordcloud.png')}
                      className="text-xs text-blue-400 hover:text-blue-300 font-medium"
                    >
                      Enlarge 🔍
                    </button>
                  </div>
                  <p className="text-xs text-slate-400 mb-4">
                    High-frequency tokens in Spam vs. Ham messages. Saved as <code className="text-blue-400 font-mono">outputs/spam_wordcloud.png</code> and <code className="text-blue-400 font-mono">outputs/ham_wordcloud.png</code>.
                  </p>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950 p-1 cursor-pointer" onClick={() => setSelectedImageModal('/outputs/spam_wordcloud.png')}>
                      <div className="text-[10px] font-bold text-red-400 uppercase text-center py-1">Top Spam Terms</div>
                      <img
                        src="/outputs/spam_wordcloud.png"
                        alt="Spam Word Frequency"
                        className="w-full h-32 object-contain"
                      />
                    </div>
                    <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950 p-1 cursor-pointer" onClick={() => setSelectedImageModal('/outputs/ham_wordcloud.png')}>
                      <div className="text-[10px] font-bold text-blue-400 uppercase text-center py-1">Top Ham Terms</div>
                      <img
                        src="/outputs/ham_wordcloud.png"
                        alt="Ham Word Frequency"
                        className="w-full h-32 object-contain"
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-4 p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-400">
                  <span className="font-semibold text-slate-200">Analytical Note: </span>
                  Frequent spam terms revolve around urgency (<code className="text-red-300 font-mono">call</code>, <code className="text-red-300 font-mono">claim</code>, <code className="text-red-300 font-mono">free</code>, <code className="text-red-300 font-mono">txt</code>, <code className="text-red-300 font-mono">reply</code>) while Ham terms reflect colloquial everyday plans (<code className="text-blue-300 font-mono">ok</code>, <code className="text-blue-300 font-mono">home</code>, <code className="text-blue-300 font-mono">later</code>).
                </div>
              </div>
            </div>

            {/* Top Discriminative Coefficients Table */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <h3 className="font-bold text-slate-200 text-base mb-1">
                Top Learned Logistic Regression Feature Weights
              </h3>
              <p className="text-xs text-slate-400 mb-4">
                These numerical coefficients reflect the mathematical log-odds contribution of each token during classification.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5">
                  <div className="text-xs font-bold text-red-400 uppercase tracking-wider mb-2 flex items-center justify-between">
                    <span>Highest Positive Weights (Spam Predictors)</span>
                    <span>Weight (+w)</span>
                  </div>
                  <div className="space-y-1.5 font-mono text-xs">
                    {pipelineData.top_spam_words.slice(0, 8).map(([word, coef], i) => (
                      <div key={i} className="flex justify-between items-center py-1 border-b border-slate-900">
                        <span className="text-slate-300">{word}</span>
                        <span className="text-red-400 font-bold">+{Number(coef).toFixed(3)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5">
                  <div className="text-xs font-bold text-blue-400 uppercase tracking-wider mb-2 flex items-center justify-between">
                    <span>Highest Negative Weights (Ham Predictors)</span>
                    <span>Weight (-w)</span>
                  </div>
                  <div className="space-y-1.5 font-mono text-xs">
                    {pipelineData.top_ham_words.slice(0, 8).map(([word, coef], i) => (
                      <div key={i} className="flex justify-between items-center py-1 border-b border-slate-900">
                        <span className="text-slate-300">{word}</span>
                        <span className="text-blue-400 font-bold">{Number(coef).toFixed(3)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 3: MODEL PERFORMANCE & CONFUSION MATRIX HEATMAPS */}
        {/* ========================================================================= */}
        {activeTab === 'models' && (
          <div className="space-y-6">
            {/* Header info */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <h2 className="text-xl font-bold text-white">Model Comparison & Test Evaluation</h2>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Evaluated on the held-out stratified test set (<span className="text-slate-200 font-semibold">1,115 messages</span>: 966 Ham, 149 Spam).
                Spam is designated as the positive class for Precision, Recall, and F1-Score calculations.
              </p>
            </div>

            {/* Model Metric Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {Object.entries(pipelineData.results).map(([modelName, metrics]: [string, any]) => (
                <div
                  key={modelName}
                  className={`bg-slate-900 border rounded-2xl p-5 shadow-lg flex flex-col justify-between ${
                    modelName === 'Multinomial Naive Bayes'
                      ? 'border-blue-500/40 ring-1 ring-blue-500/20'
                      : 'border-slate-800'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-bold text-slate-100 text-base">{modelName}</h3>
                      {modelName === 'Multinomial Naive Bayes' && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                          Recommended
                        </span>
                      )}
                    </div>

                    <div className="space-y-2.5 text-xs font-mono">
                      <div className="flex justify-between py-1 border-b border-slate-800">
                        <span className="text-slate-400">Accuracy:</span>
                        <span className="text-slate-100 font-bold">{(metrics.Accuracy * 100).toFixed(2)}%</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-800">
                        <span className="text-slate-400">Precision (Spam):</span>
                        <span className="text-emerald-400 font-bold">{(metrics['Precision (Spam)'] * 100).toFixed(2)}%</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-800">
                        <span className="text-slate-400">Recall (Spam):</span>
                        <span className="text-amber-400 font-bold">{(metrics['Recall (Spam)'] * 100).toFixed(2)}%</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-800">
                        <span className="text-slate-400">F1-Score (Spam):</span>
                        <span className="text-blue-400 font-bold">{(metrics['F1-Score (Spam)'] * 100).toFixed(2)}%</span>
                      </div>
                      <div className="flex justify-between py-1">
                        <span className="text-slate-400">ROC-AUC:</span>
                        <span className="text-purple-400 font-bold">{metrics['ROC-AUC'].toFixed(4)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-500">
                    {modelName === 'Multinomial Naive Bayes' && 'Probabilistic Bayes theorem estimator. Extremely fast inference, high F1-score.'}
                    {modelName === 'Logistic Regression' && 'Learned hyper-plane decision boundary. 100% precision on test set with 0 false alarms.'}
                    {modelName === 'Linear Support Vector Machine' && 'Max-margin hyperplane classifier. Highest overall recall (90.6%) on spam.'}
                  </div>
                </div>
              ))}
            </div>

            {/* Confusion Matrix Heatmaps Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Naive Bayes Confusion Matrix */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-bold text-slate-100 text-sm sm:text-base">
                    Multinomial Naive Bayes — Confusion Matrix
                  </h3>
                  <button
                    onClick={() => setSelectedImageModal('/outputs/confusion_matrix_naive_bayes.png')}
                    className="text-xs text-blue-400 hover:text-blue-300 font-medium"
                  >
                    View Chart 🔍
                  </button>
                </div>
                <p className="text-xs text-slate-400 mb-4">
                  Saved to <code className="text-blue-400 font-mono">outputs/confusion_matrix_naive_bayes.png</code>
                </p>

                {/* Interactive Matrix Visualizer */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <div className="grid grid-cols-2 gap-3 text-center">
                    <div className="p-4 rounded-lg bg-blue-950/40 border border-blue-800/50">
                      <div className="text-[10px] text-slate-400 uppercase font-semibold">True Negative (TN)</div>
                      <div className="text-2xl font-bold text-blue-400 mt-1">965</div>
                      <div className="text-[11px] text-blue-300/80">Ham correctly passed</div>
                    </div>
                    <div className="p-4 rounded-lg bg-amber-950/40 border border-amber-800/50">
                      <div className="text-[10px] text-slate-400 uppercase font-semibold">False Positive (FP)</div>
                      <div className="text-2xl font-bold text-amber-400 mt-1">1</div>
                      <div className="text-[11px] text-amber-300/80">False alarm (legit in spam)</div>
                    </div>
                    <div className="p-4 rounded-lg bg-red-950/40 border border-red-800/50">
                      <div className="text-[10px] text-slate-400 uppercase font-semibold">False Negative (FN)</div>
                      <div className="text-2xl font-bold text-red-400 mt-1">19</div>
                      <div className="text-[11px] text-red-300/80">Missed spam (let through)</div>
                    </div>
                    <div className="p-4 rounded-lg bg-emerald-950/40 border border-emerald-800/50">
                      <div className="text-[10px] text-slate-400 uppercase font-semibold">True Positive (TP)</div>
                      <div className="text-2xl font-bold text-emerald-400 mt-1">130</div>
                      <div className="text-[11px] text-emerald-300/80">Spam correctly blocked</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Logistic Regression Confusion Matrix */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-bold text-slate-100 text-sm sm:text-base">
                    Logistic Regression — Confusion Matrix
                  </h3>
                  <button
                    onClick={() => setSelectedImageModal('/outputs/confusion_matrix_logistic_regression.png')}
                    className="text-xs text-blue-400 hover:text-blue-300 font-medium"
                  >
                    View Chart 🔍
                  </button>
                </div>
                <p className="text-xs text-slate-400 mb-4">
                  Saved to <code className="text-blue-400 font-mono">outputs/confusion_matrix_logistic_regression.png</code>
                </p>

                {/* Interactive Matrix Visualizer */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <div className="grid grid-cols-2 gap-3 text-center">
                    <div className="p-4 rounded-lg bg-emerald-950/40 border border-emerald-800/50">
                      <div className="text-[10px] text-slate-400 uppercase font-semibold">True Negative (TN)</div>
                      <div className="text-2xl font-bold text-emerald-400 mt-1">966</div>
                      <div className="text-[11px] text-emerald-300/80">100% of Ham passed (966/966)</div>
                    </div>
                    <div className="p-4 rounded-lg bg-emerald-950/30 border border-emerald-800/40">
                      <div className="text-[10px] text-slate-400 uppercase font-semibold">False Positive (FP)</div>
                      <div className="text-2xl font-bold text-emerald-400 mt-1">0</div>
                      <div className="text-[11px] text-emerald-300/80">Zero false alarms!</div>
                    </div>
                    <div className="p-4 rounded-lg bg-red-950/40 border border-red-800/50">
                      <div className="text-[10px] text-slate-400 uppercase font-semibold">False Negative (FN)</div>
                      <div className="text-2xl font-bold text-red-400 mt-1">26</div>
                      <div className="text-[11px] text-red-300/80">Missed spam (let through)</div>
                    </div>
                    <div className="p-4 rounded-lg bg-blue-950/40 border border-blue-800/50">
                      <div className="text-[10px] text-slate-400 uppercase font-semibold">True Positive (TP)</div>
                      <div className="text-2xl font-bold text-blue-400 mt-1">123</div>
                      <div className="text-[11px] text-blue-300/80">Spam correctly blocked</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Model Comparison Bar Chart Output */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-slate-100 text-sm sm:text-base">
                  Combined Model Comparison Chart (Section 8 Output)
                </h3>
                <button
                  onClick={() => setSelectedImageModal('/outputs/model_comparison.png')}
                  className="text-xs text-blue-400 hover:text-blue-300 font-medium"
                >
                  Enlarge Chart 🔍
                </button>
              </div>
              <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950 flex items-center justify-center p-3">
                <img
                  src="/outputs/model_comparison.png"
                  alt="Model Performance Comparison"
                  className="w-full max-h-80 object-contain rounded-lg hover:scale-101 transition duration-300 cursor-pointer"
                  onClick={() => setSelectedImageModal('/outputs/model_comparison.png')}
                />
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 4: WHY RECALL MATTERS (INTERNSHIP SECTION 9) */}
        {/* ========================================================================= */}
        {activeTab === 'recall' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-blue-950/60 to-slate-900 border border-blue-500/30 rounded-2xl p-6">
              <h2 className="text-2xl font-bold text-white flex items-center space-x-2.5">
                <AlertTriangle className="w-6 h-6 text-amber-400" />
                <span>Why is Recall Particularly Important for Spam Detection?</span>
              </h2>
              <p className="text-sm text-slate-300 mt-2 max-w-3xl leading-relaxed">
                A dedicated exploration of the engineering trade-offs, asymmetric error costs, and why evaluating recall in tandem with precision is paramount for digital communications.
              </p>
            </div>

            {/* Two Types of Errors Explained */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* False Negative / Low Recall */}
              <div className="bg-slate-900 border border-red-500/30 rounded-2xl p-6">
                <div className="flex items-center space-x-2 text-red-400 font-bold text-base mb-3">
                  <span className="w-7 h-7 rounded-lg bg-red-500/20 flex items-center justify-center text-sm">FN</span>
                  <h3>Low Recall: False Negatives</h3>
                </div>
                <div className="space-y-3 text-xs sm:text-sm text-slate-300 leading-relaxed">
                  <p>
                    <span className="font-semibold text-white">What it means:</span> An incoming spam or malicious message is classified as legitimate ham and delivered directly to the user's primary inbox.
                  </p>
                  <div className="p-3 bg-red-950/40 border border-red-900/50 rounded-xl space-y-1.5 text-xs text-red-200">
                    <div className="font-semibold text-red-300">Consequences:</div>
                    <ul className="list-disc list-inside space-y-1 text-slate-300">
                      <li>Credential phishing attempts tricking users to disclose passwords.</li>
                      <li>Banking trojans and malware APK download links sent via SMS.</li>
                      <li>Inconvenience, cognitive fatigue, and inbox clutter.</li>
                    </ul>
                  </div>
                  <p className="text-slate-400 text-xs">
                    In our test set, Naive Bayes had <strong className="text-white">19 FN</strong> and Logistic Regression had <strong className="text-white">26 FN</strong>.
                  </p>
                </div>
              </div>

              {/* False Positive / Low Precision */}
              <div className="bg-slate-900 border border-amber-500/30 rounded-2xl p-6">
                <div className="flex items-center space-x-2 text-amber-400 font-bold text-base mb-3">
                  <span className="w-7 h-7 rounded-lg bg-amber-500/20 flex items-center justify-center text-sm">FP</span>
                  <h3>Low Precision: False Positives</h3>
                </div>
                <div className="space-y-3 text-xs sm:text-sm text-slate-300 leading-relaxed">
                  <p>
                    <span className="font-semibold text-white">What it means:</span> A genuine, legitimate message (ham) is incorrectly flagged as spam and moved to quarantine or silently dropped.
                  </p>
                  <div className="p-3 bg-amber-950/40 border border-amber-900/50 rounded-xl space-y-1.5 text-xs text-amber-200">
                    <div className="font-semibold text-amber-300">Consequences:</div>
                    <ul className="list-disc list-inside space-y-1 text-slate-300">
                      <li>Missed job offers, college admissions, or legal notices.</li>
                      <li>Blocked Two-Factor Authentication (2FA) SMS codes.</li>
                      <li>Lost emergency contact from hospital or family.</li>
                    </ul>
                  </div>
                  <p className="text-slate-400 text-xs">
                    In our test set, Logistic Regression achieved <strong className="text-emerald-400 font-mono">0 False Positives</strong> (100% Precision), while Naive Bayes had only <strong className="text-white">1 FP</strong> out of 966 ham!
                  </p>
                </div>
              </div>
            </div>

            {/* Industrial Real-World Synthesis */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <CheckCircle2 className="w-5 h-5 text-blue-400" />
                <span>The Industry Trade-Off: Precision vs. Recall</span>
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs sm:text-sm text-slate-300">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="font-bold text-slate-100 mb-1">1. User Tolerance Asymmetry</div>
                  <p className="text-slate-400 text-xs leading-relaxed">
                    Users dislike seeing spam in their inbox, but they will never forgive an email client that swallows an essential flight cancellation notice or OTP code. Hence, high precision is an absolute prerequisite.
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="font-bold text-slate-100 mb-1">2. Threshold Calibration</div>
                  <p className="text-slate-400 text-xs leading-relaxed">
                    Production systems adjust the probability threshold (e.g. require &gt;80% confidence before quarantining) to safeguard precision while maintaining recall above 85-90%.
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="font-bold text-slate-100 mb-1">3. The F1-Score Metric</div>
                  <p className="text-slate-400 text-xs leading-relaxed">
                    Because Accuracy is bloated by the 86.6% majority Ham class, the F1-Score (harmonic mean of Precision & Recall) serves as the honest diagnostic North Star.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 5: UCI DATASET EXPLORER */}
        {/* ========================================================================= */}
        {activeTab === 'dataset' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white">SMS Spam Collection v.1 Explorer</h2>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  Browse authentic records from the UCI Machine Learning Repository (5,572 total messages).
                </p>
              </div>

              {/* Filters */}
              <div className="flex flex-wrap items-center gap-2.5">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search keywords..."
                    value={searchFilter}
                    onChange={(e) => setSearchFilter(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 w-44"
                  />
                </div>

                <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                  {(['all', 'ham', 'spam'] as const).map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setLabelFilter(filter)}
                      className={`px-3 py-1 rounded-lg uppercase font-semibold text-[11px] transition ${
                        labelFilter === filter
                          ? 'bg-blue-600 text-white'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Dataset Table */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs sm:text-sm">
                  <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4 w-16">#</th>
                      <th className="py-3 px-4 w-28">Label</th>
                      <th className="py-3 px-4">Message Text</th>
                      <th className="py-3 px-4 w-24 text-right">Length</th>
                      <th className="py-3 px-4 w-24 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    {filteredDataset.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-850/50 transition">
                        <td className="py-3 px-4 font-mono text-slate-500 text-xs">{idx + 1}</td>
                        <td className="py-3 px-4">
                          <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            row.label === 'spam'
                              ? 'bg-red-500/15 text-red-400 border border-red-500/30'
                              : 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          }`}>
                            {row.label}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-200 font-normal leading-relaxed">
                          {row.message}
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-slate-400 text-xs">
                          {row.message.length} ch
                        </td>
                        <td className="py-3 px-4 text-center">
                          <button
                            onClick={() => {
                              setInputMessage(row.message);
                              setActiveTab('playground');
                            }}
                            className="text-xs text-blue-400 hover:text-blue-300 font-medium hover:underline"
                          >
                            Test ➔
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 6: ARTIFACTS, CODE & GITHUB SUBMISSION CHECKLIST */}
        {/* ========================================================================= */}
        {activeTab === 'artifacts' && (
          <div className="space-y-6">
            {/* Checklist Header */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <span>Oasis Infobyte Internship Task 4 Submission Checklist</span>
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-400 mt-1">
                    All requirements from the official internship brief are 100% completed, tested, and verified.
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold">
                    15/15 Passed
                  </span>
                </div>
              </div>

              {/* Checklist Items */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs sm:text-sm">
                {[
                  'Suitable public spam dataset obtained (UCI SMS Spam Collection, 5,572 rows)',
                  'Data loaded, inspected, and missing/duplicate values quantified',
                  'Spam/ham counts (4,825 vs 747) and percentages calculated',
                  'Text preprocessing implemented with regex and context preservation',
                  'TF-IDF mathematically explained in Markdown and scikit-learn Pipeline',
                  'Train/test split completed (80/20 stratified) with zero data leakage',
                  'Multinomial Naive Bayes trained with Laplace smoothing',
                  'Logistic Regression trained with L2 regularization',
                  'Linear Support Vector Machine evaluated as bonus model',
                  'Accuracy, precision, recall, F1-scores, and confusion matrices calculated',
                  'Why recall matters analyzed in dedicated Markdown section',
                  'Output charts saved to outputs/ directory in high resolution',
                  'WordClouds and frequency distributions generated',
                  'Clean, commented, reproducible Jupyter Notebook (Spam_Detection.ipynb)',
                  'Comprehensive README.md and requirements.txt provided'
                ].map((item, idx) => (
                  <div key={idx} className="flex items-start space-x-2.5 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span className="text-slate-300 text-xs">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Terminal & Git Commands */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <Terminal className="w-4 h-4 text-blue-400" />
                  <h3 className="font-bold text-slate-200 text-sm">Git Submission & Reproduction Commands</h3>
                </div>
                <button
                  onClick={() => handleCopy(
                    `git add OIBSIP/DataScience/Task4_Spam_Detection/\ngit commit -m "feat(task4): complete SMS/Email spam detection NLP project with EDA, Naive Bayes, Logistic Regression, and evaluation"`,
                    'git-cmd'
                  )}
                  className="text-xs text-slate-400 hover:text-white flex items-center space-x-1"
                >
                  {copiedCode === 'git-cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode === 'git-cmd' ? 'Copied' : 'Copy Git Commands'}</span>
                </button>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 space-y-1.5 overflow-x-auto">
                <div className="text-slate-500"># Navigate to internship task directory:</div>
                <div className="text-blue-300">cd OIBSIP/DataScience/Task4_Spam_Detection</div>
                <div className="text-slate-500 mt-2"># Install dependencies & execute pipeline:</div>
                <div className="text-emerald-300">pip install -r requirements.txt</div>
                <div className="text-emerald-300">python3 run_pipeline.py</div>
                <div className="text-slate-500 mt-2"># Launch Jupyter Notebook:</div>
                <div className="text-purple-300">jupyter notebook Spam_Detection.ipynb</div>
                <div className="text-slate-500 mt-2"># Git commit:</div>
                <div>git add OIBSIP/DataScience/Task4_Spam_Detection/</div>
                <div>git commit -m &quot;feat(task4): complete SMS/Email spam detection NLP project&quot;</div>
              </div>
            </div>

            {/* Files & Download Links */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <h3 className="font-bold text-slate-200 text-sm mb-3">Project Deliverables & File Index</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <a
                  href="/downloads/Spam_Detection.ipynb"
                  download="Spam_Detection.ipynb"
                  className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-blue-500/50 transition flex items-center space-x-3 group"
                >
                  <FileCode className="w-7 h-7 text-blue-400 shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-slate-200 group-hover:text-blue-400 transition">Spam_Detection.ipynb</div>
                    <div className="text-[11px] text-slate-500">26 cells • 12 sections</div>
                  </div>
                </a>

                <a
                  href="/downloads/README.md"
                  download="README.md"
                  className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500/50 transition flex items-center space-x-3 group"
                >
                  <FileText className="w-7 h-7 text-emerald-400 shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-slate-200 group-hover:text-emerald-400 transition">README.md</div>
                    <div className="text-[11px] text-slate-500">Markdown docs & guide</div>
                  </div>
                </a>

                <a
                  href="/downloads/requirements.txt"
                  download="requirements.txt"
                  className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-purple-500/50 transition flex items-center space-x-3 group"
                >
                  <Terminal className="w-7 h-7 text-purple-400 shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-slate-200 group-hover:text-purple-400 transition">requirements.txt</div>
                    <div className="text-[11px] text-slate-500">Python pip dependencies</div>
                  </div>
                </a>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Image Modal for Fullscreen Chart Inspection */}
      {selectedImageModal && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200"
          onClick={() => setSelectedImageModal(null)}
        >
          <div
            className="max-w-4xl w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-3 pb-2 border-b border-slate-800">
              <span className="text-xs font-mono text-slate-400">{selectedImageModal}</span>
              <button
                onClick={() => setSelectedImageModal(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800 hover:bg-slate-700"
              >
                Close ✕
              </button>
            </div>
            <div className="flex justify-center bg-white p-2 rounded-xl">
              <img
                src={selectedImageModal}
                alt="Enlarged chart"
                className="max-h-[75vh] w-auto object-contain"
              />
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-4 text-xs text-slate-500 text-center">
        <p>
          Oasis Infobyte (OIBSIP) Data Science Internship — Task 4: Email / SMS Spam Detection • Built with Python, Scikit-Learn, and React
        </p>
      </footer>
    </div>
  );
}
