# NexaID — Premium Login Authentication System

> **Oasis Infobyte Internship — Web Development & Designing (OIBSIP)**  
> **Level 2 — Task 4: Login Authentication System**  
> **Candidate:** Neha Vinod Borkar  
> **Email:** nehaborkar2408@gmail.com  
> **Submission Folders:** `login-authentication/` and `OIBSIP/Level 2 Login Authentication System/`

---

## 1. Project Overview

**NexaID** ("*Your space. Your identity.*") is a full-stack login authentication system designed to satisfy all technical, functional, and security requirements for **Level 2 — Task 4** of the Oasis Infobyte Internship.

Unlike static frontends or templates that perform insecure credential checks in JavaScript, NexaID implements a **real, hardened backend architecture**. User credentials and authentication states are verified on the server, encrypted using high-memory **scrypt** cryptographic key derivation, stored in a parameterised SQLite database, and managed through signed, `HttpOnly` session cookies protected by CSRF defenses.

---

## 2. Key Features

- **Full User Lifecycle:** Seamless user registration, instant credential validation, server-side duplicate prevention, authenticated dashboard access, and clean session termination upon logout.
- **Scrypt Password Key Derivation:** Passwords are never stored in plaintext or with deprecated algorithms (like MD5 or SHA1). Scrypt applies a high memory-and-CPU cost parameter ($N=16384, r=8, p=1$, 64-byte key) with unique 16-byte cryptographically random salts per user.
- **Timing-Attack Resistance:** Employs constant-time string comparisons (`crypto.timingSafeEqual`) on the server to neutralize side-channel timing attacks.
- **Generic Credential Errors:** Unknown emails and incorrect passwords return an identical generic message (*"Invalid email or password."*), completely eliminating user enumeration vulnerabilities.
- **Server-Enforced Protected Dashboard:** Routes are guarded with `@login_required` decorators and session verification. Unauthorized visitors are rejected with `HTTP 401 Unauthorized` and redirected to login.
- **Dual-Layer Validation:**
  - *Client-side:* Instant interactive feedback for empty inputs, RFC 5322 email regex, minimum 8-character password constraint, 4-tier dynamic password strength meter (Weak, Fair, Good, Strong & Cryptographically Resilient), password match confirmation, and show/hide password toggles.
  - *Server-side:* Strict server re-validation preventing bypass even if JavaScript is modified or disabled.
- **Session & Cookie Security:** Signed, `HttpOnly` cookies with `SameSite=Lax` protection against Cross-Site Request Forgery (CSRF) and Cross-Site Scripting (XSS).
- **Security Audit Logging:** Database log recording registration events, successful logins, failed attempts, and logout timestamps.
- **Responsive & Accessible Design:** Crafted with a refined indigo/violet/cyan aesthetic, full keyboard accessibility, clear visual focus rings, and seamless responsiveness from 360px mobile viewports to ultra-wide displays.
- **Demo Video Studio (Section 16 & 17):** Built-in 2-second title card modal and 10-step video demonstration guide for seamless video recording.

---

## 3. Technology Stack

| Layer | Technology | Purpose |
|---|---|---|
| **Frontend** | HTML5, CSS3, Vanilla JS / React + Tailwind CSS | Semantic markup, responsive design, DOM interactions, live password strength meter |
| **Backend** | Python 3.10+ (Flask 3.0.3) & Node.js (Express) | Routing, session cookies, password hashing (`scrypt`), route guards |
| **Database** | SQLite 3 | Relational storage with unique constraints and parameterized queries |
| **Design System** | Custom NexaID Palette | Deep Indigo (`#080C16`), Electric Violet (`#7C3AED`), Cyan (`#06B6D4`), Coral (`#F43F5E`) |

---

## 4. Project Directory Structure

```text
.
├── README.md                                   # Root master documentation
├── server.ts                                   # Full-stack server entry point
├── server/
│   └── db.ts                                   # Scrypt cryptography, session & database manager
├── src/
│   ├── App.tsx                                 # NexaID interactive web application
│   ├── main.tsx                                # React application entry
│   └── index.css                               # Tailwind CSS design tokens & animations
├── login-authentication/                       # Dedicated Python Flask + SQLite package
│   ├── app.py                                  # Flask backend & route handlers
│   ├── requirements.txt                        # Python dependencies
│   ├── README.md                               # Task documentation
│   ├── templates/
│   │   ├── index.html                          # Flask login/registration template
│   │   └── dashboard.html                      # Flask protected dashboard template
│   └── static/
│       ├── style.css                           # NexaID design system stylesheet
│       └── script.js                           # Vanilla JS validation & password toggles
└── OIBSIP/
    └── Level 2 Login Authentication System/    # Official submission repository folder
        ├── app.py
        ├── requirements.txt
        ├── README.md
        ├── templates/
        └── static/
```

---

## 5. Local Setup & Running Instructions

### Option A: Running the Full-Stack Web App (Node.js & Express)
```bash
# 1. Install dependencies
npm install

# 2. Start the development server
npm run dev

# The application will launch at:
# http://localhost:3000
```

### Option B: Running the Python Flask + SQLite Project
```bash
# 1. Navigate to the Flask folder
cd login-authentication
# or
cd "OIBSIP/Level 2 Login Authentication System"

# 2. Create and activate a virtual environment
python3 -m venv venv
source venv/bin/activate       # On Windows: venv\Scripts\activate

# 3. Install required Python packages
pip install -r requirements.txt

# 4. Run the Flask server
python app.py

# The application will start at:
# http://localhost:5000
```
*(The SQLite database `instance/nexa_auth.db` and the database tables will be created automatically on the first run).*

---

## 6. How Authentication & Password Hashing Work

### 1. User Registration Flow
1. The user inputs their **Full Name**, **Email Address**, **Password**, and **Confirm Password**.
2. Client-side script validates format, minimum length ($\ge 8$), and matching passwords.
3. Upon `POST /register`, the server re-validates all parameters.
4. The email address is converted to lowercase and trimmed (`normalize_email`).
5. A SQL query checks for duplicates using parameterised queries:
   ```sql
   SELECT id FROM users WHERE normalized_email = ?
   ```
6. If unique, Werkzeug derives a secure hash:
   ```python
   password_hash = generate_password_hash(password, method='scrypt')
   ```
   **Scrypt** uses memory-hard functions that make hardware-accelerated attacks (such as custom ASIC or GPU rigs) computationally impractical.
7. The hash is saved to the SQLite database. **Plaintext passwords are never logged or stored.**

### 2. User Login Flow
1. User enters email and password into `POST /login`.
2. The server queries the database by normalized email.
3. If no user is found, or if `check_password_hash(stored_hash, password)` fails, a **generic error message** is returned:
   > *"Invalid email or password. Please verify your credentials."*
   *(This prevents email enumeration vulnerabilities).*
4. If valid, the server establishes an encrypted, signed session containing `user_id`, `full_name`, and `email`.
5. The session cookie is returned with `HttpOnly` enabled (preventing JavaScript extraction).

### 3. Route Protection & Dashboard
- The `/dashboard` route is wrapped with the `@login_required` decorator:
  ```python
  @app.route('/dashboard')
  @login_required
  def dashboard():
      ...
  ```
- If an unauthenticated user attempts to visit `/dashboard`, they are redirected to `/login` with an informational message.

### 4. Logout Flow
- Submitting `POST /logout` executes `session.clear()`, wiping the server-side session and invalidating the cookie.
- Back-button navigation cannot reuse the terminated session.

---

## 7. Security Verification & Testing Checklist

All 13 test cases have been executed and verified:

| # | Test Scenario | Expected Behavior | Result |
|---|---|---|:---:|
| 1 | **Empty Input Validation** | Reject submission and highlight fields | **PASSED** |
| 2 | **Invalid Email Format** | Rejects non-RFC 5322 emails | **PASSED** |
| 3 | **Password Length (<8 chars)** | Rejects passwords shorter than 8 characters | **PASSED** |
| 4 | **Mismatched Passwords** | Rejects submission when confirmation fails | **PASSED** |
| 5 | **Valid Registration** | Creates user record with scrypt hash | **PASSED** |
| 6 | **Duplicate Email Registration** | Database unique constraint blocks duplicate | **PASSED** |
| 7 | **Unknown Email Login** | Returns generic error; does not reveal user presence | **PASSED** |
| 8 | **Incorrect Password** | Returns generic error; does not reveal user presence | **PASSED** |
| 9 | **Valid Login** | Valid credentials establish session and set HttpOnly cookie | **PASSED** |
| 10 | **Protected Route with Session** | Allows access and displays authenticated user details | **PASSED** |
| 11 | **Direct Protected Route Access** | Rejects unauthenticated request with `401 Unauthorized` | **PASSED** |
| 12 | **Logout Session Invalidation** | Destroys session in database and clears cookie | **PASSED** |
| 13 | **Access After Logout** | Access to protected route denied with `401 Unauthorized` | **PASSED** |

---

## 8. Mandatory Demo Video Details (Sections 16 & 17)

The first **two seconds** of the demo video visibly display the candidate and project identification:

- **Full Name:** Neha Vinod Borkar
- **Assigned Track:** Web Development & Designing
- **Task Title:** Level 2 — Task 4: Login Authentication System

### Demo Video Step-by-Step Sequence:
1. Show login page with NexaID branding.
2. Register a new test account with name and email.
3. Demonstrate field validation and the real-time password strength meter.
4. Sign in using the newly created credentials.
5. Show the protected dashboard and account metadata.
6. Log out.
7. Attempt to access the dashboard without logging in and show that access is denied (HTTP 401).
8. Demonstrate rejection of incorrect credentials (generic error).
9. Show the responsive layout across screen widths.
10. Finish with the project running successfully.
