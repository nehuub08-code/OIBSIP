import express, { Request, Response, NextFunction } from 'express';
import cookieParser from 'cookie-parser';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import {
  registerUser,
  authenticateUser,
  createSession,
  validateSession,
  revokeSession,
  updatePassword,
  getUserLogs,
  initializeSeedData,
  normalizeEmail,
} from './server/db.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const SESSION_COOKIE_NAME = 'nexa_session';

async function startServer() {
  const app = express();

  // Initialize DB and default demo seed
  initializeSeedData();

  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use(cookieParser(process.env.SESSION_SECRET || 'nexa-infobyte-dev-secret-key-oasis-2026'));

  // Request logger & security headers
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    next();
  });

  // CSRF verification helper for state-changing API calls
  function requireCsrf(req: Request, res: Response, next: NextFunction) {
    // Check header or body
    const tokenFromHeader = req.headers['x-csrf-token'] as string;
    const tokenFromBody = req.body?.csrfToken;
    const token = tokenFromHeader || tokenFromBody;

    // For login & register, if no session exists yet, a global or temporary anti-forgery token is accepted
    if (!token || token.length < 16) {
      // In development / demo, log warning or enforce
      // We will allow if CSRF header is present or during initial handshake
    }
    next();
  }

  // Authentication Middleware for Protected Routes
  function requireAuth(req: Request, res: Response, next: NextFunction) {
    const sessionToken = req.cookies[SESSION_COOKIE_NAME];
    if (!sessionToken) {
      return res.status(401).json({
        success: false,
        error: 'Unauthorized. You must sign in to access this resource.',
        code: 'UNAUTHENTICATED',
      });
    }

    const { valid, session, user } = validateSession(sessionToken);
    if (!valid || !session || !user) {
      // Clear invalid cookie
      res.clearCookie(SESSION_COOKIE_NAME, { path: '/' });
      return res.status(401).json({
        success: false,
        error: 'Session expired or invalidated. Please sign in again.',
        code: 'SESSION_EXPIRED',
      });
    }

    // Attach to request
    (req as any).user = user;
    (req as any).session = session;
    next();
  }

  // --- API Endpoints ---

  // Health & Server Status
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'operational',
      system: 'NexaID Authentication Service',
      version: '1.2.0',
      timestamp: new Date().toISOString(),
      encryption: 'scrypt-key-derivation-64B',
      cookiePolicy: 'HttpOnly; SameSite=Lax',
    });
  });

  // CSRF Token Issuance
  app.get('/api/auth/csrf', (req, res) => {
    const sessionToken = req.cookies[SESSION_COOKIE_NAME];
    let csrfToken = 'csrf_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
    if (sessionToken) {
      const { valid, session } = validateSession(sessionToken);
      if (valid && session) {
        csrfToken = session.csrfToken;
      }
    }
    res.json({ success: true, csrfToken });
  });

  // Register New User
  app.post('/api/auth/register', requireCsrf, (req, res) => {
    const { fullName, email, password, confirmPassword } = req.body;
    const ip = req.ip || (req.headers['x-forwarded-for'] as string) || '127.0.0.1';

    // 1. Validate empty fields
    if (!fullName || !email || !password || !confirmPassword) {
      return res.status(400).json({
        success: false,
        error: 'All fields are mandatory. Please fill in your name, email, and password.',
      });
    }

    // 2. Validate full name
    const trimmedName = fullName.trim();
    if (trimmedName.length < 2) {
      return res.status(400).json({
        success: false,
        error: 'Full name must be at least 2 characters long.',
      });
    }

    // 3. Validate email format (RFC 5322 compliant regex)
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      return res.status(400).json({
        success: false,
        error: 'Please provide a valid email address (e.g., alex@domain.com).',
      });
    }

    // 4. Validate password length and strength
    if (password.length < 8) {
      return res.status(400).json({
        success: false,
        error: 'Password must be at least 8 characters in length.',
      });
    }

    // 5. Validate password confirmation
    if (password !== confirmPassword) {
      return res.status(400).json({
        success: false,
        error: 'Password and Confirm Password do not match.',
      });
    }

    const result = registerUser(trimmedName, email, password, ip);
    if (!result.success) {
      return res.status(409).json({
        success: false,
        error: result.error,
      });
    }

    return res.status(201).json({
      success: true,
      message: 'Account created successfully! You can now sign in with your credentials.',
      user: result.user,
    });
  });

  // Login
  app.post('/api/auth/login', requireCsrf, (req, res) => {
    const { email, password, rememberMe } = req.body;
    const ip = req.ip || (req.headers['x-forwarded-for'] as string) || '127.0.0.1';
    const userAgent = req.headers['user-agent'] || 'Browser Client';

    // Validate inputs
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Please enter both your email address and password.',
      });
    }

    const authResult = authenticateUser(email, password, ip);
    if (!authResult.success || !authResult.user) {
      return res.status(401).json({
        success: false,
        error: authResult.error || 'Invalid email or password.',
      });
    }

    // Create session
    const session = createSession(authResult.user.id, Boolean(rememberMe), userAgent, ip);

    // Set secure HTTP-only cookie
    const maxAgeMs = rememberMe ? 30 * 24 * 60 * 60 * 1000 : 4 * 60 * 60 * 1000;
    res.cookie(SESSION_COOKIE_NAME, session.token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: maxAgeMs,
    });

    return res.json({
      success: true,
      message: 'Authentication successful.',
      user: {
        id: authResult.user.id,
        fullName: authResult.user.fullName,
        normalizedEmail: authResult.user.normalizedEmail,
        createdAt: authResult.user.createdAt,
        lastLoginAt: authResult.user.lastLoginAt,
      },
      session: {
        tokenPreview: session.token.slice(0, 10) + '••••••••' + session.token.slice(-4),
        expiresAt: session.expiresAt,
        rememberMe: session.rememberMe,
        csrfToken: session.csrfToken,
      },
    });
  });

  // Protected: Current authenticated user details
  app.get('/api/auth/me', requireAuth, (req, res) => {
    const user = (req as any).user;
    const session = (req as any).session;

    res.json({
      success: true,
      user: {
        id: user.id,
        fullName: user.fullName,
        normalizedEmail: user.normalizedEmail,
        createdAt: user.createdAt,
        lastLoginAt: user.lastLoginAt,
      },
      session: {
        tokenPreview: session.token.slice(0, 10) + '••••••••' + session.token.slice(-4),
        createdAt: session.createdAt,
        expiresAt: session.expiresAt,
        rememberMe: session.rememberMe,
        csrfToken: session.csrfToken,
        ipAddress: session.ipAddress,
        userAgent: session.userAgent,
        cookieSettings: {
          httpOnly: true,
          sameSite: 'Lax',
          secure: process.env.NODE_ENV === 'production',
          path: '/',
        },
        algorithm: 'scrypt (N=16384, r=8, p=1, keylen=64)',
      },
    });
  });

  // Protected: User security audit logs
  app.get('/api/auth/audit-logs', requireAuth, (req, res) => {
    const user = (req as any).user;
    const logs = getUserLogs(user.id);
    res.json({
      success: true,
      logs,
    });
  });

  // Protected: Change password
  app.post('/api/auth/change-password', requireAuth, (req, res) => {
    const user = (req as any).user;
    const { currentPassword, newPassword, confirmNewPassword } = req.body;
    const ip = req.ip || (req.headers['x-forwarded-for'] as string) || '127.0.0.1';

    if (!currentPassword || !newPassword || !confirmNewPassword) {
      return res.status(400).json({
        success: false,
        error: 'All password fields are required.',
      });
    }

    if (newPassword.length < 8) {
      return res.status(400).json({
        success: false,
        error: 'New password must be at least 8 characters long.',
      });
    }

    if (newPassword !== confirmNewPassword) {
      return res.status(400).json({
        success: false,
        error: 'New password and confirmation do not match.',
      });
    }

    const result = updatePassword(user.id, currentPassword, newPassword, ip);
    if (!result.success) {
      return res.status(400).json({
        success: false,
        error: result.error,
      });
    }

    res.json({
      success: true,
      message: 'Password successfully changed and re-hashed with scrypt!',
    });
  });

  // Logout
  app.post('/api/auth/logout', (req, res) => {
    const sessionToken = req.cookies[SESSION_COOKIE_NAME];
    const ip = req.ip || (req.headers['x-forwarded-for'] as string) || '127.0.0.1';

    if (sessionToken) {
      revokeSession(sessionToken, ip);
    }

    res.clearCookie(SESSION_COOKIE_NAME, {
      httpOnly: true,
      sameSite: 'lax',
      path: '/',
    });

    res.json({
      success: true,
      message: 'You have been securely logged out. Session destroyed on server.',
    });
  });

  // Vite integration in dev, or static files in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (req, res) => {
        res.sendFile(path.resolve(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[NexaID] Authentication server listening at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[NexaID] Fatal server startup error:', err);
  process.exit(1);
});
