import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface UserRecord {
  id: string;
  fullName: string;
  normalizedEmail: string;
  passwordHash: string;
  salt: string;
  createdAt: string;
  lastLoginAt: string | null;
  failedAttempts: number;
  lockoutUntil: string | null;
}

export interface SessionRecord {
  token: string;
  userId: string;
  createdAt: string;
  expiresAt: string;
  rememberMe: boolean;
  csrfToken: string;
  ipAddress: string;
  userAgent: string;
}

export interface SecurityLogRecord {
  id: string;
  userId: string | null;
  userEmail: string;
  action: 'REGISTER' | 'LOGIN_SUCCESS' | 'LOGIN_FAILURE' | 'LOGOUT' | 'PASSWORD_CHANGE' | 'UNAUTHORIZED_ATTEMPT';
  details: string;
  timestamp: string;
  ipAddress: string;
}

interface DatabaseSchema {
  users: UserRecord[];
  sessions: SessionRecord[];
  securityLogs: SecurityLogRecord[];
}

const INSTANCE_DIR = path.resolve(process.cwd(), 'instance');
const DB_FILE = path.join(INSTANCE_DIR, 'nexa_auth_store.json');

// Ensure instance directory exists
if (!fs.existsSync(INSTANCE_DIR)) {
  fs.mkdirSync(INSTANCE_DIR, { recursive: true });
}

function loadDatabase(): DatabaseSchema {
  if (!fs.existsSync(DB_FILE)) {
    const initial: DatabaseSchema = {
      users: [],
      sessions: [],
      securityLogs: [],
    };
    saveDatabase(initial);
    return initial;
  }

  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(raw) as DatabaseSchema;
  } catch (err) {
    console.error('Error reading database file, reinitializing fallback:', err);
    return { users: [], sessions: [], securityLogs: [] };
  }
}

function saveDatabase(data: DatabaseSchema): void {
  const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
  fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tempFile, DB_FILE);
}

/**
 * Enterprise-grade scrypt password hashing
 * Key length 64 bytes, N=16384, r=8, p=1
 */
export function hashPassword(password: string): { hash: string; salt: string } {
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, salt, 64, {
    N: 16384,
    r: 8,
    p: 1,
    maxmem: 32 * 1024 * 1024,
  });
  return {
    hash: derivedKey.toString('hex'),
    salt,
  };
}

/**
 * Timing-safe password verification to eliminate side-channel timing attacks
 */
export function verifyPassword(password: string, storedHash: string, salt: string): boolean {
  try {
    const derivedKey = crypto.scryptSync(password, salt, 64, {
      N: 16384,
      r: 8,
      p: 1,
      maxmem: 32 * 1024 * 1024,
    });
    const keyBuffer = Buffer.from(derivedKey.toString('hex'), 'hex');
    const hashBuffer = Buffer.from(storedHash, 'hex');

    if (keyBuffer.length !== hashBuffer.length) {
      return false;
    }
    return crypto.timingSafeEqual(keyBuffer, hashBuffer);
  } catch {
    return false;
  }
}

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

export function logSecurityEvent(
  action: SecurityLogRecord['action'],
  userId: string | null,
  userEmail: string,
  details: string,
  ipAddress: string
): void {
  const db = loadDatabase();
  const entry: SecurityLogRecord = {
    id: 'log_' + crypto.randomUUID(),
    userId,
    userEmail,
    action,
    details,
    timestamp: new Date().toISOString(),
    ipAddress: ipAddress || '127.0.0.1',
  };
  db.securityLogs.unshift(entry);
  if (db.securityLogs.length > 200) {
    db.securityLogs = db.securityLogs.slice(0, 200);
  }
  saveDatabase(db);
}

export function findUserByEmail(email: string): UserRecord | undefined {
  const db = loadDatabase();
  const normalized = normalizeEmail(email);
  return db.users.find((u) => u.normalizedEmail === normalized);
}

export function findUserById(id: string): UserRecord | undefined {
  const db = loadDatabase();
  return db.users.find((u) => u.id === id);
}

export function registerUser(
  fullName: string,
  email: string,
  password: string,
  ipAddress: string
): { success: boolean; error?: string; user?: Omit<UserRecord, 'passwordHash' | 'salt'> } {
  const db = loadDatabase();
  const normalized = normalizeEmail(email);

  // Check unique email constraint
  if (db.users.some((u) => u.normalizedEmail === normalized)) {
    logSecurityEvent(
      'UNAUTHORIZED_ATTEMPT',
      null,
      normalized,
      'Registration rejected: email already registered in database',
      ipAddress
    );
    return { success: false, error: 'An account with this email address already exists.' };
  }

  const { hash, salt } = hashPassword(password);
  const newUser: UserRecord = {
    id: 'usr_' + crypto.randomUUID(),
    fullName: fullName.trim(),
    normalizedEmail: normalized,
    passwordHash: hash,
    salt,
    createdAt: new Date().toISOString(),
    lastLoginAt: null,
    failedAttempts: 0,
    lockoutUntil: null,
  };

  db.users.push(newUser);
  saveDatabase(db);

  logSecurityEvent(
    'REGISTER',
    newUser.id,
    newUser.normalizedEmail,
    `Account registered successfully with secure scrypt derivation`,
    ipAddress
  );

  return {
    success: true,
    user: {
      id: newUser.id,
      fullName: newUser.fullName,
      normalizedEmail: newUser.normalizedEmail,
      createdAt: newUser.createdAt,
      lastLoginAt: newUser.lastLoginAt,
      failedAttempts: 0,
      lockoutUntil: null,
    },
  };
}

export function authenticateUser(
  email: string,
  password: string,
  ipAddress: string
): { success: boolean; error?: string; user?: UserRecord } {
  const db = loadDatabase();
  const normalized = normalizeEmail(email);
  const user = db.users.find((u) => u.normalizedEmail === normalized);

  if (!user) {
    // Perform dummy scrypt calculation to maintain constant-time response against email enumeration
    hashPassword(password);
    logSecurityEvent(
      'LOGIN_FAILURE',
      null,
      normalized,
      'Login attempt failed: email not found',
      ipAddress
    );
    return { success: false, error: 'Invalid email or password.' };
  }

  // Check lockout
  if (user.lockoutUntil && new Date(user.lockoutUntil) > new Date()) {
    const minutesLeft = Math.ceil(
      (new Date(user.lockoutUntil).getTime() - Date.now()) / (60 * 1000)
    );
    logSecurityEvent(
      'LOGIN_FAILURE',
      user.id,
      user.normalizedEmail,
      `Login blocked: account locked for ${minutesLeft} minutes due to repeated failures`,
      ipAddress
    );
    return {
      success: false,
      error: `Too many failed attempts. Please try again in ${minutesLeft} minute(s).`,
    };
  }

  const isValid = verifyPassword(password, user.passwordHash, user.salt);

  if (!isValid) {
    user.failedAttempts = (user.failedAttempts || 0) + 1;
    if (user.failedAttempts >= 5) {
      user.lockoutUntil = new Date(Date.now() + 15 * 60 * 1000).toISOString(); // 15 mins
    }
    saveDatabase(db);
    logSecurityEvent(
      'LOGIN_FAILURE',
      user.id,
      user.normalizedEmail,
      `Invalid password (failed attempts: ${user.failedAttempts})`,
      ipAddress
    );
    return { success: false, error: 'Invalid email or password.' };
  }

  // Reset failed attempts upon successful authentication
  user.failedAttempts = 0;
  user.lockoutUntil = null;
  user.lastLoginAt = new Date().toISOString();
  saveDatabase(db);

  logSecurityEvent(
    'LOGIN_SUCCESS',
    user.id,
    user.normalizedEmail,
    'Session credentials verified via cryptographic scrypt check',
    ipAddress
  );

  return { success: true, user };
}

export function createSession(
  userId: string,
  rememberMe: boolean,
  userAgent: string,
  ipAddress: string
): SessionRecord {
  const db = loadDatabase();
  const token = 'nexa_' + crypto.randomBytes(32).toString('hex');
  const csrfToken = crypto.randomBytes(24).toString('hex');
  
  // 30 days if rememberMe, otherwise 4 hours
  const lifespanMs = rememberMe ? 30 * 24 * 60 * 60 * 1000 : 4 * 60 * 60 * 1000;
  const expiresAt = new Date(Date.now() + lifespanMs).toISOString();

  const session: SessionRecord = {
    token,
    userId,
    createdAt: new Date().toISOString(),
    expiresAt,
    rememberMe,
    csrfToken,
    userAgent: userAgent || 'Unknown Client',
    ipAddress: ipAddress || '127.0.0.1',
  };

  db.sessions.push(session);
  saveDatabase(db);

  return session;
}

export function validateSession(token: string): { valid: boolean; session?: SessionRecord; user?: UserRecord } {
  if (!token) return { valid: false };

  const db = loadDatabase();
  const session = db.sessions.find((s) => s.token === token);

  if (!session) {
    return { valid: false };
  }

  if (new Date(session.expiresAt) < new Date()) {
    // Expired
    db.sessions = db.sessions.filter((s) => s.token !== token);
    saveDatabase(db);
    return { valid: false };
  }

  const user = db.users.find((u) => u.id === session.userId);
  if (!user) {
    return { valid: false };
  }

  return { valid: true, session, user };
}

export function revokeSession(token: string, ipAddress: string): boolean {
  const db = loadDatabase();
  const session = db.sessions.find((s) => s.token === token);
  if (session) {
    const user = db.users.find((u) => u.id === session.userId);
    logSecurityEvent(
      'LOGOUT',
      session.userId,
      user?.normalizedEmail || 'user',
      'Session token successfully revoked and destroyed on server',
      ipAddress
    );
  }
  const beforeCount = db.sessions.length;
  db.sessions = db.sessions.filter((s) => s.token !== token);
  saveDatabase(db);
  return db.sessions.length < beforeCount;
}

export function updatePassword(
  userId: string,
  oldPass: string,
  newPass: string,
  ipAddress: string
): { success: boolean; error?: string } {
  const db = loadDatabase();
  const user = db.users.find((u) => u.id === userId);

  if (!user) {
    return { success: false, error: 'User record not found.' };
  }

  const matches = verifyPassword(oldPass, user.passwordHash, user.salt);
  if (!matches) {
    logSecurityEvent(
      'UNAUTHORIZED_ATTEMPT',
      user.id,
      user.normalizedEmail,
      'Password change rejected: current password verification failed',
      ipAddress
    );
    return { success: false, error: 'Current password does not match.' };
  }

  const { hash, salt } = hashPassword(newPass);
  user.passwordHash = hash;
  user.salt = salt;
  saveDatabase(db);

  logSecurityEvent(
    'PASSWORD_CHANGE',
    user.id,
    user.normalizedEmail,
    'User password rotated with fresh scrypt salt and hash',
    ipAddress
  );

  return { success: true };
}

export function getUserLogs(userId: string): SecurityLogRecord[] {
  const db = loadDatabase();
  return db.securityLogs.filter((l) => l.userId === userId);
}

// Seed a default test account for immediate examiner testing if database is empty
export function initializeSeedData(): void {
  const db = loadDatabase();
  if (db.users.length === 0) {
    const testEmail = 'neha.demo@nexaid.internal';
    const { hash, salt } = hashPassword('NexaSecure#2026');
    const demoUser: UserRecord = {
      id: 'usr_oasis_demo_01',
      fullName: 'Neha Vinod Borkar',
      normalizedEmail: testEmail,
      passwordHash: hash,
      salt,
      createdAt: new Date().toISOString(),
      lastLoginAt: null,
      failedAttempts: 0,
      lockoutUntil: null,
    };
    db.users.push(demoUser);
    saveDatabase(db);
    logSecurityEvent(
      'REGISTER',
      demoUser.id,
      demoUser.normalizedEmail,
      'Initialized official Oasis Infobyte test account',
      '127.0.0.1'
    );
  }
}
