/**
 * NexaID Authentication System Frontend Script
 * Oasis Infobyte Internship — Level 2, Task 4
 * Candidate: Neha Vinod Borkar
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Password Visibility Toggles
  const toggleButtons = document.querySelectorAll('.btn-toggle-pass');
  toggleButtons.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = btn.getAttribute('data-target');
      const input = document.getElementById(targetId);
      if (!input) return;

      const isPassword = input.getAttribute('type') === 'password';
      input.setAttribute('type', isPassword ? 'text' : 'password');

      // Update icon visual
      if (isPassword) {
        btn.innerHTML = `
          <svg class="icon-eye-off" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
            <line x1="1" y1="1" x2="23" y2="23"/>
          </svg>
        `;
      } else {
        btn.innerHTML = `
          <svg class="icon-eye" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
            <circle cx="12" cy="12" r="3"/>
          </svg>
        `;
      }
    });
  });

  // 2. Client-side Form Validation for Login
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      const emailInput = document.getElementById('loginEmail');
      const passInput = document.getElementById('loginPassword');
      const emailErr = document.getElementById('loginEmailError');
      const passErr = document.getElementById('loginPasswordError');
      const submitBtn = document.getElementById('btnSignIn');

      let isValid = true;
      emailErr.textContent = '';
      emailErr.classList.remove('visible');
      passErr.textContent = '';
      passErr.classList.remove('visible');

      const emailVal = emailInput.value.trim();
      const passVal = passInput.value;

      if (!emailVal) {
        emailErr.textContent = 'Email address is required.';
        emailErr.classList.add('visible');
        isValid = false;
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailVal)) {
        emailErr.textContent = 'Please enter a valid email address.';
        emailErr.classList.add('visible');
        isValid = false;
      }

      if (!passVal) {
        passErr.textContent = 'Password is required.';
        passErr.classList.add('visible');
        isValid = false;
      }

      if (!isValid) {
        e.preventDefault();
        return;
      }

      // Prevent duplicate submission
      submitBtn.disabled = true;
      submitBtn.querySelector('.btn-text').textContent = 'Signing in...';
    });
  }

  // 3. Client-side Form Validation & Password Strength for Register
  const registerForm = document.getElementById('registerForm');
  const regPassword = document.getElementById('regPassword');
  const strengthMeter = document.getElementById('strengthMeter');

  if (regPassword && strengthMeter) {
    regPassword.addEventListener('input', () => {
      const val = regPassword.value;
      const segs = [
        document.getElementById('seg1'),
        document.getElementById('seg2'),
        document.getElementById('seg3'),
        document.getElementById('seg4'),
      ];
      const text = document.getElementById('strengthText');

      // Reset colors
      segs.forEach(s => s.style.background = '#334155');

      if (!val) {
        text.textContent = 'Password Strength: Minimum 8 characters';
        return;
      }

      let score = 0;
      if (val.length >= 8) score++;
      if (/[A-Z]/.test(val) && /[a-z]/.test(val)) score++;
      if (/[0-9]/.test(val)) score++;
      if (/[^A-Za-z0-9]/.test(val)) score++;

      const colors = ['#f43f5e', '#fb923c', '#eab308', '#10b981'];
      const labels = ['Weak', 'Fair', 'Good', 'Strong & Secure'];

      for (let i = 0; i < score; i++) {
        segs[i].style.background = colors[score - 1];
      }
      text.textContent = `Password Strength: ${labels[score - 1] || 'Weak'}`;
      text.style.color = colors[score - 1] || '#94a3b8';
    });
  }

  if (registerForm) {
    registerForm.addEventListener('submit', (e) => {
      const nameInput = document.getElementById('regFullName');
      const emailInput = document.getElementById('regEmail');
      const passInput = document.getElementById('regPassword');
      const confirmInput = document.getElementById('regConfirmPassword');

      const nameErr = document.getElementById('regNameError');
      const emailErr = document.getElementById('regEmailError');
      const passErr = document.getElementById('regPasswordError');
      const confirmErr = document.getElementById('regConfirmError');
      const submitBtn = document.getElementById('btnSignUp');

      let isValid = true;
      [nameErr, emailErr, passErr, confirmErr].forEach(err => {
        err.textContent = '';
        err.classList.remove('visible');
      });

      if (!nameInput.value.trim() || nameInput.value.trim().length < 2) {
        nameErr.textContent = 'Please enter your full name (minimum 2 characters).';
        nameErr.classList.add('visible');
        isValid = false;
      }

      const emailVal = emailInput.value.trim();
      if (!emailVal || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailVal)) {
        emailErr.textContent = 'Please provide a valid email address.';
        emailErr.classList.add('visible');
        isValid = false;
      }

      const passVal = passInput.value;
      if (!passVal || passVal.length < 8) {
        passErr.textContent = 'Password must be at least 8 characters long.';
        passErr.classList.add('visible');
        isValid = false;
      }

      if (passVal !== confirmInput.value) {
        confirmErr.textContent = 'Passwords do not match.';
        confirmErr.classList.add('visible');
        isValid = false;
      }

      if (!isValid) {
        e.preventDefault();
        return;
      }

      // Prevent duplicate submission
      submitBtn.disabled = true;
      submitBtn.querySelector('.btn-text').textContent = 'Creating Account...';
    });
  }
});
