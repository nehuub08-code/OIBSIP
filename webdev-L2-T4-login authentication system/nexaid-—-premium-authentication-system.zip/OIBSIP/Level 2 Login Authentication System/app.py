import os
import sqlite3
import re
import secrets
from datetime import datetime, timedelta
from functools import wraps
from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash,
    jsonify,
    g
)
from werkzeug.security import generate_password_hash, check_password_hash

# -----------------------------------------------------------------------------
# NexaID - Premium Login Authentication System
# Oasis Infobyte Internship: Web Development & Designing
# Level 2 — Task 4
# Student: Neha Vinod Borkar
# -----------------------------------------------------------------------------

app = Flask(__name__)

# Base configuration
# Never hardcode production secrets in source code. Fall back to secure random token for local dev.
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
app.config['DATABASE'] = os.path.join(app.instance_path, 'nexa_auth.db')

# Cookie security settings
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('FLASK_ENV') == 'production'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=30)

# Ensure instance directory exists
os.makedirs(app.instance_path, exist_ok=True)


# -----------------------------------------------------------------------------
# Database Setup & Utilities
# -----------------------------------------------------------------------------

def get_db():
    """Opens a connection to the SQLite database with row factory."""
    if 'db' not in g:
        g.db = sqlite3.connect(
            app.config['DATABASE'],
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception):
    """Closes the database connection at the end of the request."""
    db = g.pop('db', None)
    if db is not None:
        db.close()


def init_db():
    """Initializes SQLite schema safely."""
    db = get_db()
    cursor = db.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            normalized_email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login_at TIMESTAMP
        );
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT NOT NULL,
            details TEXT,
            ip_address TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        );
    """)
    db.commit()


# Automatically initialize schema on boot
with app.app_context():
    init_db()


def normalize_email(email: str) -> str:
    """Strips whitespace and converts email to lowercase."""
    return (email or '').strip().lower()


def is_valid_email(email: str) -> bool:
    """Validates email format using standard RFC 5322 regex."""
    pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return bool(re.match(pattern, email))


def log_audit_event(action: str, user_id=None, details="", ip="127.0.0.1"):
    """Records an audit log entry for security tracking."""
    try:
        db = get_db()
        db.execute(
            "INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)",
            (user_id, action, details, ip)
        )
        db.commit()
    except Exception as e:
        app.logger.warning(f"Could not write audit log: {e}")


# -----------------------------------------------------------------------------
# CSRF and Auth Decorators
# -----------------------------------------------------------------------------

@app.before_request
def csrf_protect():
    """Simple, transparent double-submit cookie / session token CSRF verification."""
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(24)

    if request.method == "POST":
        token = request.form.get('csrf_token') or request.headers.get('X-CSRF-Token')
        if not token or token != session.get('csrf_token'):
            # Reject state-changing requests lacking valid CSRF token
            flash("Security check failed: invalid or expired CSRF token. Please retry.", "error")
            return redirect(request.referrer or url_for('login'))


def login_required(view_func):
    """Decorator ensuring that only authenticated users can access the route."""
    @wraps(view_func)
    def wrapped_view(**kwargs):
        if 'user_id' not in session:
            flash("Access denied. Please sign in to view your NexaID dashboard.", "warning")
            return redirect(url_for('login', next=request.path))
        return view_func(**kwargs)
    return wrapped_view


# -----------------------------------------------------------------------------
# Application Routes
# -----------------------------------------------------------------------------

@app.route('/')
def root():
    """Root route redirects to dashboard if authenticated, else login."""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Handles user authentication with generic errors and scrypt verification."""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    active_tab = request.args.get('tab', 'signin')

    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        remember = bool(request.form.get('remember_me'))
        ip = request.remote_addr or '127.0.0.1'

        # 1. Validation for empty inputs
        if not email or not password:
            flash("Please enter both your email address and password.", "error")
            return render_template('index.html', active_tab='signin', email=email)

        normalized = normalize_email(email)

        # 2. Database lookup using parameterised query
        db = get_db()
        user = db.execute(
            "SELECT * FROM users WHERE normalized_email = ?",
            (normalized,)
        ).fetchone()

        # 3. Password verification
        # Generic error message avoids revealing if email exists
        if user is None or not check_password_hash(user['password_hash'], password):
            log_audit_event("LOGIN_FAILURE", None, f"Failed login attempt for {normalized}", ip)
            flash("Invalid email or password. Please verify your credentials.", "error")
            return render_template('index.html', active_tab='signin', email=email)

        # 4. Successful login: establish session
        session.permanent = remember
        session['user_id'] = user['id']
        session['full_name'] = user['full_name']
        session['email'] = user['normalized_email']
        session['login_time'] = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')

        # Update last login timestamp
        db.execute(
            "UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?",
            (user['id'],)
        )
        db.commit()

        log_audit_event("LOGIN_SUCCESS", user['id'], "User signed in successfully", ip)

        next_url = request.args.get('next')
        return redirect(next_url or url_for('dashboard'))

    return render_template('index.html', active_tab=active_tab)


@app.route('/register', methods=['GET', 'POST'])
def register():
    """Handles new user registration with input validation and secure scrypt hashing."""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        ip = request.remote_addr or '127.0.0.1'

        # 1. Reject empty fields
        if not full_name or not email or not password or not confirm_password:
            flash("All fields are mandatory. Please fill in all registration fields.", "error")
            return render_template('index.html', active_tab='signup', full_name=full_name, email=email)

        # 2. Validate full name length
        if len(full_name) < 2:
            flash("Full name must be at least 2 characters.", "error")
            return render_template('index.html', active_tab='signup', full_name=full_name, email=email)

        # 3. Validate email format
        normalized = normalize_email(email)
        if not is_valid_email(normalized):
            flash("Please enter a valid email address.", "error")
            return render_template('index.html', active_tab='signup', full_name=full_name, email=email)

        # 4. Validate password length policy
        if len(password) < 8:
            flash("Password must be at least 8 characters long for your security.", "error")
            return render_template('index.html', active_tab='signup', full_name=full_name, email=email)

        # 5. Check password confirmation match
        if password != confirm_password:
            flash("Passwords do not match. Please re-enter your password confirmation.", "error")
            return render_template('index.html', active_tab='signup', full_name=full_name, email=email)

        # 6. Check unique email constraint
        db = get_db()
        existing = db.execute(
            "SELECT id FROM users WHERE normalized_email = ?",
            (normalized,)
        ).fetchone()

        if existing:
            log_audit_event("REGISTRATION_REJECTED", None, f"Duplicate email: {normalized}", ip)
            flash("An account with this email address already exists. Please sign in.", "error")
            return render_template('index.html', active_tab='signin', email=normalized)

        # 7. Hash password using scrypt and insert into database
        # Never store plaintext passwords or reversible ciphers
        password_hash = generate_password_hash(password, method='scrypt')

        db.execute(
            """
            INSERT INTO users (full_name, normalized_email, password_hash)
            VALUES (?, ?, ?)
            """,
            (full_name, normalized, password_hash)
        )
        db.commit()

        new_user = db.execute(
            "SELECT id FROM users WHERE normalized_email = ?",
            (normalized,)
        ).fetchone()

        log_audit_event("REGISTER", new_user['id'], "New account registered with scrypt hash", ip)

        flash("Registration successful! You can now sign in with your credentials.", "success")
        return redirect(url_for('login', tab='signin', email=normalized))

    return render_template('index.html', active_tab='signup')


@app.route('/dashboard')
@login_required
def dashboard():
    """Protected dashboard view displaying authenticated profile and session state."""
    db = get_db()
    user = db.execute(
        "SELECT id, full_name, normalized_email, created_at, last_login_at FROM users WHERE id = ?",
        (session['user_id'],)
    ).fetchone()

    if not user:
        session.clear()
        flash("Your user record was not found. Please sign in again.", "error")
        return redirect(url_for('login'))

    # Retrieve recent security audit logs
    logs = db.execute(
        "SELECT action, details, ip_address, timestamp FROM audit_logs WHERE user_id = ? ORDER BY id DESC LIMIT 5",
        (user['id'],)
    ).fetchall()

    return render_template(
        'dashboard.html',
        user=user,
        logs=logs,
        session_id=session.get('csrf_token', '')[:12] + '••••••••'
    )


@app.route('/logout', methods=['POST', 'GET'])
def logout():
    """Terminates authenticated session and clears session data."""
    user_id = session.get('user_id')
    ip = request.remote_addr or '127.0.0.1'

    if user_id:
        log_audit_event("LOGOUT", user_id, "User ended session", ip)

    session.clear()
    flash("You have been signed out successfully. Your session has ended.", "info")
    return redirect(url_for('login'))


# -----------------------------------------------------------------------------
# Main Entry Point
# -----------------------------------------------------------------------------

if __name__ == '__main__':
    # Running locally
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
