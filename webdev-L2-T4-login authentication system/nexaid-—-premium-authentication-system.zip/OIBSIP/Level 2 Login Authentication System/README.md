# NexaID — Premium Login Authentication System
### Oasis Infobyte Internship — Web Development & Designing (OIBSIP)
### Level 2 — Task 4: Login Authentication System
**Candidate:** Neha Vinod Borkar  
**Email:** nehaborkar2408@gmail.com  
**Assigned Track:** Web Development & Designing  
**Project Folder:** `OIBSIP/Level 2 Login Authentication System/`

---

## 1. Project Overview

**NexaID** ("*Your space. Your identity.*") is a production-grade, full-stack login authentication system designed and engineered to satisfy the rigorous requirements of **Oasis Infobyte Internship Level 2 Task 4**. 

Unlike naive frontend demonstrations that store credentials in JavaScript variables or local storage, NexaID implements a **real, hardened backend architecture**. User credentials and authentication states are securely verified, encrypted using cryptographic **scrypt** key derivation, stored in a parameterised SQLite database, and managed using signed, HttpOnly session cookies with CSRF defense.

---

## 2. Key Features

- **Full User Lifecycle:** Seamless user registration, instant credential validation, server-side duplicate prevention, authenticated dashboard access, and clean session termination upon logout.
- **Scrypt Password Key Derivation:** Passwords are never stored as plaintext or using deprecated hashes (like MD5 or SHA1). Scrypt applies a high memory-and-CPU cost parameter with unique cryptographic salt per user.
- **Timing-Attack Resistance:** Employs constant-time string comparisons to neutralize side-channel timing attacks during credential validation.
- **Server-Side Protected Dashboard:** Routes are guarded with `@login_required` decorators and session verification. Unauthorized visitors are redirected to the login view.
- **Dual-Layer Validation:**
  - *Client-side:* Instant interactive feedback for empty inputs, RFC 5322 email regex, minimum 8-character password length, dynamic password strength meter, and password match confirmation.
  - *Server-side:* Strict server re-validation preventing bypass even if JavaScript is modified or disabled.
- **Session & Cookie Security:** Signed, HttpOnly cookies with `SameSite=Lax` protection against Cross-Site Request Forgery (CSRF) and Cross-Site Scripting (XSS).
- **Security Audit Logging:** Database log recording registration events, successful logins, failed attempts, and logout timestamps.
- **Responsive & Accessible Design:** Crafted with a refined indigo/violet/cyan aesthetic, full keyboard accessibility, clear visual focus rings, and seamless responsiveness from 360px mobile viewports to ultra-wide displays.

---

## 3. Technology Stack

| Layer | Technology | Purpose |
|---|---|---|
| **Frontend** | HTML5, CSS3, Vanilla JavaScript | Semantic markup, custom styling system, DOM interactions, live password strength meter |
| **Backend** | Python 3.10+, Flask 3.0.3, Werkzeug 3.0.3 | Routing, session cookies, password hashing (`scrypt`), route guards |
| **Database** | SQLite 3 | Relational storage with unique constraints and parameterized queries |
| **Design System** | Custom NexaID Palette | Deep Indigo (`#080C16`), Electric Violet (`#7C3AED`), Cyan (`#06B6D4`), Coral (`#F43F5E`) |

---

## 4. Project Directory Structure

```text
login-authentication/
├── app.py                      # Flask backend application & route handlers
├── requirements.txt            # Python dependencies
├── README.md                   # Full documentation & testing checklist
├── instance/
│   └── nexa_auth.db            # SQLite database (auto-created on first run)
├── templates/
│   ├── index.html              # Login & registration portal template
│   └── dashboard.html          # Protected user dashboard template
└── static/
    ├── style.css               # NexaID design system & responsive layout
    └── script.js               # Client validation, password toggles, strength meter
```

---

## 5. Local Setup & Installation (Beginner-Friendly)

Follow these step-by-step commands to run NexaID on your local development machine:

### Step 1: Clone or Navigate to the Project Folder
```bash
cd "OIBSIP/Level 2 Login Authentication System"
# or
cd login-authentication
```

### Step 2: Create a Python Virtual Environment
Creating an isolated environment keeps your system Python clean:
```bash
# On Linux / macOS
python3 -m venv venv
source venv/bin/activate

# On Windows (PowerShell)
python -m venv venv
venv\Scripts\Activate.ps1
```

### Step 3: Install Required Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Configure Environment Variables (Optional)
By default, the application generates a safe cryptographic session secret key in memory. You may optionally set a custom secret key:
```bash
# Linux / macOS
export SECRET_KEY="your-random-32-character-secret-key-here"
export FLASK_ENV="development"

# Windows (PowerShell)
$env:SECRET_KEY="your-random-32-character-secret-key-here"
$env:FLASK_ENV="development"
```

### Step 5: Launch the Application
```bash
python app.py
```

The application will start immediately. Open your browser and navigate to:
```
http://localhost:5000
```
*(The SQLite database `instance/nexa_auth.db` and the tables will be automatically created on initial startup.)*

---

## 6. How Authentication & Password Hashing Work

### 1. User Registration Flow
1. The user enters their **Full Name**, **Email Address**, **Password**, and **Confirm Password**.
2. Client-side script checks format and confirms passwords match.
3. Upon submission via `POST /register`, the server re-validates all parameters.
4. The email address is converted to lowercase and trimmed (`normalize_email`).
5. A SQL query checks if `normalized_email` already exists in SQLite:
   ```sql
   SELECT id FROM users WHERE normalized_email = ?
   ```
6. If unique, Werkzeug derives a secure hash:
   ```python
   password_hash = generate_password_hash(password, method='scrypt')
   ```
   **Scrypt** uses memory-hard functions that make hardware-accelerated attacks (such as custom ASIC or GPU rigs) computationally impractical.
7. The hash is saved to the SQLite database. **Plaintext passwords are never logged or stored.**

### 2. User Login Flow
1. User enters email and password into `POST /login`.
2. The server queries the database by normalized email.
3. If no user is found, or if `check_password_hash(stored_hash, password)` fails, a **generic error message** is returned:
   > *"Invalid email or password. Please verify your credentials."*
   *(This prevents email enumeration vulnerabilities).*
4. If valid, Flask establishes an encrypted, signed session containing `user_id`, `full_name`, and `email`.
5. The session cookie is returned with `HttpOnly` enabled (preventing JavaScript extraction).

### 3. Route Protection & Dashboard
- The `/dashboard` route is wrapped with the `@login_required` decorator:
  ```python
  @app.route('/dashboard')
  @login_required
  def dashboard():
      ...
  ```
- If an unauthenticated user attempts to visit `/dashboard`, they are bounced to `/login` with an informational message.

### 4. Logout Flow
- Submitting `POST /logout` executes `session.clear()`, wiping the server-side session and invalidating the cookie.
- Back-button navigation cannot reuse the terminated session.

---

## 7. Security Verification & Testing Checklist

Each test case below has been tested and verified:

| Test Case | Expected Behavior | Result |
|---|---|---|
| **Empty Input Validation** | Reject submission and highlight fields | **PASSED** |
| **Invalid Email Format** | Rejects non-RFC5322 emails | **PASSED** |
| **Password Length (<8 chars)** | Rejects passwords shorter than 8 characters | **PASSED** |
| **Mismatched Passwords** | Rejects submission when confirmation fails | **PASSED** |
| **Duplicate Email Registration** | Database unique constraint blocks duplicate | **PASSED** |
| **Password Storage in DB** | Verifies scrypt hash string stored; 0 plaintext | **PASSED** |
| **Valid Login** | Valid credentials establish session and open dashboard | **PASSED** |
| **Incorrect Password** | Returns generic error; does not reveal user presence | **PASSED** |
| **Unauthenticated Route Access** | Access to `/dashboard` redirects to `/login` | **PASSED** |
| **Logout Session Invalidation** | Destroys session; prevents protected access | **PASSED** |
| **SQL Injection Prevention** | All SQL queries parameterized with `?` | **PASSED** |
| **CSRF Defense** | Validates session CSRF token on POST requests | **PASSED** |
| **Responsive Viewports** | Tested at 360px, 768px, 1024px, 1440px | **PASSED** |

---

## 8. Mandatory Demo Video Details

As instructed by the Oasis Infobyte task guidelines, the mandatory demo video opening contains:

- **Full Name:** Neha Vinod Borkar
- **Assigned Track:** Web Development & Designing
- **Task Title:** Level 2 — Task 4: Login Authentication System

*This opening title card is also built interactively into the NexaID web application for effortless screen-recording!*
