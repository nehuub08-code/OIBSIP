import React, { useState, useEffect } from 'react';
import {
  Shield,
  ShieldCheck,
  Lock,
  Mail,
  User,
  KeyRound,
  Eye,
  EyeOff,
  LogOut,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Clock,
  Database,
  Fingerprint,
  FileCode,
  Video,
  Sparkles,
  Server,
  RefreshCw,
  Copy,
  Check,
  Terminal,
  Activity,
  ChevronRight,
  ExternalLink,
  Sliders,
  X
} from 'lucide-react';

interface UserData {
  id: string;
  fullName: string;
  normalizedEmail: string;
  createdAt: string;
  lastLoginAt: string | null;
}

interface SessionData {
  tokenPreview: string;
  createdAt: string;
  expiresAt: string;
  rememberMe: boolean;
  csrfToken: string;
  ipAddress: string;
  userAgent: string;
  cookieSettings?: {
    httpOnly: boolean;
    sameSite: string;
    secure: boolean;
    path: string;
  };
  algorithm?: string;
}

interface AuditLog {
  id: string;
  userId: string | null;
  userEmail: string;
  action: string;
  details: string;
  timestamp: string;
  ipAddress: string;
}

interface AlertMessage {
  id: string;
  type: 'error' | 'success' | 'warning' | 'info';
  text: string;
}

export default function App() {
  // Authentication & session state
  const [currentUser, setCurrentUser] = useState<UserData | null>(null);
  const [currentSession, setCurrentSession] = useState<SessionData | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'signin' | 'signup'>('signin');
  
  // Notification alerts
  const [alerts, setAlerts] = useState<AlertMessage[]>([]);

  // Sign In Form States
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [loginSubmitting, setLoginSubmitting] = useState(false);
  const [loginErrors, setLoginErrors] = useState<{ email?: string; password?: string }>({});

  // Sign Up Form States
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [showRegConfirm, setShowRegConfirm] = useState(false);
  const [regSubmitting, setRegSubmitting] = useState(false);
  const [regErrors, setRegErrors] = useState<{ fullName?: string; email?: string; password?: string; confirmPassword?: string }>({});

  // Change Password Modal States
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmNewPass, setConfirmNewPass] = useState('');
  const [passChangeLoading, setPassChangeLoading] = useState(false);
  const [passChangeError, setPassChangeError] = useState('');

  // Modals & Tools
  const [showVideoCard, setShowVideoCard] = useState(false);
  const [videoTimer, setVideoTimer] = useState(2);
  const [timerRunning, setTimerRunning] = useState(false);
  const [showCodeInspector, setShowCodeInspector] = useState(false);
  const [selectedCodeFile, setSelectedCodeFile] = useState<'app.py' | 'templates/index.html' | 'templates/dashboard.html' | 'requirements.txt' | 'README.md'>('app.py');
  const [copiedFile, setCopiedFile] = useState(false);
  const [showAuditModal, setShowAuditModal] = useState(false);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [showSecurityLab, setShowSecurityLab] = useState(false);

  // CSRF token
  const [csrfToken, setCsrfToken] = useState('');

  const addAlert = (type: 'error' | 'success' | 'warning' | 'info', text: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setAlerts((prev) => [...prev, { id, type, text }]);
    setTimeout(() => {
      setAlerts((prev) => prev.filter((a) => a.id !== id));
    }, 6000);
  };

  const removeAlert = (id: string) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  // Fetch CSRF token and check current authentication state on load
  const checkSession = async () => {
    try {
      setAuthLoading(true);
      // Handshake for CSRF
      const csrfRes = await fetch('/api/auth/csrf');
      const csrfData = await csrfRes.json();
      if (csrfData.csrfToken) {
        setCsrfToken(csrfData.csrfToken);
      }

      // Check current session cookie
      const meRes = await fetch('/api/auth/me');
      if (meRes.ok) {
        const data = await meRes.json();
        if (data.success && data.user) {
          setCurrentUser(data.user);
          setCurrentSession(data.session);
        }
      } else {
        setCurrentUser(null);
        setCurrentSession(null);
      }
    } catch (err) {
      console.warn('Session check failed:', err);
      setCurrentUser(null);
      setCurrentSession(null);
    } finally {
      setAuthLoading(false);
    }
  };

  useEffect(() => {
    checkSession();
  }, []);

  // Video Card 2-Second Timer
  useEffect(() => {
    let interval: any;
    if (showVideoCard && timerRunning && videoTimer > 0) {
      interval = setInterval(() => {
        setVideoTimer((prev) => {
          if (prev <= 1) {
            setTimerRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [showVideoCard, timerRunning, videoTimer]);

  const startVideoTimer = () => {
    setVideoTimer(2);
    setTimerRunning(true);
  };

  // Calculate Password Strength for Registration
  const getPasswordStrength = (pass: string) => {
    if (!pass) return { score: 0, label: 'Minimum 8 characters', color: '#64748b' };
    let score = 0;
    if (pass.length >= 8) score++;
    if (/[A-Z]/.test(pass) && /[a-z]/.test(pass)) score++;
    if (/[0-9]/.test(pass)) score++;
    if (/[^A-Za-z0-9]/.test(pass)) score++;

    switch (score) {
      case 1:
        return { score: 1, label: 'Weak (add numbers/symbols)', color: '#f43f5e' };
      case 2:
        return { score: 2, label: 'Fair (add capital letters & symbols)', color: '#fb923c' };
      case 3:
        return { score: 3, label: 'Good (strong character mix)', color: '#eab308' };
      case 4:
        return { score: 4, label: 'Strong & Cryptographically Resilient', color: '#10b981' };
      default:
        return { score: 0, label: 'Minimum 8 characters', color: '#64748b' };
    }
  };

  const passwordStrength = getPasswordStrength(regPassword);

  // 1. Handle Sign In
  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    const errors: { email?: string; password?: string } = {};

    const trimmedEmail = loginEmail.trim();
    if (!trimmedEmail) {
      errors.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      errors.email = 'Please provide a valid email address.';
    }

    if (!loginPassword) {
      errors.password = 'Password is required.';
    }

    setLoginErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setLoginSubmitting(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-csrf-token': csrfToken,
        },
        body: JSON.stringify({
          email: trimmedEmail,
          password: loginPassword,
          rememberMe,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        addAlert('error', data.error || 'Invalid email or password.');
      } else {
        addAlert('success', `Welcome back, ${data.user.fullName}! Session authenticated.`);
        setCurrentUser(data.user);
        setCurrentSession(data.session);
        setLoginPassword('');
      }
    } catch {
      addAlert('error', 'Network error connecting to authentication server.');
    } finally {
      setLoginSubmitting(false);
    }
  };

  // 2. Handle Sign Up
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    const errors: { fullName?: string; email?: string; password?: string; confirmPassword?: string } = {};

    const trimmedName = regFullName.trim();
    if (!trimmedName || trimmedName.length < 2) {
      errors.fullName = 'Full name must be at least 2 characters long.';
    }

    const trimmedEmail = regEmail.trim();
    if (!trimmedEmail) {
      errors.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      errors.email = 'Please provide a valid email format (e.g., alex@company.com).';
    }

    if (!regPassword) {
      errors.password = 'Password is required.';
    } else if (regPassword.length < 8) {
      errors.password = 'Password must be at least 8 characters in length.';
    }

    if (regPassword !== regConfirmPassword) {
      errors.confirmPassword = 'Passwords do not match. Please re-enter.';
    }

    setRegErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setRegSubmitting(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-csrf-token': csrfToken,
        },
        body: JSON.stringify({
          fullName: trimmedName,
          email: trimmedEmail,
          password: regPassword,
          confirmPassword: regConfirmPassword,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        addAlert('error', data.error || 'Registration failed.');
      } else {
        addAlert('success', 'Account created successfully! Please sign in with your credentials.');
        setLoginEmail(trimmedEmail);
        setActiveTab('signin');
        setRegFullName('');
        setRegEmail('');
        setRegPassword('');
        setRegConfirmPassword('');
      }
    } catch {
      addAlert('error', 'Network error registering account.');
    } finally {
      setRegSubmitting(false);
    }
  };

  // 3. Handle Logout
  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-csrf-token': csrfToken,
        },
      });
      setCurrentUser(null);
      setCurrentSession(null);
      addAlert('info', 'You have been securely signed out. Session destroyed on server.');
    } catch {
      addAlert('error', 'Error signing out.');
    }
  };

  // 4. Test Unauthenticated Access
  const testUnauthorizedAccess = async () => {
    try {
      // Direct raw request bypassing any credentials
      const res = await fetch('/api/auth/me', {
        headers: {
          // Send no cookie / bad session
          'Cache-Control': 'no-cache',
        },
        credentials: 'omit', // intentionally strip cookies
      });
      const data = await res.json();
      if (res.status === 401) {
        addAlert(
          'warning',
          `[401 UNAUTHORIZED TEST]: Direct access denied as expected! Server returned: "${data.error}" (Code: ${data.code})`
        );
      }
    } catch (err) {
      addAlert('info', 'Test completed: Request rejected.');
    }
  };

  // 5. Change Password Handler
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassChangeError('');

    if (!currentPass || !newPass || !confirmNewPass) {
      setPassChangeError('All password fields are required.');
      return;
    }

    if (newPass.length < 8) {
      setPassChangeError('New password must be at least 8 characters long.');
      return;
    }

    if (newPass !== confirmNewPass) {
      setPassChangeError('New password and confirmation do not match.');
      return;
    }

    setPassChangeLoading(true);
    try {
      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-csrf-token': csrfToken,
        },
        body: JSON.stringify({
          currentPassword: currentPass,
          newPassword: newPass,
          confirmNewPassword: confirmNewPass,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        setPassChangeError(data.error || 'Failed to update password.');
      } else {
        addAlert('success', 'Password changed successfully! Fresh scrypt salt and hash generated.');
        setShowPasswordModal(false);
        setCurrentPass('');
        setNewPass('');
        setConfirmNewPass('');
      }
    } catch {
      setPassChangeError('Network error while changing password.');
    } finally {
      setPassChangeLoading(false);
    }
  };

  // 6. Fetch Audit Logs
  const loadAuditLogs = async () => {
    try {
      const res = await fetch('/api/auth/audit-logs');
      if (res.ok) {
        const data = await res.json();
        setAuditLogs(data.logs || []);
        setShowAuditModal(true);
      } else {
        addAlert('error', 'Could not load security audit logs.');
      }
    } catch {
      addAlert('error', 'Network error fetching audit logs.');
    }
  };

  // Quick fill test account
  const fillTestAccount = () => {
    setLoginEmail('neha.demo@nexaid.internal');
    setLoginPassword('NexaSecure#2026');
    setLoginErrors({});
    addAlert('info', 'Prefilled Oasis Infobyte test credentials (neha.demo@nexaid.internal).');
  };

  // Code contents for the file inspector
  const codeFiles: Record<string, string> = {
    'app.py': `# -----------------------------------------------------------------------------
# NexaID - Premium Login Authentication System
# Oasis Infobyte Internship: Web Development & Designing
# Level 2 — Task 4
# Student: Neha Vinod Borkar
# -----------------------------------------------------------------------------
import os, sqlite3, re, secrets
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, g
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
app.config['DATABASE'] = os.path.join(app.instance_path, 'nexa_auth.db')
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('FLASK_ENV') == 'production'

def init_db():
    db = get_db()
    db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            normalized_email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login_at TIMESTAMP
        );
    """)
    db.commit()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        user = get_db().execute("SELECT * FROM users WHERE normalized_email = ?", (email,)).fetchone()
        
        # Generic error message avoids email enumeration
        if user is None or not check_password_hash(user['password_hash'], password):
            flash("Invalid email or password. Please verify your credentials.", "error")
            return render_template('index.html', active_tab='signin')
            
        session['user_id'] = user['id']
        session['full_name'] = user['full_name']
        session['email'] = user['normalized_email']
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/register', methods=['POST'])
def register():
    full_name = request.form.get('full_name', '').strip()
    email = request.form.get('email', '').strip().lower()
    password = request.form.get('password', '')
    
    # Scrypt key derivation: high memory-cost hash with unique salt
    password_hash = generate_password_hash(password, method='scrypt')
    get_db().execute("INSERT INTO users (full_name, normalized_email, password_hash) VALUES (?, ?, ?)",
                     (full_name, email, password_hash))
    get_db().commit()
    flash("Account created successfully! Please sign in.", "success")
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', user=current_user)

@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    flash("You have been signed out successfully.", "info")
    return redirect(url_for('login'))`,

    'templates/index.html': `<!-- NexaID Login & Registration Template -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>NexaID — Secure Authentication Portal</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
</head>
<body>
  <div class="auth-wrapper">
    <div class="brand-panel">
      <h1>Your space. <span class="gradient-text">Your identity.</span></h1>
      <p>Oasis Infobyte Internship Level 2 Task 4 — Neha Vinod Borkar</p>
    </div>
    <div class="form-panel">
      <!-- Tabs for Sign In and Create Account -->
      <!-- CSRF token input, show/hide password, and scrypt validation -->
    </div>
  </div>
</body>
</html>`,

    'templates/dashboard.html': `<!-- Protected Dashboard Template -->
<!DOCTYPE html>
<html lang="en">
<head>
  <title>NexaID — Protected Security Dashboard</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
</head>
<body>
  <header>
    <h2>Welcome back, {{ user['full_name'] }}!</h2>
    <form action="{{ url_for('logout') }}" method="POST">
      <button type="submit">Sign Out</button>
    </form>
  </header>
  <!-- Account info: User ID, Normalized Email, Scrypt Hashing, Session Details -->
</body>
</html>`,

    'requirements.txt': `Flask==3.0.3
Werkzeug==3.0.3
python-dotenv==1.0.1`,

    'README.md': `# NexaID — Premium Login Authentication System
Oasis Infobyte Internship — Web Development & Designing (OIBSIP)
Level 2 — Task 4: Login Authentication System
Candidate: Neha Vinod Borkar (nehaborkar2408@gmail.com)

Features:
1. Scrypt Cryptographic Key Derivation (zero plaintext)
2. Server-Enforced Sessions with HttpOnly & SameSite=Lax cookies
3. Parameterized SQLite queries against SQL injection
4. Generic error messages preventing email enumeration
5. Complete testing checklist covering all 14 test cases`,
  };

  const copyCodeToClipboard = () => {
    navigator.clipboard.writeText(codeFiles[selectedCodeFile]);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#080c16] text-slate-100 flex flex-col font-sans selection:bg-violet-600 selection:text-white">
      
      {/* =========================================================================
          Global Top Header
          ========================================================================= */}
      <header className="border-b border-slate-800/80 bg-[#0c1222]/90 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Brand Logo & Internship Tag */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-violet-600 via-indigo-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-violet-900/40">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xl font-extrabold tracking-tight text-white">
                  Nexa<span className="text-cyan-400">ID</span>
                </span>
                <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-cyan-950/70 text-cyan-300 border border-cyan-800/50 uppercase tracking-wider">
                  OIBSIP Task 4
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium hidden sm:block">
                Your space. Your identity.
              </p>
            </div>
          </div>

          {/* Quick Header Actions */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Demo Video Title Card Button (Section 16 requirement) */}
            <button
              onClick={() => {
                setShowVideoCard(true);
                startVideoTimer();
              }}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-violet-950/80 hover:bg-violet-900/80 text-violet-200 border border-violet-700/50 transition-all hover:scale-[1.02] shadow-sm"
              title="Show Mandatory 2-Second Title Card for Demo Recording"
            >
              <Video className="w-3.5 h-3.5 text-violet-400" />
              <span className="hidden sm:inline">Demo Video Studio</span>
              <span className="sm:hidden">Video Card</span>
            </button>

            {/* Task 4 Code Inspector Button */}
            <button
              onClick={() => setShowCodeInspector(true)}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border border-slate-700/60 transition-all shadow-sm"
              title="Inspect Python Flask & SQLite Code Files"
            >
              <FileCode className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Project Files</span>
            </button>

            {/* Security Lab Toggle */}
            <button
              onClick={() => setShowSecurityLab(!showSecurityLab)}
              className={`inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                showSecurityLab
                  ? 'bg-cyan-950 text-cyan-300 border-cyan-500'
                  : 'bg-slate-800/80 text-slate-300 border-slate-700/60 hover:bg-slate-700/80'
              }`}
              title="Toggle Security Testing Tools"
            >
              <Sliders className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden md:inline">Security Tools</span>
            </button>

            {/* User Session Status */}
            {currentUser ? (
              <div className="flex items-center space-x-2 pl-2 border-l border-slate-800">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-violet-600 to-cyan-500 flex items-center justify-center text-xs font-bold text-white shadow-sm">
                  {currentUser.fullName.charAt(0).toUpperCase()}
                </div>
                <div className="hidden lg:block text-left">
                  <div className="text-xs font-bold text-slate-100 leading-tight">
                    {currentUser.fullName}
                  </div>
                  <div className="text-[10px] text-emerald-400 font-mono">
                    Session Active
                  </div>
                </div>
                <button
                  onClick={handleLogout}
                  className="p-1.5 text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded-lg transition-colors"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="hidden sm:flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs bg-slate-900 border border-slate-800 text-slate-400">
                <span className="w-2 h-2 rounded-full bg-slate-500"></span>
                <span>Unauthenticated</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Floating Alerts Container */}
      {alerts.length > 0 && (
        <div className="fixed top-20 right-4 z-50 flex flex-col space-y-2 max-w-md w-full px-4">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-3.5 rounded-xl border shadow-xl flex items-start space-x-3 transition-all animate-in fade-in slide-in-from-top-2 ${
                alert.type === 'error'
                  ? 'bg-rose-950/90 border-rose-800 text-rose-200'
                  : alert.type === 'success'
                  ? 'bg-emerald-950/90 border-emerald-800 text-emerald-200'
                  : alert.type === 'warning'
                  ? 'bg-amber-950/90 border-amber-800 text-amber-200'
                  : 'bg-cyan-950/90 border-cyan-800 text-cyan-200'
              }`}
            >
              {alert.type === 'error' && <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />}
              {alert.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />}
              {alert.type === 'warning' && <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />}
              {alert.type === 'info' && <ShieldCheck className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />}
              <div className="flex-1 text-xs leading-relaxed font-medium">{alert.text}</div>
              <button
                onClick={() => removeAlert(alert.id)}
                className="text-slate-400 hover:text-white p-0.5"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Security Testing Bar (Expandable) */}
      {showSecurityLab && (
        <section className="bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 border-b border-indigo-900/50 py-2.5 px-4 sm:px-6">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center space-x-2 text-indigo-300">
              <Activity className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span className="font-semibold text-slate-200">Security Verification Testing Suite:</span>
              <span className="text-slate-400 hidden sm:inline">Execute instant assertions against backend guards</span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={testUnauthorizedAccess}
                className="px-2.5 py-1 rounded bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 transition-colors"
                title="Asserts that opening protected resource without valid cookie responds with 401 Unauthorized"
              >
                Assert 401 Unauthorized
              </button>
              <button
                onClick={fillTestAccount}
                className="px-2.5 py-1 rounded bg-violet-950/60 hover:bg-violet-900/60 text-violet-300 border border-violet-800/60 transition-colors"
                title="Prefills Neha's official Oasis Infobyte test account"
              >
                Prefill Test Account
              </button>
              <button
                onClick={loadAuditLogs}
                className="px-2.5 py-1 rounded bg-cyan-950/60 hover:bg-cyan-900/60 text-cyan-300 border border-cyan-800/60 transition-colors"
                title="View full audit log trail"
              >
                View Audit Trail
              </button>
              <button
                onClick={checkSession}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors flex items-center space-x-1"
                title="Refresh authentication check"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Re-check Session</span>
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col justify-center">
        {authLoading ? (
          <div className="min-h-[500px] flex flex-col items-center justify-center space-y-4">
            <div className="w-12 h-12 rounded-full border-4 border-violet-500 border-t-transparent animate-spin"></div>
            <p className="text-sm text-slate-400 font-medium">Verifying cryptographic session state...</p>
          </div>
        ) : currentUser ? (
          /* =========================================================================
              PROTECTED DASHBOARD VIEW (Authenticated State)
              ========================================================================= */
          <div className="max-w-6xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8 animate-in fade-in duration-300">
            
            {/* Welcome Banner */}
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/80 to-slate-900 border border-violet-900/30 p-6 sm:p-10 shadow-2xl">
              <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-violet-600/20 via-cyan-500/10 to-transparent rounded-full blur-3xl pointer-events-none"></div>
              
              <div className="relative z-10 space-y-4">
                <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-semibold bg-violet-950/70 text-violet-300 border border-violet-700/40">
                  <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Authenticated Protected Dashboard</span>
                </div>

                <div className="space-y-1">
                  <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
                    Welcome back,{' '}
                    <span className="bg-gradient-to-r from-violet-400 via-cyan-300 to-indigo-300 bg-clip-text text-transparent">
                      {currentUser.fullName}
                    </span>
                    !
                  </h1>
                  <p className="text-slate-400 text-sm sm:text-base max-w-2xl leading-relaxed">
                    You have successfully established an authenticated session. Your credentials were cryptographically verified using scrypt key derivation, and your session token is secured with HttpOnly and SameSite cookie policies.
                  </p>
                </div>

                <div className="pt-2 flex flex-wrap gap-3">
                  <button
                    onClick={() => setShowPasswordModal(true)}
                    className="inline-flex items-center space-x-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-violet-600 hover:bg-violet-500 text-white shadow-lg shadow-violet-600/30 transition-all hover:scale-[1.02]"
                  >
                    <KeyRound className="w-4 h-4" />
                    <span>Change Password</span>
                  </button>

                  <button
                    onClick={loadAuditLogs}
                    className="inline-flex items-center space-x-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-slate-800/90 hover:bg-slate-700/90 text-slate-200 border border-slate-700 transition-all"
                  >
                    <Terminal className="w-4 h-4 text-cyan-400" />
                    <span>View Security Audit Log</span>
                  </button>

                  <button
                    onClick={handleLogout}
                    className="inline-flex items-center space-x-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-rose-950/70 hover:bg-rose-900/80 text-rose-300 border border-rose-800/50 transition-all"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Metrics Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-[#0f172a]/80 border border-slate-800/90 rounded-2xl p-5 shadow-lg">
                <div className="flex items-center justify-between text-slate-400 mb-3">
                  <span className="text-xs font-semibold uppercase tracking-wider">Account ID</span>
                  <Fingerprint className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="text-sm font-mono font-bold text-white truncate" title={currentUser.id}>
                  {currentUser.id}
                </div>
                <p className="text-[11px] text-emerald-400 mt-1 flex items-center space-x-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  <span>Active & Verified</span>
                </p>
              </div>

              <div className="bg-[#0f172a]/80 border border-slate-800/90 rounded-2xl p-5 shadow-lg">
                <div className="flex items-center justify-between text-slate-400 mb-3">
                  <span className="text-xs font-semibold uppercase tracking-wider">Normalized Email</span>
                  <Mail className="w-4 h-4 text-violet-400" />
                </div>
                <div className="text-sm font-bold text-white truncate" title={currentUser.normalizedEmail}>
                  {currentUser.normalizedEmail}
                </div>
                <p className="text-[11px] text-slate-400 mt-1">Unique database constraint</p>
              </div>

              <div className="bg-[#0f172a]/80 border border-slate-800/90 rounded-2xl p-5 shadow-lg">
                <div className="flex items-center justify-between text-slate-400 mb-3">
                  <span className="text-xs font-semibold uppercase tracking-wider">Hash Algorithm</span>
                  <Lock className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-sm font-mono font-bold text-violet-300">
                  scrypt (64-byte key)
                </div>
                <p className="text-[11px] text-slate-400 mt-1">N=16384, r=8, p=1</p>
              </div>

              <div className="bg-[#0f172a]/80 border border-slate-800/90 rounded-2xl p-5 shadow-lg">
                <div className="flex items-center justify-between text-slate-400 mb-3">
                  <span className="text-xs font-semibold uppercase tracking-wider">Session Cookie</span>
                  <Shield className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-sm font-bold text-emerald-300">
                  HttpOnly • SameSite=Lax
                </div>
                <p className="text-[11px] text-slate-400 mt-1">Protected against XSS & CSRF</p>
              </div>
            </div>

            {/* Detailed Account Security Profile & Server Session Card */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Account Information */}
              <div className="bg-[#0f172a]/90 border border-slate-800 rounded-2xl p-6 space-y-4 shadow-xl">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                  <div className="flex items-center space-x-2">
                    <User className="w-5 h-5 text-cyan-400" />
                    <h3 className="font-bold text-base text-white">Identity Credentials</h3>
                  </div>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                    Primary Profile
                  </span>
                </div>

                <div className="space-y-3 text-xs sm:text-sm">
                  <div className="flex justify-between py-1.5 border-b border-slate-800/50">
                    <span className="text-slate-400">Full Name</span>
                    <span className="font-semibold text-white">{currentUser.fullName}</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-800/50">
                    <span className="text-slate-400">Registered Email</span>
                    <span className="font-mono text-cyan-300">{currentUser.normalizedEmail}</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-800/50">
                    <span className="text-slate-400">Account Created</span>
                    <span className="text-slate-300 font-mono">
                      {new Date(currentUser.createdAt).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-800/50">
                    <span className="text-slate-400">Last Successful Sign In</span>
                    <span className="text-slate-300 font-mono">
                      {currentUser.lastLoginAt ? new Date(currentUser.lastLoginAt).toLocaleString() : 'First Session'}
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5">
                    <span className="text-slate-400">Database Storage</span>
                    <span className="text-emerald-400 flex items-center space-x-1 font-medium">
                      <Database className="w-3.5 h-3.5" />
                      <span>SQLite Instance Store</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Active Session & Cryptographic Token Info */}
              <div className="bg-[#0f172a]/90 border border-slate-800 rounded-2xl p-6 space-y-4 shadow-xl">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                  <div className="flex items-center space-x-2">
                    <KeyRound className="w-5 h-5 text-violet-400" />
                    <h3 className="font-bold text-base text-white">Active Session Metadata</h3>
                  </div>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-950/60 text-emerald-300 border border-emerald-800/50">
                    Validated
                  </span>
                </div>

                <div className="space-y-3 text-xs sm:text-sm">
                  <div className="flex justify-between py-1.5 border-b border-slate-800/50">
                    <span className="text-slate-400">Session Token Mask</span>
                    <span className="font-mono text-violet-300">{currentSession?.tokenPreview || 'nexa_••••••••'}</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-800/50">
                    <span className="text-slate-400">Session Duration Mode</span>
                    <span className="text-slate-200">
                      {currentSession?.rememberMe ? '30 Days (Remember Me)' : '4 Hours (Standard)'}
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-800/50">
                    <span className="text-slate-400">Session Expiration</span>
                    <span className="text-slate-300 font-mono text-xs">
                      {currentSession?.expiresAt ? new Date(currentSession.expiresAt).toLocaleString() : 'N/A'}
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-800/50">
                    <span className="text-slate-400">Client IP Address</span>
                    <span className="font-mono text-slate-300">{currentSession?.ipAddress || '127.0.0.1'}</span>
                  </div>
                  <div className="flex justify-between py-1.5">
                    <span className="text-slate-400">CSRF Guard Handshake</span>
                    <span className="font-mono text-cyan-300 text-xs">
                      {csrfToken.slice(0, 10)}••••••••
                    </span>
                  </div>
                </div>
              </div>

            </div>

            {/* Oasis Infobyte Candidate Credentials Note */}
            <div className="bg-gradient-to-r from-violet-950/40 via-indigo-950/30 to-slate-900 border border-violet-900/40 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs sm:text-sm">
              <div className="flex items-center space-x-3">
                <div className="w-9 h-9 rounded-xl bg-violet-900/60 flex items-center justify-center text-violet-300 shrink-0">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-100">Oasis Infobyte Internship Project Submission</h4>
                  <p className="text-slate-400 text-xs">
                    Developed by Neha Vinod Borkar &bull; Web Development & Designing &bull; Level 2 — Task 4
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowVideoCard(true);
                  startVideoTimer();
                }}
                className="px-3.5 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-semibold text-xs transition-all shadow-md shrink-0 flex items-center space-x-1.5"
              >
                <Video className="w-3.5 h-3.5" />
                <span>Open Video Title Card</span>
              </button>
            </div>

          </div>
        ) : (
          /* =========================================================================
              AUTHENTICATION PORTAL (Split-Screen Sign In / Sign Up)
              ========================================================================= */
          <div className="max-w-6xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 flex flex-col lg:flex-row items-stretch gap-8 lg:gap-12 animate-in fade-in duration-300">
            
            {/* Left Column: Brand & Security Architectural Showcase */}
            <div className="flex-1 rounded-3xl bg-gradient-to-b from-slate-900/90 via-[#0d1527] to-[#080c16] border border-slate-800/80 p-6 sm:p-10 flex flex-col justify-between shadow-2xl relative overflow-hidden">
              <div className="absolute -top-24 -left-24 w-80 h-80 bg-violet-600/15 rounded-full blur-3xl pointer-events-none"></div>
              <div className="absolute -bottom-24 -right-24 w-80 h-80 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none"></div>

              <div className="relative z-10 space-y-6">
                
                {/* Security Tag */}
                <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-semibold bg-violet-950/80 text-violet-300 border border-violet-800/50 shadow-sm">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
                  <span>Zero-Plaintext • Scrypt Hashing • CSRF-Guarded</span>
                </div>

                {/* Hero Headline */}
                <div className="space-y-3">
                  <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
                    Your space.<br />
                    <span className="bg-gradient-to-r from-violet-400 via-indigo-300 to-cyan-400 bg-clip-text text-transparent">
                      Your identity.
                    </span>
                  </h1>
                  <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-md">
                    Engineered with cryptographic key derivation, parameterized database storage, and secure session management. Designed to meet every security and architectural benchmark.
                  </p>
                </div>

                {/* Highlights List */}
                <div className="space-y-3 pt-2">
                  <div className="flex items-start space-x-3 p-3.5 rounded-xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm">
                    <div className="w-8 h-8 rounded-lg bg-violet-900/40 text-violet-400 flex items-center justify-center shrink-0 mt-0.5">
                      <Lock className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Scrypt Cryptographic Key Derivation</h4>
                      <p className="text-[11px] text-slate-400 leading-normal">
                        Passwords hashed with high memory-cost parameters (N=16384, r=8, p=1) and 16-byte random salts.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3 p-3.5 rounded-xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm">
                    <div className="w-8 h-8 rounded-lg bg-cyan-900/40 text-cyan-400 flex items-center justify-center shrink-0 mt-0.5">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Signed HttpOnly Session Cookies</h4>
                      <p className="text-[11px] text-slate-400 leading-normal">
                        No sensitive credentials in local storage or client scripts; state is protected with CSRF checks.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3 p-3.5 rounded-xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm">
                    <div className="w-8 h-8 rounded-lg bg-indigo-900/40 text-indigo-400 flex items-center justify-center shrink-0 mt-0.5">
                      <Database className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Parameterized SQLite Persistence</h4>
                      <p className="text-[11px] text-slate-400 leading-normal">
                        Strict query parameterization neutralizing SQL injection and enforcing unique normalized emails.
                      </p>
                    </div>
                  </div>
                </div>

              </div>

              {/* Candidate Info Card on Left Panel */}
              <div className="relative z-10 pt-6 mt-6 border-t border-slate-800/80 flex items-center justify-between">
                <div>
                  <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                    Candidate & Task
                  </div>
                  <div className="text-sm font-bold text-white">Neha Vinod Borkar</div>
                  <div className="text-xs text-cyan-400 font-medium">Oasis Infobyte &bull; Task 4</div>
                </div>

                <button
                  type="button"
                  onClick={fillTestAccount}
                  className="px-3 py-1.5 rounded-lg bg-violet-950/70 hover:bg-violet-900/80 border border-violet-700/50 text-[11px] font-semibold text-violet-200 transition-colors shadow-sm"
                  title="One-click fill Neha's test account"
                >
                  Prefill Demo User
                </button>
              </div>

            </div>

            {/* Right Column: Interactive Authentication Card */}
            <div className="w-full lg:w-[480px] bg-[#0c1322] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col justify-center">
              
              {/* Tabs for Sign In vs Create Account */}
              <div className="flex rounded-xl bg-slate-900/90 p-1 border border-slate-800 mb-6">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('signin');
                    setLoginErrors({});
                  }}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                    activeTab === 'signin'
                      ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('signup');
                    setRegErrors({});
                  }}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                    activeTab === 'signup'
                      ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Create Account
                </button>
              </div>

              {activeTab === 'signin' ? (
                /* ==================== SIGN IN FORM ==================== */
                <div className="space-y-5 animate-in fade-in duration-200">
                  <div>
                    <h2 className="text-2xl font-bold text-white tracking-tight">Welcome back</h2>
                    <p className="text-xs text-slate-400 mt-1">
                      Enter your credentials to access your NexaID secure space.
                    </p>
                  </div>

                  <form onSubmit={handleSignIn} className="space-y-4" noValidate>
                    {/* Email Input */}
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-300 block">
                        Email Address
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          type="email"
                          value={loginEmail}
                          onChange={(e) => {
                            setLoginEmail(e.target.value);
                            if (loginErrors.email) setLoginErrors((prev) => ({ ...prev, email: undefined }));
                          }}
                          placeholder="name@company.com"
                          className={`w-full bg-[#121a2d] border ${
                            loginErrors.email ? 'border-rose-500 ring-1 ring-rose-500' : 'border-slate-800 focus:border-violet-500'
                          } rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none transition-all`}
                        />
                      </div>
                      {loginErrors.email && (
                        <p className="text-[11px] text-rose-400 font-medium">{loginErrors.email}</p>
                      )}
                    </div>

                    {/* Password Input */}
                    <div className="space-y-1">
                      <div className="flex justify-between items-center">
                        <label className="text-xs font-semibold text-slate-300">
                          Password
                        </label>
                      </div>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          type={showLoginPassword ? 'text' : 'password'}
                          value={loginPassword}
                          onChange={(e) => {
                            setLoginPassword(e.target.value);
                            if (loginErrors.password) setLoginErrors((prev) => ({ ...prev, password: undefined }));
                          }}
                          placeholder="••••••••••••"
                          className={`w-full bg-[#121a2d] border ${
                            loginErrors.password ? 'border-rose-500 ring-1 ring-rose-500' : 'border-slate-800 focus:border-violet-500'
                          } rounded-xl pl-10 pr-10 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none transition-all`}
                        />
                        <button
                          type="button"
                          onClick={() => setShowLoginPassword(!showLoginPassword)}
                          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                          title={showLoginPassword ? 'Hide password' : 'Show password'}
                        >
                          {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      {loginErrors.password && (
                        <p className="text-[11px] text-rose-400 font-medium">{loginErrors.password}</p>
                      )}
                    </div>

                    {/* Remember Me Option */}
                    <div className="flex items-center justify-between text-xs pt-1">
                      <label className="flex items-center space-x-2 cursor-pointer select-none text-slate-300">
                        <input
                          type="checkbox"
                          checked={rememberMe}
                          onChange={(e) => setRememberMe(e.target.checked)}
                          className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-violet-600 focus:ring-violet-500"
                        />
                        <span>Remember this session (30 days)</span>
                      </label>
                    </div>

                    {/* Submit Button */}
                    <button
                      type="submit"
                      disabled={loginSubmitting}
                      className="w-full mt-2 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 shadow-lg shadow-violet-600/30 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-60 flex items-center justify-center space-x-2"
                    >
                      {loginSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          <span>Authenticating...</span>
                        </>
                      ) : (
                        <>
                          <span>Sign In to NexaID</span>
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </form>

                  <div className="pt-2 text-center text-xs text-slate-400">
                    Don't have an account yet?{' '}
                    <button
                      onClick={() => setActiveTab('signup')}
                      className="text-cyan-400 hover:text-cyan-300 font-semibold underline underline-offset-2"
                    >
                      Create your NexaID
                    </button>
                  </div>
                </div>
              ) : (
                /* ==================== SIGN UP FORM ==================== */
                <div className="space-y-4 animate-in fade-in duration-200">
                  <div>
                    <h2 className="text-2xl font-bold text-white tracking-tight">Create your NexaID</h2>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Register a cryptographic identity with zero plaintext storage.
                    </p>
                  </div>

                  <form onSubmit={handleSignUp} className="space-y-3" noValidate>
                    {/* Full Name */}
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-300 block">
                        Full Name
                      </label>
                      <div className="relative">
                        <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          type="text"
                          value={regFullName}
                          onChange={(e) => {
                            setRegFullName(e.target.value);
                            if (regErrors.fullName) setRegErrors((prev) => ({ ...prev, fullName: undefined }));
                          }}
                          placeholder="e.g. Neha Borkar"
                          className={`w-full bg-[#121a2d] border ${
                            regErrors.fullName ? 'border-rose-500 ring-1 ring-rose-500' : 'border-slate-800 focus:border-violet-500'
                          } rounded-xl pl-10 pr-4 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none transition-all`}
                        />
                      </div>
                      {regErrors.fullName && (
                        <p className="text-[11px] text-rose-400 font-medium">{regErrors.fullName}</p>
                      )}
                    </div>

                    {/* Email Address */}
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-300 block">
                        Email Address
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          type="email"
                          value={regEmail}
                          onChange={(e) => {
                            setRegEmail(e.target.value);
                            if (regErrors.email) setRegErrors((prev) => ({ ...prev, email: undefined }));
                          }}
                          placeholder="name@example.com"
                          className={`w-full bg-[#121a2d] border ${
                            regErrors.email ? 'border-rose-500 ring-1 ring-rose-500' : 'border-slate-800 focus:border-violet-500'
                          } rounded-xl pl-10 pr-4 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none transition-all`}
                        />
                      </div>
                      {regErrors.email && (
                        <p className="text-[11px] text-rose-400 font-medium">{regErrors.email}</p>
                      )}
                    </div>

                    {/* Password */}
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-300 block">
                        Password
                      </label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          type={showRegPassword ? 'text' : 'password'}
                          value={regPassword}
                          onChange={(e) => {
                            setRegPassword(e.target.value);
                            if (regErrors.password) setRegErrors((prev) => ({ ...prev, password: undefined }));
                          }}
                          placeholder="Minimum 8 characters"
                          className={`w-full bg-[#121a2d] border ${
                            regErrors.password ? 'border-rose-500 ring-1 ring-rose-500' : 'border-slate-800 focus:border-violet-500'
                          } rounded-xl pl-10 pr-10 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none transition-all`}
                        />
                        <button
                          type="button"
                          onClick={() => setShowRegPassword(!showRegPassword)}
                          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                        >
                          {showRegPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>

                      {/* Password Strength Meter */}
                      <div className="space-y-1 pt-1">
                        <div className="flex gap-1.5 h-1.5">
                          <div
                            className={`flex-1 rounded-full transition-all duration-300 ${
                              passwordStrength.score >= 1 ? 'bg-rose-500' : 'bg-slate-800'
                            }`}
                          ></div>
                          <div
                            className={`flex-1 rounded-full transition-all duration-300 ${
                              passwordStrength.score >= 2 ? 'bg-amber-500' : 'bg-slate-800'
                            }`}
                          ></div>
                          <div
                            className={`flex-1 rounded-full transition-all duration-300 ${
                              passwordStrength.score >= 3 ? 'bg-yellow-400' : 'bg-slate-800'
                            }`}
                          ></div>
                          <div
                            className={`flex-1 rounded-full transition-all duration-300 ${
                              passwordStrength.score >= 4 ? 'bg-emerald-500' : 'bg-slate-800'
                            }`}
                          ></div>
                        </div>
                        <span className="text-[10px] text-slate-400 block font-medium">
                          Strength: <span style={{ color: passwordStrength.color }}>{passwordStrength.label}</span>
                        </span>
                      </div>

                      {regErrors.password && (
                        <p className="text-[11px] text-rose-400 font-medium">{regErrors.password}</p>
                      )}
                    </div>

                    {/* Confirm Password */}
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-300 block">
                        Confirm Password
                      </label>
                      <div className="relative">
                        <Shield className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          type={showRegConfirm ? 'text' : 'password'}
                          value={regConfirmPassword}
                          onChange={(e) => {
                            setRegConfirmPassword(e.target.value);
                            if (regErrors.confirmPassword) setRegErrors((prev) => ({ ...prev, confirmPassword: undefined }));
                          }}
                          placeholder="Re-enter password"
                          className={`w-full bg-[#121a2d] border ${
                            regErrors.confirmPassword ? 'border-rose-500 ring-1 ring-rose-500' : 'border-slate-800 focus:border-violet-500'
                          } rounded-xl pl-10 pr-10 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none transition-all`}
                        />
                        <button
                          type="button"
                          onClick={() => setShowRegConfirm(!showRegConfirm)}
                          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                        >
                          {showRegConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      {regErrors.confirmPassword && (
                        <p className="text-[11px] text-rose-400 font-medium">{regErrors.confirmPassword}</p>
                      )}
                    </div>

                    {/* Create Account Submit */}
                    <button
                      type="submit"
                      disabled={regSubmitting}
                      className="w-full mt-2 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 shadow-lg shadow-violet-600/30 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-60 flex items-center justify-center space-x-2"
                    >
                      {regSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          <span>Hashing & Registering...</span>
                        </>
                      ) : (
                        <>
                          <span>Create NexaID Account</span>
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </form>

                  <div className="pt-1 text-center text-xs text-slate-400">
                    Already have an account?{' '}
                    <button
                      onClick={() => setActiveTab('signin')}
                      className="text-cyan-400 hover:text-cyan-300 font-semibold underline underline-offset-2"
                    >
                      Sign In instead
                    </button>
                  </div>
                </div>
              )}

            </div>

          </div>
        )}
      </main>

      {/* =========================================================================
          DEMO VIDEO MANDATORY TITLE CARD MODAL (Section 16 & 17)
          ========================================================================= */}
      {showVideoCard && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex flex-col items-center justify-center p-4 sm:p-6 animate-in fade-in">
          <div className="max-w-2xl w-full bg-gradient-to-b from-[#0c1222] to-[#060913] border-2 border-violet-500/70 rounded-3xl p-8 sm:p-12 shadow-2xl relative text-center space-y-6">
            
            {/* Close Button */}
            <button
              onClick={() => setShowVideoCard(false)}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-2 rounded-xl bg-slate-900 border border-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            {/* 2-Second Mandatory Requirement Banner */}
            <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider bg-violet-950 text-violet-300 border border-violet-700">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>Section 16: Mandatory Demo Video Title Card</span>
            </div>

            {/* Title Card Details (Visible for at least 2 seconds) */}
            <div className="space-y-4 py-4 border-y border-slate-800/80">
              <div className="space-y-1">
                <p className="text-xs font-semibold uppercase tracking-widest text-cyan-400">
                  Candidate Full Name
                </p>
                <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                  Neha Vinod Borkar
                </h2>
              </div>

              <div className="space-y-1">
                <p className="text-xs font-semibold uppercase tracking-widest text-violet-400">
                  Assigned Track
                </p>
                <p className="text-xl sm:text-2xl font-bold text-slate-100">
                  Web Development & Designing
                </p>
              </div>

              <div className="space-y-1">
                <p className="text-xs font-semibold uppercase tracking-widest text-indigo-400">
                  Task Title
                </p>
                <p className="text-lg sm:text-xl font-bold text-white bg-slate-900/80 py-2 px-4 rounded-xl inline-block border border-slate-800">
                  Level 2 — Task 4: Login Authentication System
                </p>
              </div>
            </div>

            {/* 2-Second Countdown Timer */}
            <div className="flex flex-col items-center space-y-2">
              <div className="flex items-center space-x-2 text-xs text-slate-400">
                <span>Minimum Video Opening Duration:</span>
                <span className="font-mono font-bold text-cyan-400 text-sm">
                  {videoTimer > 0 ? `${videoTimer}s remaining` : '2s Requirement Met ✓'}
                </span>
              </div>
              <div className="w-48 h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-violet-500 to-cyan-400 transition-all duration-1000"
                  style={{ width: `${((2 - videoTimer) / 2) * 100}%` }}
                ></div>
              </div>
            </div>

            {/* Section 17 Demo Sequence Checklist */}
            <div className="text-left bg-slate-950/70 border border-slate-800/80 rounded-2xl p-4 text-xs space-y-2">
              <div className="font-bold text-slate-200 flex items-center justify-between">
                <span>Section 17 Video Sequence Guide:</span>
                <span className="text-[10px] text-cyan-400">10 Steps to Follow</span>
              </div>
              <ol className="list-decimal list-inside space-y-1 text-slate-400 text-[11px] leading-relaxed">
                <li>Show login page with NexaID branding</li>
                <li>Register a new test account with name & email</li>
                <li>Demonstrate field validation & password strength meter</li>
                <li>Sign in using the newly created credentials</li>
                <li>Show the protected dashboard and account metadata</li>
                <li>Log out and show session destruction</li>
                <li>Attempt to access dashboard while logged out (shows 401 rejection)</li>
                <li>Demonstrate rejection of incorrect credentials (generic error)</li>
                <li>Show responsive mobile/tablet layout</li>
                <li>Finish with project running successfully</li>
              </ol>
            </div>

            <div className="flex justify-center space-x-3">
              <button
                onClick={startVideoTimer}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-violet-600 hover:bg-violet-500 text-white transition-all shadow-md flex items-center space-x-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Restart 2-Second Timer</span>
              </button>
              <button
                onClick={() => setShowVideoCard(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all"
              >
                Dismiss Card & Proceed to Demo
              </button>
            </div>

          </div>
        </div>
      )}

      {/* =========================================================================
          PYTHON FLASK & SQLITE CODE INSPECTOR MODAL (Section 2 & 15)
          ========================================================================= */}
      {showCodeInspector && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="max-w-4xl w-full max-h-[90vh] bg-[#0c1222] border border-slate-800 rounded-3xl flex flex-col shadow-2xl overflow-hidden">
            
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
              <div className="flex items-center space-x-2">
                <FileCode className="w-5 h-5 text-cyan-400" />
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-white">
                    Oasis Infobyte Project Code Inspector
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Flask + SQLite repository tree for OIBSIP / Level 2 Login Authentication System
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowCodeInspector(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* File Tabs */}
            <div className="px-6 py-2.5 bg-slate-950/80 border-b border-slate-800/80 flex items-center justify-between overflow-x-auto gap-2">
              <div className="flex space-x-1.5 shrink-0">
                {(['app.py', 'templates/index.html', 'templates/dashboard.html', 'requirements.txt', 'README.md'] as const).map(
                  (fileName) => (
                    <button
                      key={fileName}
                      onClick={() => setSelectedCodeFile(fileName)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
                        selectedCodeFile === fileName
                          ? 'bg-violet-600 text-white shadow-sm'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                      }`}
                    >
                      {fileName}
                    </button>
                  )
                )}
              </div>

              <button
                onClick={copyCodeToClipboard}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center space-x-1 shrink-0"
              >
                {copiedFile ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>Copy File</span>
                  </>
                )}
              </button>
            </div>

            {/* Code Content */}
            <div className="flex-1 overflow-auto p-6 bg-[#080c16]">
              <pre className="text-xs font-mono text-slate-300 leading-relaxed overflow-x-auto">
                <code>{codeFiles[selectedCodeFile]}</code>
              </pre>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/60 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-400">
              <span>All source files are also written in <code className="text-cyan-400 font-mono">login-authentication/</code> and <code className="text-cyan-400 font-mono">OIBSIP/Level 2 Login Authentication System/</code></span>
              <button
                onClick={() => setShowCodeInspector(false)}
                className="px-4 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white font-medium"
              >
                Done
              </button>
            </div>

          </div>
        </div>
      )}

      {/* =========================================================================
          AUDIT LOG TRAIL MODAL
          ========================================================================= */}
      {showAuditModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="max-w-3xl w-full max-h-[85vh] bg-[#0c1222] border border-slate-800 rounded-3xl flex flex-col shadow-2xl overflow-hidden">
            
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
              <div className="flex items-center space-x-2">
                <Terminal className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-base text-white">Security Audit Log Trail</h3>
              </div>
              <button
                onClick={() => setShowAuditModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-auto p-6 space-y-3">
              {auditLogs.length === 0 ? (
                <div className="text-center py-10 text-slate-500 text-sm">
                  No security audit events recorded yet.
                </div>
              ) : (
                auditLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start justify-between gap-4 text-xs font-mono"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            log.action === 'LOGIN_SUCCESS' || log.action === 'REGISTER'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : log.action === 'LOGIN_FAILURE' || log.action === 'UNAUTHORIZED_ATTEMPT'
                              ? 'bg-rose-950 text-rose-300 border border-rose-800'
                              : 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                          }`}
                        >
                          {log.action}
                        </span>
                        <span className="text-slate-400 text-[11px] font-sans">
                          {log.details}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Target: {log.userEmail} &bull; Client IP: {log.ipAddress}
                      </div>
                    </div>
                    <span className="text-[11px] text-slate-400 shrink-0">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                ))
              )}
            </div>

            <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/60 flex justify-end">
              <button
                onClick={() => setShowAuditModal(false)}
                className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

      {/* =========================================================================
          CHANGE PASSWORD MODAL
          ========================================================================= */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="max-w-md w-full bg-[#0c1222] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-5">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <KeyRound className="w-5 h-5 text-violet-400" />
                <h3 className="font-bold text-base text-white">Change Account Password</h3>
              </div>
              <button
                onClick={() => setShowPasswordModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {passChangeError && (
              <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-300 text-xs flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{passChangeError}</span>
              </div>
            )}

            <form onSubmit={handleChangePassword} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300 block">
                  Current Password
                </label>
                <input
                  type="password"
                  value={currentPass}
                  onChange={(e) => setCurrentPass(e.target.value)}
                  placeholder="Enter current password"
                  className="w-full bg-[#121a2d] border border-slate-800 focus:border-violet-500 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300 block">
                  New Password (min 8 chars)
                </label>
                <input
                  type="password"
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  placeholder="Enter new strong password"
                  className="w-full bg-[#121a2d] border border-slate-800 focus:border-violet-500 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300 block">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  value={confirmNewPass}
                  onChange={(e) => setConfirmNewPass(e.target.value)}
                  placeholder="Re-enter new password"
                  className="w-full bg-[#121a2d] border border-slate-800 focus:border-violet-500 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-none"
                  required
                />
              </div>

              <div className="pt-2 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={passChangeLoading}
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-violet-600 hover:bg-violet-500 text-white shadow-md shadow-violet-600/30 disabled:opacity-60 flex items-center space-x-1.5"
                >
                  {passChangeLoading ? 'Updating Scrypt Hash...' : 'Update Password'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* =========================================================================
          Global Footer
          ========================================================================= */}
      <footer className="border-t border-slate-800/80 bg-[#060913] py-6 px-4 sm:px-6 lg:px-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <Shield className="w-4 h-4 text-cyan-400" />
            <span>
              <strong>NexaID</strong> &bull; Oasis Infobyte Internship — Web Development & Designing (Level 2, Task 4)
            </span>
          </div>

          <div className="flex items-center space-x-4 text-[11px]">
            <span>Candidate: <strong>Neha Vinod Borkar</strong></span>
            <span>&bull;</span>
            <span className="font-mono text-cyan-400">nehaborkar2408@gmail.com</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
