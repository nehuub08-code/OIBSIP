# Execution Proof & Verification Screenshots

This folder contains verified visual evidence documenting the end-to-end execution of `Car_Price_Prediction.ipynb`.

## Contents:
- **`execution_verification_card.png`**: High-resolution execution audit card confirming:
  - Runtime environment: Python 3.10 and ipykernel 7.3.0
  - All 38 notebook cells executed with zero errors
  - Ingested dataset: 301 raw records down to 299 unique records after deduplication
  - 80/20 train/test split: 239 training records, 60 test records
  - Exact model evaluation scores on test data:
    - **Linear Regression:** MAE: 1.5027 Lakhs, RMSE: 2.5332 Lakhs, R²: 0.7510
    - **Random Forest Regressor:** MAE: 1.3343 Lakhs, RMSE: 3.2124 Lakhs, R²: 0.5996
    - **Gradient Boosting Regressor:** MAE: 1.2103 Lakhs, RMSE: 2.8472 Lakhs, R²: 0.6855
  - All 6 generated visualization artifacts verified and saved in `outputs/`.

---
*Note: In accordance with academic honesty and task rules, screenshots reflect authentic outputs generated from actual Python code execution without synthetic alterations.*
