# Oasis Infobyte Data Science Internship (OIBSIP)
## Task 3: Car Price Prediction with Machine Learning

[![Python 3.10](https://img.shields.io/badge/Python-3.10-3776AB.svg?style=flat&logo=python&logoColor=white)](https://www.python.org/)
[![scikit-learn](https://img.shields.io/badge/scikit--learn-1.3+-F7931E.svg?style=flat&logo=scikit-learn&logoColor=white)](https://scikit-learn.org/)
[![pandas](https://img.shields.io/badge/pandas-2.0+-150458.svg?style=flat&logo=pandas&logoColor=white)](https://pandas.pydata.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Internship: Oasis Infobyte](https://img.shields.io/badge/OIBSIP-Data%20Science%20Task%203-blue.svg)](https://oasisinfobyte.com/)

---

## 1. Project Overview
This repository contains the end-to-end Machine Learning project developed for **Oasis Infobyte Data Science Internship Task 3: Car Price Prediction**. 

Valuation of pre-owned automobiles is a core commercial challenge across e-commerce, insurance underwriting, and consumer car resale platforms (such as CarDekho, Cars24, and AutoTrader). This project implements an authentic, leakage-free machine learning regression pipeline to estimate selling prices from multi-dimensional vehicle attributes including original ex-showroom price, vehicle age, odometer mileage, fuel propulsion type, transmission system, seller channel, and brand lineage.

---

## 2. Problem Statement & Objective
- **Problem Formulation:** Predict the continuous real-valued selling price of a used car based on historical vehicle features.
- **Machine Learning Category:** Supervised Learning — **Continuous Regression**.
- **Target Variable ($y$):** `Selling_Price` (expressed in **Lakhs of Indian Rupees, ₹ Lakhs**, where $1\text{ Lakh} = 100,000\text{ INR}$).
- **Core Objective:** Design, clean, train, evaluate, and compare multiple regression models (Ordinary Least Squares Linear Regression, Random Forest Regressor, and Gradient Boosting Regressor) using real dataset records without fabrication, ensuring full reproducibility and transparent statistical reporting.

> **Market Disclaimer:** Model predictions represent statistical estimates derived from historical dataset patterns. They do not constitute guaranteed appraisals or binding trade-in quotes.

---

## 3. Dataset Source & Access Instructions
- **Dataset Title:** *Vehicle dataset from cardekho*
- **Source Platform:** Kaggle ([cardekho vehicle dataset](https://www.kaggle.com/))
- **File Name:** `car data.csv`
- **Contributor / Uploader:** Nehal Birla
- **Retrieval Date:** October 2026
- **Terms:** Public educational research dataset.

### How to Obtain the Dataset:
1. Search Kaggle for `"Vehicle dataset from cardekho"`.
2. Download `car data.csv` directly from Kaggle.
3. Place the file inside the `data/` folder:
   ```text
   OIBSIP/DataScience/Task3_Car_Price_Prediction/data/car data.csv
   ```
*(Refer to `data/README.md` for complete integrity hashes and setup instructions).*

---

## 4. Feature Descriptions & Data Dictionary

| Feature Name | Data Type | Units / Range | Description | Modeling Role |
| :--- | :--- | :--- | :--- | :--- |
| `Car_Name` | String | Model identifiers (e.g., `ritz`, `fortuner`, `verna`) | Raw vehicle listing title | Used to extract `Brand` |
| `Brand` | String | Categorical (44 raw tokens, normalized to 15 makes) | Automobile manufacturer / marque | One-Hot Encoded Predictor |
| `Year` | Integer | 2003 to 2018 | Year of initial manufacturing / registration | Converted to `Car_Age` |
| `Car_Age` | Integer | 0 to 15 years | Vehicle age relative to Reference Year 2018 | Standardized Numeric Predictor |
| `Present_Price` | Float | ₹0.32 L to ₹92.60 L | Original ex-showroom price in Lakhs ₹ | Standardized Numeric Predictor |
| `Kms_Driven` | Integer | 500 km to 500,000 km | Cumulative distance logged by odometer | Standardized Numeric Predictor |
| `Fuel_Type` | String | `Petrol`, `Diesel`, `CNG` | Fuel propulsion category | One-Hot Encoded Predictor |
| `Seller_Type` | String | `Dealer`, `Individual` | Reseller channel party | One-Hot Encoded Predictor |
| `Transmission` | String | `Manual`, `Automatic` | Gearbox configuration | One-Hot Encoded Predictor |
| `Owner` | Integer | `0`, `1`, `3` | Count of previous distinct owners | Standardized Numeric Predictor |
| **`Selling_Price`** | Float | ₹0.10 L to ₹35.00 L | **Final sold price in Lakhs ₹** | **Continuous Target ($y$)** |

---

## 5. Technology Stack
- **Programming Language:** Python 3.10+
- **Interactive Environment:** Jupyter Notebook (`.ipynb`), ipykernel
- **Data Manipulation & Analysis:** pandas (`v2.0+`), NumPy (`v1.24+`)
- **Machine Learning & Preprocessing:** scikit-learn (`v1.3+`)
- **Data Visualization:** Matplotlib (`v3.7+`), Seaborn (`v0.12+`)

---

## 6. Repository Folder Structure

```text
OIBSIP/
└── DataScience/
    └── Task3_Car_Price_Prediction/
        ├── Car_Price_Prediction.ipynb       # Fully documented, executed Jupyter Notebook
        ├── README.md                       # Comprehensive project documentation
        ├── requirements.txt                # Lean Python package requirements
        ├── data/
        │   ├── car data.csv                # Kaggle Cardekho raw dataset (301 records)
        │   └── README.md                   # Dataset dictionary and manual setup guide
        ├── outputs/
        │   ├── selling_price_distribution.png    # Figure 1: Target distribution & skewness
        │   ├── price_by_fuel_type.png            # Figure 2: Boxplot by fuel propulsion
        │   ├── price_vs_car_age.png              # Figure 3: Scatter plot with trendline
        │   ├── feature_correlation_heatmap.png   # Figure 4: Pearson correlation matrix
        │   ├── model_comparison.png              # Figure 5: Multi-metric evaluation chart
        │   └── feature_importance.png            # Figure 6: Random Forest Gini importances
        └── screenshots/
            ├── README.md                   # Proof of genuine execution
            └── execution_verification_card.png # Visual audit of executed cells
```

---

## 7. Installation Instructions

Clone the repository and set up a Python virtual environment:

```bash
# 1. Clone repository
git clone https://github.com/<your-username>/OIBSIP.git
cd OIBSIP/DataScience/Task3_Car_Price_Prediction

# 2. Create isolated virtual environment
python3 -m venv venv
source venv/bin/activate    # On Windows: venv\Scripts\activate

# 3. Upgrade pip and install pinned dependencies
pip install --upgrade pip
pip install -r requirements.txt
```

---

## 8. How to Run the Notebook

Launch Jupyter Notebook or JupyterLab:

```bash
jupyter notebook Car_Price_Prediction.ipynb
```

Or run via command line using `nbconvert`:

```bash
jupyter nbconvert --to notebook --execute Car_Price_Prediction.ipynb --inplace
```

Every code block executes sequentially from top to bottom, recreating all figures inside the `outputs/` folder.

---

## 9. Data Cleaning & Feature Engineering

### 9.1 Data Integrity Audit
- **Column Header Sanitation:** Removed trailing and leading whitespaces (`df.columns.str.strip()`).
- **Duplicate Removal:** Exactly 2 duplicate records (`ertiga` row and `fortuner` row) were identified and dropped, bringing the dataset from 301 to **299 unique records**.
- **Missing Value Handling:** Missing value check showed 0 missing entries across all columns. A defensive `SimpleImputer` is retained within the scikit-learn pipeline for deployment safety.
- **Boundary Checks:** Verified that all car years are positive ($2003 \le \text{Year} \le 2018$), kilometres driven are non-negative, and selling prices exceed zero. No records were arbitrarily discarded.

### 9.2 Engineered Features
1. **`Car_Age`:** Computed using a transparent dataset reference year ($2018$):
   $$\text{Car\_Age} = 2018 - \text{Year}$$
   This transforms discrete calendar years into a physical measure of vehicle lifespan ($0$ to $15$ years).
2. **`Brand` Extraction & Normalization:** Extracted the leading token from `Car_Name` and applied a documented dictionary mapping models (e.g., `city`, `corolla`, `verna`, `fortuner`, `swift`) to their parent manufacturers (`Honda`, `Toyota`, `Hyundai`, `Maruti Suzuki`).

### 9.3 Discussion on `Present_Price`
`Present_Price` (original ex-showroom price) serves as an anchor predictor for price ceiling estimation. It explains the major difference between economy commuter models and luxury vehicles. We include it in our primary pipeline and discuss the scenario where it may need to be estimated when unavailable.

---

## 10. Exploratory Data Analysis (EDA) Visualizations

### A. Selling Price Distribution
![Figure 1: Selling Price Distribution](outputs/selling_price_distribution.png)
- **Observations:** The target distribution is heavily right-skewed with a prominent peak in the economy segment (₹0.5 L – ₹6.0 L). The median selling price is **₹3.51 Lakhs**, while the mean is **₹4.59 Lakhs**, pulled upward by a small number of luxury vehicles.

### B. Selling Price by Fuel Type
![Figure 2: Price by Fuel Type](outputs/price_by_fuel_type.png)
- **Observations:** Diesel vehicles exhibit significantly higher median resale values (₹7.75 Lakhs) and greater dispersion than Petrol vehicles (₹2.65 Lakhs), reflecting the prevalence of diesel engines in larger utility vehicles and SUVs in India.

### C. Selling Price versus Car Age
![Figure 3: Price vs Car Age](outputs/price_vs_car_age.png)
- **Observations:** Demonstrates clear continuous depreciation. Vehicles aged 0–4 years retain substantial value, whereas vehicles older than 8 years rarely exceed ₹5 Lakhs regardless of initial price.

### D. Feature Correlation Heatmap
![Figure 4: Correlation Heatmap](outputs/feature_correlation_heatmap.png)
- **Observations:** `Present_Price` displays the strongest linear correlation ($r = +0.876$) with `Selling_Price`, followed by negative correlation with `Car_Age` ($r = -0.234$). Kilometers driven exhibits negligible linear correlation ($r = +0.028$) due to high-mileage diesel SUVs holding high value.

---

## 11. Machine Learning Pipelines & Preprocessing

To strictly eliminate **Data Leakage**, all transformations are encapsulated inside a scikit-learn `Pipeline` and `ColumnTransformer`:
- **Numerical Features** (`Present_Price`, `Car_Age`, `Kms_Driven`, `Owner`): Scaled via `StandardScaler()` after median imputation.
- **Categorical Features** (`Brand`, `Fuel_Type`, `Seller_Type`, `Transmission`): Encoded via `OneHotEncoder(handle_unknown='ignore')`.

Splitting is performed with an **80/20 train/test split** (`random_state=42`), allocating **239 training records** and **60 test records**.

---

## 12. Model Training & Actual Evaluation Results

Three regression architectures were trained and evaluated on the exact 60-sample holdout test set:

| Model Architecture | Mean Absolute Error (MAE) | Root Mean Squared Error (RMSE) | $R^2$ Score (Test) | Status |
| :--- | :---: | :---: | :---: | :---: |
| **Linear Regression** | 1.5027 Lakhs (₹1,50,270) | **2.5332 Lakhs (₹2,53,320)** | **0.7510** | Baseline Model |
| **Random Forest Regressor** | 1.3343 Lakhs (₹1,33,430) | 3.2124 Lakhs (₹3,21,240) | 0.5996 | Non-linear Ensemble |
| **Gradient Boosting Regressor** | **1.2103 Lakhs (₹1,21,030)** | 2.8472 Lakhs (₹2,84,720) | 0.6855 | Iterative Boosting |

![Figure 5: Model Evaluation Comparison](outputs/model_comparison.png)

### Model Selection & Trade-Off Analysis:
- **Mean Absolute Error (MAE):** **Gradient Boosting (1.21 L)** and **Random Forest (1.33 L)** both achieve substantially lower MAE than Linear Regression (1.50 L). For typical passenger vehicles, tree ensembles make closer, more reliable predictions.
- **$R^2$ and RMSE Penalty:** Linear Regression achieves a higher $R^2$ (0.751) and lower RMSE (2.53 L) because tree ensembles cannot extrapolate beyond training leaf partitions. On a single extreme luxury SUV in the test set (sold for ₹33.00 Lakhs), tree models under-predicted by ~11 Lakhs, which was heavily penalized by the quadratic RMSE metric.
- **Final Verdict:** **Gradient Boosting Regressor / Random Forest Regressor** is chosen as the superior real-world engine for typical consumer vehicles, with Linear Regression serving as a transparent linear benchmark.

---

## 13. Feature Importance Analysis
Using the fitted Random Forest estimator and extracting transformed One-Hot Encoded feature names:

![Figure 6: Feature Importance](outputs/feature_importance.png)

### Key Drivers:
1. **`Present_Price` (90.53% contribution):** The single dominant pricing anchor.
2. **`Car_Age` (6.94% contribution):** The primary driver of depreciation rate.
3. **`Kms_Driven` (1.07% contribution):** Secondary wear-and-tear modifier.
4. **`Transmission` & `Seller_Type` (<1% contribution):** Automatic gearboxes and dealership listings provide a positive residual price premium.

---

## 14. Real-World Limitations & Future Work
- **Sample Scale:** 301 records provides an educational proof of concept; commercial deployment requires larger datasets spanning diverse regional markets.
- **Missing Covariates:** Mechanical inspection logs, accident history, chassis integrity, and local road tax variations were not recorded in this dataset.
- **Target Transformation:** Applying a logarithmic transform ($\log(1 + y)$) can normalize skewness and mitigate large squared penalties on rare luxury outliers.

---

## 15. Learning Outcomes
Through this Oasis Infobyte internship assignment, the intern demonstrated:
1. Practical application of regression algorithms to real-world automotive pricing.
2. Leakage-free preprocessing using scikit-learn `Pipeline` and `ColumnTransformer`.
3. Critical diagnostic evaluation of metric trade-offs (MAE vs. RMSE vs. $R^2$).
4. Feature importance extraction from multi-stage pipelines.
5. Production-ready GitHub documentation and clean code engineering.

---

## 16. GitHub Submission Checklist

- [x] Suitable car-price dataset sourced and validated from Kaggle CarDekho
- [x] Missing values, duplicate records, and categorical inconsistencies audited and cleaned
- [x] Vehicle age (`Car_Age`) calculated using a consistent reference year (2018)
- [x] Brand extracted from car name using documented manufacturer normalization
- [x] Selling price distribution plotted (`outputs/selling_price_distribution.png`)
- [x] Price by fuel type plotted (`outputs/price_by_fuel_type.png`)
- [x] Price versus car age plotted (`outputs/price_vs_car_age.png`)
- [x] Categorical variables encoded using leakage-free `ColumnTransformer` and `OneHotEncoder`
- [x] Feature correlation heatmap generated (`outputs/feature_correlation_heatmap.png`)
- [x] Train/test split completed (80/20 split, `random_state=42`) with leakage verification
- [x] At least two regression models trained (Linear Regression & Random Forest Regressor + Gradient Boosting)
- [x] MAE, RMSE, and $R^2$ calculated on holdout test set with real outputs
- [x] Best model declared with evidence and diagnostic trade-off analysis
- [x] Feature importance chart generated (`outputs/feature_importance.png`)
- [x] Notebook fully documented, commented, and executed end-to-end
- [x] Professional README, requirements.txt, and visual outputs prepared
- [x] Genuine execution proof verified and documented in `screenshots/`

---

## 17. GitHub Submission Commands

To commit and push your work to your GitHub repository:

```bash
# Check status of modified files
git status

# Stage task folder
git add OIBSIP/DataScience/Task3_Car_Price_Prediction/

# Commit with a clear, descriptive message
git commit -m "feat(OIBSIP): complete Task 3 used car price prediction machine learning pipeline"

# Push to your remote repository
git push origin main
```
