# Dataset Documentation & Setup Guide

## 1. Dataset Overview
- **Dataset Title:** Vehicle dataset from cardekho
- **Source Platform:** [Kaggle](https://www.kaggle.com/)
- **Common Uploader / Contributor:** Nehal Birla (Cardekho vehicle listings compilation)
- **Target File:** `car data.csv`
- **Retrieval Date:** October 2026
- **License / Terms of Use:** Available on Kaggle under open database terms for educational and research analysis (CC0 / Open Data Commons).

---

## 2. Dataset Structure & Data Dictionary

| Column Name | Data Type | Units / Format | Description | Role in ML |
| :--- | :--- | :--- | :--- | :--- |
| `Car_Name` | String / Object | Text (e.g. `ritz`, `fortuner`, `city`) | Model name or combined make/model identifier | Predictor (used to extract `Brand`) |
| `Year` | Integer | Calendar Year (2003 – 2018) | Manufacturing year of the vehicle | Used to compute `Car_Age = 2018 - Year` |
| `Selling_Price` | Float | ₹ Lakhs (1 Lakh = ₹100,000 INR) | The final price at which the vehicle is being sold | **Target Variable ($y$)** |
| `Present_Price` | Float | ₹ Lakhs (1 Lakh = ₹100,000 INR) | Current original ex-showroom price of the vehicle | Predictor ($X_{\text{num}}$) |
| `Kms_Driven` | Integer | Kilometres | Total cumulative distance driven by the vehicle | Predictor ($X_{\text{num}}$) |
| `Fuel_Type` | String / Categorical | `Petrol`, `Diesel`, `CNG` | Fuel engine propulsion type | Predictor ($X_{\text{cat}}$) |
| `Seller_Type` | String / Categorical | `Dealer`, `Individual` | Type of party listing the vehicle | Predictor ($X_{\text{cat}}$) |
| `Transmission` | String / Categorical | `Manual`, `Automatic` | Gearbox transmission mechanism | Predictor ($X_{\text{cat}}$) |
| `Owner` | Integer | Count (`0`, `1`, `3`) | Number of previous owners (0 = First-hand) | Predictor ($X_{\text{num}}$) |

---

## 3. How to Obtain and Setup `car data.csv` Locally

If you are cloning this repository from GitHub or setting up the project on a new machine:

1. Open your browser and navigate to [Kaggle](https://www.kaggle.com/).
2. In the Kaggle search bar, type:
   ```text
   Vehicle dataset from cardekho
   ```
3. Look for the dataset uploaded by **Nehal Birla** containing the file `car data.csv` (approx. 301 rows).
4. Click **Download** (requires a free Kaggle account).
5. Extract the downloaded archive and verify the file is named `car data.csv`.
6. Place `car data.csv` into this directory:
   ```bash
   OIBSIP/DataScience/Task3_Car_Price_Prediction/data/car data.csv
   ```
7. Verify file presence using terminal or python:
   ```bash
   ls -lh "data/car data.csv"
   # Expected: 301 rows (approx. 17 KB)
   ```

---

## 4. Integrity and Sanity Auditing Notes
- **Total Initial Records:** 301 rows, 9 columns.
- **Missing Values:** 0 missing values across all columns.
- **Duplicate Records:** Exactly 2 duplicate rows were identified during audit (one duplicate `ertiga` row and one duplicate `fortuner` row) and removed to prevent sample redundancy.
- **Post-Cleaning Dimensions:** 299 unique records.
- **Price Units:** All currency values are strictly formatted in **Lakhs of Indian Rupees (INR)**. For example, `3.35` signifies ₹3,35,000.
