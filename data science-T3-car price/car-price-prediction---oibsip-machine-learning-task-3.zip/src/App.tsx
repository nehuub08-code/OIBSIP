/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { LivePredictor } from './components/LivePredictor';
import { ProjectOverviewTab } from './components/ProjectOverviewTab';
import { EdaGalleryTab } from './components/EdaGalleryTab';
import { ModelsEvaluationTab } from './components/ModelsEvaluationTab';
import { FeatureImportanceTab } from './components/FeatureImportanceTab';
import { NotebookViewerTab } from './components/NotebookViewerTab';
import { DatasetExplorerTab } from './components/DatasetExplorerTab';
import { ChecklistModal } from './components/ChecklistModal';
import { Download, FileText, CheckCircle2, ShieldCheck, Heart } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('predictor');
  const [isChecklistOpen, setIsChecklistOpen] = useState<boolean>(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Navigation Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenChecklist={() => setIsChecklistOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'predictor' && <LivePredictor />}
        {activeTab === 'overview' && <ProjectOverviewTab />}
        {activeTab === 'eda' && <EdaGalleryTab />}
        {activeTab === 'models' && <ModelsEvaluationTab />}
        {activeTab === 'importance' && <FeatureImportanceTab />}
        {activeTab === 'notebook' && <NotebookViewerTab />}
        {activeTab === 'dataset' && <DatasetExplorerTab />}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-xs text-slate-400 mt-12 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <ShieldCheck className="w-4 h-4" />
            </span>
            <div>
              <p className="font-semibold text-slate-200">
                Oasis Infobyte Data Science Internship (OIBSIP) — Task 3
              </p>
              <p className="text-[11px] text-slate-400">
                Car Price Prediction • Python, scikit-learn, pandas, matplotlib, seaborn
              </p>
            </div>
          </div>

          <div className="flex items-center flex-wrap gap-3 text-[11px]">
            <a
              href="/Car_Price_Prediction.ipynb"
              download="Car_Price_Prediction.ipynb"
              className="text-blue-400 hover:text-blue-300 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <Download className="w-3 h-3" />
              <span>Car_Price_Prediction.ipynb (1.9MB)</span>
            </a>
            <span className="text-slate-700">•</span>
            <a
              href="/data/car_data.csv"
              download="car data.csv"
              className="text-blue-400 hover:text-blue-300 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <Download className="w-3 h-3" />
              <span>car data.csv</span>
            </a>
            <span className="text-slate-700">•</span>
            <button
              onClick={() => setIsChecklistOpen(true)}
              className="text-emerald-400 hover:text-emerald-300 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <CheckCircle2 className="w-3 h-3" />
              <span>Submission Checklist</span>
            </button>
          </div>
        </div>
      </footer>

      {/* Checklist & Git Submission Modal */}
      <ChecklistModal isOpen={isChecklistOpen} onClose={() => setIsChecklistOpen(false)} />
    </div>
  );
}
