export interface CarRecord {
  Car_Name: string;
  Year: number;
  Selling_Price: number;
  Present_Price: number;
  Kms_Driven: number;
  Fuel_Type: string;
  Seller_Type: string;
  Transmission: string;
  Owner: number;
  Car_Age?: number;
  Brand?: string;
}

export interface ModelMetric {
  Model: string;
  MAE: number;
  RMSE: number;
  R2: number;
}

export interface FeatureImportanceItem {
  name: string;
  pct: number;
}

export interface DatasetStats {
  total_rows: number;
  original_rows: number;
  duplicates_removed: number;
  train_samples: number;
  test_samples: number;
  mean_selling_price: number;
  median_selling_price: number;
  min_selling_price: number;
  max_selling_price: number;
  mean_age: number;
  mean_kms: number;
}

export interface MlSummary {
  metrics: ModelMetric[];
  top_features: FeatureImportanceItem[];
  dataset_stats: DatasetStats;
}

export interface PredictionInput {
  brand: string;
  presentPrice: number; // in Lakhs
  year: number;
  kmsDriven: number;
  fuelType: 'Petrol' | 'Diesel' | 'CNG';
  sellerType: 'Dealer' | 'Individual';
  transmission: 'Manual' | 'Automatic';
  owner: number;
}

export interface PredictionOutput {
  linearPrice: number;
  rfPrice: number;
  gbPrice: number;
  recommendedPrice: number;
  depreciationPct: number;
  rangeMin: number;
  rangeMax: number;
}
