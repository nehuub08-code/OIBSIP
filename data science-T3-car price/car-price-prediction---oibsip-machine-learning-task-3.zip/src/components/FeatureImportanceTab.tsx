import React from 'react';
import { Sliders, BarChart, ShieldAlert, Sparkles, CheckCircle2 } from 'lucide-react';

interface FeatureImportanceRow {
  name: string;
  pct: number;
  category: string;
  description: string;
}

const FEATURE_IMPORTANCES: FeatureImportanceRow[] = [
  {
    name: 'Present_Price',
    pct: 90.53,
    category: 'Showroom Price',
    description: 'Current ex-showroom price anchoring the vehicle market valuation tier.'
  },
  {
    name: 'Car_Age',
    pct: 6.94,
    category: 'Depreciation',
    description: 'Years elapsed since manufacturing (2018 - Year), driving physical aging.'
  },
  {
    name: 'Kms_Driven',
    pct: 1.07,
    category: 'Odometer Mileage',
    description: 'Cumulative usage distance reflecting engine, suspension, and brake wear.'
  },
  {
    name: 'Transmission_Manual',
    pct: 0.37,
    category: 'Transmission',
    description: 'Manual gearbox configuration reflecting higher volume and lower premium.'
  },
  {
    name: 'Transmission_Automatic',
    pct: 0.36,
    category: 'Transmission',
    description: 'Automatic transmission commanding a consistent convenience price premium.'
  },
  {
    name: 'Seller_Type_Individual',
    pct: 0.14,
    category: 'Sales Channel',
    description: 'Private party listing typically priced lower without dealer warranties.'
  },
  {
    name: 'Brand_Honda',
    pct: 0.13,
    category: 'Manufacturer',
    description: 'Strong engine reliability and resale market retention in India.'
  },
  {
    name: 'Brand_Toyota',
    pct: 0.11,
    category: 'Manufacturer',
    description: 'Exceptional durability reputation (Innova, Fortuner, Corolla Altis).'
  },
  {
    name: 'Seller_Type_Dealer',
    pct: 0.11,
    category: 'Sales Channel',
    description: 'Certified dealership listings commanding reconditioning margins.'
  },
  {
    name: 'Brand_Hyundai',
    pct: 0.07,
    category: 'Manufacturer',
    description: 'Feature-rich popular compact cars and SUVs (i20, Creta, Verna).'
  },
  {
    name: 'Fuel_Type_Diesel',
    pct: 0.07,
    category: 'Engine Fuel',
    description: 'Fuel economy and high torque favored in mid-size and larger vehicles.'
  },
  {
    name: 'Fuel_Type_Petrol',
    pct: 0.07,
    category: 'Engine Fuel',
    description: 'Standard commuter vehicle propulsion.'
  }
];

export const FeatureImportanceTab: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-xs font-semibold bg-purple-500/10 text-purple-400 border border-purple-500/20 mb-1">
              <Sliders className="w-3.5 h-3.5" />
              <span>Section 12 Feature Importance</span>
            </div>
            <h2 className="text-xl font-bold text-white">Random Forest Feature Importance Analysis</h2>
            <p className="text-xs text-slate-400">
              Extracted directly from the fitted <code className="text-blue-300">RandomForestRegressor</code> pipeline using transformed one-hot encoded category names.
            </p>
          </div>
        </div>
      </div>

      {/* Main Chart Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <BarChart className="w-4 h-4 text-purple-400" />
            <h3 className="text-sm font-bold text-white">Figure 6: Top 10 Feature Importances</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">outputs/feature_importance.png</span>
        </div>

        <div className="bg-white rounded-lg p-3 max-w-4xl mx-auto shadow-inner">
          <img
            src="/outputs/feature_importance.png"
            alt="Figure 6: Feature Importance"
            className="w-full h-auto object-contain rounded"
          />
        </div>
      </div>

      {/* Breakdown Table & Context */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Table (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
          <div className="p-4 border-b border-slate-800">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Detailed Feature Contribution Ranking
            </h4>
          </div>

          <div className="p-4 space-y-3">
            {FEATURE_IMPORTANCES.map((feat, idx) => (
              <div key={feat.name} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200 flex items-center gap-2">
                    <span className="text-[10px] text-slate-500 w-4 font-mono">{idx + 1}.</span>
                    <span className="font-mono text-blue-400">{feat.name}</span>
                    <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.2 rounded">
                      {feat.category}
                    </span>
                  </span>
                  <span className="font-bold text-white font-mono">{feat.pct.toFixed(2)}%</span>
                </div>
                {/* Visual bar */}
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-blue-500 to-indigo-500 h-full rounded-full"
                    style={{ width: `${Math.max(2, Math.min(100, feat.pct))}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-400">{feat.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Analytical Notes (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-blue-400 font-bold text-sm">
              <Sparkles className="w-4 h-4" />
              <span>Key Analytical Insights</span>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800">
                <strong className="text-white block mb-0.5">1. Showroom Price Sets the Ceiling</strong>
                <p className="text-slate-400 leading-relaxed">
                  With over <strong>90.5%</strong> importance, <code className="text-blue-300">Present_Price</code> anchors the valuation tier. A used Toyota Fortuner originally priced at ₹30 Lakhs will inevitably sell for more than an economy hatchback originally priced at ₹5 Lakhs, regardless of mileage.
                </p>
              </div>

              <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800">
                <strong className="text-white block mb-0.5">2. Car Age Dictates Depreciation Rate</strong>
                <p className="text-slate-400 leading-relaxed">
                  With nearly <strong>7%</strong> contribution, <code className="text-blue-300">Car_Age</code> is the primary time decay variable. Each year elapsed chips away value at a compounding rate.
                </p>
              </div>

              <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800">
                <strong className="text-white block mb-0.5">3. Transmission & Seller Type Refinements</strong>
                <p className="text-slate-400 leading-relaxed">
                  Automatic gearboxes and authorized dealer listings provide modest positive adjustments of approximately ₹0.5L – ₹0.8L in the final dot product.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
              <ShieldAlert className="w-4 h-4" />
              <span>Predictive Importance vs. Physical Causation</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Tree-based feature importance indicates the mathematical reduction in variance (Gini impurity) achieved by splits on that variable in this specific dataset. It does not establish that changing an individual variable in isolation will cause a corresponding price change without considering correlated market forces.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
