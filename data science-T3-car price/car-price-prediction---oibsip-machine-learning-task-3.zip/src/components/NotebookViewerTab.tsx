import React, { useState } from 'react';
import { BookOpen, Download, Code, CheckCircle, FileCode, ChevronRight, Copy } from 'lucide-react';

interface NotebookSection {
  number: number;
  title: string;
  summary: string;
  codeSnippet: string;
  outputPreview?: string;
  keyTakeaway: string;
}

const NOTEBOOK_SECTIONS: NotebookSection[] = [
  {
    number: 1,
    title: 'Introduction & Problem Formulation',
    summary:
      'Defines used car price prediction, explains why regression is the mathematically sound formulation, defines the continuous target Selling_Price in Lakhs ₹, and reviews the end-to-end ML workflow.',
    codeSnippet: `# Target Variable: Selling_Price (₹ Lakhs)
# Predictor Features: Brand, Present_Price, Kms_Driven, Fuel_Type, Seller_Type, Transmission, Owner, Car_Age
# Objective: Develop an interpretable regression pipeline to predict vehicle valuations accurately.`,
    keyTakeaway: 'Regression predicts continuous real-valued quantities, unlike classification which predicts discrete categories.'
  },
  {
    number: 2,
    title: 'Environment Imports & Dataset Loading',
    summary:
      'Imports pandas, numpy, matplotlib, seaborn, scikit-learn tools, and loads the CSV using robust fallback relative paths with clear error handling.',
    codeSnippet: `import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor

data_path = 'data/car data.csv'
df_raw = pd.read_csv(data_path)
print("Initial Dimensions:", df_raw.shape) # (301, 9)`,
    outputPreview: 'Dataset successfully loaded from: data/car data.csv\nInitial Dataset Dimensions: 301 rows, 9 columns\nMissing values: 0 across all fields',
    keyTakeaway: 'Always include helpful error messages if datasets are missing.'
  },
  {
    number: 3,
    title: 'Data Cleaning & Boundary Auditing',
    summary:
      'Strips whitespace from column names, detects and drops 2 duplicate records (ertiga and fortuner duplicate listings), and runs boundary sanity checks.',
    codeSnippet: `# 1. Clean Column Headers
df = df_raw.copy()
df.columns = df.columns.str.strip()

# 2. Audit and Drop Duplicate Rows
duplicates = df[df.duplicated(keep=False)]
df = df.drop_duplicates().reset_index(drop=True)

# 3. Physical Boundary Assertions
assert (df['Year'] > 1980).all(), "Invalid year detected"
assert (df['Kms_Driven'] >= 0).all(), "Negative kms detected"
assert (df['Selling_Price'] > 0).all(), "Non-positive selling price"`,
    outputPreview: 'Total duplicate records identified: 4 (2 redundant rows dropped)\nDimensions after dropping duplicates: 299 rows, 9 columns\nAll physical integrity checks passed successfully!',
    keyTakeaway: 'Never silently drop or impute values without verifying integrity and documenting rationale.'
  },
  {
    number: 4,
    title: 'Feature Engineering (Car_Age & Brand)',
    summary:
      'Derives Car_Age from consistent Reference Year (2018) and extracts parent automobile brands from Car_Name with a documented mapping dictionary.',
    codeSnippet: `# A. Calculate Car Age
REFERENCE_YEAR = 2018
df['Car_Age'] = REFERENCE_YEAR - df['Year']

# B. Extract Brand and Standardize
raw_token = df['Car_Name'].str.strip().str.split().str[0].str.lower()
df['Brand'] = raw_token.map(lambda x: brand_mapping.get(x, x.capitalize()))`,
    outputPreview: 'Car_Age range: 0 to 15 years old (Mean: 4.4 years)\nExtracted Brands: Maruti Suzuki, Hyundai, Honda, Toyota, Royal Enfield, etc.',
    keyTakeaway: 'Car Age is a continuous physical measure of depreciation, much more informative than raw calendar years.'
  },
  {
    number: 5,
    title: 'Exploratory Data Analysis (EDA)',
    summary:
      'Generates and interprets 4 publication-quality visualizations saved to outputs/ (distribution, fuel boxplot, age scatter, correlation matrix).',
    codeSnippet: `# Figure 1: Selling Price Distribution
fig, ax = plt.subplots(figsize=(10, 6), dpi=300)
sns.histplot(df['Selling_Price'], kde=True, color='#2563eb', bins=25, ax=ax)
fig.savefig('outputs/selling_price_distribution.png')

# Figure 2: Price by Fuel Type
fig, ax = plt.subplots(figsize=(9, 6), dpi=300)
sns.boxplot(data=df, x='Fuel_Type', y='Selling_Price', palette=palette, ax=ax)
fig.savefig('outputs/price_by_fuel_type.png')

# Figure 3: Price vs Car Age
fig, ax = plt.subplots(figsize=(10, 6), dpi=300)
sns.regplot(data=df, x='Car_Age', y='Selling_Price', ax=ax)
fig.savefig('outputs/price_vs_car_age.png')`,
    outputPreview: 'All EDA figures generated and saved to outputs/ directory.',
    keyTakeaway: 'Diesel vehicles command a significant price premium over petrol vehicles; price decays non-linearly with age.'
  },
  {
    number: 6,
    title: 'Categorical Encoding & Pipeline Architecture',
    summary:
      'Encapsulates OneHotEncoder and StandardScaler inside scikit-learn ColumnTransformer to strictly prevent data leakage between train and test splits.',
    codeSnippet: `num_features = ['Present_Price', 'Kms_Driven', 'Car_Age', 'Owner']
cat_features = ['Brand', 'Fuel_Type', 'Seller_Type', 'Transmission']

preprocessor = ColumnTransformer(
    transformers=[
        ('num', Pipeline([('scaler', StandardScaler())]), num_features),
        ('cat', Pipeline([('encoder', OneHotEncoder(handle_unknown='ignore', sparse_output=False))]), cat_features)
    ]
)`,
    outputPreview: 'ColumnTransformer pipeline defined. Categoricals encoded with handle_unknown="ignore".',
    keyTakeaway: 'Encapsulating preprocessing in Pipeline prevents train/test leakage during model evaluation.'
  },
  {
    number: 7,
    title: 'Feature Correlation Heatmap',
    summary:
      'Computes Pearson correlation coefficients across continuous features and generates outputs/feature_correlation_heatmap.png.',
    codeSnippet: `corr_cols = ['Selling_Price', 'Present_Price', 'Car_Age', 'Kms_Driven', 'Owner']
corr_matrix = df[corr_cols].corr()
fig, ax = plt.subplots(figsize=(8, 6), dpi=300)
sns.heatmap(corr_matrix, annot=True, fmt='.3f', cmap='Blues', ax=ax)
fig.savefig('outputs/feature_correlation_heatmap.png')`,
    outputPreview: 'Selling_Price correlations:\nPresent_Price: +0.876\nCar_Age:      -0.234\nOwner:        -0.088\nKms_Driven:   +0.028',
    keyTakeaway: 'Present_Price has the strongest positive correlation (+0.876); Car_Age has negative correlation (-0.234).'
  },
  {
    number: 8,
    title: 'Train / Test Split & Leakage Auditing',
    summary:
      'Splits dataset into 80% training (239 samples) and 20% holdout testing (60 samples) with fixed random_state=42 and verifies target variable isolation.',
    codeSnippet: `X = df[feature_columns]
y = df['Selling_Price']

# Explicit Leakage Check
assert 'Selling_Price' not in X.columns, "DATA LEAKAGE DETECTED!"

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)
print(f"Train samples: {len(X_train)}, Test samples: {len(X_test)}")`,
    outputPreview: 'Total Records: 299\nTrain samples: 239 (80%)\nTest samples: 60 (20%)',
    keyTakeaway: 'The test set is quarantined until final evaluation; preprocessing is fitted solely on X_train.'
  },
  {
    number: 9,
    title: 'Model Training (Linear Regression vs. Random Forest vs. Gradient Boosting)',
    summary:
      'Builds and fits pipelines for Multiple Linear Regression, Random Forest Regressor (100 trees), and Gradient Boosting Regressor.',
    codeSnippet: `pipelines = {
    'Linear Regression': Pipeline([('preprocessor', preprocessor), ('regressor', LinearRegression())]),
    'Random Forest Regressor': Pipeline([('preprocessor', preprocessor), ('regressor', RandomForestRegressor(n_estimators=100, random_state=42))]),
    'Gradient Boosting Regressor': Pipeline([('preprocessor', preprocessor), ('regressor', GradientBoostingRegressor(n_estimators=100, random_state=42))])
}
for name, pipe in pipelines.items():
    pipe.fit(X_train, y_train)`,
    outputPreview: 'Fitting Linear Regression...\nFitting Random Forest Regressor...\nFitting Gradient Boosting Regressor...\nAll 3 models fitted successfully.',
    keyTakeaway: 'Pipelines ensure preprocessing transformations are applied automatically during fit and predict.'
  },
  {
    number: 10,
    title: 'Comprehensive Model Evaluation',
    summary:
      'Calculates MAE, RMSE, and R² scores on the holdout test set using real predictions and plots outputs/model_comparison.png.',
    codeSnippet: `for name, model in fitted_models.items():
    y_pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)
    eval_records.append({'Model': name, 'MAE': mae, 'RMSE': rmse, 'R2': r2})`,
    outputPreview: 'Model                     MAE      RMSE     R2\nLinear Regression        1.5027   2.5332   0.7510\nRandom Forest Regressor  1.3343   3.2124   0.5996\nGradient Boosting        1.2103   2.8472   0.6855',
    keyTakeaway: 'MAE measures average error in ₹ Lakhs; RMSE penalizes rare large errors quadratically; R² measures explained variance.'
  },
  {
    number: 11,
    title: 'Model Selection & Diagnostic Trade-Off Analysis',
    summary:
      'Explains why Random Forest and Gradient Boosting achieve lower MAE (tighter predictions on 95% of cars) while Linear Regression has higher R² due to a single luxury outlier.',
    codeSnippet: `# Residual Error Investigation:
# Record index 63: Toyota Fortuner sold for ₹33.00 Lakhs!
# Tree models under-predict because they cannot extrapolate beyond training leaf bounds.
# Squared error (11.2L)^2 = 125.44 heavily inflates RMSE and dampens R2.`,
    outputPreview: 'Verified: Gradient Boosting / Random Forest selected as superior model for consumer vehicle valuation due to lowest MAE.',
    keyTakeaway: 'Always analyze the difference between MAE and RMSE before picking a model based solely on R².'
  },
  {
    number: 12,
    title: 'Feature Importance Analysis',
    summary:
      'Extracts feature_importances_ from fitted Random Forest and generates outputs/feature_importance.png using one-hot encoded category names.',
    codeSnippet: `rf_reg = fitted_models['Random Forest Regressor'].named_steps['regressor']
cat_trans = fitted_models['Random Forest Regressor'].named_steps['preprocessor'].named_transformers_['cat']
ohe_names = cat_trans.named_steps['encoder'].get_feature_names_out(cat_features)
all_names = list(num_features) + list(ohe_names)

feat_imp = pd.DataFrame({'Feature': all_names, 'Importance': rf_reg.feature_importances_})`,
    outputPreview: 'Top Predictive Features:\nPresent_Price: 90.53%\nCar_Age:        6.94%\nKms_Driven:     1.07%\nTransmission:   0.73%',
    keyTakeaway: 'Present_Price dominates prediction (90.5%), followed by Car_Age (6.9%).'
  },
  {
    number: 13,
    title: 'Conclusions, Limitations & Submission Checklist',
    summary:
      'Reviews key deliverables, documents real-world dataset limitations, and verifies all 16 items of the Oasis Infobyte Task 3 submission checklist.',
    codeSnippet: `# Final Verification: All 16 checklist items verified.
# All 6 output PNGs generated. Notebook executed end-to-end with zero errors.`,
    outputPreview: 'Submission ready for: OIBSIP/DataScience/Task3_Car_Price_Prediction/',
    keyTakeaway: 'The project is 100% reproducible, rigorously documented, and ready for internship submission.'
  }
];

export const NotebookViewerTab: React.FC = () => {
  const [activeSection, setActiveSection] = useState<number>(1);
  const currentSection = NOTEBOOK_SECTIONS.find((s) => s.number === activeSection) || NOTEBOOK_SECTIONS[0];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 mb-1">
              <BookOpen className="w-3.5 h-3.5" />
              <span>Interactive Notebook Walkthrough</span>
            </div>
            <h2 className="text-xl font-bold text-white">Car_Price_Prediction.ipynb (All 13 Sections)</h2>
            <p className="text-xs text-slate-400">
              Fully executed Jupyter Notebook containing 38 cells with verified code, markdown commentary, and embedded charts.
            </p>
          </div>

          <a
            href="/Car_Price_Prediction.ipynb"
            download="Car_Price_Prediction.ipynb"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white shadow transition-colors cursor-pointer shrink-0"
          >
            <Download className="w-4 h-4" />
            <span>Download .ipynb (1.9 MB)</span>
          </a>
        </div>
      </div>

      {/* 2-Column: Section Selector on Left, Section Detail on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Navigation Menu (4 cols) */}
        <div className="lg:col-span-4 space-y-1.5 max-h-[720px] overflow-y-auto pr-1">
          {NOTEBOOK_SECTIONS.map((sec) => (
            <button
              key={sec.number}
              onClick={() => setActiveSection(sec.number)}
              className={`w-full text-left p-3 rounded-lg border text-xs transition-all cursor-pointer flex items-center justify-between ${
                activeSection === sec.number
                  ? 'bg-blue-600/20 border-blue-500 text-white font-bold'
                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <div className="flex items-center gap-2.5 truncate">
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] shrink-0 font-bold ${
                  activeSection === sec.number ? 'bg-blue-500 text-white' : 'bg-slate-800 text-slate-400'
                }`}>
                  {sec.number}
                </span>
                <span className="truncate">{sec.title}</span>
              </div>
              <ChevronRight className={`w-3.5 h-3.5 shrink-0 ${activeSection === sec.number ? 'text-blue-400' : 'text-slate-600'}`} />
            </button>
          ))}
        </div>

        {/* Right: Section Content & Code (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[11px] font-bold text-blue-400 uppercase tracking-wider">
                  Notebook Section {currentSection.number} of 13
                </span>
                <h3 className="text-lg font-bold text-white">{currentSection.title}</h3>
              </div>
              <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                <span>Cell Executed</span>
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              {currentSection.summary}
            </p>

            {/* Code Block */}
            <div className="bg-slate-950 rounded-lg border border-slate-800 overflow-hidden">
              <div className="bg-slate-900/80 px-3 py-1.5 border-b border-slate-800 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                <span className="flex items-center gap-1.5">
                  <Code className="w-3.5 h-3.5 text-blue-400" />
                  <span>Python [In {currentSection.number}]:</span>
                </span>
                <span>scikit-learn / pandas</span>
              </div>
              <pre className="p-3 text-xs font-mono text-emerald-300 overflow-x-auto leading-relaxed">
                {currentSection.codeSnippet}
              </pre>
            </div>

            {/* Output Preview (if present) */}
            {currentSection.outputPreview && (
              <div className="bg-slate-950/60 rounded-lg border border-slate-800/80 overflow-hidden">
                <div className="bg-slate-900/40 px-3 py-1 border-b border-slate-800/60 text-[10px] text-slate-500 font-mono">
                  [Out {currentSection.number} Output Stream]:
                </div>
                <pre className="p-3 text-[11px] font-mono text-slate-300 overflow-x-auto whitespace-pre-wrap">
                  {currentSection.outputPreview}
                </pre>
              </div>
            )}

            {/* Key pedagogical takeaway */}
            <div className="bg-blue-950/30 border border-blue-500/20 rounded-lg p-3 text-xs text-slate-300">
              <strong className="text-blue-300 font-semibold block mb-0.5">Mentor Key Takeaway:</strong>
              <span>{currentSection.keyTakeaway}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
