import React from 'react';
import { Target, Layers, Workflow, Database, AlertCircle, CheckCircle, FileText, ExternalLink } from 'lucide-react';

export const ProjectOverviewTab: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Hero Mission Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="max-w-4xl">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 mb-3">
            <Target className="w-3.5 h-3.5" />
            <span>Oasis Infobyte Internship • Task 3 Objective</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight mb-2">
            Used Car Price Prediction Using Machine Learning Regression
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            The major objective of this project is to develop, evaluate, and interpret an authentic machine learning pipeline capable of predicting pre-owned vehicle selling prices based on physical vehicle attributes (such as ex-showroom present price, vehicle age, odometer kilometers, fuel variety, transmission type, and seller channel).
          </p>
        </div>

        {/* 3 Metric Pills */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 pt-6 border-t border-slate-800">
          <div className="bg-slate-950/70 p-3.5 rounded-lg border border-slate-800">
            <div className="text-xs text-slate-400 font-medium">Target Variable ($y$)</div>
            <div className="text-lg font-bold text-emerald-400 mt-0.5">Selling_Price</div>
            <div className="text-xs text-slate-500 mt-1">Continuous numerical (Lakhs ₹)</div>
          </div>

          <div className="bg-slate-950/70 p-3.5 rounded-lg border border-slate-800">
            <div className="text-xs text-slate-400 font-medium">Dataset Source</div>
            <div className="text-lg font-bold text-blue-400 mt-0.5">Kaggle CarDekho</div>
            <div className="text-xs text-slate-500 mt-1">301 records • 9 core columns</div>
          </div>

          <div className="bg-slate-950/70 p-3.5 rounded-lg border border-slate-800">
            <div className="text-xs text-slate-400 font-medium">Modeling Paradigm</div>
            <div className="text-lg font-bold text-purple-400 mt-0.5">Supervised Regression</div>
            <div className="text-xs text-slate-500 mt-1">Linear, RF, and Gradient Boost</div>
          </div>
        </div>
      </div>

      {/* Why Regression & Real-World Framing */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center gap-2 text-blue-400 font-semibold text-sm">
            <Layers className="w-4 h-4" />
            <span>Why is Regression the Appropriate Paradigm?</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            In supervised machine learning, problems are categorized into **Classification** (predicting discrete categorical labels such as fraud/legitimate) and **Regression** (predicting continuous real-valued quantities).
          </p>
          <p className="text-xs text-slate-300 leading-relaxed">
            Because a vehicle's selling price is a continuous scalar variable with infinite possible numeric values on the real number line (R+), regression algorithms (such as Ordinary Least Squares, Random Forest Regressors, and Gradient Boosted Trees) provide the necessary mathematical mechanics to estimate valuation without arbitrary binning.
          </p>
          <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800 text-xs text-slate-400 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>
              <strong>Crucial Real-World Note:</strong> Statistical predictions are mathematical approximations reflecting historical trends. They represent informed valuations, not binding market quotes.
            </span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
            <Workflow className="w-4 h-4" />
            <span>End-to-End Machine Learning Workflow</span>
          </div>
          <div className="space-y-2">
            {[
              { step: '1', title: 'Data Ingestion & Integrity Audit', desc: 'Loading Kaggle CarDekho dataset, sanitizing column whitespace, and checking boundaries.' },
              { step: '2', title: 'Deduplication & Cleaning', desc: 'Identifying and dropping 2 redundant rows (Ertiga & Fortuner duplicates).' },
              { step: '3', title: 'Feature Engineering', desc: 'Deriving Car_Age (2018 - Year) and normalizing parent Brand lineages.' },
              { step: '4', title: 'Exploratory Data Analysis', desc: 'Histogram KDE, Fuel boxplots, Age scatter trendlines, and correlation heatmaps.' },
              { step: '5', title: 'Leakage-Free Preprocessing', desc: 'Encapsulating ColumnTransformer (StandardScaler + OneHotEncoder) inside Pipeline.' },
              { step: '6', title: 'Model Training & Evaluation', desc: 'Fitting on 80% train split and computing MAE, RMSE, and R² on 20% holdout test set.' }
            ].map((s) => (
              <div key={s.step} className="flex items-start gap-2.5 text-xs">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-blue-400 font-bold flex items-center justify-center shrink-0 text-[11px] border border-slate-700">
                  {s.step}
                </span>
                <div>
                  <strong className="text-slate-200">{s.title}:</strong>{' '}
                  <span className="text-slate-400">{s.desc}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Data Dictionary */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-blue-400" />
            <h3 className="text-base font-bold text-white">Feature Data Dictionary</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">Dataset: car data.csv</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/60 font-semibold">
                <th className="py-2.5 px-3">Column Name</th>
                <th className="py-2.5 px-3">Data Type</th>
                <th className="py-2.5 px-3">Units / Format</th>
                <th className="py-2.5 px-3">Description</th>
                <th className="py-2.5 px-3">Role in Modeling</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr className="hover:bg-slate-800/30">
                <td className="py-2.5 px-3 font-mono font-medium text-blue-300">Selling_Price</td>
                <td className="py-2.5 px-3 text-slate-400">Float</td>
                <td className="py-2.5 px-3">₹ Lakhs (0.10 – 35.00)</td>
                <td className="py-2.5 px-3">Final recorded selling price of the used car</td>
                <td className="py-2.5 px-3 font-bold text-emerald-400">Target Variable (y)</td>
              </tr>
              <tr className="hover:bg-slate-800/30">
                <td className="py-2.5 px-3 font-mono font-medium text-slate-200">Present_Price</td>
                <td className="py-2.5 px-3 text-slate-400">Float</td>
                <td className="py-2.5 px-3">₹ Lakhs (0.32 – 92.60)</td>
                <td className="py-2.5 px-3">Original ex-showroom purchase price when new</td>
                <td className="py-2.5 px-3 text-blue-400">Numeric Predictor (X_num)</td>
              </tr>
              <tr className="hover:bg-slate-800/30">
                <td className="py-2.5 px-3 font-mono font-medium text-slate-200">Car_Age</td>
                <td className="py-2.5 px-3 text-slate-400">Integer</td>
                <td className="py-2.5 px-3">Years (0 – 15 yrs)</td>
                <td className="py-2.5 px-3">Engineered: Reference Year (2018) minus Year</td>
                <td className="py-2.5 px-3 text-blue-400">Numeric Predictor (X_num)</td>
              </tr>
              <tr className="hover:bg-slate-800/30">
                <td className="py-2.5 px-3 font-mono font-medium text-slate-200">Kms_Driven</td>
                <td className="py-2.5 px-3 text-slate-400">Integer</td>
                <td className="py-2.5 px-3">Kilometres (500 – 500,000)</td>
                <td className="py-2.5 px-3">Total cumulative distance logged on odometer</td>
                <td className="py-2.5 px-3 text-blue-400">Numeric Predictor (X_num)</td>
              </tr>
              <tr className="hover:bg-slate-800/30">
                <td className="py-2.5 px-3 font-mono font-medium text-slate-200">Brand</td>
                <td className="py-2.5 px-3 text-slate-400">Categorical</td>
                <td className="py-2.5 px-3">12 Normalized Brands</td>
                <td className="py-2.5 px-3">Extracted parent brand from Car_Name</td>
                <td className="py-2.5 px-3 text-purple-400">Categorical Predictor (X_cat)</td>
              </tr>
              <tr className="hover:bg-slate-800/30">
                <td className="py-2.5 px-3 font-mono font-medium text-slate-200">Fuel_Type</td>
                <td className="py-2.5 px-3 text-slate-400">Categorical</td>
                <td className="py-2.5 px-3">Petrol, Diesel, CNG</td>
                <td className="py-2.5 px-3">Type of fuel engine propulsion system</td>
                <td className="py-2.5 px-3 text-purple-400">Categorical Predictor (X_cat)</td>
              </tr>
              <tr className="hover:bg-slate-800/30">
                <td className="py-2.5 px-3 font-mono font-medium text-slate-200">Transmission</td>
                <td className="py-2.5 px-3 text-slate-400">Categorical</td>
                <td className="py-2.5 px-3">Manual, Automatic</td>
                <td className="py-2.5 px-3">Gearbox mechanism configuration</td>
                <td className="py-2.5 px-3 text-purple-400">Categorical Predictor (X_cat)</td>
              </tr>
              <tr className="hover:bg-slate-800/30">
                <td className="py-2.5 px-3 font-mono font-medium text-slate-200">Seller_Type</td>
                <td className="py-2.5 px-3 text-slate-400">Categorical</td>
                <td className="py-2.5 px-3">Dealer, Individual</td>
                <td className="py-2.5 px-3">Listing party channel (dealership vs private seller)</td>
                <td className="py-2.5 px-3 text-purple-400">Categorical Predictor (X_cat)</td>
              </tr>
              <tr className="hover:bg-slate-800/30">
                <td className="py-2.5 px-3 font-mono font-medium text-slate-200">Owner</td>
                <td className="py-2.5 px-3 text-slate-400">Integer</td>
                <td className="py-2.5 px-3">0, 1, 3</td>
                <td className="py-2.5 px-3">Count of previous owners (0 = First-hand)</td>
                <td className="py-2.5 px-3 text-blue-400">Numeric Predictor (X_num)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
