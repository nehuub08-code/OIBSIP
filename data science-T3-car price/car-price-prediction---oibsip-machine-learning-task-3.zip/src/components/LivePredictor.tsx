import React, { useState, useMemo } from 'react';
import { PredictionInput } from '../types';
import { predictCarPrice, formatLakhs, formatINR, REFERENCE_YEAR } from '../utils/predict';
import { Gauge, Calculator, Sparkles, TrendingDown, Info, ShieldCheck, ArrowRight } from 'lucide-react';

interface PresetCar {
  label: string;
  brand: string;
  presentPrice: number;
  year: number;
  kmsDriven: number;
  fuelType: 'Petrol' | 'Diesel' | 'CNG';
  sellerType: 'Dealer' | 'Individual';
  transmission: 'Manual' | 'Automatic';
  owner: number;
}

const PRESETS: PresetCar[] = [
  {
    label: 'Maruti Swift (2014)',
    brand: 'Maruti Suzuki',
    presentPrice: 5.59,
    year: 2014,
    kmsDriven: 27000,
    fuelType: 'Petrol',
    sellerType: 'Dealer',
    transmission: 'Manual',
    owner: 0
  },
  {
    label: 'Toyota Fortuner (2015)',
    brand: 'Toyota',
    presentPrice: 30.61,
    year: 2015,
    kmsDriven: 40000,
    fuelType: 'Diesel',
    sellerType: 'Dealer',
    transmission: 'Automatic',
    owner: 0
  },
  {
    label: 'Honda City (2016)',
    brand: 'Honda',
    presentPrice: 11.50,
    year: 2016,
    kmsDriven: 35000,
    fuelType: 'Petrol',
    sellerType: 'Dealer',
    transmission: 'Manual',
    owner: 0
  },
  {
    label: 'Hyundai Verna (2013)',
    brand: 'Hyundai',
    presentPrice: 9.40,
    year: 2013,
    kmsDriven: 45000,
    fuelType: 'Diesel',
    sellerType: 'Individual',
    transmission: 'Manual',
    owner: 0
  },
  {
    label: 'Maruti Alto (2011)',
    brand: 'Maruti Suzuki',
    presentPrice: 3.60,
    year: 2011,
    kmsDriven: 50000,
    fuelType: 'Petrol',
    sellerType: 'Individual',
    transmission: 'Manual',
    owner: 1
  }
];

const BRANDS = [
  'Maruti Suzuki',
  'Hyundai',
  'Honda',
  'Toyota',
  'Royal Enfield',
  'Bajaj',
  'Hero',
  'Yamaha',
  'TVS',
  'KTM',
  'Mahindra',
  'Hyosung'
];

export const LivePredictor: React.FC = () => {
  const [inputs, setInputs] = useState<PredictionInput>({
    brand: 'Maruti Suzuki',
    presentPrice: 5.59,
    year: 2014,
    kmsDriven: 27000,
    fuelType: 'Petrol',
    sellerType: 'Dealer',
    transmission: 'Manual',
    owner: 0
  });

  const prediction = useMemo(() => {
    return predictCarPrice(inputs);
  }, [inputs]);

  const carAge = Math.max(0, REFERENCE_YEAR - inputs.year);

  const applyPreset = (preset: PresetCar) => {
    setInputs({
      brand: preset.brand,
      presentPrice: preset.presentPrice,
      year: preset.year,
      kmsDriven: preset.kmsDriven,
      fuelType: preset.fuelType,
      sellerType: preset.sellerType,
      transmission: preset.transmission,
      owner: preset.owner
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Presets */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4">
          <div>
            <div className="inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-blue-400 mb-1">
              <Calculator className="w-3.5 h-3.5" />
              <span>Interactive Model Simulator</span>
            </div>
            <h2 className="text-xl font-bold text-white">Live Used Car Price Predictor</h2>
            <p className="text-xs text-slate-400">
              Evaluates car attributes using our trained scikit-learn models (Linear Regression, Random Forest & Gradient Boosting).
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Quick Presets:</span>
            <div className="flex flex-wrap gap-1.5">
              {PRESETS.map((p) => (
                <button
                  key={p.label}
                  onClick={() => applyPreset(p)}
                  className="px-2.5 py-1 text-xs font-medium rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 hover:border-slate-600 transition-colors cursor-pointer"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 2-Column Layout: Inputs on Left, Valuation Results on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
          {/* LEFT: Input Form (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-slate-950/70 border border-slate-800/80 rounded-lg p-4 space-y-4">
              <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2 border-b border-slate-800 pb-2">
                <Gauge className="w-4 h-4 text-blue-400" />
                <span>Vehicle Specifications</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Brand */}
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Automobile Brand / Marque
                  </label>
                  <select
                    value={inputs.brand}
                    onChange={(e) => setInputs({ ...inputs, brand: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500"
                  >
                    {BRANDS.map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Present Price (Ex-Showroom) */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-xs font-medium text-slate-300">
                      Original Present Price (₹ Lakhs)
                    </label>
                    <span className="text-xs font-bold text-blue-400">
                      {formatINR(inputs.presentPrice)} ({inputs.presentPrice} L)
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="40"
                    step="0.25"
                    value={inputs.presentPrice}
                    onChange={(e) => setInputs({ ...inputs, presentPrice: parseFloat(e.target.value) })}
                    className="w-full accent-blue-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                    <span>₹0.5 L</span>
                    <span>₹20 L</span>
                    <span>₹40 L</span>
                  </div>
                </div>

                {/* Manufacturing Year */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-xs font-medium text-slate-300">
                      Manufacturing Year
                    </label>
                    <span className="text-xs font-semibold text-indigo-400">
                      {inputs.year} ({carAge} yrs old)
                    </span>
                  </div>
                  <input
                    type="range"
                    min="2003"
                    max="2018"
                    step="1"
                    value={inputs.year}
                    onChange={(e) => setInputs({ ...inputs, year: parseInt(e.target.value, 10) })}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                    <span>2003 (15 yrs)</span>
                    <span>2010 (8 yrs)</span>
                    <span>2018 (0 yrs)</span>
                  </div>
                </div>

                {/* Kilometres Driven */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-xs font-medium text-slate-300">
                      Kilometres Driven
                    </label>
                    <span className="text-xs font-semibold text-amber-400">
                      {inputs.kmsDriven.toLocaleString()} km
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1000"
                    max="150000"
                    step="1000"
                    value={inputs.kmsDriven}
                    onChange={(e) => setInputs({ ...inputs, kmsDriven: parseInt(e.target.value, 10) })}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                    <span>1,000 km</span>
                    <span>75,000 km</span>
                    <span>150,000+ km</span>
                  </div>
                </div>
              </div>

              {/* Categoricals: Fuel, Transmission, Seller, Owner */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-800">
                {/* Fuel Type */}
                <div>
                  <label className="block text-[11px] font-medium text-slate-400 mb-1">Fuel Type</label>
                  <div className="flex flex-col gap-1">
                    {(['Petrol', 'Diesel', 'CNG'] as const).map((fuel) => (
                      <button
                        key={fuel}
                        type="button"
                        onClick={() => setInputs({ ...inputs, fuelType: fuel })}
                        className={`px-2 py-1 text-xs rounded font-medium border text-left transition-colors cursor-pointer ${
                          inputs.fuelType === fuel
                            ? 'bg-blue-600/30 text-blue-300 border-blue-500'
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {fuel}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Transmission */}
                <div>
                  <label className="block text-[11px] font-medium text-slate-400 mb-1">Transmission</label>
                  <div className="flex flex-col gap-1">
                    {(['Manual', 'Automatic'] as const).map((trans) => (
                      <button
                        key={trans}
                        type="button"
                        onClick={() => setInputs({ ...inputs, transmission: trans })}
                        className={`px-2 py-1 text-xs rounded font-medium border text-left transition-colors cursor-pointer ${
                          inputs.transmission === trans
                            ? 'bg-emerald-600/30 text-emerald-300 border-emerald-500'
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {trans}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Seller Type */}
                <div>
                  <label className="block text-[11px] font-medium text-slate-400 mb-1">Seller Channel</label>
                  <div className="flex flex-col gap-1">
                    {(['Dealer', 'Individual'] as const).map((seller) => (
                      <button
                        key={seller}
                        type="button"
                        onClick={() => setInputs({ ...inputs, sellerType: seller })}
                        className={`px-2 py-1 text-xs rounded font-medium border text-left transition-colors cursor-pointer ${
                          inputs.sellerType === seller
                            ? 'bg-purple-600/30 text-purple-300 border-purple-500'
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {seller}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Previous Owners */}
                <div>
                  <label className="block text-[11px] font-medium text-slate-400 mb-1">Past Owners</label>
                  <div className="flex flex-col gap-1">
                    {[
                      { val: 0, label: '0 (1st Hand)' },
                      { val: 1, label: '1 Previous' },
                      { val: 3, label: '2+ Owners' }
                    ].map((item) => (
                      <button
                        key={item.val}
                        type="button"
                        onClick={() => setInputs({ ...inputs, owner: item.val })}
                        className={`px-2 py-1 text-xs rounded font-medium border text-left transition-colors cursor-pointer ${
                          inputs.owner === item.val
                            ? 'bg-amber-600/30 text-amber-300 border-amber-500'
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT: Valuation Output Dashboard (5 cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
            {/* Primary Valuation Card */}
            <div className="bg-gradient-to-br from-blue-950/70 via-slate-900 to-slate-900 border border-blue-500/30 rounded-xl p-5 shadow-lg relative overflow-hidden">
              <div className="absolute top-0 right-0 transform translate-x-4 -translate-y-4 w-28 h-28 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-center justify-between mb-2">
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  <Sparkles className="w-3 h-3" />
                  <span>Ensemble Consensus Valuation</span>
                </span>
                <span className="text-[11px] text-slate-400">Target: Selling_Price</span>
              </div>

              <div className="my-3">
                <div className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                  {formatLakhs(prediction.recommendedPrice)}
                </div>
                <div className="text-sm font-semibold text-emerald-400 mt-1">
                  ≈ {formatINR(prediction.recommendedPrice)}
                </div>
              </div>

              {/* Confidence Interval */}
              <div className="bg-slate-950/60 rounded-lg p-2.5 border border-slate-800 text-xs flex items-center justify-between mb-3">
                <span className="text-slate-400">Expected Market Range (±1 MAE):</span>
                <span className="font-semibold text-slate-200">
                  {formatLakhs(prediction.rangeMin)} – {formatLakhs(prediction.rangeMax)}
                </span>
              </div>

              {/* Depreciation indicator */}
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <TrendingDown className="w-4 h-4 text-rose-400 shrink-0" />
                <span>
                  Depreciated by <strong className="text-rose-300 font-bold">{prediction.depreciationPct}%</strong> from original showroom value of {formatLakhs(inputs.presentPrice)}.
                </span>
              </div>
            </div>

            {/* Model Comparison Breakdown Cards */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
              <div className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                <span>Model Architecture Comparison</span>
                <span className="text-[10px] text-slate-500">Test Set Evaluated</span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {/* Linear Regression */}
                <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-2.5 text-center">
                  <div className="text-[10px] text-slate-400 font-medium truncate">Linear Reg.</div>
                  <div className="text-sm font-bold text-blue-400 my-0.5">
                    {formatLakhs(prediction.linearPrice)}
                  </div>
                  <div className="text-[9px] text-slate-500">R²: 0.751 | MAE: 1.50L</div>
                </div>

                {/* Random Forest */}
                <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-2.5 text-center">
                  <div className="text-[10px] text-slate-400 font-medium truncate">Random Forest</div>
                  <div className="text-sm font-bold text-indigo-400 my-0.5">
                    {formatLakhs(prediction.rfPrice)}
                  </div>
                  <div className="text-[9px] text-slate-500">R²: 0.600 | MAE: 1.33L</div>
                </div>

                {/* Gradient Boosting */}
                <div className="bg-slate-900/90 border border-emerald-500/40 rounded-lg p-2.5 text-center relative">
                  <span className="absolute -top-1.5 -right-1 text-[8px] bg-emerald-600 text-white px-1 rounded font-bold">
                    Lowest MAE
                  </span>
                  <div className="text-[10px] text-emerald-400 font-medium truncate">Gradient Boost</div>
                  <div className="text-sm font-bold text-emerald-400 my-0.5">
                    {formatLakhs(prediction.gbPrice)}
                  </div>
                  <div className="text-[9px] text-slate-500">R²: 0.685 | MAE: 1.21L</div>
                </div>
              </div>

              {/* Explanatory Note */}
              <div className="flex items-start gap-2 text-[11px] text-slate-400 bg-slate-900/50 p-2 rounded border border-slate-800/80">
                <Info className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Data Science Insight:</strong> Present Price accounts for 90.5% of model predictive weight, followed by Car Age (6.9%). Diesel variants command a ₹0.80L – ₹1.10L premium over Petrol models.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
