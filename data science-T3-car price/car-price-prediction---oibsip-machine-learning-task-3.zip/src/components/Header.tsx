import React from 'react';
import { Download, CheckCircle2, GitBranch, Terminal } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenChecklist: () => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, onOpenChecklist }) => {
  const tabs = [
    { id: 'predictor', label: 'Live Predictor' },
    { id: 'overview', label: 'Project Brief' },
    { id: 'eda', label: 'EDA & Charts' },
    { id: 'models', label: 'ML Models & Scores' },
    { id: 'importance', label: 'Feature Importance' },
    { id: 'notebook', label: 'Jupyter Notebook' },
    { id: 'dataset', label: 'Dataset Explorer' },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-50 shadow-md">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div className="flex items-center space-x-3">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              OIBSIP Task 3
            </span>
            <div>
              <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white flex items-center gap-2">
                <span>Car Price Prediction with Machine Learning</span>
                <span className="hidden sm:inline-block text-xs font-normal text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                  Oasis Infobyte Internship
                </span>
              </h1>
              <p className="text-xs text-slate-400 hidden sm:block">
                Regression Modeling • EDA • Pipelines & Transformers • Model Evaluation (MAE / RMSE / R²)
              </p>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center flex-wrap gap-2">
            <button
              onClick={onOpenChecklist}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 hover:bg-emerald-500 text-white transition-colors cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-white" />
              <span>Submission Checklist</span>
            </button>

            <a
              href="/Car_Price_Prediction.ipynb"
              download="Car_Price_Prediction.ipynb"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-600 hover:bg-blue-500 text-white transition-colors cursor-pointer"
              title="Download executed Jupyter Notebook (1.9MB with all cell outputs)"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .ipynb</span>
            </a>

            <a
              href="/data/car_data.csv"
              download="car data.csv"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors cursor-pointer"
              title="Download Kaggle Cardekho car data.csv"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Dataset CSV</span>
            </a>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-slate-950 border-t border-slate-800/80 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto overflow-x-auto scrollbar-none flex space-x-1 sm:space-x-2 py-1">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-2 text-xs sm:text-sm font-medium rounded-md whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
