import React from 'react';
import { Award, GitCompare, BarChart2, CheckCircle, AlertTriangle, HelpCircle } from 'lucide-react';
import { formatINR } from '../utils/predict';

interface MetricRow {
  model: string;
  mae: number;
  rmse: number;
  r2: number;
  type: string;
  badge?: string;
}

const EVALUATION_DATA: MetricRow[] = [
  {
    model: 'Linear Regression',
    mae: 1.5027,
    rmse: 2.5332,
    r2: 0.7510,
    type: 'Parametric Linear Baseline',
    badge: 'Lowest RMSE & Highest R²'
  },
  {
    model: 'Random Forest Regressor',
    mae: 1.3343,
    rmse: 3.2124,
    r2: 0.5996,
    type: 'Non-Linear Bagging Ensemble (100 Trees)',
    badge: 'Tighter Errors on Normal Fleet'
  },
  {
    model: 'Gradient Boosting Regressor',
    mae: 1.2103,
    rmse: 2.8472,
    r2: 0.6855,
    type: 'Sequential Boosting Ensemble (100 Trees)',
    badge: 'Recommended: Lowest MAE'
  }
];

export const ModelsEvaluationTab: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 mb-1">
              <Award className="w-3.5 h-3.5" />
              <span>Section 10 & 11 Model Evaluation</span>
            </div>
            <h2 className="text-xl font-bold text-white">Comparative Model Evaluation on Test Data</h2>
            <p className="text-xs text-slate-400">
              Evaluated strictly on the 20% holdout test partition ($n = 60$ vehicles, <code className="text-blue-300">random_state = 42</code>). Zero data leakage.
            </p>
          </div>
        </div>
      </div>

      {/* Metrics Table Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GitCompare className="w-4 h-4 text-blue-400" />
            <h3 className="text-sm font-bold text-white">Actual Computed Test Metrics</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">Test Sample: 60 vehicles</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950/60 font-semibold">
                <th className="py-3 px-4">Model Architecture</th>
                <th className="py-3 px-4">Paradigm</th>
                <th className="py-3 px-4">
                  <span>MAE (Lakhs ₹)</span>
                  <span className="block text-[10px] text-slate-500 font-normal">Lower is better</span>
                </th>
                <th className="py-3 px-4">
                  <span>Equivalent INR Error</span>
                  <span className="block text-[10px] text-slate-500 font-normal">Average Deviation</span>
                </th>
                <th className="py-3 px-4">
                  <span>RMSE (Lakhs ₹)</span>
                  <span className="block text-[10px] text-slate-500 font-normal">Outlier Penalized</span>
                </th>
                <th className="py-3 px-4">
                  <span>$R^2$ Score</span>
                  <span className="block text-[10px] text-slate-500 font-normal">Higher is better (Max 1.0)</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {EVALUATION_DATA.map((row) => (
                <tr key={row.model} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-white flex items-center gap-2">
                    <span>{row.model}</span>
                    {row.badge && (
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                        row.badge.includes('Recommended')
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-blue-500/10 text-blue-300 border border-blue-500/20'
                      }`}>
                        {row.badge}
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-slate-400">{row.type}</td>
                  <td className="py-3.5 px-4 font-mono font-bold text-blue-400 text-sm">
                    {row.mae.toFixed(4)} L
                  </td>
                  <td className="py-3.5 px-4 font-medium text-emerald-400">
                    ≈ {formatINR(row.mae)}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-amber-400 font-bold">
                    {row.rmse.toFixed(4)} L
                  </td>
                  <td className="py-3.5 px-4 font-mono font-bold text-purple-400 text-sm">
                    {row.r2.toFixed(4)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Visual Comparison Chart Embed */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-blue-400" />
            <h3 className="text-sm font-bold text-white">Figure 5: Model Evaluation Comparison Chart</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">outputs/model_comparison.png</span>
        </div>

        <div className="bg-white rounded-lg p-3 max-w-4xl mx-auto shadow-inner">
          <img
            src="/outputs/model_comparison.png"
            alt="Figure 5: Model Comparison"
            className="w-full h-auto object-contain rounded"
          />
        </div>
      </div>

      {/* Deep Dive & Diagnostic Trade-off Analysis */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
            <HelpCircle className="w-4 h-4" />
            <span>Understanding the Metric Discrepancy (MAE vs. RMSE & $R^2$)</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            In standard machine learning, beginners expect tree models to score higher on all metrics. However, in our real test results:
          </p>
          <ul className="text-xs text-slate-300 space-y-2 list-disc pl-4">
            <li>
              <strong>MAE (Mean Absolute Error):</strong> Gradient Boosting (**1.21 L**) and Random Forest (**1.33 L**) significantly outperform Linear Regression (**1.50 L**). On standard vehicles across the 60-sample test set, the ensemble tree models produce tighter, more reliable estimates.
            </li>
            <li>
              <strong>RMSE & $R^2$:</strong> Linear Regression registers lower RMSE (**2.53 L**) and higher $R^2$ (**0.751**) than Random Forest (RMSE **3.21 L**, $R^2$ **0.600**).
            </li>
          </ul>
          <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 text-xs text-slate-400 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>
              <strong>The Single Outlier Effect:</strong> In the test set, row 63 represents an ultra-rare high-end vehicle (`Toyota Fortuner`) that sold for **₹33.00 Lakhs**. Because decision trees cannot extrapolate beyond training leaf bounds, both tree models predict ~₹21.8L (an error of ~11.2L). Squaring that 11.2L error heavily inflates RMSE and dampens $R^2$ for the non-extrapolating tree ensemble!
            </span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
            <Award className="w-4 h-4" />
            <span>Best Model Selection & Practical Verdict</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Based on the empirical evidence from our executed pipeline:
          </p>
          <div className="space-y-2.5">
            <div className="bg-slate-950/70 p-3 rounded-lg border border-emerald-500/30 text-xs text-slate-300">
              <strong className="text-emerald-400 font-bold block mb-1">
                Selected Production Model: Gradient Boosting / Random Forest Regressor
              </strong>
              <span>
                For real-world automotive buyers and sellers, minimizing average absolute error (MAE) is the primary economic objective. Gradient Boosting achieves an average deviation of just ₹1,21,030 across typical consumer inventory.
              </span>
            </div>

            <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800 text-xs text-slate-300">
              <strong className="text-blue-400 font-bold block mb-1">
                Selected Baseline Benchmark: Linear Regression
              </strong>
              <span>
                Linear Regression provides valuable transparency and handles extreme upper-tail linearity without being constrained to tree leaf limits.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
