import React, { useState } from 'react';
import { BarChart3, Fuel, Calendar, Network, Maximize2, Info, CheckCircle2 } from 'lucide-react';

interface EdaFigure {
  id: string;
  figureNum: string;
  title: string;
  imageSrc: string;
  tag: string;
  summary: string;
  keyInsights: string[];
  metrics: { label: string; value: string }[];
}

const EDA_FIGURES: EdaFigure[] = [
  {
    id: 'distribution',
    figureNum: 'Figure 1',
    title: 'Selling Price Distribution (Target Variable $y$)',
    imageSrc: '/outputs/selling_price_distribution.png',
    tag: 'Univariate Analysis',
    summary:
      'Histogram and Kernel Density Estimation (KDE) curve illustrating the frequency distribution of used car selling prices across the 299 unique records.',
    keyInsights: [
      'Positive Skewness (Right-Skewed): The majority of vehicles cluster in the budget and economy segment between ₹0.5L and ₹6.0L.',
      'Mean (₹4.59L) > Median (₹3.51L): The significant difference confirms that rare high-end utility vehicles pull the arithmetic mean upward.',
      'Outlier Long Tail: A modest collection of premium SUVs (Fortuner, Land Cruiser) spans from ₹15L to ₹35L, making quadratic loss metrics (RMSE) particularly sensitive.'
    ],
    metrics: [
      { label: 'Minimum Price', value: '₹0.10 L' },
      { label: 'Median Price', value: '₹3.51 L' },
      { label: 'Mean Price', value: '₹4.59 L' },
      { label: 'Maximum Price', value: '₹35.00 L' }
    ]
  },
  {
    id: 'fuel',
    figureNum: 'Figure 2',
    title: 'Selling Price by Fuel Type (Petrol, Diesel, CNG)',
    imageSrc: '/outputs/price_by_fuel_type.png',
    tag: 'Bivariate Analysis',
    summary:
      'Categorical box plot with individual strip points illustrating market resale value distributions segregated by fuel propulsion mechanism.',
    keyInsights: [
      'Diesel Premium: Diesel vehicles exhibit a notably higher median selling price (₹7.75L) and wider interquartile range than Petrol vehicles (₹2.65L).',
      'Vehicle Type Confounding: In the Indian automotive ecosystem, larger heavy-duty passenger vehicles (e.g., Innova, Fortuner) predominantly feature diesel engines.',
      'CNG Budget Segment: CNG represents an economical, low-cost commuter sub-market with low initial capital expenditure and modest resale valuations.'
    ],
    metrics: [
      { label: 'Diesel Median', value: '₹7.75 L (60 records)' },
      { label: 'Petrol Median', value: '₹2.65 L (237 records)' },
      { label: 'CNG Median', value: '₹3.10 L (2 records)' },
      { label: 'Diesel Variance', value: 'High (up to ₹35L)' }
    ]
  },
  {
    id: 'age',
    figureNum: 'Figure 3',
    title: 'Selling Price vs. Vehicle Age (Depreciation Curve)',
    imageSrc: '/outputs/price_vs_car_age.png',
    tag: 'Scatter & Regression Trend',
    summary:
      'Scatter plot mapping vehicle age against selling price, augmented with an Ordinary Least Squares linear trend line highlighting vehicle depreciation.',
    keyInsights: [
      'Pronounced Negative Slope: Selling price decreases systematically as car age increases, reflecting physical wear, technology obsolescence, and mechanical aging.',
      'High Value Retention (0–4 Years): Vehicles manufactured between 2014 and 2018 (age 0–4) represent nearly all sales exceeding ₹10 Lakhs.',
      'Age Floor (>8 Years): Beyond 8 years of age, very few vehicles command more than ₹5 Lakhs, forming a natural market valuation floor.'
    ],
    metrics: [
      { label: 'Reference Year', value: '2018 (Dataset max)' },
      { label: 'Age Range', value: '0 to 15 years' },
      { label: 'Mean Age', value: '4.4 years old' },
      { label: 'Pearson Correlation', value: 'r = -0.234' }
    ]
  },
  {
    id: 'heatmap',
    figureNum: 'Figure 4',
    title: 'Feature Correlation Heatmap (Pearson r)',
    imageSrc: '/outputs/feature_correlation_heatmap.png',
    tag: 'Multivariate Correlation',
    summary:
      'Annotated matrix of Pearson correlation coefficients across continuous numeric features (Selling_Price, Present_Price, Car_Age, Kms_Driven, Owner).',
    keyInsights: [
      'Present_Price Dominance (r = +0.876): Ex-showroom original price is overwhelmingly the strongest linear predictor of resale price.',
      'Car_Age Depreciation (r = -0.234): Significant inverse correlation confirming expected temporal degradation.',
      'Kilometers Driven (r = +0.028): Demonstrates weak linear correlation in isolation because high-mileage diesel highway cruisers maintain high resale valuations.',
      'Methodology Note: Categorical features are strictly excluded from the correlation matrix to prevent synthetic numeric distortion.'
    ],
    metrics: [
      { label: 'Present Price Corr', value: '+0.876 (Strongest)' },
      { label: 'Car Age Corr', value: '-0.234 (Negative)' },
      { label: 'Kms Driven Corr', value: '+0.028 (Neutral)' },
      { label: 'Owner Count Corr', value: '-0.088 (Weak Neg)' }
    ]
  }
];

export const EdaGalleryTab: React.FC = () => {
  const [selectedFigure, setSelectedFigure] = useState<EdaFigure>(EDA_FIGURES[0]);

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 mb-1">
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Section 5 Exploratory Data Analysis</span>
            </div>
            <h2 className="text-xl font-bold text-white">Exploratory Data Analysis & Visualizations</h2>
            <p className="text-xs text-slate-400">
              Interactive examination of authentic figures generated and saved directly to the <code className="text-blue-300">outputs/</code> folder.
            </p>
          </div>

          {/* Figure Selector Pills */}
          <div className="flex flex-wrap gap-1.5">
            {EDA_FIGURES.map((fig) => (
              <button
                key={fig.id}
                onClick={() => setSelectedFigure(fig)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer border ${
                  selectedFigure.id === fig.id
                    ? 'bg-blue-600 text-white border-blue-500 shadow-sm'
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                }`}
              >
                {fig.figureNum}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Focus Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <span className="text-xs font-semibold text-blue-400 mr-2 uppercase tracking-wider">
              {selectedFigure.figureNum} • {selectedFigure.tag}
            </span>
            <h3 className="text-lg font-bold text-white">{selectedFigure.title}</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">Saved to: {selectedFigure.imageSrc}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 p-6">
          {/* Chart Display (7 cols) */}
          <div className="lg:col-span-7 flex flex-col justify-center bg-white rounded-lg p-2 border border-slate-700/60 shadow-inner">
            <img
              src={selectedFigure.imageSrc}
              alt={selectedFigure.title}
              className="w-full h-auto object-contain rounded"
            />
          </div>

          {/* Analysis & Observations (5 cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-blue-400" />
                <span>Figure Interpretation & Context</span>
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed mb-4">
                {selectedFigure.summary}
              </p>

              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Empirical Takeaways
              </h4>
              <ul className="space-y-2">
                {selectedFigure.keyInsights.map((insight, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{insight}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Quick Metrics Grid */}
            <div className="bg-slate-950/70 rounded-lg p-3 border border-slate-800">
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Empirical Summary Statistics
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {selectedFigure.metrics.map((m, i) => (
                  <div key={i} className="bg-slate-900 p-2 rounded border border-slate-800/80">
                    <span className="text-[10px] text-slate-500 block">{m.label}</span>
                    <span className="font-bold text-slate-200">{m.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Grid of all 4 Miniatures */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {EDA_FIGURES.map((fig) => (
          <div
            key={fig.id}
            onClick={() => setSelectedFigure(fig)}
            className={`bg-slate-900 border rounded-xl p-3 cursor-pointer transition-all hover:border-blue-500/70 ${
              selectedFigure.id === fig.id ? 'border-blue-500 ring-1 ring-blue-500' : 'border-slate-800'
            }`}
          >
            <div className="bg-white rounded p-1 mb-2">
              <img src={fig.imageSrc} alt={fig.title} className="w-full h-32 object-contain" />
            </div>
            <div className="text-[10px] font-semibold text-blue-400 uppercase">{fig.figureNum}</div>
            <div className="text-xs font-bold text-white truncate">{fig.title}</div>
            <div className="text-[11px] text-slate-400 line-clamp-2 mt-1">{fig.summary}</div>
          </div>
        ))}
      </div>
    </div>
  );
};
