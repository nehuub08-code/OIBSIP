import React, { useState } from 'react';
import { X, CheckCircle, Terminal, Copy, Check, GitBranch, ShieldCheck } from 'lucide-react';

interface ChecklistModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const CHECKLIST_ITEMS = [
  'Suitable car-price dataset sourced and validated from Kaggle CarDekho',
  'Missing values, duplicate records, and categorical inconsistencies audited and cleaned',
  'Vehicle age (Car_Age) calculated using a consistent reference year (2018)',
  'Brand extracted from car name using documented manufacturer normalization',
  'Selling price distribution plotted (outputs/selling_price_distribution.png)',
  'Price by fuel type plotted (outputs/price_by_fuel_type.png)',
  'Price versus car age plotted (outputs/price_vs_car_age.png)',
  'Categorical variables encoded using leakage-free ColumnTransformer and OneHotEncoder',
  'Feature correlation heatmap generated (outputs/feature_correlation_heatmap.png)',
  'Train/test split completed (80/20 split, random_state=42) with leakage verification',
  'At least two regression models trained (Linear Regression & Random Forest Regressor + Gradient Boosting)',
  'MAE, RMSE, and R² calculated on holdout test set with real outputs',
  'Best model declared with evidence and diagnostic trade-off analysis',
  'Feature importance chart generated (outputs/feature_importance.png)',
  'Notebook fully documented, commented, and executed end-to-end',
  'Professional README, requirements.txt, and visual outputs prepared'
];

export const ChecklistModal: React.FC<ChecklistModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const gitCommands = `# Navigate to project folder
cd OIBSIP/DataScience/Task3_Car_Price_Prediction

# Audit git status
git status

# Stage all project files (Notebook, README, outputs, data, screenshots)
git add .

# Commit with descriptive message
git commit -m "feat(OIBSIP): complete Task 3 used car price prediction machine learning pipeline"

# Push to your personal GitHub repository
git push origin main`;

  const copyGitCommands = () => {
    navigator.clipboard.writeText(gitCommands);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-5 my-8">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-lg font-bold text-white">Internship Submission Checklist</h3>
              <p className="text-xs text-slate-400">Oasis Infobyte Task 3: 16 of 16 Requirements Verified</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 16 Checklist Items */}
        <div className="max-h-60 overflow-y-auto pr-1 space-y-2">
          {CHECKLIST_ITEMS.map((item, idx) => (
            <div
              key={idx}
              className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300"
            >
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>{item}</span>
            </div>
          ))}
        </div>

        {/* Git Submission Commands */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-300">
            <span className="font-semibold flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-blue-400" />
              <span>GitHub Submission Commands</span>
            </span>
            <button
              onClick={copyGitCommands}
              className="flex items-center gap-1 text-[11px] text-blue-400 hover:text-blue-300 font-medium transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied to Clipboard!' : 'Copy Commands'}</span>
            </button>
          </div>
          <pre className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-[11px] font-mono text-emerald-400 overflow-x-auto leading-relaxed">
            {gitCommands}
          </pre>
        </div>

        {/* Close Button */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white transition-colors cursor-pointer"
          >
            Close Checklist
          </button>
        </div>
      </div>
    </div>
  );
};
