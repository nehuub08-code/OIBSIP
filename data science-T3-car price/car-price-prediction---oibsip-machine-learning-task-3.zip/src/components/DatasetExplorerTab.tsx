import React, { useState, useEffect, useMemo } from 'react';
import { Database, Search, Filter, Download, ArrowUpDown, CheckCircle } from 'lucide-react';
import { CarRecord } from '../types';
import { formatLakhs, formatINR } from '../utils/predict';

export const DatasetExplorerTab: React.FC = () => {
  const [data, setData] = useState<CarRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [fuelFilter, setFuelFilter] = useState<string>('All');
  const [transFilter, setTransFilter] = useState<string>('All');
  const [sortField, setSortField] = useState<keyof CarRecord>('Selling_Price');
  const [sortAsc, setSortAsc] = useState<boolean>(false);

  useEffect(() => {
    fetch('/dataset_sample.json')
      .then((res) => res.json())
      .then((json: CarRecord[]) => {
        setData(json);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Failed to load dataset_sample.json:', err);
        setLoading(false);
      });
  }, []);

  const filteredData = useMemo(() => {
    return data
      .filter((row) => {
        const matchesSearch =
          row.Car_Name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (row.Brand && row.Brand.toLowerCase().includes(searchTerm.toLowerCase()));
        const matchesFuel = fuelFilter === 'All' || row.Fuel_Type === fuelFilter;
        const matchesTrans = transFilter === 'All' || row.Transmission === transFilter;
        return matchesSearch && matchesFuel && matchesTrans;
      })
      .sort((a, b) => {
        const valA = a[sortField] ?? 0;
        const valB = b[sortField] ?? 0;
        if (typeof valA === 'string' && typeof valB === 'string') {
          return sortAsc ? valA.localeCompare(valB) : valB.localeCompare(valA);
        }
        return sortAsc ? (valA as number) - (valB as number) : (valB as number) - (valA as number);
      });
  }, [data, searchTerm, fuelFilter, transFilter, sortField, sortAsc]);

  const toggleSort = (field: keyof CarRecord) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 mb-1">
              <Database className="w-3.5 h-3.5" />
              <span>Kaggle CarDekho Dataset</span>
            </div>
            <h2 className="text-xl font-bold text-white">Interactive Dataset Table (299 Records)</h2>
            <p className="text-xs text-slate-400">
              Cleaned records after removing duplicate rows. All prices recorded in Indian Lakhs (₹ 1,00,000s).
            </p>
          </div>

          <a
            href="/data/car_data.csv"
            download="car data.csv"
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors cursor-pointer shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download car data.csv</span>
          </a>
        </div>

        {/* Search & Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 pt-4 border-t border-slate-800">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search car model or brand..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Fuel:</span>
            <select
              value={fuelFilter}
              onChange={(e) => setFuelFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-blue-500"
            >
              <option value="All">All Fuels</option>
              <option value="Petrol">Petrol</option>
              <option value="Diesel">Diesel</option>
              <option value="CNG">CNG</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Gearbox:</span>
            <select
              value={transFilter}
              onChange={(e) => setTransFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-blue-500"
            >
              <option value="All">All Transmissions</option>
              <option value="Manual">Manual</option>
              <option value="Automatic">Automatic</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table Container */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="px-4 py-2.5 bg-slate-950/60 border-b border-slate-800 text-xs text-slate-400 flex items-center justify-between">
          <span>Showing {filteredData.length} of {data.length} vehicles</span>
          <span className="text-[11px] text-slate-500">Click column header to toggle sort</span>
        </div>

        {loading ? (
          <div className="p-8 text-center text-slate-400 text-xs">Loading vehicle records...</div>
        ) : (
          <div className="overflow-x-auto max-h-[580px]">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="sticky top-0 bg-slate-950 text-slate-400 font-semibold border-b border-slate-800 z-10">
                <tr>
                  <th className="py-2.5 px-3">#</th>
                  <th
                    onClick={() => toggleSort('Car_Name')}
                    className="py-2.5 px-3 cursor-pointer hover:text-white"
                  >
                    <span className="inline-flex items-center gap-1">
                      <span>Car Name</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-500" />
                    </span>
                  </th>
                  <th
                    onClick={() => toggleSort('Brand')}
                    className="py-2.5 px-3 cursor-pointer hover:text-white"
                  >
                    <span className="inline-flex items-center gap-1">
                      <span>Brand</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-500" />
                    </span>
                  </th>
                  <th
                    onClick={() => toggleSort('Year')}
                    className="py-2.5 px-3 cursor-pointer hover:text-white"
                  >
                    <span className="inline-flex items-center gap-1">
                      <span>Year</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-500" />
                    </span>
                  </th>
                  <th
                    onClick={() => toggleSort('Present_Price')}
                    className="py-2.5 px-3 cursor-pointer hover:text-white"
                  >
                    <span className="inline-flex items-center gap-1">
                      <span>Present Price (L)</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-500" />
                    </span>
                  </th>
                  <th
                    onClick={() => toggleSort('Kms_Driven')}
                    className="py-2.5 px-3 cursor-pointer hover:text-white"
                  >
                    <span className="inline-flex items-center gap-1">
                      <span>Kms Driven</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-500" />
                    </span>
                  </th>
                  <th className="py-2.5 px-3">Fuel</th>
                  <th className="py-2.5 px-3">Transmission</th>
                  <th className="py-2.5 px-3">Seller</th>
                  <th
                    onClick={() => toggleSort('Selling_Price')}
                    className="py-2.5 px-3 cursor-pointer hover:text-emerald-400 font-bold text-white bg-slate-900/80"
                  >
                    <span className="inline-flex items-center gap-1">
                      <span>Target: Selling Price</span>
                      <ArrowUpDown className="w-3 h-3 text-emerald-400" />
                    </span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {filteredData.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2 px-3 text-slate-500 font-mono text-[11px]">{idx + 1}</td>
                    <td className="py-2 px-3 font-semibold text-white capitalize">{row.Car_Name}</td>
                    <td className="py-2 px-3 text-slate-300">
                      <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700/60">
                        {row.Brand || 'Unknown'}
                      </span>
                    </td>
                    <td className="py-2 px-3 font-mono text-slate-300">{row.Year}</td>
                    <td className="py-2 px-3 font-mono text-blue-400 font-medium">
                      {formatLakhs(row.Present_Price)}
                    </td>
                    <td className="py-2 px-3 font-mono text-slate-300">
                      {row.Kms_Driven.toLocaleString()} km
                    </td>
                    <td className="py-2 px-3">
                      <span
                        className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                          row.Fuel_Type === 'Diesel'
                            ? 'bg-amber-500/20 text-amber-300'
                            : row.Fuel_Type === 'CNG'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-blue-500/20 text-blue-300'
                        }`}
                      >
                        {row.Fuel_Type}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-slate-400">{row.Transmission}</td>
                    <td className="py-2 px-3 text-slate-400">{row.Seller_Type}</td>
                    <td className="py-2 px-3 font-mono font-bold text-emerald-400 text-sm bg-slate-900/40">
                      {formatLakhs(row.Selling_Price)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
