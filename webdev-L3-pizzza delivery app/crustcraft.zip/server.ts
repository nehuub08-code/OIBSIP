import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { loadDatabase } from './src/server/db.js';
import { authRouter } from './src/server/routes/authRoutes.js';
import { menuRouter } from './src/server/routes/menuRoutes.js';
import { orderRouter } from './src/server/routes/orderRoutes.js';
import { paymentRouter } from './src/server/routes/paymentRoutes.js';
import { adminRouter } from './src/server/routes/adminRoutes.js';
import { initCronJobs } from './src/server/services/cronService.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json());

  // Ensure DB seed is loaded
  const db = loadDatabase();
  console.log(`[CrustCraft] Database loaded with ${db.inventory.length} ingredients and ${db.signaturePizzas.length} signature pizzas.`);

  // Initialize automated low-stock monitoring cron
  initCronJobs();

  // API Routes
  app.use('/api/auth', authRouter);
  app.use('/api/menu', menuRouter);
  app.use('/api/orders', orderRouter);
  app.use('/api/payment', paymentRouter);
  app.use('/api/admin', adminRouter);

  // Development & Testing: Outbox viewer endpoint (so verification & reset emails are immediately readable)
  app.get('/api/outbox/recent', (_req: Request, res: Response) => {
    const currentDb = loadDatabase();
    res.json(currentDb.outbox.slice(0, 15));
  });

  // Health check
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'healthy',
      app: 'CrustCraft Artisanal Pizza Platform',
      version: '1.0.0',
      timestamp: new Date().toISOString()
    });
  });

  // Vite integration
  const isProduction = process.env.NODE_ENV === 'production';
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 CrustCraft full-stack server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal error starting server:', err);
  process.exit(1);
});
