import { Router, Request, Response } from 'express';
import { loadDatabase } from '../db.js';
import { CustomPizzaConfig, InventoryItem } from '../../types/index.js';

export const menuRouter = Router();

// 1. Get all available ingredients categorized for the builder
menuRouter.get('/ingredients', (_req: Request, res: Response) => {
  const db = loadDatabase();
  const inventory = db.inventory;

  const bases = inventory.filter(i => i.category === 'base');
  const sauces = inventory.filter(i => i.category === 'sauce');
  const cheeses = inventory.filter(i => i.category === 'cheese');
  const vegetables = inventory.filter(i => i.category === 'vegetable');

  res.json({
    bases,
    sauces,
    cheeses,
    vegetables
  });
});

// 2. Get signature artisanal pizzas
menuRouter.get('/pizzas', (_req: Request, res: Response) => {
  const db = loadDatabase();
  res.json(db.signaturePizzas);
});

// 3. Authoritative server price calculator & validation for custom pizza
menuRouter.post('/calculate-price', (req: Request, res: Response) => {
  try {
    const config: CustomPizzaConfig = req.body;
    const db = loadDatabase();

    if (!config.baseId || !config.sauceId || !config.cheeseId) {
      res.status(400).json({ error: 'Base, sauce, and cheese selections are required.' });
      return;
    }

    const base = db.inventory.find(i => i.id === config.baseId);
    const sauce = db.inventory.find(i => i.id === config.sauceId);
    const cheese = db.inventory.find(i => i.id === config.cheeseId);

    if (!base || !sauce || !cheese) {
      res.status(400).json({ error: 'One or more selected required ingredients do not exist.' });
      return;
    }

    const unavailable: string[] = [];
    if (!base.isAvailable || base.availableQuantity <= 0) unavailable.push(base.name);
    if (!sauce.isAvailable || sauce.availableQuantity <= 0) unavailable.push(sauce.name);
    if (!cheese.isAvailable || cheese.availableQuantity <= 0) unavailable.push(cheese.name);

    let itemsPrice = base.customerPrice + sauce.customerPrice + cheese.customerPrice;
    const vegBreakdown: Array<{ id: string; name: string; price: number }> = [];

    if (config.vegetableIds && Array.isArray(config.vegetableIds)) {
      for (const vId of config.vegetableIds) {
        const veg = db.inventory.find(i => i.id === vId);
        if (veg) {
          if (!veg.isAvailable || veg.availableQuantity <= 0) {
            unavailable.push(veg.name);
          }
          itemsPrice += veg.customerPrice;
          vegBreakdown.push({ id: veg.id, name: veg.name, price: veg.customerPrice });
        }
      }
    }

    // Size multiplier
    let sizeMultiplier = 1;
    if (config.size === 'Medium') sizeMultiplier = 1.35;
    if (config.size === 'Large') sizeMultiplier = 1.7;

    const authoritativeUnitPrice = Math.round(itemsPrice * sizeMultiplier);

    res.json({
      basePrice: base.customerPrice,
      saucePrice: sauce.customerPrice,
      cheesePrice: cheese.customerPrice,
      vegetables: vegBreakdown,
      sizeMultiplier,
      unitPrice: authoritativeUnitPrice,
      isAvailable: unavailable.length === 0,
      unavailableIngredients: unavailable
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error calculating price.' });
  }
});
