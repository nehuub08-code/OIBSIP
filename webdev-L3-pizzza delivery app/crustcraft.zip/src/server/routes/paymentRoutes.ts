import { Router, Response } from 'express';
import { loadDatabase, saveDatabase } from '../db.js';
import { authenticate, AuthenticatedRequest } from '../services/authService.js';
import {
  createRazorpayOrder,
  verifyPaymentSignature,
  generateTestPaymentSignature,
  isLiveRazorpayConfigured
} from '../services/paymentService.js';
import { deductOrderStock } from '../services/inventoryService.js';
import { Order } from '../../types/index.js';

export const paymentRouter = Router();

// 1. Create Razorpay Test Order
paymentRouter.post('/create-order', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { orderId } = req.body;
    if (!orderId) {
      res.status(400).json({ error: 'Order ID is required.' });
      return;
    }

    const db = loadDatabase();
    const order = db.orders.find(o => o.id === orderId);

    if (!order) {
      res.status(404).json({ error: 'Order not found.' });
      return;
    }

    if (order.customerId !== req.user?.userId && req.user?.role !== 'admin') {
      res.status(403).json({ error: 'Unauthorized to pay for this order.' });
      return;
    }

    if (order.paymentStatus === 'paid') {
      res.status(400).json({ error: 'This order has already been paid and confirmed.' });
      return;
    }

    const rzpOrder = await createRazorpayOrder({
      orderId: order.id,
      amountInRupees: order.totalAmount
    });

    order.razorpayOrderId = rzpOrder.razorpayOrderId;
    order.paymentMethod = rzpOrder.isMockMode ? 'razorpay_test_simulator' : 'razorpay';
    order.updatedAt = new Date().toISOString();
    saveDatabase(db);

    res.json({
      ...rzpOrder,
      orderId: order.id,
      customerName: order.customerName,
      customerEmail: order.customerEmail,
      customerPhone: order.customerPhone,
      displayAmount: order.totalAmount
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error creating Razorpay order.' });
  }
});

// 2. Generate simulated test signature for sandbox testing
paymentRouter.post('/simulate-test-signature', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { razorpayOrderId, razorpayPaymentId } = req.body;
    if (!razorpayOrderId || !razorpayPaymentId) {
      res.status(400).json({ error: 'Razorpay order ID and payment ID required.' });
      return;
    }

    const signature = generateTestPaymentSignature({
      razorpayOrderId,
      razorpayPaymentId
    });

    res.json({ signature });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error generating test signature.' });
  }
});

// 3. Verify Payment Signature & Commit Stock Atomically
paymentRouter.post('/verify', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      orderId,
      razorpayOrderId,
      razorpayPaymentId,
      razorpaySignature
    } = req.body;

    if (!orderId || !razorpayOrderId || !razorpayPaymentId || !razorpaySignature) {
      res.status(400).json({
        error: 'Missing required payment verification parameters (orderId, razorpayOrderId, paymentId, signature).'
      });
      return;
    }

    const db = loadDatabase();
    const order = db.orders.find(o => o.id === orderId);

    if (!order) {
      res.status(404).json({ error: 'Order not found.' });
      return;
    }

    if (order.customerId !== req.user?.userId && req.user?.role !== 'admin') {
      res.status(403).json({ error: 'Unauthorized.' });
      return;
    }

    // Verify cryptographic signature server-side
    const isValid = verifyPaymentSignature({
      razorpayOrderId,
      razorpayPaymentId,
      razorpaySignature
    });

    if (!isValid) {
      res.status(400).json({
        error: 'Payment verification failed: cryptographic signature mismatch.',
        verified: false
      });
      return;
    }

    // Idempotency: If already paid, return success immediately
    if (order.paymentStatus === 'paid') {
      res.json({
        message: 'Order already paid and verified.',
        verified: true,
        order
      });
      return;
    }

    // Safe stock deduction
    const stockCommit = await deductOrderStock(order);
    if (!stockCommit.success) {
      // Stock deduction failed (concurrency or insufficient items)
      order.paymentStatus = 'failed';
      order.statusHistory.push({
        status: 'Cancelled',
        timestamp: new Date().toISOString(),
        note: `Stock deduction failed during payment verification: ${stockCommit.error}`
      });
      order.updatedAt = new Date().toISOString();
      saveDatabase(db);

      res.status(409).json({
        error: `Payment received but stock could not be committed: ${stockCommit.error}. Order cancelled and refund initiated.`,
        verified: false
      });
      return;
    }

    // Transition order to paid
    const now = new Date().toISOString();
    order.paymentStatus = 'paid';
    order.razorpayPaymentId = razorpayPaymentId;
    order.razorpaySignature = razorpaySignature;
    order.orderStatus = 'In Kitchen';
    order.statusHistory.push({
      status: 'In Kitchen',
      timestamp: now,
      note: 'Payment verified successfully. Handed over to CrustCraft Pizzaiolo chefs in kitchen.'
    });
    order.updatedAt = now;
    saveDatabase(db);

    res.json({
      message: 'Payment verified successfully! Your artisanal pizza is now being prepared in the kitchen.',
      verified: true,
      order
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error verifying payment.' });
  }
});
