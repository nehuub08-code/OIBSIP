import { Router, Request, Response } from 'express';
import { loadDatabase, saveDatabase } from '../db.js';
import {
  hashPassword,
  comparePassword,
  generateToken,
  generateSecureToken,
  authenticate,
  AuthenticatedRequest
} from '../services/authService.js';
import { sendVerificationEmail, sendPasswordResetEmail } from '../services/emailService.js';
import { User } from '../../types/index.js';

export const authRouter = Router();

// 1. Customer Registration
authRouter.post('/register', async (req: Request, res: Response) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      res.status(400).json({ error: 'Name, email, and password are required fields.' });
      return;
    }

    const trimmedEmail = email.trim().toLowerCase();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      res.status(400).json({ error: 'Please provide a valid email address.' });
      return;
    }

    if (password.length < 8) {
      res.status(400).json({ error: 'Password must be at least 8 characters long.' });
      return;
    }

    const db = loadDatabase();
    const existing = db.users.find(u => u.email === trimmedEmail);
    if (existing) {
      res.status(409).json({ error: 'An account with this email address already exists.' });
      return;
    }

    const passwordHash = hashPassword(password);
    const verificationToken = generateSecureToken();
    const verificationTokenExpires = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(); // 24h

    const newUser: User = {
      id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: name.trim(),
      email: trimmedEmail,
      passwordHash,
      role: 'customer', // strictly customer; admin cannot be registered here
      isVerified: false,
      verificationToken,
      verificationTokenExpires,
      createdAt: new Date().toISOString()
    };

    db.users.push(newUser);
    saveDatabase(db);

    // Send verification email
    await sendVerificationEmail(trimmedEmail, newUser.name, verificationToken);

    res.status(201).json({
      message: 'Registration successful! A verification link has been sent to your email.',
      userId: newUser.id,
      email: newUser.email,
      isVerified: false
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Server error during registration.' });
  }
});

// 2. Email Verification
authRouter.get('/verify-email', async (req: Request, res: Response) => {
  try {
    const token = req.query.token as string;
    if (!token) {
      res.status(400).json({ error: 'Verification token is required.' });
      return;
    }

    const db = loadDatabase();
    const user = db.users.find(u => u.verificationToken === token);

    if (!user) {
      res.status(400).json({ error: 'Invalid or expired verification token.' });
      return;
    }

    if (user.isVerified) {
      res.json({ message: 'Your email is already verified! You can log in.', user: { email: user.email, name: user.name } });
      return;
    }

    if (user.verificationTokenExpires && new Date(user.verificationTokenExpires) < new Date()) {
      res.status(400).json({ error: 'Verification token has expired. Please request a new one.' });
      return;
    }

    user.isVerified = true;
    user.verificationToken = undefined;
    user.verificationTokenExpires = undefined;
    saveDatabase(db);

    const jwtToken = generateToken({
      userId: user.id,
      email: user.email,
      role: user.role,
      name: user.name
    });

    res.json({
      message: 'Email successfully verified! Your CrustCraft account is now active.',
      token: jwtToken,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        isVerified: true
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error verifying email.' });
  }
});

// 3. Customer Login
authRouter.post('/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const trimmedEmail = email.trim().toLowerCase();
    const db = loadDatabase();
    const user = db.users.find(u => u.email === trimmedEmail);

    if (!user) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const isValid = comparePassword(password, user.passwordHash);
    if (!isValid) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    if (!user.isVerified) {
      res.status(403).json({
        error: 'Please verify your email before logging in. Check your inbox or Outbox viewer.',
        isUnverified: true,
        email: user.email
      });
      return;
    }

    const token = generateToken({
      userId: user.id,
      email: user.email,
      role: user.role,
      name: user.name
    });

    res.json({
      message: 'Login successful!',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        isVerified: user.isVerified
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Server error during login.' });
  }
});

// 4. Admin Login (Separate Endpoint & Route)
authRouter.post('/admin-login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: 'Admin credentials required.' });
      return;
    }

    const trimmedEmail = email.trim().toLowerCase();
    const db = loadDatabase();
    const user = db.users.find(u => u.email === trimmedEmail);

    // Generic error to avoid exposing account existence
    if (!user || user.role !== 'admin') {
      res.status(401).json({ error: 'Invalid administrative credentials.' });
      return;
    }

    const isValid = comparePassword(password, user.passwordHash);
    if (!isValid) {
      res.status(401).json({ error: 'Invalid administrative credentials.' });
      return;
    }

    const token = generateToken({
      userId: user.id,
      email: user.email,
      role: 'admin',
      name: user.name
    });

    res.json({
      message: 'Admin authentication granted.',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: 'admin'
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Server error during admin login.' });
  }
});

// 5. Resend Verification Link
authRouter.post('/resend-verification', async (req: Request, res: Response) => {
  try {
    const { email } = req.body;
    if (!email) {
      res.status(400).json({ error: 'Email is required.' });
      return;
    }

    const db = loadDatabase();
    const user = db.users.find(u => u.email === email.trim().toLowerCase());

    if (user && !user.isVerified) {
      user.verificationToken = generateSecureToken();
      user.verificationTokenExpires = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
      saveDatabase(db);
      await sendVerificationEmail(user.email, user.name, user.verificationToken);
    }

    res.json({ message: 'If an unverified account exists, a new verification link was dispatched.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error resending verification.' });
  }
});

// 6. Forgot Password (Generic response to avoid account enumeration)
authRouter.post('/forgot-password', async (req: Request, res: Response) => {
  try {
    const { email } = req.body;
    if (!email) {
      res.status(400).json({ error: 'Email address is required.' });
      return;
    }

    const db = loadDatabase();
    const user = db.users.find(u => u.email === email.trim().toLowerCase());

    if (user) {
      const resetToken = generateSecureToken();
      user.resetPasswordToken = resetToken;
      user.resetPasswordTokenExpires = new Date(Date.now() + 60 * 60 * 1000).toISOString(); // 1 hour
      saveDatabase(db);
      await sendPasswordResetEmail(user.email, user.name, resetToken);
    }

    // Always generic response
    res.json({
      message: 'If an account exists with that email, a password reset link has been dispatched.'
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error processing password reset request.' });
  }
});

// 7. Reset Password with Token
authRouter.post('/reset-password', async (req: Request, res: Response) => {
  try {
    const { token, newPassword } = req.body;
    if (!token || !newPassword) {
      res.status(400).json({ error: 'Reset token and new password are required.' });
      return;
    }

    if (newPassword.length < 8) {
      res.status(400).json({ error: 'Password must be at least 8 characters long.' });
      return;
    }

    const db = loadDatabase();
    const user = db.users.find(u => u.resetPasswordToken === token);

    if (!user) {
      res.status(400).json({ error: 'Invalid or already used password reset link.' });
      return;
    }

    if (user.resetPasswordTokenExpires && new Date(user.resetPasswordTokenExpires) < new Date()) {
      res.status(400).json({ error: 'Password reset link has expired. Please request a new one.' });
      return;
    }

    user.passwordHash = hashPassword(newPassword);
    user.resetPasswordToken = undefined;
    user.resetPasswordTokenExpires = undefined;
    saveDatabase(db);

    res.json({ message: 'Password has been successfully updated. You may now log in.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error resetting password.' });
  }
});

// 8. Current Authenticated Profile
authRouter.get('/me', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const db = loadDatabase();
  const user = db.users.find(u => u.id === req.user?.userId);
  if (!user) {
    res.status(404).json({ error: 'User profile not found.' });
    return;
  }

  res.json({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      isVerified: user.isVerified
    }
  });
});
