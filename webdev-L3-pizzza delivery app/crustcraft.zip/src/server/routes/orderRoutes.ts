import { Router, Response } from 'express';
import { loadDatabase, saveDatabase } from '../db.js';
import { authenticate, AuthenticatedRequest } from '../services/authService.js';
import { validateStockAvailability } from '../services/inventoryService.js';
import { Order, OrderItem, StatusHistoryEntry } from '../../types/index.js';

export const orderRouter = Router();

// 1. Create Order (Unpaid / Pending verification)
orderRouter.post('/', authenticate, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { items, deliveryAddress, customerPhone } = req.body;
    const userId = req.user?.userId;
    const userEmail = req.user?.email;
    const userName = req.user?.name;

    if (!items || !Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'Order must contain at least one pizza item.' });
      return;
    }

    if (!deliveryAddress || !deliveryAddress.street || !deliveryAddress.city || !deliveryAddress.postalCode) {
      res.status(400).json({ error: 'Complete delivery address is required.' });
      return;
    }

    if (!customerPhone || customerPhone.trim().length < 8) {
      res.status(400).json({ error: 'A valid customer contact phone number is required.' });
      return;
    }

    const db = loadDatabase();
    const user = db.users.find(u => u.id === userId);
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    if (!user.isVerified) {
      res.status(403).json({ error: 'Please verify your email before placing an order.' });
      return;
    }

    // Authoritative recalculation of every item
    const authoritativeItems: OrderItem[] = [];
    let calculatedSubtotal = 0;

    for (const item of items) {
      const qty = Math.max(1, parseInt(item.quantity, 10) || 1);

      if (item.isCustom && item.customConfig) {
        const cfg = item.customConfig;
        const base = db.inventory.find(i => i.id === cfg.baseId);
        const sauce = db.inventory.find(i => i.id === cfg.sauceId);
        const cheese = db.inventory.find(i => i.id === cfg.cheeseId);

        if (!base || !sauce || !cheese) {
          res.status(400).json({ error: 'Custom pizza ingredients invalid or missing.' });
          return;
        }

        let baseTotal = base.customerPrice + sauce.customerPrice + cheese.customerPrice;
        const vegNames: string[] = [];

        if (cfg.vegetableIds && Array.isArray(cfg.vegetableIds)) {
          for (const vId of cfg.vegetableIds) {
            const veg = db.inventory.find(i => i.id === vId);
            if (veg) {
              baseTotal += veg.customerPrice;
              vegNames.push(veg.name);
            }
          }
        }

        let sizeMultiplier = 1;
        if (cfg.size === 'Medium') sizeMultiplier = 1.35;
        if (cfg.size === 'Large') sizeMultiplier = 1.7;

        const unitPrice = Math.round(baseTotal * sizeMultiplier);
        const totalPrice = unitPrice * qty;
        calculatedSubtotal += totalPrice;

        authoritativeItems.push({
          id: `custom_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
          name: `Custom Pizza (${cfg.size || 'Regular'})`,
          isCustom: true,
          customConfig: {
            ...cfg,
            baseName: base.name,
            sauceName: sauce.name,
            cheeseName: cheese.name,
            vegetableNames: vegNames
          },
          unitPrice,
          quantity: qty,
          totalPrice
        });
      } else {
        // Signature pizza lookup
        const sig = db.signaturePizzas.find(s => s.id === item.id || s.name === item.name);
        if (!sig) {
          res.status(400).json({ error: `Signature pizza not found: ${item.name || item.id}` });
          return;
        }
        const unitPrice = sig.price;
        const totalPrice = unitPrice * qty;
        calculatedSubtotal += totalPrice;

        authoritativeItems.push({
          id: sig.id,
          name: sig.name,
          isCustom: false,
          unitPrice,
          quantity: qty,
          totalPrice
        });
      }
    }

    // Pre-validate stock availability
    const stockCheck = await validateStockAvailability(authoritativeItems);
    if (!stockCheck.available) {
      res.status(400).json({
        error: 'Some selected ingredients are currently out of stock or low in inventory.',
        details: stockCheck.unavailableIngredients
      });
      return;
    }

    const deliveryFee = calculatedSubtotal > 600 ? 0 : 50; // Free delivery over ₹600
    const tax = Math.round(calculatedSubtotal * 0.05); // 5% GST
    const discount = 0;
    const totalAmount = calculatedSubtotal + deliveryFee + tax - discount;

    const orderId = `CC-ORD-${Math.floor(10000 + Math.random() * 90000)}`;
    const now = new Date().toISOString();

    const initialHistory: StatusHistoryEntry[] = [
      {
        status: 'Order Received',
        timestamp: now,
        note: 'Order registered and awaiting payment confirmation.'
      }
    ];

    const newOrder: Order = {
      id: orderId,
      customerId: userId!,
      customerName: userName || user.name,
      customerEmail: userEmail || user.email,
      customerPhone: customerPhone.trim(),
      deliveryAddress,
      items: authoritativeItems,
      subtotal: calculatedSubtotal,
      deliveryFee,
      tax,
      discount,
      totalAmount,
      paymentStatus: 'pending',
      paymentMethod: 'razorpay_test_simulator',
      orderStatus: 'Order Received',
      statusHistory: initialHistory,
      stockDeducted: false,
      createdAt: now,
      updatedAt: now
    };

    db.orders.unshift(newOrder);
    saveDatabase(db);

    res.status(201).json({
      message: 'Order created successfully. Ready for payment.',
      order: newOrder
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error creating order.' });
  }
});

// 2. Customer Order History
orderRouter.get('/my-orders', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const userId = req.user?.userId;
  const db = loadDatabase();
  const myOrders = db.orders.filter(o => o.customerId === userId);
  res.json(myOrders);
});

// 3. Track Specific Order
orderRouter.get('/:id/track', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = loadDatabase();
  const order = db.orders.find(o => o.id === id);

  if (!order) {
    res.status(404).json({ error: 'Order not found.' });
    return;
  }

  // Security check: Only the customer who placed the order or an admin can view it
  if (req.user?.role !== 'admin' && order.customerId !== req.user?.userId) {
    res.status(403).json({ error: 'Unauthorized to view this order.' });
    return;
  }

  res.json(order);
});
