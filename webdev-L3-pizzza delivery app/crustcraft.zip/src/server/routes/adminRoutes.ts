import { Router, Response } from 'express';
import { loadDatabase, saveDatabase } from '../db.js';
import { authenticate, requireAdmin, AuthenticatedRequest } from '../services/authService.js';
import { manualAdjustStock, updateItemSettings } from '../services/inventoryService.js';
import { runLowStockAudit } from '../services/cronService.js';
import { AdminStats, InventoryItem, OrderStatus, IngredientCategory } from '../../types/index.js';

export const adminRouter = Router();

// Protect ALL admin routes with server-side authentication & admin role check
adminRouter.use(authenticate);
adminRouter.use(requireAdmin);

// 1. Dashboard Summary Statistics
adminRouter.get('/stats', (_req: AuthenticatedRequest, res: Response) => {
  const db = loadDatabase();
  const orders = db.orders;
  const inventory = db.inventory;

  const totalOrders = orders.length;
  const newOrders = orders.filter(o => o.orderStatus === 'Order Received').length;
  const inKitchenOrders = orders.filter(o => o.orderStatus === 'In Kitchen').length;
  const sentToDeliveryOrders = orders.filter(o => o.orderStatus === 'Sent to Delivery').length;
  const deliveredOrders = orders.filter(o => o.orderStatus === 'Delivered').length;

  const totalRevenue = orders
    .filter(o => o.paymentStatus === 'paid')
    .reduce((sum, o) => sum + o.totalAmount, 0);

  const lowStockItems = inventory.filter(i => i.availableQuantity < i.lowStockThreshold);

  const stats: AdminStats = {
    totalOrders,
    newOrders,
    inKitchenOrders,
    sentToDeliveryOrders,
    deliveredOrders,
    totalRevenue,
    lowStockItemsCount: lowStockItems.length,
    lowStockItems
  };

  res.json(stats);
});

// 2. Inventory Listing & Categories
adminRouter.get('/inventory', (_req: AuthenticatedRequest, res: Response) => {
  const db = loadDatabase();
  res.json({
    inventory: db.inventory,
    stockLogs: db.stockLogs.slice(0, 50)
  });
});

// 3. Add New Inventory Item
adminRouter.post('/inventory', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { name, category, availableQuantity, unit, lowStockThreshold, unitCost, customerPrice, description } = req.body;

    if (!name || !category || availableQuantity === undefined || !unit || lowStockThreshold === undefined) {
      res.status(400).json({ error: 'All primary fields (name, category, quantity, unit, threshold) are required.' });
      return;
    }

    const validCategories: IngredientCategory[] = ['base', 'sauce', 'cheese', 'vegetable'];
    if (!validCategories.includes(category)) {
      res.status(400).json({ error: `Category must be one of: ${validCategories.join(', ')}` });
      return;
    }

    const qty = parseInt(availableQuantity, 10);
    const threshold = parseInt(lowStockThreshold, 10);
    if (isNaN(qty) || qty < 0 || isNaN(threshold) || threshold < 0) {
      res.status(400).json({ error: 'Quantity and threshold must be positive numbers.' });
      return;
    }

    const db = loadDatabase();
    const id = `${category}_${name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_${Date.now().toString().slice(-4)}`;

    const newItem: InventoryItem = {
      id,
      name: name.trim(),
      category,
      availableQuantity: qty,
      unit: unit.trim(),
      lowStockThreshold: threshold,
      unitCost: parseFloat(unitCost) || 20,
      customerPrice: parseFloat(customerPrice) || 40,
      isAvailable: qty > 0,
      description: description ? description.trim() : undefined,
      lastUpdated: new Date().toISOString()
    };

    db.inventory.push(newItem);
    saveDatabase(db);

    res.status(201).json({ message: 'Inventory ingredient added successfully.', item: newItem });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error adding inventory item.' });
  }
});

// 4. Manual Stock Adjustment with Audit Reason
adminRouter.post('/inventory/:id/adjust', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { newQuantity, reason } = req.body;
    const adminEmail = req.user?.email || 'admin@crustcraft.com';

    const qty = parseInt(newQuantity, 10);
    if (isNaN(qty) || qty < 0) {
      res.status(400).json({ error: 'Quantity must be a valid non-negative integer.' });
      return;
    }

    const result = await manualAdjustStock(id, qty, reason, adminEmail);
    if (!result.success) {
      res.status(400).json({ error: result.error });
      return;
    }

    res.json({ message: 'Stock adjusted successfully.', item: result.item });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error adjusting stock.' });
  }
});

// 5. Update Item Settings (Threshold, Price, Cost, Availability)
adminRouter.patch('/inventory/:id', async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const adminEmail = req.user?.email || 'admin@crustcraft.com';
    const result = await updateItemSettings(id, req.body, adminEmail);

    if (!result.success) {
      res.status(400).json({ error: result.error });
      return;
    }

    res.json({ message: 'Inventory item updated.', item: result.item });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating item.' });
  }
});

// 6. Order Management - List all orders
adminRouter.get('/orders', (req: AuthenticatedRequest, res: Response) => {
  const db = loadDatabase();
  const statusFilter = req.query.status as string;

  let orders = db.orders;
  if (statusFilter && statusFilter !== 'all') {
    orders = orders.filter(o => o.orderStatus === statusFilter);
  }

  res.json(orders);
});

// 7. Update Order Status
adminRouter.patch('/orders/:id/status', (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { newStatus, note } = req.body;

    const validStatuses: OrderStatus[] = ['Order Received', 'In Kitchen', 'Sent to Delivery', 'Delivered', 'Cancelled'];
    if (!validStatuses.includes(newStatus)) {
      res.status(400).json({ error: `Invalid order status. Allowed: ${validStatuses.join(', ')}` });
      return;
    }

    const db = loadDatabase();
    const order = db.orders.find(o => o.id === id);

    if (!order) {
      res.status(404).json({ error: 'Order not found.' });
      return;
    }

    const now = new Date().toISOString();
    order.orderStatus = newStatus;
    order.statusHistory.push({
      status: newStatus,
      timestamp: now,
      note: note || `Status updated to ${newStatus} by Admin`
    });
    order.updatedAt = now;
    saveDatabase(db);

    res.json({
      message: `Order status updated to ${newStatus}`,
      order
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error updating status.' });
  }
});

// 8. Instant Trigger for Low Stock Audit & Alert Email (Testing & Evaluation)
adminRouter.post('/trigger-stock-check', async (_req: AuthenticatedRequest, res: Response) => {
  try {
    const auditResult = await runLowStockAudit();
    res.json({
      message: 'Automated low stock inventory audit completed.',
      ...auditResult
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error executing stock check.' });
  }
});

// 9. Mail Outbox Inspection (For inspecting emails sent in test environment)
adminRouter.get('/mail-outbox', (_req: AuthenticatedRequest, res: Response) => {
  const db = loadDatabase();
  res.json(db.outbox);
});
