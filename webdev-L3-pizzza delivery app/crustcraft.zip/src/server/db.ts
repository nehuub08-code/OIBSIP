import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import {
  User,
  InventoryItem,
  Order,
  StockAdjustmentLog,
  SignaturePizza,
  OutboxMail
} from '../types/index.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DATA_DIR, 'db.json');

interface DatabaseSchema {
  users: User[];
  inventory: InventoryItem[];
  signaturePizzas: SignaturePizza[];
  orders: Order[];
  stockLogs: StockAdjustmentLog[];
  outbox: OutboxMail[];
}

let dbCache: DatabaseSchema | null = null;

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

export function getInitialSeedData(): DatabaseSchema {
  // Pre-hashed password for Admin: 'Admin@123456'
  const salt = bcrypt.genSaltSync(10);
  const adminPasswordHash = bcrypt.hashSync('Admin@123456', salt);

  const adminUser: User = {
    id: 'usr_admin_001',
    name: 'Master Chef Admin',
    email: 'admin@crustcraft.com',
    passwordHash: adminPasswordHash,
    role: 'admin',
    isVerified: true,
    createdAt: new Date().toISOString()
  };

  const inventory: InventoryItem[] = [
    // 5 Bases
    {
      id: 'base_hand_tossed',
      name: 'Classic Hand-Tossed',
      category: 'base',
      availableQuantity: 45,
      unit: 'dough balls',
      lowStockThreshold: 20,
      unitCost: 30,
      customerPrice: 150,
      isAvailable: true,
      description: 'Traditional slow-fermented wheat crust, crisp outer rim with airy crumb.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'base_thin_crust',
      name: 'Thin Crust (Roman Style)',
      category: 'base',
      availableQuantity: 32,
      unit: 'dough balls',
      lowStockThreshold: 20,
      unitCost: 25,
      customerPrice: 160,
      isAvailable: true,
      description: 'Ultra-thin, blistered crunch that highlights fresh toppings.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'base_whole_wheat',
      name: 'Whole Wheat Organic',
      category: 'base',
      availableQuantity: 18, // Intentionally close/under threshold for realistic low-stock test!
      unit: 'dough balls',
      lowStockThreshold: 20,
      unitCost: 35,
      customerPrice: 180,
      isAvailable: true,
      description: '100% stoneground whole grain with a nutty aroma and fiber rich.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'base_cheese_burst',
      name: 'Cheese Burst Supreme',
      category: 'base',
      availableQuantity: 28,
      unit: 'dough balls',
      lowStockThreshold: 20,
      unitCost: 65,
      customerPrice: 240,
      isAvailable: true,
      description: 'Double-crust core filled with gooey, melted molten cheese.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'base_gluten_free',
      name: 'Gluten-Free Cauliflower & Rice',
      category: 'base',
      availableQuantity: 15, // Low stock demo!
      unit: 'dough balls',
      lowStockThreshold: 20,
      unitCost: 70,
      customerPrice: 250,
      isAvailable: true,
      description: 'Certified gluten-free crispy golden crust without compromise.',
      lastUpdated: new Date().toISOString()
    },

    // 5 Sauces
    {
      id: 'sauce_classic_tomato',
      name: 'Classic San Marzano Tomato',
      category: 'sauce',
      availableQuantity: 60,
      unit: 'ladles',
      lowStockThreshold: 25,
      unitCost: 15,
      customerPrice: 50,
      isAvailable: true,
      description: 'Sun-ripened Italian plum tomatoes crushed with sea salt and fresh oregano.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'sauce_spicy_arrabbiata',
      name: 'Spicy Arrabbiata',
      category: 'sauce',
      availableQuantity: 42,
      unit: 'ladles',
      lowStockThreshold: 20,
      unitCost: 18,
      customerPrice: 60,
      isAvailable: true,
      description: 'Fire-roasted garlic and crushed Calabrian chili pepper reduction.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'sauce_pesto_genovese',
      name: 'Pesto Genovese (Basil & Pine Nut)',
      category: 'sauce',
      availableQuantity: 30,
      unit: 'ladles',
      lowStockThreshold: 15,
      unitCost: 35,
      customerPrice: 85,
      isAvailable: true,
      description: 'Fresh aromatic Genovese basil crushed with olive oil and pine nuts.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'sauce_smoky_barbecue',
      name: 'Smoky Bourbon Barbecue',
      category: 'sauce',
      availableQuantity: 38,
      unit: 'ladles',
      lowStockThreshold: 20,
      unitCost: 20,
      customerPrice: 65,
      isAvailable: true,
      description: 'Rich slow-simmered hickory and dark molasses glaze.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'sauce_creamy_garlic',
      name: 'Creamy Roasted Garlic Alfredo',
      category: 'sauce',
      availableQuantity: 24,
      unit: 'ladles',
      lowStockThreshold: 15,
      unitCost: 25,
      customerPrice: 75,
      isAvailable: true,
      description: 'Velvety cream reduction with confit garlic and cracked black pepper.',
      lastUpdated: new Date().toISOString()
    },

    // 4 Cheeses
    {
      id: 'cheese_mozzarella',
      name: 'Fior di Latte Mozzarella',
      category: 'cheese',
      availableQuantity: 75,
      unit: 'portions',
      lowStockThreshold: 30,
      unitCost: 40,
      customerPrice: 90,
      isAvailable: true,
      description: 'Silky, fresh cow-milk mozzarella with classic golden melt.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'cheese_cheddar',
      name: 'Sharp Aged Cheddar',
      category: 'cheese',
      availableQuantity: 40,
      unit: 'portions',
      lowStockThreshold: 20,
      unitCost: 45,
      customerPrice: 95,
      isAvailable: true,
      description: 'English mature cheddar bringing tangy, punchy depth.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'cheese_parmesan',
      name: 'Parmigiano-Reggiano',
      category: 'cheese',
      availableQuantity: 35,
      unit: 'portions',
      lowStockThreshold: 15,
      unitCost: 55,
      customerPrice: 110,
      isAvailable: true,
      description: 'Aged 24 months, savory umami crystalline grating cheese.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'cheese_vegan',
      name: 'Plant-Based Mozza (Dairy-Free)',
      category: 'cheese',
      availableQuantity: 22,
      unit: 'portions',
      lowStockThreshold: 15,
      unitCost: 60,
      customerPrice: 120,
      isAvailable: true,
      description: 'Cultured cashew and coconut blend that melts smoothly.',
      lastUpdated: new Date().toISOString()
    },

    // 7 Vegetables
    {
      id: 'veg_red_onion',
      name: 'Caramelized Red Onion',
      category: 'vegetable',
      availableQuantity: 80,
      unit: 'servings',
      lowStockThreshold: 25,
      unitCost: 10,
      customerPrice: 35,
      isAvailable: true,
      description: 'Crisp red onion slivers, sweet and mildly piquant.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'veg_capsicum',
      name: 'Crisp Green Bell Pepper (Capsicum)',
      category: 'vegetable',
      availableQuantity: 65,
      unit: 'servings',
      lowStockThreshold: 25,
      unitCost: 12,
      customerPrice: 35,
      isAvailable: true,
      description: 'Fresh farm bell peppers providing crunchy, garden-fresh bite.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'veg_button_mushroom',
      name: 'Sautéed Cremini Mushroom',
      category: 'vegetable',
      availableQuantity: 50,
      unit: 'servings',
      lowStockThreshold: 20,
      unitCost: 18,
      customerPrice: 45,
      isAvailable: true,
      description: 'Earthy, garlic-tossed cremini and button mushrooms.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'veg_sweet_corn',
      name: 'Golden Sweet Corn',
      category: 'vegetable',
      availableQuantity: 55,
      unit: 'servings',
      lowStockThreshold: 20,
      unitCost: 12,
      customerPrice: 35,
      isAvailable: true,
      description: 'Juicy, naturally sweet kernels plucked at peak harvest.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'veg_black_olives',
      name: 'Spanish Black Olives',
      category: 'vegetable',
      availableQuantity: 40,
      unit: 'servings',
      lowStockThreshold: 20,
      unitCost: 20,
      customerPrice: 45,
      isAvailable: true,
      description: 'Sliced Mediterranean black olives cured in sea salt brine.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'veg_jalapenos',
      name: 'Spicy Pickled Jalapeños',
      category: 'vegetable',
      availableQuantity: 45,
      unit: 'servings',
      lowStockThreshold: 20,
      unitCost: 16,
      customerPrice: 40,
      isAvailable: true,
      description: 'Tangy, zesty jalapeño pepper rings with lively heat.',
      lastUpdated: new Date().toISOString()
    },
    {
      id: 'veg_roma_tomato',
      name: 'Sun-Drenched Roma Tomato',
      category: 'vegetable',
      availableQuantity: 50,
      unit: 'servings',
      lowStockThreshold: 20,
      unitCost: 12,
      customerPrice: 35,
      isAvailable: true,
      description: 'Thinly sliced juicy Roma tomatoes with sweet acidity.',
      lastUpdated: new Date().toISOString()
    }
  ];

  const signaturePizzas: SignaturePizza[] = [
    {
      id: 'sig_margherita',
      name: 'Margherita Reale',
      description: 'San Marzano tomatoes, Fior di Latte mozzarella, fragrant basil leaves, and pure olive oil drizzle.',
      category: 'Classic',
      price: 380,
      baseIngredients: ['Classic Hand-Tossed', 'San Marzano Tomato', 'Fior di Latte Mozzarella', 'Roma Tomato'],
      ingredientIds: {
        baseId: 'base_hand_tossed',
        sauceId: 'sauce_classic_tomato',
        cheeseId: 'cheese_mozzarella',
        vegetableIds: ['veg_roma_tomato']
      },
      badge: 'Bestseller'
    },
    {
      id: 'sig_truffle_mushroom',
      name: 'Truffle & Forest Mushroom',
      description: 'Roasted garlic alfredo, sautéed cremini mushrooms, sharp parmesan, caramelized red onion, and white truffle scent.',
      category: 'Gourmet',
      price: 520,
      baseIngredients: ['Thin Crust (Roman Style)', 'Creamy Garlic Alfredo', 'Parmesan', 'Sautéed Mushrooms', 'Red Onion'],
      ingredientIds: {
        baseId: 'base_thin_crust',
        sauceId: 'sauce_creamy_garlic',
        cheeseId: 'cheese_parmesan',
        vegetableIds: ['veg_button_mushroom', 'veg_red_onion']
      },
      badge: 'Chef Signature'
    },
    {
      id: 'sig_spicy_diavola',
      name: 'Fiery Diavola & Jalapeño',
      description: 'Spicy Arrabbiata sauce, aged cheddar, melted mozzarella, pickled jalapeños, sweet corn, and chili flakes.',
      category: 'Gourmet',
      price: 460,
      baseIngredients: ['Classic Hand-Tossed', 'Spicy Arrabbiata', 'Sharp Aged Cheddar', 'Pickled Jalapeños', 'Sweet Corn'],
      ingredientIds: {
        baseId: 'base_hand_tossed',
        sauceId: 'sauce_spicy_arrabbiata',
        cheeseId: 'cheese_cheddar',
        vegetableIds: ['veg_jalapenos', 'veg_sweet_corn']
      },
      badge: 'Spicy'
    },
    {
      id: 'sig_pesto_burrata',
      name: 'Pesto Genovese & Garden Harvest',
      description: 'Fresh basil pesto base, plant-based or dairy mozzarella, black olives, bell pepper, and crisp red onion.',
      category: 'Vegetarian',
      price: 490,
      baseIngredients: ['Whole Wheat Organic', 'Pesto Genovese', 'Fior di Latte Mozzarella', 'Black Olives', 'Capsicum'],
      ingredientIds: {
        baseId: 'base_whole_wheat',
        sauceId: 'sauce_pesto_genovese',
        cheeseId: 'cheese_mozzarella',
        vegetableIds: ['veg_black_olives', 'veg_capsicum']
      },
      badge: 'Organic Wheat'
    },
    {
      id: 'sig_farmhouse_supreme',
      name: 'Rustica Farmhouse Supreme',
      description: 'Loaded with capsicum, cremini mushroom, sweet corn, Roma tomatoes, mozzarella on our signature Cheese Burst crust.',
      category: 'Classic',
      price: 560,
      baseIngredients: ['Cheese Burst Supreme', 'Classic Tomato', 'Mozzarella', 'Capsicum', 'Mushroom', 'Sweet Corn', 'Tomato'],
      ingredientIds: {
        baseId: 'base_cheese_burst',
        sauceId: 'sauce_classic_tomato',
        cheeseId: 'cheese_mozzarella',
        vegetableIds: ['veg_capsicum', 'veg_button_mushroom', 'veg_sweet_corn', 'veg_roma_tomato']
      },
      badge: 'Crowd Favorite'
    }
  ];

  return {
    users: [adminUser],
    inventory,
    signaturePizzas,
    orders: [],
    stockLogs: [],
    outbox: []
  };
}

export function loadDatabase(): DatabaseSchema {
  if (dbCache) return dbCache;

  ensureDataDir();
  if (fs.existsSync(DB_FILE)) {
    try {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      dbCache = JSON.parse(content) as DatabaseSchema;
      return dbCache;
    } catch {
      // Fallback to initial
    }
  }

  const initial = getInitialSeedData();
  saveDatabase(initial);
  return initial;
}

export function saveDatabase(data: DatabaseSchema): void {
  ensureDataDir();
  dbCache = data;
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

// In-memory mutex lock for atomic operations (such as concurrent stock deduction)
class Mutex {
  private queue: Array<() => void> = [];
  private locked = false;

  async acquire(): Promise<() => void> {
    return new Promise((resolve) => {
      const execute = () => {
        this.locked = true;
        resolve(() => {
          this.locked = false;
          const next = this.queue.shift();
          if (next) next();
        });
      };

      if (!this.locked) {
        execute();
      } else {
        this.queue.push(execute);
      }
    });
  }
}

export const dbMutex = new Mutex();
