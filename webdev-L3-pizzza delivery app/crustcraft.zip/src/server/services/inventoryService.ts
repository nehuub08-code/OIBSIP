import { loadDatabase, saveDatabase, dbMutex } from '../db.js';
import { InventoryItem, Order, OrderItem, StockAdjustmentLog } from '../../types/index.js';

export function getInventory(): InventoryItem[] {
  const db = loadDatabase();
  return db.inventory;
}

export function getInventoryItem(id: string): InventoryItem | undefined {
  const db = loadDatabase();
  return db.inventory.find(i => i.id === id);
}

export interface IngredientUsage {
  ingredientId: string;
  quantityNeeded: number;
}

export function extractIngredientRequirements(items: OrderItem[]): IngredientUsage[] {
  const db = loadDatabase();
  const map = new Map<string, number>();

  for (const item of items) {
    if (item.isCustom && item.customConfig) {
      const cfg = item.customConfig;
      // Base
      if (cfg.baseId) {
        map.set(cfg.baseId, (map.get(cfg.baseId) || 0) + item.quantity);
      }
      // Sauce
      if (cfg.sauceId) {
        map.set(cfg.sauceId, (map.get(cfg.sauceId) || 0) + item.quantity);
      }
      // Cheese
      if (cfg.cheeseId) {
        map.set(cfg.cheeseId, (map.get(cfg.cheeseId) || 0) + item.quantity);
      }
      // Vegetables
      if (cfg.vegetableIds && Array.isArray(cfg.vegetableIds)) {
        for (const vegId of cfg.vegetableIds) {
          map.set(vegId, (map.get(vegId) || 0) + item.quantity);
        }
      }
    } else {
      // Look up signature pizza
      const sig = db.signaturePizzas.find(s => s.id === item.id || s.name === item.name);
      if (sig && sig.ingredientIds) {
        const { baseId, sauceId, cheeseId, vegetableIds } = sig.ingredientIds;
        if (baseId) map.set(baseId, (map.get(baseId) || 0) + item.quantity);
        if (sauceId) map.set(sauceId, (map.get(sauceId) || 0) + item.quantity);
        if (cheeseId) map.set(cheeseId, (map.get(cheeseId) || 0) + item.quantity);
        if (vegetableIds) {
          for (const vId of vegetableIds) {
            map.set(vId, (map.get(vId) || 0) + item.quantity);
          }
        }
      }
    }
  }

  return Array.from(map.entries()).map(([ingredientId, quantityNeeded]) => ({
    ingredientId,
    quantityNeeded
  }));
}

export async function validateStockAvailability(items: OrderItem[]): Promise<{
  available: boolean;
  unavailableIngredients: string[];
}> {
  const release = await dbMutex.acquire();
  try {
    const db = loadDatabase();
    const requirements = extractIngredientRequirements(items);
    const unavailable: string[] = [];

    for (const req of requirements) {
      const item = db.inventory.find(i => i.id === req.ingredientId);
      if (!item) {
        unavailable.push(`Unknown ingredient ID: ${req.ingredientId}`);
      } else if (!item.isAvailable || item.availableQuantity < req.quantityNeeded) {
        unavailable.push(`${item.name} (Need ${req.quantityNeeded} ${item.unit}, only ${item.availableQuantity} available)`);
      }
    }

    return {
      available: unavailable.length === 0,
      unavailableIngredients: unavailable
    };
  } finally {
    release();
  }
}

export async function deductOrderStock(order: Order): Promise<{
  success: boolean;
  error?: string;
}> {
  const release = await dbMutex.acquire();
  try {
    const db = loadDatabase();

    // Check if order was already stock deducted (Idempotency)
    const existingOrder = db.orders.find(o => o.id === order.id);
    if (existingOrder && existingOrder.stockDeducted) {
      return { success: true };
    }

    const requirements = extractIngredientRequirements(order.items);

    // Verify all stock is sufficient right now
    for (const req of requirements) {
      const item = db.inventory.find(i => i.id === req.ingredientId);
      if (!item || item.availableQuantity < req.quantityNeeded) {
        return {
          success: false,
          error: `Insufficient inventory for ${item?.name || req.ingredientId}. Stock commit aborted.`
        };
      }
    }

    // Atomic deduction
    const now = new Date().toISOString();
    for (const req of requirements) {
      const item = db.inventory.find(i => i.id === req.ingredientId)!;
      const prevQty = item.availableQuantity;
      item.availableQuantity -= req.quantityNeeded;
      item.lastUpdated = now;

      // Log adjustment
      const log: StockAdjustmentLog = {
        id: `adj_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        itemId: item.id,
        itemName: item.name,
        previousQuantity: prevQty,
        newQuantity: item.availableQuantity,
        change: -req.quantityNeeded,
        reason: `Auto deduction for paid order #${order.id}`,
        adjustedBy: 'system_order_deduction',
        orderId: order.id,
        timestamp: now
      };
      db.stockLogs.unshift(log);
    }

    // Mark order as stock deducted
    if (existingOrder) {
      existingOrder.stockDeducted = true;
      existingOrder.updatedAt = now;
    }

    saveDatabase(db);
    return { success: true };
  } finally {
    release();
  }
}

export async function manualAdjustStock(
  itemId: string,
  newQuantity: number,
  reason: string,
  adminEmail: string
): Promise<{ success: boolean; item?: InventoryItem; error?: string }> {
  if (newQuantity < 0) {
    return { success: false, error: 'Inventory stock cannot be negative.' };
  }

  const release = await dbMutex.acquire();
  try {
    const db = loadDatabase();
    const item = db.inventory.find(i => i.id === itemId);
    if (!item) {
      return { success: false, error: 'Inventory item not found.' };
    }

    const prev = item.availableQuantity;
    const diff = newQuantity - prev;
    const now = new Date().toISOString();

    item.availableQuantity = newQuantity;
    item.lastUpdated = now;
    item.isAvailable = newQuantity > 0;

    // Reset lastAlertSentAt if restocked above threshold!
    if (newQuantity > item.lowStockThreshold) {
      item.lastAlertSentAt = undefined;
    }

    const log: StockAdjustmentLog = {
      id: `adj_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      itemId: item.id,
      itemName: item.name,
      previousQuantity: prev,
      newQuantity: newQuantity,
      change: diff,
      reason: reason || 'Manual Admin Restock/Adjustment',
      adjustedBy: adminEmail,
      timestamp: now
    };
    db.stockLogs.unshift(log);

    saveDatabase(db);
    return { success: true, item };
  } finally {
    release();
  }
}

export async function updateItemSettings(
  itemId: string,
  updates: Partial<Pick<InventoryItem, 'name' | 'lowStockThreshold' | 'unitCost' | 'customerPrice' | 'isAvailable'>>,
  adminEmail: string
): Promise<{ success: boolean; item?: InventoryItem; error?: string }> {
  const release = await dbMutex.acquire();
  try {
    const db = loadDatabase();
    const item = db.inventory.find(i => i.id === itemId);
    if (!item) {
      return { success: false, error: 'Inventory item not found.' };
    }

    if (updates.lowStockThreshold !== undefined) {
      if (updates.lowStockThreshold < 0) {
        return { success: false, error: 'Threshold cannot be negative.' };
      }
      item.lowStockThreshold = updates.lowStockThreshold;
    }
    if (updates.customerPrice !== undefined) {
      if (updates.customerPrice < 0) {
        return { success: false, error: 'Price cannot be negative.' };
      }
      item.customerPrice = updates.customerPrice;
    }
    if (updates.unitCost !== undefined) {
      item.unitCost = updates.unitCost;
    }
    if (updates.name !== undefined && updates.name.trim()) {
      item.name = updates.name.trim();
    }
    if (updates.isAvailable !== undefined) {
      item.isAvailable = updates.isAvailable;
    }

    item.lastUpdated = new Date().toISOString();
    saveDatabase(db);
    return { success: true, item };
  } finally {
    release();
  }
}
