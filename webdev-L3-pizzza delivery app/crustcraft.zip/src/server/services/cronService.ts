import cron, { ScheduledTask } from 'node-cron';
import { loadDatabase, saveDatabase } from '../db.js';
import { sendLowStockAlertEmail } from './emailService.js';
import { InventoryItem } from '../../types/index.js';

let cronTask: ScheduledTask | null = null;

export async function runLowStockAudit(): Promise<{
  alertSent: boolean;
  alertedItems: InventoryItem[];
  allLowStockItems: InventoryItem[];
}> {
  const db = loadDatabase();
  const lowStockItems: InventoryItem[] = [];
  const itemsNeedingAlert: InventoryItem[] = [];

  for (const item of db.inventory) {
    if (item.availableQuantity < item.lowStockThreshold) {
      lowStockItems.push(item);

      // Check if we haven't alerted yet or if it was reset after recovery
      if (!item.lastAlertSentAt) {
        itemsNeedingAlert.push(item);
      }
    }
  }

  if (itemsNeedingAlert.length > 0) {
    // Find admin email
    const admin = db.users.find(u => u.role === 'admin');
    const adminEmail = admin ? admin.email : 'admin@crustcraft.com';

    await sendLowStockAlertEmail(adminEmail, itemsNeedingAlert);

    // Update alert timestamp so we do not spam repeated emails on next cron tick
    const now = new Date().toISOString();
    for (const item of itemsNeedingAlert) {
      item.lastAlertSentAt = now;
    }
    saveDatabase(db);

    console.log(`[LowStockAudit] Alert sent for ${itemsNeedingAlert.length} items to ${adminEmail}`);
    return {
      alertSent: true,
      alertedItems: itemsNeedingAlert,
      allLowStockItems: lowStockItems
    };
  }

  return {
    alertSent: false,
    alertedItems: [],
    allLowStockItems: lowStockItems
  };
}

export function initCronJobs(): void {
  // Run inventory check every hour ('0 * * * *') or configurable CRON_SCHEDULE
  const schedule = process.env.CRON_SCHEDULE || '0 * * * *';

  cronTask = cron.schedule(schedule, async () => {
    console.log('[CrustCraft Cron] Running automated inventory threshold audit...');
    try {
      await runLowStockAudit();
    } catch (err) {
      console.error('[CrustCraft Cron] Error during low stock audit:', err);
    }
  });

  console.log(`[CrustCraft Cron] Scheduled low-stock monitor initialized with pattern: "${schedule}"`);
}
