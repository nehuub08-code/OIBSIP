import crypto from 'crypto';

const RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID || 'rzp_test_crustcraft_demo';
const RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || 'crustcraft_rzp_secret_sandbox_2026';

export const isLiveRazorpayConfigured = Boolean(
  process.env.RAZORPAY_KEY_ID &&
  process.env.RAZORPAY_KEY_SECRET &&
  process.env.RAZORPAY_KEY_ID !== 'rzp_test_crustcraft_demo'
);

export interface RazorpayOrderResult {
  razorpayOrderId: string;
  amount: number; // in paise
  currency: string;
  keyId: string;
  isMockMode: boolean;
}

export async function createRazorpayOrder({
  orderId,
  amountInRupees
}: {
  orderId: string;
  amountInRupees: number;
}): Promise<RazorpayOrderResult> {
  const amountInPaise = Math.round(amountInRupees * 100);

  if (isLiveRazorpayConfigured) {
    try {
      // Basic auth with Razorpay REST API
      const auth = Buffer.from(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`).toString('base64');
      const response = await fetch('https://api.razorpay.com/v1/orders', {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          amount: amountInPaise,
          currency: 'INR',
          receipt: orderId,
          notes: {
            platform: 'CrustCraft Artisanal Pizza'
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Razorpay API responded with status ${response.status}`);
      }

      const data = await response.json();
      return {
        razorpayOrderId: data.id,
        amount: data.amount,
        currency: data.currency,
        keyId: RAZORPAY_KEY_ID,
        isMockMode: false
      };
    } catch (err) {
      console.warn('Real Razorpay API call failed, falling back to Sandbox Simulator:', err);
    }
  }

  // Deterministic Sandbox Mock Order ID
  const mockRzpOrderId = `order_${crypto.randomBytes(8).toString('hex')}`;
  return {
    razorpayOrderId: mockRzpOrderId,
    amount: amountInPaise,
    currency: 'INR',
    keyId: RAZORPAY_KEY_ID,
    isMockMode: true
  };
}

export function verifyPaymentSignature({
  razorpayOrderId,
  razorpayPaymentId,
  razorpaySignature
}: {
  razorpayOrderId: string;
  razorpayPaymentId: string;
  razorpaySignature: string;
}): boolean {
  if (!razorpayOrderId || !razorpayPaymentId || !razorpaySignature) {
    return false;
  }

  const generatedSignature = crypto
    .createHmac('sha256', RAZORPAY_KEY_SECRET)
    .update(`${razorpayOrderId}|${razorpayPaymentId}`)
    .digest('hex');

  // Secure timing-safe buffer comparison
  try {
    const a = Buffer.from(generatedSignature);
    const b = Buffer.from(razorpaySignature);
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

export function generateTestPaymentSignature({
  razorpayOrderId,
  razorpayPaymentId
}: {
  razorpayOrderId: string;
  razorpayPaymentId: string;
}): string {
  return crypto
    .createHmac('sha256', RAZORPAY_KEY_SECRET)
    .update(`${razorpayOrderId}|${razorpayPaymentId}`)
    .digest('hex');
}
