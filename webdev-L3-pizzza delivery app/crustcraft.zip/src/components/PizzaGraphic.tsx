import React from 'react';

interface PizzaGraphicProps {
  baseId?: string;
  sauceId?: string;
  cheeseId?: string;
  vegetableIds?: string[];
  size?: 'Regular' | 'Medium' | 'Large';
  className?: string;
}

export const PizzaGraphic: React.FC<PizzaGraphicProps> = ({
  baseId = 'base_hand_tossed',
  sauceId = 'sauce_classic_tomato',
  cheeseId = 'cheese_mozzarella',
  vegetableIds = [],
  size = 'Medium',
  className = 'w-64 h-64 md:w-80 md:h-80'
}) => {
  // Crust color styling based on selected base
  let crustOuter = '#D97706'; // Golden amber
  let crustInner = '#FDE68A';
  let crustRimWidth = 24;

  if (baseId === 'base_whole_wheat') {
    crustOuter = '#92400E';
    crustInner = '#D97706';
  } else if (baseId === 'base_thin_crust') {
    crustOuter = '#B45309';
    crustInner = '#FCD34D';
    crustRimWidth = 14;
  } else if (baseId === 'base_cheese_burst') {
    crustOuter = '#D97706';
    crustInner = '#FEF08A';
    crustRimWidth = 30;
  } else if (baseId === 'base_gluten_free') {
    crustOuter = '#C2410C';
    crustInner = '#FED7AA';
  }

  // Sauce color based on sauceId
  let sauceColor = '#BE123C'; // Classic Tomato
  if (sauceId === 'sauce_spicy_arrabbiata') sauceColor = '#9F1239';
  if (sauceId === 'sauce_pesto_genovese') sauceColor = '#15803D';
  if (sauceId === 'sauce_smoky_barbecue') sauceColor = '#451A03';
  if (sauceId === 'sauce_creamy_garlic') sauceColor = '#FEF3C7';

  // Cheese color
  let cheeseFill = '#FEF08A';
  let cheeseOpacity = 0.88;
  if (cheeseId === 'cheese_cheddar') cheeseFill = '#F59E0B';
  if (cheeseId === 'cheese_parmesan') {
    cheeseFill = '#FFFBEB';
    cheeseOpacity = 0.75;
  }
  if (cheeseId === 'cheese_vegan') cheeseFill = '#FEF9C3';

  // Scale according to size
  const scale = size === 'Large' ? 1.05 : size === 'Regular' ? 0.9 : 1.0;

  return (
    <div className={`relative flex items-center justify-center select-none ${className}`}>
      <svg
        viewBox="0 0 320 320"
        className="w-full h-full drop-shadow-2xl transition-all duration-300"
        style={{ transform: `scale(${scale})` }}
      >
        <defs>
          {/* Pizza peel / board shadow */}
          <radialGradient id="peelShade" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#292524" stopOpacity="0.25" />
            <stop offset="100%" stopColor="#1C1917" stopOpacity="0" />
          </radialGradient>

          {/* Charred wood oven gradient */}
          <radialGradient id="crustGradient" cx="45%" cy="45%" r="55%">
            <stop offset="70%" stopColor={crustInner} />
            <stop offset="92%" stopColor={crustOuter} />
            <stop offset="100%" stopColor="#78350F" />
          </radialGradient>

          {/* Melted bubbly cheese texture */}
          <filter id="cheeseMelt" x="-10%" y="-10%" width="120%" height="120%">
            <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="3" result="noise" />
            <feDisplacementMap in="SourceGraphic" in2="noise" scale="6" />
          </filter>
        </defs>

        {/* Ambient shadow */}
        <circle cx="160" cy="164" r="148" fill="url(#peelShade)" />

        {/* Outer Oven-Baked Crust */}
        <circle cx="160" cy="160" r="140" fill="url(#crustGradient)" />

        {/* Charred wood-fired blisters on rim */}
        <circle cx="95" cy="48" r="4.5" fill="#451A03" opacity="0.6" />
        <circle cx="230" cy="60" r="5" fill="#451A03" opacity="0.5" />
        <circle cx="280" cy="140" r="4" fill="#451A03" opacity="0.7" />
        <circle cx="265" cy="235" r="5.5" fill="#451A03" opacity="0.5" />
        <circle cx="70" cy="220" r="6" fill="#451A03" opacity="0.6" />
        <circle cx="45" cy="130" r="5" fill="#451A03" opacity="0.65" />

        {/* Sauce Layer */}
        <circle
          cx="160"
          cy="160"
          r={140 - crustRimWidth}
          fill={sauceColor}
          className="transition-colors duration-500"
        />

        {/* Melted Cheese Layer */}
        <circle
          cx="160"
          cy="160"
          r={136 - crustRimWidth}
          fill={cheeseFill}
          opacity={cheeseOpacity}
          filter="url(#cheeseMelt)"
          className="transition-colors duration-500"
        />

        {/* Char spots on cheese */}
        <circle cx="130" cy="120" r="3" fill="#B45309" opacity="0.6" />
        <circle cx="190" cy="140" r="3.5" fill="#B45309" opacity="0.5" />
        <circle cx="150" cy="200" r="4" fill="#92400E" opacity="0.4" />
        <circle cx="205" cy="195" r="2.5" fill="#B45309" opacity="0.7" />

        {/* Vegetable Toppings Scatter */}
        {vegetableIds.includes('veg_red_onion') && (
          <g id="onion-toppings" className="transition-opacity duration-300">
            {/* Violet slivers */}
            <path d="M 120 110 Q 135 105 145 118" stroke="#831843" strokeWidth="3.5" strokeLinecap="round" fill="none" />
            <path d="M 180 100 Q 200 110 195 125" stroke="#831843" strokeWidth="3.5" strokeLinecap="round" fill="none" />
            <path d="M 210 170 Q 225 185 215 200" stroke="#831843" strokeWidth="3.5" strokeLinecap="round" fill="none" />
            <path d="M 125 190 Q 110 205 130 215" stroke="#831843" strokeWidth="3.5" strokeLinecap="round" fill="none" />
            <path d="M 160 145 Q 170 160 155 170" stroke="#831843" strokeWidth="3.5" strokeLinecap="round" fill="none" />
          </g>
        )}

        {vegetableIds.includes('veg_capsicum') && (
          <g id="capsicum-toppings" className="transition-opacity duration-300">
            {/* Vibrant green bell pepper curled slices */}
            <path d="M 140 90 C 150 85, 165 95, 160 105" stroke="#15803D" strokeWidth="5" strokeLinecap="round" fill="none" />
            <path d="M 220 120 C 230 135, 215 150, 205 145" stroke="#15803D" strokeWidth="5" strokeLinecap="round" fill="none" />
            <path d="M 175 185 C 190 190, 185 210, 170 205" stroke="#15803D" strokeWidth="5" strokeLinecap="round" fill="none" />
            <path d="M 100 150 C 95 165, 110 175, 115 160" stroke="#15803D" strokeWidth="5" strokeLinecap="round" fill="none" />
          </g>
        )}

        {vegetableIds.includes('veg_button_mushroom') && (
          <g id="mushroom-toppings" className="transition-opacity duration-300">
            {/* Tan button mushroom caps */}
            <g transform="translate(115, 130) rotate(-15)">
              <ellipse cx="0" cy="0" rx="10" ry="7" fill="#D6D3D1" stroke="#A8A29E" strokeWidth="1" />
              <rect x="-3" y="0" width="6" height="8" fill="#E7E5E4" rx="2" />
            </g>
            <g transform="translate(185, 115) rotate(25)">
              <ellipse cx="0" cy="0" rx="10" ry="7" fill="#D6D3D1" stroke="#A8A29E" strokeWidth="1" />
              <rect x="-3" y="0" width="6" height="8" fill="#E7E5E4" rx="2" />
            </g>
            <g transform="translate(145, 180) rotate(-40)">
              <ellipse cx="0" cy="0" rx="11" ry="8" fill="#D6D3D1" stroke="#A8A29E" strokeWidth="1" />
              <rect x="-3" y="0" width="6" height="8" fill="#E7E5E4" rx="2" />
            </g>
            <g transform="translate(200, 175) rotate(10)">
              <ellipse cx="0" cy="0" rx="9" ry="6" fill="#D6D3D1" stroke="#A8A29E" strokeWidth="1" />
              <rect x="-2" y="0" width="4" height="7" fill="#E7E5E4" rx="1" />
            </g>
          </g>
        )}

        {vegetableIds.includes('veg_sweet_corn') && (
          <g id="corn-toppings" className="transition-opacity duration-300">
            {/* Golden kernels */}
            <ellipse cx="105" cy="105" rx="3.5" ry="5" fill="#EAB308" transform="rotate(30 105 105)" />
            <ellipse cx="112" cy="112" rx="3.5" ry="5" fill="#EAB308" transform="rotate(-15 112 112)" />
            <ellipse cx="170" cy="100" rx="3.5" ry="5" fill="#EAB308" transform="rotate(45 170 100)" />
            <ellipse cx="205" cy="105" rx="3.5" ry="5" fill="#EAB308" transform="rotate(10 205 105)" />
            <ellipse cx="225" cy="160" rx="3.5" ry="5" fill="#EAB308" transform="rotate(-30 225 160)" />
            <ellipse cx="175" cy="165" rx="3.5" ry="5" fill="#EAB308" transform="rotate(60 175 165)" />
            <ellipse cx="140" cy="150" rx="3.5" ry="5" fill="#EAB308" transform="rotate(20 140 150)" />
            <ellipse cx="110" cy="180" rx="3.5" ry="5" fill="#EAB308" transform="rotate(-40 110 180)" />
            <ellipse cx="145" cy="210" rx="3.5" ry="5" fill="#EAB308" transform="rotate(15 145 210)" />
            <ellipse cx="185" cy="205" rx="3.5" ry="5" fill="#EAB308" transform="rotate(-25 185 205)" />
          </g>
        )}

        {vegetableIds.includes('veg_black_olives') && (
          <g id="olive-toppings" className="transition-opacity duration-300">
            {/* Sliced olive rings with hole */}
            <g transform="translate(135, 125)">
              <circle cx="0" cy="0" r="7" fill="#1C1917" />
              <circle cx="0" cy="0" r="3.5" fill="#FEF08A" />
            </g>
            <g transform="translate(195, 135)">
              <circle cx="0" cy="0" r="7" fill="#1C1917" />
              <circle cx="0" cy="0" r="3.5" fill="#FEF08A" />
            </g>
            <g transform="translate(155, 160)">
              <circle cx="0" cy="0" r="7.5" fill="#1C1917" />
              <circle cx="0" cy="0" r="3.5" fill="#FEF08A" />
            </g>
            <g transform="translate(130, 195)">
              <circle cx="0" cy="0" r="7" fill="#1C1917" />
              <circle cx="0" cy="0" r="3.5" fill="#FEF08A" />
            </g>
            <g transform="translate(190, 190)">
              <circle cx="0" cy="0" r="6.5" fill="#1C1917" />
              <circle cx="0" cy="0" r="3" fill="#FEF08A" />
            </g>
          </g>
        )}

        {vegetableIds.includes('veg_jalapenos') && (
          <g id="jalapeno-toppings" className="transition-opacity duration-300">
            {/* Zesty green rings */}
            <g transform="translate(150, 110)">
              <circle cx="0" cy="0" r="8" fill="#16A34A" />
              <circle cx="0" cy="0" r="4.5" fill="#FEF08A" />
              <circle cx="2" cy="-1" r="1.2" fill="#FEF3C7" />
            </g>
            <g transform="translate(210, 150)">
              <circle cx="0" cy="0" r="8.5" fill="#16A34A" />
              <circle cx="0" cy="0" r="4.5" fill="#FEF08A" />
              <circle cx="-1" cy="2" r="1.2" fill="#FEF3C7" />
            </g>
            <g transform="translate(120, 165)">
              <circle cx="0" cy="0" r="8" fill="#16A34A" />
              <circle cx="0" cy="0" r="4.5" fill="#FEF08A" />
              <circle cx="1" cy="1" r="1.2" fill="#FEF3C7" />
            </g>
            <g transform="translate(170, 190)">
              <circle cx="0" cy="0" r="8" fill="#16A34A" />
              <circle cx="0" cy="0" r="4.5" fill="#FEF08A" />
              <circle cx="-2" cy="-1" r="1.2" fill="#FEF3C7" />
            </g>
          </g>
        )}

        {vegetableIds.includes('veg_roma_tomato') && (
          <g id="tomato-toppings" className="transition-opacity duration-300">
            {/* Fresh juicy tomato wheel slices */}
            <g transform="translate(130, 140)">
              <circle cx="0" cy="0" r="11" fill="#DC2626" opacity="0.9" />
              <circle cx="0" cy="0" r="8" fill="#EF4444" />
              <circle cx="-3" cy="-2" r="2" fill="#FEF08A" opacity="0.7" />
              <circle cx="3" cy="2" r="2" fill="#FEF08A" opacity="0.7" />
            </g>
            <g transform="translate(180, 155)">
              <circle cx="0" cy="0" r="12" fill="#DC2626" opacity="0.9" />
              <circle cx="0" cy="0" r="9" fill="#EF4444" />
              <circle cx="-2" cy="3" r="2" fill="#FEF08A" opacity="0.7" />
              <circle cx="3" cy="-3" r="2" fill="#FEF08A" opacity="0.7" />
            </g>
            <g transform="translate(160, 95)">
              <circle cx="0" cy="0" r="10" fill="#DC2626" opacity="0.9" />
              <circle cx="0" cy="0" r="7.5" fill="#EF4444" />
              <circle cx="2" cy="2" r="1.8" fill="#FEF08A" opacity="0.7" />
            </g>
            <g transform="translate(165, 215)">
              <circle cx="0" cy="0" r="10.5" fill="#DC2626" opacity="0.9" />
              <circle cx="0" cy="0" r="8" fill="#EF4444" />
              <circle cx="-2" cy="-2" r="1.8" fill="#FEF08A" opacity="0.7" />
            </g>
          </g>
        )}

        {/* Basil leaves garnish */}
        <path d="M 152 148 Q 148 135 158 138 Q 166 142 152 148" fill="#15803D" />
        <path d="M 168 152 Q 178 145 174 158 Q 166 162 168 152" fill="#15803D" />
      </svg>
    </div>
  );
};
