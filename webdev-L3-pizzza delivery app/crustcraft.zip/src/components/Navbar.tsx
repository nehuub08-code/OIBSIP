import React from 'react';
import { ShoppingBag, User as UserIcon, LogOut, Shield } from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { useCart } from '../context/CartContext.js';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  onOpenOutbox: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, onNavigate, onOpenOutbox }) => {
  const { user, isAdmin, logout } = useAuth();
  const { itemCount } = useCart();

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <button
          onClick={() => onNavigate('/')}
          className="text-xl font-bold tracking-tight text-stone-900 whitespace-nowrap shrink-0 flex items-center gap-2 text-left"
        >
          <span className="text-rose-600 font-display">CrustCraft</span>
        </button>

        {/* Zone 2: 4–5 single-line clean navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-stone-600">
          <button
            onClick={() => onNavigate('/menu')}
            className={`hover:text-stone-900 transition-colors whitespace-nowrap shrink-0 ${
              currentPath === '/menu' ? 'text-rose-600 font-semibold' : ''
            }`}
          >
            Menu
          </button>
          <button
            onClick={() => onNavigate('/builder')}
            className={`hover:text-stone-900 transition-colors whitespace-nowrap shrink-0 ${
              currentPath === '/builder' ? 'text-rose-600 font-semibold' : ''
            }`}
          >
            Custom Builder
          </button>
          {user && (
            <button
              onClick={() => onNavigate('/orders')}
              className={`hover:text-stone-900 transition-colors whitespace-nowrap shrink-0 ${
                currentPath === '/orders' ? 'text-rose-600 font-semibold' : ''
              }`}
            >
              My Orders
            </button>
          )}
          <button
            onClick={onOpenOutbox}
            className="hover:text-stone-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
            title="View dispatched verification & alert emails"
          >
            <span>Mail Outbox</span>
          </button>
          <button
            onClick={() => onNavigate('/admin')}
            className={`hover:text-stone-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1 ${
              currentPath.startsWith('/admin') ? 'text-stone-900 font-semibold' : ''
            }`}
          >
            <Shield className="w-3.5 h-3.5 text-stone-400" />
            <span>Admin Portal</span>
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action Module */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Cart Trigger */}
          <button
            onClick={() => onNavigate('/cart')}
            className="relative px-3.5 py-2 text-xs font-semibold text-stone-900 bg-white border border-stone-200 rounded-lg hover:border-stone-300 transition-colors whitespace-nowrap shrink-0 flex items-center gap-2 shadow-2xs"
          >
            <ShoppingBag className="w-4 h-4 text-rose-600" />
            <span className="hidden sm:inline">Bag</span>
            {itemCount > 0 && (
              <span className="px-1.5 py-0.5 text-[10px] font-bold text-white bg-rose-600 rounded-full tabular-nums">
                {itemCount}
              </span>
            )}
          </button>

          {/* User Profile or Login */}
          {user ? (
            <div className="flex items-center gap-2">
              <span className="text-xs text-stone-600 hidden lg:inline truncate max-w-[120px]">
                {user.name.split(' ')[0]}
              </span>
              <button
                onClick={logout}
                title="Log Out"
                className="p-2 text-stone-500 hover:text-rose-600 rounded-lg hover:bg-stone-100 transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => onNavigate('/login')}
              className="px-4 py-2 text-xs font-semibold text-white bg-stone-900 rounded-lg hover:bg-stone-800 transition-colors whitespace-nowrap shrink-0"
            >
              Sign In
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
