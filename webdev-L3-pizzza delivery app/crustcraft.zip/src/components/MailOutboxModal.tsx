import React, { useState, useEffect } from 'react';
import { Mail, X, ExternalLink, RefreshCw, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';
import { OutboxMail } from '../types/index.js';

interface MailOutboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToUrl?: (url: string) => void;
}

export const MailOutboxModal: React.FC<MailOutboxModalProps> = ({
  isOpen,
  onClose,
  onNavigateToUrl
}) => {
  const [mails, setMails] = useState<OutboxMail[]>([]);
  const [selectedMail, setSelectedMail] = useState<OutboxMail | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const fetchOutbox = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/outbox/recent');
      if (res.ok) {
        const data = await res.json();
        setMails(data);
        if (data.length > 0 && !selectedMail) {
          setSelectedMail(data[0]);
        }
      }
    } catch (err) {
      console.error('Error fetching outbox:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchOutbox();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-[#FAF8F5] border border-stone-300 w-full max-w-4xl max-h-[85vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-white border-b border-stone-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                CrustCraft Mail Dispatcher & Outbox
                <span className="text-xs font-normal text-stone-500 bg-stone-100 px-2 py-0.5 rounded">
                  Simulated & SMTP Live Log
                </span>
              </h3>
              <p className="text-xs text-stone-500">
                Inspect verification tokens, password reset links, and scheduled inventory alert emails
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={fetchOutbox}
              disabled={isLoading}
              className="p-1.5 text-stone-500 hover:text-stone-900 rounded-lg hover:bg-stone-100 transition-colors"
              title="Refresh outbox"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body: Split view */}
        <div className="flex-1 flex overflow-hidden min-h-[420px]">
          {/* Email List Left */}
          <div className="w-1/3 border-r border-stone-200 bg-white overflow-y-auto">
            {mails.length === 0 ? (
              <div className="p-8 text-center text-stone-400">
                <Mail className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-xs">No emails dispatched yet.</p>
                <p className="text-[11px] text-stone-400 mt-1">Register an account or trigger stock check to test.</p>
              </div>
            ) : (
              mails.map((mail) => {
                const isSelected = selectedMail?.id === mail.id;
                return (
                  <button
                    key={mail.id}
                    onClick={() => setSelectedMail(mail)}
                    className={`w-full text-left p-3.5 border-b border-stone-100 transition-colors ${
                      isSelected ? 'bg-rose-50/60 border-l-4 border-l-rose-500' : 'hover:bg-stone-50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-stone-500">
                        {mail.type.replace('_', ' ')}
                      </span>
                      <span className="text-[10px] text-stone-400 tabular-nums">
                        {new Date(mail.sentAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-xs font-semibold text-stone-900 truncate">{mail.subject}</p>
                    <p className="text-[11px] text-stone-500 truncate mt-0.5">To: {mail.to}</p>
                  </button>
                );
              })
            )}
          </div>

          {/* Email Preview Right */}
          <div className="flex-1 bg-stone-50 flex flex-col overflow-y-auto p-6">
            {selectedMail ? (
              <div className="bg-white border border-stone-200 rounded-xl p-6 shadow-xs flex-1">
                <div className="border-b border-stone-100 pb-4 mb-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-base font-bold text-stone-900">{selectedMail.subject}</h4>
                      <p className="text-xs text-stone-600 mt-1">
                        <span className="text-stone-400">Recipient:</span> {selectedMail.to} ·{' '}
                        <span className="text-stone-400">Dispatched:</span>{' '}
                        {new Date(selectedMail.sentAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Quick Action Helpers */}
                {selectedMail.type === 'verification' && (
                  <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs text-emerald-800">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Ready to test verification link?</span>
                    </div>
                    <button
                      onClick={() => {
                        const match = selectedMail.text.match(/http[^\s]+/);
                        if (match && onNavigateToUrl) {
                          onClose();
                          onNavigateToUrl(match[0]);
                        }
                      }}
                      className="text-xs font-semibold px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md flex items-center gap-1 transition-colors"
                    >
                      Verify Account Now <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                )}

                {selectedMail.type === 'reset_password' && (
                  <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs text-amber-800">
                      <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>Password reset link detected</span>
                    </div>
                    <button
                      onClick={() => {
                        const match = selectedMail.text.match(/http[^\s]+/);
                        if (match && onNavigateToUrl) {
                          onClose();
                          onNavigateToUrl(match[0]);
                        }
                      }}
                      className="text-xs font-semibold px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-md flex items-center gap-1 transition-colors"
                    >
                      Reset Password Now <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                )}

                {/* Render HTML content safely */}
                <div
                  className="prose prose-sm max-w-none text-stone-800"
                  dangerouslySetInnerHTML={{ __html: selectedMail.html }}
                />
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-stone-400 text-sm">
                Select an email from the left to view rendered content.
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-stone-100 border-t border-stone-200 flex items-center justify-between text-xs text-stone-500">
          <span>SMTP Transporter: {process.env.SMTP_HOST ? 'Configured' : 'Local Outbox Mode (Auto-Logged)'}</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
