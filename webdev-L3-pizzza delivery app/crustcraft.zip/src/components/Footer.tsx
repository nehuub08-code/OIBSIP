import React from 'react';

interface FooterProps {
  onNavigate: (path: string) => void;
  onOpenOutbox: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenOutbox }) => {
  return (
    <footer className="bg-stone-900 text-stone-300 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          <div className="md:col-span-2 space-y-3">
            <span className="text-xl font-bold font-display text-white tracking-tight">CrustCraft</span>
            <p className="text-sm text-stone-400 max-w-sm">
              Artisanal stone-baked pizzas, hand-stretched slow fermented dough, and custom creations built to your exact specifications.
            </p>
            <div className="text-xs text-stone-400 pt-2">
              <span>Task 1: Oasis Infobyte Web Development Internship Project</span>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-stone-400 mb-3">Kitchen & Menu</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => onNavigate('/menu')} className="hover:text-white transition-colors">
                  Signature Pizzas
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/builder')} className="hover:text-white transition-colors">
                  Custom Pizza Builder
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/orders')} className="hover:text-white transition-colors">
                  Live Order Tracker
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-stone-400 mb-3">Operations & Tools</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => onNavigate('/admin')} className="hover:text-white transition-colors">
                  Admin Kitchen Portal
                </button>
              </li>
              <li>
                <button onClick={onOpenOutbox} className="hover:text-white transition-colors">
                  Simulated Mail Outbox
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/admin/login')} className="hover:text-white transition-colors">
                  Admin Sign In
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-stone-800 pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-400 gap-4">
          <p>© {new Date().getFullYear()} CrustCraft Pizza Co. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span>Razorpay Sandbox Integration</span>
            <span aria-hidden="true">·</span>
            <span>Node-Cron Inventory Auditing</span>
            <span aria-hidden="true">·</span>
            <span>JWT & Bcrypt Security</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
