import React, { createContext, useContext, useState, useEffect } from 'react';
import { OrderItem } from '../types/index.js';

interface CartContextType {
  items: OrderItem[];
  addToCart: (item: OrderItem) => void;
  removeFromCart: (itemId: string) => void;
  updateQuantity: (itemId: string, delta: number) => void;
  clearCart: () => void;
  itemCount: number;
  subtotal: number;
  deliveryFee: number;
  tax: number;
  total: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<OrderItem[]>(() => {
    try {
      const saved = localStorage.getItem('crustcraft_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('crustcraft_cart', JSON.stringify(items));
    } catch {
      // Ignore
    }
  }, [items]);

  const addToCart = (newItem: OrderItem) => {
    setItems((prev) => {
      // Check if duplicate signature item exists
      if (!newItem.isCustom) {
        const existingIndex = prev.findIndex(i => !i.isCustom && i.id === newItem.id);
        if (existingIndex > -1) {
          const updated = [...prev];
          const curr = updated[existingIndex];
          const nextQty = curr.quantity + newItem.quantity;
          updated[existingIndex] = {
            ...curr,
            quantity: nextQty,
            totalPrice: curr.unitPrice * nextQty
          };
          return updated;
        }
      }
      return [...prev, newItem];
    });
  };

  const removeFromCart = (itemId: string) => {
    setItems(prev => prev.filter(i => i.id !== itemId));
  };

  const updateQuantity = (itemId: string, delta: number) => {
    setItems((prev) => {
      return prev
        .map((i) => {
          if (i.id === itemId) {
            const nextQty = i.quantity + delta;
            if (nextQty <= 0) return null;
            return {
              ...i,
              quantity: nextQty,
              totalPrice: i.unitPrice * nextQty
            };
          }
          return i;
        })
        .filter(Boolean) as OrderItem[];
    });
  };

  const clearCart = () => {
    setItems([]);
    localStorage.removeItem('crustcraft_cart');
  };

  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce((sum, item) => sum + item.totalPrice, 0);
  const deliveryFee = subtotal > 600 || subtotal === 0 ? 0 : 50;
  const tax = Math.round(subtotal * 0.05); // 5% GST
  const total = subtotal + deliveryFee + tax;

  return (
    <CartContext.Provider
      value={{
        items,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        itemCount,
        subtotal,
        deliveryFee,
        tax,
        total
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
