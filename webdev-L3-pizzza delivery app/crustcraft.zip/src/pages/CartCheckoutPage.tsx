import React, { useState } from 'react';
import { Trash2, Plus, Minus, ArrowRight, ShieldCheck, MapPin, Phone, AlertCircle, ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext.js';
import { useAuth } from '../context/AuthContext.js';

interface CartCheckoutPageProps {
  onNavigate: (path: string) => void;
  onOrderCreated: (orderId: string) => void;
}

export const CartCheckoutPage: React.FC<CartCheckoutPageProps> = ({
  onNavigate,
  onOrderCreated
}) => {
  const { items, updateQuantity, removeFromCart, subtotal, deliveryFee, tax, total, clearCart } = useCart();
  const { user, token } = useAuth();

  const [street, setStreet] = useState('42 Gourmet Avenue, Artisanal Quarter');
  const [city, setCity] = useState('Mumbai');
  const [postalCode, setPostalCode] = useState('400001');
  const [phone, setPhone] = useState('9876543210');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !token) {
      onNavigate('/login');
      return;
    }

    if (!user.isVerified) {
      setErrorMessage('Please verify your email address before placing an order. Check the Mail Outbox to verify.');
      return;
    }

    if (items.length === 0) return;

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          items,
          customerPhone: phone,
          deliveryAddress: {
            street,
            city,
            state: 'Maharashtra',
            postalCode
          }
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to initialize order.');
      }

      // Order created successfully!
      clearCart();
      onOrderCreated(data.order.id);
      onNavigate(`/payment?orderId=${data.order.id}`);
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-6 py-20 text-center">
        <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center mx-auto mb-4 text-stone-400">
          <ShoppingBag className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold font-display text-stone-900">Your Bag is Empty</h2>
        <p className="text-sm text-stone-500 mt-2 max-w-sm mx-auto">
          Add one of our signature pizzas or create your own custom masterpiece in the pizza builder.
        </p>
        <div className="mt-6 flex justify-center gap-3">
          <button
            onClick={() => onNavigate('/builder')}
            className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-xl transition-colors"
          >
            Launch Pizza Builder
          </button>
          <button
            onClick={() => onNavigate('/menu')}
            className="px-5 py-2.5 bg-white border border-stone-200 hover:bg-stone-50 text-stone-800 text-xs font-semibold rounded-xl transition-colors"
          >
            View Menu
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      <div className="border-b border-stone-200 pb-4 mb-8">
        <span className="text-xs font-semibold uppercase tracking-wider text-rose-600">Review & Order</span>
        <h1 className="text-3xl font-bold font-display text-stone-900 tracking-tight mt-0.5">
          Order Summary & Checkout
        </h1>
      </div>

      {errorMessage && (
        <div className="mb-6 p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left Column: Item List */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-2xs divide-y divide-stone-100">
            {items.map((item) => (
              <div key={item.id} className="py-4 first:pt-0 last:pb-0 flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-stone-900">{item.name}</h4>
                    {item.isCustom && (
                      <span className="text-[10px] bg-rose-50 text-rose-700 px-1.5 py-0.5 rounded font-semibold">
                        Custom
                      </span>
                    )}
                  </div>

                  {item.isCustom && item.customConfig ? (
                    <div className="text-[11px] text-stone-500 space-y-0.5">
                      <p>
                        <strong className="text-stone-700">Base:</strong> {item.customConfig.baseName} ·{' '}
                        <strong className="text-stone-700">Sauce:</strong> {item.customConfig.sauceName}
                      </p>
                      <p>
                        <strong className="text-stone-700">Cheese:</strong> {item.customConfig.cheeseName}
                      </p>
                      {item.customConfig.vegetableNames.length > 0 && (
                        <p>
                          <strong className="text-stone-700">Veggies:</strong>{' '}
                          {item.customConfig.vegetableNames.join(', ')}
                        </p>
                      )}
                    </div>
                  ) : null}

                  <p className="text-xs font-mono tabular-nums text-stone-600">
                    ₹{item.unitPrice} each
                  </p>
                </div>

                <div className="flex items-center gap-4 shrink-0">
                  {/* Quantity Stepper */}
                  <div className="flex items-center border border-stone-200 rounded-lg overflow-hidden bg-stone-50">
                    <button
                      onClick={() => updateQuantity(item.id, -1)}
                      className="p-1.5 text-stone-600 hover:bg-stone-200 transition-colors"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="px-2.5 text-xs font-bold font-mono tabular-nums text-stone-900">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(item.id, 1)}
                      className="p-1.5 text-stone-600 hover:bg-stone-200 transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <span className="text-sm font-bold font-mono tabular-nums text-stone-900 w-16 text-right">
                    ₹{item.totalPrice}
                  </span>

                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="p-1.5 text-stone-400 hover:text-rose-600 transition-colors"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center justify-between">
            <span className="font-semibold">Free Express Hot Delivery on orders above ₹600!</span>
            <span className="tabular-nums font-mono text-[11px]">
              {subtotal > 600 ? 'Unlocked!' : `Add ₹${600 - subtotal} more`}
            </span>
          </div>
        </div>

        {/* Right Column: Address & Bill Breakdown */}
        <div className="lg:col-span-5 space-y-6">
          <form onSubmit={handleCheckout} className="bg-white border border-stone-200 rounded-2xl p-6 shadow-2xs space-y-6">
            <div>
              <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2 mb-3">
                <MapPin className="w-4 h-4 text-rose-600" />
                <span>Delivery Address & Contact</span>
              </h3>

              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] font-semibold text-stone-500 uppercase">Street Address</label>
                  <input
                    type="text"
                    required
                    value={street}
                    onChange={(e) => setStreet(e.target.value)}
                    className="w-full mt-1 px-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                    placeholder="e.g. 12 Baker Street"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-500 uppercase">City</label>
                    <input
                      type="text"
                      required
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full mt-1 px-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-500 uppercase">Postal Code</label>
                    <input
                      type="text"
                      required
                      value={postalCode}
                      onChange={(e) => setPostalCode(e.target.value)}
                      className="w-full mt-1 px-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-stone-500 uppercase">Contact Phone</label>
                  <div className="relative mt-1">
                    <Phone className="w-3.5 h-3.5 absolute left-3 top-2.5 text-stone-400" />
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full pl-8 pr-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                      placeholder="10 digit phone number"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Bill Details */}
            <div className="border-t border-stone-100 pt-4 space-y-2 text-xs">
              <h4 className="font-bold text-stone-900 mb-2">Price Breakdown</h4>
              <div className="flex justify-between text-stone-600">
                <span>Subtotal</span>
                <span className="font-mono tabular-nums font-semibold text-stone-900">₹{subtotal}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Delivery Charges</span>
                <span className="font-mono tabular-nums text-stone-900">
                  {deliveryFee === 0 ? <span className="text-emerald-600 font-semibold">FREE</span> : `₹${deliveryFee}`}
                </span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Taxes & GST (5%)</span>
                <span className="font-mono tabular-nums text-stone-900">₹{tax}</span>
              </div>
              <div className="border-t border-stone-200 pt-2 flex justify-between text-base font-bold text-stone-900">
                <span>Total Payable</span>
                <span className="font-mono tabular-nums text-rose-600">₹{total}</span>
              </div>
            </div>

            {/* Authentication check notice */}
            {!user ? (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800">
                You will be asked to sign in or create an account to place and track your order.
              </div>
            ) : !user.isVerified ? (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
                Your account is pending email verification. Click the Mail Outbox icon in the header to activate!
              </div>
            ) : null}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 bg-rose-600 hover:bg-rose-700 disabled:bg-stone-300 text-white font-semibold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
            >
              <span>{isSubmitting ? 'Creating Order...' : 'Proceed to Payment (Razorpay)'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
