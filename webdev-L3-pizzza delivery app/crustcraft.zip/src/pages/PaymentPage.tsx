import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { ShieldCheck, CreditCard, CheckCircle2, AlertTriangle, ArrowRight, RefreshCw, Lock } from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { Order } from '../types/index.js';

interface PaymentPageProps {
  orderId: string;
  onNavigate: (path: string) => void;
}

export const PaymentPage: React.FC<PaymentPageProps> = ({ orderId, onNavigate }) => {
  const { token } = useAuth();
  const effectiveOrderId = orderId || new URLSearchParams(window.location.search).get('orderId') || '';
  const [order, setOrder] = useState<Order | null>(null);
  const [rzpData, setRzpData] = useState<{
    razorpayOrderId: string;
    amount: number;
    currency: string;
    keyId: string;
    isMockMode: boolean;
  } | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Simulated Test Card Fields
  const [cardNumber, setCardNumber] = useState('4111 2222 3333 4444');
  const [expiry, setExpiry] = useState('12/28');
  const [cvv, setCvv] = useState('999');

  // Load order details & create Razorpay order
  useEffect(() => {
    if (!effectiveOrderId) {
      setIsLoading(false);
      setErrorMessage('No Order ID found. Please create an order first.');
      return;
    }
    if (!token) return;

    setIsLoading(true);
    // 1. Fetch current order
    fetch(`/api/orders/${effectiveOrderId}/track`, {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(async (ordData) => {
        if (ordData.error) throw new Error(ordData.error);
        setOrder(ordData);

        if (ordData.paymentStatus === 'paid') {
          setPaymentSuccess(true);
          setIsLoading(false);
          return;
        }

        // 2. Initialize Razorpay order on backend
        const rzpRes = await fetch('/api/payment/create-order', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify({ orderId: ordData.id })
        });
        const rzpOrderData = await rzpRes.json();
        if (rzpRes.ok) {
          setRzpData(rzpOrderData);
        } else {
          throw new Error(rzpOrderData.error || 'Failed to initiate Razorpay order.');
        }
      })
      .catch(err => setErrorMessage(err.message))
      .finally(() => setIsLoading(false));
  }, [effectiveOrderId, token]);

  const handleCompletePayment = async (status: 'success' | 'fail' = 'success') => {
    if (!order || !rzpData || !token) return;

    if (status === 'fail') {
      setErrorMessage('Sandbox payment failed or was declined by issuing test bank.');
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);

    try {
      // Deterministic sandbox payment ID
      const paymentId = `pay_${Date.now().toString().slice(-8)}_${Math.random().toString(36).substring(2, 6)}`;

      // Generate HMAC SHA256 signature
      const sigRes = await fetch('/api/payment/simulate-test-signature', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          razorpayOrderId: rzpData.razorpayOrderId,
          razorpayPaymentId: paymentId
        })
      });
      const sigData = await sigRes.json();
      const razorpaySignature = sigData.signature;

      // Send to server verification endpoint
      const verifyRes = await fetch('/api/payment/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          orderId: order.id,
          razorpayOrderId: rzpData.razorpayOrderId,
          razorpayPaymentId: paymentId,
          razorpaySignature
        })
      });

      const verifyData = await verifyRes.json();

      if (!verifyRes.ok) {
        throw new Error(verifyData.error || 'Payment signature verification failed.');
      }

      // Success! Fire confetti
      setPaymentSuccess(true);
      confetti({
        particleCount: 120,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (err: any) {
      setErrorMessage(err.message || 'Payment processing failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-xl mx-auto px-6 py-24 text-center">
        <RefreshCw className="w-8 h-8 mx-auto animate-spin text-rose-600 mb-4" />
        <p className="text-sm text-stone-600 font-medium">Securing Razorpay Checkout Session...</p>
      </div>
    );
  }

  if (paymentSuccess) {
    return (
      <div className="max-w-xl mx-auto px-6 py-16 text-center animate-in fade-in duration-300">
        <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
          <CheckCircle2 className="w-8 h-8" />
        </div>

        <span className="text-xs font-semibold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
          Payment Verified & Confirmed
        </span>

        <h1 className="text-3xl font-bold font-display text-stone-900 tracking-tight mt-4">
          Your Order is in the Kitchen!
        </h1>

        <p className="text-sm text-stone-600 mt-2 max-w-md mx-auto leading-relaxed">
          Order <strong>#{effectiveOrderId || order?.id}</strong> has been transferred to our pizzaiolos. Sourdough crusts are being stretched and stone-baked.
        </p>

        <div className="mt-6 p-4 bg-white border border-stone-200 rounded-2xl max-w-sm mx-auto text-left text-xs space-y-1.5 shadow-2xs">
          <div className="flex justify-between">
            <span className="text-stone-500">Order Reference:</span>
            <span className="font-mono font-bold text-stone-900">#{effectiveOrderId || order?.id}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone-500">Amount Paid:</span>
            <span className="font-mono font-bold text-stone-900">₹{order?.totalAmount}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone-500">Stock Status:</span>
            <span className="text-emerald-700 font-semibold">Reserved & Deducted</span>
          </div>
        </div>

        <div className="mt-8 flex justify-center gap-4">
          <button
            onClick={() => onNavigate(`/track?orderId=${orderId}`)}
            className="px-6 py-3 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-xl transition-all shadow-md flex items-center gap-2"
          >
            <span>Live Order Tracking</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-6 py-10">
      <div className="border-b border-stone-200 pb-4 mb-6">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-rose-600">
          <Lock className="w-3.5 h-3.5" />
          <span>Razorpay Test Sandbox</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900 tracking-tight mt-1">
          Complete Your Order Payment
        </h1>
      </div>

      {/* Test Mode Notice Banner */}
      <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-3">
        <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
        <div>
          <p className="font-bold">Razorpay Test Mode / Sandbox Simulation</p>
          <p className="text-[11px] text-amber-800 mt-0.5">
            This application uses official Razorpay test integration. No real bank accounts or funds will be debited. The payment signature is verified using HMAC SHA256 server-side.
          </p>
        </div>
      </div>

      {errorMessage && (
        <div className="mb-6 p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700">
          {errorMessage}
        </div>
      )}

      {/* Payment Box */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
        {/* Order Details Banner */}
        <div className="flex items-center justify-between p-4 bg-stone-50 border border-stone-100 rounded-xl">
          <div>
            <p className="text-xs text-stone-500">Order Reference</p>
            <p className="text-sm font-bold font-mono text-stone-900">#{orderId}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-stone-500">Total Amount</p>
            <p className="text-xl font-bold font-mono tabular-nums text-rose-600">
              ₹{order?.totalAmount}
            </p>
          </div>
        </div>

        {/* Test Card Simulator Form */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700 flex items-center gap-1.5">
              <CreditCard className="w-4 h-4 text-stone-500" />
              <span>Simulated Sandbox Card</span>
            </h4>
            <span className="text-[10px] text-stone-400">Razorpay Test Credentials</span>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-stone-500 uppercase">Card Number</label>
            <input
              type="text"
              value={cardNumber}
              onChange={(e) => setCardNumber(e.target.value)}
              className="w-full mt-1 px-3 py-2 text-xs font-mono border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-stone-500 uppercase">Expiry (MM/YY)</label>
              <input
                type="text"
                value={expiry}
                onChange={(e) => setExpiry(e.target.value)}
                className="w-full mt-1 px-3 py-2 text-xs font-mono border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-stone-500 uppercase">CVV</label>
              <input
                type="password"
                value={cvv}
                onChange={(e) => setCvv(e.target.value)}
                className="w-full mt-1 px-3 py-2 text-xs font-mono border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
              />
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="pt-4 border-t border-stone-100 space-y-3">
          <button
            onClick={() => handleCompletePayment('success')}
            disabled={isProcessing}
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-stone-300 text-white font-semibold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
          >
            {isProcessing ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <ShieldCheck className="w-4 h-4" />
            )}
            <span>
              {isProcessing
                ? 'Verifying Razorpay Signature...'
                : `Pay ₹${order?.totalAmount} (Simulate Success)`}
            </span>
          </button>

          <button
            onClick={() => handleCompletePayment('fail')}
            disabled={isProcessing}
            className="w-full py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-medium rounded-lg transition-colors"
          >
            Simulate Payment Failure / Cancellation
          </button>
        </div>
      </div>
    </div>
  );
};
