import React, { useState, useEffect } from 'react';
import {
  Package,
  Plus,
  RefreshCw,
  Search,
  Filter,
  AlertTriangle,
  CheckCircle2,
  Edit2,
  History,
  X,
  ArrowUpDown
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { InventoryItem, IngredientCategory, StockAdjustmentLog } from '../../types/index.js';

interface AdminInventoryPageProps {
  onNavigate: (path: string) => void;
}

export const AdminInventoryPage: React.FC<AdminInventoryPageProps> = ({ onNavigate }) => {
  const { token } = useAuth();
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [stockLogs, setStockLogs] = useState<StockAdjustmentLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [onlyLowStock, setOnlyLowStock] = useState(false);

  // Modals
  const [selectedAdjustItem, setSelectedAdjustItem] = useState<InventoryItem | null>(null);
  const [newStockQty, setNewStockQty] = useState<number>(0);
  const [adjustReason, setAdjustReason] = useState('Supplier Restock Delivery');
  const [isAdjusting, setIsAdjusting] = useState(false);

  const [selectedEditItem, setSelectedEditItem] = useState<InventoryItem | null>(null);
  const [editThreshold, setEditThreshold] = useState<number>(20);
  const [editCustomerPrice, setEditCustomerPrice] = useState<number>(40);
  const [isEditing, setIsEditing] = useState(false);

  const [showAddModal, setShowAddModal] = useState(false);
  const [addName, setAddName] = useState('');
  const [addCategory, setAddCategory] = useState<IngredientCategory>('vegetable');
  const [addQty, setAddQty] = useState(50);
  const [addUnit, setAddUnit] = useState('servings');
  const [addThreshold, setAddThreshold] = useState(20);
  const [addCustomerPrice, setAddCustomerPrice] = useState(40);
  const [isAdding, setIsAdding] = useState(false);

  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const fetchInventory = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/admin/inventory', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setInventory(data.inventory);
        setStockLogs(data.stockLogs || []);
      }
    } catch (err) {
      console.error('Error fetching inventory:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchInventory();
  }, [token]);

  // Adjust stock
  const handleStockAdjustSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAdjustItem || !token) return;

    if (newStockQty < 0) {
      setFeedback({ type: 'error', message: 'Quantity cannot be negative.' });
      return;
    }

    setIsAdjusting(true);
    setFeedback(null);

    try {
      const res = await fetch(`/api/admin/inventory/${selectedAdjustItem.id}/adjust`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          newQuantity: newStockQty,
          reason: adjustReason
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to adjust stock.');

      setFeedback({ type: 'success', message: `Stock for ${selectedAdjustItem.name} updated to ${newStockQty} ${selectedAdjustItem.unit}.` });
      setSelectedAdjustItem(null);
      fetchInventory();
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message });
    } finally {
      setIsAdjusting(false);
    }
  };

  // Edit threshold & price
  const handleEditItemSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEditItem || !token) return;

    setIsEditing(true);
    setFeedback(null);

    try {
      const res = await fetch(`/api/admin/inventory/${selectedEditItem.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          lowStockThreshold: editThreshold,
          customerPrice: editCustomerPrice
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update item settings.');

      setFeedback({ type: 'success', message: `Updated settings for ${selectedEditItem.name}.` });
      setSelectedEditItem(null);
      fetchInventory();
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message });
    } finally {
      setIsEditing(false);
    }
  };

  // Add Item
  const handleAddItemSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;

    setIsAdding(true);
    setFeedback(null);

    try {
      const res = await fetch('/api/admin/inventory', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name: addName,
          category: addCategory,
          availableQuantity: addQty,
          unit: addUnit,
          lowStockThreshold: addThreshold,
          customerPrice: addCustomerPrice
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to add item.');

      setFeedback({ type: 'success', message: `Added new ingredient: ${addName}` });
      setShowAddModal(false);
      setAddName('');
      fetchInventory();
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message });
    } finally {
      setIsAdding(false);
    }
  };

  // Filtered List
  const filteredItems = inventory.filter((item) => {
    if (activeCategory !== 'all' && item.category !== activeCategory) return false;
    if (onlyLowStock && item.availableQuantity >= item.lowStockThreshold) return false;
    if (searchQuery.trim() && !item.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-200 pb-6">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-rose-600">
            Operations Console
          </span>
          <h1 className="text-3xl font-bold font-display text-stone-900 tracking-tight mt-0.5">
            Inventory & Ingredient Stock
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Maintain bases, sauces, cheeses, and toppings with safe stock controls
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchInventory}
            className="p-2 text-stone-600 hover:text-stone-900 bg-white border border-stone-200 rounded-lg"
            title="Refresh"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Ingredient</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`p-3.5 rounded-xl text-xs flex items-center justify-between ${
            feedback.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-600" />
            )}
            <span>{feedback.message}</span>
          </div>
          <button onClick={() => setFeedback(null)}>
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-2xs flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Categories */}
        <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg overflow-x-auto w-full md:w-auto">
          {[
            { id: 'all', label: 'All Items' },
            { id: 'base', label: 'Bases' },
            { id: 'sauce', label: 'Sauces' },
            { id: 'cheese', label: 'Cheeses' },
            { id: 'vegetable', label: 'Vegetables' }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                activeCategory === cat.id
                  ? 'bg-white text-stone-900 shadow-2xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Search & Low-Stock Toggle */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          <div className="relative w-full md:w-60">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-stone-400" />
            <input
              type="text"
              placeholder="Search ingredient..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
            />
          </div>

          <label className="flex items-center gap-2 text-xs text-stone-700 font-medium whitespace-nowrap cursor-pointer">
            <input
              type="checkbox"
              checked={onlyLowStock}
              onChange={(e) => setOnlyLowStock(e.target.checked)}
              className="rounded text-rose-600 focus:ring-rose-500"
            />
            <span>Deficit / Low Stock Only</span>
          </label>
        </div>
      </div>

      {/* Inventory Table */}
      <div className="bg-white border border-stone-200 rounded-2xl shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-stone-200 bg-stone-50/80 text-stone-500 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">Ingredient</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Stock Level</th>
                <th className="py-3 px-4">Alert Threshold</th>
                <th className="py-3 px-4">Customer Price</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredItems.map((item) => {
                const isUnder = item.availableQuantity < item.lowStockThreshold;
                const isOut = item.availableQuantity <= 0;
                return (
                  <tr key={item.id} className="hover:bg-stone-50/60 transition-colors">
                    <td className="py-3.5 px-4">
                      <p className="font-bold text-stone-900">{item.name}</p>
                      <p className="text-[11px] text-stone-400 font-mono">ID: {item.id}</p>
                    </td>
                    <td className="py-3.5 px-4 text-stone-600 capitalize">{item.category}</td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`font-mono tabular-nums font-bold text-sm ${
                          isOut ? 'text-stone-400' : isUnder ? 'text-rose-600' : 'text-stone-900'
                        }`}
                      >
                        {item.availableQuantity}
                      </span>{' '}
                      <span className="text-[11px] text-stone-500">{item.unit}</span>
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums text-stone-600">
                      {item.lowStockThreshold} {item.unit}
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums font-medium text-stone-900">
                      ₹{item.customerPrice}
                    </td>
                    <td className="py-3.5 px-4">
                      {isOut ? (
                        <span className="text-[10px] font-semibold text-stone-700 bg-stone-100 px-2 py-0.5 rounded-full">
                          Depleted
                        </span>
                      ) : isUnder ? (
                        <span className="text-[10px] font-semibold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-full">
                          Below Threshold
                        </span>
                      ) : (
                        <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                          Adequate
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => {
                          setSelectedAdjustItem(item);
                          setNewStockQty(item.availableQuantity);
                          setAdjustReason('Supplier Restock Delivery');
                        }}
                        className="px-2.5 py-1 text-xs font-semibold text-stone-800 bg-stone-100 hover:bg-stone-200 rounded-md transition-colors"
                      >
                        Adjust Stock
                      </button>
                      <button
                        onClick={() => {
                          setSelectedEditItem(item);
                          setEditThreshold(item.lowStockThreshold);
                          setEditCustomerPrice(item.customerPrice);
                        }}
                        className="px-2 py-1 text-xs text-stone-500 hover:text-stone-900 transition-colors"
                        title="Edit threshold and pricing"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Stock Adjustment Audit Logs */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-2xs space-y-4">
        <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
          <History className="w-4 h-4 text-stone-500" />
          <span>Stock Adjustment & Deduction Audit Log</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-stone-200 text-stone-400 uppercase text-[10px]">
                <th className="py-2 px-3">Timestamp</th>
                <th className="py-2 px-3">Item</th>
                <th className="py-2 px-3">Delta</th>
                <th className="py-2 px-3">Before → After</th>
                <th className="py-2 px-3">Reason / Context</th>
                <th className="py-2 px-3">Author</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 font-mono text-[11px]">
              {stockLogs.slice(0, 15).map((log) => (
                <tr key={log.id} className="hover:bg-stone-50">
                  <td className="py-2 px-3 text-stone-500">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="py-2 px-3 font-bold font-sans text-stone-900">{log.itemName}</td>
                  <td className={`py-2 px-3 font-bold tabular-nums ${log.change > 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {log.change > 0 ? `+${log.change}` : log.change}
                  </td>
                  <td className="py-2 px-3 text-stone-600 tabular-nums">
                    {log.previousQuantity} → {log.newQuantity}
                  </td>
                  <td className="py-2 px-3 font-sans text-stone-700">{log.reason}</td>
                  <td className="py-2 px-3 text-stone-500">{log.adjustedBy.split('@')[0]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: Adjust Stock */}
      {selectedAdjustItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 p-4">
          <div className="bg-white border border-stone-200 w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-stone-900">Adjust Available Stock</h3>
                <p className="text-xs text-stone-500">{selectedAdjustItem.name} ({selectedAdjustItem.unit})</p>
              </div>
              <button onClick={() => setSelectedAdjustItem(null)} className="text-stone-400 hover:text-stone-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleStockAdjustSubmit} className="space-y-4">
              <div>
                <label className="block text-[11px] font-semibold text-stone-500 uppercase">
                  New Quantity Available ({selectedAdjustItem.unit})
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  value={newStockQty}
                  onChange={(e) => setNewStockQty(parseInt(e.target.value, 10) || 0)}
                  className="w-full mt-1 px-3 py-2 text-sm font-mono border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-stone-500 uppercase">
                  Reason for Adjustment (Audit Logged)
                </label>
                <input
                  type="text"
                  required
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  className="w-full mt-1 px-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                  placeholder="e.g. Supplier Restock Delivery, Batch Expiry, Inventory Count"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedAdjustItem(null)}
                  className="px-4 py-2 text-xs font-semibold text-stone-600 bg-stone-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isAdjusting}
                  className="px-5 py-2 text-xs font-semibold text-white bg-stone-900 hover:bg-stone-800 rounded-lg"
                >
                  {isAdjusting ? 'Saving...' : 'Commit Stock'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Edit Item Settings */}
      {selectedEditItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 p-4">
          <div className="bg-white border border-stone-200 w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-stone-900">Edit Ingredient Threshold & Price</h3>
                <p className="text-xs text-stone-500">{selectedEditItem.name}</p>
              </div>
              <button onClick={() => setSelectedEditItem(null)} className="text-stone-400 hover:text-stone-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditItemSubmit} className="space-y-4">
              <div>
                <label className="block text-[11px] font-semibold text-stone-500 uppercase">
                  Low-Stock Notification Threshold ({selectedEditItem.unit})
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={editThreshold}
                  onChange={(e) => setEditThreshold(parseInt(e.target.value, 10) || 1)}
                  className="w-full mt-1 px-3 py-2 text-sm font-mono border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                />
                <p className="text-[11px] text-stone-400 mt-0.5">
                  Automated cron triggers Nodemailer alerts when stock falls below this number.
                </p>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-stone-500 uppercase">
                  Customer Price (₹)
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  value={editCustomerPrice}
                  onChange={(e) => setEditCustomerPrice(parseInt(e.target.value, 10) || 0)}
                  className="w-full mt-1 px-3 py-2 text-sm font-mono border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedEditItem(null)}
                  className="px-4 py-2 text-xs font-semibold text-stone-600 bg-stone-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isEditing}
                  className="px-5 py-2 text-xs font-semibold text-white bg-stone-900 hover:bg-stone-800 rounded-lg"
                >
                  {isEditing ? 'Updating...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Add Ingredient */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 p-4">
          <div className="bg-white border border-stone-200 w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="text-base font-bold text-stone-900">Add New Kitchen Ingredient</h3>
              <button onClick={() => setShowAddModal(false)} className="text-stone-400 hover:text-stone-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddItemSubmit} className="space-y-4">
              <div>
                <label className="block text-[11px] font-semibold text-stone-500 uppercase">Name</label>
                <input
                  type="text"
                  required
                  value={addName}
                  onChange={(e) => setAddName(e.target.value)}
                  placeholder="e.g. Buffalo Mozzarella"
                  className="w-full mt-1 px-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-stone-500 uppercase">Category</label>
                  <select
                    value={addCategory}
                    onChange={(e) => setAddCategory(e.target.value as any)}
                    className="w-full mt-1 px-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                  >
                    <option value="base">Base</option>
                    <option value="sauce">Sauce</option>
                    <option value="cheese">Cheese</option>
                    <option value="vegetable">Vegetable</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-stone-500 uppercase">Unit</label>
                  <input
                    type="text"
                    required
                    value={addUnit}
                    onChange={(e) => setAddUnit(e.target.value)}
                    placeholder="servings / dough balls"
                    className="w-full mt-1 px-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-stone-500 uppercase">Initial Qty</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={addQty}
                    onChange={(e) => setAddQty(parseInt(e.target.value, 10) || 0)}
                    className="w-full mt-1 px-3 py-2 text-xs font-mono border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-stone-500 uppercase">Threshold</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={addThreshold}
                    onChange={(e) => setAddThreshold(parseInt(e.target.value, 10) || 1)}
                    className="w-full mt-1 px-3 py-2 text-xs font-mono border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-stone-500 uppercase">Price (₹)</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={addCustomerPrice}
                    onChange={(e) => setAddCustomerPrice(parseInt(e.target.value, 10) || 0)}
                    className="w-full mt-1 px-3 py-2 text-xs font-mono border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-stone-600 bg-stone-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isAdding}
                  className="px-5 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
                >
                  {isAdding ? 'Adding...' : 'Add Ingredient'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
