import React, { useState, useEffect } from 'react';
import {
  ShoppingBag,
  Flame,
  AlertTriangle,
  TrendingUp,
  Clock,
  ArrowRight,
  RefreshCw,
  Bell,
  CheckCircle2,
  Package
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { AdminStats } from '../../types/index.js';

interface AdminDashboardPageProps {
  onNavigate: (path: string) => void;
  onOpenOutbox: () => void;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ onNavigate, onOpenOutbox }) => {
  const { token } = useAuth();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isTriggeringAudit, setIsTriggeringAudit] = useState(false);
  const [auditFeedback, setAuditFeedback] = useState<string | null>(null);

  const fetchStats = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/admin/stats', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
    } catch (err) {
      console.error('Error fetching admin stats:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, [token]);

  const handleTriggerAuditNow = async () => {
    if (!token) return;
    setIsTriggeringAudit(true);
    setAuditFeedback(null);

    try {
      const res = await fetch('/api/admin/trigger-stock-check', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) {
        setAuditFeedback(
          data.alertSent
            ? `Audit executed! Dispatched low-stock email alert for ${data.alertedItems.length} item(s). Check Mail Outbox.`
            : `Audit executed! All items checked (${data.allLowStockItems.length} low stock items, cooldown active).`
        );
        fetchStats();
      }
    } catch (err: any) {
      setAuditFeedback(`Error executing stock check: ${err.message}`);
    } finally {
      setIsTriggeringAudit(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 space-y-10">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-200 pb-6">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-rose-600">
            Kitchen Operations & Telemetry
          </span>
          <h1 className="text-3xl font-bold font-display text-stone-900 tracking-tight mt-0.5">
            Admin Overview & Analytics
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Real-time orders, stock thresholds, and automated inventory notifications
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchStats}
            className="px-3.5 py-2 text-xs font-medium text-stone-700 bg-white border border-stone-200 rounded-lg hover:bg-stone-50 transition-colors flex items-center gap-2"
          >
            <RefreshCw className="w-3.5 h-3.5 text-stone-500" />
            <span>Refresh Telemetry</span>
          </button>
          <button
            onClick={() => onNavigate('/admin/inventory')}
            className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Package className="w-3.5 h-3.5" />
            <span>Manage Inventory</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-2xs">
          <div className="flex items-center justify-between text-stone-400 mb-2">
            <span className="text-[11px] font-semibold uppercase">Total Orders</span>
            <ShoppingBag className="w-4 h-4 text-stone-500" />
          </div>
          <p className="text-2xl font-bold font-mono tabular-nums text-stone-900">
            {stats?.totalOrders ?? 0}
          </p>
        </div>

        <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-2xs">
          <div className="flex items-center justify-between text-stone-400 mb-2">
            <span className="text-[11px] font-semibold uppercase">New Orders</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-2xl font-bold font-mono tabular-nums text-amber-600">
            {stats?.newOrders ?? 0}
          </p>
        </div>

        <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-2xs">
          <div className="flex items-center justify-between text-stone-400 mb-2">
            <span className="text-[11px] font-semibold uppercase">In Kitchen</span>
            <Flame className="w-4 h-4 text-rose-500" />
          </div>
          <p className="text-2xl font-bold font-mono tabular-nums text-rose-600">
            {stats?.inKitchenOrders ?? 0}
          </p>
        </div>

        <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-2xs">
          <div className="flex items-center justify-between text-stone-400 mb-2">
            <span className="text-[11px] font-semibold uppercase">Delivery</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-2xl font-bold font-mono tabular-nums text-emerald-600">
            {(stats?.sentToDeliveryOrders ?? 0) + (stats?.deliveredOrders ?? 0)}
          </p>
        </div>

        <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-2xs">
          <div className="flex items-center justify-between text-stone-400 mb-2">
            <span className="text-[11px] font-semibold uppercase">Low Stock</span>
            <AlertTriangle className="w-4 h-4 text-rose-500" />
          </div>
          <p className="text-2xl font-bold font-mono tabular-nums text-rose-600">
            {stats?.lowStockItemsCount ?? 0}
          </p>
        </div>

        <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-2xs">
          <div className="flex items-center justify-between text-stone-400 mb-2">
            <span className="text-[11px] font-semibold uppercase">Total Revenue</span>
            <TrendingUp className="w-4 h-4 text-stone-500" />
          </div>
          <p className="text-xl font-bold font-mono tabular-nums text-stone-900 truncate">
            ₹{stats?.totalRevenue ?? 0}
          </p>
        </div>
      </div>

      {/* Low-Stock Alerts Panel (Task Requirement #12) */}
      <div className="bg-white border border-rose-200 rounded-3xl p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-rose-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold font-display text-stone-900">
                Low-Stock Threshold Monitoring & Alerts
              </h3>
              <p className="text-xs text-stone-500">
                Monitored by scheduled node-cron job; triggers Nodemailer notification when stock drops below item threshold
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleTriggerAuditNow}
              disabled={isTriggeringAudit}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 disabled:bg-rose-300 text-white text-xs font-semibold rounded-xl transition-all shadow-xs flex items-center gap-2 whitespace-nowrap"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTriggeringAudit ? 'animate-spin' : ''}`} />
              <span>{isTriggeringAudit ? 'Auditing Inventory...' : 'Trigger Stock Audit & Alert Email'}</span>
            </button>
            <button
              onClick={onOpenOutbox}
              className="px-3 py-2 border border-stone-200 hover:bg-stone-50 text-stone-700 text-xs font-medium rounded-xl transition-colors"
              title="Inspect dispatched email alerts"
            >
              View Dispatched Mail
            </button>
          </div>
        </div>

        {auditFeedback && (
          <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{auditFeedback}</span>
          </div>
        )}

        {/* Low Stock Items List */}
        {stats && stats.lowStockItems.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-stone-200 text-stone-400 uppercase tracking-wider text-[10px]">
                  <th className="py-2.5 px-3">Ingredient</th>
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3">Current Stock</th>
                  <th className="py-2.5 px-3">Safety Threshold</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Quick Restock</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {stats.lowStockItems.map((item) => (
                  <tr key={item.id} className="hover:bg-rose-50/30 transition-colors">
                    <td className="py-3 px-3 font-bold text-stone-900">{item.name}</td>
                    <td className="py-3 px-3 text-stone-500 capitalize">{item.category}</td>
                    <td className="py-3 px-3 font-mono font-bold text-rose-600 tabular-nums">
                      {item.availableQuantity} {item.unit}
                    </td>
                    <td className="py-3 px-3 text-stone-600 font-mono tabular-nums">
                      {item.lowStockThreshold} {item.unit}
                    </td>
                    <td className="py-3 px-3">
                      <span className="text-[10px] font-semibold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-full">
                        Deficit: -{item.lowStockThreshold - item.availableQuantity} {item.unit}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => onNavigate('/admin/inventory')}
                        className="text-xs font-semibold text-stone-700 hover:text-stone-900 underline"
                      >
                        Adjust Stock →
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-6 bg-stone-50 border border-stone-200 rounded-2xl text-center text-xs text-stone-500">
            <CheckCircle2 className="w-6 h-6 text-emerald-600 mx-auto mb-2" />
            <p className="font-semibold text-stone-800">Healthy Inventory Levels</p>
            <p className="text-[11px] mt-0.5">All pizza bases, sauces, cheeses, and vegetables are above safety replenishment thresholds.</p>
          </div>
        )}
      </div>

      {/* Quick Access Panels */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Orders Action Card */}
        <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-stone-500" />
              <span>Kitchen Order Queue</span>
            </h3>
            <span className="text-xs font-semibold text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full">
              {stats?.newOrders ?? 0} Pending
            </span>
          </div>
          <p className="text-xs text-stone-500 leading-relaxed">
            Review incoming paid customer orders, update statuses through the kitchen pipeline ("In Kitchen", "Sent to Delivery", "Delivered").
          </p>
          <button
            onClick={() => onNavigate('/admin/orders')}
            className="w-full py-2.5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors"
          >
            <span>Open Order Manager</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Inventory Action Card */}
        <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
              <Package className="w-4 h-4 text-stone-500" />
              <span>Ingredient Stock Controller</span>
            </h3>
            <span className="text-xs font-semibold text-stone-700 bg-stone-100 px-2.5 py-0.5 rounded-full">
              21 Tracked Items
            </span>
          </div>
          <p className="text-xs text-stone-500 leading-relaxed">
            Perform manual restock adjustments with audit reason logging, edit replenishment thresholds, and add new seasonal ingredients.
          </p>
          <button
            onClick={() => onNavigate('/admin/inventory')}
            className="w-full py-2.5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors"
          >
            <span>Open Inventory Manager</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
