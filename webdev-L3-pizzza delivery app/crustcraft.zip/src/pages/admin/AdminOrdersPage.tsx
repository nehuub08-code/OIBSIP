import React, { useState, useEffect } from 'react';
import {
  ShoppingBag,
  RefreshCw,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  ChefHat,
  Bike,
  Eye,
  X,
  CreditCard,
  MapPin,
  Phone
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { Order, OrderStatus } from '../../types/index.js';

interface AdminOrdersPageProps {
  onNavigate: (path: string) => void;
}

export const AdminOrdersPage: React.FC<AdminOrdersPageProps> = ({ onNavigate }) => {
  const { token } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const fetchOrders = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/admin/orders', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setOrders(data);
      }
    } catch (err) {
      console.error('Error fetching admin orders:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
    const interval = setInterval(fetchOrders, 6000);
    return () => clearInterval(interval);
  }, [token]);

  const handleUpdateStatus = async (orderId: string, newStatus: OrderStatus) => {
    if (!token) return;
    setIsUpdatingStatus(true);
    setFeedback(null);

    try {
      const res = await fetch(`/api/admin/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          newStatus,
          note: `Kitchen staff advanced status to ${newStatus}`
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update order status.');

      setFeedback(`Order #${orderId} moved to ${newStatus}.`);
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder(data.order);
      }
      fetchOrders();
    } catch (err: any) {
      setFeedback(`Error: ${err.message}`);
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const filteredOrders = orders.filter((o) => {
    if (selectedStatus !== 'all' && o.orderStatus !== selectedStatus) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        o.id.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        o.customerEmail.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-200 pb-6">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-rose-600">
            Kitchen Management
          </span>
          <h1 className="text-3xl font-bold font-display text-stone-900 tracking-tight mt-0.5">
            Customer Orders & Kitchen Pipeline
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Advance orders: Order Received → In Kitchen → Sent to Delivery → Delivered
          </p>
        </div>

        <button
          onClick={fetchOrders}
          className="px-3.5 py-2 text-xs font-medium text-stone-700 bg-white border border-stone-200 rounded-lg hover:bg-stone-50 transition-colors flex items-center gap-2 self-start md:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Queue</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center justify-between">
          <span>{feedback}</span>
          <button onClick={() => setFeedback(null)}>
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-2xs flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Status segmented buttons */}
        <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg overflow-x-auto w-full md:w-auto">
          {[
            { id: 'all', label: 'All Orders' },
            { id: 'Order Received', label: 'Received' },
            { id: 'In Kitchen', label: 'In Kitchen' },
            { id: 'Sent to Delivery', label: 'Out for Delivery' },
            { id: 'Delivered', label: 'Delivered' }
          ].map((st) => (
            <button
              key={st.id}
              onClick={() => setSelectedStatus(st.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                selectedStatus === st.id
                  ? 'bg-white text-stone-900 shadow-2xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {st.label}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full md:w-72">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-stone-400" />
          <input
            type="text"
            placeholder="Search by order ID, name, email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
          />
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white border border-stone-200 rounded-2xl shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-stone-200 bg-stone-50/80 text-stone-500 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">Order ID & Date</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Items</th>
                <th className="py-3 px-4">Total</th>
                <th className="py-3 px-4">Payment</th>
                <th className="py-3 px-4">Kitchen Status</th>
                <th className="py-3 px-4 text-right">Advance Pipeline</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-stone-400">
                    No orders matching selected criteria.
                  </td>
                </tr>
              ) : (
                filteredOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-stone-50/60 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-stone-900">#{ord.id}</span>
                        <button
                          onClick={() => setSelectedOrder(ord)}
                          className="text-stone-400 hover:text-stone-900"
                          title="View order details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <p className="text-[11px] text-stone-400 font-mono mt-0.5">
                        {new Date(ord.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </td>

                    <td className="py-3.5 px-4">
                      <p className="font-semibold text-stone-900">{ord.customerName}</p>
                      <p className="text-[11px] text-stone-500">{ord.customerPhone}</p>
                    </td>

                    <td className="py-3.5 px-4">
                      <p className="font-medium text-stone-800">
                        {ord.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}
                      </p>
                    </td>

                    <td className="py-3.5 px-4 font-mono font-bold text-stone-900 tabular-nums">
                      ₹{ord.totalAmount}
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                          ord.paymentStatus === 'paid'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {ord.paymentStatus === 'paid' ? 'Paid (Verified)' : 'Pending'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                          ord.orderStatus === 'Delivered'
                            ? 'bg-emerald-50 text-emerald-700'
                            : ord.orderStatus === 'Sent to Delivery'
                            ? 'bg-blue-50 text-blue-700'
                            : ord.orderStatus === 'In Kitchen'
                            ? 'bg-rose-50 text-rose-700'
                            : 'bg-stone-100 text-stone-700'
                        }`}
                      >
                        {ord.orderStatus}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-1.5">
                      {ord.orderStatus === 'Order Received' && (
                        <button
                          onClick={() => handleUpdateStatus(ord.id, 'In Kitchen')}
                          disabled={isUpdatingStatus}
                          className="px-2.5 py-1 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-md transition-colors"
                        >
                          → To Kitchen
                        </button>
                      )}

                      {ord.orderStatus === 'In Kitchen' && (
                        <button
                          onClick={() => handleUpdateStatus(ord.id, 'Sent to Delivery')}
                          disabled={isUpdatingStatus}
                          className="px-2.5 py-1 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-md transition-colors"
                        >
                          → Send to Delivery
                        </button>
                      )}

                      {ord.orderStatus === 'Sent to Delivery' && (
                        <button
                          onClick={() => handleUpdateStatus(ord.id, 'Delivered')}
                          disabled={isUpdatingStatus}
                          className="px-2.5 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-md transition-colors"
                        >
                          ✓ Mark Delivered
                        </button>
                      )}

                      {ord.orderStatus === 'Delivered' && (
                        <span className="text-[11px] text-emerald-600 font-semibold">Completed</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 p-4">
          <div className="bg-white border border-stone-200 w-full max-w-xl max-h-[85vh] rounded-3xl p-6 sm:p-8 shadow-2xl overflow-y-auto space-y-6">
            <div className="flex items-center justify-between border-b border-stone-100 pb-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-rose-600">
                  Kitchen Ticket
                </span>
                <h3 className="text-xl font-bold font-display text-stone-900 mt-0.5">
                  Order #{selectedOrder.id}
                </h3>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Customer & Address Details */}
            <div className="grid grid-cols-2 gap-4 text-xs bg-stone-50 p-4 rounded-xl border border-stone-100">
              <div>
                <span className="text-stone-400 block uppercase text-[10px]">Customer</span>
                <p className="font-bold text-stone-900 mt-0.5">{selectedOrder.customerName}</p>
                <p className="text-stone-500">{selectedOrder.customerEmail}</p>
                <p className="text-stone-500">{selectedOrder.customerPhone}</p>
              </div>
              <div>
                <span className="text-stone-400 block uppercase text-[10px]">Delivery Destination</span>
                <p className="text-stone-800 mt-0.5 leading-relaxed">
                  {selectedOrder.deliveryAddress.street}, {selectedOrder.deliveryAddress.city} -{' '}
                  {selectedOrder.deliveryAddress.postalCode}
                </p>
              </div>
            </div>

            {/* Items & Custom Recipes */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700">
                Pizzaiolo Preparation Specs
              </h4>
              <div className="divide-y divide-stone-100 text-xs border border-stone-200 rounded-xl p-4">
                {selectedOrder.items.map((item, idx) => (
                  <div key={idx} className="py-2.5 first:pt-0 last:pb-0 space-y-1">
                    <div className="flex justify-between font-bold text-stone-900">
                      <span>{item.quantity}x {item.name}</span>
                      <span className="font-mono tabular-nums">₹{item.totalPrice}</span>
                    </div>

                    {item.isCustom && item.customConfig ? (
                      <div className="text-[11px] text-stone-600 bg-rose-50/50 p-2 rounded-lg border border-rose-100 space-y-0.5">
                        <p><strong>Base:</strong> {item.customConfig.baseName}</p>
                        <p><strong>Sauce:</strong> {item.customConfig.sauceName}</p>
                        <p><strong>Cheese:</strong> {item.customConfig.cheeseName}</p>
                        {item.customConfig.vegetableNames.length > 0 && (
                          <p><strong>Vegetables:</strong> {item.customConfig.vegetableNames.join(', ')}</p>
                        )}
                      </div>
                    ) : null}
                  </div>
                ))}
              </div>
            </div>

            {/* Payment & Security Snapshot */}
            <div className="text-xs space-y-2 border-t border-stone-100 pt-4">
              <h4 className="font-bold text-stone-900">Payment & Verification Details</h4>
              <div className="grid grid-cols-2 gap-2 text-stone-600">
                <div>
                  <span className="text-stone-400">Payment Status: </span>
                  <span className="font-semibold text-emerald-700 capitalize">{selectedOrder.paymentStatus}</span>
                </div>
                <div>
                  <span className="text-stone-400">Payment Method: </span>
                  <span className="font-mono text-stone-800">{selectedOrder.paymentMethod}</span>
                </div>
                {selectedOrder.razorpayPaymentId && (
                  <div className="col-span-2 font-mono text-[11px] truncate">
                    <span className="text-stone-400">Razorpay Payment ID: </span>
                    <span className="text-stone-800">{selectedOrder.razorpayPaymentId}</span>
                  </div>
                )}
                {selectedOrder.razorpaySignature && (
                  <div className="col-span-2 font-mono text-[11px] truncate">
                    <span className="text-stone-400">HMAC SHA256 Signature: </span>
                    <span className="text-stone-800">{selectedOrder.razorpaySignature}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Status Transition History Log */}
            <div className="text-xs space-y-2 border-t border-stone-100 pt-4">
              <h4 className="font-bold text-stone-900">Status History Audit</h4>
              <div className="space-y-1 font-mono text-[11px]">
                {selectedOrder.statusHistory.map((h, idx) => (
                  <div key={idx} className="flex justify-between text-stone-600 py-0.5">
                    <span>{h.status}: {h.note || 'Updated'}</span>
                    <span className="text-stone-400">{new Date(h.timestamp).toLocaleTimeString()}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSelectedOrder(null)}
                className="px-5 py-2 text-xs font-semibold text-white bg-stone-900 rounded-lg hover:bg-stone-800"
              >
                Close Ticket
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
