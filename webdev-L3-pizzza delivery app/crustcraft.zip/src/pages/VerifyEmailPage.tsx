import React, { useState, useEffect } from 'react';
import { CheckCircle2, AlertCircle, RefreshCw, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';

interface VerifyEmailPageProps {
  onNavigate: (path: string) => void;
  tokenParam?: string;
}

export const VerifyEmailPage: React.FC<VerifyEmailPageProps> = ({ onNavigate, tokenParam }) => {
  const { login } = useAuth();
  const [status, setStatus] = useState<'verifying' | 'success' | 'error'>('verifying');
  const [message, setMessage] = useState('Verifying your email address...');

  useEffect(() => {
    // Read token from query or prop
    const params = new URLSearchParams(window.location.search);
    const token = tokenParam || params.get('token');

    if (!token) {
      setStatus('error');
      setMessage('No verification token found in URL.');
      return;
    }

    fetch(`/api/auth/verify-email?token=${token}`)
      .then(res => res.json().then(data => ({ ok: res.ok, data })))
      .then(({ ok, data }) => {
        if (!ok) {
          setStatus('error');
          setMessage(data.error || 'Verification failed or expired.');
        } else {
          setStatus('success');
          setMessage(data.message || 'Email successfully verified!');
          if (data.token && data.user) {
            login(data.token, data.user);
          }
        }
      })
      .catch((err) => {
        setStatus('error');
        setMessage(err.message || 'Error communicating with server.');
      });
  }, [tokenParam]);

  return (
    <div className="max-w-md mx-auto px-6 py-20 text-center">
      <div className="bg-white border border-stone-200 rounded-3xl p-8 shadow-xs space-y-6">
        {status === 'verifying' && (
          <div className="space-y-4">
            <RefreshCw className="w-10 h-10 text-rose-600 animate-spin mx-auto" />
            <h2 className="text-xl font-bold font-display text-stone-900">Verifying Account...</h2>
            <p className="text-xs text-stone-500">{message}</p>
          </div>
        )}

        {status === 'success' && (
          <div className="space-y-4">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold font-display text-stone-900">Account Verified!</h2>
            <p className="text-xs text-stone-600 leading-relaxed">{message}</p>
            <div className="pt-2">
              <button
                onClick={() => onNavigate('/builder')}
                className="w-full py-3 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
              >
                <span>Start Custom Pizza</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {status === 'error' && (
          <div className="space-y-4">
            <div className="w-14 h-14 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto">
              <AlertCircle className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold font-display text-stone-900">Verification Failed</h2>
            <p className="text-xs text-rose-700 leading-relaxed">{message}</p>
            <div className="pt-2 flex flex-col gap-2">
              <button
                onClick={() => onNavigate('/login')}
                className="w-full py-2.5 bg-stone-900 text-white font-semibold text-xs rounded-xl"
              >
                Return to Login
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
