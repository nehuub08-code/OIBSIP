import React, { useState, useEffect } from 'react';
import { Clock, ChefHat, Bike, CheckCircle2, AlertCircle, RefreshCw, MapPin } from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { Order, OrderStatus } from '../types/index.js';

interface OrderTrackingPageProps {
  orderId: string;
  onNavigate: (path: string) => void;
}

export const OrderTrackingPage: React.FC<OrderTrackingPageProps> = ({ orderId, onNavigate }) => {
  const { token } = useAuth();
  const effectiveOrderId = orderId || new URLSearchParams(window.location.search).get('orderId') || '';
  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const fetchOrderStatus = async (silent = false) => {
    if (!effectiveOrderId) {
      setIsLoading(false);
      setErrorMessage('No Order ID specified for tracking.');
      return;
    }
    if (!token) return;
    if (!silent) setIsRefreshing(true);

    try {
      const res = await fetch(`/api/orders/${effectiveOrderId}/track`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to retrieve order tracking info.');
      }
      setOrder(data);
    } catch (err: any) {
      setErrorMessage(err.message);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  // Initial fetch and continuous live polling (every 4 seconds)
  useEffect(() => {
    fetchOrderStatus();
    const interval = setInterval(() => {
      fetchOrderStatus(true);
    }, 4000);
    return () => clearInterval(interval);
  }, [effectiveOrderId, token]);

  if (isLoading) {
    return (
      <div className="max-w-xl mx-auto px-6 py-24 text-center">
        <RefreshCw className="w-8 h-8 mx-auto animate-spin text-rose-600 mb-4" />
        <p className="text-sm text-stone-600 font-medium">Connecting to Kitchen Telemetry...</p>
      </div>
    );
  }

  if (errorMessage || !order) {
    return (
      <div className="max-w-xl mx-auto px-6 py-20 text-center">
        <AlertCircle className="w-12 h-12 text-rose-600 mx-auto mb-4" />
        <h2 className="text-xl font-bold font-display text-stone-900">Order Not Accessible</h2>
        <p className="text-xs text-stone-500 mt-2">{errorMessage || 'Order not found.'}</p>
        <button
          onClick={() => onNavigate('/orders')}
          className="mt-6 px-5 py-2.5 bg-stone-900 text-white text-xs font-semibold rounded-xl"
        >
          View My Orders
        </button>
      </div>
    );
  }

  // Required 3 steps (+ Delivered)
  const timelineSteps: Array<{
    status: OrderStatus;
    title: string;
    description: string;
    icon: React.ElementType;
  }> = [
    {
      status: 'Order Received',
      title: 'Order Received',
      description: 'Order confirmed and verified in our kitchen system.',
      icon: Clock
    },
    {
      status: 'In Kitchen',
      title: 'In Kitchen',
      description: 'Dough stretched, ingredients layered, wood-fired at 450°C.',
      icon: ChefHat
    },
    {
      status: 'Sent to Delivery',
      title: 'Sent to Delivery',
      description: 'Boxed in insulated thermal container and out on the road.',
      icon: Bike
    },
    {
      status: 'Delivered',
      title: 'Delivered',
      description: 'Handed over warm and fresh at your doorstep. Buon appetito!',
      icon: CheckCircle2
    }
  ];

  const getStepState = (stepStatus: OrderStatus) => {
    const statusOrder: OrderStatus[] = ['Order Received', 'In Kitchen', 'Sent to Delivery', 'Delivered'];
    const currentIndex = statusOrder.indexOf(order.orderStatus);
    const stepIndex = statusOrder.indexOf(stepStatus);

    if (order.orderStatus === 'Cancelled') return 'cancelled';
    if (stepIndex < currentIndex) return 'completed';
    if (stepIndex === currentIndex) return 'current';
    return 'upcoming';
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-10 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 pb-6">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-rose-600">
            Live Order Status
          </span>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900 tracking-tight mt-0.5">
            Tracking Order #{order.id}
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Placed on {new Date(order.createdAt).toLocaleDateString()} at{' '}
            {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => fetchOrderStatus()}
            className="px-3.5 py-2 text-xs font-medium text-stone-600 bg-white border border-stone-200 rounded-lg hover:bg-stone-50 transition-colors flex items-center gap-2"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Poll Live Status</span>
          </button>
        </div>
      </div>

      {/* Required Timeline Presentation */}
      <div className="bg-white border border-stone-200 rounded-3xl p-6 sm:p-8 shadow-xs">
        <h3 className="text-xs font-bold uppercase tracking-wider text-stone-500 mb-6">
          Order Progress Timeline
        </h3>

        <div className="relative pl-6 sm:pl-8 space-y-8 before:absolute before:left-[17px] sm:before:left-[21px] before:top-3 before:bottom-3 before:w-0.5 before:bg-stone-200">
          {timelineSteps.map((step) => {
            const state = getStepState(step.status);
            const Icon = step.icon;

            // Find transition entry from history
            const historyEntry = order.statusHistory.find(h => h.status === step.status);

            return (
              <div key={step.status} className="relative flex items-start gap-4">
                {/* Node indicator */}
                <div
                  className={`relative -ml-6 sm:-ml-8 w-9 h-9 sm:w-11 sm:h-11 rounded-full flex items-center justify-center border-2 transition-all ${
                    state === 'completed'
                      ? 'bg-emerald-600 border-emerald-600 text-white'
                      : state === 'current'
                      ? 'bg-rose-600 border-rose-600 text-white shadow-md ring-4 ring-rose-100'
                      : 'bg-white border-stone-300 text-stone-400'
                  }`}
                >
                  <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>

                <div className="flex-1 pt-1">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <h4
                      className={`text-sm font-bold ${
                        state === 'current'
                          ? 'text-rose-600'
                          : state === 'completed'
                          ? 'text-stone-900'
                          : 'text-stone-400'
                      }`}
                    >
                      {step.title}
                    </h4>

                    {historyEntry && (
                      <span className="text-[11px] font-mono tabular-nums text-stone-500">
                        {new Date(historyEntry.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                          second: '2-digit'
                        })}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-stone-500 mt-0.5">{step.description}</p>

                  {historyEntry?.note && (
                    <p className="text-[11px] text-stone-600 italic bg-stone-50 p-2 rounded-md mt-1.5 border border-stone-100">
                      "{historyEntry.note}"
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Order Itemized Receipt */}
      <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-2xs space-y-4">
        <h3 className="text-sm font-bold text-stone-900 border-b border-stone-100 pb-3">
          Kitchen Order Summary
        </h3>

        <div className="divide-y divide-stone-100 text-xs">
          {order.items.map((item, idx) => (
            <div key={idx} className="py-3 first:pt-0 last:pb-0 flex justify-between items-start">
              <div>
                <p className="font-bold text-stone-900">
                  {item.quantity}x {item.name}
                </p>
                {item.isCustom && item.customConfig ? (
                  <p className="text-[11px] text-stone-500 mt-0.5">
                    {item.customConfig.baseName} · {item.customConfig.sauceName} ·{' '}
                    {item.customConfig.cheeseName}
                    {item.customConfig.vegetableNames.length > 0 &&
                      ` · ${item.customConfig.vegetableNames.join(', ')}`}
                  </p>
                ) : null}
              </div>
              <span className="font-mono tabular-nums font-semibold text-stone-900">
                ₹{item.totalPrice}
              </span>
            </div>
          ))}
        </div>

        <div className="border-t border-stone-200 pt-3 space-y-1.5 text-xs">
          <div className="flex justify-between text-stone-600">
            <span>Subtotal</span>
            <span className="font-mono tabular-nums">₹{order.subtotal}</span>
          </div>
          <div className="flex justify-between text-stone-600">
            <span>Delivery Fee</span>
            <span className="font-mono tabular-nums">
              {order.deliveryFee === 0 ? 'FREE' : `₹${order.deliveryFee}`}
            </span>
          </div>
          <div className="flex justify-between text-stone-600">
            <span>Tax (5% GST)</span>
            <span className="font-mono tabular-nums">₹{order.tax}</span>
          </div>
          <div className="flex justify-between text-sm font-bold text-stone-900 pt-2 border-t border-stone-100">
            <span>Total Paid</span>
            <span className="font-mono tabular-nums text-rose-600">₹{order.totalAmount}</span>
          </div>
        </div>

        {/* Address */}
        <div className="mt-4 pt-3 border-t border-stone-100 flex items-start gap-2 text-xs text-stone-600">
          <MapPin className="w-4 h-4 text-stone-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-stone-800">Delivering to: </span>
            {order.deliveryAddress.street}, {order.deliveryAddress.city} -{' '}
            {order.deliveryAddress.postalCode}
          </div>
        </div>
      </div>
    </div>
  );
};
