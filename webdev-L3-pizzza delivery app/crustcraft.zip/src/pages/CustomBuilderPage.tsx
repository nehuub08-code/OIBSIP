import React, { useState, useEffect } from 'react';
import { ArrowLeft, ArrowRight, Check, Sparkles, AlertCircle, ShoppingBag } from 'lucide-react';
import { PizzaGraphic } from '../components/PizzaGraphic.js';
import { InventoryItem, CustomPizzaConfig } from '../types/index.js';
import { useCart } from '../context/CartContext.js';

interface CustomBuilderPageProps {
  onNavigate: (path: string) => void;
}

export const CustomBuilderPage: React.FC<CustomBuilderPageProps> = ({ onNavigate }) => {
  const { addToCart } = useCart();

  const [ingredients, setIngredients] = useState<{
    bases: InventoryItem[];
    sauces: InventoryItem[];
    cheeses: InventoryItem[];
    vegetables: InventoryItem[];
  }>({
    bases: [],
    sauces: [],
    cheeses: [],
    vegetables: []
  });

  const [isLoading, setIsLoading] = useState(true);
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4>(1);

  // Selections
  const [selectedBaseId, setSelectedBaseId] = useState<string>('base_hand_tossed');
  const [selectedSauceId, setSelectedSauceId] = useState<string>('sauce_classic_tomato');
  const [selectedCheeseId, setSelectedCheeseId] = useState<string>('cheese_mozzarella');
  const [selectedVegIds, setSelectedVegIds] = useState<string[]>(['veg_roma_tomato']);
  const [selectedSize, setSelectedSize] = useState<'Regular' | 'Medium' | 'Large'>('Medium');

  // Server Price Calculation State
  const [calculatedPrice, setCalculatedPrice] = useState<number>(380);
  const [isAvailableOnServer, setIsAvailableOnServer] = useState<boolean>(true);
  const [unavailableList, setUnavailableList] = useState<string[]>([]);
  const [isCalculating, setIsCalculating] = useState(false);
  const [addedSuccess, setAddedSuccess] = useState(false);

  // Fetch ingredients on mount
  useEffect(() => {
    setIsLoading(true);
    fetch('/api/menu/ingredients')
      .then(res => res.json())
      .then(data => {
        setIngredients(data);
        if (data.bases.length > 0 && !selectedBaseId) setSelectedBaseId(data.bases[0].id);
        if (data.sauces.length > 0 && !selectedSauceId) setSelectedSauceId(data.sauces[0].id);
        if (data.cheeses.length > 0 && !selectedCheeseId) setSelectedCheeseId(data.cheeses[0].id);
      })
      .catch(err => console.error('Error loading ingredients:', err))
      .finally(() => setIsLoading(false));
  }, []);

  // Recalculate price whenever selections change
  useEffect(() => {
    if (!selectedBaseId || !selectedSauceId || !selectedCheeseId) return;

    setIsCalculating(true);
    fetch('/api/menu/calculate-price', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        baseId: selectedBaseId,
        sauceId: selectedSauceId,
        cheeseId: selectedCheeseId,
        vegetableIds: selectedVegIds,
        size: selectedSize
      })
    })
      .then(res => res.json())
      .then(data => {
        if (data.unitPrice) {
          setCalculatedPrice(data.unitPrice);
          setIsAvailableOnServer(data.isAvailable);
          setUnavailableList(data.unavailableIngredients || []);
        }
      })
      .catch(err => console.error('Error calculating price:', err))
      .finally(() => setIsCalculating(false));
  }, [selectedBaseId, selectedSauceId, selectedCheeseId, selectedVegIds, selectedSize]);

  const toggleVegetable = (vegId: string) => {
    setSelectedVegIds(prev =>
      prev.includes(vegId) ? prev.filter(id => id !== vegId) : [...prev, vegId]
    );
  };

  const handleAddToCart = () => {
    if (!isAvailableOnServer) return;

    const baseItem = ingredients.bases.find(b => b.id === selectedBaseId);
    const sauceItem = ingredients.sauces.find(s => s.id === selectedSauceId);
    const cheeseItem = ingredients.cheeses.find(c => c.id === selectedCheeseId);
    const vegNames = ingredients.vegetables
      .filter(v => selectedVegIds.includes(v.id))
      .map(v => v.name);

    const customConfig: CustomPizzaConfig = {
      baseId: selectedBaseId,
      baseName: baseItem?.name || 'Selected Base',
      sauceId: selectedSauceId,
      sauceName: sauceItem?.name || 'Selected Sauce',
      cheeseId: selectedCheeseId,
      cheeseName: cheeseItem?.name || 'Selected Cheese',
      vegetableIds: selectedVegIds,
      vegetableNames: vegNames,
      size: selectedSize
    };

    addToCart({
      id: `custom_${Date.now()}`,
      name: `Custom ${selectedSize} Creation`,
      isCustom: true,
      customConfig,
      unitPrice: calculatedPrice,
      quantity: 1,
      totalPrice: calculatedPrice
    });

    setAddedSuccess(true);
    setTimeout(() => {
      setAddedSuccess(false);
      onNavigate('/cart');
    }, 1000);
  };

  const steps = [
    { num: 1, label: 'Base' },
    { num: 2, label: 'Sauce' },
    { num: 3, label: 'Cheese' },
    { num: 4, label: 'Vegetables' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      {/* Step Indicator Header */}
      <div className="border-b border-stone-200 pb-6 mb-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-rose-600">
            Interactive Atelier
          </span>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-stone-900 tracking-tight">
            Custom Pizza Builder
          </h1>
          <p className="text-xs text-stone-500 mt-0.5">
            Craft your signature pie from slow-fermented base to fresh toppings
          </p>
        </div>

        {/* Step Progress Tracker */}
        <div className="flex items-center gap-2">
          {steps.map((s, idx) => (
            <React.Fragment key={s.num}>
              <button
                onClick={() => setCurrentStep(s.num as any)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  currentStep === s.num
                    ? 'bg-stone-900 text-white shadow-xs'
                    : currentStep > s.num
                    ? 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                    : 'text-stone-400 hover:text-stone-700 bg-stone-100'
                }`}
              >
                <span
                  className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] ${
                    currentStep === s.num
                      ? 'bg-rose-500 text-white'
                      : currentStep > s.num
                      ? 'bg-rose-600 text-white'
                      : 'bg-stone-300 text-stone-700'
                  }`}
                >
                  {currentStep > s.num ? '✓' : s.num}
                </span>
                <span>{s.label}</span>
              </button>
              {idx < steps.length - 1 && <span className="text-stone-300">/</span>}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Main Builder Split: Visualizer Left, Ingredient Selection Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Left Sticky Preview & Authoritative Price Box */}
        <div className="lg:col-span-5 lg:sticky lg:top-24 space-y-6">
          <div className="bg-white border border-stone-200 rounded-3xl p-6 sm:p-8 shadow-xs flex flex-col items-center">
            {/* Size Selector */}
            <div className="w-full flex items-center justify-between mb-4 border-b border-stone-100 pb-3">
              <span className="text-xs font-bold text-stone-700 uppercase tracking-wider">Pizza Size:</span>
              <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg">
                {(['Regular', 'Medium', 'Large'] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => setSelectedSize(s)}
                    className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                      selectedSize === s
                        ? 'bg-white text-stone-900 shadow-2xs font-semibold'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Dynamic Pizza SVG */}
            <PizzaGraphic
              baseId={selectedBaseId}
              sauceId={selectedSauceId}
              cheeseId={selectedCheeseId}
              vegetableIds={selectedVegIds}
              size={selectedSize}
              className="w-56 h-56 sm:w-72 sm:h-72 my-2"
            />

            {/* Ingredient Summary Breakdown */}
            <div className="w-full mt-6 space-y-2 border-t border-stone-100 pt-4 text-xs">
              <div className="flex justify-between text-stone-600">
                <span className="text-stone-500">Base:</span>
                <span className="font-medium text-stone-900">
                  {ingredients.bases.find(b => b.id === selectedBaseId)?.name || 'Classic'}
                </span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span className="text-stone-500">Sauce:</span>
                <span className="font-medium text-stone-900">
                  {ingredients.sauces.find(s => s.id === selectedSauceId)?.name || 'Tomato'}
                </span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span className="text-stone-500">Cheese:</span>
                <span className="font-medium text-stone-900">
                  {ingredients.cheeses.find(c => c.id === selectedCheeseId)?.name || 'Mozzarella'}
                </span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span className="text-stone-500">Vegetables ({selectedVegIds.length}):</span>
                <span className="font-medium text-stone-900 text-right truncate max-w-[200px]">
                  {selectedVegIds.length === 0
                    ? 'None'
                    : ingredients.vegetables
                        .filter(v => selectedVegIds.includes(v.id))
                        .map(v => v.name.split(' ')[0])
                        .join(', ')}
                </span>
              </div>
            </div>

            {/* Availability Warning if any item is out of stock */}
            {!isAvailableOnServer && (
              <div className="w-full mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">Unavailable Selection</p>
                  <p className="text-[11px] mt-0.5">
                    {unavailableList.join(', ')} currently out of inventory. Please choose an alternative.
                  </p>
                </div>
              </div>
            )}

            {/* Total Price & Add Action */}
            <div className="w-full mt-6 pt-4 border-t border-stone-200 flex items-center justify-between">
              <div>
                <span className="text-[11px] uppercase tracking-wider text-stone-500">Calculated Total</span>
                <div className="text-2xl font-bold font-mono tabular-nums text-stone-900">
                  ₹{calculatedPrice}
                </div>
              </div>

              <button
                onClick={handleAddToCart}
                disabled={!isAvailableOnServer || isCalculating}
                className={`px-5 py-3 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 whitespace-nowrap shadow-md ${
                  addedSuccess
                    ? 'bg-emerald-600 text-white'
                    : isAvailableOnServer
                    ? 'bg-rose-600 hover:bg-rose-700 text-white'
                    : 'bg-stone-300 text-stone-500 cursor-not-allowed'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{addedSuccess ? 'Added to Bag!' : 'Add Creation to Bag'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Selection Steps */}
        <div className="lg:col-span-7 bg-white border border-stone-200 rounded-3xl p-6 sm:p-8 shadow-xs space-y-6">
          {/* STEP 1: CHOOSE BASE */}
          {currentStep === 1 && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="border-b border-stone-100 pb-3">
                <span className="text-xs font-semibold text-rose-600 uppercase tracking-wider">Step 1 of 4</span>
                <h3 className="text-xl font-bold font-display text-stone-900 mt-0.5">
                  Choose Your Pizza Base
                </h3>
                <p className="text-xs text-stone-500">Select the foundation for your hand-tossed creation</p>
              </div>

              <div className="space-y-3">
                {ingredients.bases.map((base) => {
                  const isSelected = selectedBaseId === base.id;
                  const isOutOfStock = !base.isAvailable || base.availableQuantity <= 0;
                  return (
                    <button
                      key={base.id}
                      onClick={() => !isOutOfStock && setSelectedBaseId(base.id)}
                      disabled={isOutOfStock}
                      className={`w-full p-4 rounded-xl border text-left transition-all flex items-center justify-between ${
                        isSelected
                          ? 'border-rose-600 bg-rose-50/50 shadow-xs'
                          : isOutOfStock
                          ? 'border-stone-200 bg-stone-50 opacity-60 cursor-not-allowed'
                          : 'border-stone-200 hover:border-stone-300 hover:bg-stone-50/60'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-stone-900">{base.name}</span>
                          {isOutOfStock ? (
                            <span className="text-[10px] bg-stone-200 text-stone-600 px-1.5 py-0.5 rounded">
                              Out of Stock
                            </span>
                          ) : base.availableQuantity < base.lowStockThreshold ? (
                            <span className="text-[10px] text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded">
                              Low Stock ({base.availableQuantity} left)
                            </span>
                          ) : null}
                        </div>
                        <p className="text-xs text-stone-600">{base.description}</p>
                      </div>
                      <div className="flex items-center gap-3 shrink-0 ml-4">
                        <span className="text-xs font-bold font-mono tabular-nums text-stone-900">
                          ₹{base.customerPrice}
                        </span>
                        <div
                          className={`w-5 h-5 rounded-full flex items-center justify-center border ${
                            isSelected
                              ? 'bg-rose-600 border-rose-600 text-white'
                              : 'border-stone-300'
                          }`}
                        >
                          {isSelected && <Check className="w-3 h-3" />}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  onClick={() => setCurrentStep(2)}
                  className="px-5 py-2.5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg flex items-center gap-2"
                >
                  <span>Next: Choose Sauce</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: CHOOSE SAUCE */}
          {currentStep === 2 && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="border-b border-stone-100 pb-3">
                <span className="text-xs font-semibold text-rose-600 uppercase tracking-wider">Step 2 of 4</span>
                <h3 className="text-xl font-bold font-display text-stone-900 mt-0.5">
                  Select Simmered Sauce
                </h3>
                <p className="text-xs text-stone-500">Rich tomato reductions, Genovese pesto, or savory garlic alfredo</p>
              </div>

              <div className="space-y-3">
                {ingredients.sauces.map((sauce) => {
                  const isSelected = selectedSauceId === sauce.id;
                  const isOutOfStock = !sauce.isAvailable || sauce.availableQuantity <= 0;
                  return (
                    <button
                      key={sauce.id}
                      onClick={() => !isOutOfStock && setSelectedSauceId(sauce.id)}
                      disabled={isOutOfStock}
                      className={`w-full p-4 rounded-xl border text-left transition-all flex items-center justify-between ${
                        isSelected
                          ? 'border-rose-600 bg-rose-50/50 shadow-xs'
                          : isOutOfStock
                          ? 'border-stone-200 bg-stone-50 opacity-60 cursor-not-allowed'
                          : 'border-stone-200 hover:border-stone-300 hover:bg-stone-50/60'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-stone-900">{sauce.name}</span>
                          {isOutOfStock && (
                            <span className="text-[10px] bg-stone-200 text-stone-600 px-1.5 py-0.5 rounded">
                              Out of Stock
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-stone-600">{sauce.description}</p>
                      </div>
                      <div className="flex items-center gap-3 shrink-0 ml-4">
                        <span className="text-xs font-bold font-mono tabular-nums text-stone-900">
                          ₹{sauce.customerPrice}
                        </span>
                        <div
                          className={`w-5 h-5 rounded-full flex items-center justify-center border ${
                            isSelected
                              ? 'bg-rose-600 border-rose-600 text-white'
                              : 'border-stone-300'
                          }`}
                        >
                          {isSelected && <Check className="w-3 h-3" />}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="pt-4 flex items-center justify-between">
                <button
                  onClick={() => setCurrentStep(1)}
                  className="px-4 py-2 border border-stone-200 hover:bg-stone-50 text-stone-700 text-xs font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Base</span>
                </button>
                <button
                  onClick={() => setCurrentStep(3)}
                  className="px-5 py-2.5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg flex items-center gap-2"
                >
                  <span>Next: Choose Cheese</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: CHOOSE CHEESE */}
          {currentStep === 3 && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="border-b border-stone-100 pb-3">
                <span className="text-xs font-semibold text-rose-600 uppercase tracking-wider">Step 3 of 4</span>
                <h3 className="text-xl font-bold font-display text-stone-900 mt-0.5">
                  Pick Melted Cheese
                </h3>
                <p className="text-xs text-stone-500">Fresh fior di latte mozzarella, sharp aged cheddar, or dairy-free cashew</p>
              </div>

              <div className="space-y-3">
                {ingredients.cheeses.map((cheese) => {
                  const isSelected = selectedCheeseId === cheese.id;
                  const isOutOfStock = !cheese.isAvailable || cheese.availableQuantity <= 0;
                  return (
                    <button
                      key={cheese.id}
                      onClick={() => !isOutOfStock && setSelectedCheeseId(cheese.id)}
                      disabled={isOutOfStock}
                      className={`w-full p-4 rounded-xl border text-left transition-all flex items-center justify-between ${
                        isSelected
                          ? 'border-rose-600 bg-rose-50/50 shadow-xs'
                          : isOutOfStock
                          ? 'border-stone-200 bg-stone-50 opacity-60 cursor-not-allowed'
                          : 'border-stone-200 hover:border-stone-300 hover:bg-stone-50/60'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-stone-900">{cheese.name}</span>
                          {isOutOfStock && (
                            <span className="text-[10px] bg-stone-200 text-stone-600 px-1.5 py-0.5 rounded">
                              Out of Stock
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-stone-600">{cheese.description}</p>
                      </div>
                      <div className="flex items-center gap-3 shrink-0 ml-4">
                        <span className="text-xs font-bold font-mono tabular-nums text-stone-900">
                          ₹{cheese.customerPrice}
                        </span>
                        <div
                          className={`w-5 h-5 rounded-full flex items-center justify-center border ${
                            isSelected
                              ? 'bg-rose-600 border-rose-600 text-white'
                              : 'border-stone-300'
                          }`}
                        >
                          {isSelected && <Check className="w-3 h-3" />}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="pt-4 flex items-center justify-between">
                <button
                  onClick={() => setCurrentStep(2)}
                  className="px-4 py-2 border border-stone-200 hover:bg-stone-50 text-stone-700 text-xs font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Sauce</span>
                </button>
                <button
                  onClick={() => setCurrentStep(4)}
                  className="px-5 py-2.5 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-lg flex items-center gap-2"
                >
                  <span>Next: Choose Vegetables</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: CHOOSE VEGETABLES (Multiple allowed) */}
          {currentStep === 4 && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="border-b border-stone-100 pb-3 flex items-end justify-between">
                <div>
                  <span className="text-xs font-semibold text-rose-600 uppercase tracking-wider">Step 4 of 4</span>
                  <h3 className="text-xl font-bold font-display text-stone-900 mt-0.5">
                    Layer Garden Vegetables
                  </h3>
                  <p className="text-xs text-stone-500">Pick any combination of freshly sliced produce (Multi-select)</p>
                </div>
                <span className="text-xs text-stone-500 tabular-nums">
                  {selectedVegIds.length} selected
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {ingredients.vegetables.map((veg) => {
                  const isSelected = selectedVegIds.includes(veg.id);
                  const isOutOfStock = !veg.isAvailable || veg.availableQuantity <= 0;
                  return (
                    <button
                      key={veg.id}
                      onClick={() => !isOutOfStock && toggleVegetable(veg.id)}
                      disabled={isOutOfStock}
                      className={`p-3.5 rounded-xl border text-left transition-all flex items-center justify-between ${
                        isSelected
                          ? 'border-rose-600 bg-rose-50/50 shadow-xs'
                          : isOutOfStock
                          ? 'border-stone-200 bg-stone-50 opacity-60 cursor-not-allowed'
                          : 'border-stone-200 hover:border-stone-300 hover:bg-stone-50/60'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-stone-900">{veg.name}</span>
                        </div>
                        <span className="text-[11px] text-stone-500 font-mono tabular-nums">
                          +₹{veg.customerPrice}
                        </span>
                      </div>
                      <div
                        className={`w-5 h-5 rounded-md flex items-center justify-center border ${
                          isSelected
                            ? 'bg-rose-600 border-rose-600 text-white'
                            : 'border-stone-300'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3" />}
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="pt-4 flex items-center justify-between border-t border-stone-100 mt-6">
                <button
                  onClick={() => setCurrentStep(3)}
                  className="px-4 py-2 border border-stone-200 hover:bg-stone-50 text-stone-700 text-xs font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Cheese</span>
                </button>
                <button
                  onClick={handleAddToCart}
                  disabled={!isAvailableOnServer}
                  className="px-6 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-lg flex items-center gap-2 shadow-sm"
                >
                  <span>Complete & Add to Bag · ₹{calculatedPrice}</span>
                  <ShoppingBag className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
