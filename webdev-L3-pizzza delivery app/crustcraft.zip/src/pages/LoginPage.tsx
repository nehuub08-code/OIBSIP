import React, { useState } from 'react';
import { Lock, Mail, ArrowRight, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';

interface LoginPageProps {
  onNavigate: (path: string) => void;
  onOpenOutbox: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onNavigate, onOpenOutbox }) => {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isUnverified, setIsUnverified] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    setIsUnverified(false);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();

      if (!res.ok) {
        if (data.isUnverified) {
          setIsUnverified(true);
        }
        throw new Error(data.error || 'Failed to sign in.');
      }

      login(data.token, data.user);
      onNavigate('/');
    } catch (err: any) {
      setErrorMessage(err.message || 'Error logging in.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-6 py-16">
      <div className="bg-white border border-stone-200 rounded-3xl p-8 shadow-xs space-y-6">
        <div className="text-center space-y-1">
          <span className="text-xs font-semibold uppercase tracking-wider text-rose-600">
            Welcome Back
          </span>
          <h1 className="text-2xl font-bold font-display text-stone-900 tracking-tight">
            Customer Sign In
          </h1>
          <p className="text-xs text-stone-500">
            Sign in to track orders, save addresses, and earn crust points
          </p>
        </div>

        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p>{errorMessage}</p>
              {isUnverified && (
                <button
                  type="button"
                  onClick={onOpenOutbox}
                  className="font-bold underline text-rose-800 block text-left"
                >
                  Open Mail Outbox to Click Verification Link →
                </button>
              )}
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-semibold text-stone-500 uppercase">Email Address</label>
            <div className="relative mt-1">
              <Mail className="w-4 h-4 absolute left-3 top-2.5 text-stone-400" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="customer@example.com"
                className="w-full pl-9 pr-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between">
              <label className="block text-[11px] font-semibold text-stone-500 uppercase">Password</label>
              <button
                type="button"
                onClick={() => onNavigate('/forgot-password')}
                className="text-[11px] text-rose-600 hover:underline"
              >
                Forgot password?
              </button>
            </div>
            <div className="relative mt-1">
              <Lock className="w-4 h-4 absolute left-3 top-2.5 text-stone-400" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
          >
            <span>{isLoading ? 'Signing In...' : 'Sign In to CrustCraft'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>

        <div className="border-t border-stone-100 pt-4 text-center text-xs text-stone-500">
          Don't have an account yet?{' '}
          <button
            onClick={() => onNavigate('/register')}
            className="font-semibold text-rose-600 hover:underline"
          >
            Create Customer Account
          </button>
        </div>
      </div>
    </div>
  );
};
