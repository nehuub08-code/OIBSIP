import React, { useState, useEffect } from 'react';
import { Plus, Check, Sparkles, Filter, ArrowRight } from 'lucide-react';
import { PizzaGraphic } from '../components/PizzaGraphic.js';
import { SignaturePizza } from '../types/index.js';
import { useCart } from '../context/CartContext.js';

interface MenuPageProps {
  onNavigate: (path: string) => void;
}

export const MenuPage: React.FC<MenuPageProps> = ({ onNavigate }) => {
  const [pizzas, setPizzas] = useState<SignaturePizza[]>([]);
  const [categoryFilter, setCategoryFilter] = useState<'All' | 'Classic' | 'Gourmet' | 'Vegetarian'>('All');
  const [addedIds, setAddedIds] = useState<Record<string, boolean>>({});
  const { addToCart } = useCart();

  useEffect(() => {
    fetch('/api/menu/pizzas')
      .then(res => res.json())
      .then(data => setPizzas(data))
      .catch(err => console.error('Error loading menu:', err));
  }, []);

  const handleAdd = (pizza: SignaturePizza) => {
    addToCart({
      id: pizza.id,
      name: pizza.name,
      isCustom: false,
      unitPrice: pizza.price,
      quantity: 1,
      totalPrice: pizza.price
    });

    setAddedIds(prev => ({ ...prev, [pizza.id]: true }));
    setTimeout(() => {
      setAddedIds(prev => ({ ...prev, [pizza.id]: false }));
    }, 1500);
  };

  const filteredPizzas = categoryFilter === 'All'
    ? pizzas
    : pizzas.filter(p => p.category === categoryFilter);

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 space-y-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-stone-200 pb-6">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-rose-600">Kitchen Creations</span>
          <h1 className="text-3xl sm:text-4xl font-bold font-display text-stone-900 tracking-tight mt-1">
            Signature Artisanal Pizzas
          </h1>
          <p className="text-sm text-stone-600 mt-1 max-w-xl">
            Each recipe crafted by our pizzaiolos using slow-fermented bases and authentic Italian ingredients.
          </p>
        </div>

        {/* Filter Segmented Control */}
        <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg">
          {(['All', 'Classic', 'Gourmet', 'Vegetarian'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                categoryFilter === cat
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Custom Pizza Builder Promo Banner */}
      <div className="p-6 bg-gradient-to-r from-rose-500 to-rose-600 text-white rounded-2xl shadow-md flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1">
          <h3 className="text-lg font-bold font-display">Prefer to design your own pizza?</h3>
          <p className="text-xs text-rose-100">
            Pick from 5 dough bases, 5 simmered sauces, 4 artisan cheeses, and 7 garden vegetables.
          </p>
        </div>
        <button
          onClick={() => onNavigate('/builder')}
          className="px-5 py-2.5 text-xs font-semibold text-rose-600 bg-white hover:bg-rose-50 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span>Open Custom Builder</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredPizzas.map((pizza) => (
          <div
            key={pizza.id}
            className="bg-white border border-stone-200 rounded-2xl p-6 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 text-xs text-stone-500">
                  <span>{pizza.category}</span>
                  {pizza.badge && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="text-rose-700 font-semibold">{pizza.badge}</span>
                    </>
                  )}
                </div>
                <span className="text-base font-bold font-mono tabular-nums text-stone-900">
                  ₹{pizza.price}
                </span>
              </div>

              {/* Pizza Graphic Rendering */}
              <div className="py-4 flex justify-center">
                <PizzaGraphic
                  baseId={pizza.ingredientIds.baseId}
                  sauceId={pizza.ingredientIds.sauceId}
                  cheeseId={pizza.ingredientIds.cheeseId}
                  vegetableIds={pizza.ingredientIds.vegetableIds}
                  size="Regular"
                  className="w-48 h-48"
                />
              </div>

              <h2 className="text-lg font-bold text-stone-900 mt-2">{pizza.name}</h2>
              <p className="text-xs text-stone-600 mt-1 leading-relaxed">{pizza.description}</p>

              <div className="mt-4 pt-3 border-t border-stone-100">
                <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider mb-1.5">
                  Ingredients:
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {pizza.baseIngredients.map((item, idx) => (
                    <span key={idx} className="text-[11px] text-stone-600 bg-stone-100 px-2 py-0.5 rounded">
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-stone-100">
              <button
                onClick={() => handleAdd(pizza)}
                className={`w-full py-2.5 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 ${
                  addedIds[pizza.id]
                    ? 'bg-emerald-600 text-white'
                    : 'bg-stone-900 hover:bg-stone-800 text-white'
                }`}
              >
                {addedIds[pizza.id] ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>Added to Bag!</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add to Bag · ₹{pizza.price}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
