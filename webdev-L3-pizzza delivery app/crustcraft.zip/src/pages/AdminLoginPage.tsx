import React, { useState } from 'react';
import { Shield, Lock, Mail, ArrowRight, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';

interface AdminLoginPageProps {
  onNavigate: (path: string) => void;
}

export const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ onNavigate }) => {
  const { login } = useAuth();
  const [email, setEmail] = useState('admin@crustcraft.com');
  const [password, setPassword] = useState('Admin@123456');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/auth/admin-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Unauthorized administrative credentials.');
      }

      login(data.token, data.user);
      onNavigate('/admin');
    } catch (err: any) {
      setErrorMessage(err.message || 'Error signing in to admin portal.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-6 py-20">
      <div className="bg-white border border-stone-200 rounded-3xl p-8 shadow-md space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-stone-900 text-white flex items-center justify-center mx-auto shadow-sm">
            <Shield className="w-6 h-6 text-rose-500" />
          </div>
          <h1 className="text-2xl font-bold font-display text-stone-900 tracking-tight">
            Kitchen Admin Portal
          </h1>
          <p className="text-xs text-stone-500">
            Authorized pizzaiolos and restaurant management personnel only
          </p>
        </div>

        {/* Demo Seed Credentials Hint */}
        <div className="p-3 bg-stone-50 border border-stone-200 rounded-xl text-xs space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400">
            Seeded Admin Credentials
          </span>
          <div className="flex justify-between text-stone-700 font-mono text-[11px]">
            <span>Email: <strong>admin@crustcraft.com</strong></span>
            <span>Password: <strong>Admin@123456</strong></span>
          </div>
        </div>

        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-semibold text-stone-500 uppercase">Admin Email</label>
            <div className="relative mt-1">
              <Mail className="w-4 h-4 absolute left-3 top-2.5 text-stone-400" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-stone-500 uppercase">Password</label>
            <div className="relative mt-1">
              <Lock className="w-4 h-4 absolute left-3 top-2.5 text-stone-400" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-none focus:border-stone-900 font-mono"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-white font-semibold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
          >
            <span>{isLoading ? 'Verifying Admin...' : 'Authenticate to Admin Console'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>

        <div className="border-t border-stone-100 pt-4 text-center text-xs text-stone-400">
          <button onClick={() => onNavigate('/')} className="hover:text-stone-700">
            ← Return to Customer Storefront
          </button>
        </div>
      </div>
    </div>
  );
};
