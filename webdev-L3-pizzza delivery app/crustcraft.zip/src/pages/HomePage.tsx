import React, { useState, useEffect } from 'react';
import { ArrowRight, Flame, Sparkles, ChefHat, Clock, ShieldCheck, Plus } from 'lucide-react';
import { PizzaGraphic } from '../components/PizzaGraphic.js';
import { SignaturePizza } from '../types/index.js';
import { useCart } from '../context/CartContext.js';

interface HomePageProps {
  onNavigate: (path: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const [signaturePizzas, setSignaturePizzas] = useState<SignaturePizza[]>([]);
  const { addToCart } = useCart();
  const [addedId, setAddedId] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/menu/pizzas')
      .then(res => res.json())
      .then(data => setSignaturePizzas(data))
      .catch(err => console.error('Error loading signature pizzas:', err));
  }, []);

  const handleAddSignature = (pizza: SignaturePizza) => {
    addToCart({
      id: pizza.id,
      name: pizza.name,
      isCustom: false,
      unitPrice: pizza.price,
      quantity: 1,
      totalPrice: pizza.price
    });
    setAddedId(pizza.id);
    setTimeout(() => setAddedId(null), 1500);
  };

  return (
    <div className="space-y-20 pb-16">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 pt-10 md:pt-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-rose-700 bg-rose-50 px-3 py-1 rounded-md border border-rose-100">
              <Flame className="w-3.5 h-3.5 text-rose-600" />
              <span>Artisanal Wood-Fired Pizza Kitchen</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold font-display tracking-tight text-stone-900 text-balance leading-none">
              Your Crust. <br />
              <span className="text-rose-600">Your Creation.</span>
            </h1>

            <p className="text-base sm:text-lg text-stone-600 max-w-xl leading-relaxed">
              Step into the craft of true Neapolitan pizza. Build your pie layer by layer with 5 artisanal dough bases, simmered Italian sauces, and farm-fresh toppings, stone-baked at 450°C.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={() => onNavigate('/builder')}
                className="px-6 py-3.5 text-sm font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition-all shadow-md hover:shadow-lg flex items-center gap-2 whitespace-nowrap shrink-0"
              >
                <span>Build Custom Pizza</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onNavigate('/menu')}
                className="px-6 py-3.5 text-sm font-semibold text-stone-800 bg-white hover:bg-stone-50 border border-stone-200 rounded-xl transition-colors whitespace-nowrap shrink-0"
              >
                View Kitchen Menu
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 flex justify-center">
            <div className="relative p-6 sm:p-8 bg-white border border-stone-200/80 rounded-3xl shadow-xl flex flex-col items-center">
              <div className="absolute top-4 right-4 bg-amber-50 border border-amber-200 text-amber-900 text-[11px] font-semibold px-2.5 py-1 rounded-md">
                Live Interactive Pizza
              </div>

              <PizzaGraphic
                baseId="base_cheese_burst"
                sauceId="sauce_classic_tomato"
                cheeseId="cheese_mozzarella"
                vegetableIds={['veg_button_mushroom', 'veg_roma_tomato', 'veg_black_olives', 'veg_capsicum']}
                size="Large"
                className="w-64 h-64 sm:w-76 sm:h-76"
              />

              <div className="mt-4 text-center">
                <p className="text-sm font-bold text-stone-900">Custom Rustica Creation</p>
                <div className="flex items-center justify-center gap-2 text-xs text-stone-500 mt-0.5">
                  <span>Cheese Burst</span>
                  <span aria-hidden="true">·</span>
                  <span>San Marzano</span>
                  <span aria-hidden="true">·</span>
                  <span>4 Toppings</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4-Column KPI Strip below hero split */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 p-6 bg-white border border-stone-200 rounded-2xl shadow-2xs">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-stone-900 font-semibold text-sm">
              <Clock className="w-4 h-4 text-rose-600" />
              <span>48h Cold Ferment</span>
            </div>
            <p className="text-xs text-stone-500">Airy, digestible sourdough crust with bubbly blisters.</p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2 text-stone-900 font-semibold text-sm">
              <Flame className="w-4 h-4 text-rose-600" />
              <span>450°C Hearth Oven</span>
            </div>
            <p className="text-xs text-stone-500">Fast flash-baked in under 90 seconds for peak aroma.</p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2 text-stone-900 font-semibold text-sm">
              <ChefHat className="w-4 h-4 text-rose-600" />
              <span>100% Real Cheese</span>
            </div>
            <p className="text-xs text-stone-500">Fresh fior di latte mozzarella and aged parmesan.</p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2 text-stone-900 font-semibold text-sm">
              <ShieldCheck className="w-4 h-4 text-rose-600" />
              <span>Atomic Inventory</span>
            </div>
            <p className="text-xs text-stone-500">Live ingredient availability and stock protection.</p>
          </div>
        </div>
      </section>

      {/* Featured Signature Pizzas */}
      <section className="max-w-7xl mx-auto px-6">
        <div className="flex items-end justify-between mb-8">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-rose-600">From Our Oven</span>
            <h2 className="text-2xl sm:text-3xl font-bold font-display text-stone-900 tracking-tight mt-1">
              Signature Masterpieces
            </h2>
          </div>
          <button
            onClick={() => onNavigate('/menu')}
            className="text-xs font-semibold text-stone-700 hover:text-rose-600 flex items-center gap-1 transition-colors"
          >
            <span>View Full Menu</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {signaturePizzas.slice(0, 3).map((pizza) => (
            <div
              key={pizza.id}
              className="bg-white border border-stone-200 rounded-2xl p-6 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 text-xs text-stone-500">
                    <span>{pizza.category}</span>
                    {pizza.badge && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-rose-700 font-medium">{pizza.badge}</span>
                      </>
                    )}
                  </div>
                  <span className="text-base font-bold font-mono tabular-nums text-stone-900">
                    ₹{pizza.price}
                  </span>
                </div>

                <div className="py-2 flex justify-center">
                  <PizzaGraphic
                    baseId={pizza.ingredientIds.baseId}
                    sauceId={pizza.ingredientIds.sauceId}
                    cheeseId={pizza.ingredientIds.cheeseId}
                    vegetableIds={pizza.ingredientIds.vegetableIds}
                    size="Regular"
                    className="w-44 h-44"
                  />
                </div>

                <h3 className="text-lg font-bold text-stone-900 mt-2">{pizza.name}</h3>
                <p className="text-xs text-stone-600 line-clamp-2 mt-1 leading-relaxed">
                  {pizza.description}
                </p>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {pizza.baseIngredients.slice(0, 4).map((ing, idx) => (
                    <span key={idx} className="text-[11px] text-stone-500 bg-stone-100 px-2 py-0.5 rounded">
                      {ing}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-stone-100 flex items-center gap-3">
                <button
                  onClick={() => handleAddSignature(pizza)}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                    addedId === pizza.id
                      ? 'bg-emerald-600 text-white'
                      : 'bg-stone-900 hover:bg-stone-800 text-white'
                  }`}
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{addedId === pizza.id ? 'Added to Bag!' : 'Add to Bag'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* How It Works Section */}
      <section className="max-w-7xl mx-auto px-6">
        <div className="bg-stone-900 text-white rounded-3xl p-8 sm:p-12 relative overflow-hidden">
          <div className="max-w-xl space-y-4 relative z-10">
            <span className="text-xs font-semibold uppercase tracking-wider text-rose-400">
              The CrustCraft Process
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold font-display tracking-tight">
              Create Your Dream Pizza In 4 Simple Steps
            </h2>
            <p className="text-sm text-stone-300 leading-relaxed">
              Every crust is hand-stretched on order. Choose from our slow-fermented bases, signature sauces, cheeses, and garden vegetables.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="p-3 bg-stone-800/80 rounded-xl border border-stone-700/60">
                <span className="text-xs font-bold text-rose-400">01. Pick Your Base</span>
                <p className="text-xs text-stone-400 mt-1">Hand-Tossed, Thin Roman, Wheat, Cheese Burst or Gluten-Free.</p>
              </div>
              <div className="p-3 bg-stone-800/80 rounded-xl border border-stone-700/60">
                <span className="text-xs font-bold text-rose-400">02. Select Simmered Sauce</span>
                <p className="text-xs text-stone-400 mt-1">San Marzano, Spicy Arrabbiata, Pesto, BBQ or Roasted Garlic.</p>
              </div>
              <div className="p-3 bg-stone-800/80 rounded-xl border border-stone-700/60">
                <span className="text-xs font-bold text-rose-400">03. Choose Cheese & Toppings</span>
                <p className="text-xs text-stone-400 mt-1">Fior di Latte, aged cheddar, parmesan, or vegan with garden veg.</p>
              </div>
              <div className="p-3 bg-stone-800/80 rounded-xl border border-stone-700/60">
                <span className="text-xs font-bold text-rose-400">04. Live Real-Time Tracking</span>
                <p className="text-xs text-stone-400 mt-1">Watch your pizza move from kitchen oven straight to delivery.</p>
              </div>
            </div>

            <div className="pt-4">
              <button
                onClick={() => onNavigate('/builder')}
                className="px-6 py-3 text-sm font-semibold text-stone-900 bg-white hover:bg-stone-100 rounded-xl transition-colors inline-flex items-center gap-2"
              >
                <span>Launch Pizza Builder</span>
                <ArrowRight className="w-4 h-4 text-stone-900" />
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
