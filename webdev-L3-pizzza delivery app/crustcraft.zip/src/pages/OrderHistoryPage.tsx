import React, { useState, useEffect } from 'react';
import { ShoppingBag, ArrowRight, Clock, ChefHat, Bike, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { Order } from '../types/index.js';

interface OrderHistoryPageProps {
  onNavigate: (path: string) => void;
}

export const OrderHistoryPage: React.FC<OrderHistoryPageProps> = ({ onNavigate }) => {
  const { token, user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!token) return;
    setIsLoading(true);
    fetch('/api/orders/my-orders', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) setOrders(data);
      })
      .catch(err => console.error('Error fetching orders:', err))
      .finally(() => setIsLoading(false));
  }, [token]);

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-6 py-20 text-center">
        <h2 className="text-xl font-bold font-display text-stone-900">Sign in to view orders</h2>
        <p className="text-xs text-stone-500 mt-2">Access your past pizzas and active delivery orders.</p>
        <button
          onClick={() => onNavigate('/login')}
          className="mt-6 px-5 py-2.5 bg-stone-900 text-white text-xs font-semibold rounded-xl"
        >
          Sign In
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-6 py-10 space-y-6">
      <div className="border-b border-stone-200 pb-4">
        <span className="text-xs font-semibold uppercase tracking-wider text-rose-600">Past & Active</span>
        <h1 className="text-3xl font-bold font-display text-stone-900 tracking-tight mt-0.5">
          My Pizza Orders
        </h1>
      </div>

      {isLoading ? (
        <div className="py-20 text-center text-xs text-stone-500">Loading order history...</div>
      ) : orders.length === 0 ? (
        <div className="bg-white border border-stone-200 rounded-2xl p-12 text-center space-y-3">
          <ShoppingBag className="w-8 h-8 text-stone-400 mx-auto" />
          <h3 className="text-base font-bold text-stone-900">No orders placed yet</h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            You haven't ordered any artisanal pizzas yet. Start building your custom pizza or try our signature recipes!
          </p>
          <button
            onClick={() => onNavigate('/builder')}
            className="mt-2 px-5 py-2 bg-rose-600 text-white text-xs font-semibold rounded-xl hover:bg-rose-700 transition-colors"
          >
            Start Custom Pizza
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((ord) => (
            <div
              key={ord.id}
              className="bg-white border border-stone-200 rounded-2xl p-6 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-6"
            >
              <div className="space-y-1.5">
                <div className="flex items-center gap-3">
                  <span className="text-sm font-bold font-mono text-stone-900">#{ord.id}</span>
                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                      ord.orderStatus === 'Delivered'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : ord.orderStatus === 'In Kitchen'
                        ? 'bg-rose-50 text-rose-700 border border-rose-200'
                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}
                  >
                    {ord.orderStatus}
                  </span>
                </div>

                <p className="text-xs text-stone-500">
                  {new Date(ord.createdAt).toLocaleDateString()} at{' '}
                  {new Date(ord.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} ·{' '}
                  <span className="font-medium text-stone-700">{ord.items.length} item(s)</span>
                </p>

                <div className="text-xs text-stone-600 font-medium">
                  {ord.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}
                </div>
              </div>

              <div className="flex items-center gap-4 shrink-0 border-t md:border-t-0 pt-4 md:pt-0">
                <div className="text-right">
                  <span className="text-[11px] text-stone-400 block uppercase">Total Amount</span>
                  <span className="text-base font-bold font-mono tabular-nums text-stone-900">
                    ₹{ord.totalAmount}
                  </span>
                </div>

                <button
                  onClick={() => onNavigate(`/track?orderId=${ord.id}`)}
                  className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors"
                >
                  <span>Track Live</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
