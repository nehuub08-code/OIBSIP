import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { CartProvider } from './context/CartContext.js';
import { Navbar } from './components/Navbar.js';
import { Footer } from './components/Footer.js';
import { MailOutboxModal } from './components/MailOutboxModal.js';

import { HomePage } from './pages/HomePage.js';
import { MenuPage } from './pages/MenuPage.js';
import { CustomBuilderPage } from './pages/CustomBuilderPage.js';
import { CartCheckoutPage } from './pages/CartCheckoutPage.js';
import { PaymentPage } from './pages/PaymentPage.js';
import { OrderTrackingPage } from './pages/OrderTrackingPage.js';
import { OrderHistoryPage } from './pages/OrderHistoryPage.js';
import { LoginPage } from './pages/LoginPage.js';
import { RegisterPage } from './pages/RegisterPage.js';
import { VerifyEmailPage } from './pages/VerifyEmailPage.js';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage.js';
import { ResetPasswordPage } from './pages/ResetPasswordPage.js';
import { AdminLoginPage } from './pages/AdminLoginPage.js';
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage.js';
import { AdminInventoryPage } from './pages/admin/AdminInventoryPage.js';
import { AdminOrdersPage } from './pages/admin/AdminOrdersPage.js';

function AppContent() {
  const { user, isAdmin, isLoading } = useAuth();
  const [currentPath, setCurrentPath] = useState<string>(() => {
    return window.location.pathname || '/';
  });
  const [currentSearch, setCurrentSearch] = useState<string>(() => {
    return window.location.search || '';
  });
  const [activeOrderId, setActiveOrderId] = useState<string>(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('orderId') || '';
  });
  const [isOutboxOpen, setIsOutboxOpen] = useState(false);

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
      setCurrentSearch(window.location.search);
      const params = new URLSearchParams(window.location.search);
      if (params.get('orderId')) {
        setActiveOrderId(params.get('orderId')!);
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    let cleanPath = path;
    let queryOrderId = '';
    let searchStr = '';

    if (path.includes('?')) {
      const parts = path.split('?');
      cleanPath = parts[0];
      searchStr = '?' + parts[1];
      const params = new URLSearchParams(parts[1]);
      if (params.get('orderId')) {
        queryOrderId = params.get('orderId')!;
        setActiveOrderId(queryOrderId);
      }
    }

    setCurrentPath(cleanPath);
    setCurrentSearch(searchStr);
    window.history.pushState({}, '', path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateFromUrl = (fullUrl: string) => {
    try {
      const url = new URL(fullUrl);
      navigate(url.pathname + url.search);
    } catch {
      navigate(fullUrl);
    }
  };

  // Render active page based on currentPath
  const renderPage = () => {
    const queryToken = new URLSearchParams(currentSearch || window.location.search).get('token') || undefined;

    // 1. Verification & Password Recovery
    if (currentPath === '/verify-email') {
      return <VerifyEmailPage onNavigate={navigate} tokenParam={queryToken} />;
    }
    if (currentPath === '/forgot-password') {
      return <ForgotPasswordPage onNavigate={navigate} onOpenOutbox={() => setIsOutboxOpen(true)} />;
    }
    if (currentPath === '/reset-password') {
      return <ResetPasswordPage onNavigate={navigate} tokenParam={queryToken} />;
    }

    // 2. Auth
    if (currentPath === '/login') {
      return <LoginPage onNavigate={navigate} onOpenOutbox={() => setIsOutboxOpen(true)} />;
    }
    if (currentPath === '/register') {
      return <RegisterPage onNavigate={navigate} onOpenOutbox={() => setIsOutboxOpen(true)} />;
    }
    if (currentPath === '/admin/login') {
      return <AdminLoginPage onNavigate={navigate} />;
    }

    // 3. Admin Protected Console
    if (currentPath.startsWith('/admin')) {
      if (!user || !isAdmin) {
        return <AdminLoginPage onNavigate={navigate} />;
      }
      if (currentPath === '/admin/inventory') {
        return <AdminInventoryPage onNavigate={navigate} />;
      }
      if (currentPath === '/admin/orders') {
        return <AdminOrdersPage onNavigate={navigate} />;
      }
      return <AdminDashboardPage onNavigate={navigate} onOpenOutbox={() => setIsOutboxOpen(true)} />;
    }

    // 4. Customer Ordering & Tracking
    if (currentPath === '/menu') {
      return <MenuPage onNavigate={navigate} />;
    }
    if (currentPath === '/builder') {
      return <CustomBuilderPage onNavigate={navigate} />;
    }
    if (currentPath === '/cart') {
      return <CartCheckoutPage onNavigate={navigate} onOrderCreated={(id) => setActiveOrderId(id)} />;
    }
    if (currentPath === '/payment') {
      return <PaymentPage orderId={activeOrderId} onNavigate={navigate} />;
    }
    if (currentPath === '/track') {
      return <OrderTrackingPage orderId={activeOrderId} onNavigate={navigate} />;
    }
    if (currentPath === '/orders') {
      return <OrderHistoryPage onNavigate={navigate} />;
    }

    // Default Home
    return <HomePage onNavigate={navigate} />;
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-stone-900 font-sans">
      <Navbar
        currentPath={currentPath}
        onNavigate={navigate}
        onOpenOutbox={() => setIsOutboxOpen(true)}
      />

      <main className="flex-1">
        {renderPage()}
      </main>

      <Footer
        onNavigate={navigate}
        onOpenOutbox={() => setIsOutboxOpen(true)}
      />

      <MailOutboxModal
        isOpen={isOutboxOpen}
        onClose={() => setIsOutboxOpen(false)}
        onNavigateToUrl={handleNavigateFromUrl}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <AppContent />
      </CartProvider>
    </AuthProvider>
  );
}
