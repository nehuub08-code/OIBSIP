export type UserRole = 'customer' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: UserRole;
  isVerified: boolean;
  verificationToken?: string;
  verificationTokenExpires?: string;
  resetPasswordToken?: string;
  resetPasswordTokenExpires?: string;
  createdAt: string;
}

export type IngredientCategory = 'base' | 'sauce' | 'cheese' | 'vegetable';

export interface InventoryItem {
  id: string;
  name: string;
  category: IngredientCategory;
  availableQuantity: number;
  unit: string;
  lowStockThreshold: number;
  unitCost: number; // cost to business
  customerPrice: number; // price charged to customer
  isAvailable: boolean;
  description?: string;
  lastUpdated: string;
  lastAlertSentAt?: string;
}

export interface StockAdjustmentLog {
  id: string;
  itemId: string;
  itemName: string;
  previousQuantity: number;
  newQuantity: number;
  change: number;
  reason: string;
  adjustedBy: string; // admin email or 'system_order_deduction'
  orderId?: string;
  timestamp: string;
}

export interface CustomPizzaConfig {
  baseId: string;
  baseName: string;
  sauceId: string;
  sauceName: string;
  cheeseId: string;
  cheeseName: string;
  vegetableIds: string[];
  vegetableNames: string[];
  size?: 'Regular' | 'Medium' | 'Large';
}

export interface OrderItem {
  id: string;
  name: string;
  isCustom: boolean;
  customConfig?: CustomPizzaConfig;
  unitPrice: number;
  quantity: number;
  totalPrice: number;
  imageUrl?: string;
}

export type OrderStatus = 'Order Received' | 'In Kitchen' | 'Sent to Delivery' | 'Delivered' | 'Cancelled';

export type PaymentStatus = 'pending' | 'paid' | 'failed';

export interface StatusHistoryEntry {
  status: OrderStatus;
  timestamp: string;
  note?: string;
}

export interface Order {
  id: string; // CC-ORD-XXXXX
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  deliveryAddress: {
    street: string;
    city: string;
    state: string;
    postalCode: string;
  };
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  tax: number;
  discount: number;
  totalAmount: number;
  paymentStatus: PaymentStatus;
  paymentMethod: 'razorpay' | 'razorpay_test_simulator';
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  razorpaySignature?: string;
  orderStatus: OrderStatus;
  statusHistory: StatusHistoryEntry[];
  stockDeducted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SignaturePizza {
  id: string;
  name: string;
  description: string;
  category: 'Vegetarian' | 'Gourmet' | 'Classic';
  price: number;
  baseIngredients: string[];
  ingredientIds: {
    baseId: string;
    sauceId: string;
    cheeseId: string;
    vegetableIds: string[];
  };
  badge?: string;
}

export interface OutboxMail {
  id: string;
  to: string;
  subject: string;
  html: string;
  text: string;
  sentAt: string;
  type: 'verification' | 'reset_password' | 'low_stock_alert' | 'order_confirmation';
}

export interface AdminStats {
  totalOrders: number;
  newOrders: number;
  inKitchenOrders: number;
  sentToDeliveryOrders: number;
  deliveredOrders: number;
  totalRevenue: number;
  lowStockItemsCount: number;
  lowStockItems: InventoryItem[];
}
