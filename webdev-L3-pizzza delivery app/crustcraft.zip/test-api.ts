/**
 * CrustCraft Full-Stack End-to-End API Integration & Regression Tests
 * Tests all core functional flows specified in Master Prompt:
 * 1. Customer registration & email verification token
 * 2. Password reset flow with single-use token
 * 3. Role security (Customer cannot access admin endpoints)
 * 4. Admin authentication & inventory listing
 * 5. Menu ingredient availability & authoritative price calculation
 * 6. Order creation, Razorpay test payment signature verification, & safe atomic stock deduction
 * 7. Scheduled cron low-stock threshold audit
 */

const BASE_URL = 'http://localhost:3000';

async function runTests() {
  console.log('🧪 Starting CrustCraft Full-Stack Test Suite...\n');
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      console.log(`  ✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${testName}`);
      failed++;
    }
  }

  try {
    // 1. Health check
    const healthRes = await fetch(`${BASE_URL}/api/health`);
    const healthData = await healthRes.json();
    assert(healthRes.status === 200 && healthData.status === 'healthy', 'Server is healthy');

    // 2. Menu Ingredients & Availability
    const ingRes = await fetch(`${BASE_URL}/api/menu/ingredients`);
    const ingData = await ingRes.json();
    assert(
      ingData.bases?.length === 5 &&
      ingData.sauces?.length === 5 &&
      ingData.cheeses?.length === 4 &&
      ingData.vegetables?.length === 7,
      'Menu loads all 21 categorized ingredients (5 bases, 5 sauces, 4 cheeses, 7 vegetables)'
    );

    // 3. Authoritative Price Calculation on Server
    const calcRes = await fetch(`${BASE_URL}/api/menu/calculate-price`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        baseId: 'base_hand_tossed',
        sauceId: 'sauce_classic_tomato',
        cheeseId: 'cheese_mozzarella',
        vegetableIds: ['veg_red_onion', 'veg_button_mushroom'],
        size: 'Medium'
      })
    });
    const calcData = await calcRes.json();
    assert(calcRes.status === 200 && calcData.unitPrice > 0, `Authoritative price calculation on server: ₹${calcData.unitPrice}`);

    // 4. Customer Registration
    const testEmail = `chef_${Date.now()}@example.com`;
    const regRes = await fetch(`${BASE_URL}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Giuseppe Pizza',
        email: testEmail,
        password: 'Password123'
      })
    });
    const regData = await regRes.json();
    assert(regRes.status === 201 && regData.isVerified === false, 'Customer registration succeeds with unverified state');

    // 5. Unverified login should be blocked
    const unverifiedLoginRes = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: testEmail,
        password: 'Password123'
      })
    });
    assert(unverifiedLoginRes.status === 403, 'Unverified customer account is prevented from logging in');

    // 6. Check Mail Outbox for Verification Token
    const outboxRes = await fetch(`${BASE_URL}/api/outbox/recent`);
    const outboxData = await outboxRes.json();
    const verifyMail = outboxData.find((m: any) => m.to === testEmail && m.type === 'verification');
    assert(Boolean(verifyMail), 'Verification email dispatched and recorded in Outbox');

    const tokenMatch = verifyMail.text.match(/token=([a-f0-9]+)/);
    const verifyToken = tokenMatch ? tokenMatch[1] : '';
    assert(Boolean(verifyToken), 'Expiring verification token extracted from email');

    // 7. Verify Email Address
    const verifyRes = await fetch(`${BASE_URL}/api/auth/verify-email?token=${verifyToken}`);
    const verifyData = await verifyRes.json();
    assert(verifyRes.status === 200 && verifyData.user?.isVerified === true, 'Email verified successfully and user activated');
    const customerToken = verifyData.token;

    // 8. Role Security Check: Customer MUST NOT access admin APIs
    const breachAttempt = await fetch(`${BASE_URL}/api/admin/stats`, {
      headers: { Authorization: `Bearer ${customerToken}` }
    });
    assert(breachAttempt.status === 403, 'Customer token is strictly forbidden from accessing /api/admin/* endpoints');

    // 9. Admin Authentication with Seeded Credentials
    const adminLoginRes = await fetch(`${BASE_URL}/api/auth/admin-login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'admin@crustcraft.com',
        password: 'Admin@123456'
      })
    });
    const adminData = await adminLoginRes.json();
    assert(adminLoginRes.status === 200 && adminData.user?.role === 'admin', 'Admin authenticated using seeded credentials');
    const adminToken = adminData.token;

    // 10. Admin Stats Access
    const statsRes = await fetch(`${BASE_URL}/api/admin/stats`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const statsData = await statsRes.json();
    assert(statsRes.status === 200 && typeof statsData.totalOrders === 'number', 'Admin dashboard stats retrieved successfully');

    // 11. Create Customer Order
    const orderRes = await fetch(`${BASE_URL}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${customerToken}`
      },
      body: JSON.stringify({
        customerPhone: '9876543210',
        deliveryAddress: {
          street: '10 Via Roma',
          city: 'Mumbai',
          state: 'Maharashtra',
          postalCode: '400001'
        },
        items: [
          {
            id: 'sig_margherita',
            name: 'Margherita Reale',
            isCustom: false,
            quantity: 1
          }
        ]
      })
    });
    const orderData = await orderRes.json();
    assert(orderRes.status === 201 && orderData.order?.orderStatus === 'Order Received', `Order placed successfully: #${orderData.order?.id}`);
    const createdOrder = orderData.order;

    // 12. Create Razorpay Test Order
    const rzpOrderRes = await fetch(`${BASE_URL}/api/payment/create-order`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${customerToken}`
      },
      body: JSON.stringify({ orderId: createdOrder.id })
    });
    const rzpOrderData = await rzpOrderRes.json();
    assert(rzpOrderRes.status === 200 && Boolean(rzpOrderData.razorpayOrderId), `Razorpay sandbox order created: ${rzpOrderData.razorpayOrderId}`);

    // 13. Test HMAC SHA256 Payment Verification & Safe Atomic Stock Deduction
    const testPaymentId = `pay_test_${Date.now()}`;
    const sigGenRes = await fetch(`${BASE_URL}/api/payment/simulate-test-signature`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${customerToken}`
      },
      body: JSON.stringify({
        razorpayOrderId: rzpOrderData.razorpayOrderId,
        razorpayPaymentId: testPaymentId
      })
    });
    const sigGenData = await sigGenRes.json();
    assert(Boolean(sigGenData.signature), 'HMAC SHA256 test signature generated');

    const verifyPayRes = await fetch(`${BASE_URL}/api/payment/verify`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${customerToken}`
      },
      body: JSON.stringify({
        orderId: createdOrder.id,
        razorpayOrderId: rzpOrderData.razorpayOrderId,
        razorpayPaymentId: testPaymentId,
        razorpaySignature: sigGenData.signature
      })
    });
    const verifyPayData = await verifyPayRes.json();
    assert(
      verifyPayRes.status === 200 &&
      verifyPayData.order?.paymentStatus === 'paid' &&
      verifyPayData.order?.orderStatus === 'In Kitchen' &&
      verifyPayData.order?.stockDeducted === true,
      'Payment verified server-side, order advanced to In Kitchen, and stock deducted atomically'
    );

    // 14. Idempotency Check: Repeat verification must not double-deduct stock
    const repeatVerify = await fetch(`${BASE_URL}/api/payment/verify`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${customerToken}`
      },
      body: JSON.stringify({
        orderId: createdOrder.id,
        razorpayOrderId: rzpOrderData.razorpayOrderId,
        razorpayPaymentId: testPaymentId,
        razorpaySignature: sigGenData.signature
      })
    });
    assert(repeatVerify.status === 200, 'Idempotent verification prevents double-deduction on repeat calls');

    // 15. Admin Status Advance: Move from In Kitchen to Sent to Delivery
    const advanceRes = await fetch(`${BASE_URL}/api/admin/orders/${createdOrder.id}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`
      },
      body: JSON.stringify({
        newStatus: 'Sent to Delivery',
        note: 'Pizza dispatched with insulated bag rider'
      })
    });
    const advanceData = await advanceRes.json();
    assert(advanceRes.status === 200 && advanceData.order?.orderStatus === 'Sent to Delivery', 'Admin advanced order to "Sent to Delivery"');

    // 16. Automated Low-Stock Cron Audit Check
    const cronAuditRes = await fetch(`${BASE_URL}/api/admin/trigger-stock-check`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const cronAuditData = await cronAuditRes.json();
    assert(cronAuditRes.status === 200 && Array.isArray(cronAuditData.allLowStockItems), 'Scheduled low-stock inventory audit executed');

  } catch (err: any) {
    console.error('Fatal test error:', err);
    failed++;
  }

  console.log(`\n========================================`);
  console.log(`Test Results: ${passed} Passed, ${failed} Failed`);
  console.log(`========================================\n`);

  if (failed > 0) {
    process.exit(1);
  }
}

runTests();
