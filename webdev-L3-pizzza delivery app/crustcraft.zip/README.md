# CrustCraft — Full-Stack Pizza Delivery & Inventory Platform

> **“Your Crust. Your Creation.”**  
> Developed for **Oasis Infobyte Web Development & Designing Internship — Level 3, Task 1: Pizza Delivery Full-Stack Application**.

CrustCraft is a production-inspired, full-stack artisanal pizza ordering and kitchen inventory management platform. It features two dedicated experiences:

1. **Customer Experience:** Register, verify email, log in, craft bespoke pizzas with an interactive visualizer, place orders, complete test payments via Razorpay sandbox, and track pizza progress in real time.
2. **Admin Experience:** Independent admin portal (`/admin/login`), live telemetry dashboard, inventory management with atomic stock deduction, manual restock adjustments with audit logs, order pipeline progression, and scheduled low-stock email alerts.

---

## 🍕 Key Architectural Features

### 1. Customer Authentication & Security
- **Bcrypt Hashing:** Passwords hashed using `bcryptjs` with salt rounds; plaintext passwords are never stored.
- **Email Verification Tokens:** Expiring single-use tokens dispatched on registration. Unverified accounts cannot place orders until their email is confirmed.
- **Password Recovery:** Generic responses to avoid user enumeration, single-use cryptographically secure reset tokens with 1-hour expiration.
- **Strict Role Separation:** Customer registration can never select or escalate to the admin role. Admin endpoints are guarded server-side by role checks.

### 2. Interactive Custom Pizza Builder & Menu
- **Dynamic Layered SVG Visualizer:** Real-time visual feedback rendering custom dough rims, simmered sauce tones, molten cheese textures, and freshly scattered vegetables.
- **Configurable Multi-Step Progression:**
  - **Step 1 (Base):** Classic Hand-Tossed, Thin Crust (Roman), Whole Wheat, Cheese Burst, Gluten-Free.
  - **Step 2 (Sauce):** San Marzano Tomato, Spicy Arrabbiata, Pesto Genovese, Smoky Bourbon BBQ, Creamy Garlic Alfredo.
  - **Step 3 (Cheese):** Fior di Latte Mozzarella, Sharp Aged Cheddar, Parmigiano-Reggiano, Plant-Based Mozza (Dairy-Free).
  - **Step 4 (Vegetables - Multi-select):** Caramelized Red Onion, Crisp Bell Pepper, Sautéed Cremini Mushroom, Golden Sweet Corn, Spanish Black Olives, Pickled Jalapeños, Roma Tomatoes.
- **Authoritative Server Pricing:** Client-submitted prices or quantities are never trusted; the backend validates current ingredient availability and computes the true total.

### 3. Razorpay Test Mode Payment
- **Official Sandbox Flow:** Initiates order with Razorpay test credentials (`rzp_test_crustcraft_demo`).
- **Server-Side Cryptographic Signature Verification:** Verifies payment validity using HMAC SHA-256 (`crypto.createHmac('sha256', secret)`).
- **Atomic Stock Deduction:** Mutex-safe stock deduction committed only when payment signature is verified.
- **Idempotency:** Re-verification requests prevent duplicate stock deductions.

### 4. Real-Time Customer Order Tracking
- **Required Three Statuses:**
  1. `Order Received`
  2. `In Kitchen`
  3. `Sent to Delivery`
  *(plus `Delivered`)*
- **Live Status Polling:** Automatically refreshes kitchen progress every 4 seconds so customer timeline updates immediately when admin advances status.

### 5. Kitchen Operations & Inventory Management (Admin)
- **Separate Admin Route:** Accessible at `/admin/login`.
- **Pre-Seeded Master Admin Credentials:**
  - **Email:** `admin@crustcraft.com`
  - **Password:** `Admin@123456`
- **Dashboard Telemetry:** Real-time metrics for Total Orders, New Pending Orders, Orders In Kitchen, Sent to Delivery, Total Revenue, and Low-Stock Alert Items.
- **Inventory Controller:** Full CRUD across 21 kitchen ingredients with non-negative stock validation.
- **Audit Logging:** Every stock deduction (automatic order deduction) or manual adjustment is recorded with previous quantity, new quantity, delta, timestamp, and author.
- **Automated Low-Stock Email Alerts:** Scheduled `node-cron` job monitors safety replenishment thresholds (e.g., alert when pizza bases fall below 20 units).
- **Cooldown & State Tracking:** Prevents duplicate spam emails while an item remains under threshold; resets alert state after replenishment. Includes an instant **"Trigger Stock Audit & Alert Email"** button for immediate evaluation.
- **In-App Mail Outbox Viewer:** Allows inspecting dispatched email verification tokens, password reset links, and low-stock alerts without requiring external SMTP accounts.

---

## 🛠️ Technology Stack

| Layer | Technologies |
| :--- | :--- |
| **Frontend** | React 19, TypeScript, Vite, Tailwind CSS v4, Lucide Icons, Canvas Confetti |
| **Backend** | Node.js, Express.js |
| **Database** | Persistent Mongoose-compatible schema store with atomic mutex locks |
| **Authentication** | JSON Web Tokens (`jsonwebtoken`), `bcryptjs`, cryptographic tokens |
| **Payment Gateway** | Razorpay Node.js Test Mode (HMAC SHA-256 verification) |
| **Email Service** | Nodemailer (environment-configured SMTP + in-app logged outbox) |
| **Scheduled Jobs** | `node-cron` (automated inventory threshold auditing) |
| **Testing** | Automated End-to-End Test Suite (`tsx test-api.ts`) |

---

## 📂 Project Structure

```
├── .env.example              # Environment configuration template
├── package.json              # Scripts and project dependencies
├── server.ts                 # Full-stack Express server mounting APIs and Vite
├── test-api.ts               # End-to-end integration test runner
├── data/
│   └── db.json               # Seeded persistent database store
├── src/
│   ├── types/                # Core TypeScript data models & schemas
│   ├── components/           # Reusable UI components
│   │   ├── Navbar.tsx        # Top Bar Contract compliant header
│   │   ├── Footer.tsx        # Brand footer with outbox access
│   │   ├── PizzaGraphic.tsx  # Dynamic multi-layered SVG pizza visualizer
│   │   └── MailOutboxModal.tsx# In-app email inspection drawer
│   ├── context/
│   │   ├── AuthContext.tsx   # User session, JWT storage & roles
│   │   └── CartContext.tsx   # Shopping bag state & authoritative calculation
│   ├── pages/
│   │   ├── HomePage.tsx            # Hero, artisanal showcase & KPIs
│   │   ├── MenuPage.tsx            # Signature pizzas catalog
│   │   ├── CustomBuilderPage.tsx   # 4-step interactive pizza atelier
│   │   ├── CartCheckoutPage.tsx    # Order review & delivery details
│   │   ├── PaymentPage.tsx         # Razorpay sandbox payment & verification
│   │   ├── OrderTrackingPage.tsx   # Live timeline order tracker
│   │   ├── OrderHistoryPage.tsx    # Customer order log
│   │   ├── LoginPage.tsx           # Customer login
│   │   ├── RegisterPage.tsx        # Customer registration
│   │   ├── VerifyEmailPage.tsx     # Email token verification
│   │   ├── ForgotPasswordPage.tsx  # Password reset request
│   │   ├── ResetPasswordPage.tsx   # New password entry
│   │   ├── AdminLoginPage.tsx      # Independent admin login
│   │   └── admin/
│   │       ├── AdminDashboardPage.tsx # KPI telemetry & stock alert panel
│   │       ├── AdminInventoryPage.tsx # Inventory CRUD & adjustment audit logs
│   │       └── AdminOrdersPage.tsx    # Kitchen order queue & status updater
│   └── server/
│       ├── db.ts             # Thread-safe database with seed data
│       ├── routes/           # REST API routes (auth, menu, orders, payment, admin)
│       └── services/         # Auth, Email, Inventory, Cron, and Payment services
```

---

## 🚀 Setup & Local Installation

### Prerequisites
- Node.js (v18 or higher recommended)
- npm or yarn

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment Variables
Create a `.env` file in the project root:
```env
PORT=3000
APP_URL="http://localhost:3000"
JWT_SECRET="crustcraft_jwt_super_secret_key_2026"
RAZORPAY_KEY_ID="rzp_test_crustcraft_demo"
RAZORPAY_KEY_SECRET="crustcraft_rzp_secret_sandbox_2026"
CRON_SCHEDULE="0 * * * *"
```
*(Optional SMTP credentials for live external emailing: `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM`. When left blank, CrustCraft automatically logs all dispatched emails to the in-app Outbox Viewer).*

### 3. Start Development Server
```bash
npm run dev
```
The application will launch at `http://localhost:3000`.

---

## 🧪 Running Automated Tests

Run the built-in end-to-end integration test suite:
```bash
npm test
```
The test runner validates:
1. Server health check.
2. Menu availability across all 21 categorized ingredients.
3. Authoritative server price calculation.
4. Customer registration with unverified state.
5. Blocking unverified accounts from signing in.
6. Email verification token generation in the outbox.
7. Verification token redemption & user activation.
8. Server-side role protection (blocking customers from admin endpoints).
9. Admin authentication using seeded credentials.
10. Admin telemetry stats retrieval.
11. Order placement with stock validation.
12. Razorpay sandbox order creation.
13. Cryptographic HMAC SHA-256 signature verification.
14. Atomic stock deduction upon payment confirmation.
15. Idempotent payment verification preventing double deductions.
16. Admin order status progression (*Order Received* $\to$ *In Kitchen* $\to$ *Sent to Delivery* $\to$ *Delivered*).
17. Automated low-stock scheduled cron auditing.

---

## 📡 REST API Reference

| Method | Endpoint | Description | Auth Required |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/health` | Service health status | Public |
| `POST` | `/api/auth/register` | Register new customer account | Public |
| `GET` | `/api/auth/verify-email` | Verify email with token | Public |
| `POST` | `/api/auth/login` | Authenticate customer | Public |
| `POST` | `/api/auth/admin-login` | Authenticate admin | Public |
| `POST` | `/api/auth/forgot-password` | Request password reset token | Public |
| `POST` | `/api/auth/reset-password` | Update password with token | Public |
| `GET` | `/api/auth/me` | Fetch authenticated profile | Bearer Token |
| `GET` | `/api/menu/ingredients` | List categorized ingredients with live stock | Public |
| `GET` | `/api/menu/pizzas` | List signature artisanal pizzas | Public |
| `POST` | `/api/menu/calculate-price` | Server price calculation & stock check | Public |
| `POST` | `/api/orders` | Create order & validate stock | Customer Token |
| `GET` | `/api/orders/my-orders` | Fetch customer order history | Customer Token |
| `GET` | `/api/orders/:id/track` | Track live order status | Customer / Admin |
| `POST` | `/api/payment/create-order` | Create Razorpay test order | Customer Token |
| `POST` | `/api/payment/verify` | Verify HMAC signature & deduct stock | Customer Token |
| `GET` | `/api/admin/stats` | Dashboard telemetry metrics | Admin Token |
| `GET` | `/api/admin/inventory` | Inventory list & audit logs | Admin Token |
| `POST` | `/api/admin/inventory` | Add new kitchen ingredient | Admin Token |
| `POST` | `/api/admin/inventory/:id/adjust` | Adjust stock with reason log | Admin Token |
| `PATCH` | `/api/admin/inventory/:id` | Update threshold & pricing | Admin Token |
| `GET` | `/api/admin/orders` | List customer orders (with filters) | Admin Token |
| `PATCH` | `/api/admin/orders/:id/status` | Advance order kitchen pipeline | Admin Token |
| `POST` | `/api/admin/trigger-stock-check` | Execute instant low-stock audit | Admin Token |
| `GET` | `/api/outbox/recent` | View recent dispatched emails | Public / Demo |

---

## 👨‍🍳 Master Seed Account

To evaluate the Admin operations console immediately:
- **URL:** `/admin/login`
- **Email:** `admin@crustcraft.com`
- **Password:** `Admin@123456`

---

## 📄 License
This project is open-source and built for the Oasis Infobyte Internship assessment.
