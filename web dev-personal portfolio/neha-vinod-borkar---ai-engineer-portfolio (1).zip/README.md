# Neha Vinod Borkar — Personal AI Engineer Portfolio

A personal portfolio website for **Neha Vinod Borkar**, an aspiring AI Engineer and AI Agent Engineer. Built with React, TypeScript, Tailwind CSS, and lightweight interactive canvas animations.

## 🚀 Key Features

- **Personal & Academic Identity**:
  - Highlights First-Year CGPA (9.16/10) and First-Semester SGPA (9.5/10) without disclosing institutional affiliations.
  - Honest skill level presentation (Foundational, Basic, Learning, Practicing, Building, Exploring) without arbitrary percentage bars.
- **Interactive Neural Network Canvas**:
  - Real-time particle and connection network in the hero section that responds to ambient movement and cursor proximity.
- **Featured Project Showcases & Case Studies**:
  - **DecisionTrace**: AI decision-support interface and satisfaction chatbot with voice dictation (`https://decision-trace-dt.netlify.app/`).
  - **Nexora**: AI-powered student career guidance and milestone roadmap platform.
  - **Veritas-X**: AI-assisted transparent evidence breakdown with verified (green), flawed (amber), and missing (red) status badges (`https://veritas-x.netlify.app/`).
  - Detailed modal case studies with problem framing, architectural decisions, challenges, and lessons learned.
- **Milestone Timeline**:
  - 6-stage engineering roadmap tracking progression from core CS/DSA to backend APIs and applied AI workflows.
- **Printable & Viewable Resume**:
  - In-browser clean resume viewer with built-in print-to-PDF formatting.
- **Recruiter-Friendly Contact**:
  - Verified LinkedIn and GitHub shortcuts, direct email copy helper, and pre-formatted mailto dispatch.

## 🛠️ Tech Stack

- **Framework**: React 19 + TypeScript
- **Bundler & Tooling**: Vite
- **Styling**: Tailwind CSS v4
- **Icons**: Lucide React
- **Animations**: CSS Compositor Transforms & HTML5 Canvas

## 💻 Development & Build

### Install Dependencies
```bash
npm install
```

### Run Local Development Server
```bash
npm run dev
```
The application will start on `http://localhost:3000`.

### Production Build
```bash
npm run build
```

### Lint & Type Check
```bash
npm run lint
```

## ⚙️ Configuration

- Data definitions and external links are configured in `src/data/portfolioData.ts`.
- Personal links:
  - LinkedIn: `https://www.linkedin.com/in/neha-borkar-a6a6ba390/`
  - GitHub: `https://github.com/nehuub08-code`
  - Email: `borkarnehuu6@gmail.com`
