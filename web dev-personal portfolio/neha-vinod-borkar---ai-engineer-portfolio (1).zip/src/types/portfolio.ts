export interface SkillItem {
  name: string;
  stage: 'Foundational' | 'Basic' | 'Learning' | 'Practicing' | 'Building' | 'Exploring';
  experienceNote: string;
  icon?: string;
}

export interface SkillCategory {
  id: string;
  title: string;
  description: string;
  skills: SkillItem[];
}

export interface CaseStudy {
  problem: string;
  approach: string;
  implementationHighlights: string[];
  challengesAndSolutions: {
    challenge: string;
    solution: string;
  }[];
  lessonsLearned: string[];
  architectureNote?: string;
}

export interface Project {
  id: string;
  name: string;
  category: string;
  status: 'Live' | 'In Progress' | 'Planned';
  description: string;
  features: string[];
  techStack: string[];
  imagePath: string;
  liveDemoUrl?: string;
  githubUrl: string;
  caseStudy: CaseStudy;
  verifiedNotes?: string;
}

export interface LearningStage {
  stage: number;
  title: string;
  status: 'Completed' | 'In Progress' | 'Upcoming';
  description: string;
  focusAreas: string[];
}

export interface ExploringTopic {
  id: string;
  topic: string;
  objective: string;
  status: 'Actively Practicing' | 'Deepening Foundations' | 'Experimental Workflow';
  focus: string;
}

export interface AcademicHighlight {
  value: string;
  label: string;
  description: string;
}
