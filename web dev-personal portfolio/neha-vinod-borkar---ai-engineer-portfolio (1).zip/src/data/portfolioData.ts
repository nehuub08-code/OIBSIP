import { Project, SkillCategory, LearningStage, ExploringTopic, AcademicHighlight } from '../types/portfolio';

export const PERSONAL_INFO = {
  name: "Neha Vinod Borkar",
  shortName: "Neha",
  title: "Aspiring AI Engineer | AI Agent Engineer",
  education: "B.Tech in Computer Engineering, Second Year",
  location: "Maharashtra, India",
  email: "borkarnehuu6@gmail.com",
  linkedin: "https://www.linkedin.com/in/neha-borkar-a6a6ba390/",
  github: "https://github.com/nehuub08-code",
  academicStats: {
    cgpa: "9.16 / 10",
    cgpaLabel: "First-Year CGPA",
    sgpa: "9.5 / 10",
    sgpaLabel: "First-Semester SGPA",
  },
  careerGoal: "Become an industry-ready AI Engineer and AI Agent Engineer, build reliable intelligent systems, gain practical engineering experience, and secure a meaningful technical internship by the end of my second year.",
  introHeadline: "Building intelligent solutions, one experiment at a time.",
  introDescription: "I'm a Computer Engineering student exploring machine learning, AI agents, and software engineering. I enjoy turning ideas into practical projects while learning how intelligent systems work.",
  aboutText: "I'm Neha Vinod Borkar, a second-year Computer Engineering student with a strong academic foundation and a growing interest in artificial intelligence. I'm developing my skills in programming, data structures, machine learning, and AI-powered application development through hands-on practice and personal projects.\n\nMy goal is to understand how intelligent systems are designed, built, tested, and improved. I believe in learning by building, understanding the fundamentals, and turning small experiments into meaningful solutions.",
  mindset: [
    "Learn concepts deeply instead of blindly depending on AI tools.",
    "Build real projects and understand their architecture.",
    "Improve programming, problem-solving, and software engineering skills.",
    "Learn machine learning and deep learning through practical implementation.",
    "Develop AI agents, intelligent workflows, and useful AI applications.",
    "Continuously improve communication, teamwork, and interview readiness."
  ],
  myApproach: [
    { title: "Understand the fundamentals", desc: "Building solid ground in math, algorithms, and core architectures before abstractions." },
    { title: "Build practical projects", desc: "Applying newly learned patterns directly into usable software interfaces and backend endpoints." },
    { title: "Test and improve", desc: "Validating edge cases, refining logic, and measuring real behavioral outcomes." },
    { title: "Document what I learn", desc: "Writing clear technical explanations, case notes, and transparent project trade-offs." }
  ]
};

export const ACADEMIC_HIGHLIGHTS: AcademicHighlight[] = [
  {
    value: "9.16 / 10",
    label: "First-Year CGPA",
    description: "Consistent academic performance across foundational engineering and mathematics"
  },
  {
    value: "9.5 / 10",
    label: "First-Semester SGPA",
    description: "Strong initial semester foundation in computer science and basic sciences"
  },
  {
    value: "3",
    label: "Featured Portfolio Projects",
    description: "DecisionTrace, Nexora, and Veritas-X targeting real user workflows"
  },
  {
    value: "1",
    label: "Backend Authentication API Project",
    description: "FastAPI, SQLite, password hashing & JWT token security implemented locally"
  }
];

export const HERO_SKILLS = [
  { name: "Python", stage: "Basic" },
  { name: "C++", stage: "Learning & Practicing" },
  { name: "Data Structures & Algorithms", stage: "Practicing" },
  { name: "Machine Learning", stage: "Fundamentals" },
  { name: "AI Agents", stage: "Developing Knowledge" },
  { name: "FastAPI", stage: "Practical API" },
];

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    id: "programming",
    title: "Programming & Problem Solving",
    description: "Foundational languages and algorithmic thinking practiced through hands-on problem solving.",
    skills: [
      { name: "Python", stage: "Basic", experienceNote: "Core syntax, scripting, virtual environments, data structures, and script-level automation." },
      { name: "C++", stage: "Learning", experienceNote: "Object-oriented programming, standard template library (STL), and algorithmic exercises." },
      { name: "C", stage: "Foundational", experienceNote: "Pointers, memory management basics, structured modular programming." },
      { name: "Data Structures & Algorithms", stage: "Practicing", experienceNote: "Arrays, linked lists, stacks, queues, recursion, sorting, and algorithmic complexity." }
    ]
  },
  {
    id: "ai-ml",
    title: "AI & Machine Learning",
    description: "Active study of intelligent systems, machine learning fundamentals, and agentic workflows.",
    skills: [
      { name: "Machine Learning Fundamentals", stage: "Learning", experienceNote: "Supervised & unsupervised principles, regression, classification, loss functions, metrics." },
      { name: "Deep Learning Foundations", stage: "Learning", experienceNote: "Beginner learning stage: neural network architectures, backpropagation, activation functions." },
      { name: "Model Training & Evaluation", stage: "Exploring", experienceNote: "Exploring dataset splits, bias/variance trade-offs, and metrics through practical exercises." },
      { name: "NLP & Computer Vision", stage: "Exploring", experienceNote: "Areas of active interest: text processing, tokenization, embeddings, and feature extraction." },
      { name: "AI Agents & Intelligent Workflows", stage: "Building", experienceNote: "Developing knowledge in multi-step reasoning, tool execution, decision traces, and structured outputs." }
    ]
  },
  {
    id: "backend",
    title: "Backend & APIs",
    description: "Practical engineering experience building local services, database schemas, and REST endpoints.",
    skills: [
      { name: "FastAPI", stage: "Building", experienceNote: "Built a local authentication API with route modularization and automatic Swagger docs." },
      { name: "REST APIs", stage: "Practicing", experienceNote: "Practical learning of HTTP methods, status codes, query/path parameters, and JSON payloads." },
      { name: "SQLite", stage: "Building", experienceNote: "Used in project development for lightweight transactional storage and rapid prototyping." },
      { name: "PostgreSQL", stage: "Learning", experienceNote: "Currently learning relational database schemas, indexing fundamentals, and SQL queries." },
      { name: "SQLAlchemy", stage: "Learning", experienceNote: "Exposure through backend development for ORM modeling and database sessions." },
      { name: "JWT Authentication", stage: "Building", experienceNote: "Implemented password hashing with bcrypt and stateless JWT token issuance in a local API." }
    ]
  },
  {
    id: "frontend",
    title: "Frontend & Web Development",
    description: "Client-side development skills applied in project user interfaces and interactive prototypes.",
    skills: [
      { name: "HTML5 & CSS3", stage: "Foundational", experienceNote: "Semantic markup, modern layout techniques, flexbox, and responsive principles." },
      { name: "JavaScript & React", stage: "Practicing", experienceNote: "Used at the practical level demonstrated in personal portfolio projects and interactive tools." },
      { name: "Tailwind CSS", stage: "Practicing", experienceNote: "Supported by practical experience building clean, utility-driven responsive web layouts." }
    ]
  },
  {
    id: "tools",
    title: "Developer Tools & Environment",
    description: "Tools for version control, local development hygiene, and automated testing.",
    skills: [
      { name: "Git & GitHub", stage: "Practicing", experienceNote: "Commit discipline, branching, remote sync, repository management, and pull requests." },
      { name: "Linux & Bash Fundamentals", stage: "Learning", experienceNote: "Command line navigation, shell scripting basics, package management, and file systems." },
      { name: "Virtual Environments & pip", stage: "Practicing", experienceNote: "Environment isolation (venv), dependency management via requirements.txt, and packaging." },
      { name: "pytest Fundamentals", stage: "Learning", experienceNote: "Unit test structure, assertions, and test-driven sanity checks for Python code." },
      { name: "API Testing & Debugging", stage: "Practicing", experienceNote: "Interactive API testing with Postman, curl, and FastAPI interactive docs." }
    ]
  },
  {
    id: "soft-skills",
    title: "Soft Skills & Engineering Mindset",
    description: "Qualities that foster effective collaboration, technical clarity, and personal growth.",
    skills: [
      { name: "Problem-Solving Mindset", stage: "Practicing", experienceNote: "Breaking complex assignments into verifiable sub-problems before writing code." },
      { name: "Continuous Learning", stage: "Practicing", experienceNote: "Relentless curiosity to learn fundamentals deeply rather than relying blindly on tools." },
      { name: "Technical Communication", stage: "Practicing", experienceNote: "Explaining architectural reasoning, trade-offs, and project findings concisely." },
      { name: "Project Presentation & Docs", stage: "Practicing", experienceNote: "Writing honest READMEs, clean documentation, and well-structured case studies." },
      { name: "Collaboration & Adaptability", stage: "Practicing", experienceNote: "Receptive to feedback, eager to learn from peers, and quick to adapt to new workflows." }
    ]
  }
];

export const FEATURED_PROJECTS: Project[] = [
  {
    id: "decision-trace",
    name: "DecisionTrace",
    category: "AI Decision Support & Interactive Chatbot",
    status: "Live",
    description: "DecisionTrace is a decision-support project designed to make decision-making more understandable through structured decision traces and an interactive, friend-style satisfaction chatbot.",
    features: [
      "Decision-trace visual interface mapping step-by-step choice trajectories",
      "Conversational satisfaction chatbot with a friendly tone and natural emojis",
      "Voice input support for hands-free queries and conversational responses",
      "Interactive user experience providing confidence metrics and follow-up prompts"
    ],
    techStack: ["React", "JavaScript", "Tailwind CSS", "Web Speech API", "Decision Graph Logic"],
    imagePath: "/src/assets/images/project_decision_trace_preview_1793296083881.jpg",
    liveDemoUrl: "https://decision-trace-dt.netlify.app/",
    githubUrl: "https://github.com/nehuub08-code",
    verifiedNotes: "Verified live deployment on Netlify. Chatbot provides supportive, friendly feedback with voice input interaction.",
    caseStudy: {
      problem: "Decision-making tools are often either too complex and clinical, or provide arbitrary answers without giving users a clear reasoning trace or an approachable sounding board.",
      approach: "Built a structured decision exploration tool coupled with a friendly satisfaction assistant that combines visual trace trees with intuitive conversational reassurance.",
      architectureNote: "Client-side React state machine managing branching trace paths with an integrated Web Speech API layer for voice input and an empathetic response synthesis pipeline.",
      implementationHighlights: [
        "Interactive node graph displaying decision nodes, priority levels, and confidence estimations.",
        "Voice input processing using native browser Web Speech API for seamless audio dictation.",
        "Friendly assistant persona with contextual emoji reactions that helps users reflect on choice satisfaction.",
        "Responsive multi-pane layout balancing graphical trace visualization and chat interaction."
      ],
      challengesAndSolutions: [
        {
          challenge: "Ensuring voice input operates smoothly across various browser speech recognition implementations.",
          solution: "Implemented graceful feature detection with fallback to standard keyboard input and clear mic permission cues."
        },
        {
          challenge: "Balancing analytical decision breakdown with an encouraging, approachable tone.",
          solution: "Separated the formal decision node tree from the informal conversational assistant so users get both structured clarity and empathetic reflection."
        }
      ],
      lessonsLearned: [
        "User experience in AI tools heavily depends on transparency: showing why an option is recommended is far more valuable than an opaque score.",
        "Voice interactions require clear visual state indicators (listening, processing, error) to build user confidence.",
        "Modular state management simplifies expanding decision branch trees."
      ]
    }
  },
  {
    id: "nexora",
    name: "Nexora",
    category: "AI-Powered Career Guidance Platform",
    status: "In Progress",
    description: "Nexora is a developing career guidance platform intended to help students move from understanding their current skills to building projects, preparing for interviews, and working toward internship opportunities.",
    features: [
      "Personalized onboarding module assessing current skills and engineering interests",
      "Career discovery and specialization goal selection (Backend, AI/ML, Full-Stack)",
      "Personalized learning roadmaps with progressive milestone checkpoints",
      "Modular learning and project guidance paired with practical repository suggestions",
      "Interview preparation and soft-skill development practice questions",
      "Internship & job search readiness checklists and milestone progress tracking"
    ],
    techStack: ["React", "TypeScript", "Tailwind CSS", "FastAPI (Planned)", "SQLite / PostgreSQL"],
    imagePath: "/src/assets/images/project_nexora_preview_1793296084848.jpg",
    githubUrl: "https://github.com/nehuub08-code",
    verifiedNotes: "Active developing platform. Core UI onboarding, skill diagnostic workflows, and roadmap blueprints are implemented; backend integration is in active progress.",
    caseStudy: {
      problem: "Early engineering students often feel overwhelmed by fragmented online advice, lack clarity on their current skill baseline, and don't know what concrete projects lead to internships.",
      approach: "Architecting a step-by-step career companion that diagnoses a student's actual current stage and builds an actionable roadmap linking theory, project milestones, and interview prep.",
      architectureNote: "Modular UI architecture designed to integrate with a FastAPI backend service powering student skill profiles and dynamic roadmaps.",
      implementationHighlights: [
        "Structured skills assessment onboarding capturing technical confidence across multiple domains.",
        "Dynamic milestone timeline generator breaking multi-month goals into digestible weekly checkpoints.",
        "Separate modules planned for technical questions, behavioral practice, and portfolio curation.",
        "Clear distinction between implemented client workflows and upcoming backend API endpoints."
      ],
      challengesAndSolutions: [
        {
          challenge: "Preventing over-promising on automated AI career advice while the backend AI service is being developed.",
          solution: "Maintained complete honesty in the product state: frontend roadmap visualizer is fully functional while backend dynamic generation is clearly tagged as in-progress."
        },
        {
          challenge: "Structuring student roadmaps so they are neither demoralizingly long nor unrealistically brief.",
          solution: "Segmented the path into distinct phases: Foundations -> Specialization -> Portfolio Building -> Internship Preparation."
        }
      ],
      lessonsLearned: [
        "Building a platform incrementally requires strong domain scoping before writing backend code.",
        "Designing clear data contracts early (e.g. roadmap node schemas) makes backend integration much smoother.",
        "Student platforms must celebrate incremental progress to maintain consistency."
      ]
    }
  },
  {
    id: "veritas-x",
    name: "Veritas-X",
    category: "AI-Assisted Evidence Verification",
    status: "Live",
    description: "Veritas-X is a project focused on making evidence assessment more transparent by presenting claim-related evidence and highlighting verification outcomes.",
    features: [
      "Evidence breakdown interface clearly categorizing claim outcomes into Verified, Bypassed / Flawed, and Missing",
      "Three-tier color-coded verification status: Verified (Green), Bypassed / Flawed (Amber), Missing (Red)",
      "Source citation breakdown linking claims to peer-reviewed studies, reports, and reputable news outlets",
      "Transparent audit trail designed to make evidence gaps identifiable without misleading certainty claims"
    ],
    techStack: ["React", "JavaScript", "Tailwind CSS", "Evidence Classification Rules", "REST API Integration"],
    imagePath: "/src/assets/images/project_veritas_x_preview_1793296085454.jpg",
    liveDemoUrl: "https://veritas-x.netlify.app/",
    githubUrl: "https://github.com/nehuub08-code",
    verifiedNotes: "Verified live deployment on Netlify. Explicitly designed to highlight verification gaps rather than claiming universal infallibility.",
    caseStudy: {
      problem: "Automated verification tools often present a binary 'True' or 'False' verdict without revealing missing evidence, conflicting datasets, or unsupported leaps in logic.",
      approach: "Created a transparent verification breakdown interface that highlights source completeness and categorizes claims into Verified, Bypassed/Flawed, or Missing evidence.",
      architectureNote: "Evidence evaluation pipeline presenting source citations, verification status badges, and expandable analyst notes for each individual claim item.",
      implementationHighlights: [
        "Three-state evidence status indicators: Green (Verified), Amber (Bypassed / Flawed Notice), Red (Missing Evidence).",
        "Source citation drawer displaying document types (peer-reviewed papers, official releases, news outlets).",
        "Clear disclaimer model ensuring users understand the system assists human evaluation without claiming absolute truth.",
        "Streamlined audit queue for rapid review of claim verification batches."
      ],
      challengesAndSolutions: [
        {
          challenge: "Avoiding false certainty where partial evidence exists for a nuanced claim.",
          solution: "Introduced the 'Bypassed / Flawed' amber state specifically for claims with conflicting datasets or methodological gaps."
        },
        {
          challenge: "Designing an interface that remains scannable when displaying multiple dense claim citations.",
          solution: "Organized claims in clean table rows with expandable source drawers, keeping high-level stats visible at the top."
        }
      ],
      lessonsLearned: [
        "Responsible AI engineering means communicating uncertainty and gaps rather than projecting false confidence.",
        "Visual hierarchy in data verification is crucial: color coding must always be supported by clear textual labels.",
        "Building tools that facilitate human oversight is often more impactful than trying to fully automate subjective judgments."
      ]
    }
  }
];

export const LEARNING_STAGES: LearningStage[] = [
  {
    stage: 1,
    title: "Programming Foundations",
    status: "Completed",
    description: "Built core algorithmic thinking, control flow, functions, and structured programming in Python, C, and C++.",
    focusAreas: [
      "Python syntax, basic scripting & virtual environment setups",
      "C memory fundamentals, pointers & structured logic",
      "C++ object-oriented principles & standard libraries"
    ]
  },
  {
    stage: 2,
    title: "DSA & Computer Science Concepts",
    status: "In Progress",
    description: "Deepening practical understanding of fundamental data structures, algorithm efficiency, and problem solving.",
    focusAreas: [
      "Arrays, linked lists, stacks, queues & recursion",
      "Searching & sorting algorithm implementations",
      "Time and space complexity (Big-O analysis)"
    ]
  },
  {
    stage: 3,
    title: "Software Engineering Foundations",
    status: "Completed",
    description: "Adopting professional developer workflows, version control hygiene, and command-line agility.",
    focusAreas: [
      "Git branching, commit discipline & GitHub workflows",
      "Linux environment navigation & Bash automation basics",
      "Virtual environment hygiene & dependency isolation with pip"
    ]
  },
  {
    stage: 4,
    title: "Backend Development & APIs",
    status: "Completed",
    description: "Built and documented a local authentication API, learning real backend protocols and security best practices.",
    focusAreas: [
      "FastAPI routing, request validation & Pydantic models",
      "Password hashing (bcrypt) & stateless JWT token security",
      "SQLite transactional database operations & API documentation"
    ]
  },
  {
    stage: 5,
    title: "AI Engineering & Machine Learning",
    status: "In Progress",
    description: "Studying foundational machine learning theory, neural network architectures, and practical model training.",
    focusAreas: [
      "Supervised & unsupervised learning mathematical foundations",
      "Model training, evaluation metrics, and overfitting/underfitting",
      "AI agent architectures, tool calling, and multi-step reasoning"
    ]
  },
  {
    stage: 6,
    title: "Building & Improving Applied Projects",
    status: "In Progress",
    description: "Turning learning into tangible software projects: DecisionTrace, Nexora, and Veritas-X.",
    focusAreas: [
      "Engineering full-stack and frontend interactive web prototypes",
      "Iterating based on actual usability, testing edge cases & documenting lessons",
      "Preparing for technical internships through real project evidence"
    ]
  }
];

export const CURRENTLY_EXPLORING: ExploringTopic[] = [
  {
    id: "ml-foundations",
    topic: "Machine Learning Fundamentals",
    objective: "Mastering mathematical intuition behind gradient descent, cost functions, and classical algorithms.",
    status: "Deepening Foundations",
    focus: "Mathematics & Supervised Learning"
  },
  {
    id: "model-training",
    topic: "Model Training & Evaluation",
    objective: "Hands-on exercises with train/test splits, cross-validation, precision, recall, and F1-score interpretation.",
    status: "Actively Practicing",
    focus: "Practical ML Exercises"
  },
  {
    id: "deep-learning",
    topic: "Deep Learning Foundations",
    objective: "Understanding perceptrons, multi-layer neural networks, backpropagation, and loss surfaces.",
    status: "Deepening Foundations",
    focus: "Neural Networks & Math"
  },
  {
    id: "ai-agents",
    topic: "AI Agent Workflows & Decision Traces",
    objective: "Studying multi-step tool execution, reasoning loops, prompt structuring, and output schema validation.",
    status: "Experimental Workflow",
    focus: "Agentic Systems"
  },
  {
    id: "backend-apis",
    topic: "Backend Engineering & API Design",
    objective: "Expanding from local FastAPI authentication to relational schema design with PostgreSQL and SQLAlchemy.",
    status: "Actively Practicing",
    focus: "FastAPI + PostgreSQL"
  },
  {
    id: "dsa-practice",
    topic: "Data Structures & Algorithms",
    objective: "Daily problem-solving practice on core patterns like two pointers, sliding windows, and recursion trees.",
    status: "Actively Practicing",
    focus: "Problem Solving"
  },
  {
    id: "communication",
    topic: "Communication & Technical Interviews",
    objective: "Articulating architectural trade-offs, code walkthroughs, and preparing for second-year internships.",
    status: "Actively Practicing",
    focus: "Professional Readiness"
  }
];
