import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AcademicStrip } from './components/AcademicStrip';
import { AboutSection } from './components/AboutSection';
import { SkillsSection } from './components/SkillsSection';
import { ProjectsSection } from './components/ProjectsSection';
import { LearningJourney } from './components/LearningJourney';
import { CurrentlyLearning } from './components/CurrentlyLearning';
import { ResumeSection } from './components/ResumeSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ResumeModal } from './components/ResumeModal';

export default function App() {
  const [resumeModalOpen, setResumeModalOpen] = useState(false);

  const scrollToProjects = () => {
    const el = document.getElementById('projects');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToContact = () => {
    const el = document.getElementById('contact');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#070B19] text-slate-100 flex flex-col font-sans selection:bg-violet-600 selection:text-white">
      {/* Sticky Top Navigation */}
      <Navbar onOpenResume={() => setResumeModalOpen(true)} />

      {/* Main Content Area */}
      <main className="flex-grow">
        {/* Hero Section */}
        <Hero
          onExploreProjects={scrollToProjects}
          onConnect={scrollToContact}
          onOpenResume={() => setResumeModalOpen(true)}
        />

        {/* Academic Highlights & Stats Strip */}
        <AcademicStrip />

        {/* About Me Section (Light visual accent) */}
        <AboutSection />

        {/* Technical Toolkit & Skills Section */}
        <SkillsSection />

        {/* Featured Projects Section (Light visual accent with dark previews) */}
        <ProjectsSection />

        {/* Learning Journey Timeline */}
        <LearningJourney />

        {/* Currently Exploring / Active Learning Section */}
        <CurrentlyLearning />

        {/* Resume Overview & Download Area */}
        <ResumeSection onOpenResume={() => setResumeModalOpen(true)} />

        {/* Contact & LinkedIn Section */}
        <ContactSection />
      </main>

      {/* Minimal Footer */}
      <Footer />

      {/* Full Screen Resume Previewer Modal */}
      <ResumeModal
        isOpen={resumeModalOpen}
        onClose={() => setResumeModalOpen(false)}
      />
    </div>
  );
}
