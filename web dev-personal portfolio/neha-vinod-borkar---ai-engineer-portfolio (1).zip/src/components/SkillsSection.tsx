import React, { useState } from 'react';
import { SKILL_CATEGORIES } from '../data/portfolioData';
import { Terminal, BrainCircuit, Database, Layout, Wrench, HeartHandshake } from 'lucide-react';

export const SkillsSection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categoryIcons: Record<string, React.ReactNode> = {
    programming: <Terminal className="w-4 h-4 text-violet-400" />,
    'ai-ml': <BrainCircuit className="w-4 h-4 text-cyan-400" />,
    backend: <Database className="w-4 h-4 text-indigo-400" />,
    frontend: <Layout className="w-4 h-4 text-emerald-400" />,
    tools: <Wrench className="w-4 h-4 text-amber-400" />,
    'soft-skills': <HeartHandshake className="w-4 h-4 text-pink-400" />,
  };

  const getStageBadgeStyle = (stage: string) => {
    switch (stage) {
      case 'Building':
        return 'text-emerald-400 bg-emerald-950/40 border-emerald-800/60';
      case 'Practicing':
        return 'text-cyan-400 bg-cyan-950/40 border-cyan-800/60';
      case 'Learning':
        return 'text-violet-400 bg-violet-950/40 border-violet-800/60';
      case 'Exploring':
        return 'text-amber-400 bg-amber-950/40 border-amber-800/60';
      case 'Foundational':
        return 'text-slate-400 bg-slate-900 border-slate-700/60';
      default:
        return 'text-indigo-400 bg-indigo-950/40 border-indigo-800/60';
    }
  };

  const filteredCategories = selectedCategory === 'all'
    ? SKILL_CATEGORIES
    : SKILL_CATEGORIES.filter((cat) => cat.id === selectedCategory);

  return (
    <section id="skills" className="py-24 bg-[#070B19] text-white border-b border-slate-800 relative">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="text-xs font-bold tracking-widest uppercase text-cyan-400 mb-2">
              Capabilities & Practical Exposure
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
              My Technical Toolkit
            </h2>
            <p className="text-sm sm:text-base text-slate-400 mt-2 max-w-xl">
              An honest representation of what I know, build with, and actively study. No arbitrary percentages.
            </p>
          </div>

          {/* Category Filter Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-900/90 rounded-xl border border-slate-800 self-start md:self-auto">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                selectedCategory === 'all'
                  ? 'bg-violet-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              All Skills
            </button>
            {SKILL_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                  selectedCategory === cat.id
                    ? 'bg-violet-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {cat.title.split(' ')[0]}
              </button>
            ))}
          </div>
        </div>

        {/* Categories Grid */}
        <div className="space-y-12">
          {filteredCategories.map((category) => (
            <div key={category.id} className="space-y-4">
              {/* Category Header */}
              <div className="flex items-center gap-2.5 pb-2 border-b border-slate-800/80">
                <div className="p-1.5 rounded-lg bg-slate-900 border border-slate-800">
                  {categoryIcons[category.id] || <Terminal className="w-4 h-4 text-violet-400" />}
                </div>
                <h3 className="text-lg font-bold text-slate-100">
                  {category.title}
                </h3>
                <span className="text-slate-600 hidden sm:inline" aria-hidden="true">·</span>
                <span className="text-xs text-slate-400 hidden sm:inline">
                  {category.description}
                </span>
              </div>

              {/* Skills Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {category.skills.map((skill) => (
                  <div
                    key={skill.name}
                    className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/90 hover:border-slate-700 hover:bg-slate-900 transition-all duration-200 flex flex-col justify-between group"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <h4 className="text-sm font-semibold text-white group-hover:text-cyan-300 transition-colors">
                          {skill.name}
                        </h4>
                        <span
                          className={`text-[10px] font-mono px-2 py-0.5 rounded-md border font-medium whitespace-nowrap ${getStageBadgeStyle(
                            skill.stage
                          )}`}
                        >
                          {skill.stage}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        {skill.experienceNote}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
