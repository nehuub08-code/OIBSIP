import React from 'react';
import { FileText, Eye, Printer, Award, CheckCircle2, ArrowUpRight } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface ResumeSectionProps {
  onOpenResume: () => void;
}

export const ResumeSection: React.FC<ResumeSectionProps> = ({ onOpenResume }) => {
  return (
    <section className="py-20 bg-gradient-to-b from-[#F0F4FF] to-white text-slate-900 border-b border-slate-200">
      <div className="max-w-6xl mx-auto px-6">
        <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 shadow-xl relative overflow-hidden">
          {/* Subtle gradient background mesh */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-violet-600/20 via-indigo-600/10 to-transparent rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Column: Description & Value proposition */}
            <div className="lg:col-span-8">
              <div className="text-xs font-bold tracking-widest uppercase text-violet-400 mb-2">
                Curriculum Vitae
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-3">
                A Little More About My Journey
              </h2>
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed mb-6 max-w-2xl">
                Explore my technical background, academic achievements, projects, and current learning journey in an easy-to-review format tailored for technical recruiters and engineering mentors.
              </p>

              {/* Highlights pills/list */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300 mb-8">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>First-Year Academic Distinction ({PERSONAL_INFO.academicStats.cgpa})</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Verified Project Repositories & Live Demos</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Transparent Skill Stages (No Inflatation)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>FastAPI, REST & AI Agent Experiments</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-4">
                <button
                  onClick={onOpenResume}
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 rounded-xl shadow-lg shadow-violet-950/60 transition-all active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-violet-400"
                >
                  <Eye className="w-4 h-4" />
                  <span>View Resume</span>
                </button>

                <button
                  onClick={onOpenResume}
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-all active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-slate-700"
                >
                  <FileText className="w-4 h-4" />
                  <span>Print / Save as PDF</span>
                </button>
              </div>
            </div>

            {/* Right Column: Mini Document Card Preview */}
            <div className="lg:col-span-4 flex justify-center">
              <div
                onClick={onOpenResume}
                className="w-full max-w-[280px] bg-slate-950/80 border border-slate-800 rounded-2xl p-5 cursor-pointer hover:border-violet-500/50 hover:bg-slate-900 transition-all group"
              >
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs">
                  <span className="font-mono text-slate-400">RESUME.pdf</span>
                  <span className="text-violet-400 group-hover:translate-x-0.5 transition-transform">
                    <ArrowUpRight className="w-4 h-4" />
                  </span>
                </div>
                <div className="py-4 space-y-2">
                  <div className="h-3 bg-slate-800 rounded w-3/4" />
                  <div className="h-2 bg-slate-850 rounded w-full" />
                  <div className="h-2 bg-slate-850 rounded w-5/6" />
                  <div className="h-2 bg-slate-850 rounded w-2/3" />
                </div>
                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Click to expand full CV</span>
                  <span className="text-cyan-400 font-mono">1 Page</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
