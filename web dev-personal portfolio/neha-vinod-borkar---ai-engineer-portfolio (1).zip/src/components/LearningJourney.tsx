import React from 'react';
import { CheckCircle2, Clock, Sparkles } from 'lucide-react';
import { LEARNING_STAGES } from '../data/portfolioData';

export const LearningJourney: React.FC = () => {
  return (
    <section id="journey" className="py-24 bg-[#070B19] text-white border-b border-slate-800 relative">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="text-xs font-bold tracking-widest uppercase text-cyan-400 mb-2">
            Engineering Milestones
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white mb-4 text-balance">
            Learning in Public. Building With Purpose.
          </h2>
          <p className="text-base sm:text-lg text-slate-400 leading-relaxed">
            A transparent timeline of how my technical foundations have evolved from core programming and DSA to backend APIs and applied AI systems.
          </p>
        </div>

        {/* Timeline Grid */}
        <div className="relative border-l border-slate-800 ml-3 sm:ml-6 pl-6 sm:pl-8 space-y-12">
          {LEARNING_STAGES.map((item) => {
            const isCompleted = item.status === 'Completed';
            return (
              <div key={item.stage} className="relative group">
                {/* Timeline Node Point */}
                <div
                  className={`absolute -left-[31px] sm:-left-[39px] top-1.5 w-7 h-7 rounded-full flex items-center justify-center border-2 transition-transform duration-300 group-hover:scale-110 ${
                    isCompleted
                      ? 'bg-emerald-950 border-emerald-500 text-emerald-400 shadow-sm shadow-emerald-950'
                      : 'bg-violet-950 border-violet-500 text-violet-300 shadow-sm shadow-violet-950'
                  }`}
                >
                  {isCompleted ? (
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  ) : (
                    <Clock className="w-3.5 h-3.5" />
                  )}
                </div>

                {/* Content Card */}
                <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-slate-700 transition-colors">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-violet-400">
                        STAGE 0{item.stage}
                      </span>
                      <span className="text-slate-600" aria-hidden="true">·</span>
                      <h3 className="text-lg font-bold text-white">
                        {item.title}
                      </h3>
                    </div>

                    <span
                      className={`text-[11px] font-mono px-2.5 py-0.5 rounded-full font-medium ${
                        isCompleted
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/60'
                          : 'bg-violet-950/60 text-violet-300 border border-violet-800/60'
                      }`}
                    >
                      {item.status}
                    </span>
                  </div>

                  <p className="text-sm text-slate-300 leading-relaxed mb-4">
                    {item.description}
                  </p>

                  <div className="space-y-1.5 pt-3 border-t border-slate-800/60">
                    <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      Core Focus & Outcomes:
                    </div>
                    {item.focusAreas.map((area, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-slate-300">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                        <span>{area}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
