import React, { useEffect } from 'react';
import { X, Printer, Download, ExternalLink, Mail, MapPin, Award } from 'lucide-react';
import { PERSONAL_INFO, FEATURED_PROJECTS, SKILL_CATEGORIES } from '../data/portfolioData';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="resume-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-white text-slate-900 rounded-2xl shadow-2xl overflow-hidden my-6 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Controls Bar */}
        <div className="flex items-center justify-between px-6 py-3.5 bg-slate-900 text-white shrink-0 no-print">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
            <span className="text-xs font-semibold tracking-wide">
              Resume Preview — Neha Vinod Borkar
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-violet-600 hover:bg-violet-500 text-white rounded-lg transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save as PDF</span>
            </button>
            <button
              onClick={onClose}
              aria-label="Close resume viewer"
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Resume Document Canvas */}
        <div className="p-8 sm:p-12 overflow-y-auto space-y-8 bg-white font-sans text-slate-800">
          {/* Header */}
          <div className="border-b border-slate-200 pb-6">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
              <div>
                <h1 id="resume-title" className="text-3xl font-extrabold text-slate-900 tracking-tight">
                  {PERSONAL_INFO.name}
                </h1>
                <p className="text-base font-semibold text-violet-700 mt-0.5">
                  {PERSONAL_INFO.title}
                </p>
                <p className="text-xs text-slate-500 mt-1 max-w-xl">
                  {PERSONAL_INFO.careerGoal}
                </p>
              </div>

              <div className="text-xs text-slate-600 space-y-1 sm:text-right shrink-0">
                <div className="flex items-center sm:justify-end gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{PERSONAL_INFO.location}</span>
                </div>
                <div className="flex items-center sm:justify-end gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <a href={`mailto:${PERSONAL_INFO.email}`} className="text-violet-700 hover:underline">
                    {PERSONAL_INFO.email}
                  </a>
                </div>
                <div className="flex items-center sm:justify-end gap-2 text-violet-700 pt-1">
                  <a href={PERSONAL_INFO.linkedin} target="_blank" rel="noreferrer noopener" className="hover:underline">
                    LinkedIn
                  </a>
                  <span>·</span>
                  <a href={PERSONAL_INFO.github} target="_blank" rel="noreferrer noopener" className="hover:underline">
                    GitHub
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Education & Academic Highlights */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-200 pb-1 mb-3">
              Education & Academic Highlights
            </h2>
            <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  {PERSONAL_INFO.education}
                </h3>
                <p className="text-xs text-slate-600">
                  Core curriculum in Data Structures, Algorithms, Computer Architecture, Discrete Mathematics & Programming.
                </p>
              </div>
              <div className="text-xs font-mono font-bold text-violet-700 whitespace-nowrap">
                CGPA: {PERSONAL_INFO.academicStats.cgpa} · SGPA (Sem 1): {PERSONAL_INFO.academicStats.sgpa}
              </div>
            </div>
          </div>

          {/* Technical Skills */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-200 pb-1 mb-3">
              Technical Skills & Practical Competencies
            </h2>
            <div className="space-y-2.5 text-xs text-slate-700">
              <div>
                <strong className="text-slate-900">Programming & Problem Solving:</strong>{' '}
                Python (Basic), C++ (Learning & Practicing), C (Foundational), Data Structures and Algorithms.
              </div>
              <div>
                <strong className="text-slate-900">AI & Machine Learning:</strong>{' '}
                Machine Learning fundamentals, Deep Learning foundations, Model training & evaluation exercises, AI agent architectures & tool execution.
              </div>
              <div>
                <strong className="text-slate-900">Backend & Databases:</strong>{' '}
                FastAPI (Built local authentication API with JWT & bcrypt), REST APIs, SQLite, PostgreSQL (learning), SQLAlchemy.
              </div>
              <div>
                <strong className="text-slate-900">Web & Development Tools:</strong>{' '}
                HTML5, CSS3, JavaScript, React, Tailwind CSS, Git, GitHub, Linux/Bash, virtual environments (venv/pip), pytest basics.
              </div>
            </div>
          </div>

          {/* Featured Projects */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-200 pb-1 mb-3">
              Featured Engineering Projects
            </h2>
            <div className="space-y-4">
              {FEATURED_PROJECTS.map((proj) => (
                <div key={proj.id} className="text-xs">
                  <div className="flex flex-wrap items-baseline justify-between gap-1 mb-1">
                    <div className="font-bold text-slate-900 text-sm">
                      {proj.name} — <span className="font-normal text-slate-600">{proj.category}</span>
                    </div>
                    <div className="font-mono text-[11px] text-slate-500">
                      {proj.techStack.slice(0, 3).join(', ')}
                    </div>
                  </div>
                  <p className="text-slate-700 leading-relaxed mb-1.5">
                    {proj.description}
                  </p>
                  <ul className="list-disc list-inside space-y-0.5 text-slate-600">
                    {proj.features.slice(0, 2).map((feat, fIdx) => (
                      <li key={fIdx}>{feat}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Practical Backend Exposure */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-200 pb-1 mb-2">
              Practical Engineering Projects
            </h2>
            <div className="text-xs">
              <div className="font-bold text-slate-900">Local Authentication REST API (FastAPI)</div>
              <p className="text-slate-600 mt-0.5">
                Developed a standalone modular authentication microservice in Python utilizing FastAPI, SQLite, bcrypt password hashing, and stateless JWT token issuance. Configured automated Swagger documentation and manual endpoint verification.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
