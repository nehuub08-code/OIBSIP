import React from 'react';
import { ACADEMIC_HIGHLIGHTS } from '../data/portfolioData';

export const AcademicStrip: React.FC = () => {
  return (
    <section className="relative z-20 border-y border-slate-800 bg-[#0A0E22]/90 backdrop-blur-md">
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8 divide-y md:divide-y-0 md:divide-x divide-slate-800/80">
          {ACADEMIC_HIGHLIGHTS.map((item, index) => (
            <div
              key={item.label}
              className={`flex flex-col ${index !== 0 ? 'pt-4 md:pt-0 md:pl-6 lg:pl-8' : ''}`}
            >
              <div className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight font-mono tabular-nums bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent mb-1">
                {item.value}
              </div>
              <div className="text-xs font-semibold text-violet-300 tracking-wide uppercase mb-1">
                {item.label}
              </div>
              <div className="text-xs text-slate-400 leading-snug">
                {item.description}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
