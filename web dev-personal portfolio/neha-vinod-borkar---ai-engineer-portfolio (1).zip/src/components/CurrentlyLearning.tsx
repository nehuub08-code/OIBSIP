import React from 'react';
import { Compass, Sparkles, BookOpenCheck, ArrowRight } from 'lucide-react';
import { CURRENTLY_EXPLORING } from '../data/portfolioData';

export const CurrentlyLearning: React.FC = () => {
  return (
    <section className="py-20 bg-gradient-to-b from-[#070B19] to-[#0A0F24] text-white border-b border-slate-800">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12">
          <div>
            <div className="text-xs font-bold tracking-widest uppercase text-violet-400 mb-2 flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-cyan-400" />
              <span>Active Horizon</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              What I'm Exploring Now
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              Curated topics actively on my desk this semester, combining theoretical study with hands-on coding.
            </p>
          </div>

          <div className="text-xs text-slate-500 font-mono">
            Updated for 2nd Year B.Tech
          </div>
        </div>

        {/* Interactive Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {CURRENTLY_EXPLORING.map((item) => (
            <div
              key={item.id}
              className="p-5 rounded-2xl bg-slate-900/50 border border-slate-800/80 hover:border-violet-500/50 hover:bg-slate-900/80 transition-all duration-200 flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="text-[11px] font-mono text-cyan-400 font-medium tracking-wide">
                    {item.focus}
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700/60">
                    {item.status}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white mb-2 group-hover:text-violet-300 transition-colors">
                  {item.topic}
                </h3>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {item.objective}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-500 font-medium">
                <span>Practicing weekly</span>
                <span className="w-1.5 h-1.5 rounded-full bg-violet-400 opacity-60" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
