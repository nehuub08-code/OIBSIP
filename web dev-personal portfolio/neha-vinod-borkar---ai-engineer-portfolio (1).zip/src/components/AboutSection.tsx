import React from 'react';
import { BookOpen, Target, Compass, CheckCircle2 } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-gradient-to-b from-[#FAF5FF] via-white to-[#F0F4FF] text-slate-900 border-b border-slate-200">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="text-xs font-bold tracking-widest uppercase text-violet-700 mb-2">
            About Me
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 mb-6 text-balance">
            A Curious Mind. A Builder's Journey.
          </h2>
          <div className="space-y-4 text-base sm:text-lg text-slate-700 leading-relaxed">
            <p>
              I'm <strong className="text-slate-900 font-semibold">{PERSONAL_INFO.name}</strong>, a second-year Computer Engineering student with a strong academic foundation and a growing interest in artificial intelligence. I'm developing my skills in programming, data structures, machine learning, and AI-powered application development through hands-on practice and personal projects.
            </p>
            <p>
              My goal is to understand how intelligent systems are designed, built, tested, and improved. I believe in learning by building, understanding the fundamentals, and turning small experiments into meaningful solutions.
            </p>
          </div>
        </div>

        {/* 3 Compact Information Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {/* Card 1: Academic Foundation */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-xl bg-violet-100 text-violet-700 flex items-center justify-center mb-4">
              <BookOpen className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-semibold tracking-wide uppercase text-slate-500 mb-1">
              1. Academic Foundation
            </h3>
            <div className="text-xl font-bold text-slate-900 mb-2">
              CGPA: {PERSONAL_INFO.academicStats.cgpa}
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Consistently strong first-year results ({PERSONAL_INFO.academicStats.sgpa} First-Semester SGPA) with deep interest in computing core theory.
            </p>
          </div>

          {/* Card 2: Current Focus */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center mb-4">
              <Target className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-semibold tracking-wide uppercase text-slate-500 mb-1">
              2. Current Focus
            </h3>
            <div className="text-xl font-bold text-slate-900 mb-2">
              AI Engineering & Agents
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Machine learning fundamentals, model evaluation, decision-trace systems, and building agentic workflows with clean APIs.
            </p>
          </div>

          {/* Card 3: Career Goal */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-xl bg-cyan-100 text-cyan-800 flex items-center justify-center mb-4">
              <Compass className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-semibold tracking-wide uppercase text-slate-500 mb-1">
              3. Career Goal
            </h3>
            <div className="text-xl font-bold text-slate-900 mb-2">
              Internship Readiness
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Acquiring industry-ready engineering skills and securing a meaningful technical internship by the end of second year.
            </p>
          </div>
        </div>

        {/* "My Approach" Area */}
        <div className="rounded-2xl bg-slate-900 text-white p-8 sm:p-10 shadow-xl border border-slate-800 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-violet-600/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10">
            <div className="text-xs font-bold tracking-widest uppercase text-violet-400 mb-2">
              Methodology
            </div>
            <h3 className="text-2xl font-bold text-white mb-6">
              My Engineering Approach
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {PERSONAL_INFO.myApproach.map((item, index) => (
                <div key={item.title} className="flex flex-col space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-violet-950 border border-violet-700/60 text-violet-300 font-mono text-xs flex items-center justify-center font-bold shrink-0">
                      0{index + 1}
                    </span>
                    <h4 className="text-sm font-bold text-slate-100">
                      {item.title}
                    </h4>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed pl-8">
                    {item.desc}
                  </p>
                </div>
              ))}
            </div>

            {/* Mindset bullets */}
            <div className="mt-8 pt-8 border-t border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-300">
              {PERSONAL_INFO.mindset.slice(0, 4).map((mindsetItem) => (
                <div key={mindsetItem} className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>{mindsetItem}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
