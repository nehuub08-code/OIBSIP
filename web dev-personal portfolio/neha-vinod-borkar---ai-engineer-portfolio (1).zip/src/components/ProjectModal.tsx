import React, { useEffect } from 'react';
import { X, ExternalLink, Github, CheckCircle2, AlertTriangle, AlertCircle, Sparkles, ShieldAlert } from 'lucide-react';
import { Project } from '../types/portfolio';

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (project) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [project, onClose]);

  if (!project) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-project-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-3xl bg-[#0A0F24] border border-slate-800 rounded-2xl shadow-2xl text-slate-100 overflow-hidden my-8 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-start justify-between p-6 border-b border-slate-800 bg-[#070B19]/80 shrink-0">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-xs font-semibold text-violet-400 uppercase tracking-wider">
                {project.category}
              </span>
              <span className="text-slate-600" aria-hidden="true">·</span>
              <span
                className={`text-[11px] px-2 py-0.5 rounded-full font-mono font-medium ${
                  project.status === 'Live'
                    ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/60'
                    : 'bg-amber-950/80 text-amber-300 border border-amber-800/60'
                }`}
              >
                {project.status}
              </span>
            </div>
            <h3 id="modal-project-title" className="text-2xl font-bold text-white">
              {project.name} — Technical Case Study
            </h3>
          </div>

          <button
            onClick={onClose}
            aria-label="Close modal"
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-8">
          {/* Preview Image */}
          <div className="relative w-full h-56 sm:h-72 rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
            <img
              src={project.imagePath}
              alt={`${project.name} interface preview`}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Core Problem & Approach */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
              <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-2 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>The Problem</span>
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {project.caseStudy.problem}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
              <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-400 mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>The Approach</span>
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {project.caseStudy.approach}
              </p>
            </div>
          </div>

          {/* Architecture / Special Status note if Veritas-X */}
          {project.id === 'veritas-x' && (
            <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-700/80">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-violet-400" />
                <span>Evidence Breakdown Architecture</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3">
                <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-800/60 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="text-xs font-semibold text-emerald-300">Verified (Green)</span>
                </div>
                <div className="p-3 rounded-lg bg-amber-950/30 border border-amber-800/60 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="text-xs font-semibold text-amber-300">Bypassed / Flawed (Amber)</span>
                </div>
                <div className="p-3 rounded-lg bg-rose-950/30 border border-rose-800/60 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span className="text-xs font-semibold text-rose-300">Missing Evidence (Red)</span>
                </div>
              </div>
              <p className="text-xs text-slate-400 italic">
                Note: The interface is designed to make evidence gaps and verification status easier to understand. It does not claim to detect every form of misinformation or guarantee factual accuracy.
              </p>
            </div>
          )}

          {/* Implementation Highlights */}
          <div>
            <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <span className="w-1.5 h-4 bg-violet-500 rounded-full" />
              <span>Key Implementation Highlights</span>
            </h4>
            <div className="space-y-2">
              {project.caseStudy.implementationHighlights.map((highlight, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{highlight}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Challenges & Solutions */}
          <div>
            <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <span className="w-1.5 h-4 bg-cyan-500 rounded-full" />
              <span>Challenges Overcome</span>
            </h4>
            <div className="space-y-3">
              {project.caseStudy.challengesAndSolutions.map((item, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs sm:text-sm">
                  <div className="font-semibold text-amber-300 mb-1">
                    Challenge: {item.challenge}
                  </div>
                  <div className="text-slate-300">
                    Solution: {item.solution}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Lessons Learned */}
          <div>
            <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <span className="w-1.5 h-4 bg-indigo-500 rounded-full" />
              <span>Lessons Learned as an Aspiring Engineer</span>
            </h4>
            <ul className="list-disc list-inside space-y-1.5 text-xs sm:text-sm text-slate-300">
              {project.caseStudy.lessonsLearned.map((lesson, idx) => (
                <li key={idx} className="leading-relaxed">{lesson}</li>
              ))}
            </ul>
          </div>

          {/* Tech Stack Chips */}
          <div className="pt-4 border-t border-slate-800">
            <div className="text-xs font-semibold text-slate-400 mb-2">Technologies Used:</div>
            <div className="flex flex-wrap gap-1.5">
              {project.techStack.map((tech) => (
                <span
                  key={tech}
                  className="px-2.5 py-1 rounded-md bg-slate-800/80 border border-slate-700/60 text-xs font-mono text-slate-300"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer with Actions */}
        <div className="p-6 border-t border-slate-800 bg-[#070B19]/80 flex flex-wrap items-center justify-between gap-4 shrink-0">
          <div className="text-xs text-slate-400 font-mono">
            Verified Project Evidence
          </div>

          <div className="flex items-center gap-3">
            {project.liveDemoUrl && (
              <a
                href={project.liveDemoUrl}
                target="_blank"
                rel="noreferrer noopener"
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-violet-600 hover:bg-violet-500 rounded-lg transition-colors"
              >
                <span>Open Live Demo</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
            <a
              href={project.githubUrl}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors"
            >
              <Github className="w-3.5 h-3.5" />
              <span>GitHub Repo</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
