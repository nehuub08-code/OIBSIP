import React from 'react';
import { ArrowDown, Sparkles, Award, Code2, Cpu, ExternalLink } from 'lucide-react';
import { PERSONAL_INFO, HERO_SKILLS } from '../data/portfolioData';
import { NetworkCanvas } from './NetworkCanvas';

interface HeroProps {
  onExploreProjects: () => void;
  onConnect: () => void;
  onOpenResume: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreProjects, onConnect, onOpenResume }) => {
  return (
    <section
      id="home"
      className="relative min-h-[92vh] flex items-center justify-center pt-24 pb-16 overflow-hidden bg-[#070B19]"
    >
      {/* Background Radial Glow Gradients */}
      <div
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-gradient-to-tr from-violet-600/15 via-indigo-600/10 to-cyan-500/15 rounded-full blur-3xl pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute top-1/2 -right-40 w-[450px] h-[450px] bg-cyan-600/10 rounded-full blur-3xl pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute bottom-10 -left-40 w-[400px] h-[400px] bg-fuchsia-600/10 rounded-full blur-3xl pointer-events-none"
        aria-hidden="true"
      />

      {/* Interactive Neural Network Canvas */}
      <NetworkCanvas />

      {/* Content Container */}
      <div className="relative z-10 max-w-6xl mx-auto px-6 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Typographic & Action Hierarchy */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            {/* Academic Achievement Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/80 border border-slate-700/80 text-xs text-slate-300 shadow-sm mb-6">
              <span className="flex items-center gap-1.5 text-violet-300 font-medium">
                <Award className="w-3.5 h-3.5 text-violet-400" />
                <span>CGPA 9.16/10</span>
              </span>
              <span className="text-slate-500" aria-hidden="true">·</span>
              <span className="text-slate-400">First-Year Distinction</span>
              <span className="text-slate-500" aria-hidden="true">·</span>
              <span className="text-cyan-400 font-medium">Second Year B.Tech</span>
            </div>

            {/* Main Heading */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.12] mb-4">
              Hi, I'm <span className="bg-gradient-to-r from-violet-400 via-indigo-300 to-cyan-300 bg-clip-text text-transparent">{PERSONAL_INFO.shortName}</span>.
            </h1>

            {/* Supporting Headline */}
            <h2 className="text-xl sm:text-2xl font-semibold text-slate-200 tracking-tight mb-5 leading-snug">
              {PERSONAL_INFO.introHeadline}
            </h2>

            {/* Short Description */}
            <p className="text-base sm:text-lg text-slate-400 leading-relaxed max-w-2xl mb-8">
              {PERSONAL_INFO.introDescription}
            </p>

            {/* Primary & Secondary Call to Actions */}
            <div className="flex flex-wrap items-center gap-4 mb-10 w-full sm:w-auto">
              <button
                onClick={onExploreProjects}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-gradient-to-r from-violet-600 via-indigo-600 to-cyan-600 hover:from-violet-500 hover:via-indigo-500 hover:to-cyan-500 rounded-xl shadow-lg shadow-violet-950/60 hover:shadow-violet-600/25 transition-all duration-200 active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-violet-400"
              >
                <span>Explore My Projects</span>
                <ArrowDown className="w-4 h-4" />
              </button>

              <button
                onClick={onConnect}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-semibold text-slate-200 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-slate-600 rounded-xl shadow-sm transition-all duration-200 active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-violet-400"
              >
                <span>Connect With Me</span>
              </button>

              <button
                onClick={onOpenResume}
                className="hidden md:inline-flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-cyan-300 transition-colors ml-2 py-2"
              >
                <span>View Full Resume</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Honest Learning Stage Skill Chips */}
            <div className="w-full pt-4 border-t border-slate-800/80">
              <div className="text-xs font-semibold tracking-wider text-slate-400 uppercase mb-3 flex items-center gap-1.5">
                <Code2 className="w-3.5 h-3.5 text-violet-400" />
                <span>Current Learning & Practice Toolkit</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {HERO_SKILLS.map((skill) => (
                  <div
                    key={skill.name}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/70 border border-slate-800 text-xs text-slate-300 hover:border-slate-700 hover:bg-slate-850 transition-colors"
                  >
                    <span className="font-medium text-slate-200">{skill.name}</span>
                    <span className="text-slate-600" aria-hidden="true">·</span>
                    <span className="text-[11px] text-cyan-400/90 font-mono">{skill.stage}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Abstract AI Graphic & Visual Showcase */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end">
            <div className="relative w-full max-w-[420px] aspect-square rounded-3xl p-1 bg-gradient-to-tr from-violet-600/30 via-slate-800 to-cyan-500/30 shadow-2xl shadow-indigo-950/50 group">
              <div className="w-full h-full rounded-[22px] bg-[#0A0F24] p-5 flex flex-col justify-between overflow-hidden relative border border-slate-800">
                {/* Visual Image */}
                <div className="relative w-full h-[260px] rounded-xl overflow-hidden bg-slate-950/60 border border-slate-800/80">
                  <img
                    src="/src/assets/images/abstract_ai_neural_cube_1793296085049.jpg"
                    alt="Abstract AI neural network cube visualization"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0A0F24] via-transparent to-transparent opacity-80" />
                  
                  {/* Floating micro-badge */}
                  <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-[#070B19]/80 backdrop-blur-md border border-white/10 text-[11px] font-medium text-violet-200 flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3 text-violet-400" />
                    <span>Neural Network Architecture</span>
                  </div>
                </div>

                {/* Card Bottom Meta */}
                <div className="pt-4">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-semibold text-slate-300 tracking-wide">
                      {PERSONAL_INFO.title}
                    </span>
                    <span className="text-[11px] font-mono text-cyan-400 font-medium">
                      2nd Year Student
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Learning concepts from mathematical fundamentals to practical intelligent agent workflows.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
