import React, { useState } from 'react';
import { ExternalLink, Github, BookOpen, CheckCircle2, AlertTriangle, AlertCircle, Radio } from 'lucide-react';
import { FEATURED_PROJECTS } from '../data/portfolioData';
import { Project } from '../types/portfolio';
import { ProjectModal } from './ProjectModal';

export const ProjectsSection: React.FC = () => {
  const [activeModalProject, setActiveModalProject] = useState<Project | null>(null);

  return (
    <section id="projects" className="py-24 bg-[#F8F9FE] text-slate-900 border-b border-slate-200">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="text-xs font-bold tracking-widest uppercase text-violet-700 mb-2">
            Selected Works
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 mb-4 text-balance">
            Featured Engineering Projects
          </h2>
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Hands-on projects addressing real interaction workflows—from AI decision trees and voice chatbots to student career guidance and transparent evidence verification.
          </p>
        </div>

        {/* 3 Projects Stacked / Grid */}
        <div className="space-y-16">
          {FEATURED_PROJECTS.map((project, index) => (
            <div
              key={project.id}
              className="bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden grid grid-cols-1 lg:grid-cols-12 gap-0 group"
            >
              {/* Left Column: Media Preview */}
              <div className={`lg:col-span-6 relative bg-slate-950 min-h-[300px] lg:min-h-full overflow-hidden ${index % 2 === 1 ? 'lg:order-2' : ''}`}>
                <img
                  src={project.imagePath}
                  alt={`${project.name} preview`}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent pointer-events-none" />

                {/* Status Indicator Chip */}
                <div className="absolute top-4 left-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/90 backdrop-blur-md border border-white/10 text-xs font-medium text-white shadow-md">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      project.status === 'Live' ? 'bg-emerald-400' : 'bg-amber-400'
                    }`}
                  />
                  <span>{project.status === 'Live' ? 'Live Deployment' : 'In Development'}</span>
                </div>
              </div>

              {/* Right Column: Project Details & Actions */}
              <div className={`lg:col-span-6 p-8 sm:p-10 flex flex-col justify-between ${index % 2 === 1 ? 'lg:order-1' : ''}`}>
                <div>
                  <div className="text-xs font-bold text-violet-700 uppercase tracking-wider mb-2">
                    {project.category}
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mb-3">
                    {project.name}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed mb-6">
                    {project.description}
                  </p>

                  {/* Veritas-X Evidence Breakdown Micro-Widget */}
                  {project.id === 'veritas-x' && (
                    <div className="p-3.5 mb-6 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-2">
                        Evidence Breakdown States
                      </div>
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-100 text-emerald-800 font-medium">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Verified</span>
                        </span>
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-amber-100 text-amber-800 font-medium">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                          <span>Bypassed / Flawed</span>
                        </span>
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-rose-100 text-rose-800 font-medium">
                          <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                          <span>Missing</span>
                        </span>
                      </div>
                    </div>
                  )}

                  {/* Features List */}
                  <div className="space-y-2 mb-6">
                    <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      Key Highlights:
                    </div>
                    {project.features.slice(0, 3).map((feat, fIdx) => (
                      <div key={fIdx} className="flex items-start gap-2 text-xs sm:text-sm text-slate-700">
                        <span className="text-violet-600 font-bold shrink-0">·</span>
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>

                  {/* Tech Stack Chips */}
                  <div className="flex flex-wrap gap-1.5 mb-8">
                    {project.techStack.map((tech) => (
                      <span
                        key={tech}
                        className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-700 text-xs font-mono font-medium"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="pt-6 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                  <button
                    onClick={() => setActiveModalProject(project)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-violet-700 hover:text-violet-900 bg-violet-50 hover:bg-violet-100 rounded-lg transition-colors focus-visible:outline-2 focus-visible:outline-violet-600"
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>Read Case Study</span>
                  </button>

                  <div className="flex items-center gap-2">
                    {project.liveDemoUrl && (
                      <a
                        href={project.liveDemoUrl}
                        target="_blank"
                        rel="noreferrer noopener"
                        className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm transition-colors focus-visible:outline-2 focus-visible:outline-slate-900"
                      >
                        <span>Live Demo</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors focus-visible:outline-2 focus-visible:outline-slate-900"
                    >
                      <Github className="w-3.5 h-3.5" />
                      <span>Code</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Case Study Modal */}
      <ProjectModal
        project={activeModalProject}
        onClose={() => setActiveModalProject(null)}
      />
    </section>
  );
};
