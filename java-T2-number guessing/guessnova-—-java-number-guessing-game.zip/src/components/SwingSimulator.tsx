import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  DifficultyLevel, 
  DIFFICULTY_CONFIGS, 
  FeedbackState, 
  GuessRecord, 
  CompletedRound, 
  OverallStats 
} from '../types/game';
import { 
  Play, 
  RotateCcw, 
  Award, 
  AlertCircle, 
  Info, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  XCircle, 
  Sparkles,
  ArrowUp,
  ArrowDown
} from 'lucide-react';

interface SwingSimulatorProps {
  onRoundComplete?: (round: CompletedRound) => void;
  initialStats?: OverallStats;
}

export const SwingSimulator: React.FC<SwingSimulatorProps> = ({ onRoundComplete }) => {
  // Game States
  const [difficulty, setDifficulty] = useState<DifficultyLevel>('medium');
  const [roundNumber, setRoundNumber] = useState<number>(1);
  const [secretNumber, setSecretNumber] = useState<number>(() => generateSecret('medium'));
  const [currentGuessInput, setCurrentGuessInput] = useState<string>('');
  const [attemptsUsed, setAttemptsUsed] = useState<number>(0);
  const [isRoundActive, setIsRoundActive] = useState<boolean>(true);
  const [guessesInRound, setGuessesInRound] = useState<GuessRecord[]>([]);
  const [history, setHistory] = useState<CompletedRound[]>([]);

  // Swing Look and Feel Simulation: 'flatlaf-light' | 'flatlaf-dark' | 'metal'
  const [lookAndFeel, setLookAndFeel] = useState<'flatlaf-light' | 'flatlaf-dark' | 'metal'>('flatlaf-light');

  // Feedback State
  const [feedback, setFeedback] = useState<FeedbackState>({
    type: 'neutral',
    title: 'Guess the secret number!',
    message: 'I have picked a secret number between 1 and 100. Enter your first guess to begin!',
    hint: 'You have 7 attempts for Medium difficulty.',
  });

  // Modal / Confirmations
  const [confirmModal, setConfirmModal] = useState<{
    show: boolean;
    pendingDifficulty: DifficultyLevel | null;
  }>({ show: false, pendingDifficulty: null });

  // Debug / Evaluator Peek Secret toggle
  const [showSecretPeek, setShowSecretPeek] = useState<boolean>(false);

  // About Dialog
  const [showAboutDialog, setShowAboutDialog] = useState<boolean>(false);
  const [showRulesDialog, setShowRulesDialog] = useState<boolean>(false);

  const inputRef = useRef<HTMLInputElement>(null);

  const config = DIFFICULTY_CONFIGS[difficulty];
  const maxAttempts = config.maxAttempts;
  const attemptsRemaining = Math.max(0, maxAttempts - attemptsUsed);

  function generateSecret(diff: DifficultyLevel): number {
    const cfg = DIFFICULTY_CONFIGS[diff];
    // Formula: random.nextInt(max - min + 1) + min
    return Math.floor(Math.random() * (cfg.max - cfg.min + 1)) + cfg.min;
  }

  // Auto focus input on mount & new round
  useEffect(() => {
    if (isRoundActive) {
      inputRef.current?.focus();
    }
  }, [isRoundActive, roundNumber]);

  // Overall statistics calculated from history
  const stats: OverallStats = {
    totalRounds: history.length,
    roundsWon: history.filter(r => r.won).length,
    roundsLost: history.filter(r => !r.won).length,
    totalValidGuesses: history.reduce((sum, r) => sum + r.attemptsUsed, 0) + attemptsUsed,
    winRate: history.length > 0 
      ? Math.round((history.filter(r => r.won).length / history.length) * 100) 
      : 0,
    bestAttempts: history.filter(r => r.won).length > 0
      ? Math.min(...history.filter(r => r.won).map(r => r.attemptsUsed))
      : null,
  };

  const handleDifficultySelect = (newDiff: DifficultyLevel) => {
    if (newDiff === difficulty) return;

    // Check if round is active with attempts already made
    if (isRoundActive && attemptsUsed > 0) {
      setConfirmModal({
        show: true,
        pendingDifficulty: newDiff,
      });
    } else {
      applyNewDifficulty(newDiff);
    }
  };

  const applyNewDifficulty = (newDiff: DifficultyLevel) => {
    setDifficulty(newDiff);
    const newSecret = generateSecret(newDiff);
    setSecretNumber(newSecret);
    setAttemptsUsed(0);
    setIsRoundActive(true);
    setGuessesInRound([]);
    setCurrentGuessInput('');
    const newCfg = DIFFICULTY_CONFIGS[newDiff];
    setFeedback({
      type: 'neutral',
      title: 'New Round Started!',
      message: `Difficulty changed to ${newCfg.name}. Pick a number between ${newCfg.min} and ${newCfg.max}.`,
      hint: `You have ${newCfg.maxAttempts} attempts.`,
    });
    setConfirmModal({ show: false, pendingDifficulty: null });
  };

  const handleGuessSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!isRoundActive) return;

    const trimmed = currentGuessInput.trim();

    // 1. Empty Check
    if (!trimmed) {
      setFeedback({
        type: 'invalid',
        title: 'Input Notice',
        message: 'Input field cannot be empty. Please type an integer.',
        hint: 'Invalid input does not count toward your attempts.',
      });
      return;
    }

    // 2. Numeric / Integer.parseInt validation
    // Checking integer format
    const parsed = Number(trimmed);
    if (!/^-?\d+$/.test(trimmed) || isNaN(parsed) || !Number.isInteger(parsed)) {
      setFeedback({
        type: 'invalid',
        title: 'Invalid Number Format',
        message: `"${trimmed}" is not a valid integer. Java Integer.parseInt() would throw a NumberFormatException.`,
        hint: 'Please enter whole numbers only (no letters, symbols, or decimals). Turn is not consumed.',
      });
      return;
    }

    const guess = parsed;

    // 3. Range bounds check
    if (guess < config.min || guess > config.max) {
      setFeedback({
        type: 'invalid',
        title: 'Out of Range!',
        message: `Your guess (${guess}) is outside the active range of ${config.min} to ${config.max}.`,
        hint: 'Enter a number within the specified bounds. Turn is not consumed.',
      });
      return;
    }

    // 4. Valid guess consumes an attempt
    const newAttemptsUsed = attemptsUsed + 1;
    const remainingAfter = Math.max(0, maxAttempts - newAttemptsUsed);
    setAttemptsUsed(newAttemptsUsed);
    setCurrentGuessInput('');

    // Check Win Condition
    if (guess === secretNumber) {
      setIsRoundActive(false);
      const record: GuessRecord = {
        guess,
        result: 'correct',
        feedback: `Correct! ${guess} is the secret number!`,
        attemptsUsed: newAttemptsUsed,
        attemptsRemaining: remainingAfter,
        timestamp: new Date().toLocaleTimeString(),
      };
      setGuessesInRound(prev => [...prev, record]);

      setFeedback({
        type: 'correct',
        title: 'Correct! You Won!',
        message: `Outstanding! You discovered the secret number ${secretNumber} in ${newAttemptsUsed} ${newAttemptsUsed === 1 ? 'attempt' : 'attempts'}!`,
        hint: 'Round completed successfully. Click "Play Again" to start the next round.',
      });

      // Confetti burst
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });

      const completed: CompletedRound = {
        roundNumber,
        difficulty,
        difficultyName: config.name,
        rangeText: `${config.min}–${config.max}`,
        secretNumber,
        attemptsUsed: newAttemptsUsed,
        maxAttempts,
        won: true,
        guesses: [...guessesInRound, record],
        summary: `Round ${roundNumber} — Won in ${newAttemptsUsed} / ${maxAttempts} attempts! (Secret: ${secretNumber})`,
        date: new Date().toLocaleTimeString(),
      };

      setHistory(prev => [completed, ...prev]);
      onRoundComplete?.(completed);
      return;
    }

    // Check Loss Condition (exhausted attempts)
    if (remainingAfter === 0) {
      setIsRoundActive(false);
      const record: GuessRecord = {
        guess,
        result: guess < secretNumber ? 'too_low' : 'too_high',
        feedback: `Out of attempts. Secret was ${secretNumber}.`,
        attemptsUsed: newAttemptsUsed,
        attemptsRemaining: 0,
        timestamp: new Date().toLocaleTimeString(),
      };
      setGuessesInRound(prev => [...prev, record]);

      setFeedback({
        type: 'lost',
        title: 'You Lost!',
        message: `All ${maxAttempts} attempts have been used up. The secret number was ${secretNumber}.`,
        hint: 'Do not worry! Click "Play Again" to test your intuition in a brand new round.',
      });

      const completed: CompletedRound = {
        roundNumber,
        difficulty,
        difficultyName: config.name,
        rangeText: `${config.min}–${config.max}`,
        secretNumber,
        attemptsUsed: newAttemptsUsed,
        maxAttempts,
        won: false,
        guesses: [...guessesInRound, record],
        summary: `Round ${roundNumber} — Lost! Used all ${maxAttempts} attempts. (Secret was ${secretNumber})`,
        date: new Date().toLocaleTimeString(),
      };

      setHistory(prev => [completed, ...prev]);
      onRoundComplete?.(completed);
      return;
    }

    // Too Low or Too High
    if (guess < secretNumber) {
      const record: GuessRecord = {
        guess,
        result: 'too_low',
        feedback: `Too Low! (${remainingAfter} attempts remaining)`,
        attemptsUsed: newAttemptsUsed,
        attemptsRemaining: remainingAfter,
        timestamp: new Date().toLocaleTimeString(),
      };
      setGuessesInRound(prev => [...prev, record]);
      setFeedback({
        type: 'too_low',
        title: 'Too Low!',
        message: `Your guess of ${guess} is lower than the secret number. Try guessing higher!`,
        hint: `${remainingAfter} ${remainingAfter === 1 ? 'attempt' : 'attempts'} remaining.`,
      });
    } else {
      const record: GuessRecord = {
        guess,
        result: 'too_high',
        feedback: `Too High! (${remainingAfter} attempts remaining)`,
        attemptsUsed: newAttemptsUsed,
        attemptsRemaining: remainingAfter,
        timestamp: new Date().toLocaleTimeString(),
      };
      setGuessesInRound(prev => [...prev, record]);
      setFeedback({
        type: 'too_high',
        title: 'Too High!',
        message: `Your guess of ${guess} is higher than the secret number. Try guessing lower!`,
        hint: `${remainingAfter} ${remainingAfter === 1 ? 'attempt' : 'attempts'} remaining.`,
      });
    }
  };

  const startNewRound = () => {
    const nextRound = roundNumber + 1;
    const newSecret = generateSecret(difficulty);
    setRoundNumber(nextRound);
    setSecretNumber(newSecret);
    setAttemptsUsed(0);
    setIsRoundActive(true);
    setGuessesInRound([]);
    setCurrentGuessInput('');
    setFeedback({
      type: 'neutral',
      title: `Round ${nextRound} Started`,
      message: `A new secret number between ${config.min} and ${config.max} has been generated.`,
      hint: `You have ${config.maxAttempts} attempts. Good luck!`,
    });
  };

  // Styling based on Look and Feel
  const isDark = lookAndFeel === 'flatlaf-dark';
  const isMetal = lookAndFeel === 'metal';

  const windowBg = isDark ? 'bg-slate-900 text-slate-100' : isMetal ? 'bg-slate-200 text-slate-900 font-sans' : 'bg-slate-100 text-slate-800';
  const cardBg = isDark ? 'bg-slate-800 border-slate-700' : isMetal ? 'bg-slate-100 border-slate-300 shadow-inner' : 'bg-white border-slate-200 shadow-xs';
  const titleBarBg = isDark ? 'bg-slate-950 border-b border-slate-800' : isMetal ? 'bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white' : 'bg-slate-800 text-slate-100';

  // Feedback colors matching prompt specification:
  // - Too Low: cool-toned feedback
  // - Too High: warm-toned feedback
  // - Correct: positive success feedback
  // - Invalid input: clear validation message
  const getFeedbackStyles = () => {
    switch (feedback.type) {
      case 'too_low':
        return isDark 
          ? 'bg-sky-950/70 border-sky-800 text-sky-200' 
          : 'bg-sky-50 border-sky-200 text-sky-950';
      case 'too_high':
        return isDark 
          ? 'bg-amber-950/70 border-amber-800 text-amber-200' 
          : 'bg-amber-50 border-amber-200 text-amber-950';
      case 'correct':
        return isDark 
          ? 'bg-emerald-950/70 border-emerald-800 text-emerald-200' 
          : 'bg-emerald-50 border-emerald-200 text-emerald-950';
      case 'lost':
        return isDark 
          ? 'bg-rose-950/70 border-rose-800 text-rose-200' 
          : 'bg-rose-50 border-rose-200 text-rose-950';
      case 'invalid':
        return isDark 
          ? 'bg-orange-950/70 border-orange-800 text-orange-200' 
          : 'bg-orange-50 border-orange-200 text-orange-950';
      default:
        return isDark 
          ? 'bg-slate-800/80 border-slate-700 text-slate-300' 
          : 'bg-slate-50 border-slate-200 text-slate-700';
    }
  };

  const getFeedbackIcon = () => {
    switch (feedback.type) {
      case 'too_low':
        return <ArrowUp className="w-6 h-6 text-sky-600 animate-bounce" />;
      case 'too_high':
        return <ArrowDown className="w-6 h-6 text-amber-600 animate-bounce" />;
      case 'correct':
        return <CheckCircle2 className="w-6 h-6 text-emerald-600" />;
      case 'lost':
        return <XCircle className="w-6 h-6 text-rose-600" />;
      case 'invalid':
        return <AlertCircle className="w-6 h-6 text-orange-600" />;
      default:
        return <Sparkles className="w-6 h-6 text-indigo-500" />;
    }
  };

  return (
    <div className="w-full flex flex-col items-center">
      {/* Look & Feel Switcher Bar */}
      <div className="w-full max-w-4xl mb-3 flex flex-wrap items-center justify-between text-xs text-slate-600 px-2 gap-2">
        <div className="flex items-center gap-2">
          <span className="font-medium text-slate-700">Swing Look & Feel:</span>
          <div className="flex bg-slate-200 rounded-md p-0.5">
            <button
              onClick={() => setLookAndFeel('flatlaf-light')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                lookAndFeel === 'flatlaf-light' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              FlatLaf Light
            </button>
            <button
              onClick={() => setLookAndFeel('flatlaf-dark')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                lookAndFeel === 'flatlaf-dark' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              FlatLaf Dark
            </button>
            <button
              onClick={() => setLookAndFeel('metal')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                lookAndFeel === 'metal' ? 'bg-blue-700 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Classic Metal L&F
            </button>
          </div>
        </div>

        {/* Debug Peek Toggle */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowSecretPeek(!showSecretPeek)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-medium transition-colors"
            title="Inspector tool to inspect the secret number for testing and grading"
          >
            {showSecretPeek ? <EyeOff className="w-3.5 h-3.5 text-indigo-600" /> : <Eye className="w-3.5 h-3.5 text-slate-600" />}
            <span>Secret Inspector: {showSecretPeek ? <strong className="text-indigo-600">{secretNumber}</strong> : 'Hidden'}</span>
          </button>
        </div>
      </div>

      {/* Main Java Swing Window Frame */}
      <div className={`w-full max-w-4xl rounded-xl border border-slate-300 shadow-xl overflow-hidden transition-colors ${windowBg}`}>
        {/* Java Window Title Bar */}
        <div className={`px-4 py-2.5 flex items-center justify-between select-none ${titleBarBg}`}>
          <div className="flex items-center gap-2.5">
            {/* Java Cup Icon */}
            <div className="w-5 h-5 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center font-serif text-xs font-bold border border-amber-400/40">
              ☕
            </div>
            <span className="font-semibold text-xs md:text-sm tracking-wide">
              GuessNova — Number Guessing Game [Java Swing EDT]
            </span>
            <span className="hidden sm:inline text-xs opacity-75">· Oasis Infobyte Task 2</span>
          </div>

          {/* Window Control Buttons */}
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-amber-400/80 inline-block cursor-default" title="Minimize"></span>
            <span className="w-3 h-3 rounded-full bg-emerald-400/80 inline-block cursor-default" title="Maximize"></span>
            <span className="w-3 h-3 rounded-full bg-rose-400/80 inline-block cursor-default" title="Close"></span>
          </div>
        </div>

        {/* Java JMenuBar */}
        <div className={`px-4 py-1.5 border-b text-xs flex items-center gap-4 ${
          isDark ? 'bg-slate-900 border-slate-800 text-slate-300' : 'bg-slate-100 border-slate-200 text-slate-700'
        }`}>
          <div className="relative group cursor-pointer">
            <span className="hover:text-indigo-600 font-medium">Game</span>
            <div className="absolute top-full left-0 hidden group-hover:flex flex-col bg-white border border-slate-200 shadow-lg rounded-md py-1 z-20 w-36 text-slate-800">
              <button 
                onClick={startNewRound}
                className="text-left px-3 py-1 text-xs hover:bg-slate-100 w-full"
              >
                New Round
              </button>
              <button 
                onClick={() => {
                  setHistory([]);
                  setRoundNumber(1);
                  startNewRound();
                }}
                className="text-left px-3 py-1 text-xs hover:bg-slate-100 w-full text-rose-600"
              >
                Reset All Statistics
              </button>
            </div>
          </div>

          <div className="relative group cursor-pointer">
            <span className="hover:text-indigo-600 font-medium">Difficulty</span>
            <div className="absolute top-full left-0 hidden group-hover:flex flex-col bg-white border border-slate-200 shadow-lg rounded-md py-1 z-20 w-44 text-slate-800">
              <button 
                onClick={() => handleDifficultySelect('easy')}
                className={`text-left px-3 py-1 text-xs hover:bg-slate-100 w-full flex justify-between ${difficulty === 'easy' ? 'font-bold text-indigo-600' : ''}`}
              >
                <span>Easy (1-50)</span>
                {difficulty === 'easy' && <span>✓</span>}
              </button>
              <button 
                onClick={() => handleDifficultySelect('medium')}
                className={`text-left px-3 py-1 text-xs hover:bg-slate-100 w-full flex justify-between ${difficulty === 'medium' ? 'font-bold text-indigo-600' : ''}`}
              >
                <span>Medium (1-100)</span>
                {difficulty === 'medium' && <span>✓</span>}
              </button>
              <button 
                onClick={() => handleDifficultySelect('hard')}
                className={`text-left px-3 py-1 text-xs hover:bg-slate-100 w-full flex justify-between ${difficulty === 'hard' ? 'font-bold text-indigo-600' : ''}`}
              >
                <span>Hard (1-200)</span>
                {difficulty === 'hard' && <span>✓</span>}
              </button>
            </div>
          </div>

          <div className="relative group cursor-pointer">
            <span className="hover:text-indigo-600 font-medium">Help</span>
            <div className="absolute top-full left-0 hidden group-hover:flex flex-col bg-white border border-slate-200 shadow-lg rounded-md py-1 z-20 w-48 text-slate-800">
              <button 
                onClick={() => setShowRulesDialog(true)}
                className="text-left px-3 py-1 text-xs hover:bg-slate-100 w-full"
              >
                Game Rules & Scoring
              </button>
              <button 
                onClick={() => setShowAboutDialog(true)}
                className="text-left px-3 py-1 text-xs hover:bg-slate-100 w-full"
              >
                About Developer & Oasis
              </button>
            </div>
          </div>

          <div className="ml-auto text-[11px] opacity-70">
            Developer: <strong className="font-medium">Neha Vinod Borkar</strong>
          </div>
        </div>

        {/* Window Content Pane */}
        <div className="p-5 md:p-6 space-y-5">
          {/* Top Info Header */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">GuessNova</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Guess the secret number! · Task 2 — Java Development
              </p>
            </div>

            <div className="flex items-center gap-3">
              {/* Round Badge */}
              <div className="px-3 py-1.5 rounded-lg border border-indigo-200 dark:border-indigo-900 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 font-bold text-sm">
                Round #{roundNumber}
              </div>

              {/* Status Indicator */}
              <div className={`px-2.5 py-1 rounded-md text-xs font-semibold ${
                isRoundActive 
                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' 
                  : feedback.type === 'correct' 
                    ? 'bg-emerald-600 text-white' 
                    : 'bg-rose-600 text-white'
              }`}>
                {isRoundActive ? 'ACTIVE ROUND' : feedback.type === 'correct' ? 'ROUND WON' : 'ROUND FINISHED'}
              </div>
            </div>
          </div>

          {/* Controls Card: Difficulty, Input, Guess Button, Play Again */}
          <div className={`p-4 md:p-5 rounded-lg border ${cardBg}`}>
            <form onSubmit={handleGuessSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
                {/* JComboBox: Difficulty Selector */}
                <div className="md:col-span-5 flex flex-col gap-1">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400">
                    Difficulty Level (JComboBox)
                  </label>
                  <select
                    value={difficulty}
                    onChange={(e) => handleDifficultySelect(e.target.value as DifficultyLevel)}
                    className="w-full h-11 px-3 text-sm rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="easy">Easy (1–50, 10 attempts)</option>
                    <option value="medium">Medium (1–100, 7 attempts) — Default</option>
                    <option value="hard">Hard (1–200, 5 attempts)</option>
                  </select>
                </div>

                {/* Range & Limits Display */}
                <div className="md:col-span-4 flex flex-col justify-center px-3 py-1.5 rounded bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">Valid Target Range:</span>
                  <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400">
                    [{config.min} to {config.max}]
                  </span>
                </div>

                {/* New Round / Play Again Button */}
                <div className="md:col-span-3 flex items-end">
                  <button
                    type="button"
                    onClick={startNewRound}
                    className="w-full h-11 flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold rounded-md border border-slate-300 dark:border-slate-600 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 transition-colors shadow-xs"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>New Round</span>
                  </button>
                </div>
              </div>

              {/* Numeric Input & Guess Button */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row gap-3">
                <div className="flex-1 relative">
                  <input
                    ref={inputRef}
                    type="text"
                    inputMode="numeric"
                    placeholder={`Enter an integer (${config.min} - ${config.max})...`}
                    value={currentGuessInput}
                    disabled={!isRoundActive}
                    onChange={(e) => setCurrentGuessInput(e.target.value)}
                    className="w-full h-12 px-4 text-center text-lg font-bold tracking-wide rounded-md border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50 disabled:bg-slate-100 dark:disabled:bg-slate-800"
                  />
                  <span className="absolute right-3 top-3.5 text-xs text-slate-400 pointer-events-none hidden sm:inline">
                    ↵ Press Enter
                  </span>
                </div>

                <button
                  type="submit"
                  disabled={!isRoundActive}
                  className="h-12 px-8 flex items-center justify-center gap-2 font-bold text-sm rounded-md bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed disabled:bg-slate-400"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Guess Number</span>
                </button>
              </div>
            </form>
          </div>

          {/* Feedback Display Card */}
          <div className={`p-5 rounded-lg border transition-all ${getFeedbackStyles()}`}>
            <div className="flex items-start gap-4">
              <div className="p-2 rounded-full bg-white/70 dark:bg-black/20 shadow-xs shrink-0">
                {getFeedbackIcon()}
              </div>

              <div className="flex-1">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-lg font-bold tracking-tight">
                    {feedback.title}
                  </h3>
                  <span className="text-xs opacity-75 font-mono">
                    Attempt #{attemptsUsed} of {maxAttempts}
                  </span>
                </div>

                <p className="mt-1 text-sm font-medium leading-relaxed">
                  {feedback.message}
                </p>

                {feedback.hint && (
                  <p className="mt-1.5 text-xs opacity-90 italic">
                    💡 Hint: {feedback.hint}
                  </p>
                )}
              </div>
            </div>

            {/* Visual Attempt Progress Bar */}
            <div className="mt-4 pt-3 border-t border-current/15">
              <div className="flex items-center justify-between text-xs font-semibold mb-1.5">
                <span>Attempts Used: {attemptsUsed} / {maxAttempts}</span>
                <span>{attemptsRemaining} {attemptsRemaining === 1 ? 'attempt' : 'attempts'} remaining</span>
              </div>

              <div className="w-full h-3 rounded-full bg-black/10 dark:bg-white/10 overflow-hidden p-0.5">
                <div
                  className={`h-full rounded-full transition-all duration-300 ${
                    attemptsRemaining <= 1 
                      ? 'bg-rose-500' 
                      : attemptsRemaining <= 3 
                        ? 'bg-amber-500' 
                        : 'bg-indigo-600'
                  }`}
                  style={{ width: `${(attemptsUsed / maxAttempts) * 100}%` }}
                />
              </div>

              {/* Quick Dots visualization */}
              <div className="flex items-center justify-center gap-1.5 mt-2">
                {Array.from({ length: maxAttempts }).map((_, idx) => {
                  const isUsed = idx < attemptsUsed;
                  const isCurrent = idx === attemptsUsed - 1;
                  return (
                    <span
                      key={idx}
                      className={`w-2.5 h-2.5 rounded-full transition-all ${
                        isUsed
                          ? isCurrent && feedback.type === 'correct'
                            ? 'bg-emerald-500 scale-125'
                            : 'bg-indigo-600 dark:bg-indigo-400'
                          : 'bg-slate-300 dark:bg-slate-700'
                      }`}
                      title={`Attempt ${idx + 1}`}
                    />
                  );
                })}
              </div>
            </div>
          </div>

          {/* Current Round Guess Trail */}
          {guessesInRound.length > 0 && (
            <div className={`p-3 rounded-lg border ${cardBg}`}>
              <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400 mb-2">
                <span>This Round's Guesses ({guessesInRound.length}):</span>
                <span>Secret Range: {config.min}–{config.max}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {guessesInRound.map((g, idx) => (
                  <div
                    key={idx}
                    className={`px-3 py-1 rounded text-xs font-mono font-medium flex items-center gap-1.5 border ${
                      g.result === 'correct'
                        ? 'bg-emerald-100 border-emerald-300 text-emerald-800 dark:bg-emerald-950 dark:border-emerald-800 dark:text-emerald-300'
                        : g.result === 'too_low'
                          ? 'bg-sky-50 border-sky-200 text-sky-800 dark:bg-sky-950 dark:border-sky-800 dark:text-sky-300'
                          : 'bg-amber-50 border-amber-200 text-amber-800 dark:bg-amber-950 dark:border-amber-800 dark:text-amber-300'
                    }`}
                  >
                    <span>#{idx + 1}: <strong>{g.guess}</strong></span>
                    <span className="text-[10px] opacity-75">
                      {g.result === 'correct' ? '✅ Correct' : g.result === 'too_low' ? '↑ Too Low' : '↓ Too High'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* History Ledger Table */}
          <div className={`p-4 rounded-lg border ${cardBg}`}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-indigo-600" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Round History & Score Summary (JTable)
                </h4>
              </div>
              <span className="text-xs text-slate-500">
                {history.length} {history.length === 1 ? 'round' : 'rounds'} completed
              </span>
            </div>

            {history.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-400 border border-dashed border-slate-300 dark:border-slate-700 rounded-md">
                No completed rounds yet. Play a round to record history!
              </div>
            ) : (
              <div className="overflow-x-auto max-h-48 border border-slate-200 dark:border-slate-700 rounded-md">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-750 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
                    <tr>
                      <th className="px-3 py-2">Round</th>
                      <th className="px-3 py-2">Difficulty</th>
                      <th className="px-3 py-2">Result</th>
                      <th className="px-3 py-2">Attempts</th>
                      <th className="px-3 py-2">Secret Number</th>
                      <th className="px-3 py-2">Summary</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                    {history.map((r, i) => (
                      <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-750">
                        <td className="px-3 py-2 font-bold font-mono">#{r.roundNumber}</td>
                        <td className="px-3 py-2">{r.difficultyName}</td>
                        <td className="px-3 py-2">
                          <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                            r.won 
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' 
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          }`}>
                            {r.won ? 'WON' : 'LOST'}
                          </span>
                        </td>
                        <td className="px-3 py-2 font-mono">{r.attemptsUsed} / {r.maxAttempts}</td>
                        <td className="px-3 py-2 font-bold font-mono text-indigo-600 dark:text-indigo-400">{r.secretNumber}</td>
                        <td className="px-3 py-2 text-slate-500 truncate max-w-xs">{r.summary}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Java Swing Status Bar */}
        <div className={`px-4 py-2 border-t text-xs flex flex-wrap items-center justify-between gap-2 ${
          isDark ? 'bg-slate-950 border-slate-800 text-slate-400' : 'bg-slate-200 border-slate-300 text-slate-600'
        }`}>
          <div className="flex flex-wrap items-center gap-3">
            <span>Total Rounds: <strong>{stats.totalRounds}</strong></span>
            <span>·</span>
            <span className="text-emerald-600 font-semibold">Won: {stats.roundsWon}</span>
            <span>·</span>
            <span className="text-rose-600 font-semibold">Lost: {stats.roundsLost}</span>
            <span>·</span>
            <span>Win Rate: <strong>{stats.winRate}%</strong></span>
            <span>·</span>
            <span>Total Guesses: <strong>{stats.totalValidGuesses}</strong></span>
          </div>

          <div className="text-[11px] font-mono">
            Oasis Infobyte OIBSIP · Java Task 2
          </div>
        </div>
      </div>

      {/* Confirmation Modal for Mid-Round Difficulty Change */}
      {confirmModal.show && confirmModal.pendingDifficulty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center gap-3 text-amber-600">
              <AlertCircle className="w-6 h-6" />
              <h3 className="text-lg font-bold text-slate-900">
                Confirm Difficulty Change
              </h3>
            </div>

            <p className="text-sm text-slate-600 leading-relaxed">
              You are currently in an active round with <strong>{attemptsUsed} attempts</strong> used. Changing difficulty to{' '}
              <strong>{DIFFICULTY_CONFIGS[confirmModal.pendingDifficulty].name}</strong> will reset this round and generate a fresh secret number.
            </p>

            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setConfirmModal({ show: false, pendingDifficulty: null })}
                className="px-4 py-2 rounded-md border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-100"
              >
                Cancel (Keep Current Round)
              </button>
              <button
                onClick={() => applyNewDifficulty(confirmModal.pendingDifficulty!)}
                className="px-4 py-2 rounded-md bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700"
              >
                Yes, Change & Reset Round
              </button>
            </div>
          </div>
        </div>
      )}

      {/* About Developer Dialog */}
      {showAboutDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 p-6 space-y-4 text-slate-800">
            <div className="flex items-center justify-between pb-3 border-b">
              <div className="flex items-center gap-2">
                <Info className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold">About GuessNova</h3>
              </div>
              <button 
                onClick={() => setShowAboutDialog(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ×
              </button>
            </div>

            <div className="space-y-3 text-xs leading-relaxed text-slate-600">
              <div className="p-3 rounded-lg bg-indigo-50 border border-indigo-100 text-indigo-950">
                <p><strong>Developer:</strong> Neha Vinod Borkar</p>
                <p><strong>Assigned Track:</strong> Java Development</p>
                <p><strong>Task Title:</strong> Task 2 — Number Guessing Game</p>
                <p><strong>Internship:</strong> Oasis Infobyte (OIBSIP)</p>
              </div>

              <p>
                This desktop game was engineered with <strong>Java Swing</strong> following clean object-oriented architecture:
                <code>GameLogic.java</code> for business rules, <code>GameFrame.java</code> for the GUI, <code>Difficulty.java</code> for configuration,
                and <code>RoundResult.java</code> for round metrics.
              </p>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setShowAboutDialog(false)}
                className="px-4 py-2 rounded-md bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800"
              >
                Close Dialog
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rules Dialog */}
      {showRulesDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 p-6 space-y-4 text-slate-800">
            <div className="flex items-center justify-between pb-3 border-b">
              <div className="flex items-center gap-2">
                <Info className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold">Game Rules & Difficulty</h3>
              </div>
              <button 
                onClick={() => setShowRulesDialog(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ×
              </button>
            </div>

            <div className="space-y-3 text-xs leading-relaxed text-slate-600">
              <table className="w-full text-left border border-slate-200 rounded">
                <thead className="bg-slate-100 font-bold">
                  <tr>
                    <th className="p-2 border-b">Difficulty</th>
                    <th className="p-2 border-b">Range</th>
                    <th className="p-2 border-b">Max Attempts</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="p-2 border-b">Easy</td>
                    <td className="p-2 border-b">1 – 50</td>
                    <td className="p-2 border-b">10</td>
                  </tr>
                  <tr>
                    <td className="p-2 border-b font-medium">Medium (Default)</td>
                    <td className="p-2 border-b">1 – 100</td>
                    <td className="p-2 border-b">7</td>
                  </tr>
                  <tr>
                    <td className="p-2">Hard</td>
                    <td className="p-2">1 – 200</td>
                    <td className="p-2">5</td>
                  </tr>
                </tbody>
              </table>

              <p>• Correct guesses within attempts result in a <strong>WIN</strong>.</p>
              <p>• Using all attempts without finding the secret results in a <strong>LOSS</strong> with secret reveal.</p>
              <p>• Invalid strings or out-of-range inputs <strong>never consume attempts</strong>.</p>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setShowRulesDialog(false)}
                className="px-4 py-2 rounded-md bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
