import React, { useState } from 'react';
import JSZip from 'jszip';
import { JAVA_PROJECT_FILES, JavaFile } from '../data/javaCodebase';
import { 
  FileCode, 
  Copy, 
  Check, 
  Download, 
  FolderArchive, 
  Folder, 
  FileText,
  File,
  Terminal,
  ExternalLink
} from 'lucide-react';

export const CodeExplorer: React.FC = () => {
  const [selectedFileIndex, setSelectedFileIndex] = useState<number>(0);
  const [copied, setCopied] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);

  const activeFile: JavaFile = JAVA_PROJECT_FILES[selectedFileIndex] || JAVA_PROJECT_FILES[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSingle = () => {
    const blob = new Blob([activeFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = activeFile.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();

      // Create folder root: OIBSIP/Task 2 - Number Guessing Game
      const rootFolder = zip.folder('OIBSIP')?.folder('Task 2 - Number Guessing Game');

      if (!rootFolder) {
        throw new Error('Could not initialize zip folder');
      }

      // Add each file into proper directory
      for (const file of JAVA_PROJECT_FILES) {
        rootFolder.file(file.path, file.content);
      }

      // Generate zip blob
      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'OIBSIP-Task2-GuessNova.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to generate ZIP:', err);
    } finally {
      setIsZipping(false);
    }
  };

  const getFileIcon = (filename: string) => {
    if (filename.endsWith('.java')) {
      return <FileCode className="w-4 h-4 text-amber-500 shrink-0" />;
    }
    if (filename.endsWith('.xml')) {
      return <FileText className="w-4 h-4 text-rose-500 shrink-0" />;
    }
    if (filename.endsWith('.md')) {
      return <FileText className="w-4 h-4 text-sky-500 shrink-0" />;
    }
    return <File className="w-4 h-4 text-slate-400 shrink-0" />;
  };

  return (
    <div className="w-full max-w-6xl space-y-4">
      {/* Top Banner & Quick Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-xl bg-white border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-900 text-base">
              Java Source Code & Maven Project
            </span>
            <span className="text-xs text-slate-500">
              · Ready for GitHub <code>OIBSIP</code>
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Complete, beginner-friendly Java code matching every requirement: Java Swing GUI, GameLogic, inclusive Random bounds, and Maven build setup.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-xs transition-colors shadow-xs disabled:opacity-50"
          >
            <FolderArchive className="w-4 h-4" />
            <span>{isZipping ? 'Creating ZIP...' : 'Download Maven ZIP'}</span>
          </button>
        </div>
      </div>

      {/* Code Viewer Layout: Sidebar Files + Code Display */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Left File Navigation */}
        <div className="md:col-span-4 lg:col-span-3 border-r border-slate-200 bg-slate-50 p-3 space-y-3">
          <div className="flex items-center gap-2 px-2 py-1 text-xs font-bold uppercase tracking-wider text-slate-500">
            <Folder className="w-3.5 h-3.5 text-indigo-500" />
            <span>Repository Tree</span>
          </div>

          <div className="space-y-1">
            {JAVA_PROJECT_FILES.map((file, idx) => {
              const isSelected = idx === selectedFileIndex;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFileIndex(idx)}
                  className={`w-full text-left px-3 py-2 rounded-md text-xs font-mono flex items-center justify-between gap-2 transition-colors ${
                    isSelected
                      ? 'bg-indigo-50 text-indigo-900 font-semibold border border-indigo-200'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    {getFileIcon(file.filename)}
                    <span className="truncate">{file.filename}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 uppercase font-sans">
                    {file.language}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Quick CLI command tips */}
          <div className="p-3 rounded-lg bg-slate-900 text-slate-200 text-xs font-mono space-y-2 mt-4">
            <div className="flex items-center gap-1.5 text-slate-400 font-bold text-[11px]">
              <Terminal className="w-3.5 h-3.5 text-indigo-400" />
              <span>Maven Execution</span>
            </div>
            <p className="text-[11px] text-slate-400">Compile & run via terminal:</p>
            <div className="bg-slate-950 p-2 rounded text-[11px] text-emerald-400 select-all overflow-x-auto">
              mvn clean compile exec:java
            </div>
          </div>
        </div>

        {/* Right Code Display Area */}
        <div className="md:col-span-8 lg:col-span-9 flex flex-col bg-slate-950 text-slate-100 overflow-hidden">
          {/* Header of Active File */}
          <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              {getFileIcon(activeFile.filename)}
              <span className="font-mono text-xs font-semibold text-slate-200 truncate">
                {activeFile.path}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
                title="Copy code to clipboard"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                <span>{copied ? 'Copied!' : 'Copy Code'}</span>
              </button>

              <button
                onClick={handleDownloadSingle}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
                title="Download this file"
              >
                <Download className="w-3.5 h-3.5 text-slate-400" />
                <span>Save File</span>
              </button>
            </div>
          </div>

          {/* Description banner */}
          <div className="px-4 py-1.5 bg-slate-900/50 border-b border-slate-800/80 text-xs text-slate-400">
            {activeFile.description}
          </div>

          {/* Code Viewer with Line Numbers */}
          <div className="p-4 overflow-x-auto max-h-[600px] font-mono text-xs leading-relaxed">
            <table className="w-full border-collapse">
              <tbody>
                {activeFile.content.split('\n').map((line, idx) => (
                  <tr key={idx} className="hover:bg-slate-900/70">
                    <td className="pr-4 py-0.5 text-right text-slate-600 select-none w-10 text-[11px]">
                      {idx + 1}
                    </td>
                    <td className="py-0.5 text-slate-200 whitespace-pre">
                      {line}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
