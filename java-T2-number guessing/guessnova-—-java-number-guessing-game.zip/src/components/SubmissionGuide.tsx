import React, { useState } from 'react';
import { 
  GitBranch, 
  FolderGit2, 
  Copy, 
  Check, 
  Linkedin, 
  Youtube, 
  CheckCircle,
  HelpCircle,
  ExternalLink,
  Terminal,
  FileText
} from 'lucide-react';

export const SubmissionGuide: React.FC = () => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const copyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(id);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const gitCommands = `# 1. Clone your Oasis Infobyte repository
git clone https://github.com/<your-username>/OIBSIP.git
cd OIBSIP

# 2. Extract or copy the GuessNova project into Task 2 folder
# (Or extract the downloaded OIBSIP-Task2-GuessNova.zip directly into this repository)

# 3. Verify directory contents
cd "Task 2 - Number Guessing Game"
ls -la

# 4. Test compilation with Maven
mvn clean compile test

# 5. Commit and push your code
git add .
git commit -m "Complete Task 2: Number Guessing Game (GuessNova) with Java Swing GUI and Maven"
git push origin main`;

  const linkedinPost = `🚀 Excited to share my completion of Task 2 under the Java Development internship at Oasis Infobyte (OIBSIP)!

🎯 Project: GuessNova — Number Guessing Game
🛠️ Tech Stack: Java 17, Java Swing (JFrame, JPanel, JTextField, JComboBox), java.util.Random, Maven

✨ Key Highlights:
• Dynamic difficulty settings: Easy (1-50, 10 att), Medium (1-100, 7 att), Hard (1-200, 5 att)
• Robust exception handling with Integer.parseInt() and non-penalty input validation
• Intuitive visual feedback (Too Low, Too High, Correct, and You Lost)
• In-memory round score tracking, win rate calculation, and multi-round replay
• Structured object-oriented codebase adhering to clean code standards

A big thank you to Oasis Infobyte for this enriching hands-on opportunity!

🔗 GitHub Repository: https://github.com/<your-username>/OIBSIP
🎥 Video Demo: [Your Video Link]

#Java #JavaDevelopment #JavaSwing #OasisInfobyte #OIBSIP #Internship #SoftwareEngineering #Coding`;

  return (
    <div className="w-full max-w-5xl space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <FolderGit2 className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-900 text-base">
              Oasis Infobyte (OIBSIP) Task 2 Submission Kit
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Complete compliance checklist, Git repository structure, LinkedIn post template, and demo guidelines for Developer Neha Vinod Borkar.
          </p>
        </div>

        <div className="px-3 py-1.5 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs font-semibold">
          Repo: <code>OIBSIP</code>
        </div>
      </div>

      {/* Grid: 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Step 1: Repository Structure */}
        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-indigo-600 font-bold text-sm">
            <GitBranch className="w-4 h-4" />
            <span>1. Required Repository Layout</span>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            Per Oasis Infobyte instructions, keep all tasks inside a single repository named <strong>OIBSIP</strong>, organized into dedicated task directories:
          </p>

          <div className="p-3 rounded-lg bg-slate-900 text-slate-200 font-mono text-xs overflow-x-auto leading-relaxed">
            <pre className="text-slate-300">
{`OIBSIP/
├── Task 1 - .../
└── Task 2 - Number Guessing Game/
    ├── pom.xml
    ├── README.md
    ├── TESTING_REPORT.md
    └── src/
        └── main/
            └── java/
                └── com/
                    └── oasis/
                        └── guessnova/
                            ├── Main.java
                            ├── GameFrame.java
                            ├── GameLogic.java
                            ├── Difficulty.java
                            └── RoundResult.java`}
            </pre>
          </div>
        </div>

        {/* Step 2: Git Terminal Commands */}
        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
              <Terminal className="w-4 h-4 text-emerald-600" />
              <span>2. Terminal Git Setup Commands</span>
            </div>

            <button
              onClick={() => copyText(gitCommands, 'git')}
              className="flex items-center gap-1 text-xs text-indigo-600 font-semibold hover:text-indigo-700"
            >
              {copiedSection === 'git' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSection === 'git' ? 'Copied' : 'Copy Commands'}</span>
            </button>
          </div>

          <div className="p-3 rounded-lg bg-slate-950 text-emerald-400 font-mono text-xs overflow-x-auto">
            <pre>{gitCommands}</pre>
          </div>
        </div>
      </div>

      {/* Demo Video & LinkedIn Sharing Kit */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Demo Video Flow */}
        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-rose-600 font-bold text-sm">
            <Youtube className="w-4 h-4" />
            <span>3. Video Recording Checklist (Section 16)</span>
          </div>

          <ul className="space-y-2 text-xs text-slate-600">
            <li className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>First 2+ Seconds:</strong> Display title card showing Full Name: <em>Neha Vinod Borkar</em>, Track: <em>Java Development</em>, Task: <em>Task 2 — Number Guessing Game</em>.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>Demonstrate Guessing:</strong> Show both "Too Low!" and "Too High!" messages with attempt counters updating.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>Demonstrate Win:</strong> Guess the secret number and showcase emerald feedback + confetti.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>Demonstrate Loss:</strong> Exhaust attempts to show "You Lost!" and the revealed secret number.
              </span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>Difficulty & Score:</strong> Switch to Easy/Hard and review the completed round ledger table.
              </span>
            </li>
          </ul>
        </div>

        {/* LinkedIn Post Template */}
        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sky-600 font-bold text-sm">
              <Linkedin className="w-4 h-4" />
              <span>4. LinkedIn Submission Post Copy</span>
            </div>

            <button
              onClick={() => copyText(linkedinPost, 'linkedin')}
              className="flex items-center gap-1 text-xs text-indigo-600 font-semibold hover:text-indigo-700"
            >
              {copiedSection === 'linkedin' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSection === 'linkedin' ? 'Copied' : 'Copy Post'}</span>
            </button>
          </div>

          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-700 font-mono whitespace-pre-wrap max-h-56 overflow-y-auto leading-relaxed">
            {linkedinPost}
          </div>
        </div>
      </div>
    </div>
  );
};
