import React, { useState, useEffect } from 'react';
import { 
  Video, 
  Play, 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle2, 
  Maximize2, 
  Sparkles, 
  Timer,
  FileVideo,
  Award
} from 'lucide-react';
import { SwingSimulator } from './SwingSimulator';

interface DemoStep {
  step: number;
  title: string;
  actionRequired: string;
  scriptHint: string;
  completed: boolean;
}

export const DemoVideoPresenter: React.FC = () => {
  const [showTitleCard, setShowTitleCard] = useState<boolean>(true);
  const [titleCardTimer, setTitleCardTimer] = useState<number>(3);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  const demoSteps: DemoStep[] = [
    {
      step: 1,
      title: 'Initial Title Card (Section 16 requirement)',
      actionRequired: 'Display credentials for at least 2 seconds on screen.',
      scriptHint: '"Hello, my name is Neha Vinod Borkar. This is my submission for Oasis Infobyte Java Development Task 2 — Number Guessing Game."',
      completed: true,
    },
    {
      step: 2,
      title: 'Starting a Round (Medium 1–100)',
      actionRequired: 'Show the default game state with 7 attempts and range 1 to 100.',
      scriptHint: '"Here is GuessNova with default Medium difficulty, 1 to 100 range, and 7 total attempts."',
      completed: false,
    },
    {
      step: 3,
      title: 'Demonstrating "Too Low!" Response',
      actionRequired: 'Enter a low number (e.g. 10 or 25) and click Guess.',
      scriptHint: '"I will enter 25. The application provides immediate cool-toned feedback: Too Low! Try a higher number, updating attempts used to 1."',
      completed: false,
    },
    {
      step: 4,
      title: 'Demonstrating "Too High!" Response',
      actionRequired: 'Enter a high number (e.g. 90) and click Guess.',
      scriptHint: '"Next I enter 90. The system displays warm-toned feedback: Too High! Try a lower number. The attempt counter now shows 2 of 7 used."',
      completed: false,
    },
    {
      step: 5,
      title: 'Demonstrating a Correct Guess (Win Condition)',
      actionRequired: 'Use Secret Inspector to find the exact secret number, enter it, and click Guess.',
      scriptHint: '"Now entering the secret number. The application displays emerald success feedback: Correct! You Won!, shows confetti, and logs the win in the history table."',
      completed: false,
    },
    {
      step: 6,
      title: 'Exhausted Attempt Limit (Loss Condition & Reveal)',
      actionRequired: 'Click "New Round", make repeated wrong guesses until attempt 7 is reached.',
      scriptHint: '"Now demonstrating the loss condition. Exhausting all 7 attempts triggers You Lost!, disables the guess input, and reveals the secret number."',
      completed: false,
    },
    {
      step: 7,
      title: 'Changing Difficulty (Easy / Hard)',
      actionRequired: 'Switch dropdown to Easy (1-50, 10 attempts) or Hard (1-200, 5 attempts).',
      scriptHint: '"Switching difficulty to Hard adjusts the range to 1–200 and limits attempts to 5."',
      completed: false,
    },
    {
      step: 8,
      title: 'Multi-Round Replay & Overall Score Summary',
      actionRequired: 'Showcase the completed history table and the bottom status bar statistics.',
      scriptHint: '"The application records each completed round in the JTable with round number, difficulty, result, attempts, and secret number, keeping accurate win rate and totals."',
      completed: false,
    },
  ];

  useEffect(() => {
    let interval: any;
    if (showTitleCard && titleCardTimer > 0) {
      interval = setInterval(() => {
        setTitleCardTimer(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [showTitleCard, titleCardTimer]);

  const activeStep = demoSteps[currentStepIndex];

  return (
    <div className="w-full max-w-5xl space-y-5">
      {/* Top Banner */}
      <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Video className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-900 text-base">
              Task 2 Demo Video Recording Mode
            </h3>
            <span className="text-xs text-slate-500">
              · Built for Section 16 Submission Requirements
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Includes mandatory 2+ second introductory title card followed by interactive guided demonstration flow for recording your submission video.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setShowTitleCard(true);
              setTitleCardTimer(3);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs transition-colors"
          >
            <Timer className="w-4 h-4 text-slate-500" />
            <span>Show Title Card</span>
          </button>
        </div>
      </div>

      {/* Mandatory Title Card (Section 16: First frame must display for at least 2 seconds) */}
      {showTitleCard ? (
        <div className="w-full aspect-video min-h-[420px] rounded-2xl bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 text-white p-8 md:p-12 flex flex-col justify-between shadow-2xl relative overflow-hidden border border-indigo-900/50">
          <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Top Organization Header */}
          <div className="flex items-center justify-between z-10 border-b border-white/10 pb-4">
            <div className="flex items-center gap-2">
              <span className="text-xl">☕</span>
              <span className="font-bold tracking-widest text-xs uppercase text-indigo-300">
                Oasis Infobyte Internship Program (OIBSIP)
              </span>
            </div>
            <div className="px-3 py-1 rounded-full bg-white/10 text-xs font-mono">
              Title Card ({titleCardTimer > 0 ? `${titleCardTimer}s required` : 'Ready to Proceed'})
            </div>
          </div>

          {/* Central Required Credentials */}
          <div className="my-auto py-6 space-y-4 z-10 text-center max-w-2xl mx-auto">
            <div className="inline-block px-3 py-1 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-bold uppercase tracking-wider">
              Project Demonstration
            </div>

            <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight">
              GuessNova
            </h1>
            <p className="text-base text-slate-300">
              Java Swing Number Guessing Game
            </p>

            {/* Official Credentials matching Section 16 format */}
            <div className="p-6 rounded-xl bg-white/5 border border-white/10 backdrop-blur-xs space-y-2 text-left max-w-md mx-auto font-mono text-sm">
              <p className="text-slate-300">
                <span className="text-slate-400 font-sans">Full Name:</span>{' '}
                <strong className="text-white text-base">Neha Vinod Borkar</strong>
              </p>
              <p className="text-slate-300">
                <span className="text-slate-400 font-sans">Assigned Track:</span>{' '}
                <strong className="text-indigo-300">Java Development</strong>
              </p>
              <p className="text-slate-300">
                <span className="text-slate-400 font-sans">Task Title:</span>{' '}
                <strong className="text-emerald-400">Task 2 — Number Guessing Game</strong>
              </p>
            </div>
          </div>

          {/* Bottom Bar: Dismiss Button */}
          <div className="flex items-center justify-between pt-4 border-t border-white/10 z-10">
            <span className="text-xs text-slate-400">
              Leave this on screen for ≥ 2 seconds when recording your demo video.
            </span>

            <button
              onClick={() => setShowTitleCard(false)}
              className="flex items-center gap-2 px-6 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition-all"
            >
              <span>Start Live Application Demo</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        /* Demonstration Mode with Step Controller */
        <div className="space-y-4">
          {/* Step Guide Banner */}
          <div className="p-4 rounded-xl bg-slate-900 text-white border border-slate-800 shadow-md space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-indigo-600 text-[11px] font-bold">
                  Step {activeStep.step} of {demoSteps.length}
                </span>
                <h4 className="font-bold text-sm text-slate-100">
                  {activeStep.title}
                </h4>
              </div>

              <div className="flex items-center gap-2">
                <button
                  disabled={currentStepIndex === 0}
                  onClick={() => setCurrentStepIndex(prev => Math.max(0, prev - 1))}
                  className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs text-slate-200"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  disabled={currentStepIndex === demoSteps.length - 1}
                  onClick={() => setCurrentStepIndex(prev => Math.min(demoSteps.length - 1, prev + 1))}
                  className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs text-slate-200"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div>
                <span className="text-slate-400 block font-semibold mb-0.5">What to show in the app:</span>
                <span className="text-indigo-300 font-medium">{activeStep.actionRequired}</span>
              </div>
              <div>
                <span className="text-slate-400 block font-semibold mb-0.5">Recommended Voiceover Script:</span>
                <span className="text-slate-300 italic">{activeStep.scriptHint}</span>
              </div>
            </div>
          </div>

          {/* Embedded Simulator to record live */}
          <SwingSimulator />
        </div>
      )}
    </div>
  );
};
