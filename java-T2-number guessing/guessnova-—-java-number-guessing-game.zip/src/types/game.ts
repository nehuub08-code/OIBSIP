export type DifficultyLevel = 'easy' | 'medium' | 'hard';

export interface DifficultyConfig {
  id: DifficultyLevel;
  name: string;
  min: number;
  max: number;
  maxAttempts: number;
  description: string;
}

export const DIFFICULTY_CONFIGS: Record<DifficultyLevel, DifficultyConfig> = {
  easy: {
    id: 'easy',
    name: 'Easy',
    min: 1,
    max: 50,
    maxAttempts: 10,
    description: '1–50 (10 attempts max)',
  },
  medium: {
    id: 'medium',
    name: 'Medium',
    min: 1,
    max: 100,
    maxAttempts: 7,
    description: '1–100 (7 attempts max) — Default',
  },
  hard: {
    id: 'hard',
    name: 'Hard',
    min: 1,
    max: 200,
    maxAttempts: 5,
    description: '1–200 (5 attempts max)',
  },
};

export type FeedbackType = 'neutral' | 'too_low' | 'too_high' | 'correct' | 'lost' | 'invalid';

export interface FeedbackState {
  type: FeedbackType;
  title: string;
  message: string;
  hint?: string;
}

export interface GuessRecord {
  guess: number;
  result: 'too_low' | 'too_high' | 'correct';
  feedback: string;
  attemptsUsed: number;
  attemptsRemaining: number;
  timestamp: string;
}

export interface CompletedRound {
  roundNumber: number;
  difficulty: DifficultyLevel;
  difficultyName: string;
  rangeText: string;
  secretNumber: number;
  attemptsUsed: number;
  maxAttempts: number;
  won: boolean;
  guesses: GuessRecord[];
  summary: string;
  date: string;
}

export interface OverallStats {
  totalRounds: number;
  roundsWon: number;
  roundsLost: number;
  totalValidGuesses: number;
  winRate: number;
  bestAttempts: number | null;
}
