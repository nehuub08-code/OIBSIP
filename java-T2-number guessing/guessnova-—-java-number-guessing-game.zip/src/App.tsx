import React, { useState } from 'react';
import JSZip from 'jszip';
import { SwingSimulator } from './components/SwingSimulator';
import { CodeExplorer } from './components/CodeExplorer';
import { AutomatedTestSuite } from './components/AutomatedTestSuite';
import { DemoVideoPresenter } from './components/DemoVideoPresenter';
import { SubmissionGuide } from './components/SubmissionGuide';
import { JAVA_PROJECT_FILES } from './data/javaCodebase';
import { 
  Gamepad2, 
  Code2, 
  CheckSquare2, 
  Video, 
  FolderGit2, 
  FolderArchive,
  GraduationCap
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'code' | 'tests' | 'video' | 'submission'>('simulator');
  const [isZipping, setIsZipping] = useState<boolean>(false);

  const handleDownloadAllZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();
      const rootFolder = zip.folder('OIBSIP')?.folder('Task 2 - Number Guessing Game');
      if (rootFolder) {
        for (const file of JAVA_PROJECT_FILES) {
          rootFolder.file(file.path, file.content);
        }
      }
      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'OIBSIP-Task2-GuessNova.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans">
      {/* Top Header Navigation */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
        <div className="max-w-6xl mx-auto px-4 py-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          {/* Brand Identity */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center text-lg font-bold shadow-xs">
              ☕
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-extrabold text-slate-900 tracking-tight">
                  GuessNova
                </h1>
                <span className="text-xs text-slate-400">/</span>
                <span className="text-xs font-semibold text-indigo-600">
                  Java Task 2
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Oasis Infobyte Internship · Developer: <strong className="text-slate-700 font-medium">Neha Vinod Borkar</strong>
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              onClick={handleDownloadAllZip}
              disabled={isZipping}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold border border-indigo-200 transition-colors disabled:opacity-50"
              title="Download entire project files ready for submission"
            >
              <FolderArchive className="w-4 h-4" />
              <span>{isZipping ? 'Archiving...' : 'Download Maven ZIP'}</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-6xl mx-auto px-4 border-t border-slate-100">
          <nav className="flex items-center gap-1 overflow-x-auto py-1 scrollbar-none">
            <button
              onClick={() => setActiveTab('simulator')}
              className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors shrink-0 ${
                activeTab === 'simulator'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Gamepad2 className="w-4 h-4" />
              <span>Swing GUI Game</span>
            </button>

            <button
              onClick={() => setActiveTab('code')}
              className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors shrink-0 ${
                activeTab === 'code'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Code2 className="w-4 h-4" />
              <span>Java Source & Maven</span>
            </button>

            <button
              onClick={() => setActiveTab('tests')}
              className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors shrink-0 ${
                activeTab === 'tests'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <CheckSquare2 className="w-4 h-4" />
              <span>QA Checklist (18 Tests)</span>
            </button>

            <button
              onClick={() => setActiveTab('video')}
              className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors shrink-0 ${
                activeTab === 'video'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Video className="w-4 h-4" />
              <span>Demo Video Studio</span>
            </button>

            <button
              onClick={() => setActiveTab('submission')}
              className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors shrink-0 ${
                activeTab === 'submission'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <FolderGit2 className="w-4 h-4" />
              <span>OIBSIP Submission Guide</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-6 flex flex-col items-center">
        {activeTab === 'simulator' && <SwingSimulator />}
        {activeTab === 'code' && <CodeExplorer />}
        {activeTab === 'tests' && <AutomatedTestSuite />}
        {activeTab === 'video' && <DemoVideoPresenter />}
        {activeTab === 'submission' && <SubmissionGuide />}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-4 text-xs text-slate-500">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-indigo-600" />
            <span>
              <strong>Oasis Infobyte Internship Program (OIBSIP)</strong> · Java Development Track · Task 2
            </span>
          </div>
          <div className="text-slate-400">
            Developer: <strong className="text-slate-600">Neha Vinod Borkar</strong> (nehaborkar2408@gmail.com)
          </div>
        </div>
      </footer>
    </div>
  );
}
