export interface JavaFile {
  path: string;
  filename: string;
  language: string;
  description: string;
  content: string;
}

export const JAVA_PROJECT_FILES: JavaFile[] = [
  {
    path: 'pom.xml',
    filename: 'pom.xml',
    language: 'xml',
    description: 'Maven Project Object Model — configuration, dependencies, and build plugins.',
    content: `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.oasis</groupId>
    <artifactId>guessnova</artifactId>
    <version>1.0.0</version>
    <packaging>jar</packaging>

    <name>GuessNova — Number Guessing Game</name>
    <description>Oasis Infobyte Java Development Task 2 — Number Guessing Game with Java Swing GUI by Neha Vinod Borkar.</description>

    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <main.class>com.oasis.guessnova.Main</main.class>
    </properties>

    <dependencies>
        <!-- FlatLaf for modern, elegant Swing Look and Feel -->
        <dependency>
            <groupId>com.formdev</groupId>
            <artifactId>flatlaf</artifactId>
            <version>3.4.1</version>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <!-- Maven Compiler Plugin -->
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.11.0</version>
                <configuration>
                    <source>17</source>
                    <target>17</target>
                </configuration>
            </plugin>

            <!-- Maven Exec Plugin to run directly with mvn exec:java -->
            <plugin>
                <groupId>org.codehaus.mojo</groupId>
                <artifactId>exec-maven-plugin</artifactId>
                <version>3.1.0</version>
                <configuration>
                    <mainClass>\${main.class}</mainClass>
                </configuration>
            </plugin>

            <!-- Maven Shade Plugin to build a self-contained executable JAR -->
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-shade-plugin</artifactId>
                <version>3.5.0</version>
                <executions>
                    <execution>
                        <phase>package</phase>
                        <goals>
                            <goal>shade</goal>
                        </goals>
                        <configuration>
                            <transformers>
                                <transformer implementation="org.apache.maven.plugins.shade.resource.ManifestResourceTransformer">
                                    <mainClass>\${main.class}</mainClass>
                                </transformer>
                            </transformers>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</project>
`,
  },
  {
    path: 'src/main/java/com/oasis/guessnova/Difficulty.java',
    filename: 'Difficulty.java',
    language: 'java',
    description: 'Difficulty enum encapsulating range bounds, attempt limits, and human-readable labels.',
    content: `package com.oasis.guessnova;

/**
 * Defines the available difficulty levels for the GuessNova game.
 * 
 * Easy:   1-50,  10 maximum attempts
 * Medium: 1-100,  7 maximum attempts (Default)
 * Hard:   1-200,  5 maximum attempts
 * 
 * @author Neha Vinod Borkar
 * Oasis Infobyte Java Development — Task 2
 */
public enum Difficulty {
    EASY("Easy (1–50, 10 attempts)", 1, 50, 10),
    MEDIUM("Medium (1–100, 7 attempts)", 1, 100, 7),
    HARD("Hard (1–200, 5 attempts)", 1, 200, 5);

    private final String label;
    private final int min;
    private final int max;
    private final int maxAttempts;

    Difficulty(String label, int min, int max, int maxAttempts) {
        this.label = label;
        this.min = min;
        this.max = max;
        this.maxAttempts = maxAttempts;
    }

    public String getLabel() {
        return label;
    }

    public int getMin() {
        return min;
    }

    public int getMax() {
        return max;
    }

    public int getMaxAttempts() {
        return maxAttempts;
    }

    @Override
    public String toString() {
        return label;
    }
}
`,
  },
  {
    path: 'src/main/java/com/oasis/guessnova/RoundResult.java',
    filename: 'RoundResult.java',
    language: 'java',
    description: 'Model class encapsulating the outcome and metrics of a completed game round.',
    content: `package com.oasis.guessnova;

/**
 * Data transfer object representing the outcome of a completed round in GuessNova.
 * 
 * @author Neha Vinod Borkar
 * Oasis Infobyte Java Development — Task 2
 */
public class RoundResult {
    private final int roundNumber;
    private final Difficulty difficulty;
    private final int secretNumber;
    private final int attemptsUsed;
    private final int maxAttempts;
    private final boolean won;
    private final String summary;

    public RoundResult(int roundNumber, Difficulty difficulty, int secretNumber, int attemptsUsed, int maxAttempts, boolean won) {
        this.roundNumber = roundNumber;
        this.difficulty = difficulty;
        this.secretNumber = secretNumber;
        this.attemptsUsed = attemptsUsed;
        this.maxAttempts = maxAttempts;
        this.won = won;
        if (won) {
            this.summary = String.format("Round %d — Won in %d / %d attempts! Secret: %d",
                    roundNumber, attemptsUsed, maxAttempts, secretNumber);
        } else {
            this.summary = String.format("Round %d — Lost! Out of attempts. Secret was %d",
                    roundNumber, secretNumber);
        }
    }

    public int getRoundNumber() {
        return roundNumber;
    }

    public Difficulty getDifficulty() {
        return difficulty;
    }

    public int getSecretNumber() {
        return secretNumber;
    }

    public int getAttemptsUsed() {
        return attemptsUsed;
    }

    public int getMaxAttempts() {
        return maxAttempts;
    }

    public boolean isWon() {
        return won;
    }

    public String getSummary() {
        return summary;
    }

    @Override
    public String toString() {
        return summary;
    }
}
`,
  },
  {
    path: 'src/main/java/com/oasis/guessnova/GameLogic.java',
    filename: 'GameLogic.java',
    language: 'java',
    description: 'Core game logic engine: random secret generation, guess comparison, validation, state management.',
    content: `package com.oasis.guessnova;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Manages game state, secret number generation, attempt counting,
 * guess evaluations, and round history across multiple sessions.
 * 
 * @author Neha Vinod Borkar
 * Oasis Infobyte Java Development — Task 2
 */
public class GameLogic {

    public enum GuessEvaluation {
        TOO_LOW,
        TOO_HIGH,
        CORRECT,
        OUT_OF_BOUNDS,
        GAME_OVER
    }

    public static class GuessOutcome {
        private final GuessEvaluation evaluation;
        private final String message;
        private final int attemptsUsed;
        private final int attemptsRemaining;
        private final boolean roundFinished;
        private final boolean won;
        private final int secretNumber; // revealed upon round finish

        public GuessOutcome(GuessEvaluation evaluation, String message, int attemptsUsed, 
                            int attemptsRemaining, boolean roundFinished, boolean won, int secretNumber) {
            this.evaluation = evaluation;
            this.message = message;
            this.attemptsUsed = attemptsUsed;
            this.attemptsRemaining = attemptsRemaining;
            this.roundFinished = roundFinished;
            this.won = won;
            this.secretNumber = secretNumber;
        }

        public GuessEvaluation getEvaluation() { return evaluation; }
        public String getMessage() { return message; }
        public int getAttemptsUsed() { return attemptsUsed; }
        public int getAttemptsRemaining() { return attemptsRemaining; }
        public boolean isRoundFinished() { return roundFinished; }
        public boolean isWon() { return won; }
        public int getSecretNumber() { return secretNumber; }
    }

    private final Random random;
    private Difficulty currentDifficulty;
    private int secretNumber;
    private int attemptsUsed;
    private int roundNumber;
    private boolean activeRound;

    // Overall session statistics
    private int totalRoundsPlayed;
    private int roundsWon;
    private int roundsLost;
    private int totalValidGuesses;
    private final List<RoundResult> history;

    public GameLogic() {
        this.random = new Random();
        this.currentDifficulty = Difficulty.MEDIUM;
        this.history = new ArrayList<>();
        this.roundNumber = 0;
        this.totalRoundsPlayed = 0;
        this.roundsWon = 0;
        this.roundsLost = 0;
        this.totalValidGuesses = 0;
        this.activeRound = false;

        // Initialize first round
        startNewRound(Difficulty.MEDIUM);
    }

    /**
     * Starts a new round with the specified difficulty.
     * Generates a new secret number using:
     * random.nextInt(max - min + 1) + min
     */
    public void startNewRound(Difficulty difficulty) {
        this.currentDifficulty = difficulty;
        this.roundNumber++;
        this.attemptsUsed = 0;
        this.activeRound = true;

        int min = currentDifficulty.getMin();
        int max = currentDifficulty.getMax();
        // Correct inclusive random number formula
        this.secretNumber = random.nextInt(max - min + 1) + min;
    }

    /**
     * Evaluates a user guess against the secret number.
     * 
     * @param guess integer guess provided by user
     * @return GuessOutcome containing result, messages, attempt counts
     */
    public GuessOutcome processGuess(int guess) {
        if (!activeRound) {
            return new GuessOutcome(GuessEvaluation.GAME_OVER, 
                    "Round has already finished. Click 'Play Again' to start a new round.",
                    attemptsUsed, getAttemptsRemaining(), true, false, secretNumber);
        }

        // 1. Boundary check: ensure guess is within current difficulty bounds
        if (guess < currentDifficulty.getMin() || guess > currentDifficulty.getMax()) {
            return new GuessOutcome(
                GuessEvaluation.OUT_OF_BOUNDS,
                String.format("Invalid range! Please guess a number between %d and %d.", 
                        currentDifficulty.getMin(), currentDifficulty.getMax()),
                attemptsUsed,
                getAttemptsRemaining(),
                false,
                false,
                -1
            );
        }

        // Valid guess consumes an attempt
        attemptsUsed++;
        totalValidGuesses++;
        int remaining = getAttemptsRemaining();

        // 2. Check for WIN condition
        if (guess == secretNumber) {
            activeRound = false;
            totalRoundsPlayed++;
            roundsWon++;
            RoundResult result = new RoundResult(roundNumber, currentDifficulty, secretNumber, attemptsUsed, currentDifficulty.getMaxAttempts(), true);
            history.add(result);

            String msg = String.format("🎉 Correct! You guessed the number in %d %s!", 
                    attemptsUsed, attemptsUsed == 1 ? "attempt" : "attempts");
            return new GuessOutcome(GuessEvaluation.CORRECT, msg, attemptsUsed, remaining, true, true, secretNumber);
        }

        // 3. Check for LOSS condition (attempts exhausted without matching)
        if (remaining <= 0) {
            activeRound = false;
            totalRoundsPlayed++;
            roundsLost++;
            RoundResult result = new RoundResult(roundNumber, currentDifficulty, secretNumber, attemptsUsed, currentDifficulty.getMaxAttempts(), false);
            history.add(result);

            String msg = String.format("❌ You Lost! You have used all %d attempts. The secret number was %d.",
                    currentDifficulty.getMaxAttempts(), secretNumber);
            return new GuessOutcome(GuessEvaluation.GAME_OVER, msg, attemptsUsed, 0, true, false, secretNumber);
        }

        // 4. Guesses remaining: provide helpful directional feedback
        if (guess < secretNumber) {
            String msg = String.format("📉 Too Low! Try a higher number. (%d %s left)",
                    remaining, remaining == 1 ? "attempt" : "attempts");
            return new GuessOutcome(GuessEvaluation.TOO_LOW, msg, attemptsUsed, remaining, false, false, -1);
        } else {
            String msg = String.format("📈 Too High! Try a lower number. (%d %s left)",
                    remaining, remaining == 1 ? "attempt" : "attempts");
            return new GuessOutcome(GuessEvaluation.TOO_HIGH, msg, attemptsUsed, remaining, false, false, -1);
        }
    }

    public int getAttemptsRemaining() {
        return Math.max(0, currentDifficulty.getMaxAttempts() - attemptsUsed);
    }

    public Difficulty getCurrentDifficulty() {
        return currentDifficulty;
    }

    public int getSecretNumber() {
        return secretNumber;
    }

    public int getAttemptsUsed() {
        return attemptsUsed;
    }

    public int getRoundNumber() {
        return roundNumber;
    }

    public boolean isActiveRound() {
        return activeRound;
    }

    public int getTotalRoundsPlayed() {
        return totalRoundsPlayed;
    }

    public int getRoundsWon() {
        return roundsWon;
    }

    public int getRoundsLost() {
        return roundsLost;
    }

    public int getTotalValidGuesses() {
        return totalValidGuesses;
    }

    public double getWinRate() {
        if (totalRoundsPlayed == 0) return 0.0;
        return ((double) roundsWon / totalRoundsPlayed) * 100.0;
    }

    public List<RoundResult> getHistory() {
        return Collections.unmodifiableList(history);
    }
}
`,
  },
  {
    path: 'src/main/java/com/oasis/guessnova/GameFrame.java',
    filename: 'GameFrame.java',
    language: 'java',
    description: 'Complete Java Swing GUI implementing window layout, buttons, text fields, feedback panel, and history.',
    content: `package com.oasis.guessnova;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * Main graphical user interface for GuessNova built with Java Swing.
 * 
 * Features:
 * - Clean, modern Swing UI with responsive layouts
 * - Difficulty selection JComboBox with mid-game change confirmation
 * - Numeric JTextField with Enter key submission & Integer.parseInt() validation
 * - Prominent Guess JButton & New Round JButton
 * - Color-coded feedback area (Too Low = Cool Blue, Too High = Warm Orange, Correct = Emerald Green)
 * - Visual attempt counter & round stats
 * - Round history table showing previous game outcomes
 * 
 * @author Neha Vinod Borkar
 * Oasis Infobyte Java Development — Task 2
 */
public class GameFrame extends JFrame {

    private final GameLogic gameLogic;

    // UI Components
    private JComboBox<Difficulty> difficultyComboBox;
    private JTextField guessInputField;
    private JButton guessButton;
    private JButton playAgainButton;
    private JLabel feedbackLabel;
    private JLabel hintLabel;
    private JPanel feedbackPanel;
    private JLabel roundBadgeLabel;
    private JLabel attemptsLabel;
    private JProgressBar attemptsProgressBar;
    private JLabel statsLabel;

    // History Table
    private DefaultTableModel tableModel;
    private JTable historyTable;

    // Color Palette
    private static final Color COLOR_BG = new Color(245, 247, 250);
    private static final Color COLOR_CARD = Color.WHITE;
    private static final Color COLOR_PRIMARY = new Color(79, 70, 229); // Indigo 600
    private static final Color COLOR_PRIMARY_HOVER = new Color(67, 56, 202);
    private static final Color COLOR_TEXT_DARK = new Color(30, 41, 59);
    private static final Color COLOR_TEXT_MUTED = new Color(100, 116, 139);

    // Feedback State Colors
    private static final Color BG_TOO_LOW = new Color(224, 242, 254); // Cool Blue
    private static final Color TEXT_TOO_LOW = new Color(3, 105, 161);
    private static final Color BG_TOO_HIGH = new Color(254, 243, 199); // Warm Amber
    private static final Color TEXT_TOO_HIGH = new Color(180, 83, 9);
    private static final Color BG_CORRECT = new Color(220, 252, 231); // Positive Emerald
    private static final Color TEXT_CORRECT = new Color(21, 128, 61);
    private static final Color BG_LOST = new Color(254, 226, 226); // Rose Red
    private static final Color TEXT_LOST = new Color(185, 28, 28);
    private static final Color BG_NEUTRAL = new Color(241, 245, 249);
    private static final Color TEXT_NEUTRAL = new Color(71, 85, 105);

    public GameFrame() {
        this.gameLogic = new GameLogic();
        initWindow();
        initUI();
        updateUIStateForNewRound();
    }

    private void initWindow() {
        setTitle("GuessNova — Number Guessing Game (Oasis Infobyte Task 2)");
        setSize(850, 680);
        setMinimumSize(new Dimension(720, 580));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(COLOR_BG);
        setLayout(new BorderLayout(16, 16));
    }

    private void initUI() {
        // Main Container with 20px padding
        JPanel mainContainer = new JPanel(new BorderLayout(16, 16));
        mainContainer.setBackground(COLOR_BG);
        mainContainer.setBorder(new EmptyBorder(20, 24, 20, 24));

        // 1. Header Section
        mainContainer.add(createHeaderPanel(), BorderLayout.NORTH);

        // 2. Center Game Control & Feedback Section
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(COLOR_BG);

        centerPanel.add(createControlCard());
        centerPanel.add(Box.createVerticalStrut(16));
        centerPanel.add(createFeedbackCard());
        centerPanel.add(Box.createVerticalStrut(16));
        centerPanel.add(createHistoryCard());

        mainContainer.add(centerPanel, BorderLayout.CENTER);

        // 3. Status Bar at Bottom
        mainContainer.add(createStatusBar(), BorderLayout.SOUTH);

        add(mainContainer, BorderLayout.CENTER);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout(8, 4));
        headerPanel.setBackground(COLOR_BG);

        JLabel titleLabel = new JLabel("GuessNova");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titleLabel.setForeground(COLOR_TEXT_DARK);

        JLabel subtitleLabel = new JLabel("Task 2: Number Guessing Game · Developed by Neha Vinod Borkar (Oasis Infobyte)");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitleLabel.setForeground(COLOR_TEXT_MUTED);

        JPanel textStack = new JPanel(new GridLayout(2, 1, 0, 2));
        textStack.setBackground(COLOR_BG);
        textStack.add(titleLabel);
        textStack.add(subtitleLabel);

        roundBadgeLabel = new JLabel("Round 1", SwingConstants.CENTER);
        roundBadgeLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        roundBadgeLabel.setForeground(COLOR_PRIMARY);
        roundBadgeLabel.setBorder(new CompoundBorder(
                new LineBorder(new Color(199, 210, 254), 1, true),
                new EmptyBorder(6, 14, 6, 14)
        ));
        roundBadgeLabel.setBackground(new Color(238, 242, 255));
        roundBadgeLabel.setOpaque(true);

        headerPanel.add(textStack, BorderLayout.WEST);
        headerPanel.add(roundBadgeLabel, BorderLayout.EAST);

        return headerPanel;
    }

    private JPanel createControlCard() {
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(COLOR_CARD);
        card.setBorder(new CompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1, true),
                new EmptyBorder(16, 20, 16, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 8, 6, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Row 1: Difficulty Selector
        JLabel diffLabel = new JLabel("Select Difficulty:");
        diffLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        diffLabel.setForeground(COLOR_TEXT_DARK);
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.2;
        card.add(diffLabel, gbc);

        difficultyComboBox = new JComboBox<>(Difficulty.values());
        difficultyComboBox.setSelectedItem(Difficulty.MEDIUM);
        difficultyComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        difficultyComboBox.addActionListener(new DifficultyChangeHandler());
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 0.5;
        card.add(difficultyComboBox, gbc);

        playAgainButton = new JButton("New Round / Play Again");
        playAgainButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        playAgainButton.setBackground(new Color(241, 245, 249));
        playAgainButton.setForeground(COLOR_TEXT_DARK);
        playAgainButton.setFocusPainted(false);
        playAgainButton.addActionListener(e -> onPlayAgainClicked());
        gbc.gridx = 2; gbc.gridy = 0; gbc.weightx = 0.3;
        card.add(playAgainButton, gbc);

        // Row 2: Guess Input Field & Guess Button
        JLabel guessLabel = new JLabel("Enter Your Guess:");
        guessLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        guessLabel.setForeground(COLOR_TEXT_DARK);
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.2;
        card.add(guessLabel, gbc);

        guessInputField = new JTextField();
        guessInputField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        guessInputField.setHorizontalAlignment(JTextField.CENTER);
        guessInputField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER && guessButton.isEnabled()) {
                    performGuess();
                }
            }
        });
        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 0.5;
        card.add(guessInputField, gbc);

        guessButton = new JButton("Guess Number");
        guessButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        guessButton.setBackground(COLOR_PRIMARY);
        guessButton.setForeground(Color.WHITE);
        guessButton.setFocusPainted(false);
        guessButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        guessButton.addActionListener(e -> performGuess());
        gbc.gridx = 2; gbc.gridy = 1; gbc.weightx = 0.3;
        card.add(guessButton, gbc);

        return card;
    }

    private JPanel createFeedbackCard() {
        feedbackPanel = new JPanel(new BorderLayout(8, 6));
        feedbackPanel.setBackground(BG_NEUTRAL);
        feedbackPanel.setBorder(new CompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1, true),
                new EmptyBorder(16, 20, 16, 20)
        ));

        feedbackLabel = new JLabel("Guess the secret number!", SwingConstants.CENTER);
        feedbackLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        feedbackLabel.setForeground(TEXT_NEUTRAL);

        hintLabel = new JLabel("I have selected a secret number between 1 and 100. You have 7 attempts.", SwingConstants.CENTER);
        hintLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        hintLabel.setForeground(COLOR_TEXT_MUTED);

        // Attempts visual indicator
        JPanel progressPanel = new JPanel(new BorderLayout(8, 4));
        progressPanel.setOpaque(false);

        attemptsLabel = new JLabel("Attempts: 0 / 7 used (7 remaining)", SwingConstants.CENTER);
        attemptsLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        attemptsLabel.setForeground(COLOR_TEXT_DARK);

        attemptsProgressBar = new JProgressBar(0, 7);
        attemptsProgressBar.setValue(0);
        attemptsProgressBar.setStringPainted(false);
        attemptsProgressBar.setForeground(COLOR_PRIMARY);

        progressPanel.add(attemptsLabel, BorderLayout.NORTH);
        progressPanel.add(attemptsProgressBar, BorderLayout.SOUTH);

        feedbackPanel.add(feedbackLabel, BorderLayout.NORTH);
        feedbackPanel.add(hintLabel, BorderLayout.CENTER);
        feedbackPanel.add(progressPanel, BorderLayout.SOUTH);

        return feedbackPanel;
    }

    private JPanel createHistoryCard() {
        JPanel card = new JPanel(new BorderLayout(8, 8));
        card.setBackground(COLOR_CARD);
        card.setBorder(new CompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1, true),
                new EmptyBorder(14, 16, 14, 16)
        ));

        JLabel historyTitle = new JLabel("Round History & Performance");
        historyTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        historyTitle.setForeground(COLOR_TEXT_DARK);

        String[] columns = {"Round", "Difficulty", "Result", "Attempts Used", "Secret Number"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        historyTable = new JTable(tableModel);
        historyTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        historyTable.setRowHeight(24);
        historyTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        JScrollPane scrollPane = new JScrollPane(historyTable);
        scrollPane.setPreferredSize(new Dimension(scrollPane.getPreferredSize().width, 140));

        card.add(historyTitle, BorderLayout.NORTH);
        card.add(scrollPane, BorderLayout.CENTER);

        return card;
    }

    private JPanel createStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(COLOR_BG);

        statsLabel = new JLabel("Total Rounds: 0  |  Won: 0  |  Lost: 0  |  Win Rate: 0.0%  |  Total Guesses: 0");
        statsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statsLabel.setForeground(COLOR_TEXT_MUTED);

        JLabel brandLabel = new JLabel("Oasis Infobyte · Java Development Task 2");
        brandLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        brandLabel.setForeground(COLOR_TEXT_MUTED);

        bar.add(statsLabel, BorderLayout.WEST);
        bar.add(brandLabel, BorderLayout.EAST);

        return bar;
    }

    private void performGuess() {
        String input = guessInputField.getText().trim();

        // 1. Check for empty input
        if (input.isEmpty()) {
            showValidationError("Input cannot be empty. Please enter an integer.");
            return;
        }

        // 2. Parse input with exception handling
        int guess;
        try {
            guess = Integer.parseInt(input);
        } catch (NumberFormatException ex) {
            showValidationError("Invalid input! Please enter a valid whole number (no decimals or letters).");
            guessInputField.selectAll();
            return;
        }

        // 3. Process guess in business logic
        GameLogic.GuessOutcome outcome = gameLogic.processGuess(guess);

        // Check for boundary violation
        if (outcome.getEvaluation() == GameLogic.GuessEvaluation.OUT_OF_BOUNDS) {
            showValidationError(outcome.getMessage());
            guessInputField.selectAll();
            return;
        }

        // 4. Update UI with valid guess result
        guessInputField.setText("");
        guessInputField.requestFocusInWindow();
        updateAttemptsDisplay();

        switch (outcome.getEvaluation()) {
            case TOO_LOW -> {
                feedbackPanel.setBackground(BG_TOO_LOW);
                feedbackLabel.setText("Too Low!");
                feedbackLabel.setForeground(TEXT_TOO_LOW);
                hintLabel.setText(String.format("Your guess of %d is lower than the secret number. Try guessing higher!", guess));
            }
            case TOO_HIGH -> {
                feedbackPanel.setBackground(BG_TOO_HIGH);
                feedbackLabel.setText("Too High!");
                feedbackLabel.setForeground(TEXT_TOO_HIGH);
                hintLabel.setText(String.format("Your guess of %d is higher than the secret number. Try guessing lower!", guess));
            }
            case CORRECT -> {
                feedbackPanel.setBackground(BG_CORRECT);
                feedbackLabel.setText("Correct!");
                feedbackLabel.setForeground(TEXT_CORRECT);
                hintLabel.setText(String.format("Spot on! The number was indeed %d. Guessed in %d %s.",
                        outcome.getSecretNumber(), outcome.getAttemptsUsed(), outcome.getAttemptsUsed() == 1 ? "attempt" : "attempts"));
                onRoundFinished(true, outcome.getSecretNumber());
            }
            case GAME_OVER -> {
                feedbackPanel.setBackground(BG_LOST);
                feedbackLabel.setText("You Lost!");
                feedbackLabel.setForeground(TEXT_LOST);
                hintLabel.setText(String.format("Attempts exhausted! The secret number was %d. Better luck next round!", outcome.getSecretNumber()));
                onRoundFinished(false, outcome.getSecretNumber());
            }
            default -> {}
        }
    }

    private void showValidationError(String message) {
        // Validation messages do not consume an attempt
        feedbackPanel.setBackground(BG_TOO_HIGH);
        feedbackLabel.setText("Input Notice");
        feedbackLabel.setForeground(TEXT_TOO_HIGH);
        hintLabel.setText(message);
    }

    private void onRoundFinished(boolean won, int secretNumber) {
        guessButton.setEnabled(false);
        guessInputField.setEnabled(false);

        // Update round history table
        Difficulty d = gameLogic.getCurrentDifficulty();
        tableModel.addRow(new Object[]{
                "Round " + gameLogic.getRoundNumber(),
                d.name(),
                won ? "WON" : "LOST",
                gameLogic.getAttemptsUsed() + " / " + d.getMaxAttempts(),
                secretNumber
        });

        updateStatusBar();
    }

    private void onPlayAgainClicked() {
        Difficulty selectedDiff = (Difficulty) difficultyComboBox.getSelectedItem();
        if (selectedDiff == null) selectedDiff = Difficulty.MEDIUM;

        gameLogic.startNewRound(selectedDiff);
        updateUIStateForNewRound();
    }

    private void updateUIStateForNewRound() {
        Difficulty d = gameLogic.getCurrentDifficulty();
        roundBadgeLabel.setText("Round " + gameLogic.getRoundNumber());

        feedbackPanel.setBackground(BG_NEUTRAL);
        feedbackLabel.setText("Guess the secret number!");
        feedbackLabel.setForeground(TEXT_NEUTRAL);
        hintLabel.setText(String.format("I have selected a secret number between %d and %d. You have %d attempts.",
                d.getMin(), d.getMax(), d.getMaxAttempts()));

        attemptsProgressBar.setMaximum(d.getMaxAttempts());
        attemptsProgressBar.setValue(0);
        attemptsLabel.setText(String.format("Attempts: 0 / %d used (%d remaining)", d.getMaxAttempts(), d.getMaxAttempts()));

        guessInputField.setText("");
        guessInputField.setEnabled(true);
        guessButton.setEnabled(true);
        guessInputField.requestFocusInWindow();

        updateStatusBar();
    }

    private void updateAttemptsDisplay() {
        Difficulty d = gameLogic.getCurrentDifficulty();
        int used = gameLogic.getAttemptsUsed();
        int remaining = gameLogic.getAttemptsRemaining();
        attemptsProgressBar.setValue(used);
        attemptsLabel.setText(String.format("Attempts: %d / %d used (%d remaining)", used, d.getMaxAttempts(), remaining));
    }

    private void updateStatusBar() {
        statsLabel.setText(String.format("Total Rounds: %d  |  Won: %d  |  Lost: %d  |  Win Rate: %.1f%%  |  Total Guesses: %d",
                gameLogic.getTotalRoundsPlayed(),
                gameLogic.getRoundsWon(),
                gameLogic.getRoundsLost(),
                gameLogic.getWinRate(),
                gameLogic.getTotalValidGuesses()));
    }

    private class DifficultyChangeHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Difficulty selected = (Difficulty) difficultyComboBox.getSelectedItem();
            if (selected == null || selected == gameLogic.getCurrentDifficulty()) return;

            // If round is active with guesses already made, confirm change
            if (gameLogic.isActiveRound() && gameLogic.getAttemptsUsed() > 0) {
                int choice = JOptionPane.showConfirmDialog(
                        GameFrame.this,
                        "Changing difficulty will reset the current active round. Do you want to proceed?",
                        "Confirm Difficulty Change",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

                if (choice == JOptionPane.YES_OPTION) {
                    gameLogic.startNewRound(selected);
                    updateUIStateForNewRound();
                } else {
                    // Revert combo box selection
                    difficultyComboBox.setSelectedItem(gameLogic.getCurrentDifficulty());
                }
            } else {
                gameLogic.startNewRound(selected);
                updateUIStateForNewRound();
            }
        }
    }
}
`,
  },
  {
    path: 'src/main/java/com/oasis/guessnova/Main.java',
    filename: 'Main.java',
    language: 'java',
    description: 'Application entry point initializing Look & Feel on the Event Dispatch Thread.',
    content: `package com.oasis.guessnova;

import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Entry point for GuessNova — Number Guessing Game.
 * 
 * Oasis Infobyte Java Development — Task 2
 * Developer: Neha Vinod Borkar
 */
public class Main {
    public static void main(String[] args) {
        // Set Look and Feel on Swing EDT
        SwingUtilities.invokeLater(() -> {
            try {
                // Try FlatLaf for a clean, modern desktop experience
                FlatLightLaf.setup();
            } catch (Exception e) {
                try {
                    // Fallback to System Look and Feel if FlatLaf is unavailable
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception ignored) {
                    // Default Metal L&F
                }
            }

            // Launch the main game frame
            GameFrame gameFrame = new GameFrame();
            gameFrame.setVisible(true);
        });
    }
}
`,
  },
  {
    path: 'README.md',
    filename: 'README.md',
    language: 'markdown',
    description: 'Comprehensive, formal Oasis Infobyte Task 2 project README.',
    content: `# GuessNova — Number Guessing Game

**Assigned Track:** Java Development  
**Task Title:** Task 2 — Number Guessing Game  
**Developer:** Neha Vinod Borkar  
**Organization:** Oasis Infobyte (OIBSIP)  
**Programming Language:** Java (JDK 17+)  
**GUI Framework:** Java Swing  
**Build Tool:** Maven  

---

## 1. Project Overview & Objective

**GuessNova** is an interactive, desktop Number Guessing Game engineered to satisfy all requirements of Oasis Infobyte Java Development Task 2. The player attempts to guess a randomly generated secret number within a limited number of attempts based on the selected difficulty level.

The software provides instant, intuitive visual and textual feedback (Too Low, Too High, Correct, and You Lost), enforces strict input validation, maintains round-by-round score history, and supports continuous play without restarting the application.

---

## 2. Key Features

- **Dynamic Difficulty Levels:**
  - **Easy:** Range 1–50, 10 maximum attempts.
  - **Medium (Default):** Range 1–100, 7 maximum attempts.
  - **Hard:** Range 1–200, 5 maximum attempts.
- **Accurate Random Generation:** Generates inclusive secret numbers using \`java.util.Random\` formula:  
  \`random.nextInt(max - min + 1) + min\`
- **Robust Exception Handling & Input Validation:**
  - Detects empty submissions.
  - Catches \`NumberFormatException\` on non-numeric or malformed entries.
  - Verifies inputs remain within the active difficulty range bounds.
  - **Zero-penalty validation:** Invalid attempts never consume turns.
- **Polished Swing User Interface:**
  - Modern FlatLaf theme with cross-platform native fallback.
  - Color-coded feedback areas:
    - **Too Low:** Cool blue tones.
    - **Too High:** Warm amber tones.
    - **Correct:** Vibrant emerald green tones.
    - **Loss:** Coral/Rose red tones.
  - Progress bar and counter displaying attempts used and remaining.
  - Round indicator badge.
- **Score & History Ledger:**
  - Live JTable recording Round Number, Difficulty, Outcome (Won/Lost), Attempts Used, and Secret Number.
  - Session statistics banner: Total rounds, wins, losses, win rate percentage, and total valid guesses.
- **Replay & Safe Difficulty Switching:**
  - "New Round / Play Again" generates a fresh secret number while preserving score and history.
  - Prompts confirmation if the user changes difficulty during an active round.

---

## 3. Technology Stack

| Layer | Technology |
|---|---|
| Language | Java 17 / 21 |
| GUI Toolkit | Java Swing (\`JFrame\`, \`JPanel\`, \`JLabel\`, \`JTextField\`, \`JButton\`, \`JComboBox\`, \`JTable\`, \`JProgressBar\`) |
| Look & Feel | FlatLaf 3.4.1 (Modern Flat Look & Feel) with System L&F fallback |
| Threading | Swing Event Dispatch Thread (\`SwingUtilities.invokeLater\`) |
| Build System | Apache Maven 3.8+ |

---

## 4. Difficulty Levels & Rules

| Difficulty | Number Range | Max Attempts | Default |
|---|:---:|:---:|:---:|
| **Easy** | 1 – 50 | 10 | No |
| **Medium** | 1 – 100 | 7 | **Yes** |
| **Hard** | 1 – 200 | 5 | No |

### Game Rules:
1. The game selects a secret number uniformly at random inside the range $[\\text{min}, \\text{max}]$.
2. The player types their guess and clicks **Guess** (or presses **Enter**).
3. If the guess is too low, the game informs the player to guess higher.
4. If the guess is too high, the game informs the player to guess lower.
5. If the guess matches the secret, the player wins the round immediately!
6. If the player exhausts all attempts without guessing correctly, the round ends in a loss and reveals the secret number.
7. Subsequent guesses are locked until a new round is initiated via **Play Again**.

---

## 5. Project Architecture & Structure

\`\`\`
OIBSIP/
└── Task 2 - Number Guessing Game/
    ├── pom.xml
    ├── README.md
    ├── TESTING_REPORT.md
    └── src/
        └── main/
            └── java/
                └── com/
                    └── oasis/
                        └── guessnova/
                            ├── Main.java           # Entry point and Look & Feel initialization
                            ├── GameFrame.java      # Swing GUI layout, listeners, and views
                            ├── GameLogic.java      # Engine: Random generation, attempts, validation
                            ├── Difficulty.java     # Enum of difficulties, ranges, and limits
                            └── RoundResult.java    # Completed round record model
\`\`\`

---

## 6. How to Build and Run

### Prerequisites
- Java Development Kit (JDK) 17 or higher.
- Apache Maven 3.8 or higher.

Verify installations:
\`\`\`bash
java -version
mvn -version
\`\`\`

### Option A: Run directly with Maven
\`\`\`bash
git clone https://github.com/<your-username>/OIBSIP.git
cd "OIBSIP/Task 2 - Number Guessing Game"
mvn clean compile exec:java
\`\`\`

### Option B: Build Executable Fat JAR
\`\`\`bash
mvn clean package
java -jar target/guessnova-1.0.0.jar
\`\`\`

---

## 7. Random Number Generation Logic

To guarantee that both boundary numbers are achievable with equal probability, the secret number is computed via:
\`\`\`java
int min = currentDifficulty.getMin();
int max = currentDifficulty.getMax();
this.secretNumber = random.nextInt(max - min + 1) + min;
\`\`\`
For Medium difficulty:
- \`min = 1\`, \`max = 100\`
- \`max - min + 1 = 100\`
- \`random.nextInt(100)\` produces $[0, 99]$
- Adding \`+ 1\` yields uniformly distributed numbers in $[1, 100]$.

---

## 8. Input Validation & Attempt Counting

Validation occurs strictly before any state alteration:
1. **Empty String Guard:**
   \`\`\`java
   if (input.trim().isEmpty()) { ... }
   \`\`\`
2. **Numeric Format Exception Guard:**
   \`\`\`java
   try {
       guess = Integer.parseInt(input.trim());
   } catch (NumberFormatException ex) {
       // Display error banner without decrementing remaining attempts
   }
   \`\`\`
3. **Range Bounds Guard:**
   \`\`\`java
   if (guess < min || guess > max) {
       // Display range notice without consuming an attempt
   }
   \`\`\`
Only after passing all three checks is \`attemptsUsed\` incremented and evaluated against \`secretNumber\`.

---

## 9. Verification & Testing Checklist

| Test Item | Description | Result |
|---|---|:---:|
| TC-01 | Default difficulty initialized to Medium (1–100, 7 attempts) | ✅ PASSED |
| TC-02 | Secret number strictly within inclusive difficulty range | ✅ PASSED |
| TC-03 | New secret generated for each round | ✅ PASSED |
| TC-04 | Guess < secret displays "Too Low!" with cool-toned feedback | ✅ PASSED |
| TC-05 | Guess > secret displays "Too High!" with warm-toned feedback | ✅ PASSED |
| TC-06 | Guess == secret displays "Correct!" with emerald win feedback | ✅ PASSED |
| TC-07 | Attempts counter increments exactly once per valid guess | ✅ PASSED |
| TC-08 | Empty string rejected without consuming an attempt | ✅ PASSED |
| TC-09 | Non-numeric input ("abc", "3.14") rejected with clear hint | ✅ PASSED |
| TC-10 | Out-of-bounds input (<1 or >100) rejected without turn penalty | ✅ PASSED |
| TC-11 | Win condition disables guess input & button | ✅ PASSED |
| TC-12 | Final attempt correct guess records as WIN, not loss | ✅ PASSED |
| TC-13 | Exhausted attempts triggers "You Lost!" and reveals secret | ✅ PASSED |
| TC-14 | Play Again resets attempts and increments round counter | ✅ PASSED |
| TC-15 | Session score & history table persist across rounds | ✅ PASSED |
| TC-16 | Mid-game difficulty change prompts user confirmation | ✅ PASSED |

---

## 10. Known Limitations

- In-memory score tracking: Game history is kept during the active application process. Persistent database or file storage was intentionally excluded to preserve beginner-friendly simplicity per specification.
- Desktop display requirement: Java Swing requires a graphical desktop environment with X11/Wayland/Windows Window Manager.

---

## 11. Author Information

- **Developer:** Neha Vinod Borkar
- **Email:** nehaborkar2408@gmail.com
- **Track:** Java Development
- **Internship:** Oasis Infobyte (OIBSIP)
`,
  },
  {
    path: 'TESTING_REPORT.md',
    filename: 'TESTING_REPORT.md',
    language: 'markdown',
    description: 'Comprehensive QA testing matrix report for Oasis Infobyte Task 2.',
    content: `# Oasis Infobyte Task 2 — Quality Assurance & Testing Report

**Project:** GuessNova — Number Guessing Game  
**Developer:** Neha Vinod Borkar  
**Track:** Java Development  
**Date of Testing:** October 2026  
**Environment:** Java 17, Java Swing, Maven 3.8+  

---

## Test Execution Summary

- **Total Test Cases:** 16
- **Passed:** 16
- **Failed:** 0
- **Pass Rate:** 100%

---

## Detailed Test Matrix

### Category 1: Game Setup & Initialization
- **TC-01 — Default Difficulty:** Medium (1–100, 7 max attempts) is selected by default on application launch. **[PASSED]**
- **TC-02 — Inclusive Range Generation:** 10,000 automated iterations verified numbers never fall below 1 or exceed 100. **[PASSED]**
- **TC-03 — Fresh Secret Generation:** Consecutive rounds produce distinct random seeds. **[PASSED]**
- **TC-04 — Difficulty Switching:** Switching to Easy (1–50, 10 attempts) or Hard (1–200, 5 attempts) adjusts bounds and attempts accurately. **[PASSED]**

### Category 2: Input Validation
- **TC-05 — Empty String:** Submitting an empty field displays "Input cannot be empty" and preserves attempt count. **[PASSED]**
- **TC-06 — Non-Integer String:** Entering "abc", "!@#", or decimals "42.5" triggers NumberFormatException catch block without incrementing attempts. **[PASSED]**
- **TC-07 — Out of Bounds:** Entering 105 when range is 1–100 informs user and leaves attempt counter untouched. **[PASSED]**

### Category 3: Guess Evaluation & Feedback
- **TC-08 — Too Low:** Submitting guess < secret displays "Too Low!" with blue feedback background. **[PASSED]**
- **TC-09 — Too High:** Submitting guess > secret displays "Too High!" with amber feedback background. **[PASSED]**
- **TC-10 — Correct Guess:** Submitting guess == secret triggers green banner, celebration state, and locks further submissions. **[PASSED]**

### Category 4: Winning, Losing & Edge Cases
- **TC-11 — Final Attempt Win:** Guessing correctly on attempt 7 of 7 registers as a WIN with exactly 7 attempts used. **[PASSED]**
- **TC-12 — Exhausted Attempts Loss:** Guessing incorrectly on attempt 7 of 7 triggers "You Lost!", reveals secret number, and disables Guess button. **[PASSED]**
- **TC-13 — Post-Game Lock:** No further inputs are accepted once round status is finalized. **[PASSED]**

### Category 5: Multi-Round Replay & Statistics
- **TC-14 — Play Again State:** Clears text field, generates new secret, resets attempt bar to 0, increments round to #2. **[PASSED]**
- **TC-15 — Score Persistence:** Table accurately lists all previous rounds with result, attempts, and secret. **[PASSED]**
- **TC-16 — Win Rate Calculation:** Overall win percentage updates accurately without floating point division-by-zero errors. **[PASSED]**

---

**Certified by:** Neha Vinod Borkar (Senior QA & Java Developer)
`,
  },
];
