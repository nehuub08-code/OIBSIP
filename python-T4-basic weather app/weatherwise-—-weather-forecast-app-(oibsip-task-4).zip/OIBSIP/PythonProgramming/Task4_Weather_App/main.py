"""
WeatherWise - Weather Forecast Desktop Application
OIBSIP Python Programming Internship - Task 4

Main GUI Application built using Tkinter and ttk.
Features:
- Responsive desktop window with modern color palette
- City / ZIP code search with Enter key binding
- Celsius (°C) and Fahrenheit (°F) dynamic unit toggle
- Large current weather hero card (temperature, feels-like, humidity, wind, pressure)
- 6-9 Hour upcoming forecast cards (3-hour API intervals, honestly labeled)
- 5-Day forecast cards with min/max daily temperatures
- Optional IP-based location detection (ipinfo.io)
- Non-blocking background worker threads (GUI never freezes)
- Safe GUI updates using root.after()
- Visible error banners inside the GUI
- OpenWeatherMap icon rendering with Pillow or canvas fallback
"""

import io
import os
import sys
import threading
import time
from typing import Any, Dict, List, Optional

# Tkinter imports
import tkinter as tk
from tkinter import ttk, messagebox

# Pillow for icon rendering (optional with fallback)
try:
    from PIL import Image, ImageTk
    HAS_PILLOW = True
except ImportError:
    HAS_PILLOW = False

# Local application imports
from weather_api import (
    WeatherAPIError,
    fetch_current_weather,
    fetch_forecast,
    fetch_weather_icon,
    detect_location_by_ip,
    get_api_key,
)
from weather_utils import (
    validate_location_input,
    parse_current_weather,
    extract_upcoming_intervals,
    group_forecast_by_day,
    format_temperature,
    celsius_to_fahrenheit,
)


# Color Palette (Modern Deep Indigo & Crisp Accents)
THEME = {
    "bg_main": "#0f172a",         # Slate 900
    "bg_card": "#1e293b",         # Slate 800
    "bg_card_highlight": "#334155",# Slate 700
    "text_primary": "#f8fafc",    # Slate 50
    "text_secondary": "#94a3b8",  # Slate 400
    "text_muted": "#64748b",      # Slate 500
    "accent_blue": "#38bdf8",     # Sky 400
    "accent_purple": "#818cf8",   # Indigo 400
    "accent_orange": "#fb923c",   # Orange 400
    "accent_green": "#4ade80",    # Green 400
    "error_bg": "#450a0a",        # Red 950
    "error_border": "#ef4444",    # Red 500
    "error_text": "#fca5a5",      # Red 300
    "entry_bg": "#0f172a",        # Slate 900
    "entry_fg": "#ffffff",
}


class WeatherWiseApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("WeatherWise — Weather Forecast App (OIBSIP Task 4)")
        self.root.geometry("980x780")
        self.root.minsize(860, 680)
        self.root.configure(bg=THEME["bg_main"])

        # State management
        self.current_unit: str = "C"  # 'C' or 'F'
        self.active_request_id: int = 0
        self.is_fetching: bool = False
        
        # Stored weather records (in metric Celsius, converted on display)
        self.raw_current: Optional[Dict[str, Any]] = None
        self.upcoming_intervals: List[Dict[str, Any]] = []
        self.five_day_summary: List[Dict[str, Any]] = []
        
        # Image cache to prevent Python garbage collection
        self._image_tk_refs: List[Any] = []

        self._configure_styles()
        self._build_ui()
        self._check_api_key_banner()

    def _configure_styles(self):
        """Configures ttk styles to match the modern dark theme."""
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        # Frame styles
        style.configure("Main.TFrame", background=THEME["bg_main"])
        style.configure("Card.TFrame", background=THEME["bg_card"], relief="flat")
        style.configure("SubCard.TFrame", background=THEME["bg_card_highlight"], relief="flat")

        # Label styles
        style.configure("Title.TLabel", background=THEME["bg_main"], foreground=THEME["text_primary"], font=("Segoe UI", 18, "bold"))
        style.configure("Subtitle.TLabel", background=THEME["bg_main"], foreground=THEME["text_secondary"], font=("Segoe UI", 9))
        style.configure("CardTitle.TLabel", background=THEME["bg_card"], foreground=THEME["text_secondary"], font=("Segoe UI", 10, "bold"))

    def _build_ui(self):
        """Constructs the desktop layout with a responsive header, search bar, and content panels."""
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(2, weight=1)

        # 1. Header & Title Bar
        header_frame = tk.Frame(self.root, bg=THEME["bg_main"], padx=20, pady=12)
        header_frame.grid(row=0, column=0, sticky="ew")
        header_frame.columnconfigure(0, weight=1)

        title_box = tk.Frame(header_frame, bg=THEME["bg_main"])
        title_box.pack(side=tk.LEFT)

        title_lbl = tk.Label(
            title_box,
            text="⛅ WeatherWise",
            font=("Segoe UI", 18, "bold"),
            bg=THEME["bg_main"],
            fg=THEME["accent_blue"]
        )
        title_lbl.pack(anchor="w")

        subtitle_lbl = tk.Label(
            title_box,
            text="OIBSIP Task 4 • Live OpenWeatherMap Forecast & Atmospheric Intelligence",
            font=("Segoe UI", 9),
            bg=THEME["bg_main"],
            fg=THEME["text_secondary"]
        )
        subtitle_lbl.pack(anchor="w")

        # Unit Toggle (°C / °F) in Header
        unit_frame = tk.Frame(header_frame, bg=THEME["bg_card"], bd=1, relief="solid")
        unit_frame.pack(side=tk.RIGHT, pady=4)

        self.btn_celsius = tk.Button(
            unit_frame,
            text="°C",
            font=("Segoe UI", 10, "bold"),
            bg=THEME["accent_blue"],
            fg="#0f172a",
            activebackground=THEME["accent_blue"],
            bd=0,
            padx=12,
            pady=4,
            cursor="hand2",
            command=lambda: self.set_unit("C")
        )
        self.btn_celsius.pack(side=tk.LEFT)

        self.btn_fahrenheit = tk.Button(
            unit_frame,
            text="°F",
            font=("Segoe UI", 10, "bold"),
            bg=THEME["bg_card"],
            fg=THEME["text_secondary"],
            activebackground=THEME["bg_card_highlight"],
            bd=0,
            padx=12,
            pady=4,
            cursor="hand2",
            command=lambda: self.set_unit("F")
        )
        self.btn_fahrenheit.pack(side=tk.LEFT)

        # 2. Search & Controls Bar
        search_card = tk.Frame(self.root, bg=THEME["bg_card"], padx=18, pady=12, bd=1, relief="flat")
        search_card.grid(row=1, column=0, sticky="ew", padx=20, pady=(0, 10))
        search_card.columnconfigure(1, weight=1)

        loc_icon_lbl = tk.Label(search_card, text="🔍", font=("Segoe UI", 12), bg=THEME["bg_card"], fg=THEME["text_secondary"])
        loc_icon_lbl.grid(row=0, column=0, padx=(0, 6))

        self.entry_location = tk.Entry(
            search_card,
            font=("Segoe UI", 12),
            bg=THEME["entry_bg"],
            fg=THEME["entry_fg"],
            insertbackground=THEME["accent_blue"],
            relief="flat",
            bd=6
        )
        self.entry_location.grid(row=0, column=1, sticky="ew", padx=(0, 10))
        self.entry_location.insert(0, "Pune")
        self.entry_location.bind("<Return>", lambda event: self.start_fetch_weather())

        self.btn_get_weather = tk.Button(
            search_card,
            text="Get Weather",
            font=("Segoe UI", 10, "bold"),
            bg=THEME["accent_blue"],
            fg="#0f172a",
            activebackground="#0284c7",
            bd=0,
            padx=16,
            pady=6,
            cursor="hand2",
            command=self.start_fetch_weather
        )
        self.btn_get_weather.grid(row=0, column=2, padx=(0, 8))

        self.btn_detect_location = tk.Button(
            search_card,
            text="📍 Detect My Location",
            font=("Segoe UI", 10),
            bg=THEME["bg_card_highlight"],
            fg=THEME["text_primary"],
            activebackground="#475569",
            bd=0,
            padx=12,
            pady=6,
            cursor="hand2",
            command=self.start_detect_location
        )
        self.btn_detect_location.grid(row=0, column=3)

        # Error / Alert Banner (Hidden by default)
        self.error_banner = tk.Frame(self.root, bg=THEME["error_bg"], bd=1, relief="solid", padx=14, pady=8)
        self.lbl_error = tk.Label(
            self.error_banner,
            text="",
            font=("Segoe UI", 10),
            bg=THEME["error_bg"],
            fg=THEME["error_text"],
            wraplength=880,
            justify="left"
        )
        self.lbl_error.pack(side=tk.LEFT, fill="x", expand=True)

        self.btn_dismiss_error = tk.Button(
            self.error_banner,
            text="✕",
            font=("Segoe UI", 9, "bold"),
            bg=THEME["error_bg"],
            fg=THEME["error_text"],
            bd=0,
            cursor="hand2",
            command=self.hide_error
        )
        self.btn_dismiss_error.pack(side=tk.RIGHT, padx=4)

        # 3. Main Scrollable or Grid Workspace
        workspace = tk.Frame(self.root, bg=THEME["bg_main"], padx=20, pady=4)
        workspace.grid(row=2, column=0, sticky="nsew")
        workspace.columnconfigure(0, weight=5)  # Left: Current weather
        workspace.columnconfigure(1, weight=6)  # Right: 6-hour + 5-day forecasts
        workspace.rowconfigure(0, weight=1)

        # Left Column: Current Weather Hero Card
        self.current_card = tk.Frame(workspace, bg=THEME["bg_card"], padx=20, pady=18, bd=1, relief="flat")
        self.current_card.grid(row=0, column=0, sticky="nsew", padx=(0, 10), pady=(0, 10))
        self._build_current_weather_panel(self.current_card)

        # Right Column: Forecasts (Upcoming 6-9h + 5-Day)
        forecast_column = tk.Frame(workspace, bg=THEME["bg_main"])
        forecast_column.grid(row=0, column=1, sticky="nsew", padx=(0, 0), pady=(0, 10))
        forecast_column.columnconfigure(0, weight=1)
        forecast_column.rowconfigure(0, weight=4)
        forecast_column.rowconfigure(1, weight=6)

        # Right-Top: Next 6-9 Hours Forecast Card
        self.hourly_card = tk.Frame(forecast_column, bg=THEME["bg_card"], padx=16, pady=14, bd=1, relief="flat")
        self.hourly_card.grid(row=0, column=0, sticky="nsew", pady=(0, 10))
        self._build_upcoming_forecast_panel(self.hourly_card)

        # Right-Bottom: 5-Day Forecast Card
        self.daily_card = tk.Frame(forecast_column, bg=THEME["bg_card"], padx=16, pady=14, bd=1, relief="flat")
        self.daily_card.grid(row=1, column=0, sticky="nsew")
        self._build_five_day_forecast_panel(self.daily_card)

        # 4. Status Bar
        self.status_bar = tk.Frame(self.root, bg=THEME["bg_card"], padx=16, pady=4)
        self.status_bar.grid(row=3, column=0, sticky="ew")

        self.lbl_status = tk.Label(
            self.status_bar,
            text="Ready. Enter a city name and click 'Get Weather'.",
            font=("Segoe UI", 9),
            bg=THEME["bg_card"],
            fg=THEME["text_secondary"]
        )
        self.lbl_status.pack(side=tk.LEFT)

        self.lbl_api_note = tk.Label(
            self.status_bar,
            text="Free OpenWeatherMap 3h interval tier",
            font=("Segoe UI", 8),
            bg=THEME["bg_card"],
            fg=THEME["text_muted"]
        )
        self.lbl_api_note.pack(side=tk.RIGHT)

    def _build_current_weather_panel(self, parent: tk.Frame):
        """Constructs the hero current weather metrics panel."""
        top_row = tk.Frame(parent, bg=THEME["bg_card"])
        top_row.pack(fill="x", pady=(0, 10))

        self.lbl_city = tk.Label(
            top_row,
            text="Ready to explore",
            font=("Segoe UI", 18, "bold"),
            bg=THEME["bg_card"],
            fg=THEME["text_primary"]
        )
        self.lbl_city.pack(side=tk.LEFT)

        self.lbl_timestamp = tk.Label(
            top_row,
            text="",
            font=("Segoe UI", 9),
            bg=THEME["bg_card"],
            fg=THEME["text_secondary"]
        )
        self.lbl_timestamp.pack(side=tk.RIGHT, pady=4)

        # Hero Temperature and Icon row
        temp_row = tk.Frame(parent, bg=THEME["bg_card"])
        temp_row.pack(fill="x", pady=10)

        self.canvas_icon = tk.Canvas(temp_row, width=80, height=80, bg=THEME["bg_card"], highlightthickness=0)
        self.canvas_icon.pack(side=tk.LEFT, padx=(0, 12))

        temp_box = tk.Frame(temp_row, bg=THEME["bg_card"])
        temp_box.pack(side=tk.LEFT)

        self.lbl_temperature = tk.Label(
            temp_box,
            text="--",
            font=("Segoe UI", 36, "bold"),
            bg=THEME["bg_card"],
            fg=THEME["accent_blue"]
        )
        self.lbl_temperature.pack(anchor="w")

        self.lbl_condition = tk.Label(
            temp_box,
            text="Enter location to view weather",
            font=("Segoe UI", 11, "bold"),
            bg=THEME["bg_card"],
            fg=THEME["text_primary"]
        )
        self.lbl_condition.pack(anchor="w")

        # Metric Tiles (Grid 2x2: Feels Like, Humidity, Wind, Pressure)
        metrics_frame = tk.Frame(parent, bg=THEME["bg_card"])
        metrics_frame.pack(fill="both", expand=True, pady=(15, 0))
        metrics_frame.columnconfigure(0, weight=1)
        metrics_frame.columnconfigure(1, weight=1)

        # Tile 1: Feels Like
        self.tile_feels_like = self._create_metric_tile(metrics_frame, 0, 0, "🌡️ Feels Like", "--")
        # Tile 2: Humidity
        self.tile_humidity = self._create_metric_tile(metrics_frame, 0, 1, "💧 Humidity", "--")
        # Tile 3: Wind Speed
        self.tile_wind = self._create_metric_tile(metrics_frame, 1, 0, "💨 Wind Speed", "--")
        # Tile 4: Pressure
        self.tile_pressure = self._create_metric_tile(metrics_frame, 1, 1, "⏲️ Pressure", "--")

    def _create_metric_tile(self, parent: tk.Frame, row: int, col: int, label: str, default_val: str) -> tk.Label:
        box = tk.Frame(parent, bg=THEME["bg_card_highlight"], padx=12, pady=10, bd=1, relief="flat")
        box.grid(row=row, column=col, sticky="nsew", padx=4, pady=4)
        
        lbl_title = tk.Label(box, text=label, font=("Segoe UI", 9), bg=THEME["bg_card_highlight"], fg=THEME["text_secondary"])
        lbl_title.pack(anchor="w")

        lbl_value = tk.Label(box, text=default_val, font=("Segoe UI", 12, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_primary"])
        lbl_value.pack(anchor="w", pady=(3, 0))
        return lbl_value

    def _build_upcoming_forecast_panel(self, parent: tk.Frame):
        """Constructs the upcoming next 6-9 hours forecast section."""
        header_row = tk.Frame(parent, bg=THEME["bg_card"])
        header_row.pack(fill="x", pady=(0, 8))

        lbl_title = tk.Label(
            header_row,
            text="⏱️ Next 6–9 Hours (3-Hour Forecast Steps)",
            font=("Segoe UI", 10, "bold"),
            bg=THEME["bg_card"],
            fg=THEME["accent_orange"]
        )
        lbl_title.pack(side=tk.LEFT)

        lbl_note = tk.Label(
            header_row,
            text="API standard intervals",
            font=("Segoe UI", 8),
            bg=THEME["bg_card"],
            fg=THEME["text_muted"]
        )
        lbl_note.pack(side=tk.RIGHT)

        self.hourly_container = tk.Frame(parent, bg=THEME["bg_card"])
        self.hourly_container.pack(fill="both", expand=True)
        self.hourly_container.columnconfigure((0, 1, 2), weight=1)

        self._render_placeholder_upcoming()

    def _render_placeholder_upcoming(self):
        for widget in self.hourly_container.winfo_children():
            widget.destroy()

        for col in range(3):
            box = tk.Frame(self.hourly_container, bg=THEME["bg_card_highlight"], padx=8, pady=10)
            box.grid(row=0, column=col, sticky="nsew", padx=3)
            tk.Label(box, text=f"+{ (col+1)*3 }h", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_secondary"]).pack()
            tk.Label(box, text="--°", font=("Segoe UI", 14, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_primary"]).pack(pady=4)
            tk.Label(box, text="Waiting...", font=("Segoe UI", 8), bg=THEME["bg_card_highlight"], fg=THEME["text_muted"]).pack()

    def _build_five_day_forecast_panel(self, parent: tk.Frame):
        """Constructs the 5-day daily forecast summary panel."""
        header_row = tk.Frame(parent, bg=THEME["bg_card"])
        header_row.pack(fill="x", pady=(0, 6))

        lbl_title = tk.Label(
            header_row,
            text="📅 5-Day Outlook (Aggregated Daily Min / Max)",
            font=("Segoe UI", 10, "bold"),
            bg=THEME["bg_card"],
            fg=THEME["accent_green"]
        )
        lbl_title.pack(side=tk.LEFT)

        self.daily_container = tk.Frame(parent, bg=THEME["bg_card"])
        self.daily_container.pack(fill="both", expand=True)

        self._render_placeholder_daily()

    def _render_placeholder_daily(self):
        for widget in self.daily_container.winfo_children():
            widget.destroy()

        for i in range(5):
            row_box = tk.Frame(self.daily_container, bg=THEME["bg_card_highlight"], padx=10, pady=5)
            row_box.pack(fill="x", pady=2)
            row_box.columnconfigure(1, weight=1)

            tk.Label(row_box, text=f"Day {i+1}", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_secondary"], width=10, anchor="w").grid(row=0, column=0)
            tk.Label(row_box, text="Forecast pending", font=("Segoe UI", 8), bg=THEME["bg_card_highlight"], fg=THEME["text_muted"], anchor="w").grid(row=0, column=1, sticky="w")
            tk.Label(row_box, text="-- / --", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_primary"], anchor="e").grid(row=0, column=2)

    def _check_api_key_banner(self):
        """Warns the user if the OpenWeatherMap API key is missing."""
        key = get_api_key()
        if not key or key == "your_api_key_here":
            self.show_error(
                "Notice: OPENWEATHER_API_KEY is not set in .env. "
                "Add your free API key to .env or tests to make live calls."
            )

    def set_unit(self, unit: str):
        """Switches the display temperature unit between 'C' and 'F'."""
        if self.current_unit == unit:
            return
        self.current_unit = unit

        # Update button styling
        if unit == "C":
            self.btn_celsius.configure(bg=THEME["accent_blue"], fg="#0f172a")
            self.btn_fahrenheit.configure(bg=THEME["bg_card"], fg=THEME["text_secondary"])
        else:
            self.btn_celsius.configure(bg=THEME["bg_card"], fg=THEME["text_secondary"])
            self.btn_fahrenheit.configure(bg=THEME["accent_blue"], fg="#0f172a")

        # Refresh all displayed values without making unnecessary API calls
        self._refresh_displays_with_current_unit()

    def show_error(self, message: str):
        """Displays a visible error notification banner inside the GUI."""
        self.lbl_error.configure(text=message)
        self.error_banner.grid(row=1, column=0, sticky="ew", padx=20, pady=(0, 10))

    def hide_error(self):
        """Hides the error notification banner."""
        self.error_banner.grid_forget()

    def set_status(self, text: str, is_loading: bool = False):
        """Updates the bottom status bar."""
        if is_loading:
            self.lbl_status.configure(text=f"⏳ {text}", fg=THEME["accent_blue"])
        else:
            self.lbl_status.configure(text=text, fg=THEME["text_secondary"])

    def start_fetch_weather(self):
        """Validates input and launches the background thread to fetch weather."""
        location_raw = self.entry_location.get()
        is_valid, validated_or_err = validate_location_input(location_raw)

        if not is_valid:
            self.show_error(validated_or_err)
            return

        self.hide_error()
        self.active_request_id += 1
        req_id = self.active_request_id

        self._set_loading_state(True)
        self.set_status(f"Fetching current weather and forecast for '{validated_or_err}'...", is_loading=True)

        # Run network requests in background thread to avoid freezing GUI
        threading.Thread(
            target=self._worker_fetch_weather,
            args=(validated_or_err, req_id),
            daemon=True
        ).start()

    def start_detect_location(self):
        """Triggers optional IP-based location lookup via ipinfo.io in background thread."""
        self.hide_error()
        self.active_request_id += 1
        req_id = self.active_request_id

        self._set_loading_state(True)
        self.set_status("Detecting approximate location using IP...", is_loading=True)

        threading.Thread(
            target=self._worker_detect_location,
            args=(req_id,),
            daemon=True
        ).start()

    def _worker_detect_location(self, req_id: int):
        try:
            city, country = detect_location_by_ip()
            loc_str = f"{city}, {country}" if country else city
            self.root.after(0, self._on_location_detected, loc_str, req_id)
        except WeatherAPIError as e:
            self.root.after(0, self._on_request_error, e.message, req_id)
        except Exception as e:
            self.root.after(0, self._on_request_error, f"Location detection failed: {str(e)}", req_id)

    def _on_location_detected(self, location_name: str, req_id: int):
        if req_id != self.active_request_id:
            return
        self.entry_location.delete(0, tk.END)
        self.entry_location.insert(0, location_name)
        self.set_status(f"Location detected: {location_name}. Fetching weather...")
        # Now automatically fetch weather for detected location
        self.start_fetch_weather()

    def _worker_fetch_weather(self, location: str, req_id: int):
        """Worker thread executing HTTP calls for current weather and forecast."""
        try:
            current_raw = fetch_current_weather(location)
            forecast_raw = fetch_forecast(location)

            # Process pure data models
            parsed_current = parse_current_weather(current_raw)
            upcoming = extract_upcoming_intervals(forecast_raw, count=3)
            daily = group_forecast_by_day(forecast_raw)

            # Fetch icon image bytes
            icon_bytes = fetch_weather_icon(parsed_current["icon_code"])

            # Schedule UI update in main thread
            self.root.after(
                0,
                self._on_fetch_success,
                parsed_current,
                upcoming,
                daily,
                icon_bytes,
                req_id
            )
        except WeatherAPIError as e:
            self.root.after(0, self._on_request_error, e.message, req_id)
        except Exception as e:
            self.root.after(0, self._on_request_error, f"Unexpected error: {str(e)}", req_id)

    def _on_fetch_success(
        self,
        current_data: Dict[str, Any],
        upcoming_data: List[Dict[str, Any]],
        daily_data: List[Dict[str, Any]],
        icon_bytes: Optional[bytes],
        req_id: int
    ):
        """Main thread callback when weather data is successfully fetched."""
        # Check for race condition: ignore if a newer request was dispatched
        if req_id != self.active_request_id:
            return

        self._set_loading_state(False)
        self.raw_current = current_data
        self.upcoming_intervals = upcoming_data
        self.five_day_summary = daily_data

        self.hide_error()
        self.set_status(f"Updated weather for {current_data['full_location']}")

        # Render data onto GUI
        self._refresh_displays_with_current_unit()
        self._draw_weather_icon(icon_bytes, current_data["condition"])

    def _on_request_error(self, error_message: str, req_id: int):
        """Main thread callback on error."""
        if req_id != self.active_request_id:
            return

        self._set_loading_state(False)
        self.show_error(error_message)
        self.set_status("Request failed. Please check error message above.")

    def _set_loading_state(self, is_loading: bool):
        """Disables/enables input buttons during network calls."""
        self.is_fetching = is_loading
        state = tk.DISABLED if is_loading else tk.NORMAL
        self.btn_get_weather.configure(state=state)
        self.btn_detect_location.configure(state=state)

    def _refresh_displays_with_current_unit(self):
        """Refreshes all displayed numbers according to self.current_unit."""
        if not self.raw_current:
            return

        # 1. Current Weather Hero
        unit = self.current_unit
        c = self.raw_current
        
        self.lbl_city.configure(text=c["full_location"])
        self.lbl_timestamp.configure(text=f"Updated: {c['timestamp_str']}")
        self.lbl_temperature.configure(text=format_temperature(c["temp_c"], unit))
        self.lbl_condition.configure(text=f"{c['condition']} — {c['description']}")

        # Metric tiles
        self.tile_feels_like.configure(text=format_temperature(c["feels_like_c"], unit))
        self.tile_humidity.configure(text=f"{c['humidity']}%")
        self.tile_wind.configure(text=f"{c['wind_speed_mps']} m/s ({round(c['wind_speed_mps'] * 3.6, 1)} km/h)")
        self.tile_pressure.configure(text=f"{c['pressure']} hPa")

        # 2. Upcoming 6-9 Hours (3-Hour intervals)
        for widget in self.hourly_container.winfo_children():
            widget.destroy()

        if not self.upcoming_intervals:
            self._render_placeholder_upcoming()
        else:
            for col, item in enumerate(self.upcoming_intervals[:3]):
                box = tk.Frame(self.hourly_container, bg=THEME["bg_card_highlight"], padx=10, pady=10)
                box.grid(row=0, column=col, sticky="nsew", padx=3)
                
                tk.Label(box, text=item["time_label"], font=("Segoe UI", 9, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["accent_orange"]).pack()
                tk.Label(box, text=format_temperature(item["temp_c"], unit), font=("Segoe UI", 13, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_primary"]).pack(pady=3)
                tk.Label(box, text=item["description"], font=("Segoe UI", 8), bg=THEME["bg_card_highlight"], fg=THEME["text_secondary"]).pack()

        # 3. 5-Day Daily Forecast
        for widget in self.daily_container.winfo_children():
            widget.destroy()

        if not self.five_day_summary:
            self._render_placeholder_daily()
        else:
            for day in self.five_day_summary:
                row_box = tk.Frame(self.daily_container, bg=THEME["bg_card_highlight"], padx=10, pady=6)
                row_box.pack(fill="x", pady=2)
                row_box.columnconfigure(1, weight=1)

                day_str = f"{day['day_name'][:3]}, {day['date_formatted']}"
                min_str = format_temperature(day["min_temp_c"], unit)
                max_str = format_temperature(day["max_temp_c"], unit)

                tk.Label(row_box, text=day_str, font=("Segoe UI", 9, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_primary"], width=12, anchor="w").grid(row=0, column=0)
                tk.Label(row_box, text=f"{day['condition']} • {day['description']}", font=("Segoe UI", 8), bg=THEME["bg_card_highlight"], fg=THEME["text_secondary"], anchor="w").grid(row=0, column=1, sticky="w")
                tk.Label(row_box, text=f"L: {min_str}  H: {max_str}", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["accent_green"], anchor="e").grid(row=0, column=2)

    def _draw_weather_icon(self, icon_bytes: Optional[bytes], condition: str):
        """Draws downloaded weather icon onto canvas, or draws custom stylized symbol if Pillow is unavailable."""
        self.canvas_icon.delete("all")

        if icon_bytes and HAS_PILLOW:
            try:
                img = Image.open(io.BytesIO(icon_bytes))
                img = img.resize((72, 72), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(img)
                self._image_tk_refs.append(photo)  # keep reference
                self.canvas_icon.create_image(40, 40, image=photo)
                return
            except Exception:
                pass

        # Stylized Tkinter Canvas Fallback
        cond_lower = condition.lower()
        if "clear" in cond_lower:
            # Sun: golden circle with rays
            self.canvas_icon.create_oval(25, 25, 55, 55, fill="#f59e0b", outline="#fbbf24", width=2)
            self.canvas_icon.create_line(40, 10, 40, 20, fill="#f59e0b", width=3)
            self.canvas_icon.create_line(40, 60, 40, 70, fill="#f59e0b", width=3)
            self.canvas_icon.create_line(10, 40, 20, 40, fill="#f59e0b", width=3)
            self.canvas_icon.create_line(60, 40, 70, 40, fill="#f59e0b", width=3)
        elif "rain" in cond_lower or "drizzle" in cond_lower:
            # Cloud with rain drops
            self.canvas_icon.create_oval(20, 25, 50, 48, fill="#64748b", outline="")
            self.canvas_icon.create_oval(35, 18, 65, 48, fill="#94a3b8", outline="")
            self.canvas_icon.create_line(28, 55, 24, 66, fill="#38bdf8", width=2)
            self.canvas_icon.create_line(42, 55, 38, 66, fill="#38bdf8", width=2)
            self.canvas_icon.create_line(56, 55, 52, 66, fill="#38bdf8", width=2)
        elif "cloud" in cond_lower:
            # Cloud
            self.canvas_icon.create_oval(18, 28, 48, 54, fill="#64748b", outline="")
            self.canvas_icon.create_oval(32, 18, 68, 54, fill="#94a3b8", outline="")
        elif "snow" in cond_lower:
            # Snowflake
            self.canvas_icon.create_line(40, 15, 40, 65, fill="#e2e8f0", width=3)
            self.canvas_icon.create_line(15, 40, 65, 40, fill="#e2e8f0", width=3)
            self.canvas_icon.create_line(22, 22, 58, 58, fill="#e2e8f0", width=3)
            self.canvas_icon.create_line(22, 58, 58, 22, fill="#e2e8f0", width=3)
        else:
            # Generic atmospheric symbol
            self.canvas_icon.create_oval(22, 22, 58, 58, fill="#0284c7", outline="#38bdf8", width=2)
            self.canvas_icon.create_text(40, 40, text="⛅", font=("Segoe UI", 20), fill="#ffffff")


def main():
    root = tk.Tk()
    app = WeatherWiseApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
