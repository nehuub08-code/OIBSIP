"""
WeatherWise - Weather API Client Module
OIBSIP Python Programming Internship - Task 4

This module handles:
- Loading configuration from .env safely
- Communicating with OpenWeatherMap REST endpoints (Current & Forecast)
- Handling HTTP status codes, timeouts, connection errors, and rate limits
- Downloading and caching weather icon images
- Optional IP-based geolocation lookup via ipinfo.io
"""

import json
import os
import sys
from typing import Any, Dict, Optional, Tuple

# Try loading python-dotenv if installed
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Try importing requests; fallback gracefully to standard urllib if requests is missing
try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    import urllib.error
    import urllib.parse
    import urllib.request
    HAS_REQUESTS = False

# Default configuration constants
DEFAULT_TIMEOUT_SECONDS = 10
OPENWEATHER_BASE_URL = "https://api.openweathermap.org/data/2.5"
ICON_URL_TEMPLATE = "https://openweathermap.org/img/wn/{icon_code}@2x.png"
IPINFO_URL = "https://ipinfo.io/json"

# In-memory icon image bytes cache to avoid redundant downloads
_ICON_CACHE: Dict[str, bytes] = {}


class WeatherAPIError(Exception):
    """Custom exception class for user-friendly weather API errors."""
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


def get_api_key() -> str:
    """
    Retrieves the OpenWeatherMap API key from environment variables.
    Never exposes or logs the key value.
    """
    key = os.getenv("OPENWEATHER_API_KEY", "").strip()
    return key


def _http_get_json(url: str, params: Dict[str, Any], timeout: int = DEFAULT_TIMEOUT_SECONDS) -> Dict[str, Any]:
    """
    Internal helper to perform an HTTP GET request and return parsed JSON.
    Uses 'requests' if available, otherwise falls back to standard 'urllib'.
    """
    if HAS_REQUESTS:
        try:
            response = requests.get(url, params=params, timeout=timeout)
        except requests.exceptions.Timeout:
            raise WeatherAPIError("The request timed out. Please try again.")
        except requests.exceptions.ConnectionError:
            raise WeatherAPIError("Unable to connect. Check your internet connection.")
        except requests.exceptions.RequestException as e:
            raise WeatherAPIError(f"Network error: {str(e)}")

        status = response.status_code
        try:
            payload = response.json()
        except Exception:
            payload = {}

        if status == 200:
            return payload
        elif status == 404:
            raise WeatherAPIError("City not found. Check the spelling and try again.", status_code=404)
        elif status == 401:
            raise WeatherAPIError(
                "Invalid or inactive API key. Note: Newly generated OpenWeatherMap keys may take 15 to 60 minutes to activate.",
                status_code=401
            )
        elif status == 429:
            raise WeatherAPIError("The API request limit has been reached. Please wait and try again.", status_code=429)
        elif status >= 500:
            raise WeatherAPIError("OpenWeatherMap service is temporarily down. Please try again later.", status_code=status)
        else:
            msg = payload.get("message", "Failed to retrieve weather data.")
            raise WeatherAPIError(f"Error ({status}): {msg}", status_code=status)

    else:
        # Standard library urllib fallback
        query_string = urllib.parse.urlencode(params)
        full_url = f"{url}?{query_string}"
        req = urllib.request.Request(full_url, headers={"User-Agent": "WeatherWise-OIBSIP/1.0"})

        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read().decode("utf-8")
                return json.loads(data)
        except urllib.error.HTTPError as e:
            status = e.code
            try:
                err_data = json.loads(e.read().decode("utf-8"))
            except Exception:
                err_data = {}

            if status == 404:
                raise WeatherAPIError("City not found. Check the spelling and try again.", status_code=404)
            elif status == 401:
                raise WeatherAPIError(
                    "Invalid or inactive API key. Note: Newly generated OpenWeatherMap keys may take 15 to 60 minutes to activate.",
                    status_code=401
                )
            elif status == 429:
                raise WeatherAPIError("The API request limit has been reached. Please wait and try again.", status_code=429)
            elif status >= 500:
                raise WeatherAPIError("OpenWeatherMap service is temporarily down. Please try again later.", status_code=status)
            else:
                msg = err_data.get("message", "Weather API request failed.")
                raise WeatherAPIError(f"Error ({status}): {msg}", status_code=status)
        except urllib.error.URLError as e:
            if "timed out" in str(e.reason).lower():
                raise WeatherAPIError("The request timed out. Please try again.")
            raise WeatherAPIError("Unable to connect. Check your internet connection.")
        except json.JSONDecodeError:
            raise WeatherAPIError("Received malformed response from weather server.")


def build_location_query(location: str) -> Dict[str, str]:
    """
    Constructs query parameters supporting either city names or postal codes.
    If the location looks like a postal code (digits, or digits with country code),
    it formats it for the 'zip' parameter, otherwise for 'q'.
    """
    cleaned = location.strip()
    # Check if purely digits or digits with comma (e.g., "411001" or "90210,US" or "411001,IN")
    parts = [p.strip() for p in cleaned.split(",")]
    if parts[0].isdigit() or (len(parts) > 1 and parts[0].isdigit()):
        if len(parts) == 1:
            # Default to India if 6 digits, or US if 5 digits, but best is pass zip as-is
            return {"zip": cleaned}
        return {"zip": f"{parts[0]},{parts[1]}"}
    
    return {"q": cleaned}


def fetch_current_weather(location: str, api_key: Optional[str] = None) -> Dict[str, Any]:
    """
    Fetches the current weather report for a given city or ZIP code.
    Units are requested in metric (Celsius) by default.
    """
    key = (api_key or get_api_key()).strip()
    if not key or key == "your_api_key_here":
        raise WeatherAPIError("API key is missing. Please set OPENWEATHER_API_KEY in your .env file.")

    url = f"{OPENWEATHER_BASE_URL}/weather"
    params = build_location_query(location)
    params["appid"] = key
    params["units"] = "metric"

    return _http_get_json(url, params)


def fetch_forecast(location: str, api_key: Optional[str] = None) -> Dict[str, Any]:
    """
    Fetches the 5-day / 3-hour forecast data for a given city or ZIP code.
    Units are requested in metric (Celsius) by default.
    """
    key = (api_key or get_api_key()).strip()
    if not key or key == "your_api_key_here":
        raise WeatherAPIError("API key is missing. Please set OPENWEATHER_API_KEY in your .env file.")

    url = f"{OPENWEATHER_BASE_URL}/forecast"
    params = build_location_query(location)
    params["appid"] = key
    params["units"] = "metric"

    return _http_get_json(url, params)


def fetch_weather_icon(icon_code: str, timeout: int = 5) -> Optional[bytes]:
    """
    Downloads the official OpenWeatherMap icon image binary data.
    Caches downloaded icons in memory during the active session.
    Returns bytes, or None if downloading fails.
    """
    if not icon_code:
        return None

    if icon_code in _ICON_CACHE:
        return _ICON_CACHE[icon_code]

    url = ICON_URL_TEMPLATE.format(icon_code=icon_code)

    try:
        if HAS_REQUESTS:
            resp = requests.get(url, timeout=timeout)
            if resp.status_code == 200:
                data = resp.content
                _ICON_CACHE[icon_code] = data
                return data
        else:
            req = urllib.request.Request(url, headers={"User-Agent": "WeatherWise-OIBSIP/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                _ICON_CACHE[icon_code] = data
                return data
    except Exception:
        # Graceful fallback: return None if icon image cannot be downloaded
        return None

    return None


def detect_location_by_ip(timeout: int = 5) -> Tuple[str, str]:
    """
    Optional bonus feature: detects the user's approximate location
    using ipinfo.io only when explicitly triggered by the user.
    
    Returns:
        (city_name, country_code)
    Raises:
        WeatherAPIError on network error or if detection fails.
    """
    try:
        if HAS_REQUESTS:
            resp = requests.get(IPINFO_URL, timeout=timeout)
            if resp.status_code == 200:
                data = resp.json()
                city = data.get("city", "").strip()
                country = data.get("country", "").strip()
                if city:
                    return city, country
        else:
            req = urllib.request.Request(IPINFO_URL, headers={"User-Agent": "WeatherWise-OIBSIP/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                city = data.get("city", "").strip()
                country = data.get("country", "").strip()
                if city:
                    return city, country
    except Exception as e:
        raise WeatherAPIError("Could not auto-detect location via IP. Please enter your city manually.")

    raise WeatherAPIError("Could not determine city name from IP info.")
