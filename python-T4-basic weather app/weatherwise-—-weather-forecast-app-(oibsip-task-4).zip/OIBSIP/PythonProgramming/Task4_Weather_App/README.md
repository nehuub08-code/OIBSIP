# WeatherWise — Weather Forecast App ⛅

> **OIBSIP Internship Task 4 — Python Programming**  
> **Student:** 2nd Year Computer Engineering  
> **Technology Stack:** Python 3, Tkinter & ttk, `requests`, `python-dotenv`, `Pillow`, OpenWeatherMap API  

---

## 📌 Project Overview

**WeatherWise** is a modern, responsive, and robust desktop weather forecast application developed as part of the **Oasis Infobyte Summer Internship Program (OIBSIP)** Python Programming track.

The application allows users to query real-time atmospheric conditions and multi-day forecasts for any city or postal code worldwide using the official **OpenWeatherMap REST API**. The user interface is designed with a modern dark theme using Python's native `tkinter.ttk` framework, with multi-threaded asynchronous networking to ensure smooth, unfreezing performance.

---

## ✨ Features Checklist

| Feature | Status | Description |
| :--- | :---: | :--- |
| **City & ZIP Code Input** | ✅ | Search by city name (`Pune`, `Tokyo`, `London, UK`) or postal codes (`411001,IN`, `90210,US`). |
| **Real-Time Weather Metrics** | ✅ | Displays Temperature, Feels-Like, Condition, Humidity (%), Wind Speed (m/s & km/h), and Atmospheric Pressure (hPa). |
| **Dynamic Unit Toggle** | ✅ | Instant switch between **Celsius (°C)** and **Fahrenheit (°F)** with zero redundant network queries. |
| **Next 6–9 Hours Forecast** | ✅ | Real upcoming forecast slices using OpenWeatherMap's 3-hour intervals with exact time labels. |
| **5-Day Daily Outlook** | ✅ | Aggregated daily forecast calculating genuine minimum and maximum temperatures across intervals. |
| **Official Weather Icons** | ✅ | Loads official OpenWeatherMap icons with in-memory caching and fallback vector drawings. |
| **Detect My Location** | ✅ | Optional one-click IP-based geolocation lookup via `ipinfo.io` (user-initiated only). |
| **In-GUI Error Notifications** | ✅ | Clear banner messages for city not found (404), invalid API key (401), rate limits (429), and offline network timeouts. |
| **Non-Blocking UI (Threading)** | ✅ | Network requests execute on background daemon threads so the GUI never freezes. |
| **Comprehensive Test Suite** | ✅ | 21 automated unit tests with mocked HTTP responses passing 100%. |

---

## 🛠️ Technology Stack

- **Core Language:** Python 3.10+
- **Graphical User Interface:** `tkinter` & `tkinter.ttk` (native Python GUI toolkit)
- **HTTP Client:** `requests` (with built-in fallback to `urllib.request`)
- **Environment Management:** `python-dotenv`
- **Image Processing:** `Pillow` (`PIL.Image` & `PIL.ImageTk`) for icon rendering
- **Testing Framework:** `unittest` and `unittest.mock`

---

## 📂 Project Structure

```text
OIBSIP/PythonProgramming/Task4_Weather_App/
│
├── main.py                     # GUI entry point (Tkinter app, event loop & threads)
├── weather_api.py              # HTTP client, endpoint definitions & error classification
├── weather_utils.py            # Unit conversion, input validation & data grouping
│
├── tests/
│   ├── __init__.py             # Tests package marker
│   ├── test_weather_utils.py   # Unit tests for temperature conversion & parsing
│   └── test_weather_api.py     # Mocked tests for API responses, 404, 401, 429, timeouts
│
├── requirements.txt            # Third-party Python dependencies
├── .env.example                # Sample environment template (safe to commit)
├── .gitignore                  # Excludes .env, __pycache__, and venv
└── README.md                   # Full documentation and evaluation guide
```

---

## 🔑 How to Obtain an OpenWeatherMap API Key

1. Visit **[OpenWeatherMap](https://openweathermap.org/)** and click **Sign In** / **Create an Account**.
2. Once registered and verified via email, navigate to your profile menu and select **My API Keys**.
3. Under **Create key**, enter a name (e.g., `WeatherWise-App`) and click **Generate**.
4. Copy your 32-character hexadecimal key.
5. **Important Note:** Newly created OpenWeatherMap keys typically take **15 to 60 minutes** to propagate through their CDN servers. If you receive an `Invalid or inactive API key` message initially, wait a short while and retry.

---

## 🚀 Setup & Installation Guide

### Step 1: Clone or Navigate to the Project Folder
```bash
cd OIBSIP/PythonProgramming/Task4_Weather_App
```

### Step 2: Create a Virtual Environment
```bash
python -m venv .venv
```

### Step 3: Activate the Virtual Environment
- **On macOS / Linux:**
  ```bash
  source .venv/bin/activate
  ```
- **On Windows (Command Prompt):**
  ```cmd
  .venv\Scripts\activate.bat
  ```
- **On Windows (PowerShell):**
  ```powershell
  .venv\Scripts\Activate.ps1
  ```

### Step 4: Install Dependencies
```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

> **Note for Linux Users (Ubuntu/Debian):**  
> If Tkinter is not pre-installed on your system distribution, install it via:  
> `sudo apt-get install python3-tk`

### Step 5: Configure Your API Key
Copy `.env.example` to create a real local `.env` file:
```bash
cp .env.example .env
```
Open `.env` in any text editor and paste your key:
```ini
OPENWEATHER_API_KEY=your_actual_32_char_api_key_here
```
*(Notice: The `.gitignore` file guarantees `.env` will never be accidentally committed to git).*

---

## 🖥️ Running the Application

Launch the desktop GUI by executing:
```bash
python main.py
```

### Interacting with the Interface:
1. Type a city name (e.g., `Pune`, `Mumbai`, `London`, `New York`) or postal code into the input field.
2. Press <kbd>Enter</kbd> or click **Get Weather**.
3. Click **°C / °F** in the top right corner anytime to instantly toggle between Celsius and Fahrenheit.
4. Click **📍 Detect My Location** to look up your approximate city via IP.

---

## 🧪 Running Automated Unit Tests

Run the full test suite with verbose reporting:

```bash
python -m unittest discover -s tests -v
```

### Expected Output:
```text
test_01_missing_api_key_raises_error (test_weather_api.TestWeatherAPI) ... ok
test_02_placeholder_api_key_raises_error (test_weather_api.TestWeatherAPI) ... ok
test_03_build_location_query_city_vs_zip (test_weather_api.TestWeatherAPI) ... ok
test_04_successful_fetch_current_weather (test_weather_api.TestWeatherAPI) ... ok
test_05_city_not_found_404_handling (test_weather_api.TestWeatherAPI) ... ok
test_06_invalid_api_key_401_handling (test_weather_api.TestWeatherAPI) ... ok
test_07_request_timeout_handling (test_weather_api.TestWeatherAPI) ... ok
test_08_connection_failure_handling (test_weather_api.TestWeatherAPI) ... ok
test_09_rate_limit_429_handling (test_weather_api.TestWeatherAPI) ... ok
test_10_server_error_500_handling (test_weather_api.TestWeatherAPI) ... ok
test_11_detect_location_by_ip_success (test_weather_api.TestWeatherAPI) ... ok
test_01_celsius_to_fahrenheit_conversion (test_weather_utils.TestWeatherUtils) ... ok
test_02_fahrenheit_to_celsius_conversion (test_weather_utils.TestWeatherUtils) ... ok
test_03_format_temperature_unit_switch (test_weather_utils.TestWeatherUtils) ... ok
test_04_empty_location_validation (test_weather_utils.TestWeatherUtils) ... ok
test_05_parse_valid_current_weather (test_weather_utils.TestWeatherUtils) ... ok
test_06_parse_weather_missing_fields_gracefully (test_weather_utils.TestWeatherUtils) ... ok
test_07_parse_weather_invalid_structure_raises (test_weather_utils.TestWeatherUtils) ... ok
test_08_extract_upcoming_intervals (test_weather_utils.TestWeatherUtils) ... ok
test_09_group_forecast_by_day (test_weather_utils.TestWeatherUtils) ... ok
test_10_group_forecast_empty_or_corrupt_data (test_weather_utils.TestWeatherUtils) ... ok

----------------------------------------------------------------------
Ran 21 tests in 0.019s

OK
```

All network calls in tests are completely mocked using `unittest.mock.patch`, meaning:
- Tests run instantaneously (~0.02 seconds).
- Tests never consume your free OpenWeatherMap API rate limit.
- Tests can execute completely offline.

---

## ⚠️ API Endpoint & Forecast Design Transparency

### OpenWeatherMap Free Tier Limitation:
OpenWeatherMap's free tier provides two primary endpoints:
1. `/data/2.5/weather` — Real-time current conditions.
2. `/data/2.5/forecast` — 5-day forecast provided in **3-hour interval slices** (8 slices per 24 hours), **not** 1-hour interval slices. One-hour resolution is restricted to paid subscriptions ("One Call API 3.0").

### How WeatherWise Handles This Honestly:
- **Upcoming Forecast:** Rather than interpolating fabricated hourly numbers, the app extracts the next three 3-hour slices (covering the next 6 to 9 hours) and clearly displays the actual target forecast timestamp (e.g., `03:00 PM`, `06:00 PM`, `09:00 PM`).
- **5-Day Daily Outlook:** The app groups all 3-hour slices by calendar date, calculating the genuine observed minimum and maximum temperatures across those slices for each day, alongside the midday representative weather condition.

---

## 🔒 Security & Privacy Considerations

1. **Zero Secret Leaks:** Real API keys are stored exclusively in the uncommitted `.env` file and accessed via `os.getenv()`. They are never logged to console or shown in the GUI.
2. **Explicit Geolocation:** Location detection via `ipinfo.io` is strictly opt-in and triggered solely when the user clicks **Detect My Location**. No background or startup tracking occurs.
3. **Safe Network Calls:** A 10-second request timeout prevents hanging sockets in unstable network environments.

---

## 🎓 Viva & Presentation Talking Points (For Internship Evaluation)

When demonstrating WeatherWise to your internship mentor or evaluator:

1. **What is an API?**  
   *Analogous to a restaurant waiter:* The customer (our Tkinter app) asks the waiter for a menu item (weather for "Pune"), the waiter conveys the request to the kitchen (OpenWeatherMap servers), and brings back the prepared dish (JSON data).
2. **Why use JSON?**  
   JavaScript Object Notation is a lightweight, human-readable text standard for data interchange. In Python, `response.json()` converts this string directly into native dictionaries and lists.
3. **Why use threading?**  
   Tkinter runs on a single event loop (`root.mainloop()`). If an HTTP request takes 2 seconds over the network, running it synchronously freezes the window (making it unresponsive or showing "Not Responding"). By running requests in `threading.Thread(daemon=True)` and posting results back via `root.after()`, the user interface stays butter-smooth.
4. **How does unit toggling avoid re-fetching?**  
   All temperatures are stored in memory in Celsius. When the user switches to Fahrenheit, the pure mathematical function `(C * 9/5) + 32` recalculates the labels instantly without wasting API quota.

---

## 📜 License & Acknowledgments

- **Internship:** Oasis Infobyte (OIBSIP)
- **Data Provider:** [OpenWeatherMap API](https://openweathermap.org/)
- **IP Detection:** [ipinfo.io](https://ipinfo.io/)
