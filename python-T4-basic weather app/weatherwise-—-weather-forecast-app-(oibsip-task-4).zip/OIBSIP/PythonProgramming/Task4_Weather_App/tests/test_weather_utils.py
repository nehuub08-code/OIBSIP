"""
Unit tests for weather_utils.py
OIBSIP Python Programming Internship - Task 4

Tests:
1. Celsius-to-Fahrenheit conversion
2. Fahrenheit-to-Celsius conversion
3. Empty location validation & edge cases
4. Parsing valid current weather JSON
5. Handling missing/malformed fields in current weather JSON
6. Grouping 3-hour forecast entries by calendar date
7. Handling missing/empty forecast data
8. Extracting upcoming 3-hour forecast intervals (next 6-9 hours)
"""

import unittest
from datetime import datetime
import sys
import os

# Ensure the parent directory is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from weather_utils import (
    celsius_to_fahrenheit,
    fahrenheit_to_celsius,
    format_temperature,
    validate_location_input,
    parse_current_weather,
    extract_upcoming_intervals,
    group_forecast_by_day,
)


class TestWeatherUtils(unittest.TestCase):

    def test_01_celsius_to_fahrenheit_conversion(self):
        """Test conversion of standard temperatures from Celsius to Fahrenheit."""
        self.assertEqual(celsius_to_fahrenheit(0.0), 32.0)
        self.assertEqual(celsius_to_fahrenheit(100.0), 212.0)
        self.assertEqual(celsius_to_fahrenheit(25.0), 77.0)
        self.assertEqual(celsius_to_fahrenheit(-40.0), -40.0)
        self.assertEqual(celsius_to_fahrenheit(37.0), 98.6)

    def test_02_fahrenheit_to_celsius_conversion(self):
        """Test conversion from Fahrenheit back to Celsius."""
        self.assertEqual(fahrenheit_to_celsius(32.0), 0.0)
        self.assertEqual(fahrenheit_to_celsius(212.0), 100.0)
        self.assertEqual(fahrenheit_to_celsius(77.0), 25.0)
        self.assertEqual(fahrenheit_to_celsius(-40.0), -40.0)
        self.assertEqual(fahrenheit_to_celsius(98.6), 37.0)

    def test_03_format_temperature_unit_switch(self):
        """Test temperature formatting with °C and °F unit string suffixes."""
        self.assertEqual(format_temperature(24.5, "C"), "24.5°C")
        # 24.5 C in F = 76.1 F
        self.assertEqual(format_temperature(24.5, "F"), "76.1°F")

    def test_04_empty_location_validation(self):
        """Test rejection of empty, whitespace-only, and invalid location strings."""
        is_valid, msg = validate_location_input("")
        self.assertFalse(is_valid)
        self.assertIn("enter a city", msg.lower())

        is_valid, msg = validate_location_input("   ")
        self.assertFalse(is_valid)
        self.assertIn("enter a city", msg.lower())

        is_valid, msg = validate_location_input(None)
        self.assertFalse(is_valid)

        is_valid, msg = validate_location_input("A")
        self.assertFalse(is_valid)
        self.assertIn("at least 2 characters", msg.lower())

        is_valid, msg = validate_location_input("Mumbai<script>")
        self.assertFalse(is_valid)
        self.assertIn("invalid characters", msg.lower())

        # Valid inputs
        is_valid, cleaned = validate_location_input("  Pune  ")
        self.assertTrue(is_valid)
        self.assertEqual(cleaned, "Pune")

        is_valid, cleaned = validate_location_input("411001,IN")
        self.assertTrue(is_valid)
        self.assertEqual(cleaned, "411001,IN")

    def test_05_parse_valid_current_weather(self):
        """Test parsing of a complete, valid OpenWeatherMap /weather response."""
        sample_api_response = {
            "coord": {"lon": 73.8567, "lat": 18.5204},
            "weather": [
                {
                    "id": 800,
                    "main": "Clear",
                    "description": "clear sky",
                    "icon": "01d"
                }
            ],
            "base": "stations",
            "main": {
                "temp": 28.5,
                "feels_like": 29.8,
                "temp_min": 27.0,
                "temp_max": 30.0,
                "pressure": 1012,
                "humidity": 45
            },
            "visibility": 10000,
            "wind": {"speed": 3.6, "deg": 240},
            "clouds": {"all": 0},
            "dt": 1698500000,
            "sys": {"country": "IN", "sunrise": 1698455000, "sunset": 1698496000},
            "timezone": 19800,
            "id": 1259229,
            "name": "Pune",
            "cod": 200
        }

        parsed = parse_current_weather(sample_api_response)
        self.assertEqual(parsed["city"], "Pune")
        self.assertEqual(parsed["country"], "IN")
        self.assertEqual(parsed["full_location"], "Pune, IN")
        self.assertEqual(parsed["temp_c"], 28.5)
        self.assertEqual(parsed["feels_like_c"], 29.8)
        self.assertEqual(parsed["humidity"], 45)
        self.assertEqual(parsed["pressure"], 1012)
        self.assertEqual(parsed["wind_speed_mps"], 3.6)
        self.assertEqual(parsed["condition"], "Clear")
        self.assertEqual(parsed["description"], "Clear Sky")
        self.assertEqual(parsed["icon_code"], "01d")

    def test_06_parse_weather_missing_fields_gracefully(self):
        """Test robust handling when optional JSON fields are omitted or None."""
        minimal_response = {
            "name": "Satara",
            "main": {"temp": 22.0},  # missing humidity, pressure, feels_like
            "cod": 200
        }
        parsed = parse_current_weather(minimal_response)
        self.assertEqual(parsed["city"], "Satara")
        self.assertEqual(parsed["temp_c"], 22.0)
        self.assertEqual(parsed["feels_like_c"], 22.0)
        self.assertEqual(parsed["humidity"], 0)
        self.assertEqual(parsed["pressure"], 1013)
        self.assertEqual(parsed["icon_code"], "01d")

    def test_07_parse_weather_invalid_structure_raises(self):
        """Test that malformed JSON without 'main' or temp raises ValueError."""
        with self.assertRaises(ValueError):
            parse_current_weather({"invalid": "structure"})
        with self.assertRaises(ValueError):
            parse_current_weather("not a dictionary")

    def test_08_extract_upcoming_intervals(self):
        """Test extraction of the next 3 intervals (covering upcoming 6-9 hours)."""
        sample_forecast = {
            "list": [
                {
                    "dt": 1698500000,
                    "dt_txt": "2026-10-28 15:00:00",
                    "main": {"temp": 27.2, "humidity": 50},
                    "weather": [{"description": "scattered clouds", "main": "Clouds", "icon": "03d"}]
                },
                {
                    "dt": 1698510800,
                    "dt_txt": "2026-10-28 18:00:00",
                    "main": {"temp": 24.1, "humidity": 65},
                    "weather": [{"description": "few clouds", "main": "Clouds", "icon": "02n"}]
                },
                {
                    "dt": 1698521600,
                    "dt_txt": "2026-10-28 21:00:00",
                    "main": {"temp": 22.0, "humidity": 70},
                    "weather": [{"description": "clear sky", "main": "Clear", "icon": "01n"}]
                },
                {
                    "dt": 1698532400,
                    "dt_txt": "2026-10-29 00:00:00",
                    "main": {"temp": 20.5, "humidity": 75},
                    "weather": [{"description": "clear sky", "main": "Clear", "icon": "01n"}]
                }
            ]
        }

        intervals = extract_upcoming_intervals(sample_forecast, count=3)
        self.assertEqual(len(intervals), 3)
        self.assertEqual(intervals[0]["time_label"], "03:00 PM")
        self.assertEqual(intervals[0]["temp_c"], 27.2)
        self.assertEqual(intervals[1]["time_label"], "06:00 PM")
        self.assertEqual(intervals[2]["time_label"], "09:00 PM")

    def test_09_group_forecast_by_day(self):
        """Test grouping 3-hour forecasts by calendar day to determine min and max."""
        sample_multi_day_forecast = {
            "list": [
                # Day 1: Oct 29
                {"dt_txt": "2026-10-29 09:00:00", "main": {"temp": 20.0, "humidity": 60}, "weather": [{"main": "Clear", "description": "clear", "icon": "01d"}]},
                {"dt_txt": "2026-10-29 12:00:00", "main": {"temp": 30.0, "humidity": 40}, "weather": [{"main": "Clear", "description": "clear sky", "icon": "01d"}]},
                {"dt_txt": "2026-10-29 18:00:00", "main": {"temp": 24.0, "humidity": 50}, "weather": [{"main": "Clear", "description": "clear", "icon": "01n"}]},
                # Day 2: Oct 30
                {"dt_txt": "2026-10-30 06:00:00", "main": {"temp": 18.0, "humidity": 70}, "weather": [{"main": "Rain", "description": "light rain", "icon": "10d"}]},
                {"dt_txt": "2026-10-30 12:00:00", "main": {"temp": 26.0, "humidity": 65}, "weather": [{"main": "Rain", "description": "moderate rain", "icon": "10d"}]},
                # Day 3: Oct 31
                {"dt_txt": "2026-10-31 12:00:00", "main": {"temp": 28.0, "humidity": 55}, "weather": [{"main": "Clouds", "description": "few clouds", "icon": "02d"}]},
            ]
        }

        daily = group_forecast_by_day(sample_multi_day_forecast)
        self.assertEqual(len(daily), 3)

        # Day 1 checks
        day1 = daily[0]
        self.assertEqual(day1["date_key"], "2026-10-29")
        self.assertEqual(day1["min_temp_c"], 20.0)
        self.assertEqual(day1["max_temp_c"], 30.0)
        self.assertEqual(day1["icon_code"], "01d")

        # Day 2 checks
        day2 = daily[1]
        self.assertEqual(day2["date_key"], "2026-10-30")
        self.assertEqual(day2["min_temp_c"], 18.0)
        self.assertEqual(day2["max_temp_c"], 26.0)
        self.assertEqual(day2["condition"], "Rain")

    def test_10_group_forecast_empty_or_corrupt_data(self):
        """Test grouping returns an empty list gracefully when list is empty or invalid."""
        self.assertEqual(group_forecast_by_day({}), [])
        self.assertEqual(group_forecast_by_day({"list": []}), [])
        self.assertEqual(group_forecast_by_day(None), [])


if __name__ == "__main__":
    unittest.main()
