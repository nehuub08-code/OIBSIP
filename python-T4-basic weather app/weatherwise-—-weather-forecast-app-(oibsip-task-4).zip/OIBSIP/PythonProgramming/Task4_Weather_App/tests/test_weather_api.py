"""
Unit tests for weather_api.py
OIBSIP Python Programming Internship - Task 4

Tests:
1. Missing API key validation error
2. Valid city weather fetching (Mocked)
3. 404 City not found response handling
4. 401 Invalid or unactivated API key handling
5. Request timeout handling
6. Connection / network failure handling
7. 429 API rate-limit response handling
8. 500+ Server error handling
9. Location query formatting for city and postal codes
10. IP location detection (Mocked)
"""

import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Ensure parent directory is in path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import weather_api
from weather_api import (
    WeatherAPIError,
    fetch_current_weather,
    fetch_forecast,
    build_location_query,
    detect_location_by_ip,
)


class TestWeatherAPI(unittest.TestCase):

    def test_01_missing_api_key_raises_error(self):
        """Test that attempting to fetch weather without an API key raises WeatherAPIError."""
        with patch.dict(os.environ, {"OPENWEATHER_API_KEY": ""}, clear=True):
            with self.assertRaises(WeatherAPIError) as ctx:
                fetch_current_weather("Pune", api_key="")
            self.assertIn("API key is missing", str(ctx.exception))

    def test_02_placeholder_api_key_raises_error(self):
        """Test that default template placeholder key is caught."""
        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_current_weather("Mumbai", api_key="your_api_key_here")
        self.assertIn("API key is missing", str(ctx.exception))

    def test_03_build_location_query_city_vs_zip(self):
        """Test that query parameters format correctly for cities and postal codes."""
        # Simple city
        q1 = build_location_query("Pune")
        self.assertEqual(q1, {"q": "Pune"})

        # City with country
        q2 = build_location_query("London, UK")
        self.assertEqual(q2, {"q": "London, UK"})

        # Pure numeric postal code
        q3 = build_location_query("411001")
        self.assertEqual(q3, {"zip": "411001"})

        # Postal code with country
        q4 = build_location_query("90210, US")
        self.assertEqual(q4, {"zip": "90210,US"})

    @patch("weather_api._http_get_json")
    def test_04_successful_fetch_current_weather(self, mock_get_json):
        """Test successful response parsing from mocked HTTP request."""
        mock_response = {
            "name": "Pune",
            "cod": 200,
            "main": {"temp": 28.0, "feels_like": 29.0, "humidity": 50},
            "weather": [{"main": "Clear", "description": "clear sky", "icon": "01d"}]
        }
        mock_get_json.return_value = mock_response

        data = fetch_current_weather("Pune", api_key="test_dummy_key_123")
        self.assertEqual(data["name"], "Pune")
        self.assertEqual(data["main"]["temp"], 28.0)
        mock_get_json.assert_called_once()

    @patch("weather_api._http_get_json")
    def test_05_city_not_found_404_handling(self, mock_get_json):
        """Test that a 404 response raises user-friendly 'City not found' error."""
        mock_get_json.side_effect = WeatherAPIError("City not found. Check the spelling and try again.", status_code=404)

        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_current_weather("NonExistentCity999XYZ", api_key="test_dummy_key")
        self.assertEqual(ctx.exception.status_code, 404)
        self.assertIn("City not found", str(ctx.exception))

    @patch("weather_api._http_get_json")
    def test_06_invalid_api_key_401_handling(self, mock_get_json):
        """Test that a 401 response raises user-friendly invalid key error."""
        mock_get_json.side_effect = WeatherAPIError(
            "Invalid or inactive API key. Note: Newly generated OpenWeatherMap keys may take 15 to 60 minutes to activate.",
            status_code=401
        )

        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_current_weather("Pune", api_key="invalid_bad_key")
        self.assertEqual(ctx.exception.status_code, 401)
        self.assertIn("Invalid or inactive API key", str(ctx.exception))

    @patch("weather_api._http_get_json")
    def test_07_request_timeout_handling(self, mock_get_json):
        """Test that network timeout raises user-friendly message."""
        mock_get_json.side_effect = WeatherAPIError("The request timed out. Please try again.")

        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_current_weather("Mumbai", api_key="valid_key")
        self.assertIn("timed out", str(ctx.exception).lower())

    @patch("weather_api._http_get_json")
    def test_08_connection_failure_handling(self, mock_get_json):
        """Test that lack of internet connection raises clear network error."""
        mock_get_json.side_effect = WeatherAPIError("Unable to connect. Check your internet connection.")

        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_current_weather("Mumbai", api_key="valid_key")
        self.assertIn("unable to connect", str(ctx.exception).lower())

    @patch("weather_api._http_get_json")
    def test_09_rate_limit_429_handling(self, mock_get_json):
        """Test that 429 status triggers a rate-limit warning."""
        mock_get_json.side_effect = WeatherAPIError(
            "The API request limit has been reached. Please wait and try again.", status_code=429
        )

        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_forecast("Pune", api_key="valid_key")
        self.assertEqual(ctx.exception.status_code, 429)
        self.assertIn("limit has been reached", str(ctx.exception))

    @patch("weather_api._http_get_json")
    def test_10_server_error_500_handling(self, mock_get_json):
        """Test that 500+ server error is cleanly reported."""
        mock_get_json.side_effect = WeatherAPIError(
            "OpenWeatherMap service is temporarily down. Please try again later.", status_code=500
        )

        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_current_weather("Delhi", api_key="valid_key")
        self.assertEqual(ctx.exception.status_code, 500)
        self.assertIn("temporarily down", str(ctx.exception))

    def test_11_detect_location_by_ip_success(self):
        """Test optional IP detection parsing."""
        sample_json = '{"city": "Pune", "country": "IN", "ip": "103.21.124.1"}'
        if weather_api.HAS_REQUESTS:
            with patch("requests.get") as mock_get:
                mock_resp = MagicMock()
                mock_resp.status_code = 200
                mock_resp.json.return_value = {"city": "Pune", "country": "IN"}
                mock_get.return_value = mock_resp
                city, country = detect_location_by_ip()
                self.assertEqual(city, "Pune")
                self.assertEqual(country, "IN")
        else:
            with patch("urllib.request.urlopen") as mock_urlopen:
                mock_resp = MagicMock()
                mock_resp.read.return_value = sample_json.encode("utf-8")
                mock_resp.__enter__.return_value = mock_resp
                mock_urlopen.return_value = mock_resp
                city, country = detect_location_by_ip()
                self.assertEqual(city, "Pune")
                self.assertEqual(country, "IN")


if __name__ == "__main__":
    unittest.main()
