"""
WeatherWise - Weather Utilities Module
OIBSIP Python Programming Internship - Task 4

This module contains pure, reusable helper functions for:
- Temperature conversions (Celsius <-> Fahrenheit)
- Input validation and sanitization
- Response JSON parsing and field extraction
- Forecast interval filtering (next 6-9 hours)
- 5-day daily forecast aggregation (min/max temperatures & conditions)
"""

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple


def celsius_to_fahrenheit(celsius: float) -> float:
    """
    Converts a temperature from Celsius to Fahrenheit.
    Formula: (Celsius * 9/5) + 32
    """
    return round((celsius * 9.0 / 5.0) + 32.0, 1)


def fahrenheit_to_celsius(fahrenheit: float) -> float:
    """
    Converts a temperature from Fahrenheit to Celsius.
    Formula: (Fahrenheit - 32) * 5/9
    """
    return round((fahrenheit - 32.0) * 5.0 / 9.0, 1)


def format_temperature(temp_celsius: float, unit: str = "C") -> str:
    """
    Formats a Celsius temperature value according to the desired unit ('C' or 'F').
    Keeps a single decimal point or integer format for clean UI display.
    """
    if unit.upper() == "F":
        temp_f = celsius_to_fahrenheit(temp_celsius)
        return f"{temp_f:.1f}°F"
    return f"{temp_celsius:.1f}°C"


def validate_location_input(location_text: Optional[str]) -> Tuple[bool, str]:
    """
    Validates and cleans user input for city or ZIP code.
    
    Returns:
        (is_valid, cleaned_location_or_error_message)
    """
    if location_text is None:
        return False, "Please enter a city or postal code."
    
    cleaned = location_text.strip()
    if not cleaned:
        return False, "Please enter a city or postal code."
    
    if len(cleaned) < 2:
        return False, "Location name must be at least 2 characters."
    
    # Reject strings with suspicious characters
    if any(char in cleaned for char in ["<", ">", ";", "{", "}", "\\"]):
        return False, "Location contains invalid characters."
        
    return True, cleaned


def parse_current_weather(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Safely extracts and standardizes current weather metrics from the
    OpenWeatherMap /weather JSON response.
    
    Raises:
        ValueError: If required core fields are missing or malformed.
    """
    if not isinstance(data, dict):
        raise ValueError("Invalid weather data format received.")
    
    # Check status code if returned in body
    cod = data.get("cod")
    if cod and str(cod) not in ("200", 200):
        msg = data.get("message", "Weather data unavailable.")
        raise ValueError(f"API Error ({cod}): {msg}")

    # Validate essential top-level structures
    main = data.get("main")
    if not isinstance(main, dict) or "temp" not in main:
        raise ValueError("Missing 'main' temperature section in API response.")

    weather_list = data.get("weather", [])
    weather_info = weather_list[0] if (isinstance(weather_list, list) and len(weather_list) > 0) else {}

    sys_info = data.get("sys", {}) if isinstance(data.get("sys"), dict) else {}
    wind_info = data.get("wind", {}) if isinstance(data.get("wind"), dict) else {}

    city_name = data.get("name", "Unknown City")
    country = sys_info.get("country", "")
    full_location = f"{city_name}, {country}" if country else city_name

    # Core temperature in Celsius (assuming units=metric was requested)
    temp_c = float(main.get("temp", 0.0))
    feels_like_c = float(main.get("feels_like", temp_c))
    temp_min_c = float(main.get("temp_min", temp_c))
    temp_max_c = float(main.get("temp_max", temp_c))
    
    humidity = main.get("humidity", 0)
    pressure = main.get("pressure", 1013)
    
    wind_speed = wind_info.get("speed", 0.0)
    wind_deg = wind_info.get("deg", 0)

    condition = weather_info.get("main", "Clear")
    description = weather_info.get("description", "Clear Sky").title()
    icon_code = weather_info.get("icon", "01d")

    # Time of reading
    dt_timestamp = data.get("dt", 0)
    timestamp_str = datetime.fromtimestamp(dt_timestamp).strftime("%I:%M %p, %b %d") if dt_timestamp else "Just now"

    return {
        "city": city_name,
        "country": country,
        "full_location": full_location,
        "temp_c": round(temp_c, 1),
        "feels_like_c": round(feels_like_c, 1),
        "temp_min_c": round(temp_min_c, 1),
        "temp_max_c": round(temp_max_c, 1),
        "humidity": int(humidity),
        "pressure": int(pressure),
        "wind_speed_mps": round(float(wind_speed), 1),
        "wind_deg": int(wind_deg),
        "condition": condition,
        "description": description,
        "icon_code": icon_code,
        "timestamp_str": timestamp_str,
    }


def extract_upcoming_intervals(forecast_data: Dict[str, Any], count: int = 3) -> List[Dict[str, Any]]:
    """
    Extracts the nearest forecast steps (typically 3-hour intervals) from the
    5-day /forecast endpoint to cover the next 6 to 9 hours honestly.
    
    OpenWeatherMap free tier provides forecasts in 3-hour slices (e.g. +3h, +6h, +9h).
    We take `count` slices (default 3 = next 6-9 hours) and clearly preserve the actual
    forecast timestamp so the UI is 100% transparent about the time step.
    """
    if not isinstance(forecast_data, dict):
        return []

    item_list = forecast_data.get("list", [])
    if not isinstance(item_list, list):
        return []

    results = []
    for item in item_list[:count]:
        if not isinstance(item, dict):
            continue
        
        main = item.get("main", {})
        weather = item.get("weather", [{}])[0]
        dt_txt = item.get("dt_txt", "")
        dt_timestamp = item.get("dt", 0)
        
        # Format time label (e.g., "03:00 PM" or "Tomorrow 09:00 AM")
        time_label = "Upcoming"
        if dt_txt:
            try:
                dt_obj = datetime.strptime(dt_txt, "%Y-%m-%d %H:%M:%S")
                time_label = dt_obj.strftime("%I:%M %p")
            except ValueError:
                time_label = dt_txt
        elif dt_timestamp:
            dt_obj = datetime.fromtimestamp(dt_timestamp)
            time_label = dt_obj.strftime("%I:%M %p")

        temp_c = float(main.get("temp", 0.0))
        
        results.append({
            "time_label": time_label,
            "raw_dt_txt": dt_txt,
            "temp_c": round(temp_c, 1),
            "description": weather.get("description", "Normal").title(),
            "condition": weather.get("main", "Normal"),
            "icon_code": weather.get("icon", "01d"),
            "humidity": main.get("humidity", 0),
        })

    return results


def group_forecast_by_day(forecast_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Groups 3-hour forecast steps by calendar date to produce a 5-day daily forecast.
    
    For each date:
    - Calculates true minimum and maximum temperatures across available slices
    - Selects the representative midday (around 12:00 or 15:00) icon and description
    - Clearly distinguishes aggregated interval estimates from single-snapshot readings
    """
    if not isinstance(forecast_data, dict):
        return []

    item_list = forecast_data.get("list", [])
    if not isinstance(item_list, list):
        return []

    daily_buckets: Dict[str, List[Dict[str, Any]]] = {}

    for item in item_list:
        if not isinstance(item, dict):
            continue
        dt_txt = item.get("dt_txt", "")
        if not dt_txt:
            dt_ts = item.get("dt", 0)
            if dt_ts:
                dt_txt = datetime.fromtimestamp(dt_ts).strftime("%Y-%m-%d %H:%M:%S")
            else:
                continue

        # Extract date key "YYYY-MM-DD"
        date_key = dt_txt.split(" ")[0]
        if date_key not in daily_buckets:
            daily_buckets[date_key] = []
        daily_buckets[date_key].append(item)

    daily_summary: List[Dict[str, Any]] = []

    for date_key, slices in daily_buckets.items():
        try:
            date_obj = datetime.strptime(date_key, "%Y-%m-%d")
            day_name = date_obj.strftime("%A")      # e.g., "Wednesday"
            date_formatted = date_obj.strftime("%b %d") # e.g., "Oct 29"
        except ValueError:
            day_name = date_key
            date_formatted = date_key

        temps = []
        humidities = []
        midday_slice = None

        for s in slices:
            main = s.get("main", {})
            if "temp" in main:
                temps.append(float(main["temp"]))
            if "humidity" in main:
                humidities.append(int(main["humidity"]))
            
            # Look for midday reading (approx 12:00:00 or 15:00:00) for representative icon
            dt_txt = s.get("dt_txt", "")
            if "12:00:00" in dt_txt or "15:00:00" in dt_txt:
                midday_slice = s

        if not temps:
            continue

        # If no explicit midday slice found, pick the middle slice of the day
        if midday_slice is None:
            midday_slice = slices[len(slices) // 2]

        weather_rep = midday_slice.get("weather", [{}])[0]
        min_temp_c = min(temps)
        max_temp_c = max(temps)
        avg_humidity = sum(humidities) // len(humidities) if humidities else 0

        daily_summary.append({
            "date_key": date_key,
            "day_name": day_name,
            "date_formatted": date_formatted,
            "min_temp_c": round(min_temp_c, 1),
            "max_temp_c": round(max_temp_c, 1),
            "description": weather_rep.get("description", "Variable").title(),
            "condition": weather_rep.get("main", "Variable"),
            "icon_code": weather_rep.get("icon", "01d"),
            "humidity": avg_humidity,
            "data_points_count": len(slices),
        })

    # Return up to 5 days
    return daily_summary[:5]
