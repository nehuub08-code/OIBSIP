export interface CurrentWeather {
  city: string;
  country: string;
  full_location: string;
  temp_c: number;
  feels_like_c: number;
  temp_min_c: number;
  temp_max_c: number;
  humidity: number;
  pressure: number;
  wind_speed_mps: number;
  wind_deg: number;
  condition: string;
  description: string;
  icon_code: string;
  timestamp_str: string;
}

export interface UpcomingInterval {
  time_label: string;
  raw_dt_txt: string;
  temp_c: number;
  description: string;
  condition: string;
  icon_code: string;
  humidity: number;
}

export interface DailyForecast {
  date_key: string;
  day_name: string;
  date_formatted: string;
  min_temp_c: number;
  max_temp_c: number;
  description: string;
  condition: string;
  icon_code: string;
  humidity: number;
  data_points_count: number;
}

export interface CityWeatherData {
  current: CurrentWeather;
  upcoming: UpcomingInterval[];
  daily: DailyForecast[];
}

export const MOCK_CITIES_WEATHER: Record<string, CityWeatherData> = {
  pune: {
    current: {
      city: "Pune",
      country: "IN",
      full_location: "Pune, IN",
      temp_c: 28.5,
      feels_like_c: 29.8,
      temp_min_c: 26.0,
      temp_max_c: 31.0,
      humidity: 48,
      pressure: 1012,
      wind_speed_mps: 3.6,
      wind_deg: 240,
      condition: "Clear",
      description: "Clear Sky",
      icon_code: "01d",
      timestamp_str: "02:30 PM, Today",
    },
    upcoming: [
      { time_label: "03:00 PM", raw_dt_txt: "2026-10-28 15:00:00", temp_c: 29.1, description: "Clear Sky", condition: "Clear", icon_code: "01d", humidity: 45 },
      { time_label: "06:00 PM", raw_dt_txt: "2026-10-28 18:00:00", temp_c: 25.4, description: "Few Clouds", condition: "Clouds", icon_code: "02n", humidity: 55 },
      { time_label: "09:00 PM", raw_dt_txt: "2026-10-28 21:00:00", temp_c: 22.8, description: "Clear Sky", condition: "Clear", icon_code: "01n", humidity: 62 },
    ],
    daily: [
      { date_key: "2026-10-29", day_name: "Thursday", date_formatted: "Oct 29", min_temp_c: 19.5, max_temp_c: 31.0, description: "Sunny & Warm", condition: "Clear", icon_code: "01d", humidity: 46, data_points_count: 8 },
      { date_key: "2026-10-30", day_name: "Friday", date_formatted: "Oct 30", min_temp_c: 20.0, max_temp_c: 30.5, description: "Partly Cloudy", condition: "Clouds", icon_code: "02d", humidity: 50, data_points_count: 8 },
      { date_key: "2026-10-31", day_name: "Saturday", date_formatted: "Oct 31", min_temp_c: 21.2, max_temp_c: 29.0, description: "Passing Clouds", condition: "Clouds", icon_code: "03d", humidity: 54, data_points_count: 8 },
      { date_key: "2026-11-01", day_name: "Sunday", date_formatted: "Nov 01", min_temp_c: 18.8, max_temp_c: 30.2, description: "Clear Sky", condition: "Clear", icon_code: "01d", humidity: 42, data_points_count: 8 },
      { date_key: "2026-11-02", day_name: "Monday", date_formatted: "Nov 02", min_temp_c: 19.0, max_temp_c: 31.5, description: "Sunny", condition: "Clear", icon_code: "01d", humidity: 40, data_points_count: 8 },
    ],
  },
  mumbai: {
    current: {
      city: "Mumbai",
      country: "IN",
      full_location: "Mumbai, IN",
      temp_c: 32.0,
      feels_like_c: 36.5,
      temp_min_c: 29.0,
      temp_max_c: 33.5,
      humidity: 72,
      pressure: 1010,
      wind_speed_mps: 4.8,
      wind_deg: 260,
      condition: "Haze",
      description: "Hazy Sunshine",
      icon_code: "50d",
      timestamp_str: "02:30 PM, Today",
    },
    upcoming: [
      { time_label: "03:00 PM", raw_dt_txt: "2026-10-28 15:00:00", temp_c: 32.4, description: "Hazy Sunshine", condition: "Haze", icon_code: "50d", humidity: 70 },
      { time_label: "06:00 PM", raw_dt_txt: "2026-10-28 18:00:00", temp_c: 29.8, description: "Pleasant Evening", condition: "Clear", icon_code: "01n", humidity: 76 },
      { time_label: "09:00 PM", raw_dt_txt: "2026-10-28 21:00:00", temp_c: 28.2, description: "Clear Sky", condition: "Clear", icon_code: "01n", humidity: 80 },
    ],
    daily: [
      { date_key: "2026-10-29", day_name: "Thursday", date_formatted: "Oct 29", min_temp_c: 26.5, max_temp_c: 33.0, description: "Humid & Sunny", condition: "Clear", icon_code: "01d", humidity: 71, data_points_count: 8 },
      { date_key: "2026-10-30", day_name: "Friday", date_formatted: "Oct 30", min_temp_c: 26.0, max_temp_c: 32.5, description: "Partly Cloudy", condition: "Clouds", icon_code: "02d", humidity: 73, data_points_count: 8 },
      { date_key: "2026-10-31", day_name: "Saturday", date_formatted: "Oct 31", min_temp_c: 25.8, max_temp_c: 33.2, description: "Sunny Coast", condition: "Clear", icon_code: "01d", humidity: 70, data_points_count: 8 },
      { date_key: "2026-11-01", day_name: "Sunday", date_formatted: "Nov 01", min_temp_c: 26.2, max_temp_c: 32.8, description: "Light Breeze", condition: "Clear", icon_code: "01d", humidity: 68, data_points_count: 8 },
      { date_key: "2026-11-02", day_name: "Monday", date_formatted: "Nov 02", min_temp_c: 25.5, max_temp_c: 33.0, description: "Clear Sky", condition: "Clear", icon_code: "01d", humidity: 69, data_points_count: 8 },
    ],
  },
  delhi: {
    current: {
      city: "Delhi",
      country: "IN",
      full_location: "Delhi, IN",
      temp_c: 26.0,
      feels_like_c: 26.0,
      temp_min_c: 22.0,
      temp_max_c: 28.0,
      humidity: 38,
      pressure: 1015,
      wind_speed_mps: 2.1,
      wind_deg: 310,
      condition: "Mist",
      description: "Mild Smog & Mist",
      icon_code: "50d",
      timestamp_str: "02:30 PM, Today",
    },
    upcoming: [
      { time_label: "03:00 PM", raw_dt_txt: "2026-10-28 15:00:00", temp_c: 26.8, description: "Haze", condition: "Mist", icon_code: "50d", humidity: 35 },
      { time_label: "06:00 PM", raw_dt_txt: "2026-10-28 18:00:00", temp_c: 22.5, description: "Cool Night", condition: "Clear", icon_code: "01n", humidity: 48 },
      { time_label: "09:00 PM", raw_dt_txt: "2026-10-28 21:00:00", temp_c: 19.8, description: "Crisp Air", condition: "Clear", icon_code: "01n", humidity: 55 },
    ],
    daily: [
      { date_key: "2026-10-29", day_name: "Thursday", date_formatted: "Oct 29", min_temp_c: 16.0, max_temp_c: 28.5, description: "Dry Autumn Sun", condition: "Clear", icon_code: "01d", humidity: 40, data_points_count: 8 },
      { date_key: "2026-10-30", day_name: "Friday", date_formatted: "Oct 30", min_temp_c: 15.5, max_temp_c: 28.0, description: "Cool Morning", condition: "Clear", icon_code: "01d", humidity: 42, data_points_count: 8 },
      { date_key: "2026-10-31", day_name: "Saturday", date_formatted: "Oct 31", min_temp_c: 15.0, max_temp_c: 27.5, description: "Pleasant", condition: "Clear", icon_code: "01d", humidity: 44, data_points_count: 8 },
      { date_key: "2026-11-01", day_name: "Sunday", date_formatted: "Nov 01", min_temp_c: 14.8, max_temp_c: 27.0, description: "Sunny Skies", condition: "Clear", icon_code: "01d", humidity: 45, data_points_count: 8 },
      { date_key: "2026-11-02", day_name: "Monday", date_formatted: "Nov 02", min_temp_c: 14.5, max_temp_c: 26.8, description: "Mild & Clear", condition: "Clear", icon_code: "01d", humidity: 43, data_points_count: 8 },
    ],
  },
  london: {
    current: {
      city: "London",
      country: "GB",
      full_location: "London, GB",
      temp_c: 13.5,
      feels_like_c: 12.0,
      temp_min_c: 11.0,
      temp_max_c: 15.0,
      humidity: 82,
      pressure: 1018,
      wind_speed_mps: 5.5,
      wind_deg: 210,
      condition: "Rain",
      description: "Light Drizzle",
      icon_code: "10d",
      timestamp_str: "10:00 AM, Today",
    },
    upcoming: [
      { time_label: "12:00 PM", raw_dt_txt: "2026-10-28 12:00:00", temp_c: 14.2, description: "Light Rain", condition: "Rain", icon_code: "10d", humidity: 80 },
      { time_label: "03:00 PM", raw_dt_txt: "2026-10-28 15:00:00", temp_c: 14.8, description: "Overcast", condition: "Clouds", icon_code: "04d", humidity: 78 },
      { time_label: "06:00 PM", raw_dt_txt: "2026-10-28 18:00:00", temp_c: 12.6, description: "Breezy Clouds", condition: "Clouds", icon_code: "03n", humidity: 84 },
    ],
    daily: [
      { date_key: "2026-10-29", day_name: "Thursday", date_formatted: "Oct 29", min_temp_c: 8.5, max_temp_c: 14.0, description: "Scattered Showers", condition: "Rain", icon_code: "10d", humidity: 82, data_points_count: 8 },
      { date_key: "2026-10-30", day_name: "Friday", date_formatted: "Oct 30", min_temp_c: 7.0, max_temp_c: 13.5, description: "Passing Clouds", condition: "Clouds", icon_code: "03d", humidity: 75, data_points_count: 8 },
      { date_key: "2026-10-31", day_name: "Saturday", date_formatted: "Oct 31", min_temp_c: 9.0, max_temp_c: 15.0, description: "Moderate Rain", condition: "Rain", icon_code: "10d", humidity: 88, data_points_count: 8 },
      { date_key: "2026-11-01", day_name: "Sunday", date_formatted: "Nov 01", min_temp_c: 6.5, max_temp_c: 12.0, description: "Partly Sunny", condition: "Clouds", icon_code: "02d", humidity: 70, data_points_count: 8 },
      { date_key: "2026-11-02", day_name: "Monday", date_formatted: "Nov 02", min_temp_c: 5.0, max_temp_c: 11.5, description: "Chilly & Clear", condition: "Clear", icon_code: "01d", humidity: 74, data_points_count: 8 },
    ],
  },
  "new york": {
    current: {
      city: "New York",
      country: "US",
      full_location: "New York, US",
      temp_c: 16.0,
      feels_like_c: 15.2,
      temp_min_c: 12.0,
      temp_max_c: 18.0,
      humidity: 58,
      pressure: 1022,
      wind_speed_mps: 4.2,
      wind_deg: 180,
      condition: "Clear",
      description: "Crisp Autumn Sun",
      icon_code: "01d",
      timestamp_str: "05:00 AM, Today",
    },
    upcoming: [
      { time_label: "08:00 AM", raw_dt_txt: "2026-10-28 08:00:00", temp_c: 14.5, description: "Sunny", condition: "Clear", icon_code: "01d", humidity: 62 },
      { time_label: "11:00 AM", raw_dt_txt: "2026-10-28 11:00:00", temp_c: 17.5, description: "Sunny Skies", condition: "Clear", icon_code: "01d", humidity: 52 },
      { time_label: "02:00 PM", raw_dt_txt: "2026-10-28 14:00:00", temp_c: 19.0, description: "High Clouds", condition: "Clouds", icon_code: "02d", humidity: 48 },
    ],
    daily: [
      { date_key: "2026-10-29", day_name: "Thursday", date_formatted: "Oct 29", min_temp_c: 11.0, max_temp_c: 19.0, description: "Mild & Sunny", condition: "Clear", icon_code: "01d", humidity: 55, data_points_count: 8 },
      { date_key: "2026-10-30", day_name: "Friday", date_formatted: "Oct 30", min_temp_c: 13.0, max_temp_c: 20.5, description: "Gentle Breeze", condition: "Clear", icon_code: "01d", humidity: 58, data_points_count: 8 },
      { date_key: "2026-10-31", day_name: "Saturday", date_formatted: "Oct 31", min_temp_c: 12.5, max_temp_c: 17.0, description: "Halloween Clouds", condition: "Clouds", icon_code: "03d", humidity: 65, data_points_count: 8 },
      { date_key: "2026-11-01", day_name: "Sunday", date_formatted: "Nov 01", min_temp_c: 9.0, max_temp_c: 15.0, description: "Light Rain", condition: "Rain", icon_code: "10d", humidity: 72, data_points_count: 8 },
      { date_key: "2026-11-02", day_name: "Monday", date_formatted: "Nov 02", min_temp_c: 8.0, max_temp_c: 14.2, description: "Crisp Sun", condition: "Clear", icon_code: "01d", humidity: 50, data_points_count: 8 },
    ],
  },
  tokyo: {
    current: {
      city: "Tokyo",
      country: "JP",
      full_location: "Tokyo, JP",
      temp_c: 18.2,
      feels_like_c: 17.8,
      temp_min_c: 15.0,
      temp_max_c: 20.0,
      humidity: 64,
      pressure: 1016,
      wind_speed_mps: 3.1,
      wind_deg: 90,
      condition: "Clouds",
      description: "Broken Clouds",
      icon_code: "04d",
      timestamp_str: "06:00 PM, Today",
    },
    upcoming: [
      { time_label: "06:00 PM", raw_dt_txt: "2026-10-28 18:00:00", temp_c: 18.2, description: "Broken Clouds", condition: "Clouds", icon_code: "04d", humidity: 64 },
      { time_label: "09:00 PM", raw_dt_txt: "2026-10-28 21:00:00", temp_c: 16.5, description: "Clear Interval", condition: "Clear", icon_code: "01n", humidity: 70 },
      { time_label: "12:00 AM", raw_dt_txt: "2026-10-29 00:00:00", temp_c: 15.0, description: "Calm Night", condition: "Clear", icon_code: "01n", humidity: 75 },
    ],
    daily: [
      { date_key: "2026-10-29", day_name: "Thursday", date_formatted: "Oct 29", min_temp_c: 13.5, max_temp_c: 21.0, description: "Pleasant & Fair", condition: "Clear", icon_code: "01d", humidity: 60, data_points_count: 8 },
      { date_key: "2026-10-30", day_name: "Friday", date_formatted: "Oct 30", min_temp_c: 14.0, max_temp_c: 20.0, description: "Overcast", condition: "Clouds", icon_code: "04d", humidity: 68, data_points_count: 8 },
      { date_key: "2026-10-31", day_name: "Saturday", date_formatted: "Oct 31", min_temp_c: 15.2, max_temp_c: 22.0, description: "Scattered Rain", condition: "Rain", icon_code: "10d", humidity: 78, data_points_count: 8 },
      { date_key: "2026-11-01", day_name: "Sunday", date_formatted: "Nov 01", min_temp_c: 12.0, max_temp_c: 19.5, description: "Sunny Autumn", condition: "Clear", icon_code: "01d", humidity: 55, data_points_count: 8 },
      { date_key: "2026-11-02", day_name: "Monday", date_formatted: "Nov 02", min_temp_c: 11.5, max_temp_c: 18.0, description: "Brisk Sun", condition: "Clear", icon_code: "01d", humidity: 52, data_points_count: 8 },
    ],
  },
};

export function getMockWeather(cityName: string): CityWeatherData {
  const normalized = cityName.toLowerCase().trim();
  if (MOCK_CITIES_WEATHER[normalized]) {
    return MOCK_CITIES_WEATHER[normalized];
  }
  
  // Dynamic mock generator for arbitrary city names
  const hash = cityName.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const baseTemp = 15 + (hash % 18);
  const conditions = ["Clear", "Clouds", "Rain", "Partly Cloudy"];
  const cond = conditions[hash % conditions.length];
  const icon = cond === "Clear" ? "01d" : cond === "Rain" ? "10d" : "03d";
  
  return {
    current: {
      city: cityName.charAt(0).toUpperCase() + cityName.slice(1),
      country: "GLOBAL",
      full_location: `${cityName.charAt(0).toUpperCase() + cityName.slice(1)}, REGION`,
      temp_c: baseTemp,
      feels_like_c: baseTemp + 1.2,
      temp_min_c: baseTemp - 3,
      temp_max_c: baseTemp + 4,
      humidity: 50 + (hash % 35),
      pressure: 1010 + (hash % 15),
      wind_speed_mps: 2.5 + (hash % 5),
      wind_deg: hash % 360,
      condition: cond,
      description: `${cond} Skies`,
      icon_code: icon,
      timestamp_str: "Just now",
    },
    upcoming: [
      { time_label: "+3h", raw_dt_txt: "2026-10-28 15:00:00", temp_c: baseTemp + 1, description: cond, condition: cond, icon_code: icon, humidity: 52 },
      { time_label: "+6h", raw_dt_txt: "2026-10-28 18:00:00", temp_c: baseTemp - 2, description: cond, condition: cond, icon_code: icon, humidity: 60 },
      { time_label: "+9h", raw_dt_txt: "2026-10-28 21:00:00", temp_c: baseTemp - 4, description: cond, condition: cond, icon_code: "01n", humidity: 65 },
    ],
    daily: [
      { date_key: "2026-10-29", day_name: "Day 1", date_formatted: "Oct 29", min_temp_c: baseTemp - 5, max_temp_c: baseTemp + 3, description: cond, condition: cond, icon_code: icon, humidity: 55, data_points_count: 8 },
      { date_key: "2026-10-30", day_name: "Day 2", date_formatted: "Oct 30", min_temp_c: baseTemp - 4, max_temp_c: baseTemp + 4, description: "Fair", condition: "Clear", icon_code: "01d", humidity: 50, data_points_count: 8 },
      { date_key: "2026-10-31", day_name: "Day 3", date_formatted: "Oct 31", min_temp_c: baseTemp - 6, max_temp_c: baseTemp + 2, description: "Variable", condition: "Clouds", icon_code: "03d", humidity: 58, data_points_count: 8 },
      { date_key: "2026-11-01", day_name: "Day 4", date_formatted: "Nov 01", min_temp_c: baseTemp - 3, max_temp_c: baseTemp + 5, description: "Pleasant", condition: "Clear", icon_code: "01d", humidity: 48, data_points_count: 8 },
      { date_key: "2026-11-02", day_name: "Day 5", date_formatted: "Nov 02", min_temp_c: baseTemp - 4, max_temp_c: baseTemp + 3, description: "Breezy", condition: "Clouds", icon_code: "02d", humidity: 52, data_points_count: 8 },
    ],
  };
}
