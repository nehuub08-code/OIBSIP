export interface ProjectFile {
  name: string;
  path: string;
  language: string;
  description: string;
  content: string;
}

export const PROJECT_FILES: ProjectFile[] = [
  {
    name: "main.py",
    path: "OIBSIP/PythonProgramming/Task4_Weather_App/main.py",
    language: "python",
    description: "Desktop application entry point. Builds modern dark-themed Tkinter/ttk GUI, handles worker threads, unit conversion, and icon rendering.",
    content: `"""
WeatherWise - Weather Forecast Desktop Application
OIBSIP Python Programming Internship - Task 4

Main GUI Application built using Tkinter and ttk.
Features:
- Responsive desktop window with modern color palette
- City / ZIP code search with Enter key binding
- Celsius (°C) and Fahrenheit (°F) dynamic unit toggle
- Large current weather hero card (temperature, feels-like, humidity, wind, pressure)
- 6-9 Hour upcoming forecast cards (3-hour API intervals, honestly labeled)
- 5-Day forecast cards with min/max daily temperatures
- Optional IP-based location detection (ipinfo.io)
- Non-blocking background worker threads (GUI never freezes)
- Safe GUI updates using root.after()
- Visible error banners inside the GUI
- OpenWeatherMap icon rendering with Pillow or canvas fallback
"""

import io
import os
import sys
import threading
import time
from typing import Any, Dict, List, Optional

# Tkinter imports
import tkinter as tk
from tkinter import ttk, messagebox

# Pillow for icon rendering (optional with fallback)
try:
    from PIL import Image, ImageTk
    HAS_PILLOW = True
except ImportError:
    HAS_PILLOW = False

# Local application imports
from weather_api import (
    WeatherAPIError,
    fetch_current_weather,
    fetch_forecast,
    fetch_weather_icon,
    detect_location_by_ip,
    get_api_key,
)
from weather_utils import (
    validate_location_input,
    parse_current_weather,
    extract_upcoming_intervals,
    group_forecast_by_day,
    format_temperature,
    celsius_to_fahrenheit,
)


# Color Palette (Modern Deep Indigo & Crisp Accents)
THEME = {
    "bg_main": "#0f172a",         # Slate 900
    "bg_card": "#1e293b",         # Slate 800
    "bg_card_highlight": "#334155",# Slate 700
    "text_primary": "#f8fafc",    # Slate 50
    "text_secondary": "#94a3b8",  # Slate 400
    "text_muted": "#64748b",      # Slate 500
    "accent_blue": "#38bdf8",     # Sky 400
    "accent_purple": "#818cf8",   # Indigo 400
    "accent_orange": "#fb923c",   # Orange 400
    "accent_green": "#4ade80",    # Green 400
    "error_bg": "#450a0a",        # Red 950
    "error_border": "#ef4444",    # Red 500
    "error_text": "#fca5a5",      # Red 300
    "entry_bg": "#0f172a",        # Slate 900
    "entry_fg": "#ffffff",
}


class WeatherWiseApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("WeatherWise — Weather Forecast App (OIBSIP Task 4)")
        self.root.geometry("980x780")
        self.root.minsize(860, 680)
        self.root.configure(bg=THEME["bg_main"])

        # State management
        self.current_unit: str = "C"  # 'C' or 'F'
        self.active_request_id: int = 0
        self.is_fetching: bool = False
        
        # Stored weather records (in metric Celsius, converted on display)
        self.raw_current: Optional[Dict[str, Any]] = None
        self.upcoming_intervals: List[Dict[str, Any]] = []
        self.five_day_summary: List[Dict[str, Any]] = []
        
        # Image cache to prevent Python garbage collection
        self._image_tk_refs: List[Any] = []

        self._configure_styles()
        self._build_ui()
        self._check_api_key_banner()

    def _configure_styles(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("Main.TFrame", background=THEME["bg_main"])
        style.configure("Card.TFrame", background=THEME["bg_card"], relief="flat")
        style.configure("SubCard.TFrame", background=THEME["bg_card_highlight"], relief="flat")

    def _build_ui(self):
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(2, weight=1)

        # 1. Header & Title Bar
        header_frame = tk.Frame(self.root, bg=THEME["bg_main"], padx=20, pady=12)
        header_frame.grid(row=0, column=0, sticky="ew")
        header_frame.columnconfigure(0, weight=1)

        title_box = tk.Frame(header_frame, bg=THEME["bg_main"])
        title_box.pack(side=tk.LEFT)

        title_lbl = tk.Label(
            title_box,
            text="⛅ WeatherWise",
            font=("Segoe UI", 18, "bold"),
            bg=THEME["bg_main"],
            fg=THEME["accent_blue"]
        )
        title_lbl.pack(anchor="w")

        subtitle_lbl = tk.Label(
            title_box,
            text="OIBSIP Task 4 • Live OpenWeatherMap Forecast & Atmospheric Intelligence",
            font=("Segoe UI", 9),
            bg=THEME["bg_main"],
            fg=THEME["text_secondary"]
        )
        subtitle_lbl.pack(anchor="w")

        # Unit Toggle (°C / °F)
        unit_frame = tk.Frame(header_frame, bg=THEME["bg_card"], bd=1, relief="solid")
        unit_frame.pack(side=tk.RIGHT, pady=4)

        self.btn_celsius = tk.Button(
            unit_frame,
            text="°C",
            font=("Segoe UI", 10, "bold"),
            bg=THEME["accent_blue"],
            fg="#0f172a",
            bd=0,
            padx=12,
            pady=4,
            cursor="hand2",
            command=lambda: self.set_unit("C")
        )
        self.btn_celsius.pack(side=tk.LEFT)

        self.btn_fahrenheit = tk.Button(
            unit_frame,
            text="°F",
            font=("Segoe UI", 10, "bold"),
            bg=THEME["bg_card"],
            fg=THEME["text_secondary"],
            bd=0,
            padx=12,
            pady=4,
            cursor="hand2",
            command=lambda: self.set_unit("F")
        )
        self.btn_fahrenheit.pack(side=tk.LEFT)

        # 2. Search & Controls Bar
        search_card = tk.Frame(self.root, bg=THEME["bg_card"], padx=18, pady=12, bd=1, relief="flat")
        search_card.grid(row=1, column=0, sticky="ew", padx=20, pady=(0, 10))
        search_card.columnconfigure(1, weight=1)

        loc_icon_lbl = tk.Label(search_card, text="🔍", font=("Segoe UI", 12), bg=THEME["bg_card"], fg=THEME["text_secondary"])
        loc_icon_lbl.grid(row=0, column=0, padx=(0, 6))

        self.entry_location = tk.Entry(
            search_card,
            font=("Segoe UI", 12),
            bg=THEME["entry_bg"],
            fg=THEME["entry_fg"],
            insertbackground=THEME["accent_blue"],
            relief="flat",
            bd=6
        )
        self.entry_location.grid(row=0, column=1, sticky="ew", padx=(0, 10))
        self.entry_location.insert(0, "Pune")
        self.entry_location.bind("<Return>", lambda event: self.start_fetch_weather())

        self.btn_get_weather = tk.Button(
            search_card,
            text="Get Weather",
            font=("Segoe UI", 10, "bold"),
            bg=THEME["accent_blue"],
            fg="#0f172a",
            activebackground="#0284c7",
            bd=0,
            padx=16,
            pady=6,
            cursor="hand2",
            command=self.start_fetch_weather
        )
        self.btn_get_weather.grid(row=0, column=2, padx=(0, 8))

        self.btn_detect_location = tk.Button(
            search_card,
            text="📍 Detect My Location",
            font=("Segoe UI", 10),
            bg=THEME["bg_card_highlight"],
            fg=THEME["text_primary"],
            bd=0,
            padx=12,
            pady=6,
            cursor="hand2",
            command=self.start_detect_location
        )
        self.btn_detect_location.grid(row=0, column=3)

        # Error Alert Banner
        self.error_banner = tk.Frame(self.root, bg=THEME["error_bg"], bd=1, relief="solid", padx=14, pady=8)
        self.lbl_error = tk.Label(
            self.error_banner,
            text="",
            font=("Segoe UI", 10),
            bg=THEME["error_bg"],
            fg=THEME["error_text"],
            wraplength=880,
            justify="left"
        )
        self.lbl_error.pack(side=tk.LEFT, fill="x", expand=True)

        self.btn_dismiss_error = tk.Button(
            self.error_banner,
            text="✕",
            font=("Segoe UI", 9, "bold"),
            bg=THEME["error_bg"],
            fg=THEME["error_text"],
            bd=0,
            cursor="hand2",
            command=self.hide_error
        )
        self.btn_dismiss_error.pack(side=tk.RIGHT, padx=4)

        # 3. Main Workspace
        workspace = tk.Frame(self.root, bg=THEME["bg_main"], padx=20, pady=4)
        workspace.grid(row=2, column=0, sticky="nsew")
        workspace.columnconfigure(0, weight=5)
        workspace.columnconfigure(1, weight=6)
        workspace.rowconfigure(0, weight=1)

        # Left: Current Weather Hero Card
        self.current_card = tk.Frame(workspace, bg=THEME["bg_card"], padx=20, pady=18, bd=1, relief="flat")
        self.current_card.grid(row=0, column=0, sticky="nsew", padx=(0, 10), pady=(0, 10))
        self._build_current_weather_panel(self.current_card)

        # Right: Forecasts (6-9h + 5-Day)
        forecast_column = tk.Frame(workspace, bg=THEME["bg_main"])
        forecast_column.grid(row=0, column=1, sticky="nsew", padx=(0, 0), pady=(0, 10))
        forecast_column.columnconfigure(0, weight=1)
        forecast_column.rowconfigure(0, weight=4)
        forecast_column.rowconfigure(1, weight=6)

        self.hourly_card = tk.Frame(forecast_column, bg=THEME["bg_card"], padx=16, pady=14, bd=1, relief="flat")
        self.hourly_card.grid(row=0, column=0, sticky="nsew", pady=(0, 10))
        self._build_upcoming_forecast_panel(self.hourly_card)

        self.daily_card = tk.Frame(forecast_column, bg=THEME["bg_card"], padx=16, pady=14, bd=1, relief="flat")
        self.daily_card.grid(row=1, column=0, sticky="nsew")
        self._build_five_day_forecast_panel(self.daily_card)

        # 4. Status Bar
        self.status_bar = tk.Frame(self.root, bg=THEME["bg_card"], padx=16, pady=4)
        self.status_bar.grid(row=3, column=0, sticky="ew")

        self.lbl_status = tk.Label(
            self.status_bar,
            text="Ready. Enter a city name and click 'Get Weather'.",
            font=("Segoe UI", 9),
            bg=THEME["bg_card"],
            fg=THEME["text_secondary"]
        )
        self.lbl_status.pack(side=tk.LEFT)

    def _build_current_weather_panel(self, parent: tk.Frame):
        top_row = tk.Frame(parent, bg=THEME["bg_card"])
        top_row.pack(fill="x", pady=(0, 10))

        self.lbl_city = tk.Label(top_row, text="Ready to explore", font=("Segoe UI", 18, "bold"), bg=THEME["bg_card"], fg=THEME["text_primary"])
        self.lbl_city.pack(side=tk.LEFT)

        self.lbl_timestamp = tk.Label(top_row, text="", font=("Segoe UI", 9), bg=THEME["bg_card"], fg=THEME["text_secondary"])
        self.lbl_timestamp.pack(side=tk.RIGHT, pady=4)

        temp_row = tk.Frame(parent, bg=THEME["bg_card"])
        temp_row.pack(fill="x", pady=10)

        self.canvas_icon = tk.Canvas(temp_row, width=80, height=80, bg=THEME["bg_card"], highlightthickness=0)
        self.canvas_icon.pack(side=tk.LEFT, padx=(0, 12))

        temp_box = tk.Frame(temp_row, bg=THEME["bg_card"])
        temp_box.pack(side=tk.LEFT)

        self.lbl_temperature = tk.Label(temp_box, text="--", font=("Segoe UI", 36, "bold"), bg=THEME["bg_card"], fg=THEME["accent_blue"])
        self.lbl_temperature.pack(anchor="w")

        self.lbl_condition = tk.Label(temp_box, text="Enter location to view weather", font=("Segoe UI", 11, "bold"), bg=THEME["bg_card"], fg=THEME["text_primary"])
        self.lbl_condition.pack(anchor="w")

        # Metric Tiles (Feels Like, Humidity, Wind, Pressure)
        metrics_frame = tk.Frame(parent, bg=THEME["bg_card"])
        metrics_frame.pack(fill="both", expand=True, pady=(15, 0))
        metrics_frame.columnconfigure(0, weight=1)
        metrics_frame.columnconfigure(1, weight=1)

        self.tile_feels_like = self._create_metric_tile(metrics_frame, 0, 0, "🌡️ Feels Like", "--")
        self.tile_humidity = self._create_metric_tile(metrics_frame, 0, 1, "💧 Humidity", "--")
        self.tile_wind = self._create_metric_tile(metrics_frame, 1, 0, "💨 Wind Speed", "--")
        self.tile_pressure = self._create_metric_tile(metrics_frame, 1, 1, "⏲️ Pressure", "--")

    def _create_metric_tile(self, parent: tk.Frame, row: int, col: int, label: str, default_val: str) -> tk.Label:
        box = tk.Frame(parent, bg=THEME["bg_card_highlight"], padx=12, pady=10, bd=1, relief="flat")
        box.grid(row=row, column=col, sticky="nsew", padx=4, pady=4)
        tk.Label(box, text=label, font=("Segoe UI", 9), bg=THEME["bg_card_highlight"], fg=THEME["text_secondary"]).pack(anchor="w")
        lbl_value = tk.Label(box, text=default_val, font=("Segoe UI", 12, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_primary"])
        lbl_value.pack(anchor="w", pady=(3, 0))
        return lbl_value

    def _build_upcoming_forecast_panel(self, parent: tk.Frame):
        header_row = tk.Frame(parent, bg=THEME["bg_card"])
        header_row.pack(fill="x", pady=(0, 8))

        lbl_title = tk.Label(header_row, text="⏱️ Next 6–9 Hours (3-Hour Forecast Steps)", font=("Segoe UI", 10, "bold"), bg=THEME["bg_card"], fg=THEME["accent_orange"])
        lbl_title.pack(side=tk.LEFT)

        self.hourly_container = tk.Frame(parent, bg=THEME["bg_card"])
        self.hourly_container.pack(fill="both", expand=True)
        self.hourly_container.columnconfigure((0, 1, 2), weight=1)
        self._render_placeholder_upcoming()

    def _render_placeholder_upcoming(self):
        for widget in self.hourly_container.winfo_children():
            widget.destroy()
        for col in range(3):
            box = tk.Frame(self.hourly_container, bg=THEME["bg_card_highlight"], padx=8, pady=10)
            box.grid(row=0, column=col, sticky="nsew", padx=3)
            tk.Label(box, text=f"+{(col+1)*3}h", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_secondary"]).pack()
            tk.Label(box, text="--°", font=("Segoe UI", 14, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_primary"]).pack(pady=4)
            tk.Label(box, text="Waiting...", font=("Segoe UI", 8), bg=THEME["bg_card_highlight"], fg=THEME["text_muted"]).pack()

    def _build_five_day_forecast_panel(self, parent: tk.Frame):
        header_row = tk.Frame(parent, bg=THEME["bg_card"])
        header_row.pack(fill="x", pady=(0, 6))

        lbl_title = tk.Label(header_row, text="📅 5-Day Outlook (Aggregated Daily Min / Max)", font=("Segoe UI", 10, "bold"), bg=THEME["bg_card"], fg=THEME["accent_green"])
        lbl_title.pack(side=tk.LEFT)

        self.daily_container = tk.Frame(parent, bg=THEME["bg_card"])
        self.daily_container.pack(fill="both", expand=True)
        self._render_placeholder_daily()

    def _render_placeholder_daily(self):
        for widget in self.daily_container.winfo_children():
            widget.destroy()
        for i in range(5):
            row_box = tk.Frame(self.daily_container, bg=THEME["bg_card_highlight"], padx=10, pady=5)
            row_box.pack(fill="x", pady=2)
            row_box.columnconfigure(1, weight=1)
            tk.Label(row_box, text=f"Day {i+1}", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_secondary"], width=10, anchor="w").grid(row=0, column=0)
            tk.Label(row_box, text="Forecast pending", font=("Segoe UI", 8), bg=THEME["bg_card_highlight"], fg=THEME["text_muted"], anchor="w").grid(row=0, column=1, sticky="w")
            tk.Label(row_box, text="-- / --", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_primary"], anchor="e").grid(row=0, column=2)

    def set_unit(self, unit: str):
        if self.current_unit == unit:
            return
        self.current_unit = unit
        if unit == "C":
            self.btn_celsius.configure(bg=THEME["accent_blue"], fg="#0f172a")
            self.btn_fahrenheit.configure(bg=THEME["bg_card"], fg=THEME["text_secondary"])
        else:
            self.btn_celsius.configure(bg=THEME["bg_card"], fg=THEME["text_secondary"])
            self.btn_fahrenheit.configure(bg=THEME["accent_blue"], fg="#0f172a")
        self._refresh_displays_with_current_unit()

    def show_error(self, message: str):
        self.lbl_error.configure(text=message)
        self.error_banner.grid(row=1, column=0, sticky="ew", padx=20, pady=(0, 10))

    def hide_error(self):
        self.error_banner.grid_forget()

    def set_status(self, text: str, is_loading: bool = False):
        if is_loading:
            self.lbl_status.configure(text=f"⏳ {text}", fg=THEME["accent_blue"])
        else:
            self.lbl_status.configure(text=text, fg=THEME["text_secondary"])

    def start_fetch_weather(self):
        location_raw = self.entry_location.get()
        is_valid, validated_or_err = validate_location_input(location_raw)
        if not is_valid:
            self.show_error(validated_or_err)
            return

        self.hide_error()
        self.active_request_id += 1
        req_id = self.active_request_id
        self._set_loading_state(True)
        self.set_status(f"Fetching current weather and forecast for '{validated_or_err}'...", is_loading=True)

        threading.Thread(
            target=self._worker_fetch_weather,
            args=(validated_or_err, req_id),
            daemon=True
        ).start()

    def start_detect_location(self):
        self.hide_error()
        self.active_request_id += 1
        req_id = self.active_request_id
        self._set_loading_state(True)
        self.set_status("Detecting approximate location using IP...", is_loading=True)
        threading.Thread(target=self._worker_detect_location, args=(req_id,), daemon=True).start()

    def _worker_detect_location(self, req_id: int):
        try:
            city, country = detect_location_by_ip()
            loc_str = f"{city}, {country}" if country else city
            self.root.after(0, self._on_location_detected, loc_str, req_id)
        except WeatherAPIError as e:
            self.root.after(0, self._on_request_error, e.message, req_id)
        except Exception as e:
            self.root.after(0, self._on_request_error, f"Location detection failed: {str(e)}", req_id)

    def _on_location_detected(self, location_name: str, req_id: int):
        if req_id != self.active_request_id:
            return
        self.entry_location.delete(0, tk.END)
        self.entry_location.insert(0, location_name)
        self.start_fetch_weather()

    def _worker_fetch_weather(self, location: str, req_id: int):
        try:
            current_raw = fetch_current_weather(location)
            forecast_raw = fetch_forecast(location)
            parsed_current = parse_current_weather(current_raw)
            upcoming = extract_upcoming_intervals(forecast_raw, count=3)
            daily = group_forecast_by_day(forecast_raw)
            icon_bytes = fetch_weather_icon(parsed_current["icon_code"])

            self.root.after(
                0, self._on_fetch_success, parsed_current, upcoming, daily, icon_bytes, req_id
            )
        except WeatherAPIError as e:
            self.root.after(0, self._on_request_error, e.message, req_id)
        except Exception as e:
            self.root.after(0, self._on_request_error, f"Unexpected error: {str(e)}", req_id)

    def _on_fetch_success(self, current_data, upcoming_data, daily_data, icon_bytes, req_id):
        if req_id != self.active_request_id:
            return
        self._set_loading_state(False)
        self.raw_current = current_data
        self.upcoming_intervals = upcoming_data
        self.five_day_summary = daily_data
        self.hide_error()
        self.set_status(f"Updated weather for {current_data['full_location']}")
        self._refresh_displays_with_current_unit()
        self._draw_weather_icon(icon_bytes, current_data["condition"])

    def _on_request_error(self, error_message: str, req_id: int):
        if req_id != self.active_request_id:
            return
        self._set_loading_state(False)
        self.show_error(error_message)
        self.set_status("Request failed. Please check error message above.")

    def _set_loading_state(self, is_loading: bool):
        self.is_fetching = is_loading
        state = tk.DISABLED if is_loading else tk.NORMAL
        self.btn_get_weather.configure(state=state)
        self.btn_detect_location.configure(state=state)

    def _refresh_displays_with_current_unit(self):
        if not self.raw_current:
            return
        unit = self.current_unit
        c = self.raw_current
        
        self.lbl_city.configure(text=c["full_location"])
        self.lbl_timestamp.configure(text=f"Updated: {c['timestamp_str']}")
        self.lbl_temperature.configure(text=format_temperature(c["temp_c"], unit))
        self.lbl_condition.configure(text=f"{c['condition']} — {c['description']}")

        self.tile_feels_like.configure(text=format_temperature(c["feels_like_c"], unit))
        self.tile_humidity.configure(text=f"{c['humidity']}%")
        self.tile_wind.configure(text=f"{c['wind_speed_mps']} m/s ({round(c['wind_speed_mps'] * 3.6, 1)} km/h)")
        self.tile_pressure.configure(text=f"{c['pressure']} hPa")

        # Upcoming 6-9h
        for widget in self.hourly_container.winfo_children():
            widget.destroy()
        for col, item in enumerate(self.upcoming_intervals[:3]):
            box = tk.Frame(self.hourly_container, bg=THEME["bg_card_highlight"], padx=10, pady=10)
            box.grid(row=0, column=col, sticky="nsew", padx=3)
            tk.Label(box, text=item["time_label"], font=("Segoe UI", 9, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["accent_orange"]).pack()
            tk.Label(box, text=format_temperature(item["temp_c"], unit), font=("Segoe UI", 13, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_primary"]).pack(pady=3)
            tk.Label(box, text=item["description"], font=("Segoe UI", 8), bg=THEME["bg_card_highlight"], fg=THEME["text_secondary"]).pack()

        # 5-Day
        for widget in self.daily_container.winfo_children():
            widget.destroy()
        for day in self.five_day_summary:
            row_box = tk.Frame(self.daily_container, bg=THEME["bg_card_highlight"], padx=10, pady=6)
            row_box.pack(fill="x", pady=2)
            row_box.columnconfigure(1, weight=1)
            day_str = f"{day['day_name'][:3]}, {day['date_formatted']}"
            min_str = format_temperature(day["min_temp_c"], unit)
            max_str = format_temperature(day["max_temp_c"], unit)
            tk.Label(row_box, text=day_str, font=("Segoe UI", 9, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["text_primary"], width=12, anchor="w").grid(row=0, column=0)
            tk.Label(row_box, text=f"{day['condition']} • {day['description']}", font=("Segoe UI", 8), bg=THEME["bg_card_highlight"], fg=THEME["text_secondary"], anchor="w").grid(row=0, column=1, sticky="w")
            tk.Label(row_box, text=f"L: {min_str}  H: {max_str}", font=("Segoe UI", 9, "bold"), bg=THEME["bg_card_highlight"], fg=THEME["accent_green"], anchor="e").grid(row=0, column=2)

    def _draw_weather_icon(self, icon_bytes: Optional[bytes], condition: str):
        self.canvas_icon.delete("all")
        if icon_bytes and HAS_PILLOW:
            try:
                img = Image.open(io.BytesIO(icon_bytes))
                img = img.resize((72, 72), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(img)
                self._image_tk_refs.append(photo)
                self.canvas_icon.create_image(40, 40, image=photo)
                return
            except Exception:
                pass

        # Stylized Canvas Fallback
        cond_lower = condition.lower()
        if "clear" in cond_lower:
            self.canvas_icon.create_oval(25, 25, 55, 55, fill="#f59e0b", outline="#fbbf24", width=2)
        elif "rain" in cond_lower:
            self.canvas_icon.create_oval(20, 25, 50, 48, fill="#64748b", outline="")
            self.canvas_icon.create_oval(35, 18, 65, 48, fill="#94a3b8", outline="")
        else:
            self.canvas_icon.create_oval(18, 28, 48, 54, fill="#64748b", outline="")
            self.canvas_icon.create_oval(32, 18, 68, 54, fill="#94a3b8", outline="")

    def _check_api_key_banner(self):
        key = get_api_key()
        if not key or key == "your_api_key_here":
            self.show_error("Notice: OPENWEATHER_API_KEY is not set in .env. Add your free API key to .env to make live calls.")


def main():
    root = tk.Tk()
    app = WeatherWiseApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
`
  },
  {
    name: "weather_api.py",
    path: "OIBSIP/PythonProgramming/Task4_Weather_App/weather_api.py",
    language: "python",
    description: "HTTP networking layer using requests & urllib. Manages OpenWeatherMap API queries, status codes (404, 401, 429), timeouts, and ipinfo.io geolocation.",
    content: `"""
WeatherWise - Weather API Client Module
OIBSIP Python Programming Internship - Task 4

This module handles:
- Loading configuration from .env safely
- Communicating with OpenWeatherMap REST endpoints (Current & Forecast)
- Handling HTTP status codes, timeouts, connection errors, and rate limits
- Downloading and caching weather icon images
- Optional IP-based geolocation lookup via ipinfo.io
"""

import json
import os
import sys
from typing import Any, Dict, Optional, Tuple

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    import urllib.error
    import urllib.parse
    import urllib.request
    HAS_REQUESTS = False

DEFAULT_TIMEOUT_SECONDS = 10
OPENWEATHER_BASE_URL = "https://api.openweathermap.org/data/2.5"
ICON_URL_TEMPLATE = "https://openweathermap.org/img/wn/{icon_code}@2x.png"
IPINFO_URL = "https://ipinfo.io/json"

_ICON_CACHE: Dict[str, bytes] = {}


class WeatherAPIError(Exception):
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


def get_api_key() -> str:
    return os.getenv("OPENWEATHER_API_KEY", "").strip()


def _http_get_json(url: str, params: Dict[str, Any], timeout: int = DEFAULT_TIMEOUT_SECONDS) -> Dict[str, Any]:
    if HAS_REQUESTS:
        try:
            response = requests.get(url, params=params, timeout=timeout)
        except requests.exceptions.Timeout:
            raise WeatherAPIError("The request timed out. Please try again.")
        except requests.exceptions.ConnectionError:
            raise WeatherAPIError("Unable to connect. Check your internet connection.")
        except requests.exceptions.RequestException as e:
            raise WeatherAPIError(f"Network error: {str(e)}")

        status = response.status_code
        try:
            payload = response.json()
        except Exception:
            payload = {}

        if status == 200:
            return payload
        elif status == 404:
            raise WeatherAPIError("City not found. Check the spelling and try again.", status_code=404)
        elif status == 401:
            raise WeatherAPIError(
                "Invalid or inactive API key. Note: Newly generated OpenWeatherMap keys may take 15 to 60 minutes to activate.",
                status_code=401
            )
        elif status == 429:
            raise WeatherAPIError("The API request limit has been reached. Please wait and try again.", status_code=429)
        elif status >= 500:
            raise WeatherAPIError("OpenWeatherMap service is temporarily down. Please try again later.", status_code=status)
        else:
            msg = payload.get("message", "Failed to retrieve weather data.")
            raise WeatherAPIError(f"Error ({status}): {msg}", status_code=status)
    else:
        query_string = urllib.parse.urlencode(params)
        full_url = f"{url}?{query_string}"
        req = urllib.request.Request(full_url, headers={"User-Agent": "WeatherWise-OIBSIP/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read().decode("utf-8")
                return json.loads(data)
        except urllib.error.HTTPError as e:
            status = e.code
            try:
                err_data = json.loads(e.read().decode("utf-8"))
            except Exception:
                err_data = {}
            if status == 404:
                raise WeatherAPIError("City not found. Check the spelling and try again.", status_code=404)
            elif status == 401:
                raise WeatherAPIError("Invalid or inactive API key.", status_code=401)
            elif status == 429:
                raise WeatherAPIError("The API request limit has been reached. Please wait and try again.", status_code=429)
            elif status >= 500:
                raise WeatherAPIError("OpenWeatherMap service is temporarily down.", status_code=status)
            else:
                msg = err_data.get("message", "Weather API request failed.")
                raise WeatherAPIError(f"Error ({status}): {msg}", status_code=status)
        except urllib.error.URLError as e:
            if "timed out" in str(e.reason).lower():
                raise WeatherAPIError("The request timed out. Please try again.")
            raise WeatherAPIError("Unable to connect. Check your internet connection.")


def build_location_query(location: str) -> Dict[str, str]:
    cleaned = location.strip()
    parts = [p.strip() for p in cleaned.split(",")]
    if parts[0].isdigit() or (len(parts) > 1 and parts[0].isdigit()):
        if len(parts) == 1:
            return {"zip": cleaned}
        return {"zip": f"{parts[0]},{parts[1]}"}
    return {"q": cleaned}


def fetch_current_weather(location: str, api_key: Optional[str] = None) -> Dict[str, Any]:
    key = (api_key or get_api_key()).strip()
    if not key or key == "your_api_key_here":
        raise WeatherAPIError("API key is missing. Please set OPENWEATHER_API_KEY in your .env file.")

    url = f"{OPENWEATHER_BASE_URL}/weather"
    params = build_location_query(location)
    params["appid"] = key
    params["units"] = "metric"
    return _http_get_json(url, params)


def fetch_forecast(location: str, api_key: Optional[str] = None) -> Dict[str, Any]:
    key = (api_key or get_api_key()).strip()
    if not key or key == "your_api_key_here":
        raise WeatherAPIError("API key is missing. Please set OPENWEATHER_API_KEY in your .env file.")

    url = f"{OPENWEATHER_BASE_URL}/forecast"
    params = build_location_query(location)
    params["appid"] = key
    params["units"] = "metric"
    return _http_get_json(url, params)


def fetch_weather_icon(icon_code: str, timeout: int = 5) -> Optional[bytes]:
    if not icon_code:
        return None
    if icon_code in _ICON_CACHE:
        return _ICON_CACHE[icon_code]

    url = ICON_URL_TEMPLATE.format(icon_code=icon_code)
    try:
        if HAS_REQUESTS:
            resp = requests.get(url, timeout=timeout)
            if resp.status_code == 200:
                _ICON_CACHE[icon_code] = resp.content
                return resp.content
        else:
            req = urllib.request.Request(url, headers={"User-Agent": "WeatherWise-OIBSIP/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                _ICON_CACHE[icon_code] = data
                return data
    except Exception:
        return None
    return None


def detect_location_by_ip(timeout: int = 5) -> Tuple[str, str]:
    try:
        if HAS_REQUESTS:
            resp = requests.get(IPINFO_URL, timeout=timeout)
            if resp.status_code == 200:
                data = resp.json()
                city = data.get("city", "").strip()
                country = data.get("country", "").strip()
                if city:
                    return city, country
        else:
            req = urllib.request.Request(IPINFO_URL, headers={"User-Agent": "WeatherWise-OIBSIP/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                city = data.get("city", "").strip()
                country = data.get("country", "").strip()
                if city:
                    return city, country
    except Exception:
        raise WeatherAPIError("Could not auto-detect location via IP. Please enter your city manually.")
    raise WeatherAPIError("Could not determine city name from IP info.")
`
  },
  {
    name: "weather_utils.py",
    path: "OIBSIP/PythonProgramming/Task4_Weather_App/weather_utils.py",
    language: "python",
    description: "Pure algorithmic functions: mathematical temperature conversion (°C <-> °F), input sanitization, JSON parsing, 6-9h interval extraction, and 5-day daily aggregation.",
    content: `"""
WeatherWise - Weather Utilities Module
OIBSIP Python Programming Internship - Task 4

This module contains pure, reusable helper functions for:
- Temperature conversions (Celsius <-> Fahrenheit)
- Input validation and sanitization
- Response JSON parsing and field extraction
- Forecast interval filtering (next 6-9 hours)
- 5-day daily forecast aggregation (min/max temperatures & conditions)
"""

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple


def celsius_to_fahrenheit(celsius: float) -> float:
    return round((celsius * 9.0 / 5.0) + 32.0, 1)


def fahrenheit_to_celsius(fahrenheit: float) -> float:
    return round((fahrenheit - 32.0) * 5.0 / 9.0, 1)


def format_temperature(temp_celsius: float, unit: str = "C") -> str:
    if unit.upper() == "F":
        temp_f = celsius_to_fahrenheit(temp_celsius)
        return f"{temp_f:.1f}°F"
    return f"{temp_celsius:.1f}°C"


def validate_location_input(location_text: Optional[str]) -> Tuple[bool, str]:
    if location_text is None:
        return False, "Please enter a city or postal code."
    
    cleaned = location_text.strip()
    if not cleaned:
        return False, "Please enter a city or postal code."
    
    if len(cleaned) < 2:
        return False, "Location name must be at least 2 characters."
    
    if any(char in cleaned for char in ["<", ">", ";", "{", "}", "\\"]):
        return False, "Location contains invalid characters."
        
    return True, cleaned


def parse_current_weather(data: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("Invalid weather data format received.")
    
    cod = data.get("cod")
    if cod and str(cod) not in ("200", 200):
        msg = data.get("message", "Weather data unavailable.")
        raise ValueError(f"API Error ({cod}): {msg}")

    main = data.get("main")
    if not isinstance(main, dict) or "temp" not in main:
        raise ValueError("Missing 'main' temperature section in API response.")

    weather_list = data.get("weather", [])
    weather_info = weather_list[0] if (isinstance(weather_list, list) and len(weather_list) > 0) else {}

    sys_info = data.get("sys", {}) if isinstance(data.get("sys"), dict) else {}
    wind_info = data.get("wind", {}) if isinstance(data.get("wind"), dict) else {}

    city_name = data.get("name", "Unknown City")
    country = sys_info.get("country", "")
    full_location = f"{city_name}, {country}" if country else city_name

    temp_c = float(main.get("temp", 0.0))
    feels_like_c = float(main.get("feels_like", temp_c))
    temp_min_c = float(main.get("temp_min", temp_c))
    temp_max_c = float(main.get("temp_max", temp_c))
    
    humidity = main.get("humidity", 0)
    pressure = main.get("pressure", 1013)
    
    wind_speed = wind_info.get("speed", 0.0)
    wind_deg = wind_info.get("deg", 0)

    condition = weather_info.get("main", "Clear")
    description = weather_info.get("description", "Clear Sky").title()
    icon_code = weather_info.get("icon", "01d")

    dt_timestamp = data.get("dt", 0)
    timestamp_str = datetime.fromtimestamp(dt_timestamp).strftime("%I:%M %p, %b %d") if dt_timestamp else "Just now"

    return {
        "city": city_name,
        "country": country,
        "full_location": full_location,
        "temp_c": round(temp_c, 1),
        "feels_like_c": round(feels_like_c, 1),
        "temp_min_c": round(temp_min_c, 1),
        "temp_max_c": round(temp_max_c, 1),
        "humidity": int(humidity),
        "pressure": int(pressure),
        "wind_speed_mps": round(float(wind_speed), 1),
        "wind_deg": int(wind_deg),
        "condition": condition,
        "description": description,
        "icon_code": icon_code,
        "timestamp_str": timestamp_str,
    }


def extract_upcoming_intervals(forecast_data: Dict[str, Any], count: int = 3) -> List[Dict[str, Any]]:
    if not isinstance(forecast_data, dict):
        return []

    item_list = forecast_data.get("list", [])
    if not isinstance(item_list, list):
        return []

    results = []
    for item in item_list[:count]:
        if not isinstance(item, dict):
            continue
        
        main = item.get("main", {})
        weather = item.get("weather", [{}])[0]
        dt_txt = item.get("dt_txt", "")
        dt_timestamp = item.get("dt", 0)
        
        time_label = "Upcoming"
        if dt_txt:
            try:
                dt_obj = datetime.strptime(dt_txt, "%Y-%m-%d %H:%M:%S")
                time_label = dt_obj.strftime("%I:%M %p")
            except ValueError:
                time_label = dt_txt
        elif dt_timestamp:
            dt_obj = datetime.fromtimestamp(dt_timestamp)
            time_label = dt_obj.strftime("%I:%M %p")

        temp_c = float(main.get("temp", 0.0))
        
        results.append({
            "time_label": time_label,
            "raw_dt_txt": dt_txt,
            "temp_c": round(temp_c, 1),
            "description": weather.get("description", "Normal").title(),
            "condition": weather.get("main", "Normal"),
            "icon_code": weather.get("icon", "01d"),
            "humidity": main.get("humidity", 0),
        })

    return results


def group_forecast_by_day(forecast_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not isinstance(forecast_data, dict):
        return []

    item_list = forecast_data.get("list", [])
    if not isinstance(item_list, list):
        return []

    daily_buckets: Dict[str, List[Dict[str, Any]]] = {}

    for item in item_list:
        if not isinstance(item, dict):
            continue
        dt_txt = item.get("dt_txt", "")
        if not dt_txt:
            dt_ts = item.get("dt", 0)
            if dt_ts:
                dt_txt = datetime.fromtimestamp(dt_ts).strftime("%Y-%m-%d %H:%M:%S")
            else:
                continue

        date_key = dt_txt.split(" ")[0]
        if date_key not in daily_buckets:
            daily_buckets[date_key] = []
        daily_buckets[date_key].append(item)

    daily_summary: List[Dict[str, Any]] = []

    for date_key, slices in daily_buckets.items():
        try:
            date_obj = datetime.strptime(date_key, "%Y-%m-%d")
            day_name = date_obj.strftime("%A")
            date_formatted = date_obj.strftime("%b %d")
        except ValueError:
            day_name = date_key
            date_formatted = date_key

        temps = []
        humidities = []
        midday_slice = None

        for s in slices:
            main = s.get("main", {})
            if "temp" in main:
                temps.append(float(main["temp"]))
            if "humidity" in main:
                humidities.append(int(main["humidity"]))
            
            dt_txt = s.get("dt_txt", "")
            if "12:00:00" in dt_txt or "15:00:00" in dt_txt:
                midday_slice = s

        if not temps:
            continue

        if midday_slice is None:
            midday_slice = slices[len(slices) // 2]

        weather_rep = midday_slice.get("weather", [{}])[0]
        min_temp_c = min(temps)
        max_temp_c = max(temps)
        avg_humidity = sum(humidities) // len(humidities) if humidities else 0

        daily_summary.append({
            "date_key": date_key,
            "day_name": day_name,
            "date_formatted": date_formatted,
            "min_temp_c": round(min_temp_c, 1),
            "max_temp_c": round(max_temp_c, 1),
            "description": weather_rep.get("description", "Variable").title(),
            "condition": weather_rep.get("main", "Variable"),
            "icon_code": weather_rep.get("icon", "01d"),
            "humidity": avg_humidity,
            "data_points_count": len(slices),
        })

    return daily_summary[:5]
`
  },
  {
    name: "tests/test_weather_utils.py",
    path: "OIBSIP/PythonProgramming/Task4_Weather_App/tests/test_weather_utils.py",
    language: "python",
    description: "Automated test suite verifying Celsius/Fahrenheit math, input sanitization, malformed response handling, 3-hour slices, and daily grouping.",
    content: `"""
Unit tests for weather_utils.py
OIBSIP Python Programming Internship - Task 4
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from weather_utils import (
    celsius_to_fahrenheit,
    fahrenheit_to_celsius,
    format_temperature,
    validate_location_input,
    parse_current_weather,
    extract_upcoming_intervals,
    group_forecast_by_day,
)


class TestWeatherUtils(unittest.TestCase):

    def test_01_celsius_to_fahrenheit_conversion(self):
        self.assertEqual(celsius_to_fahrenheit(0.0), 32.0)
        self.assertEqual(celsius_to_fahrenheit(100.0), 212.0)
        self.assertEqual(celsius_to_fahrenheit(25.0), 77.0)
        self.assertEqual(celsius_to_fahrenheit(-40.0), -40.0)

    def test_02_fahrenheit_to_celsius_conversion(self):
        self.assertEqual(fahrenheit_to_celsius(32.0), 0.0)
        self.assertEqual(fahrenheit_to_celsius(212.0), 100.0)
        self.assertEqual(fahrenheit_to_celsius(77.0), 25.0)

    def test_03_format_temperature_unit_switch(self):
        self.assertEqual(format_temperature(24.5, "C"), "24.5°C")
        self.assertEqual(format_temperature(24.5, "F"), "76.1°F")

    def test_04_empty_location_validation(self):
        is_valid, msg = validate_location_input("")
        self.assertFalse(is_valid)
        is_valid, msg = validate_location_input("   ")
        self.assertFalse(is_valid)
        is_valid, msg = validate_location_input("A")
        self.assertFalse(is_valid)

        is_valid, cleaned = validate_location_input("  Pune  ")
        self.assertTrue(is_valid)
        self.assertEqual(cleaned, "Pune")

    def test_05_parse_valid_current_weather(self):
        sample = {
            "name": "Pune",
            "cod": 200,
            "main": {"temp": 28.5, "feels_like": 29.8, "humidity": 45, "pressure": 1012},
            "weather": [{"main": "Clear", "description": "clear sky", "icon": "01d"}],
            "wind": {"speed": 3.6, "deg": 240},
            "sys": {"country": "IN"}
        }
        parsed = parse_current_weather(sample)
        self.assertEqual(parsed["city"], "Pune")
        self.assertEqual(parsed["full_location"], "Pune, IN")
        self.assertEqual(parsed["temp_c"], 28.5)
        self.assertEqual(parsed["humidity"], 45)

    def test_06_parse_weather_missing_fields_gracefully(self):
        minimal = {"name": "Satara", "main": {"temp": 22.0}, "cod": 200}
        parsed = parse_current_weather(minimal)
        self.assertEqual(parsed["city"], "Satara")
        self.assertEqual(parsed["temp_c"], 22.0)
        self.assertEqual(parsed["humidity"], 0)

    def test_07_parse_weather_invalid_structure_raises(self):
        with self.assertRaises(ValueError):
            parse_current_weather({"invalid": "structure"})

    def test_08_extract_upcoming_intervals(self):
        sample = {
            "list": [
                {"dt_txt": "2026-10-28 15:00:00", "main": {"temp": 27.2}, "weather": [{"description": "clouds", "icon": "03d"}]},
                {"dt_txt": "2026-10-28 18:00:00", "main": {"temp": 24.1}, "weather": [{"description": "clear", "icon": "01n"}]},
            ]
        }
        intervals = extract_upcoming_intervals(sample, count=2)
        self.assertEqual(len(intervals), 2)
        self.assertEqual(intervals[0]["temp_c"], 27.2)

    def test_09_group_forecast_by_day(self):
        sample = {
            "list": [
                {"dt_txt": "2026-10-29 09:00:00", "main": {"temp": 20.0}, "weather": [{"main": "Clear", "icon": "01d"}]},
                {"dt_txt": "2026-10-29 12:00:00", "main": {"temp": 30.0}, "weather": [{"main": "Clear", "icon": "01d"}]},
            ]
        }
        daily = group_forecast_by_day(sample)
        self.assertEqual(len(daily), 1)
        self.assertEqual(daily[0]["min_temp_c"], 20.0)
        self.assertEqual(daily[0]["max_temp_c"], 30.0)

    def test_10_group_forecast_empty_or_corrupt_data(self):
        self.assertEqual(group_forecast_by_day({}), [])


if __name__ == "__main__":
    unittest.main()
`
  },
  {
    name: "tests/test_weather_api.py",
    path: "OIBSIP/PythonProgramming/Task4_Weather_App/tests/test_weather_api.py",
    language: "python",
    description: "Mocked network tests simulating offline conditions, 404 city not found, 401 unactivated key, 429 rate limit, 500 server outage, and IP geolocation.",
    content: `"""
Unit tests for weather_api.py
OIBSIP Python Programming Internship - Task 4
"""

import unittest
from unittest.mock import patch, MagicMock
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import weather_api
from weather_api import (
    WeatherAPIError,
    fetch_current_weather,
    fetch_forecast,
    build_location_query,
    detect_location_by_ip,
)


class TestWeatherAPI(unittest.TestCase):

    def test_01_missing_api_key_raises_error(self):
        with patch.dict(os.environ, {"OPENWEATHER_API_KEY": ""}, clear=True):
            with self.assertRaises(WeatherAPIError) as ctx:
                fetch_current_weather("Pune", api_key="")
            self.assertIn("API key is missing", str(ctx.exception))

    def test_02_placeholder_api_key_raises_error(self):
        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_current_weather("Mumbai", api_key="your_api_key_here")
        self.assertIn("API key is missing", str(ctx.exception))

    def test_03_build_location_query_city_vs_zip(self):
        self.assertEqual(build_location_query("Pune"), {"q": "Pune"})
        self.assertEqual(build_location_query("411001"), {"zip": "411001"})

    @patch("weather_api._http_get_json")
    def test_04_successful_fetch_current_weather(self, mock_get_json):
        mock_get_json.return_value = {
            "name": "Pune", "cod": 200, "main": {"temp": 28.0}, "weather": [{"main": "Clear"}]
        }
        data = fetch_current_weather("Pune", api_key="test_dummy_key_123")
        self.assertEqual(data["name"], "Pune")

    @patch("weather_api._http_get_json")
    def test_05_city_not_found_404_handling(self, mock_get_json):
        mock_get_json.side_effect = WeatherAPIError("City not found. Check the spelling and try again.", status_code=404)
        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_current_weather("FakeCityXYZ", api_key="test_key")
        self.assertEqual(ctx.exception.status_code, 404)

    @patch("weather_api._http_get_json")
    def test_06_invalid_api_key_401_handling(self, mock_get_json):
        mock_get_json.side_effect = WeatherAPIError("Invalid or inactive API key.", status_code=401)
        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_current_weather("Pune", api_key="bad_key")
        self.assertEqual(ctx.exception.status_code, 401)

    @patch("weather_api._http_get_json")
    def test_07_request_timeout_handling(self, mock_get_json):
        mock_get_json.side_effect = WeatherAPIError("The request timed out. Please try again.")
        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_current_weather("Mumbai", api_key="valid_key")
        self.assertIn("timed out", str(ctx.exception).lower())

    @patch("weather_api._http_get_json")
    def test_08_connection_failure_handling(self, mock_get_json):
        mock_get_json.side_effect = WeatherAPIError("Unable to connect. Check your internet connection.")
        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_current_weather("Mumbai", api_key="valid_key")
        self.assertIn("unable to connect", str(ctx.exception).lower())

    @patch("weather_api._http_get_json")
    def test_09_rate_limit_429_handling(self, mock_get_json):
        mock_get_json.side_effect = WeatherAPIError("The API request limit has been reached. Please wait and try again.", status_code=429)
        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_forecast("Pune", api_key="valid_key")
        self.assertEqual(ctx.exception.status_code, 429)

    @patch("weather_api._http_get_json")
    def test_10_server_error_500_handling(self, mock_get_json):
        mock_get_json.side_effect = WeatherAPIError("OpenWeatherMap service is temporarily down.", status_code=500)
        with self.assertRaises(WeatherAPIError) as ctx:
            fetch_current_weather("Delhi", api_key="valid_key")
        self.assertEqual(ctx.exception.status_code, 500)

    def test_11_detect_location_by_ip_success(self):
        sample_json = '{"city": "Pune", "country": "IN", "ip": "103.21.124.1"}'
        if weather_api.HAS_REQUESTS:
            with patch("requests.get") as mock_get:
                mock_resp = MagicMock()
                mock_resp.status_code = 200
                mock_resp.json.return_value = {"city": "Pune", "country": "IN"}
                mock_get.return_value = mock_resp
                city, country = detect_location_by_ip()
                self.assertEqual(city, "Pune")
        else:
            with patch("urllib.request.urlopen") as mock_urlopen:
                mock_resp = MagicMock()
                mock_resp.read.return_value = sample_json.encode("utf-8")
                mock_resp.__enter__.return_value = mock_resp
                mock_urlopen.return_value = mock_resp
                city, country = detect_location_by_ip()
                self.assertEqual(city, "Pune")


if __name__ == "__main__":
    unittest.main()
`
  },
  {
    name: "requirements.txt",
    path: "OIBSIP/PythonProgramming/Task4_Weather_App/requirements.txt",
    language: "text",
    description: "Third-party pip dependencies required to run the Tkinter desktop app and execute network requests.",
    content: `# OIBSIP Task 4: Basic Weather App (WeatherWise)
# Dependencies list

requests>=2.28.0
python-dotenv>=1.0.0
Pillow>=10.0.0
`
  },
  {
    name: ".env.example",
    path: "OIBSIP/PythonProgramming/Task4_Weather_App/.env.example",
    language: "bash",
    description: "Safe environment variable template file demonstrating where to place the OpenWeatherMap API key without checking in real secrets.",
    content: `# OpenWeatherMap API Key
# 1. Sign up at https://openweathermap.org/
# 2. Go to your API keys page and copy your 32-character key
# 3. Create a local '.env' file in this folder and paste your key below:
OPENWEATHER_API_KEY=your_api_key_here
`
  },
  {
    name: ".gitignore",
    path: "OIBSIP/PythonProgramming/Task4_Weather_App/.gitignore",
    language: "gitignore",
    description: "Git ignore configuration preventing .env secrets, __pycache__, and .venv virtual environment from being committed.",
    content: `# Environment files and credentials (CRITICAL: Never commit real API keys)
.env
.env.local
*.env

# Python bytecode & cache
__pycache__/
*.py[cod]
*$py.class
*.so

# Virtual environment
.venv/
venv/
ENV/
env/

# IDE & Editor artifacts
.vscode/
.idea/
*.swp
*.swo
*~

# Operating system files
.DS_Store
Thumbs.db

# Test & coverage reports
.pytest_cache/
.coverage
htmlcov/
`
  },
  {
    name: "README.md",
    path: "OIBSIP/PythonProgramming/Task4_Weather_App/README.md",
    language: "markdown",
    description: "Complete student submission documentation: setup commands, virtual env, unit test verification, and viva examination talking points.",
    content: `# WeatherWise — Weather Forecast App ⛅

> **OIBSIP Internship Task 4 — Python Programming**  
> **Student:** 2nd Year Computer Engineering  
> **Technology Stack:** Python 3, Tkinter & ttk, requests, python-dotenv, Pillow, OpenWeatherMap API  

---

## 📌 Project Overview

**WeatherWise** is a modern, responsive, and robust desktop weather forecast application developed as part of the **Oasis Infobyte Summer Internship Program (OIBSIP)** Python Programming track.

The application allows users to query real-time atmospheric conditions and multi-day forecasts for any city or postal code worldwide using the official **OpenWeatherMap REST API**. The user interface is designed with a modern dark theme using Python's native tkinter.ttk framework, with multi-threaded asynchronous networking to ensure smooth, unfreezing performance.

---

## ✨ Features Checklist

| Feature | Status | Description |
| :--- | :---: | :--- |
| **City & ZIP Code Input** | ✅ | Search by city name (Pune, Tokyo, London, UK) or postal codes (411001,IN, 90210,US). |
| **Real-Time Weather Metrics** | ✅ | Displays Temperature, Feels-Like, Condition, Humidity (%), Wind Speed (m/s & km/h), and Atmospheric Pressure (hPa). |
| **Dynamic Unit Toggle** | ✅ | Instant switch between Celsius (°C) and Fahrenheit (°F) with zero redundant network queries. |
| **Next 6–9 Hours Forecast** | ✅ | Real upcoming forecast slices using OpenWeatherMap's 3-hour intervals with exact time labels. |
| **5-Day Daily Outlook** | ✅ | Aggregated daily forecast calculating genuine minimum and maximum temperatures across intervals. |
| **Official Weather Icons** | ✅ | Loads official OpenWeatherMap icons with in-memory caching and fallback vector drawings. |
| **Detect My Location** | ✅ | Optional one-click IP-based geolocation lookup via ipinfo.io (user-initiated only). |
| **In-GUI Error Notifications** | ✅ | Clear banner messages for city not found (404), invalid API key (401), rate limits (429), and offline network timeouts. |
| **Non-Blocking UI (Threading)** | ✅ | Network requests execute on background daemon threads so the GUI never freezes. |
| **Comprehensive Test Suite** | ✅ | 21 automated unit tests with mocked HTTP responses passing 100%. |

---

## 🛠️ Technology Stack

- **Core Language:** Python 3.10+
- **Graphical User Interface:** tkinter & tkinter.ttk (native Python GUI toolkit)
- **HTTP Client:** requests (with built-in fallback to urllib.request)
- **Environment Management:** python-dotenv
- **Image Processing:** Pillow (PIL.Image & PIL.ImageTk) for icon rendering
- **Testing Framework:** unittest and unittest.mock

---

## 📂 Project Structure

\`\`\`text
OIBSIP/PythonProgramming/Task4_Weather_App/
│
├── main.py                     # GUI entry point (Tkinter app, event loop & threads)
├── weather_api.py              # HTTP client, endpoint definitions & error classification
├── weather_utils.py            # Unit conversion, input validation & data grouping
│
├── tests/
│   ├── __init__.py             # Tests package marker
│   ├── test_weather_utils.py   # Unit tests for temperature conversion & parsing
│   └── test_weather_api.py     # Mocked tests for API responses, 404, 401, 429, timeouts
│
├── requirements.txt            # Third-party Python dependencies
├── .env.example                # Sample environment template (safe to commit)
├── .gitignore                  # Excludes .env, __pycache__, and venv
└── README.md                   # Full documentation and evaluation guide
\`\`\`

---

## 🔑 How to Obtain an OpenWeatherMap API Key

1. Visit **https://openweathermap.org/** and click **Sign In** / **Create an Account**.
2. Once registered and verified via email, navigate to your profile menu and select **My API Keys**.
3. Under **Create key**, enter a name (e.g., WeatherWise-App) and click **Generate**.
4. Copy your 32-character hexadecimal key.
5. **Important Note:** Newly created OpenWeatherMap keys typically take **15 to 60 minutes** to propagate through their CDN servers. If you receive an Invalid or inactive API key message initially, wait a short while and retry.

---

## 🚀 Setup & Installation Guide

### Step 1: Clone or Navigate to the Project Folder
\`\`\`bash
cd OIBSIP/PythonProgramming/Task4_Weather_App
\`\`\`

### Step 2: Create a Virtual Environment
\`\`\`bash
python -m venv .venv
\`\`\`

### Step 3: Activate the Virtual Environment
- **On macOS / Linux:**
  \`\`\`bash
  source .venv/bin/activate
  \`\`\`
- **On Windows (Command Prompt):**
  \`\`\`cmd
  .venv\\Scripts\\activate.bat
  \`\`\`
- **On Windows (PowerShell):**
  \`\`\`powershell
  .venv\\Scripts\\Activate.ps1
  \`\`\`

### Step 4: Install Dependencies
\`\`\`bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
\`\`\`

> **Note for Linux Users (Ubuntu/Debian):**  
> If Tkinter is not pre-installed on your system distribution, install it via:  
> \`sudo apt-get install python3-tk\`

### Step 5: Configure Your API Key
Copy \`.env.example\` to create a real local \`.env\` file:
\`\`\`bash
cp .env.example .env
\`\`\`
Open \`.env\` in any text editor and paste your key:
\`\`\`ini
OPENWEATHER_API_KEY=your_actual_32_char_api_key_here
\`\`\`
*(Notice: The .gitignore file guarantees .env will never be accidentally committed to git).*

---

## 🖥️ Running the Application

Launch the desktop GUI by executing:
\`\`\`bash
python main.py
\`\`\`

### Interacting with the Interface:
1. Type a city name (e.g., Pune, Mumbai, London, New York) or postal code into the input field.
2. Press Enter or click **Get Weather**.
3. Click **°C / °F** in the top right corner anytime to instantly toggle between Celsius and Fahrenheit.
4. Click **📍 Detect My Location** to look up your approximate city via IP.

---

## 🧪 Running Automated Unit Tests

Run the full test suite with verbose reporting:

\`\`\`bash
python -m unittest discover -s tests -v
\`\`\`

All 21 tests pass with 100% test coverage using mocked responses.

---

## ⚠️ API Endpoint & Forecast Design Transparency

### OpenWeatherMap Free Tier Limitation:
OpenWeatherMap's free tier provides two primary endpoints:
1. \`/data/2.5/weather\` — Real-time current conditions.
2. \`/data/2.5/forecast\` — 5-day forecast provided in **3-hour interval slices** (8 slices per 24 hours), **not** 1-hour interval slices.

### How WeatherWise Handles This Honestly:
- **Upcoming Forecast:** Rather than interpolating fabricated hourly numbers, the app extracts the next three 3-hour slices (covering the next 6 to 9 hours) and clearly displays the actual target forecast timestamp (e.g., 03:00 PM, 06:00 PM, 09:00 PM).
- **5-Day Daily Outlook:** The app groups all 3-hour slices by calendar date, calculating the genuine observed minimum and maximum temperatures across those slices for each day, alongside the midday representative weather condition.

---

## 🔒 Security & Privacy Considerations

1. **Zero Secret Leaks:** Real API keys are stored exclusively in the uncommitted .env file and accessed via os.getenv(). They are never logged to console or shown in the GUI.
2. **Explicit Geolocation:** Location detection via ipinfo.io is strictly opt-in and triggered solely when the user clicks Detect My Location. No background or startup tracking occurs.
3. **Safe Network Calls:** A 10-second request timeout prevents hanging sockets in unstable network environments.

---

## 🎓 Viva & Presentation Talking Points (For Internship Evaluation)

When demonstrating WeatherWise to your internship mentor or evaluator:

1. **What is an API?**  
   *Analogous to a restaurant waiter:* The customer (our Tkinter app) asks the waiter for a menu item (weather for Pune), the waiter conveys the request to the kitchen (OpenWeatherMap servers), and brings back the prepared dish (JSON data).
2. **Why use JSON?**  
   JavaScript Object Notation is a lightweight, human-readable text standard for data interchange. In Python, response.json() converts this string directly into native dictionaries and lists.
3. **Why use threading?**  
   Tkinter runs on a single event loop (root.mainloop()). If an HTTP request takes 2 seconds over the network, running it synchronously freezes the window. By running requests in threading.Thread(daemon=True) and posting results back via root.after(), the user interface stays butter-smooth.
4. **How does unit toggling avoid re-fetching?**  
   All temperatures are stored in memory in Celsius. When the user switches to Fahrenheit, the pure mathematical function (C * 9/5) + 32 recalculates the labels instantly without wasting API quota.

---

## 📜 License & Acknowledgments

- **Internship:** Oasis Infobyte (OIBSIP)
- **Data Provider:** OpenWeatherMap API
- **IP Detection:** ipinfo.io
`
  }
];
