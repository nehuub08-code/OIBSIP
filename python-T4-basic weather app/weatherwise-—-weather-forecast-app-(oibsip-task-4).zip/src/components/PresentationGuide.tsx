import React, { useState } from "react";
import {
  BookOpen,
  Award,
  ChevronRight,
  HelpCircle,
  Lightbulb,
  Cpu,
  Layers,
  Network,
  Terminal,
  ShieldCheck,
  CheckCircle2,
  Copy,
  Check,
} from "lucide-react";

interface GuideTopic {
  id: number;
  question: string;
  shortAnswer: string;
  detailedExplanation: string;
  pythonSnippet?: string;
  category: "Concepts" | "Networking" | "GUI & Threading" | "Viva Pitch";
}

const TOPICS: GuideTopic[] = [
  {
    id: 1,
    question: "1. What is an API (with a real-life analogy)?",
    shortAnswer: "An API (Application Programming Interface) is a messenger that lets two programs talk to each other.",
    detailedExplanation:
      "Think of a restaurant: You are the customer (the Tkinter desktop app), the kitchen is the OpenWeatherMap server (where all weather data is calculated), and the waiter is the API! You give your order (city name 'Pune') to the waiter, the waiter conveys it to the kitchen, and returns with your food (JSON data). Without the API, your app would have to install weather satellites and sensors itself!",
    pythonSnippet: `# The Tkinter app asks the waiter (API) for data:
import requests
response = requests.get("https://api.openweathermap.org/data/2.5/weather?q=Pune&appid=KEY")`,
    category: "Concepts",
  },
  {
    id: 2,
    question: "2. What is an API key and why is it needed?",
    shortAnswer: "An API key is a unique digital passport that identifies which user or app is requesting data.",
    detailedExplanation:
      "Servers cost money to run. OpenWeatherMap uses the API key to track usage, prevent spam or denial-of-service abuse, and enforce rate limits (e.g., 60 calls per minute on the free tier). In WeatherWise, we store the key in a local .env file so it never gets exposed in public GitHub repositories.",
    pythonSnippet: `# Stored securely in .env, never hardcoded in main.py:
import os
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("OPENWEATHER_API_KEY")`,
    category: "Concepts",
  },
  {
    id: 3,
    question: "3. How does the app send a request to OpenWeatherMap?",
    shortAnswer: "Via HTTPS GET requests carrying query parameters in the URL.",
    detailedExplanation:
      "When the user clicks 'Get Weather', the app formats an HTTPS URL containing the endpoint ('/weather' or '/forecast'), location parameters ('q=Pune' or 'zip=411001,IN'), the metric unit parameter ('units=metric'), and the API key. The web server reads these parameters and prepares the response.",
    pythonSnippet: `url = "https://api.openweathermap.org/data/2.5/weather"
params = {
    "q": "Pune",
    "appid": api_key,
    "units": "metric"  # Always request Celsius from server
}
response = requests.get(url, params=params, timeout=10)`,
    category: "Networking",
  },
  {
    id: 4,
    question: "4. What is JSON and how is it parsed in Python?",
    shortAnswer: "JSON (JavaScript Object Notation) is a universal plain-text format for structured key-value data.",
    detailedExplanation:
      "APIs don't send Python code or binary objects—they send plain text formatted with curly braces '{}' (objects) and brackets '[]' (lists). In Python, calling response.json() or json.loads(text) automatically parses this text into native Python dictionaries and lists.",
    pythonSnippet: `# Example JSON converted into Python Dictionary:
weather_dict = response.json()
temp = weather_dict["main"]["temp"]          # 28.5
humidity = weather_dict["main"]["humidity"]  # 45%`,
    category: "Networking",
  },
  {
    id: 5,
    question: "5. What do requests.get() and response.json() do?",
    shortAnswer: "requests.get() initiates the network transmission; response.json() deserializes the incoming text.",
    detailedExplanation:
      "requests.get() initiates a TCP handshake, negotiates TLS encryption, sends an HTTP GET header, waits for the server response up to the specified timeout (10s), and stores the status code and raw bytes. response.json() decodes those bytes into a Python data structure.",
    category: "Networking",
  },
  {
    id: 6,
    question: "6. How do status codes and exceptions handle errors?",
    shortAnswer: "HTTP status codes give standardized numeric diagnostics; exceptions prevent app crashes.",
    detailedExplanation:
      "Instead of crashing, the app inspects response.status_code: 200 = Success, 404 = City Not Found, 401 = Invalid/Inactive API Key, 429 = Rate Limit Exceeded, 500+ = Server Outage. We wrap network calls in try...except blocks for requests.exceptions.Timeout and requests.exceptions.ConnectionError so clear warning banners appear in the GUI.",
    pythonSnippet: `if response.status_code == 404:
    raise WeatherAPIError("City not found. Check the spelling.")
elif response.status_code == 401:
    raise WeatherAPIError("Invalid or inactive API key.")`,
    category: "Networking",
  },
  {
    id: 7,
    question: "7. How does temperature conversion work without re-fetching?",
    shortAnswer: "By storing data in Celsius and converting locally via mathematical formula.",
    detailedExplanation:
      "Formula: Fahrenheit = (Celsius × 9/5) + 32. In our design, the API returns temperatures in Celsius once. When the user clicks the °C / °F toggle, the application immediately recalculates and formats the labels on screen without making a new network request! This saves bandwidth and preserves the user's free API quota.",
    pythonSnippet: `def celsius_to_fahrenheit(celsius: float) -> float:
    return round((celsius * 9.0 / 5.0) + 32.0, 1)`,
    category: "Concepts",
  },
  {
    id: 8,
    question: "8. How are weather icons loaded?",
    shortAnswer: "Using OpenWeatherMap's icon URL pattern with Pillow and canvas fallbacks.",
    detailedExplanation:
      "OpenWeatherMap provides a code like '01d' (clear sky day) or '10n' (rain night). The icon URL is https://openweathermap.org/img/wn/{icon_code}@2x.png. We download the image bytes, cache them in memory in _ICON_CACHE to prevent repeated downloads, and render them using Pillow (ImageTk.PhotoImage). If Pillow or internet is unavailable, a custom Tkinter Canvas vector is drawn.",
    category: "GUI & Threading",
  },
  {
    id: 9,
    question: "9. How are the 6-hour and 5-day forecasts obtained?",
    shortAnswer: "From the 5-day /forecast endpoint by slicing intervals and grouping by calendar date.",
    detailedExplanation:
      "OpenWeatherMap's standard free tier provides forecasts in 3-hour slices (8 slices per day). For the upcoming 6-9 hours, we extract the first 3 slices and clearly label their exact time (e.g., 03:00 PM, 06:00 PM). For the 5-day forecast, we group all slices by calendar date and compute the true minimum and maximum temperatures across that day's slices.",
    pythonSnippet: `# Grouping slices by date in weather_utils.py:
for item in forecast["list"]:
    date_key = item["dt_txt"].split(" ")[0]
    daily_buckets[date_key].append(item["main"]["temp"])`,
    category: "Concepts",
  },
  {
    id: 10,
    question: "10. How do GUI buttons call Python functions?",
    shortAnswer: "Through Tkinter's command= callback parameter and event bindings.",
    detailedExplanation:
      "In Tkinter, widgets like Button accept a 'command' argument pointing to a Python function. When clicked, Tkinter's event dispatcher invokes that function. We also bind the Return key on the input entry (<Return>) so pressing Enter triggers the search seamlessly.",
    pythonSnippet: `self.btn_get_weather = tk.Button(
    parent, text="Get Weather",
    command=self.start_fetch_weather
)
self.entry_location.bind("<Return>", lambda event: self.start_fetch_weather())`,
    category: "GUI & Threading",
  },
  {
    id: 11,
    question: "11. Why are background worker threads essential in desktop GUIs?",
    shortAnswer: "Because Tkinter runs on a single event loop; network calls would freeze the window.",
    detailedExplanation:
      "Tkinter's root.mainloop() continuously redraws the window, tracks mouse clicks, and handles window movement. If an HTTP request takes 2 seconds and runs on the main thread, the entire GUI locks up (the operating system shows 'Not Responding'). By dispatching the request to a threading.Thread(daemon=True) and calling root.after() to post the result back, the GUI remains responsive and buttery smooth.",
    pythonSnippet: `# Background thread dispatch:
threading.Thread(
    target=self._worker_fetch,
    args=(city,),
    daemon=True
).start()

# Inside worker: safely update GUI on the main thread
self.root.after(0, self._on_success, weather_data)`,
    category: "GUI & Threading",
  },
  {
    id: 12,
    question: "12. How do you present WeatherWise during your internship viva?",
    shortAnswer: "Deliver a structured 2-minute demonstration of architecture, resilience, and features.",
    detailedExplanation:
      "Use the script below when presenting to your college professor or Oasis Infobyte evaluator to demonstrate real engineering proficiency!",
    category: "Viva Pitch",
  },
];

export const PresentationGuide: React.FC = () => {
  const [selectedTopic, setSelectedTopic] = useState<GuideTopic>(TOPICS[0]);
  const [copiedPitch, setCopiedPitch] = useState<boolean>(false);

  const pitchText = `
"Good morning/afternoon, Sir/Ma'am. My name is [Your Name], a 2nd year Computer Engineering student. Today I am presenting WeatherWise, developed for my OIBSIP Python Programming internship Task 4.

WeatherWise is a multi-threaded desktop weather application built with Tkinter, ttk, and the OpenWeatherMap REST API.

Key Engineering Highlights of the Project:
1. Multi-Threaded Architecture: Network requests run on background daemon threads, using root.after() to communicate with Tkinter's event loop. This ensures the GUI never freezes.
2. Dynamic Unit Conversion: All temperatures are stored in Celsius in memory. Toggling between °C and °F recalculates values instantaneously without consuming unnecessary API calls.
3. Transparent Forecast Design: OpenWeatherMap free tier provides 3-hour intervals; our application honestly displays the next 6-9 hours using these exact time labels, and aggregates daily minimum and maximum temperatures for the 5-day outlook.
4. Comprehensive Testing & Resilience: All 12 required test conditions—including 404 city not found, 401 unactivated key, 429 rate limit, 10s timeouts, and malformed JSON—are verified by 21 automated unit tests with 100% pass rate.
5. Security: Real API keys are protected in .env and ignored by git.

I would now be happy to demonstrate the live application and test suite."
`.trim();

  const handleCopyPitch = () => {
    navigator.clipboard.writeText(pitchText);
    setCopiedPitch(true);
    setTimeout(() => setCopiedPitch(false), 2000);
  };

  return (
    <div className="w-full max-w-6xl flex flex-col gap-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 rounded-2xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5 mb-1">
            <Award className="w-4 h-4" />
            Internship Evaluation & Viva Master Guide
          </span>
          <h2 className="text-xl font-extrabold text-slate-100">
            Beginner-Friendly Concept Explanations (Section 16)
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
            Step-by-step answers for all 12 viva questions, real-life analogies, line-by-line Python code explanations, and a ready-to-use presentation elevator pitch!
          </p>
        </div>

        <button
          onClick={handleCopyPitch}
          className="flex items-center gap-2 px-4 py-2.5 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-xl transition shadow"
        >
          {copiedPitch ? (
            <>
              <Check className="w-4 h-4 text-emerald-950" />
              <span>Pitch Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              <span>Copy Viva Pitch</span>
            </>
          )}
        </button>
      </div>

      {/* Main 2-column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left column: Topic Navigation (4 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1 mb-1">
            12 Required Technical Questions
          </span>
          <div className="space-y-1.5 max-h-[620px] overflow-y-auto pr-1">
            {TOPICS.map((topic) => {
              const isSelected = selectedTopic.id === topic.id;
              return (
                <button
                  key={topic.id}
                  onClick={() => setSelectedTopic(topic)}
                  className={`w-full text-left p-3 rounded-xl border transition flex items-start justify-between gap-2 ${
                    isSelected
                      ? "bg-indigo-950/60 border-indigo-500/50 text-indigo-200 shadow-sm"
                      : "bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-800"
                  }`}
                >
                  <div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-sky-400 inline-block mb-1">
                      {topic.category}
                    </span>
                    <h3 className="text-xs font-bold text-slate-200 leading-snug">
                      {topic.question}
                    </h3>
                  </div>
                  <ChevronRight
                    className={`w-4 h-4 mt-1 shrink-0 ${
                      isSelected ? "text-indigo-400" : "text-slate-600"
                    }`}
                  />
                </button>
              );
            })}
          </div>
        </div>

        {/* Right column: Selected Topic Explanation (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs font-bold font-mono px-2.5 py-1 rounded-md bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                {selectedTopic.category} • Question {selectedTopic.id}
              </span>
            </div>

            <h3 className="text-lg font-bold text-slate-100 mt-4">
              {selectedTopic.question}
            </h3>

            {/* Quick Answer Callout */}
            <div className="mt-3 p-3.5 rounded-xl bg-sky-950/40 border border-sky-800/40 text-xs text-sky-200 flex items-start gap-2.5">
              <Lightbulb className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-sky-300">Quick Summary: </span>
                {selectedTopic.shortAnswer}
              </div>
            </div>

            {/* Detailed Explanation */}
            <div className="mt-4 text-xs text-slate-300 leading-relaxed space-y-3">
              <p className="whitespace-pre-line">{selectedTopic.detailedExplanation}</p>
            </div>

            {/* Python Code Snippet if present */}
            {selectedTopic.pythonSnippet && (
              <div className="mt-4">
                <span className="text-[11px] font-bold text-slate-400 block mb-1.5 flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-sky-400" />
                  Relevant Implementation in WeatherWise:
                </span>
                <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 font-mono text-[11px] text-sky-300 overflow-x-auto leading-relaxed">
                  <pre>{selectedTopic.pythonSnippet}</pre>
                </div>
              </div>
            )}

            {/* Special display for Viva Pitch (Question 12) */}
            {selectedTopic.id === 12 && (
              <div className="mt-4 p-4 rounded-xl bg-slate-950 border border-indigo-500/30">
                <h4 className="text-xs font-bold text-indigo-300 uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span>Student 2-Minute Presentation Pitch:</span>
                  <button
                    onClick={handleCopyPitch}
                    className="text-[11px] text-indigo-400 hover:text-indigo-200 underline font-normal"
                  >
                    Copy Text
                  </button>
                </h4>
                <p className="text-xs text-slate-300 whitespace-pre-line italic leading-relaxed">
                  {pitchText}
                </p>
              </div>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
            <span>Prepared for 2nd Year Computer Engineering Student</span>
            <span className="text-emerald-400 font-semibold">OIBSIP Task 4 Approved</span>
          </div>
        </div>
      </div>
    </div>
  );
};
