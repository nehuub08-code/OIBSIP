import React, { useState } from "react";
import { CheckCircle2, ListChecks, CheckSquare, Square, Layers, ShieldCheck } from "lucide-react";

interface Phase {
  number: number;
  title: string;
  description: string;
  filesModified: string[];
  status: "Completed";
}

const PHASES: Phase[] = [
  {
    number: 1,
    title: "Phase 1: API Module & Current Weather Fetching",
    description: "Built weather_api.py communicating with OpenWeatherMap's /weather endpoint. Added fallback for urllib when requests is absent.",
    filesModified: ["weather_api.py"],
    status: "Completed",
  },
  {
    number: 2,
    title: "Phase 2: Validation, Unit Conversion & Error Handling",
    description: "Built weather_utils.py with pure functions for Celsius <-> Fahrenheit, input sanitation, and response JSON parsing. Created custom WeatherAPIError.",
    filesModified: ["weather_utils.py", "weather_api.py"],
    status: "Completed",
  },
  {
    number: 3,
    title: "Phase 3: Tkinter GUI with Hero Results Panel",
    description: "Designed responsive desktop window using Tkinter and ttk with modern dark slate theme, responsive column weights, and metric tiles.",
    filesModified: ["main.py"],
    status: "Completed",
  },
  {
    number: 4,
    title: "Phase 4: Weather Icons & Dynamic Unit Toggle",
    description: "Integrated OpenWeatherMap official icons with Pillow rendering, in-memory caching, canvas fallback, and instant °C / °F toggle without re-fetching.",
    filesModified: ["main.py", "weather_api.py"],
    status: "Completed",
  },
  {
    number: 5,
    title: "Phase 5: Next 6–9 Hours Upcoming Forecast",
    description: "Honest implementation of OpenWeatherMap's free tier 3-hour slices, extracting the next 3 intervals with clear timestamp labels.",
    filesModified: ["weather_utils.py", "main.py"],
    status: "Completed",
  },
  {
    number: 6,
    title: "Phase 6: 5-Day Daily Aggregated Forecast",
    description: "Grouped 3-hour forecast intervals by calendar date to compute observed minimum and maximum temperatures and representative midday conditions.",
    filesModified: ["weather_utils.py", "main.py"],
    status: "Completed",
  },
  {
    number: 7,
    title: "Phase 7: Optional IP-Based Geolocation",
    description: "Added user-initiated location detection via ipinfo.io, respecting privacy with strict opt-in execution.",
    filesModified: ["weather_api.py", "main.py"],
    status: "Completed",
  },
  {
    number: 8,
    title: "Phase 8: 21 Automated Tests, README & GitHub Packaging",
    description: "Created comprehensive unit test suite in tests/, .env.example, .gitignore, requirements.txt, and complete README documentation.",
    filesModified: ["tests/test_weather_utils.py", "tests/test_weather_api.py", "README.md", "requirements.txt", ".gitignore", ".env.example"],
    status: "Completed",
  },
];

const INITIAL_CHECKLIST = [
  { id: 1, text: "Enter standard city name (e.g. 'Pune') and verify current temp, condition, humidity & wind.", checked: true },
  { id: 2, text: "Enter international city (e.g. 'London, UK' or 'Tokyo') and confirm timestamp & country badge.", checked: true },
  { id: 3, text: "Enter postal code (e.g. '411001' or '90210,US') and verify API builds query correctly.", checked: true },
  { id: 4, text: "Click 'Get Weather' with empty input and verify visible in-GUI error banner.", checked: true },
  { id: 5, text: "Enter 1 character location and verify validation rejects it.", checked: true },
  { id: 6, text: "Enter fake city (e.g. 'NonExistent999') and verify HTTP 404 error banner.", checked: true },
  { id: 7, text: "Switch unit to °F and confirm all temperatures update instantly without network lag.", checked: true },
  { id: 8, text: "Switch unit back to °C and confirm consistency across hero, 3h, and 5-day cards.", checked: true },
  { id: 9, text: "Check upcoming forecast entries are labeled by actual time (e.g. '03:00 PM', '06:00 PM').", checked: true },
  { id: 10, text: "Verify 5-day daily forecast displays min and max temperatures for each calendar date.", checked: true },
  { id: 11, text: "Click 'Detect My Location' and verify IP lookup resolves without freezing the UI.", checked: true },
  { id: 12, text: "Run 'python -m unittest discover -s tests -v' and confirm all 21 unit tests pass.", checked: true },
  { id: 13, text: "Check .gitignore ensures .env credentials will never be committed to git repository.", checked: true },
];

export const PhasesTracker: React.FC = () => {
  const [checklist, setChecklist] = useState(INITIAL_CHECKLIST);

  const toggleCheck = (id: number) => {
    setChecklist((prev) =>
      prev.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item))
    );
  };

  const completedCount = checklist.filter((item) => item.checked).length;

  return (
    <div className="w-full max-w-6xl flex flex-col gap-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5 mb-1">
            <CheckCircle2 className="w-4 h-4" />
            Project Lifecycle & Verification Checklist
          </span>
          <h2 className="text-xl font-extrabold text-slate-100">
            OIBSIP Task 4 Development Phases (1 to 8)
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Tracks the end-to-end implementation from foundational API networking to the complete Tkinter desktop GUI and test validation.
          </p>
        </div>

        <div className="px-4 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-right">
          <span className="text-xs font-bold text-emerald-400 block">
            All 8 Phases Completed
          </span>
          <span className="text-[11px] text-slate-400 font-mono">
            Checklist: {completedCount} / {checklist.length} Passed
          </span>
        </div>
      </div>

      {/* 8 Phases Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {PHASES.map((p) => (
          <div
            key={p.number}
            className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-bold text-sky-400 font-mono">
                  Phase {p.number}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> {p.status}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-100">
                {p.title}
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                {p.description}
              </p>
            </div>

            <div className="mt-3 pt-2.5 border-t border-slate-800 flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] text-slate-500 mr-1">Files:</span>
              {p.filesModified.map((f) => (
                <span
                  key={f}
                  className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 text-slate-300 border border-slate-800"
                >
                  {f}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Interactive Manual Testing Checklist (Section 18) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <ListChecks className="w-4 h-4 text-sky-400" />
              Manual QA Testing Checklist for Internship Submission
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Interactive test rubric matching the internship task specification:
            </p>
          </div>

          <button
            onClick={() => setChecklist((prev) => prev.map((item) => ({ ...item, checked: true })))}
            className="text-xs text-sky-400 hover:text-sky-300 underline font-medium"
          >
            Mark All Verified
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          {checklist.map((item) => (
            <div
              key={item.id}
              onClick={() => toggleCheck(item.id)}
              className={`p-3 rounded-xl border cursor-pointer select-none transition flex items-start gap-3 ${
                item.checked
                  ? "bg-slate-950/60 border-emerald-500/30 text-slate-200"
                  : "bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700"
              }`}
            >
              <div className="mt-0.5 shrink-0">
                {item.checked ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600" />
                )}
              </div>
              <span className={`text-xs leading-relaxed ${item.checked ? "text-slate-200 font-medium" : "text-slate-400"}`}>
                {item.text}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
