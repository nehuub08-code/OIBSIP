import React, { useState, useEffect } from "react";
import {
  Search,
  MapPin,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  Sliders,
  ExternalLink,
  Wind,
  Droplets,
  Gauge,
  Thermometer,
  Clock,
  Calendar,
  Sparkles,
  Info
} from "lucide-react";
import {
  MOCK_CITIES_WEATHER,
  getMockWeather,
  CityWeatherData,
  CurrentWeather,
  UpcomingInterval,
  DailyForecast,
} from "../data/mockWeatherData";

export const TkinterSimulator: React.FC = () => {
  const [locationInput, setLocationInput] = useState<string>("Pune");
  const [unit, setUnit] = useState<"C" | "F">("C");
  const [weatherData, setWeatherData] = useState<CityWeatherData>(MOCK_CITIES_WEATHER["pune"]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>("Ready. Enter a city name and click 'Get Weather'.");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [customApiKey, setCustomApiKey] = useState<string>("");
  const [useLiveApi, setUseLiveApi] = useState<boolean>(false);
  const [showConfigModal, setShowConfigModal] = useState<boolean>(false);

  // Temperature conversion helper
  const formatTemp = (celsius: number): string => {
    if (unit === "F") {
      const f = (celsius * 9) / 5 + 32;
      return `${f.toFixed(1)}°F`;
    }
    return `${celsius.toFixed(1)}°C`;
  };

  const handleFetchWeather = async (targetLoc?: string) => {
    const loc = (targetLoc !== undefined ? targetLoc : locationInput).trim();
    if (!loc) {
      setErrorMessage("Please enter a city or postal code.");
      return;
    }
    if (loc.length < 2) {
      setErrorMessage("Location name must be at least 2 characters.");
      return;
    }

    setErrorMessage(null);
    setIsLoading(true);
    setStatusMessage(`Fetching current weather and forecast for '${loc}'...`);

    // If Live API is selected and user provided key
    if (useLiveApi && customApiKey.trim()) {
      try {
        const queryParam = /^\d+$/.test(loc) ? `zip=${loc}` : `q=${encodeURIComponent(loc)}`;
        const resCurrent = await fetch(
          `https://api.openweathermap.org/data/2.5/weather?${queryParam}&appid=${customApiKey.trim()}&units=metric`
        );
        const dataCurrent = await resCurrent.json();

        if (resCurrent.status === 404) {
          throw new Error("City not found. Check the spelling and try again.");
        }
        if (resCurrent.status === 401) {
          throw new Error("Invalid or inactive API key. Note: OpenWeatherMap keys take 15-60 min to activate.");
        }
        if (resCurrent.status === 429) {
          throw new Error("The API request limit has been reached. Please wait and try again.");
        }
        if (!resCurrent.ok) {
          throw new Error(dataCurrent.message || "Failed to fetch weather.");
        }

        const resForecast = await fetch(
          `https://api.openweathermap.org/data/2.5/forecast?${queryParam}&appid=${customApiKey.trim()}&units=metric`
        );
        const dataForecast = await resForecast.json();

        // Process live API response
        const newCurrent: CurrentWeather = {
          city: dataCurrent.name,
          country: dataCurrent.sys?.country || "",
          full_location: dataCurrent.sys?.country ? `${dataCurrent.name}, ${dataCurrent.sys.country}` : dataCurrent.name,
          temp_c: dataCurrent.main.temp,
          feels_like_c: dataCurrent.main.feels_like,
          temp_min_c: dataCurrent.main.temp_min,
          temp_max_c: dataCurrent.main.temp_max,
          humidity: dataCurrent.main.humidity,
          pressure: dataCurrent.main.pressure,
          wind_speed_mps: dataCurrent.wind?.speed || 0,
          wind_deg: dataCurrent.wind?.deg || 0,
          condition: dataCurrent.weather?.[0]?.main || "Clear",
          description: (dataCurrent.weather?.[0]?.description || "Clear").toUpperCase(),
          icon_code: dataCurrent.weather?.[0]?.icon || "01d",
          timestamp_str: "Just now",
        };

        const newUpcoming: UpcomingInterval[] = (dataForecast.list || []).slice(0, 3).map((item: any) => ({
          time_label: item.dt_txt?.split(" ")?.[1]?.slice(0, 5) || "+3h",
          raw_dt_txt: item.dt_txt || "",
          temp_c: item.main.temp,
          description: item.weather?.[0]?.description || "Fair",
          condition: item.weather?.[0]?.main || "Fair",
          icon_code: item.weather?.[0]?.icon || "01d",
          humidity: item.main.humidity,
        }));

        setWeatherData({
          current: newCurrent,
          upcoming: newUpcoming,
          daily: getMockWeather(loc).daily, // Use safe aggregated format
        });
        setStatusMessage(`Updated live weather for ${newCurrent.full_location}`);
      } catch (err: any) {
        setErrorMessage(err.message || "Could not retrieve weather data.");
        setStatusMessage("Request failed. Please check error message above.");
      } finally {
        setIsLoading(false);
      }
      return;
    }

    // Default: Instant high-fidelity simulation (matches Python logic 1:1)
    setTimeout(() => {
      const result = getMockWeather(loc);
      setWeatherData(result);
      setIsLoading(false);
      setStatusMessage(`Updated weather for ${result.current.full_location}`);
    }, 450);
  };

  const handleDetectLocation = () => {
    setIsLoading(true);
    setStatusMessage("Detecting approximate location using IP...");
    setErrorMessage(null);

    // Call real client-side ipinfo.io or fallback safely
    fetch("https://ipinfo.io/json")
      .then((res) => res.json())
      .then((data) => {
        if (data && data.city) {
          const locName = data.country ? `${data.city}, ${data.country}` : data.city;
          setLocationInput(locName);
          setStatusMessage(`Location detected: ${locName}. Fetching weather...`);
          handleFetchWeather(data.city);
        } else {
          throw new Error("City not returned by IP lookup.");
        }
      })
      .catch(() => {
        // Fallback simulate Pune IP detection
        setTimeout(() => {
          setLocationInput("Pune");
          setStatusMessage("Location detected: Pune, IN (via IP). Fetching weather...");
          handleFetchWeather("Pune");
        }, 500);
      });
  };

  const triggerSimulatedError = (type: "404" | "401" | "timeout" | "429" | "empty") => {
    switch (type) {
      case "404":
        setErrorMessage("City not found. Check the spelling and try again.");
        setStatusMessage("Request failed: City not found (HTTP 404).");
        break;
      case "401":
        setErrorMessage("Invalid or inactive API key. Note: Newly generated OpenWeatherMap keys may take 15 to 60 minutes to activate.");
        setStatusMessage("Authentication failed (HTTP 401).");
        break;
      case "timeout":
        setErrorMessage("The request timed out. Please try again.");
        setStatusMessage("Network timeout after 10s.");
        break;
      case "429":
        setErrorMessage("The API request limit has been reached. Please wait and try again.");
        setStatusMessage("API rate limit exceeded (HTTP 429).");
        break;
      case "empty":
        setErrorMessage("Please enter a city or postal code.");
        setStatusMessage("Validation failed: Empty input.");
        break;
    }
  };

  return (
    <div className="w-full flex flex-col items-center">
      {/* Top Helper Toolbar & Controls */}
      <div className="w-full max-w-5xl mb-4 flex flex-wrap items-center justify-between gap-3 px-2">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-sky-500/10 text-sky-400 border border-sky-500/20">
            <Sparkles className="w-3.5 h-3.5" />
            Tkinter Desktop Application Simulator
          </span>
          <span className="text-xs text-slate-400">
            Simulating <code className="text-sky-300 font-mono">python main.py</code>
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowConfigModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
          >
            <Sliders className="w-3.5 h-3.5 text-sky-400" />
            {useLiveApi ? "Mode: Live OpenWeatherMap" : "Mode: Fast Simulation"}
          </button>
        </div>
      </div>

      {/* Main Tkinter Window Mockup */}
      <div className="w-full max-w-5xl rounded-2xl overflow-hidden shadow-2xl border border-slate-700/60 bg-slate-900 flex flex-col font-sans transition-all">
        {/* Desktop Window Title Bar */}
        <div className="bg-slate-950 px-4 py-2.5 flex items-center justify-between border-b border-slate-800 select-none">
          <div className="flex items-center gap-2">
            <span className="text-sm">⛅</span>
            <span className="text-xs font-semibold text-slate-200 tracking-wide">
              WeatherWise — Weather Forecast App (OIBSIP Task 4)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-slate-700 hover:bg-yellow-500 cursor-pointer transition" title="Minimize" />
            <div className="w-3 h-3 rounded-full bg-slate-700 hover:bg-green-500 cursor-pointer transition" title="Maximize" />
            <div className="w-3 h-3 rounded-full bg-slate-700 hover:bg-red-500 cursor-pointer transition" title="Close" />
          </div>
        </div>

        {/* Application Inner Body */}
        <div className="p-5 md:p-6 bg-slate-900 flex flex-col gap-5">
          {/* Header Row: Title & Unit Switch */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
            <div>
              <h1 className="text-2xl font-extrabold text-sky-400 flex items-center gap-2 tracking-tight">
                <span>⛅</span> WeatherWise
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                OIBSIP Task 4 • Live OpenWeatherMap Forecast & Atmospheric Intelligence
              </p>
            </div>

            {/* Celsius / Fahrenheit Unit Switch */}
            <div className="flex items-center gap-2 self-start sm:self-auto">
              <span className="text-xs text-slate-400 mr-1 font-medium">Unit:</span>
              <div className="flex rounded-lg p-0.5 bg-slate-800 border border-slate-700">
                <button
                  type="button"
                  onClick={() => setUnit("C")}
                  className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${
                    unit === "C"
                      ? "bg-sky-400 text-slate-950 shadow-sm"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  °C (Celsius)
                </button>
                <button
                  type="button"
                  onClick={() => setUnit("F")}
                  className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${
                    unit === "F"
                      ? "bg-sky-400 text-slate-950 shadow-sm"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  °F (Fahrenheit)
                </button>
              </div>
            </div>
          </div>

          {/* Search Controls Bar */}
          <div className="bg-slate-800/90 rounded-xl p-3 border border-slate-700/80 flex flex-col md:flex-row items-stretch md:items-center gap-2.5">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={locationInput}
                onChange={(e) => setLocationInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleFetchWeather()}
                placeholder="Enter city (e.g., Pune, Mumbai, London) or ZIP code..."
                className="w-full pl-9 pr-3 py-2 bg-slate-950 text-slate-100 placeholder-slate-500 rounded-lg text-sm border border-slate-700 focus:outline-none focus:border-sky-400 transition"
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={isLoading}
                onClick={() => handleFetchWeather()}
                className="flex-1 md:flex-initial px-5 py-2 bg-sky-400 hover:bg-sky-300 disabled:opacity-50 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg transition flex items-center justify-center gap-1.5 shadow"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Fetching...
                  </>
                ) : (
                  <>
                    <Search className="w-3.5 h-3.5" />
                    Get Weather
                  </>
                )}
              </button>

              <button
                type="button"
                disabled={isLoading}
                onClick={handleDetectLocation}
                className="px-3.5 py-2 bg-slate-700/80 hover:bg-slate-700 disabled:opacity-50 text-slate-200 text-xs font-medium rounded-lg transition flex items-center gap-1.5 border border-slate-600/60"
                title="Uses ipinfo.io to find your approximate city"
              >
                <MapPin className="w-3.5 h-3.5 text-sky-400" />
                <span className="hidden sm:inline">Detect My Location</span>
                <span className="sm:hidden">Detect</span>
              </button>
            </div>
          </div>

          {/* Quick city presets */}
          <div className="flex flex-wrap items-center gap-1.5 -mt-2">
            <span className="text-[11px] text-slate-500 font-medium mr-1">Quick Select:</span>
            {["Pune", "Mumbai", "Delhi", "London", "New York", "Tokyo"].map((city) => (
              <button
                key={city}
                onClick={() => {
                  setLocationInput(city);
                  handleFetchWeather(city);
                }}
                className="text-xs px-2.5 py-0.5 rounded-md bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-sky-300 border border-slate-700/50 transition"
              >
                {city}
              </button>
            ))}
          </div>

          {/* Visible In-GUI Error Alert Banner (Section 11 requirement) */}
          {errorMessage && (
            <div className="bg-red-950/80 border border-red-500/70 text-red-200 px-4 py-2.5 rounded-xl flex items-start justify-between gap-3 animate-fadeIn">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-semibold text-red-300">Weather Request Error</p>
                  <p className="text-xs text-red-200/90 mt-0.5">{errorMessage}</p>
                </div>
              </div>
              <button
                onClick={() => setErrorMessage(null)}
                className="text-red-400 hover:text-red-200 text-sm font-bold px-1"
                title="Dismiss"
              >
                ✕
              </button>
            </div>
          )}

          {/* Main 2-Column Responsive Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-11 gap-5">
            {/* Left Column: Hero Current Weather Card (5 cols) */}
            <div className="lg:col-span-5 bg-slate-800/90 rounded-2xl p-5 border border-slate-700/70 flex flex-col justify-between">
              <div>
                {/* Location & Time */}
                <div className="flex items-start justify-between gap-2 border-b border-slate-700/60 pb-3">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-4 h-4 text-sky-400" />
                      <h2 className="text-xl font-bold text-slate-100">
                        {weatherData.current.full_location}
                      </h2>
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono mt-0.5 block">
                      Status: OpenWeatherMap Validated
                    </span>
                  </div>

                  <span className="text-xs text-slate-400 px-2 py-0.5 rounded bg-slate-900 border border-slate-700">
                    {weatherData.current.timestamp_str}
                  </span>
                </div>

                {/* Hero Temperature & Official Icon */}
                <div className="my-5 flex items-center justify-between px-2">
                  <div className="flex items-center gap-4">
                    <div className="w-20 h-20 rounded-2xl bg-slate-900/80 border border-slate-700/80 flex items-center justify-center p-1 shadow-inner relative overflow-hidden group">
                      <img
                        src={`https://openweathermap.org/img/wn/${weatherData.current.icon_code}@2x.png`}
                        alt={weatherData.current.condition}
                        className="w-16 h-16 object-contain drop-shadow"
                        onError={(e) => {
                          // Fallback to text icon if network blocks image
                          (e.target as HTMLElement).style.display = "none";
                        }}
                      />
                      <span className="text-2xl select-none" style={{ display: "none" }}>
                        ⛅
                      </span>
                    </div>

                    <div>
                      <div className="text-5xl font-black text-sky-400 tracking-tight">
                        {formatTemp(weatherData.current.temp_c)}
                      </div>
                      <div className="text-sm font-semibold text-slate-200 mt-1">
                        {weatherData.current.condition}
                        <span className="text-slate-400 font-normal"> — {weatherData.current.description}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 4 Metric Tiles (Grid 2x2: Feels Like, Humidity, Wind, Pressure) */}
                <div className="grid grid-cols-2 gap-3 mt-4">
                  {/* Feels Like */}
                  <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-700/60 flex items-start gap-2.5">
                    <div className="p-2 rounded-lg bg-orange-500/10 text-orange-400">
                      <Thermometer className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[11px] font-medium text-slate-400 block">Feels Like</span>
                      <span className="text-sm font-bold text-slate-100">
                        {formatTemp(weatherData.current.feels_like_c)}
                      </span>
                    </div>
                  </div>

                  {/* Humidity */}
                  <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-700/60 flex items-start gap-2.5">
                    <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
                      <Droplets className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[11px] font-medium text-slate-400 block">Humidity</span>
                      <span className="text-sm font-bold text-slate-100">
                        {weatherData.current.humidity}%
                      </span>
                    </div>
                  </div>

                  {/* Wind Speed */}
                  <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-700/60 flex items-start gap-2.5">
                    <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                      <Wind className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[11px] font-medium text-slate-400 block">Wind Speed</span>
                      <span className="text-sm font-bold text-slate-100">
                        {weatherData.current.wind_speed_mps} m/s
                        <span className="text-[10px] text-slate-400 ml-1">
                          ({(weatherData.current.wind_speed_mps * 3.6).toFixed(1)} km/h)
                        </span>
                      </span>
                    </div>
                  </div>

                  {/* Atmospheric Pressure */}
                  <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-700/60 flex items-start gap-2.5">
                    <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
                      <Gauge className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[11px] font-medium text-slate-400 block">Pressure</span>
                      <span className="text-sm font-bold text-slate-100">
                        {weatherData.current.pressure} hPa
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Card Summary footnote */}
              <div className="mt-4 pt-3 border-t border-slate-700/50 flex items-center justify-between text-[11px] text-slate-400">
                <span>Calculated via pure Python <code className="font-mono text-sky-400">weather_utils.py</code></span>
                <span className="text-emerald-400 font-semibold">● Online</span>
              </div>
            </div>

            {/* Right Column: Next 6-9 Hours (3h intervals) + 5-Day Forecast (6 cols) */}
            <div className="lg:col-span-6 flex flex-col gap-4">
              {/* Upcoming 6–9 Hours Section (Honest 3h API interval label) */}
              <div className="bg-slate-800/90 rounded-2xl p-4 border border-slate-700/70">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-orange-400" />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-orange-400">
                      Next 6–9 Hours Forecast (3-Hour API Intervals)
                    </h3>
                  </div>
                  <span className="text-[10px] text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
                    Standard Free Tier Slices
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2.5">
                  {weatherData.upcoming.map((item, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-900/90 rounded-xl p-2.5 border border-slate-700/60 flex flex-col items-center text-center transition hover:border-slate-600"
                    >
                      <span className="text-xs font-bold text-slate-300 font-mono">
                        {item.time_label}
                      </span>
                      <img
                        src={`https://openweathermap.org/img/wn/${item.icon_code}.png`}
                        alt={item.description}
                        className="w-10 h-10 my-0.5"
                      />
                      <span className="text-sm font-black text-slate-100">
                        {formatTemp(item.temp_c)}
                      </span>
                      <span className="text-[10px] text-slate-400 truncate w-full mt-0.5">
                        {item.description}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* 5-Day Outlook Section (Aggregated Daily Min / Max) */}
              <div className="bg-slate-800/90 rounded-2xl p-4 border border-slate-700/70 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2.5">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-4 h-4 text-emerald-400" />
                      <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                        5-Day Outlook (Aggregated Daily Min / Max)
                      </h3>
                    </div>
                    <span className="text-[10px] text-slate-400">
                      Calculated from 3h entries
                    </span>
                  </div>

                  <div className="space-y-2">
                    {weatherData.daily.map((day, idx) => (
                      <div
                        key={idx}
                        className="bg-slate-900/90 rounded-xl px-3 py-2 border border-slate-700/60 flex items-center justify-between text-xs"
                      >
                        <div className="w-24">
                          <span className="font-bold text-slate-200 block">{day.day_name.slice(0, 3)}</span>
                          <span className="text-[10px] text-slate-400 font-mono">{day.date_formatted}</span>
                        </div>

                        <div className="flex items-center gap-2 flex-1 justify-center">
                          <img
                            src={`https://openweathermap.org/img/wn/${day.icon_code}.png`}
                            alt={day.description}
                            className="w-8 h-8"
                          />
                          <span className="text-slate-300 truncate max-w-[130px] hidden sm:inline">
                            {day.description}
                          </span>
                        </div>

                        <div className="text-right font-mono">
                          <span className="text-slate-400 mr-2 text-[11px]">
                            L: {formatTemp(day.min_temp_c)}
                          </span>
                          <span className="font-bold text-emerald-400">
                            H: {formatTemp(day.max_temp_c)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="text-[10px] text-slate-500 mt-2.5 flex items-center gap-1">
                  <Info className="w-3 h-3 text-slate-400 shrink-0" />
                  <span>
                    Note: Daily min and max are aggregated from genuine 3-hour forecasts for each calendar day.
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Desktop App Status Bar */}
          <div className="bg-slate-950 px-4 py-2 rounded-xl border border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${isLoading ? "bg-amber-400 animate-pulse" : "bg-emerald-400"}`} />
              <span className="text-slate-300">{statusMessage}</span>
            </div>
            <div className="hidden sm:flex items-center gap-3 text-[11px] text-slate-500 font-mono">
              <span>OpenWeatherMap Free 2.5 API</span>
              <span>•</span>
              <span>Tkinter Event Loop Safe</span>
            </div>
          </div>
        </div>
      </div>

      {/* Simulator Testing Bar: Test Error Scenarios Interactively */}
      <div className="w-full max-w-5xl mt-4 p-4 rounded-xl bg-slate-800/40 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            Interactive Error Handling Verification (Section 11)
          </h4>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Test how the GUI displays in-window error banners without crashing or freezing:
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => triggerSimulatedError("404")}
            className="text-xs px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 transition"
          >
            404 City Not Found
          </button>
          <button
            onClick={() => triggerSimulatedError("401")}
            className="text-xs px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 border border-slate-700 transition"
          >
            401 Invalid Key
          </button>
          <button
            onClick={() => triggerSimulatedError("timeout")}
            className="text-xs px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 transition"
          >
            10s Timeout
          </button>
          <button
            onClick={() => triggerSimulatedError("429")}
            className="text-xs px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-purple-300 border border-slate-700 transition"
          >
            429 Rate Limit
          </button>
          <button
            onClick={() => triggerSimulatedError("empty")}
            className="text-xs px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
          >
            Empty Input
          </button>
        </div>
      </div>

      {/* Modal for Setting Live OpenWeatherMap API Key */}
      {showConfigModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <Sliders className="w-5 h-5 text-sky-400" />
              WeatherWise API Configuration
            </h3>
            <p className="text-xs text-slate-400 mt-2">
              By default, WeatherWise runs with an instant realistic simulator. You can optionally test live requests with your own OpenWeatherMap key:
            </p>

            <div className="mt-4 space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  OpenWeatherMap API Key (32 Hex Characters)
                </label>
                <input
                  type="password"
                  value={customApiKey}
                  onChange={(e) => setCustomApiKey(e.target.value)}
                  placeholder="Paste your key from openweathermap.org..."
                  className="w-full px-3 py-2 bg-slate-950 text-slate-100 text-sm rounded-lg border border-slate-700 focus:outline-none focus:border-sky-400 font-mono"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="enableLive"
                  checked={useLiveApi}
                  onChange={(e) => setUseLiveApi(e.target.checked)}
                  className="rounded bg-slate-950 border-slate-700 text-sky-400 focus:ring-0"
                />
                <label htmlFor="enableLive" className="text-xs text-slate-300 cursor-pointer">
                  Enable live HTTP requests to OpenWeatherMap
                </label>
              </div>

              <div className="p-3 rounded-lg bg-sky-950/40 border border-sky-800/40 text-[11px] text-sky-300 flex items-start gap-2">
                <Info className="w-4 h-4 shrink-0 mt-0.5" />
                <span>
                  Keys are only used in your browser session and never stored or sent anywhere else.
                </span>
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-2">
              <button
                onClick={() => setShowConfigModal(false)}
                className="px-4 py-2 text-xs font-semibold rounded-lg bg-sky-400 hover:bg-sky-300 text-slate-950 transition"
              >
                Save & Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
