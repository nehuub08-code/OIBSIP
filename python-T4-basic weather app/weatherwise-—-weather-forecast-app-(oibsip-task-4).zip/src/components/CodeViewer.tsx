import React, { useState } from "react";
import {
  FileCode,
  Copy,
  Check,
  Download,
  FolderArchive,
  Terminal,
  FileText,
  Lock,
  GitBranch,
} from "lucide-react";
import JSZip from "jszip";
import { PROJECT_FILES, ProjectFile } from "../data/projectFiles";

export const CodeViewer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<ProjectFile>(PROJECT_FILES[0]);
  const [copied, setCopied] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSingle = () => {
    const blob = new Blob([selectedFile.content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = selectedFile.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();
      const rootFolder = zip.folder("OIBSIP/PythonProgramming/Task4_Weather_App");
      const testsFolder = rootFolder?.folder("tests");

      for (const file of PROJECT_FILES) {
        if (file.name.startsWith("tests/")) {
          const testName = file.name.replace("tests/", "");
          testsFolder?.file(testName, file.content);
        } else {
          rootFolder?.file(file.name, file.content);
        }
      }

      const content = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(content);
      const link = document.createElement("a");
      link.href = url;
      link.download = "WeatherWise_OIBSIP_Task4.zip";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("ZIP generation error:", err);
    } finally {
      setIsZipping(false);
    }
  };

  const getFileIcon = (name: string) => {
    if (name.endsWith(".py")) return <FileCode className="w-4 h-4 text-sky-400" />;
    if (name.includes("env")) return <Lock className="w-4 h-4 text-amber-400" />;
    if (name.includes("git")) return <GitBranch className="w-4 h-4 text-orange-400" />;
    if (name.endsWith(".txt")) return <FileText className="w-4 h-4 text-emerald-400" />;
    return <FileText className="w-4 h-4 text-slate-400" />;
  };

  const lines = selectedFile.content.split("\n");

  return (
    <div className="w-full max-w-6xl flex flex-col gap-4">
      {/* Top action header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-900 p-4 rounded-xl border border-slate-800">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Terminal className="w-4 h-4 text-sky-400" />
            Python Project Source Code Explorer
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Path: <code className="font-mono text-sky-300">OIBSIP/PythonProgramming/Task4_Weather_App/</code>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-lg transition shadow"
          >
            <FolderArchive className="w-3.5 h-3.5" />
            {isZipping ? "Packaging ZIP..." : "Download Full Project ZIP"}
          </button>
        </div>
      </div>

      {/* Main Code View Area */}
      <div className="grid grid-cols-1 md:grid-cols-12 rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
        {/* Left Sidebar: File Tree */}
        <div className="md:col-span-3 bg-slate-900/90 border-r border-slate-800 p-3 flex flex-col gap-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-2 py-1 mb-1">
            Project Files ({PROJECT_FILES.length})
          </span>

          {PROJECT_FILES.map((file) => {
            const isSelected = selectedFile.name === file.name;
            return (
              <button
                key={file.name}
                onClick={() => setSelectedFile(file)}
                className={`w-full text-left px-2.5 py-2 rounded-lg text-xs font-mono flex items-center gap-2 transition ${
                  isSelected
                    ? "bg-sky-500/15 text-sky-300 border border-sky-500/30 font-semibold"
                    : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
                }`}
              >
                {getFileIcon(file.name)}
                <span className="truncate">{file.name}</span>
              </button>
            );
          })}

          <div className="mt-4 pt-3 border-t border-slate-800 px-2 text-[11px] text-slate-500">
            <span>All modules structured for Python 3.10+ with standard PEP 8 compliance.</span>
          </div>
        </div>

        {/* Right Area: Code Content & Metadata */}
        <div className="md:col-span-9 flex flex-col bg-slate-950">
          {/* File Header */}
          <div className="px-4 py-3 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                {getFileIcon(selectedFile.name)}
                <span className="font-mono text-xs font-bold text-slate-200">
                  {selectedFile.name}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                  {lines.length} lines
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1 max-w-xl">
                {selectedFile.description}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition border border-slate-700"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>

              <button
                onClick={handleDownloadSingle}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition border border-slate-700"
                title="Download this file"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Save</span>
              </button>
            </div>
          </div>

          {/* Code Viewer with Line Numbers */}
          <div className="p-4 overflow-x-auto max-h-[600px] font-mono text-xs text-slate-300 leading-relaxed select-text">
            <pre className="flex">
              {/* Line numbers column */}
              <div className="select-none text-slate-600 text-right pr-4 border-r border-slate-800/80 mr-4 shrink-0">
                {lines.map((_, i) => (
                  <div key={i}>{i + 1}</div>
                ))}
              </div>
              {/* Actual code content */}
              <code className="text-slate-200 whitespace-pre">
                {selectedFile.content}
              </code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
