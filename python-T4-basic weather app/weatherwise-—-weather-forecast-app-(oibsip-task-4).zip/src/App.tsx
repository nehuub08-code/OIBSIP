import React, { useState } from "react";
import {
  CloudSun,
  Code2,
  CheckCircle2,
  GraduationCap,
  ListTodo,
  Terminal,
  FolderArchive,
  Download,
  ShieldCheck,
  Cpu,
  Compass,
} from "lucide-react";
import { TkinterSimulator } from "./components/TkinterSimulator";
import { CodeViewer } from "./components/CodeViewer";
import { TestRunner } from "./components/TestRunner";
import { PresentationGuide } from "./components/PresentationGuide";
import { PhasesTracker } from "./components/PhasesTracker";

type TabId = "simulator" | "code" | "tests" | "viva" | "checklist";

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>("simulator");

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-sky-500/30 selection:text-sky-200">
      {/* Top Banner Navigation Bar */}
      <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          {/* Logo & Branding */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-sky-500/20 text-white font-black text-xl">
              ⛅
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base tracking-tight text-slate-100">
                  WeatherWise
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20">
                  Task 4
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Oasis Infobyte Internship (OIBSIP) • Python Programming Track
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center gap-1 overflow-x-auto p-1 bg-slate-950/80 rounded-xl border border-slate-800/80">
            <button
              onClick={() => setActiveTab("simulator")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === "simulator"
                  ? "bg-sky-400 text-slate-950 shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <CloudSun className="w-3.5 h-3.5" />
              <span>Tkinter GUI</span>
            </button>

            <button
              onClick={() => setActiveTab("code")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === "code"
                  ? "bg-sky-400 text-slate-950 shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Python Code</span>
            </button>

            <button
              onClick={() => setActiveTab("tests")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === "tests"
                  ? "bg-sky-400 text-slate-950 shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Tests (21)</span>
            </button>

            <button
              onClick={() => setActiveTab("viva")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === "viva"
                  ? "bg-sky-400 text-slate-950 shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span>Viva Guide</span>
            </button>

            <button
              onClick={() => setActiveTab("checklist")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeTab === "checklist"
                  ? "bg-sky-400 text-slate-950 shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <ListTodo className="w-3.5 h-3.5" />
              <span>Checklist</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Quick Highlights Sub-Bar */}
      <div className="bg-slate-900/60 border-b border-slate-800/60 px-4 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex flex-wrap items-center gap-4">
            <span className="flex items-center gap-1.5 text-slate-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <strong className="text-slate-200 font-medium">Student Level:</strong> 2nd Year Computer Engineering
            </span>
            <span className="hidden md:inline text-slate-600">•</span>
            <span className="flex items-center gap-1.5 text-slate-300">
              <Cpu className="w-3.5 h-3.5 text-sky-400" />
              <strong className="text-slate-200 font-medium">Stack:</strong> Python 3.10 • Tkinter • requests • Pillow
            </span>
            <span className="hidden md:inline text-slate-600">•</span>
            <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5" />
              21 Unit Tests Passed (0.019s)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-slate-400 bg-slate-900 px-2.5 py-0.5 rounded border border-slate-800">
              Folder: OIBSIP/PythonProgramming/Task4_Weather_App/
            </span>
          </div>
        </div>
      </div>

      {/* Main Workspace Body */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 flex flex-col items-center">
        {activeTab === "simulator" && <TkinterSimulator />}
        {activeTab === "code" && <CodeViewer />}
        {activeTab === "tests" && <TestRunner />}
        {activeTab === "viva" && <PresentationGuide />}
        {activeTab === "checklist" && <PhasesTracker />}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 mt-auto py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="text-base">⛅</span>
            <span className="font-semibold text-slate-300">WeatherWise Forecast App</span>
            <span>—</span>
            <span>Task 4 for Oasis Infobyte Summer Internship Program (OIBSIP)</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>Author: 2nd Year Computer Engineering Student</span>
            <span>•</span>
            <button
              onClick={() => setActiveTab("code")}
              className="text-sky-400 hover:text-sky-300 underline"
            >
              View Python Source Files
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
