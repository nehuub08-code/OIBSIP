import React, { useState, useMemo } from 'react';
import {
  Flower2,
  Sliders,
  BarChart3,
  Database,
  BookOpen,
  Github,
  Terminal,
  Download,
  CheckCircle2,
  ChevronRight,
  Layers,
  Search,
  Sparkles,
  Camera,
  FileCode2,
  CheckSquare,
  Maximize2,
  Info,
  Scale,
  RefreshCw,
  Copy,
  Check
} from 'lucide-react';
import {
  IRIS_DATA,
  SPECIES_PROFILES,
  predictSpecies,
  IrisSample
} from './irisData';
import dataSummary from './data_summary.json';

type ActiveTab = 'predictor' | 'eda' | 'visualizations' | 'models' | 'notebook' | 'submission';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('predictor');

  // Interactive Predictor State
  const [sepalLength, setSepalLength] = useState<number>(5.8);
  const [sepalWidth, setSepalWidth] = useState<number>(3.0);
  const [petalLength, setPetalLength] = useState<number>(4.2);
  const [petalWidth, setPetalWidth] = useState<number>(1.3);

  // EDA search and filter state
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [speciesFilter, setSpeciesFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<keyof IrisSample>('id');
  const [sortAsc, setSortAsc] = useState<boolean>(true);

  // Active visualization modal state
  const [activeImageModal, setActiveImageModal] = useState<string | null>(null);

  // Code copy feedback
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);

  // Prediction calculation
  const prediction = useMemo(() => {
    return predictSpecies(sepalLength, sepalWidth, petalLength, petalWidth);
  }, [sepalLength, sepalWidth, petalLength, petalWidth]);

  const activeProfile = SPECIES_PROFILES[prediction.species];

  // Presets
  const applyPreset = (preset: 'setosa' | 'versicolor' | 'virginica' | 'borderline') => {
    if (preset === 'setosa') {
      setSepalLength(5.1);
      setSepalWidth(3.5);
      setPetalLength(1.4);
      setPetalWidth(0.2);
    } else if (preset === 'versicolor') {
      setSepalLength(5.9);
      setSepalWidth(2.8);
      setPetalLength(4.3);
      setPetalWidth(1.3);
    } else if (preset === 'virginica') {
      setSepalLength(6.6);
      setSepalWidth(3.0);
      setPetalLength(5.6);
      setPetalWidth(2.1);
    } else if (preset === 'borderline') {
      setSepalLength(6.0);
      setSepalWidth(2.8);
      setPetalLength(4.9);
      setPetalWidth(1.7);
    }
  };

  // Filtered Iris dataset
  const filteredData = useMemo(() => {
    return IRIS_DATA.filter(item => {
      const matchesSpecies = speciesFilter === 'all' || item.species === speciesFilter;
      const matchesSearch =
        item.id.toString().includes(searchQuery) ||
        item.species.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.sepalLength.toString().includes(searchQuery) ||
        item.petalLength.toString().includes(searchQuery);
      return matchesSpecies && matchesSearch;
    }).sort((a, b) => {
      const valA = a[sortField];
      const valB = b[sortField];
      if (valA < valB) return sortAsc ? -1 : 1;
      if (valA > valB) return sortAsc ? 1 : -1;
      return 0;
    });
  }, [searchQuery, speciesFilter, sortField, sortAsc]);

  const handleCopyCode = (codeText: string, id: string) => {
    navigator.clipboard.writeText(codeText);
    setCopiedCodeId(id);
    setTimeout(() => setCopiedCodeId(null), 2000);
  };

  // Download Notebook handler
  const handleDownloadNotebook = async () => {
    try {
      const response = await fetch('/Iris_Flower_Classification.ipynb');
      if (!response.ok) {
        window.open('/Iris_Flower_Classification.ipynb', '_blank');
        return;
      }
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Iris_Flower_Classification.ipynb';
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch {
      window.open('/Iris_Flower_Classification.ipynb', '_blank');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Banner & Header */}
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-slate-950 font-bold">
              <Flower2 className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  OIBSIP Data Science
                </span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                  Task 1 Completed
                </span>
              </div>
              <h1 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                Iris Flower Classification
                <span className="text-xs font-normal text-slate-400 hidden sm:inline">
                  • Ronald Fisher Benchmark ML Pipeline
                </span>
              </h1>
            </div>
          </div>

          {/* Quick Metrics Bar & Action */}
          <div className="flex items-center gap-3 flex-wrap">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/60 border border-slate-700/60 text-xs">
              <span className="text-slate-400">Dataset:</span>
              <span className="font-semibold text-emerald-400">150 Samples (Balanced)</span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-400">Best Test Acc:</span>
              <span className="font-semibold text-emerald-400">96.67% (RF)</span>
            </div>
            <button
              onClick={handleDownloadNotebook}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors shadow-sm font-semibold cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Download .ipynb
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-800/60 overflow-x-auto scrollbar-none">
          <nav className="flex space-x-1 py-1.5" aria-label="Tabs">
            {[
              { id: 'predictor', label: 'Interactive Predictor', icon: Sliders },
              { id: 'eda', label: 'Exploratory Analysis (EDA)', icon: Database },
              { id: 'visualizations', label: 'Output Visualizations', icon: BarChart3 },
              { id: 'models', label: 'Model Evaluation & Metrics', icon: Scale },
              { id: 'notebook', label: 'Jupyter Notebook Viewer', icon: FileCode2 },
              { id: 'submission', label: 'Internship Submission Hub', icon: CheckSquare },
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as ActiveTab)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-slate-800 text-emerald-400 shadow-sm border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">

        {/* TAB 1: INTERACTIVE PREDICTOR */}
        {activeTab === 'predictor' && (
          <div className="space-y-6">
            {/* Context callout */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-teal-950/30 border border-emerald-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-base font-semibold text-emerald-300 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  Live Morphological Classification Engine
                </h2>
                <p className="text-xs text-slate-300 mt-1 max-w-3xl">
                  Adjust the four standard Iris flower measurements below using the sliders or choose quick empirical presets.
                  Inference is evaluated using the exact decision boundaries discovered by our scikit-learn models (80% train partition).
                </p>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs text-slate-400 font-medium">Presets:</span>
                <button
                  onClick={() => applyPreset('setosa')}
                  className="px-2.5 py-1 text-xs rounded-md bg-blue-500/10 text-blue-400 border border-blue-500/20 hover:bg-blue-500/20 transition-colors"
                >
                  Setosa
                </button>
                <button
                  onClick={() => applyPreset('versicolor')}
                  className="px-2.5 py-1 text-xs rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 transition-colors"
                >
                  Versicolor
                </button>
                <button
                  onClick={() => applyPreset('virginica')}
                  className="px-2.5 py-1 text-xs rounded-md bg-purple-500/10 text-purple-400 border border-purple-500/20 hover:bg-purple-500/20 transition-colors"
                >
                  Virginica
                </button>
                <button
                  onClick={() => applyPreset('borderline')}
                  className="px-2.5 py-1 text-xs rounded-md bg-amber-500/10 text-amber-400 border border-amber-500/20 hover:bg-amber-500/20 transition-colors"
                >
                  Borderline
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Sliders Panel */}
              <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-emerald-400" />
                    Input Morphological Measurements (cm)
                  </h3>
                  <button
                    onClick={() => {
                      setSepalLength(5.8);
                      setSepalWidth(3.0);
                      setPetalLength(4.2);
                      setPetalWidth(1.3);
                    }}
                    className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" /> Reset Mean
                  </button>
                </div>

                {/* 1. Sepal Length */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-slate-200">Sepal Length</span>
                    <span className="font-mono bg-slate-800 px-2.5 py-0.5 rounded text-emerald-400 font-bold text-sm">
                      {sepalLength.toFixed(1)} cm
                    </span>
                  </div>
                  <input
                    type="range"
                    min="4.0"
                    max="8.0"
                    step="0.1"
                    value={sepalLength}
                    onChange={e => setSepalLength(parseFloat(e.target.value))}
                    className="w-full accent-emerald-500 cursor-pointer h-2 bg-slate-800 rounded-lg appearance-none"
                  />
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>Min: 4.3 cm (Dataset)</span>
                    <span>Mean: 5.84 cm</span>
                    <span>Max: 7.9 cm</span>
                  </div>
                </div>

                {/* 2. Sepal Width */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-slate-200">Sepal Width</span>
                    <span className="font-mono bg-slate-800 px-2.5 py-0.5 rounded text-emerald-400 font-bold text-sm">
                      {sepalWidth.toFixed(1)} cm
                    </span>
                  </div>
                  <input
                    type="range"
                    min="2.0"
                    max="4.5"
                    step="0.1"
                    value={sepalWidth}
                    onChange={e => setSepalWidth(parseFloat(e.target.value))}
                    className="w-full accent-emerald-500 cursor-pointer h-2 bg-slate-800 rounded-lg appearance-none"
                  />
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>Min: 2.0 cm (Dataset)</span>
                    <span>Mean: 3.06 cm</span>
                    <span>Max: 4.4 cm</span>
                  </div>
                </div>

                {/* 3. Petal Length (High Discriminative Power) */}
                <div className="space-y-2 p-3 rounded-xl bg-slate-800/40 border border-emerald-500/20">
                  <div className="flex justify-between items-center text-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-slate-200">Petal Length</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-bold uppercase">
                        High Importance (44%)
                      </span>
                    </div>
                    <span className="font-mono bg-slate-800 px-2.5 py-0.5 rounded text-emerald-400 font-bold text-sm">
                      {petalLength.toFixed(1)} cm
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1.0"
                    max="7.0"
                    step="0.1"
                    value={petalLength}
                    onChange={e => setPetalLength(parseFloat(e.target.value))}
                    className="w-full accent-emerald-500 cursor-pointer h-2 bg-slate-800 rounded-lg appearance-none"
                  />
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>Setosa: 1.0–1.9 cm</span>
                    <span>Versicolor: 3.0–5.1 cm</span>
                    <span>Virginica: 4.5–6.9 cm</span>
                  </div>
                </div>

                {/* 4. Petal Width (High Discriminative Power) */}
                <div className="space-y-2 p-3 rounded-xl bg-slate-800/40 border border-emerald-500/20">
                  <div className="flex justify-between items-center text-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-slate-200">Petal Width</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-bold uppercase">
                        High Importance (41%)
                      </span>
                    </div>
                    <span className="font-mono bg-slate-800 px-2.5 py-0.5 rounded text-emerald-400 font-bold text-sm">
                      {petalWidth.toFixed(1)} cm
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="2.6"
                    step="0.1"
                    value={petalWidth}
                    onChange={e => setPetalWidth(parseFloat(e.target.value))}
                    className="w-full accent-emerald-500 cursor-pointer h-2 bg-slate-800 rounded-lg appearance-none"
                  />
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>Setosa: 0.1–0.6 cm</span>
                    <span>Versicolor: 1.0–1.8 cm</span>
                    <span>Virginica: 1.4–2.5 cm</span>
                  </div>
                </div>

                {/* Feature Importance takeaway */}
                <div className="p-3 bg-slate-800/50 rounded-xl text-xs text-slate-400 flex items-start gap-2 border border-slate-700/50">
                  <Info className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <p>
                    <strong>EDA Finding:</strong> Petal Length and Petal Width account for over <span className="text-emerald-300 font-semibold">84%</span> of total classification power. Notice how shifting Petal Length below 2.5 cm instantly snaps the model to Iris Setosa.
                  </p>
                </div>
              </div>

              {/* Classification Result Card */}
              <div className="lg:col-span-5 flex flex-col space-y-6">
                <div className={`bg-slate-900 border-2 rounded-2xl p-6 shadow-2xl transition-all ${activeProfile.borderColor}`}>
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                      ML Predicted Target Class
                    </span>
                    <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase ${activeProfile.badgeBg} ${activeProfile.textColor}`}>
                      {prediction.species}
                    </span>
                  </div>

                  <div className="mt-4 flex items-center gap-4">
                    <div
                      className="w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-lg shrink-0"
                      style={{ backgroundColor: activeProfile.color }}
                    >
                      <Flower2 className="w-8 h-8" />
                    </div>
                    <div>
                      <h4 className="text-2xl font-black text-white tracking-tight">
                        {activeProfile.displayName}
                      </h4>
                      <p className="text-xs text-slate-400 font-medium">
                        {activeProfile.tagline}
                      </p>
                    </div>
                  </div>

                  {/* Confidence Breakdown Bars */}
                  <div className="mt-6 space-y-3">
                    <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Class Posterior Probability
                    </h5>

                    {/* Setosa */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-medium">
                        <span className="text-blue-400">Iris-setosa</span>
                        <span className="font-mono text-slate-200">
                          {(prediction.probabilities.setosa * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-blue-500 h-full transition-all duration-300 rounded-full"
                          style={{ width: `${Math.max(2, prediction.probabilities.setosa * 100)}%` }}
                        />
                      </div>
                    </div>

                    {/* Versicolor */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-medium">
                        <span className="text-emerald-400">Iris-versicolor</span>
                        <span className="font-mono text-slate-200">
                          {(prediction.probabilities.versicolor * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-500 h-full transition-all duration-300 rounded-full"
                          style={{ width: `${Math.max(2, prediction.probabilities.versicolor * 100)}%` }}
                        />
                      </div>
                    </div>

                    {/* Virginica */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-medium">
                        <span className="text-purple-400">Iris-virginica</span>
                        <span className="font-mono text-slate-200">
                          {(prediction.probabilities.virginica * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-purple-500 h-full transition-all duration-300 rounded-full"
                          style={{ width: `${Math.max(2, prediction.probabilities.virginica * 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Decision Rule Explanation */}
                  <div className="mt-5 p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-300 space-y-1.5">
                    <div className="font-semibold text-slate-200 flex items-center gap-1.5">
                      <ChevronRight className="w-3.5 h-3.5 text-emerald-400" />
                      Decision Boundary Analysis:
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      {prediction.ruleExplanation}
                    </p>
                  </div>

                  {/* Species Typical Dimensions */}
                  <div className="mt-4 pt-4 border-t border-slate-800 grid grid-cols-2 gap-2 text-[11px] text-slate-400">
                    <div className="bg-slate-800/40 p-2 rounded-lg">
                      <span className="block text-slate-300 font-semibold">Typical Sepal:</span>
                      {activeProfile.avgSepalLength} × {activeProfile.avgSepalWidth} cm
                    </div>
                    <div className="bg-slate-800/40 p-2 rounded-lg">
                      <span className="block text-slate-300 font-semibold">Typical Petal:</span>
                      {activeProfile.avgPetalLength} × {activeProfile.avgPetalWidth} cm
                    </div>
                  </div>
                </div>

                {/* Algorithmic Agreement Card */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                    <Scale className="w-4 h-4 text-emerald-400" />
                    Model Consensus Comparison
                  </h4>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/50">
                      <span className="text-slate-400 text-[11px] block">Logistic Regression</span>
                      <span className="font-bold text-white text-sm capitalize">{prediction.species}</span>
                      <span className="text-[10px] text-emerald-400 block mt-1">Pipeline (StandardScaler)</span>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/50">
                      <span className="text-slate-400 text-[11px] block">Random Forest</span>
                      <span className="font-bold text-white text-sm capitalize">{prediction.species}</span>
                      <span className="text-[10px] text-emerald-400 block mt-1">100 Estimators (Ensemble)</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: EXPLORATORY DATA ANALYSIS (EDA) */}
        {activeTab === 'eda' && (
          <div className="space-y-6">
            {/* Top stats summary cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                <span className="text-xs text-slate-400 font-medium">Total Samples</span>
                <p className="text-2xl font-bold text-white mt-1">150</p>
                <span className="text-[11px] text-emerald-400 flex items-center gap-1 mt-1">
                  <CheckCircle2 className="w-3 h-3" /> 50 per class (Balanced)
                </span>
              </div>
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                <span className="text-xs text-slate-400 font-medium">Input Features</span>
                <p className="text-2xl font-bold text-white mt-1">4 Numeric</p>
                <span className="text-[11px] text-slate-400 mt-1 block">Continuous cm</span>
              </div>
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                <span className="text-xs text-slate-400 font-medium">Missing Values</span>
                <p className="text-2xl font-bold text-emerald-400 mt-1">0 (0.0%)</p>
                <span className="text-[11px] text-slate-400 mt-1 block">Clean canonical dataset</span>
              </div>
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                <span className="text-xs text-slate-400 font-medium">Train / Test Split</span>
                <p className="text-2xl font-bold text-white mt-1">120 / 30</p>
                <span className="text-[11px] text-purple-400 mt-1 block">80/20 Stratified Split</span>
              </div>
            </div>

            {/* Species Comparison Table */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-400" />
                Descriptive Statistics Grouped by Species (Mean ± Std)
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-semibold">
                      <th className="py-3 px-4">Species</th>
                      <th className="py-3 px-4">Count</th>
                      <th className="py-3 px-4">Sepal Length (cm)</th>
                      <th className="py-3 px-4">Sepal Width (cm)</th>
                      <th className="py-3 px-4">Petal Length (cm)</th>
                      <th className="py-3 px-4">Petal Width (cm)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
                    <tr className="hover:bg-slate-800/30">
                      <td className="py-3 px-4 font-sans font-semibold text-blue-400 flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span> Setosa
                      </td>
                      <td className="py-3 px-4">50 (33.3%)</td>
                      <td className="py-3 px-4">5.01 ± 0.35</td>
                      <td className="py-3 px-4">3.43 ± 0.38</td>
                      <td className="py-3 px-4 text-emerald-400 font-bold">1.46 ± 0.17</td>
                      <td className="py-3 px-4 text-emerald-400 font-bold">0.25 ± 0.11</td>
                    </tr>
                    <tr className="hover:bg-slate-800/30">
                      <td className="py-3 px-4 font-sans font-semibold text-emerald-400 flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Versicolor
                      </td>
                      <td className="py-3 px-4">50 (33.3%)</td>
                      <td className="py-3 px-4">5.94 ± 0.52</td>
                      <td className="py-3 px-4">2.77 ± 0.31</td>
                      <td className="py-3 px-4">4.26 ± 0.47</td>
                      <td className="py-3 px-4">1.33 ± 0.20</td>
                    </tr>
                    <tr className="hover:bg-slate-800/30">
                      <td className="py-3 px-4 font-sans font-semibold text-purple-400 flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span> Virginica
                      </td>
                      <td className="py-3 px-4">50 (33.3%)</td>
                      <td className="py-3 px-4">6.59 ± 0.64</td>
                      <td className="py-3 px-4">2.97 ± 0.32</td>
                      <td className="py-3 px-4">5.55 ± 0.55</td>
                      <td className="py-3 px-4">2.03 ± 0.27</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Interactive Dataset Browser */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    <Database className="w-4 h-4 text-emerald-400" />
                    Built-in Iris Dataset Records ({filteredData.length} of {IRIS_DATA.length})
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Search and filter records loaded from <code className="text-emerald-400">sklearn.datasets.load_iris</code>
                  </p>
                </div>

                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <div className="relative flex-1 sm:w-48">
                    <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Search record..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-800 border border-slate-700 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <select
                    value={speciesFilter}
                    onChange={e => setSpeciesFilter(e.target.value)}
                    className="py-1.5 px-3 text-xs bg-slate-800 border border-slate-700 rounded-lg text-slate-200 focus:outline-none focus:border-emerald-500"
                  >
                    <option value="all">All Species</option>
                    <option value="setosa">Setosa (50)</option>
                    <option value="versicolor">Versicolor (50)</option>
                    <option value="virginica">Virginica (50)</option>
                  </select>
                </div>
              </div>

              {/* Data Table */}
              <div className="overflow-x-auto max-h-96 overflow-y-auto border border-slate-800 rounded-xl">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="sticky top-0 bg-slate-800 text-slate-300 font-semibold z-10">
                    <tr className="border-b border-slate-700">
                      {[
                        { key: 'id', label: 'ID' },
                        { key: 'sepalLength', label: 'Sepal Length (cm)' },
                        { key: 'sepalWidth', label: 'Sepal Width (cm)' },
                        { key: 'petalLength', label: 'Petal Length (cm)' },
                        { key: 'petalWidth', label: 'Petal Width (cm)' },
                        { key: 'species', label: 'Species' },
                      ].map(col => (
                        <th
                          key={col.key}
                          onClick={() => {
                            if (sortField === col.key) {
                              setSortAsc(!sortAsc);
                            } else {
                              setSortField(col.key as keyof IrisSample);
                              setSortAsc(true);
                            }
                          }}
                          className="py-2.5 px-4 cursor-pointer hover:text-emerald-400 select-none whitespace-nowrap"
                        >
                          {col.label} {sortField === col.key ? (sortAsc ? '▲' : '▼') : ''}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 font-mono text-slate-300">
                    {filteredData.slice(0, 100).map(row => (
                      <tr key={row.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-2 px-4 text-slate-400">#{row.id}</td>
                        <td className="py-2 px-4">{row.sepalLength.toFixed(1)}</td>
                        <td className="py-2 px-4">{row.sepalWidth.toFixed(1)}</td>
                        <td className="py-2 px-4 text-emerald-400 font-semibold">{row.petalLength.toFixed(1)}</td>
                        <td className="py-2 px-4 text-emerald-400 font-semibold">{row.petalWidth.toFixed(1)}</td>
                        <td className="py-2 px-4 font-sans font-medium">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[11px] ${
                              row.species === 'setosa'
                                ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                                : row.species === 'versicolor'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                : 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                            }`}
                          >
                            {row.species}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: VISUALIZATIONS GALLERY */}
        {activeTab === 'visualizations' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h2 className="text-base font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-emerald-400" />
                  Generated High-Resolution Visualizations (outputs/)
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Rendered with Seaborn and Matplotlib at 300 DPI and stored in the project's outputs folder.
                </p>
              </div>
              <span className="text-xs px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-emerald-400 font-medium">
                5 Publication-Grade PNG Files
              </span>
            </div>

            {/* Visualizations Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* 1. Pairplot */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col group hover:border-slate-700 transition-all">
                <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
                  <div>
                    <h4 className="text-sm font-bold text-white">1. Iris Feature Pairplot (Pairwise & KDE)</h4>
                    <span className="text-[11px] text-slate-400 font-mono">outputs/pairplot.png</span>
                  </div>
                  <button
                    onClick={() => setActiveImageModal('/outputs/pairplot.png')}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                    title="Expand View"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="p-4 bg-slate-950 flex items-center justify-center min-h-[280px]">
                  <img
                    src="/outputs/pairplot.png"
                    alt="Pairplot of Iris Features"
                    className="max-h-72 object-contain rounded-lg border border-slate-800/80 cursor-pointer hover:opacity-95 transition-opacity"
                    onClick={() => setActiveImageModal('/outputs/pairplot.png')}
                  />
                </div>
                <div className="p-4 bg-slate-900/90 border-t border-slate-800 text-xs text-slate-300">
                  <strong className="text-emerald-400">Key Observation:</strong> Setosa (blue) is completely isolated in petal length and width. Versicolor (green) and Virginica (purple) share a close boundary.
                </div>
              </div>

              {/* 2. Feature Boxplots */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col group hover:border-slate-700 transition-all">
                <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
                  <div>
                    <h4 className="text-sm font-bold text-white">2. Feature Box Plots with Strip Overlay</h4>
                    <span className="text-[11px] text-slate-400 font-mono">outputs/feature_boxplots.png</span>
                  </div>
                  <button
                    onClick={() => setActiveImageModal('/outputs/feature_boxplots.png')}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                    title="Expand View"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="p-4 bg-slate-950 flex items-center justify-center min-h-[280px]">
                  <img
                    src="/outputs/feature_boxplots.png"
                    alt="Feature Boxplots"
                    className="max-h-72 object-contain rounded-lg border border-slate-800/80 cursor-pointer hover:opacity-95 transition-opacity"
                    onClick={() => setActiveImageModal('/outputs/feature_boxplots.png')}
                  />
                </div>
                <div className="p-4 bg-slate-900/90 border-t border-slate-800 text-xs text-slate-300">
                  <strong className="text-emerald-400">Key Observation:</strong> Petal dimensions exhibit clear interquartile gaps between species, while Sepal Width shows noticeable overlap between Versicolor and Virginica.
                </div>
              </div>

              {/* 3. Confusion Matrix: Logistic Regression */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col group hover:border-slate-700 transition-all">
                <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
                  <div>
                    <h4 className="text-sm font-bold text-white">3. Confusion Matrix — Logistic Regression</h4>
                    <span className="text-[11px] text-slate-400 font-mono">outputs/confusion_matrix_logistic_regression.png</span>
                  </div>
                  <button
                    onClick={() => setActiveImageModal('/outputs/confusion_matrix_logistic_regression.png')}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                    title="Expand View"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="p-4 bg-slate-950 flex items-center justify-center min-h-[260px]">
                  <img
                    src="/outputs/confusion_matrix_logistic_regression.png"
                    alt="Logistic Regression Confusion Matrix"
                    className="max-h-64 object-contain rounded-lg border border-slate-800/80 cursor-pointer hover:opacity-95 transition-opacity"
                    onClick={() => setActiveImageModal('/outputs/confusion_matrix_logistic_regression.png')}
                  />
                </div>
                <div className="p-4 bg-slate-900/90 border-t border-slate-800 text-xs text-slate-300">
                  <strong className="text-blue-400">Result:</strong> 28/30 correct (93.33% Accuracy). 10/10 Setosa, 9/10 Versicolor, 9/10 Virginica.
                </div>
              </div>

              {/* 4. Confusion Matrix: Random Forest */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col group hover:border-slate-700 transition-all">
                <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
                  <div>
                    <h4 className="text-sm font-bold text-white">4. Confusion Matrix — Random Forest</h4>
                    <span className="text-[11px] text-slate-400 font-mono">outputs/confusion_matrix_random_forest.png</span>
                  </div>
                  <button
                    onClick={() => setActiveImageModal('/outputs/confusion_matrix_random_forest.png')}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                    title="Expand View"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="p-4 bg-slate-950 flex items-center justify-center min-h-[260px]">
                  <img
                    src="/outputs/confusion_matrix_random_forest.png"
                    alt="Random Forest Confusion Matrix"
                    className="max-h-64 object-contain rounded-lg border border-slate-800/80 cursor-pointer hover:opacity-95 transition-opacity"
                    onClick={() => setActiveImageModal('/outputs/confusion_matrix_random_forest.png')}
                  />
                </div>
                <div className="p-4 bg-slate-900/90 border-t border-slate-800 text-xs text-slate-300">
                  <strong className="text-emerald-400">Result:</strong> 29/30 correct (96.67% Accuracy). 10/10 Setosa, 9/10 Versicolor, 10/10 Virginica.
                </div>
              </div>

              {/* 5. Model Comparison Bar Chart (Full Width) */}
              <div className="md:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col group hover:border-slate-700 transition-all">
                <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
                  <div>
                    <h4 className="text-sm font-bold text-white">5. Model Performance Comparison Chart</h4>
                    <span className="text-[11px] text-slate-400 font-mono">outputs/model_comparison.png</span>
                  </div>
                  <button
                    onClick={() => setActiveImageModal('/outputs/model_comparison.png')}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                    title="Expand View"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="p-4 bg-slate-950 flex items-center justify-center min-h-[300px]">
                  <img
                    src="/outputs/model_comparison.png"
                    alt="Model Comparison Bar Chart"
                    className="max-h-96 object-contain rounded-lg border border-slate-800/80 cursor-pointer hover:opacity-95 transition-opacity"
                    onClick={() => setActiveImageModal('/outputs/model_comparison.png')}
                  />
                </div>
                <div className="p-4 bg-slate-900/90 border-t border-slate-800 text-xs text-slate-300 flex items-center justify-between">
                  <span>
                    <strong className="text-emerald-400">Evaluation:</strong> Compares Accuracy, Macro Precision, Macro Recall, and Macro F1-Score on the held-out 30 test samples.
                  </span>
                  <span className="font-semibold text-emerald-400">Random Forest leads at 96.67%</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: MODEL EVALUATION & METRICS */}
        {activeTab === 'models' && (
          <div className="space-y-6">
            {/* Model Comparison Table */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                <div>
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    <Scale className="w-4 h-4 text-emerald-400" />
                    Model Benchmark Comparison (30 Test Samples)
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Directly executed metrics from scikit-learn without hardcoded estimates or data leakage.
                  </p>
                </div>
                <span className="text-xs px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">
                  Zero Data Leakage (Pipeline Fit on Train Only)
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-semibold">
                      <th className="py-3 px-4">Classifier</th>
                      <th className="py-3 px-4">Accuracy</th>
                      <th className="py-3 px-4">Macro Precision</th>
                      <th className="py-3 px-4">Macro Recall</th>
                      <th className="py-3 px-4">Macro F1-Score</th>
                      <th className="py-3 px-4">Status / Verdict</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
                    <tr className="bg-emerald-950/20 hover:bg-emerald-950/30">
                      <td className="py-3 px-4 font-sans font-bold text-white flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        Random Forest Classifier
                      </td>
                      <td className="py-3 px-4 text-emerald-400 font-bold text-sm">
                        {(dataSummary.random_forest.accuracy * 100).toFixed(2)}%
                      </td>
                      <td className="py-3 px-4">{dataSummary.random_forest.precision_macro.toFixed(4)}</td>
                      <td className="py-3 px-4">{dataSummary.random_forest.recall_macro.toFixed(4)}</td>
                      <td className="py-3 px-4 text-emerald-400 font-bold">{dataSummary.random_forest.f1_macro.toFixed(4)}</td>
                      <td className="py-3 px-4 font-sans">
                        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          Best Performing (29/30)
                        </span>
                      </td>
                    </tr>
                    <tr className="hover:bg-slate-800/30">
                      <td className="py-3 px-4 font-sans font-semibold text-slate-200 flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-bold">
                          LR
                        </div>
                        Logistic Regression (Pipeline)
                      </td>
                      <td className="py-3 px-4 text-blue-400 font-bold text-sm">
                        {(dataSummary.logistic_regression.accuracy * 100).toFixed(2)}%
                      </td>
                      <td className="py-3 px-4">{dataSummary.logistic_regression.precision_macro.toFixed(4)}</td>
                      <td className="py-3 px-4">{dataSummary.logistic_regression.recall_macro.toFixed(4)}</td>
                      <td className="py-3 px-4 text-blue-400 font-bold">{dataSummary.logistic_regression.f1_macro.toFixed(4)}</td>
                      <td className="py-3 px-4 font-sans">
                        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-slate-800 text-slate-300 border border-slate-700">
                          Strong Baseline (28/30)
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Feature Importance & Technical Takeaway */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Random Forest Feature Importance */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
                <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-emerald-400" />
                  Random Forest Gini Feature Importance
                </h4>
                <div className="space-y-3 pt-2">
                  {Object.entries(dataSummary.random_forest.feature_importances).map(([feat, score]) => (
                    <div key={feat} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="font-medium text-slate-300 capitalize">{feat}</span>
                        <span className="font-mono text-emerald-400 font-bold">{(score * 100).toFixed(2)}%</span>
                      </div>
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                          style={{ width: `${score * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
                <div className="p-3 bg-slate-800/40 rounded-xl text-xs text-slate-400 border border-slate-700/50 mt-4">
                  <strong>Takeaway:</strong> Petal Length (44.13%) and Petal Width (40.55%) together account for <strong>84.68%</strong> of tree split decisions. Sepal Width contributes least (2.75%).
                </div>
              </div>

              {/* Technical Comparison Discussion */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3">
                <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-emerald-400" />
                  Technical Analysis & Decision Verdict
                </h4>
                <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
                  <p>
                    <strong className="text-white">Why Random Forest Won:</strong> The Random Forest classifier achieved <strong>96.67% test accuracy</strong> by successfully capturing subtle non-linear interactions between petal width and sepal length near the Versicolor-Virginica boundary.
                  </p>
                  <p>
                    <strong className="text-white">Logistic Regression Baseline:</strong> Logistic Regression scored <strong>93.33%</strong>. With StandardScaler normalization, it provides instant convergence and completely transparent log-odds coefficients, making it suitable for low-power edge deployment.
                  </p>
                  <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/20 text-emerald-300">
                    <strong>Internship Recommendation:</strong> Select Random Forest as the primary model for accuracy, but emphasize the interpretability and low computational cost of the Logistic Regression pipeline in the final presentation.
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: JUPYTER NOTEBOOK VIEWER */}
        {activeTab === 'notebook' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h2 className="text-base font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <FileCode2 className="w-5 h-5 text-emerald-400" />
                  Jupyter Notebook Explorer (Iris_Flower_Classification.ipynb)
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  12 comprehensive sections written, commented, and executed strictly for the Oasis Infobyte Task 1 requirements.
                </p>
              </div>
              <button
                onClick={handleDownloadNotebook}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors shadow-sm cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                Download Complete .ipynb
              </button>
            </div>

            {/* Notebook Section Outline */}
            <div className="space-y-4">
              {[
                {
                  sec: 'Section 1',
                  title: 'Project Introduction & Machine Learning Paradigm',
                  summary: 'Explains classification, Ronald Fisher benchmark, supervised learning, and the 4 inputs and 3 target species.',
                  codeSnippet: `# Four input features and three target classes
FEATURES = ['sepal length (cm)', 'sepal width (cm)', 'petal length (cm)', 'petal width (cm)']
CLASSES = ['setosa', 'versicolor', 'virginica']`,
                },
                {
                  sec: 'Section 2',
                  title: 'Import Libraries with Reproducibility Seed',
                  summary: 'Imports pandas, numpy, matplotlib, seaborn, and scikit-learn modules. Uses random_state=42.',
                  codeSnippet: `import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

RANDOM_STATE = 42`,
                },
                {
                  sec: 'Section 3',
                  title: 'Load Dataset via sklearn.datasets.load_iris',
                  summary: 'Converts built-in dataset to a DataFrame with species target column, printing shape (150, 5), dtypes, and null counts.',
                  codeSnippet: `iris_raw = load_iris()
df = pd.DataFrame(data=iris_raw.data, columns=iris_raw.feature_names)
df['species'] = pd.Categorical.from_codes(iris_raw.target, iris_raw.target_names)
print("Shape:", df.shape) # (150, 5)
print("Missing values:", df.isnull().sum().sum()) # 0`,
                },
                {
                  sec: 'Section 4',
                  title: 'Exploratory Data Analysis (EDA)',
                  summary: 'Audits nulls, duplicates, descriptive statistics, and feature statistics grouped by species.',
                  codeSnippet: `grouped_stats = df.groupby('species', observed=False).agg(['mean', 'std'])
display(grouped_stats)`,
                },
                {
                  sec: 'Section 5',
                  title: 'Data Visualizations (Pairplot, Boxplots, Heatmap)',
                  summary: 'Generates high-res pairplot, 4 feature boxplots with observation strip overlays, and saves to outputs/.',
                  codeSnippet: `# Pairplot saved with 300 DPI
pairplot = sns.pairplot(df, hue='species', diag_kind="kde")
pairplot.savefig("outputs/pairplot.png", dpi=300)

# Feature boxplots saved with 300 DPI
fig, axes = plt.subplots(2, 2, figsize=(13, 9))
...
plt.savefig("outputs/feature_boxplots.png", dpi=300)`,
                },
                {
                  sec: 'Section 6',
                  title: 'Feature Selection & Discriminative Analysis',
                  summary: 'Compares all 4 features, proving Petal Length and Width have >84% importance using empirical evidence.',
                  codeSnippet: `rf_importances = pd.Series(rf_classifier.feature_importances_, index=iris_raw.feature_names)
print(rf_importances.sort_values(ascending=False))`,
                },
                {
                  sec: 'Section 7',
                  title: 'Stratified 80/20 Train-Test Split (Zero Leakage)',
                  summary: 'Splits 150 samples into 120 train and 30 test with stratify=y to maintain 10 samples per class in test.',
                  codeSnippet: `X = df[iris_raw.feature_names]
y = df['species']
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)`,
                },
                {
                  sec: 'Section 8',
                  title: 'Train Classifiers: Scaled Logistic Regression & Random Forest',
                  summary: 'Fits StandardScaler pipeline on train only. Random Forest with n_estimators=100 and max_depth=4.',
                  codeSnippet: `# Model A: Scaled Logistic Regression Pipeline
lr_pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('classifier', LogisticRegression(max_iter=200, random_state=42))
])
lr_pipeline.fit(X_train, y_train)

# Model B: Random Forest Classifier
rf_clf = RandomForestClassifier(n_estimators=100, max_depth=4, random_state=42)
rf_clf.fit(X_train, y_train)`,
                },
                {
                  sec: 'Section 9',
                  title: 'Model Evaluation: Accuracy, Reports, & Confusion Matrices',
                  summary: 'Computes accuracy, precision, recall, and F1-score. Generates confusion matrix heatmaps saved to outputs/.',
                  codeSnippet: `y_pred_rf = rf_clf.predict(X_test)
print(classification_report(y_test, y_pred_rf, target_names=iris_raw.target_names))
cm_rf = confusion_matrix(y_test, y_pred_rf, labels=iris_raw.target_names)
sns.heatmap(cm_rf, annot=True, fmt='d', cmap='Greens')
plt.savefig("outputs/confusion_matrix_random_forest.png", dpi=300)`,
                },
                {
                  sec: 'Section 10',
                  title: 'Model Comparison Table & Best-Performing Model Declaration',
                  summary: 'Side-by-side comparison bar chart. Declares Random Forest as best-performing (96.67% vs 93.33%).',
                  codeSnippet: `comparison_df = pd.DataFrame({
    'Model': ['Logistic Regression (Pipeline)', 'Random Forest Classifier'],
    'Accuracy': [acc_lr, acc_rf],
    'Macro Precision': [prec_lr, prec_rf],
    'Macro Recall': [rec_lr, rec_rf],
    'Macro F1-Score': [f1_lr, f1_rf]
})
display(comparison_df)`,
                },
                {
                  sec: 'Section 11',
                  title: 'Final Conclusion, Limitations & Real-World Scope',
                  summary: 'Documents accomplishments, dataset limitations (150 samples from 1936), and educational purpose.',
                  codeSnippet: `# Final summary documented in detailed markdown cells`,
                },
                {
                  sec: 'Section 12',
                  title: 'Beginner Learning Glossary for Junior Engineers',
                  summary: 'Concise 1-2 sentence definitions for Dataset, Feature, Target, Classification, Overfitting, Confusion Matrix, etc.',
                  codeSnippet: `# 10 core Machine Learning terms defined for engineering students`,
                },
              ].map(item => (
                <div key={item.sec} className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono text-xs font-bold border border-emerald-500/20">
                        {item.sec}
                      </span>
                      <h4 className="text-sm font-bold text-white">{item.title}</h4>
                    </div>
                    <button
                      onClick={() => handleCopyCode(item.codeSnippet, item.sec)}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs rounded bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium transition-colors self-start sm:self-auto cursor-pointer"
                    >
                      {copiedCodeId === item.sec ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy Code</span>
                        </>
                      )}
                    </button>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {item.summary}
                  </p>
                  <pre className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-[11px] text-slate-300 overflow-x-auto">
                    <code>{item.codeSnippet}</code>
                  </pre>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 6: SUBMISSION & GITHUB HUB */}
        {activeTab === 'submission' && (
          <div className="space-y-6">
            {/* Internship Verification Banner */}
            <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-teal-950/30 border border-emerald-500/30 p-6 rounded-2xl shadow-xl space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <CheckSquare className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    Oasis Infobyte Internship (OIBSIP) Task 1 Submission Kit
                  </h3>
                  <p className="text-xs text-slate-400">
                    Repository target: <code className="text-emerald-400 font-mono">OIBSIP/DataScience/Task1_Iris_Flower_Classification/</code>
                  </p>
                </div>
              </div>

              {/* Requirements Checklist */}
              <div className="pt-2 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                {[
                  'Loaded from sklearn.datasets.load_iris (no external download)',
                  'Complete EDA (shape, types, nulls, duplicates, stats)',
                  'Publication-grade Pairplot saved to outputs/pairplot.png',
                  'Feature Boxplots for all 4 features saved to outputs/',
                  'Correlation heatmap & discriminative feature analysis',
                  'Stratified 80/20 train-test split (random_state=42)',
                  'Model A: Scaled Logistic Regression Pipeline trained',
                  'Model B: Random Forest Classifier (n=100) trained',
                  'Accuracy, Precision, Recall, F1 & Confusion Matrices evaluated',
                  'Model comparison table & bar chart saved to outputs/',
                  'Best model declared with technical justification',
                  'Beginner glossary, README.md, & screenshots guide created',
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2.5 p-2 rounded-lg bg-slate-800/40 border border-slate-800 text-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Folder Structure Explorer */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Layers className="w-4 h-4 text-emerald-400" />
                Verified Repository Structure
              </h4>
              <pre className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-emerald-300 leading-relaxed overflow-x-auto">
{`OIBSIP/
└── DataScience/
    └── Task1_Iris_Flower_Classification/
        ├── Iris_Flower_Classification.ipynb   # Complete executed notebook (Sections 1-12)
        ├── README.md                          # Full GitHub documentation with all metrics
        ├── requirements.txt                   # pandas, numpy, scikit-learn, matplotlib, etc.
        ├── outputs/                           # 300 DPI generated visualization PNGs
        │   ├── pairplot.png
        │   ├── feature_boxplots.png
        │   ├── confusion_matrix_logistic_regression.png
        │   ├── confusion_matrix_random_forest.png
        │   └── model_comparison.png
        └── screenshots/                       # Directory for local execution capture
            └── README.md                      # Guide for genuine screenshot capture`}
              </pre>
            </div>

            {/* Terminal Commands for Submission */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Step 1: Install & Run */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-emerald-400" />
                    1. Run Locally in Virtualenv
                  </h4>
                  <button
                    onClick={() =>
                      handleCopyCode(
                        `cd OIBSIP/DataScience/Task1_Iris_Flower_Classification\npython3 -m venv venv\nsource venv/bin/activate\npip install -r requirements.txt\njupyter notebook`,
                        'cmd1'
                      )
                    }
                    className="text-xs text-slate-400 hover:text-emerald-400 flex items-center gap-1 cursor-pointer"
                  >
                    {copiedCodeId === 'cmd1' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    Copy
                  </button>
                </div>
                <pre className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 overflow-x-auto">
{`# Navigate to task directory
cd OIBSIP/DataScience/Task1_Iris_Flower_Classification

# Create and activate virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\\Scripts\\activate

# Install project requirements
pip install -r requirements.txt

# Launch Jupyter Notebook
jupyter notebook`}
                </pre>
              </div>

              {/* Step 2: Push to GitHub */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Github className="w-4 h-4 text-emerald-400" />
                    2. Git Commit & Push to GitHub
                  </h4>
                  <button
                    onClick={() =>
                      handleCopyCode(
                        `git add OIBSIP/DataScience/Task1_Iris_Flower_Classification\ngit commit -m "Complete OIBSIP Task 1 Iris Flower Classification"\ngit push origin main`,
                        'cmd2'
                      )
                    }
                    className="text-xs text-slate-400 hover:text-emerald-400 flex items-center gap-1 cursor-pointer"
                  >
                    {copiedCodeId === 'cmd2' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    Copy
                  </button>
                </div>
                <pre className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 font-mono text-xs text-slate-300 overflow-x-auto">
{`# Stage task files
git add OIBSIP/DataScience/Task1_Iris_Flower_Classification

# Commit with Oasis Infobyte task message
git commit -m "Complete OIBSIP Task 1 Iris Flower Classification"

# Push to your GitHub repository
git push origin main`}
                </pre>
              </div>
            </div>

            {/* Genuine Screenshot Capture Instructions */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Camera className="w-4 h-4 text-emerald-400" />
                Genuine Screenshot Capture Guide (Oasis Infobyte Requirement)
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Oasis Infobyte asks interns to submit genuine, verifiable screenshots of the notebook running locally:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs pt-1">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <span className="font-bold text-emerald-400 block">Windows</span>
                  <p className="text-slate-400 text-[11px]">
                    Press <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-200">Win + Shift + S</kbd> to snip the browser cell with cell execution counts visible.
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <span className="font-bold text-emerald-400 block">macOS</span>
                  <p className="text-slate-400 text-[11px]">
                    Press <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-200">Cmd + Shift + 4</kbd> to drag over the notebook execution cell and plot output.
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <span className="font-bold text-emerald-400 block">Linux</span>
                  <p className="text-slate-400 text-[11px]">
                    Press <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-200">Shift + PrintScreen</kbd> or launch GNOME screenshot tool to capture.
                  </p>
                </div>
              </div>
              <p className="text-[11px] text-slate-400 pt-2">
                Save the images into <code className="text-emerald-400">OIBSIP/DataScience/Task1_Iris_Flower_Classification/screenshots/</code> and reference them in your README.
              </p>
            </div>
          </div>
        )}
      </main>

      {/* Lightbox Image Modal */}
      {activeImageModal && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setActiveImageModal(null)}
        >
          <div
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-4xl w-full p-4 shadow-2xl space-y-3"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex justify-between items-center pb-2 border-b border-slate-800">
              <span className="text-xs font-mono text-emerald-400">{activeImageModal}</span>
              <button
                onClick={() => setActiveImageModal(null)}
                className="px-2.5 py-1 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
              >
                Close ✕
              </button>
            </div>
            <div className="max-h-[75vh] flex items-center justify-center overflow-auto bg-slate-950 rounded-xl p-2">
              <img
                src={activeImageModal}
                alt="Enlarged Plot"
                className="max-h-[70vh] object-contain rounded-lg"
              />
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-4 text-center text-xs text-slate-500">
        <p>
          Oasis Infobyte Data Science Internship (OIBSIP) — Task 1: Iris Flower Classification • Built with Python, Scikit-Learn, Pandas & React
        </p>
      </footer>
    </div>
  );
}
