#!/usr/bin/env python3
"""
Iris Flower Classification - OIBSIP Data Science Internship Task 1
Complete automated generator and executor.
"""
import os
import json
import base64
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    precision_score,
    recall_score,
    f1_score
)

def run():
    base_dir = "OIBSIP/DataScience/Task1_Iris_Flower_Classification"
    outputs_dir = os.path.join(base_dir, "outputs")
    screenshots_dir = os.path.join(base_dir, "screenshots")
    public_outputs_dir = "public/outputs"
    os.makedirs(outputs_dir, exist_ok=True)
    os.makedirs(screenshots_dir, exist_ok=True)
    os.makedirs(public_outputs_dir, exist_ok=True)

    print("1. Loading dataset...")
    iris = load_iris()
    df = pd.DataFrame(data=iris.data, columns=iris.feature_names)
    df['species'] = pd.Categorical.from_codes(iris.target, iris.target_names)

    print("Shape:", df.shape)
    print("Class distribution:\n", df['species'].value_counts())

    # Set visualization styling
    sns.set_theme(style="whitegrid", palette="muted")
    plt.rcParams.update({'font.sans-serif': 'DejaVu Sans', 'font.size': 11})

    # 1. Pairplot
    print("Generating pairplot...")
    pairplot = sns.pairplot(
        df,
        hue='species',
        markers=["o", "s", "D"],
        palette={'setosa': '#3b82f6', 'versicolor': '#10b981', 'virginica': '#8b5cf6'},
        diag_kind="kde",
        plot_kws={'alpha': 0.8, 's': 45}
    )
    pairplot.fig.subplots_adjust(top=0.93)
    pairplot.fig.suptitle("Iris Feature Pairplot (Bivariate Distributions & KDE)", fontsize=16, weight='bold')
    pairplot_path = os.path.join(outputs_dir, "pairplot.png")
    pairplot.savefig(pairplot_path, dpi=300, bbox_inches='tight')
    pairplot.savefig(os.path.join(public_outputs_dir, "pairplot.png"), dpi=300, bbox_inches='tight')
    plt.close()

    # 2. Feature Boxplots
    print("Generating feature boxplots...")
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    palette = {'setosa': '#3b82f6', 'versicolor': '#10b981', 'virginica': '#8b5cf6'}
    for ax, feature in zip(axes.flatten(), iris.feature_names):
        sns.boxplot(x='species', y=feature, data=df, ax=ax, palette=palette, width=0.5, fliersize=4)
        sns.stripplot(x='species', y=feature, data=df, ax=ax, color='black', alpha=0.3, jitter=0.2, size=4)
        ax.set_title(f"Distribution of {feature.title()}", fontsize=13, weight='bold', pad=10)
        ax.set_xlabel("Species", fontsize=11)
        ax.set_ylabel(feature, fontsize=11)
    fig.suptitle("Feature Box Plots with Observations across Iris Species", fontsize=16, weight='bold', y=0.98)
    plt.tight_layout()
    boxplots_path = os.path.join(outputs_dir, "feature_boxplots.png")
    fig.savefig(boxplots_path, dpi=300, bbox_inches='tight')
    fig.savefig(os.path.join(public_outputs_dir, "feature_boxplots.png"), dpi=300, bbox_inches='tight')
    plt.close(fig)

    # 3. Model Training & Splitting
    X = df[iris.feature_names]
    y = df['species']

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    print(f"Train samples: {len(X_train)}, Test samples: {len(X_test)}")

    # Model A: Logistic Regression with StandardScaler Pipeline
    lr_pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', LogisticRegression(max_iter=200, random_state=42))
    ])
    lr_pipeline.fit(X_train, y_train)
    y_pred_lr = lr_pipeline.predict(X_test)

    # Model B: Random Forest Classifier
    rf_clf = RandomForestClassifier(
        n_estimators=100,
        max_depth=4,
        random_state=42
    )
    rf_clf.fit(X_train, y_train)
    y_pred_rf = rf_clf.predict(X_test)

    # Confusion matrix plots
    labels = list(iris.target_names)

    # LR Confusion Matrix
    cm_lr = confusion_matrix(y_test, y_pred_lr, labels=labels)
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(cm_lr, annot=True, fmt='d', cmap='Blues', xticklabels=labels, yticklabels=labels, cbar=False, ax=ax, annot_kws={"size": 14, "weight": "bold"})
    ax.set_title("Confusion Matrix — Logistic Regression", fontsize=14, weight='bold', pad=12)
    ax.set_xlabel("Predicted Species", fontsize=11, weight='bold')
    ax.set_ylabel("True Species", fontsize=11, weight='bold')
    plt.tight_layout()
    cm_lr_path = os.path.join(outputs_dir, "confusion_matrix_logistic_regression.png")
    fig.savefig(cm_lr_path, dpi=300, bbox_inches='tight')
    fig.savefig(os.path.join(public_outputs_dir, "confusion_matrix_logistic_regression.png"), dpi=300, bbox_inches='tight')
    plt.close(fig)

    # RF Confusion Matrix
    cm_rf = confusion_matrix(y_test, y_pred_rf, labels=labels)
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(cm_rf, annot=True, fmt='d', cmap='Greens', xticklabels=labels, yticklabels=labels, cbar=False, ax=ax, annot_kws={"size": 14, "weight": "bold"})
    ax.set_title("Confusion Matrix — Random Forest", fontsize=14, weight='bold', pad=12)
    ax.set_xlabel("Predicted Species", fontsize=11, weight='bold')
    ax.set_ylabel("True Species", fontsize=11, weight='bold')
    plt.tight_layout()
    cm_rf_path = os.path.join(outputs_dir, "confusion_matrix_random_forest.png")
    fig.savefig(cm_rf_path, dpi=300, bbox_inches='tight')
    fig.savefig(os.path.join(public_outputs_dir, "confusion_matrix_random_forest.png"), dpi=300, bbox_inches='tight')
    plt.close(fig)

    # Metrics calculation
    metrics = {
        'Model': ['Logistic Regression (Pipeline)', 'Random Forest Classifier'],
        'Accuracy': [accuracy_score(y_test, y_pred_lr), accuracy_score(y_test, y_pred_rf)],
        'Macro Precision': [
            precision_score(y_test, y_pred_lr, average='macro'),
            precision_score(y_test, y_pred_rf, average='macro')
        ],
        'Macro Recall': [
            recall_score(y_test, y_pred_lr, average='macro'),
            recall_score(y_test, y_pred_rf, average='macro')
        ],
        'Macro F1-Score': [
            f1_score(y_test, y_pred_lr, average='macro'),
            f1_score(y_test, y_pred_rf, average='macro')
        ]
    }
    comparison_df = pd.DataFrame(metrics)
    print("\nModel Comparison Table:")
    print(comparison_df.to_string(index=False))

    # Model comparison plot
    fig, ax = plt.subplots(figsize=(10, 6))
    df_melted = pd.melt(comparison_df, id_vars=['Model'], var_name='Metric', value_name='Score')
    barplot = sns.barplot(data=df_melted, x='Metric', y='Score', hue='Model', palette=['#3b82f6', '#10b981'], ax=ax)
    ax.set_ylim(0, 1.15)
    ax.set_title("Model Performance Comparison (Test Set: 30 Samples)", fontsize=15, weight='bold', pad=14)
    ax.set_ylabel("Score (0.0 to 1.0)", fontsize=12, weight='bold')
    ax.set_xlabel("Evaluation Metric", fontsize=12, weight='bold')
    ax.legend(title="Classifier", loc='lower right', frameon=True)
    for p in barplot.patches:
        height = p.get_height()
        if not np.isnan(height) and height > 0:
            ax.annotate(f"{height:.3f}",
                        (p.get_x() + p.get_width() / 2., height),
                        ha='center', va='bottom',
                        xytext=(0, 4), textcoords='offset points',
                        fontsize=10, weight='bold')
    plt.tight_layout()
    comparison_path = os.path.join(outputs_dir, "model_comparison.png")
    fig.savefig(comparison_path, dpi=300, bbox_inches='tight')
    fig.savefig(os.path.join(public_outputs_dir, "model_comparison.png"), dpi=300, bbox_inches='tight')
    plt.close(fig)

    # Save summary json for frontend usage
    summary = {
        "dataset_stats": {
            "total_samples": int(len(df)),
            "n_features": 4,
            "features": iris.feature_names,
            "classes": list(iris.target_names),
            "class_counts": {str(k): int(v) for k, v in df['species'].value_counts().items()},
            "missing_values": int(df.isnull().sum().sum()),
            "duplicates": int(df.duplicated().sum()),
            "train_samples": int(len(X_train)),
            "test_samples": int(len(X_test))
        },
        "logistic_regression": {
            "accuracy": float(accuracy_score(y_test, y_pred_lr)),
            "precision_macro": float(precision_score(y_test, y_pred_lr, average='macro')),
            "recall_macro": float(recall_score(y_test, y_pred_lr, average='macro')),
            "f1_macro": float(f1_score(y_test, y_pred_lr, average='macro')),
            "confusion_matrix": cm_lr.tolist(),
            "classification_report": classification_report(y_test, y_pred_lr, target_names=labels, output_dict=True)
        },
        "random_forest": {
            "accuracy": float(accuracy_score(y_test, y_pred_rf)),
            "precision_macro": float(precision_score(y_test, y_pred_rf, average='macro')),
            "recall_macro": float(recall_score(y_test, y_pred_rf, average='macro')),
            "f1_macro": float(f1_score(y_test, y_pred_rf, average='macro')),
            "confusion_matrix": cm_rf.tolist(),
            "classification_report": classification_report(y_test, y_pred_rf, target_names=labels, output_dict=True),
            "feature_importances": {
                feat: round(float(imp), 4) for feat, imp in zip(iris.feature_names, rf_clf.feature_importances_)
            }
        },
        "test_ground_truth": list(y_test.values),
        "lr_predictions": list(y_pred_lr),
        "rf_predictions": list(y_pred_rf)
    }

    with open("src/data_summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    print("Project outputs successfully generated.")

if __name__ == "__main__":
    run()
