# Capturing Genuine Screenshots for Oasis Infobyte Submission

This folder is designated for your authentic execution screenshots when preparing your Oasis Infobyte Data Science Internship submission.

> **Important Policy**: Do not upload placeholder, fake, or synthetic mock screenshots. Oasis Infobyte evaluators look for authentic screenshots showing the Jupyter Notebook running on your local machine with visible cell execution counts (`[1]`, `[2]`, etc.) and system timestamps.

---

## Required Screenshots Checklist

Capture the following 4 to 6 genuine screenshots:

1. **`01_notebook_environment_launch.png`**
   - Terminal or Anaconda prompt showing `jupyter notebook` launched and running on `localhost:8888`.
2. **`02_eda_and_pairplot_cell.png`**
   - Jupyter Notebook browser window showing Section 4 (EDA output) and Section 5 (Pairplot rendered inline).
3. **`03_feature_boxplots_cell.png`**
   - Jupyter Notebook showing Section 5.3 (Feature boxplots for all 4 attributes with strip plot overlay).
4. **`04_model_training_and_confusion_matrices.png`**
   - Section 8 & 9 showing Logistic Regression and Random Forest training output and Seaborn confusion matrix heatmaps.
5. **`05_model_comparison_table_and_chart.png`**
   - Section 10 showing the model comparison DataFrame table and `model_comparison.png` bar chart.
6. **`06_terminal_git_commit.png` (Optional but recommended)**
   - Terminal showing `git status` or `git commit -m "Complete OIBSIP Task 1 Iris Flower Classification"` to demonstrate authentic version control.

---

## Step-by-Step Instructions by Operating System

### On Windows
1. Open your browser with the executed notebook `Iris_Flower_Classification.ipynb`.
2. Press `Windows Key + Shift + S` to open the Windows Snipping Tool.
3. Select the rectangular region covering the notebook cell and output (keep the browser tab and notebook header visible).
4. Save the image directly into this directory (`OIBSIP/DataScience/Task1_Iris_Flower_Classification/screenshots/`).

### On macOS
1. Open the executed notebook in your browser.
2. Press `Command + Shift + 4`, then drag over the notebook cell and outputs.
3. (Alternatively press `Command + Shift + 4` then `Spacebar` to capture the entire active browser window).
4. Move and rename the resulting screenshot file to this folder.

### On Linux (Ubuntu / Debian / Fedora)
1. Use `Shift + PrintScreen` or launch the `gnome-screenshot` utility.
2. Select the area and save as PNG in this folder.

---

## Embedding Screenshots into the Project README

Once captured and saved, reference them in the main project `README.md` using relative markdown links:

```markdown
### Execution Screenshot Preview
![EDA and Pairplot Execution](screenshots/02_eda_and_pairplot_cell.png)
![Model Evaluation](screenshots/04_model_training_and_confusion_matrices.png)
```
