# Iris Flower Classification — Oasis Infobyte Data Science Internship (OIBSIP)

![Python Version](https://img.shields.io/badge/Python-3.10%2B-blue.svg)
![Scikit-Learn](https://img.shields.io/badge/scikit--learn-1.2%2B-orange.svg)
![Pandas](https://img.shields.io/badge/pandas-2.0%2B-150458.svg)
![Status](https://img.shields.io/badge/Status-Completed-success.svg)
![Task](https://img.shields.io/badge/OIBSIP-Task%201-purple.svg)

---

## 1. Project Title & Overview

**Iris Flower Classification: End-to-End Supervised Machine Learning Benchmark**

This project fulfills **Task 1** of the Oasis Infobyte Data Science Internship program. It demonstrates a complete, reproducible machine learning workflow for classifying iris flowers into three biological species based on sepal and petal measurements.

---

## 2. Problem Statement

Botanists classify iris flowers by measuring morphological characteristics. Manually identifying physical varieties requires taxonomic expertise and can be error-prone. 

The goal of this project is to build an automated machine learning system that takes four continuous morphological attributes of an unknown iris specimen:
1. **Sepal Length (cm)**
2. **Sepal Width (cm)**
3. **Petal Length (cm)**
4. **Petal Width (cm)**

and accurately predicts its species among three target categories:
- **Iris Setosa**
- **Iris Versicolor**
- **Iris Virginica**

---

## 3. Project Objectives

- **Load Built-In Data**: Ingest the clean, canonical Iris dataset directly from `sklearn.datasets.load_iris` without external downloads.
- **Exploratory Data Analysis (EDA)**: Validate shape, data types, missing values, duplicates, and compute species-grouped summary statistics.
- **Statistical Visualization**: Create publication-grade pairplots, box plots with observation overlays, and correlation heatmaps.
- **Rigorous Data Preprocessing**: Partition data using an **80/20 stratified split** (`random_state=42`) with zero data leakage.
- **Model Training**: Build two distinct classifiers:
  1. *Model A*: Scaled **Logistic Regression** (using `StandardScaler` inside a scikit-learn `Pipeline`).
  2. *Model B*: **Random Forest Classifier** ($n=100$ estimators, tree depth constraint).
- **Evaluation**: Assess test set performance using Accuracy, Precision, Recall, F1-Score, and Confusion Matrix Heatmaps.
- **Comparison & Selection**: Formulate an objective comparison table and bar chart, justifying the best model.
- **Documentation**: Provide beginner-friendly guidance for computer engineering and data science students.

---

## 4. Dataset Details & Source

- **Source**: Directly loaded via `from sklearn.datasets import load_iris` (originally compiled by R.A. Fisher in 1936).
- **Total Samples**: 150 instances.
- **Target Distribution**: Perfectly balanced with 50 samples per species ($33.33\%$ each).
  - Class 0: `setosa` (50 samples)
  - Class 1: `versicolor` (50 samples)
  - Class 2: `virginica` (50 samples)
- **Features**: 4 continuous numeric measurements in centimeters (cm):
  - `sepal length (cm)`: Min $4.3$, Mean $5.84$, Max $7.9$
  - `sepal width (cm)`: Min $2.0$, Mean $3.06$, Max $4.4$
  - `petal length (cm)`: Min $1.0$, Mean $3.76$, Max $6.9$
  - `petal width (cm)`: Min $0.1$, Mean $1.20$, Max $2.5$
- **Data Quality**: 0 missing values, 1 natural duplicate record, 0 corrupted types.

---

## 5. Technology Stack

- **Programming Language**: Python 3.10+
- **Interactive Development**: Jupyter Notebook (`.ipynb`)
- **Data Manipulation**: `pandas`, `numpy`
- **Machine Learning**: `scikit-learn`
- **Data Visualization**: `matplotlib`, `seaborn`

---

## 6. Project Folder Structure

```
OIBSIP/
└── DataScience/
    └── Task1_Iris_Flower_Classification/
        ├── Iris_Flower_Classification.ipynb      # Complete executed Jupyter Notebook
        ├── README.md                             # Comprehensive project documentation
        ├── requirements.txt                      # Project dependencies
        ├── outputs/                              # Generated high-resolution visualization plots
        │   ├── pairplot.png
        │   ├── feature_boxplots.png
        │   ├── confusion_matrix_logistic_regression.png
        │   ├── confusion_matrix_random_forest.png
        │   └── model_comparison.png
        └── screenshots/                          # Guidelines for local execution capture
            └── README.md
```

---

## 7. Installation Instructions

Ensure you have Python 3.8+ installed on your system.

```bash
# 1. Clone or navigate to the project directory
cd OIBSIP/DataScience/Task1_Iris_Flower_Classification

# 2. (Recommended) Create and activate a Python virtual environment
python3 -m venv venv

# On Linux/macOS:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# 3. Upgrade pip and install required packages
pip install --upgrade pip
pip install -r requirements.txt
```

---

## 8. How to Launch Jupyter Notebook

Once dependencies are installed, launch the notebook server:

```bash
jupyter notebook
```

Your default web browser will open at `http://localhost:8888`. Navigate to `Iris_Flower_Classification.ipynb` and click **Kernel -> Restart & Run All** to execute the pipeline from top to bottom.

---

## 9. Workflow Explanation

```
┌──────────────────────────────────────┐
│  1. Load Dataset from scikit-learn   │ (150 rows, 4 numeric features, 1 target)
└──────────────────┬───────────────────┘
                   ▼
┌──────────────────────────────────────┐
│  2. Exploratory Data Analysis (EDA)  │ (Null checks, duplicate audit, group statistics)
└──────────────────┬───────────────────┘
                   ▼
┌──────────────────────────────────────┐
│  3. Statistical Visualizations       │ (Pairplot, feature boxplots, correlation heatmap)
└──────────────────┬───────────────────┘
                   ▼
┌──────────────────────────────────────┐
│  4. Stratified 80/20 Train-Test Split│ (Train=120 samples, Test=30 samples, stratify=y)
└──────────────────┬───────────────────┘
                   ▼
┌──────────────────────────────────────┐
│  5. Model Training (No Test Leakage) │ 
│   • Model A: StandardScaler + LR     │ (max_iter=200, random_state=42)
│   • Model B: Random Forest           │ (n_estimators=100, max_depth=4)
└──────────────────┬───────────────────┘
                   ▼
┌──────────────────────────────────────┐
│  6. Evaluation on Unseen Test Data   │ (Accuracy, Precision, Recall, F1, Confusion Matrix)
└──────────────────┬───────────────────┘
                   ▼
┌──────────────────────────────────────┐
│  7. Model Benchmarking & Selection   │ (Table summary & comparative visualization)
└──────────────────────────────────────┘
```

---

## 10. Models Trained & Evaluation Metrics

We trained two distinct algorithms on the identical training split ($N=120$):

1. **Model A: Logistic Regression with StandardScaler Pipeline**
   - Wrapped in a scikit-learn `Pipeline` to prevent test-set information leakage.
   - Standardizes features to mean $\mu = 0$ and standard deviation $\sigma = 1$.
   - Applies multinomial logistic regression with $L_2$ regularization.

2. **Model B: Random Forest Classifier**
   - Ensemble of 100 decorrelated decision trees (`n_estimators=100`, `max_depth=4`, `random_state=42`).
   - Non-parametric algorithm invariant to feature scaling.

### Metric Definitions:
- **Accuracy**: Overall proportion of correct predictions ($\frac{\text{Correct}}{\text{Total}}$).
- **Precision (Macro)**: Proportion of positive identifications that were correct across all classes without favoring frequent classes.
- **Recall (Macro)**: Proportion of actual positives identified correctly across all classes.
- **F1-Score (Macro)**: The harmonic mean of macro precision and macro recall:
  $$F_1 = 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$$

---

## 11. Actual Results from the Executed Notebook

Both models were evaluated on the **same held-out test set of 30 flowers** (10 Setosa, 10 Versicolor, 10 Virginica).

### Model Performance Summary:

| Classifier | Test Accuracy | Macro Precision | Macro Recall | Macro F1-Score | Status |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Random Forest Classifier** | **96.67% (0.9667)** | **0.9697** | **0.9667** | **0.9666** | **Best Performing** |
| **Logistic Regression (Pipeline)** | **93.33% (0.9333)** | **0.9333** | **0.9333** | **0.9333** | Strong Baseline |

### Detailed Classification Report (Random Forest Classifier):
```
              precision    recall  f1-score   support

      setosa       1.00      1.00      1.00        10
  versicolor       1.00      0.90      0.95        10
   virginica       0.91      1.00      0.95        10

    accuracy                           0.97        30
   macro avg       0.97      0.97      0.97        30
weighted avg       0.97      0.97      0.97        30
```

### Detailed Classification Report (Logistic Regression):
```
              precision    recall  f1-score   support

      setosa       1.00      1.00      1.00        10
  versicolor       0.90      0.90      0.90        10
   virginica       0.90      0.90      0.90        10

    accuracy                           0.93        30
   macro avg       0.93      0.93      0.93        30
weighted avg       0.93      0.93      0.93        30
```

*Note: The Random Forest correctly classified 29 out of 30 test samples, misclassifying only 1 borderline Versicolor flower as Virginica. Logistic Regression correctly classified 28 out of 30 flowers.*

---

## 12. Key Findings & Feature Selection

1. **Dominance of Petal Dimensions**:
   - `petal length (cm)` and `petal width (cm)` are the primary drivers of class separability.
   - In the Random Forest model, petal measurements accounted for **$84.68\%$** of total feature importance (Petal Length: $44.13\%$, Petal Width: $40.55\%$).
2. **Linear Separability of Setosa**:
   - Iris Setosa exhibits zero overlap in petal length ($1.0 - 1.9\text{ cm}$) compared to Versicolor ($3.0 - 5.1\text{ cm}$) and Virginica ($4.5 - 6.9\text{ cm}$).
   - Setosa achieved **$100\%$ precision and recall** in both models.
3. **Versicolor vs. Virginica Boundary**:
   - The decision boundary between Versicolor and Virginica involves subtle overlap in petal length around $4.8 - 5.1\text{ cm}$.
4. **Model Selection Verdict**:
   - **Random Forest Classifier is declared the best-performing model** on the held-out test set with $96.67\%$ test accuracy.
   - Its ensemble mechanism successfully handles the slight non-linearity between Versicolor and Virginica.
   - Scaled Logistic Regression remains a compelling lightweight alternative at $93.33\%$ accuracy for environments requiring immediate linear interpretability and low computational footprint.

---

## 13. Generated Visualizations

All visualizations are generated and saved at 300 DPI in the `outputs/` folder:

### 1. Feature Pairplot (Distributions & KDE Curves)
![Pairplot](outputs/pairplot.png)

### 2. Feature Box Plots Grouped by Species
![Feature Boxplots](outputs/feature_boxplots.png)

### 3. Confusion Matrix: Logistic Regression
![Logistic Regression Confusion Matrix](outputs/confusion_matrix_logistic_regression.png)

### 4. Confusion Matrix: Random Forest Classifier
![Random Forest Confusion Matrix](outputs/confusion_matrix_random_forest.png)

### 5. Model Comparison Bar Chart
![Model Comparison](outputs/model_comparison.png)

---

## 14. Limitations & Real-World Considerations

- **Small Sample Size**: 150 instances collected in 1936 is tiny compared to modern industrial datasets; performance may vary when exposed to diverse agricultural strains.
- **Controlled Lab Conditions**: Historical measurements were taken under controlled conditions; real-world photos or field sensor readings introduce environmental noise and angle distortions.
- **Educational Scope**: This project is structured as an internship benchmark to master supervised classification, EDA, metric interpretation, and reproducible pipeline construction.

---

## 15. Learning Outcomes

- Gained end-to-end experience with the scikit-learn classification workflow.
- Mastered stratified train-test splitting to protect class ratios.
- Learned how to prevent data leakage using `Pipeline` and `StandardScaler`.
- Interpreted multi-class confusion matrices and macro vs. weighted averaging.
- Generated publication-ready visualizations with Seaborn and Matplotlib.
- Documented data science artifacts suitable for technical internship portfolios.

---

## 16. Oasis Infobyte Submission Checklist

- [x] Dataset loaded directly from `sklearn.datasets.load_iris`
- [x] Complete EDA with shapes, types, null-checks, and descriptive stats
- [x] High-resolution pairplot generated and saved to `outputs/pairplot.png`
- [x] Feature box plots for all four attributes saved to `outputs/feature_boxplots.png`
- [x] In-depth feature selection discussion with empirical evidence
- [x] Stratified 80/20 train-test split (`random_state=42`)
- [x] Scaled Logistic Regression pipeline trained on training data only
- [x] Random Forest Classifier trained on training data only
- [x] Confusion matrix heatmaps saved to `outputs/`
- [x] Accuracy, Precision, Recall, and F1-score computed programmatically
- [x] Model comparison table and visualization saved to `outputs/model_comparison.png`
- [x] Best-performing model declared with objective technical justification
- [x] Beginner learning glossary provided
- [x] GitHub-ready README, requirements.txt, and screenshots guide included
