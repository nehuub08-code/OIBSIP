# Sales Prediction Using Python — Oasis Infobyte Data Science Internship (Task 5)

[![Python Version](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Scikit-Learn](https://img.shields.io/badge/Library-scikit--learn-orange.svg)](https://scikit-learn.org/)
[![Track](https://img.shields.io/badge/Track-Data%20Science-green.svg)](https://oasisinfobyte.com/)

An end-to-end Machine Learning regression project developed for the **Oasis Infobyte Internship Program (OIBSIP)** under the **Data Science Track**.

---

## Table of Contents
1. [Project Overview](#project-overview)
2. [Objective](#objective)
3. [Dataset Description & Source](#dataset-description--source)
4. [Technologies and Libraries](#technologies-and-libraries)
5. [Repository & Folder Structure](#repository--folder-structure)
6. [Installation & Setup](#installation--setup)
7. [Running the Jupyter Notebook](#running-the-jupyter-notebook)
8. [Methodology & Workflow](#methodology--workflow)
9. [Exploratory Data Analysis (EDA)](#exploratory-data-analysis-eda)
10. [Model Training](#model-training)
11. [Model Evaluation & Real Results](#model-evaluation--real-results)
12. [Actual vs. Predicted & Residual Analysis](#actual-vs-predicted--residual-analysis)
13. [Advertising Channel Impact Interpretation](#advertising-channel-impact-interpretation)
14. [Limitations](#limitations)
15. [Future Improvements](#future-improvements)
16. [Attribution & Acknowledgments](#attribution--acknowledgments)

---

## Project Overview

In the commercial landscape, advertising budget allocation is one of the most consequential decisions a business makes. Knowing how much revenue will result from investments in TV, Radio, or Newspaper advertising enables data-driven budget optimization and risk mitigation.

This project formulates **Sales Prediction** as a **Supervised Regression** task. By learning from historical advertising expenditure across media channels, we build and evaluate statistical and machine learning models capable of predicting continuous product sales volume accurately.

---

## Objective

- Predict product **Sales** (in thousands of units) based on advertising expenditure across three media platforms: **TV**, **Radio**, and **Newspaper** (in thousands of dollars).
- Understand the mathematical and empirical relationships between marketing investments and sales outcomes.
- Compare a baseline parametric model (**Multiple Linear Regression**) with a non-linear ensemble model (**Random Forest Regressor**).
- Identify which advertising channel possesses the highest predictive relationship with sales and provide actionable, honest business takeaways.

---

## Dataset Description & Source

- **Dataset Name:** Classic Advertising Expenditure Dataset (`Advertising.csv`).
- **Origin & Heritage:** Originates from the foundational statistical learning textbook *An Introduction to Statistical Learning with Applications in R* (ISLR) by Gareth James, Daniela Witten, Trevor Hastie, and Robert Tibshirani. Publicly available on Kaggle and GitHub educational repositories.
- **Records & Dimensions:** 200 observations (rows) and 4 operational variables (after dropping the exported row index column).
- **Data Integrity:** 0 missing values (`isnull().sum() == 0`), 0 duplicate records.

### Feature Specification
| Column Name | Type | Description | Unit of Measure |
|:---|:---:|:---|:---|
| **TV** | Numerical (float64) | Advertising spend on television broadcasts | Thousands of dollars ($000s) |
| **Radio** | Numerical (float64) | Advertising spend on radio broadcasts | Thousands of dollars ($000s) |
| **Newspaper** | Numerical (float64) | Advertising spend on print newspapers | Thousands of dollars ($000s) |
| **Sales** *(Target)* | Numerical (float64) | Product sales volume | Thousands of units |

---

## Technologies and Libraries

- **Language:** Python 3.10+
- **Data Manipulation:** `pandas`, `numpy`
- **Visualization:** `matplotlib`, `seaborn`
- **Machine Learning:** `scikit-learn` (`LinearRegression`, `RandomForestRegressor`, `train_test_split`, `metrics`)
- **Development Environment:** Jupyter Notebook (`.ipynb`)

---

## Repository & Folder Structure

```text
OIBSIP/
└── DataScience/
    └── Task5_Sales_Prediction/
        ├── data/
        │   └── Advertising.csv          # Authentic raw dataset
        ├── notebooks/
        │   └── Sales_Prediction.ipynb   # Fully annotated Jupyter Notebook
        ├── outputs/
        │   ├── pairplot.png             # Feature pairwise distribution plot
        │   ├── tv_vs_sales.png          # TV spend vs Sales scatter with trendline
        │   ├── radio_vs_sales.png       # Radio spend vs Sales scatter with trendline
        │   ├── newspaper_vs_sales.png   # Newspaper spend vs Sales scatter with trendline
        │   ├── correlation_heatmap.png  # Pearson correlation heatmap
        │   ├── model_comparison.png     # MAE, RMSE, and R² visual comparison
        │   ├── actual_vs_predicted.png  # Prediction accuracy scatter vs y=x line
        │   └── residual_plot.png        # Residual error diagnostic plot
        ├── README.md                    # Comprehensive project documentation
        └── requirements.txt             # Pip dependency specification
```

---

## Installation & Setup

1. **Clone the Repository:**
   ```bash
   git clone https://github.com/<your-username>/OIBSIP.git
   cd OIBSIP/DataScience/Task5_Sales_Prediction
   ```

2. **Create and Activate a Virtual Environment (Recommended):**
   ```bash
   python3 -m venv venv
   source venv/bin/activate    # On Windows: venv\Scripts\activate
   ```

3. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

---

## Running the Jupyter Notebook

To launch and step through the full analysis interactively:

```bash
jupyter notebook notebooks/Sales_Prediction.ipynb
```

Or open the directory in VS Code or JupyterLab and select your virtual environment kernel.

---

## Methodology & Workflow

The project follows a standard CRISP-DM / Machine Learning lifecycle:
1. **Problem Definition:** Establish continuous regression objective and delineate input features vs. target.
2. **Data Ingestion & Hygiene:** Load `Advertising.csv`, strip extraneous index columns (`Unnamed: 0`), standardize column capitalization, and verify zero nulls / duplicates.
3. **Exploratory Data Analysis (EDA):** Visualize distributions via pairplots, compute Pearson correlation coefficients, and isolate bivariate trendlines.
4. **Data Partitioning:** Split data into an **80% Training Set** (160 rows) and a **20% Testing Set** (40 rows) using a fixed random seed (`random_state=42`) to prevent data leakage.
5. **Baseline Modeling:** Train Multiple Linear Regression and extract parametric weights (intercept and slope coefficients).
6. **Ensemble Modeling:** Train a Random Forest Regressor to capture non-linearities and channel interaction effects.
7. **Empirical Evaluation:** Compute MAE, RMSE, and $R^2$ scores on unseen test data.
8. **Diagnostic Residual Analysis:** Verify error randomness around zero and inspect homoscedasticity.
9. **Channel Impact Analysis:** Contrast Pearson correlations, regression coefficients, and tree-based feature importances.

---

## Exploratory Data Analysis (EDA)

### 1. Pairwise Feature Distribution (Pairplot)
The pairplot illuminates the univariate density distributions along the diagonal (KDE) and bivariate relationships across off-diagonals.

![Pairplot](outputs/pairplot.png)

### 2. Individual Channel Relationships vs. Sales

| Channel | Pearson Correlation ($r$) | Visualization |
|:---:|:---:|:---:|
| **TV** | **0.782** (Strong Positive) | ![TV vs Sales](outputs/tv_vs_sales.png) |
| **Radio** | **0.576** (Moderate Positive) | ![Radio vs Sales](outputs/radio_vs_sales.png) |
| **Newspaper** | **0.228** (Weak Positive) | ![Newspaper vs Sales](outputs/newspaper_vs_sales.png) |

### 3. Correlation Heatmap
![Correlation Heatmap](outputs/correlation_heatmap.png)

**Key Observations:**
- **TV** exhibits the highest linear association with Sales ($r = 0.782$).
- **Radio** displays moderate positive linear association ($r = 0.576$).
- **Newspaper** shows weak association ($r = 0.228$) and moderate collinearity with Radio ($r = 0.354$), suggesting newspaper spend may be redundant when Radio is already included.

---

## Model Training

### 1. Baseline Model: Multiple Linear Regression
Linear Regression assumes an additive relationship:
$$\hat{y} = \beta_0 + \beta_1(\text{TV}) + \beta_2(\text{Radio}) + \beta_3(\text{Newspaper})$$

**Learned Parameters:**
- **Intercept ($\beta_0$):** `2.9791` (Baseline expected sales of ~2,979 units when zero advertising budget is expended).
- **$\beta_{\text{TV}}$:** `0.0447` (For every additional $1,000 spent on TV, sales increase by ~44.7 units, holding Radio & Newspaper constant).
- **$\beta_{\text{Radio}}$:** `0.1892` (For every additional $1,000 spent on Radio, sales increase by ~189.2 units, holding TV & Newspaper constant).
- **$\beta_{\text{Newspaper}}$:** `0.0028` (Negligible marginal contribution of ~2.8 units per $1,000 spent).

### 2. Non-Linear Model: Random Forest Regressor
Random Forest trains an ensemble of decision trees using bootstrap aggregating (bagging) and random feature subspace splitting. It captures non-linear saturation curves and synergistic interactions (e.g. TV exposure amplifying Radio ad recall).

---

## Model Evaluation & Real Results

Both models were evaluated on the identical 20% held-out test split (40 observations, `random_state=42`).

### Calculated Performance Metrics Table
| Model | Mean Absolute Error (MAE) | Root Mean Squared Error (RMSE) | $R^2$ Score |
|:---|:---:|:---:|:---:|
| **Linear Regression** | `1.4608` | `1.7816` | `0.8994` (89.9%) |
| **Random Forest Regressor** | **`0.6201`** | **`0.7686`** | **`0.9813`** (98.1%) |

*(All values are calculated from the executed code; no values are estimated or fabricated).*

![Model Comparison](outputs/model_comparison.png)

### Metric Interpretations:
1. **MAE:** Random Forest predictions deviate from actual sales by an average of only **620 units**, compared to **1,461 units** for Linear Regression.
2. **RMSE:** Random Forest cuts the root mean squared error by more than **56%** (from 1.7816 to 0.7686), demonstrating strong resistance to large outlier errors.
3. **$R^2$ Score:** Random Forest explains **98.13%** of the variance in test sales, outperforming Linear Regression's **89.94%**.

**Winning Model:** **Random Forest Regressor** is chosen as the superior model for production predictions.

---

## Actual vs. Predicted & Residual Analysis

### Actual vs. Predicted Sales
The scatter plot below compares actual test sales to Random Forest predictions against the red $y = x$ reference line:

![Actual vs Predicted](outputs/actual_vs_predicted.png)

The tight clustering along the 45-degree diagonal confirms excellent predictive fidelity across low, medium, and high sales volumes.

### Residual Analysis
Residuals represent prediction errors ($\text{Residual} = y - \hat{y}$):

![Residual Plot](outputs/residual_plot.png)

**Interpretation:**
- Errors are evenly distributed around the horizontal zero line.
- No heavy funnel shape (heteroscedasticity) or pronounced parabolic curves are observed.
- Small residual magnitudes ($\pm 1.5$ units) confirm the model does not suffer from systematic under-prediction or over-prediction bias.

---

## Advertising Channel Impact Interpretation

Which channel has the highest impact on predicted sales? The answer depends on the analytical dimension examined:

| Channel | Pearson Correlation ($r$) | Linear Reg Coef ($\beta$) | RF Feature Importance | Primary Insight |
|:---|:---:|:---:|:---:|:---|
| **TV** | **0.7822** *(1st)* | `0.0447` | **62.48%** *(1st)* | **Strongest overall driver** of sales variance and baseline volume. |
| **Radio** | `0.5762` *(2nd)* | **0.1892** *(1st)* | **36.22%** *(2nd)* | **Highest marginal efficiency** per dollar spent. |
| **Newspaper** | `0.2283` *(3rd)* | `0.0028` *(3rd)* | **1.30%** *(3rd)* | **Negligible impact**; low correlation, near-zero coefficient and importance. |

### Why do TV and Radio have differing "highest impact" metrics?
- **TV** operates over a massive budget scale ($0.7k to $296.4k) and drives over **62% of the total variance** in sales.
- **Radio** operates on a smaller budget scale ($0.0k to $49.6k), but yields a higher unit slope ($\beta = 0.1892$ vs $0.0447$). Each incremental thousand dollars into Radio yields more units sold, but only up to its saturation ceiling.
- **Newspaper** advertising can safely be de-emphasized in marketing budgets without materially hurting projected sales.

> **Caution on Causation:** These findings reflect statistical relationships within this historical dataset. In real-world enterprise marketing, external factors (seasonality, macroeconomic sentiment, product pricing, creative copy quality) also influence conversion.

---

## Limitations

1. **Static Cross-Sectional Data:** The dataset contains 200 static records without timestamps, preventing time-series modeling of ad-stock carryover (delayed impact of ads).
2. **Absence of Confounding Variables:** Key market drivers such as product price changes, competitor ad campaigns, and seasonal holidays are not captured.
3. **Diminishing Returns Ceiling:** While Random Forest models non-linearities, extrapolation beyond the historical spend range ($>\$300\text{k}$) is unreliable.

---

## Future Improvements

1. **Time-Series Ad-Stock Modeling:** Incorporate memory decay decay curves ($\lambda$) to model how yesterday's TV ads affect next week's sales.
2. **Hyperparameter Tuning:** Apply `GridSearchCV` or Bayesian Optimization on Random Forest (`n_estimators`, `max_depth`, `min_samples_split`).
3. **Interactive Budget Simulator:** A live Streamlit / React web interface allowing marketing managers to slide channel allocations and view real-time sales forecasts with confidence intervals.

---

## Attribution & Acknowledgments

- **Internship Program:** [Oasis Infobyte (OIBSIP)](https://oasisinfobyte.com/)
- **Track:** Data Science
- **Task:** Task 5 — Sales Prediction Using Python
- **Original Dataset:** *An Introduction to Statistical Learning* (James, Witten, Hastie, Tibshirani)
