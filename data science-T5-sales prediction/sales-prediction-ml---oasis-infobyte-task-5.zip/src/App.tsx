import React, { useState } from 'react';
import { Header } from './components/Header';
import { RepoStructureModal } from './components/RepoStructureModal';
import { OverviewTab } from './components/OverviewTab';
import { EdaGalleryTab } from './components/EdaGalleryTab';
import { DataExplorerTab } from './components/DataExplorerTab';
import { ModelComparisonTab } from './components/ModelComparisonTab';
import { SimulatorTab } from './components/SimulatorTab';
import { ResidualsTab } from './components/ResidualsTab';
import { ChannelImpactTab } from './components/ChannelImpactTab';
import { InternshipPrepTab } from './components/InternshipPrepTab';
import { NotebookTab } from './components/NotebookTab';
import mlResultsRaw from './data/ml_results.json';
import { MLResultsSummary } from './types';
import { LayoutDashboard, BarChart3, Database, GitCompare, Sliders, Activity, Compass, BookOpen, FileCode } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [isRepoModalOpen, setIsRepoModalOpen] = useState<boolean>(false);

  const results = mlResultsRaw as MLResultsSummary;

  const tabs = [
    { id: 'overview', label: 'Executive Summary', icon: LayoutDashboard },
    { id: 'eda', label: 'EDA & Visualizations', icon: BarChart3 },
    { id: 'data', label: 'Dataset Explorer', icon: Database },
    { id: 'comparison', label: 'Model Evaluation', icon: GitCompare },
    { id: 'simulator', label: 'Budget Simulator', icon: Sliders },
    { id: 'residuals', label: 'Residual Diagnostics', icon: Activity },
    { id: 'impact', label: 'Channel Impact', icon: Compass },
    { id: 'prep', label: 'Internship Defense', icon: BookOpen },
    { id: 'notebook', label: 'Notebook Code', icon: FileCode },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800 antialiased selection:bg-blue-100 selection:text-blue-900">
      {/* Top Application Header */}
      <Header onOpenRepoModal={() => setIsRepoModalOpen(true)} />

      {/* Navigation Sub-header Bar (Segmented Controls) */}
      <div className="border-b border-slate-200 bg-white sticky top-[89px] sm:top-[73px] z-20 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <nav className="flex space-x-1 overflow-x-auto py-2 no-scrollbar" aria-label="Tabs">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-md whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-blue-400' : 'text-slate-500'}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Main Tab Content Canvas */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8">
        {activeTab === 'overview' && (
          <OverviewTab results={results} onNavigateTab={(tabId) => setActiveTab(tabId)} />
        )}
        {activeTab === 'eda' && <EdaGalleryTab results={results} />}
        {activeTab === 'data' && <DataExplorerTab />}
        {activeTab === 'comparison' && (
          <ModelComparisonTab results={results} onNavigateTab={(tabId) => setActiveTab(tabId)} />
        )}
        {activeTab === 'simulator' && <SimulatorTab results={results} />}
        {activeTab === 'residuals' && <ResidualsTab results={results} />}
        {activeTab === 'impact' && <ChannelImpactTab results={results} />}
        {activeTab === 'prep' && <InternshipPrepTab />}
        {activeTab === 'notebook' && <NotebookTab />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 mt-12 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Oasis Infobyte Internship Program</span>
            <span aria-hidden="true">·</span>
            <span>Data Science Track — Task 5</span>
            <span aria-hidden="true">·</span>
            <span>Sales Prediction Using Python</span>
          </div>

          <div className="flex items-center gap-3">
            <span>ISLR Advertising Benchmark (200 records)</span>
            <span aria-hidden="true">·</span>
            <span>scikit-learn 1.7.2</span>
            <span aria-hidden="true">·</span>
            <span>Python 3.10</span>
          </div>
        </div>
      </footer>

      {/* Folder Structure Modal */}
      <RepoStructureModal isOpen={isRepoModalOpen} onClose={() => setIsRepoModalOpen(false)} />
    </div>
  );
}
