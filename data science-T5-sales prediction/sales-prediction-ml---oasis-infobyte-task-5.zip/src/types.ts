export interface AdvertisingRecord {
  TV: number;
  Radio: number;
  Newspaper: number;
  Sales: number;
}

export interface ModelMetrics {
  mae: number;
  rmse: number;
  r2: number;
}

export interface LinearRegressionData extends ModelMetrics {
  intercept: number;
  coefficients: {
    TV: number;
    Radio: number;
    Newspaper: number;
  };
}

export interface RandomForestData extends ModelMetrics {
  feature_importances: {
    TV: number;
    Radio: number;
    Newspaper: number;
  };
}

export interface SamplePrediction {
  index: number;
  tv: number;
  radio: number;
  newspaper: number;
  actual_sales: number;
  lr_pred: number;
  rf_pred: number;
  residual: number;
}

export interface MLResultsSummary {
  summary: {
    total_samples: number;
    features: string[];
    target: string;
    train_samples: number;
    test_samples: number;
    best_model: string;
  };
  correlations: {
    TV: Record<string, number>;
    Radio: Record<string, number>;
    Newspaper: Record<string, number>;
    Sales: Record<string, number>;
  };
  linear_regression: LinearRegressionData;
  random_forest: RandomForestData;
  sample_test_predictions: SamplePrediction[];
}
