import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, Terminal, BookOpen, Check, Copy } from 'lucide-react';

export const InternshipPrepTab: React.FC = () => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const questions = [
    {
      q: "1. Why is this project formulated as Regression rather than Classification?",
      a: "In Machine Learning, problems are divided based on the nature of the target variable. In our dataset, 'Sales' is a continuous numerical measurement (thousands of units sold, ranging continuously from 1.6k to 27.0k units). Classification algorithms predict discrete class categories (e.g., Yes/No, Low/Medium/High), whereas Regression models estimate exact continuous numerical quantities."
    },
    {
      q: "2. Why does Radio have a higher Linear Regression coefficient than TV, while TV has a much higher correlation and feature importance?",
      a: "This is one of the most critical questions in data science! The coefficient in Multiple Linear Regression measures the marginal rate of return per unit increase ($1,000) holding other variables constant. Radio has a high unit slope (+0.189 sales per $1k) because it is very efficient per dollar. However, Radio spending in the dataset is small (max $50k), while TV spending spans up to $300k. Because TV spans a huge budget range and accounts for the largest share of overall sales variance (r = 0.782), Random Forest assigns TV 62.5% feature importance and Radio 36.2%."
    },
    {
      q: "3. What does the Linear Regression intercept (β₀ = 2.9791) represent?",
      a: "The intercept β₀ represents the expected baseline product sales (~2,979 units) when zero advertising budget is spent across all three media channels (TV = 0, Radio = 0, Newspaper = 0). This baseline can reflect organic word-of-mouth demand, existing brand awareness, or repeat customer purchases."
    },
    {
      q: "4. What is the difference between MAE and RMSE, and why does Random Forest perform better?",
      a: "MAE (Mean Absolute Error) is the average absolute difference between predicted and actual values—it treats all errors linearly. RMSE (Root Mean Squared Error) squares errors before averaging, penalizing large outlier errors much more heavily. Random Forest reduced MAE from 1.46 to 0.62 and RMSE from 1.78 to 0.77. Random Forest performs significantly better because it captures non-linear relationships and synergy: when high TV spending is paired with high Radio spending, sales spike non-linearly, which a straight linear hyper-plane cannot fit."
    },
    {
      q: "5. How did you prevent data leakage during model training?",
      a: "Data leakage occurs when information from the evaluation data contaminates the training phase. We strictly partitioned the dataset into an 80% training set (160 rows) and a 20% test set (40 rows) using a fixed random seed (random_state=42). Both models were fitted solely on the training data, and all final evaluation metrics (MAE, RMSE, R²) were calculated exclusively on the held-out test data."
    },
    {
      q: "6. Why did Newspaper perform so poorly (weak correlation, 0.0028 coefficient, 1.3% importance)?",
      a: "Newspaper exhibited moderate collinearity with Radio (r = 0.3541). In historical markets where companies spent heavily on Radio, they also spent on Newspapers. When both are entered into Multiple Linear Regression, the model attributes the predictive power to Radio, leaving Newspaper with a near-zero slope (0.0028). In practice, Newspaper ad spend provides negligible incremental predictive value."
    },
    {
      q: "7. Does this model prove that increasing TV ad spend causes sales to increase?",
      a: "No! A fundamental tenet of statistics is that correlation and regression association do not establish causal proof. The model establishes strong predictive correlation within this historical dataset. In real business operations, creative ad quality, seasonal holidays, product pricing, competitor counter-campaigns, and macroeconomic conditions influence actual causal outcomes."
    },
    {
      q: "8. What are the main limitations of this dataset, and how would you improve it?",
      a: "First, it contains only 200 static cross-sectional records with no timestamps, preventing time-series modeling of ad-stock decay (the delayed carryover effect of TV ads over weeks). Second, it lacks confounding variables like product price and competitor spending. In a future production iteration, I would implement time-series regression with ad-stock transformations and perform cross-validated Bayesian hyperparameter tuning."
    }
  ];

  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Intro */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-bold text-slate-900">Internship Review & Interview Defense Guide</h2>
          </div>
          <p className="text-xs text-slate-600 mt-1">
            Senior mentor crib sheet for confidently presenting Oasis Infobyte Task 5 during evaluations, interviews, and project reviews.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 px-3 py-2 rounded-lg border border-slate-200">
          <span>8 Core Technical Defense Questions</span>
        </div>
      </div>

      {/* Terminal Launch Commands */}
      <div className="bg-slate-900 text-slate-200 p-6 rounded-xl shadow-xs space-y-4 font-mono text-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2 text-slate-300 font-bold">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span>Terminal Setup & Execution Commands (For Reviewer)</span>
          </div>
          <span className="text-[11px] text-slate-500 font-sans">Tested on Python 3.10+</span>
        </div>

        <div className="space-y-3">
          <div>
            <div className="text-slate-400 text-[11px] mb-1 font-sans">Step 1: Clone repo and navigate to task directory</div>
            <div className="flex items-center justify-between bg-slate-950 p-2.5 rounded border border-slate-800">
              <code>cd OIBSIP/DataScience/Task5_Sales_Prediction</code>
              <button
                onClick={() => copyToClipboard('cd OIBSIP/DataScience/Task5_Sales_Prediction', 'cmd1')}
                className="text-slate-400 hover:text-white transition-colors"
                title="Copy command"
              >
                {copiedCmd === 'cmd1' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <div>
            <div className="text-slate-400 text-[11px] mb-1 font-sans">Step 2: Install dependencies from requirements.txt</div>
            <div className="flex items-center justify-between bg-slate-950 p-2.5 rounded border border-slate-800">
              <code>pip install -r requirements.txt</code>
              <button
                onClick={() => copyToClipboard('pip install -r requirements.txt', 'cmd2')}
                className="text-slate-400 hover:text-white transition-colors"
                title="Copy command"
              >
                {copiedCmd === 'cmd2' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <div>
            <div className="text-slate-400 text-[11px] mb-1 font-sans">Step 3: Launch Jupyter Notebook interactively</div>
            <div className="flex items-center justify-between bg-slate-950 p-2.5 rounded border border-slate-800">
              <code>jupyter notebook notebooks/Sales_Prediction.ipynb</code>
              <button
                onClick={() => copyToClipboard('jupyter notebook notebooks/Sales_Prediction.ipynb', 'cmd3')}
                className="text-slate-400 hover:text-white transition-colors"
                title="Copy command"
              >
                {copiedCmd === 'cmd3' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Accordion of Interview Questions */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs divide-y divide-slate-100 overflow-hidden">
        {questions.map((item, idx) => {
          const isOpen = expandedIndex === idx;
          return (
            <div key={idx} className="transition-colors">
              <button
                onClick={() => setExpandedIndex(isOpen ? null : idx)}
                className="w-full text-left p-5 flex items-center justify-between gap-4 hover:bg-slate-50 transition-colors"
              >
                <span className="font-semibold text-sm text-slate-900">{item.q}</span>
                {isOpen ? (
                  <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                )}
              </button>

              {isOpen && (
                <div className="px-5 pb-5 pt-1 text-xs text-slate-700 leading-relaxed bg-slate-50/50">
                  <div className="p-4 bg-white rounded-lg border border-slate-200 text-slate-700 leading-relaxed">
                    <strong className="text-blue-900 block mb-1">Recommended Response:</strong>
                    {item.a}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
