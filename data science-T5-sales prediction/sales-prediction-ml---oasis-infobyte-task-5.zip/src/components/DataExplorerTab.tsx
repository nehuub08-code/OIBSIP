import React, { useState, useMemo } from 'react';
import { Search, ArrowUpDown, Download, Filter, Database, CheckCircle2 } from 'lucide-react';
import advertisingDataRaw from '../data/advertising_data.json';
import { AdvertisingRecord } from '../types';

export const DataExplorerTab: React.FC = () => {
  const data = advertisingDataRaw as AdvertisingRecord[];
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof AdvertisingRecord>('Sales');
  const [sortAsc, setSortAsc] = useState(false);
  const [page, setPage] = useState(1);
  const rowsPerPage = 15;

  // Compute descriptive statistics dynamically
  const stats = useMemo(() => {
    const keys: (keyof AdvertisingRecord)[] = ['TV', 'Radio', 'Newspaper', 'Sales'];
    const result: Record<string, { mean: number; std: number; min: number; max: number; median: number }> = {};

    keys.forEach((k) => {
      const vals = data.map((d) => d[k]).sort((a, b) => a - b);
      const sum = vals.reduce((acc, v) => acc + v, 0);
      const mean = sum / vals.length;
      const variance = vals.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / vals.length;
      const std = Math.sqrt(variance);
      const min = vals[0];
      const max = vals[vals.length - 1];
      const median = vals[Math.floor(vals.length / 2)];
      result[k] = { mean, std, min, max, median };
    });

    return result;
  }, [data]);

  // Filter and sort
  const filteredData = useMemo(() => {
    return data
      .filter((row) => {
        if (!searchTerm) return true;
        const term = searchTerm.toLowerCase();
        return (
          row.TV.toString().includes(term) ||
          row.Radio.toString().includes(term) ||
          row.Newspaper.toString().includes(term) ||
          row.Sales.toString().includes(term)
        );
      })
      .sort((a, b) => {
        const valA = a[sortField];
        const valB = b[sortField];
        return sortAsc ? valA - valB : valB - valA;
      });
  }, [data, searchTerm, sortField, sortAsc]);

  const totalPages = Math.ceil(filteredData.length / rowsPerPage);
  const paginatedData = useMemo(() => {
    const start = (page - 1) * rowsPerPage;
    return filteredData.slice(start, start + rowsPerPage);
  }, [filteredData, page]);

  const handleSort = (field: keyof AdvertisingRecord) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
    setPage(1);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Database className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-bold text-slate-900">Dataset Explorer & Statistical Summary</h2>
          </div>
          <p className="text-xs text-slate-600 mt-1">
            Real historical observations from the classic Advertising dataset (200 records, 3 features, 1 continuous target).
          </p>
        </div>

        <a
          href="/Advertising.csv"
          download="Advertising.csv"
          className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export CSV</span>
        </a>
      </div>

      {/* Summary Statistics Table */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900">Descriptive Statistics (Pandas describe() equivalent)</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Metric</th>
                <th className="py-3 px-4">TV Spend ($000s)</th>
                <th className="py-3 px-4">Radio Spend ($000s)</th>
                <th className="py-3 px-4">Newspaper Spend ($000s)</th>
                <th className="py-3 px-4 text-blue-700 font-bold">Sales (000s units)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700 font-mono">
              <tr>
                <td className="py-2.5 px-4 font-sans font-medium text-slate-900">Count</td>
                <td className="py-2.5 px-4">200</td>
                <td className="py-2.5 px-4">200</td>
                <td className="py-2.5 px-4">200</td>
                <td className="py-2.5 px-4 text-blue-700 font-bold">200</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-sans font-medium text-slate-900">Mean (μ)</td>
                <td className="py-2.5 px-4">{stats.TV.mean.toFixed(2)}</td>
                <td className="py-2.5 px-4">{stats.Radio.mean.toFixed(2)}</td>
                <td className="py-2.5 px-4">{stats.Newspaper.mean.toFixed(2)}</td>
                <td className="py-2.5 px-4 text-blue-700 font-bold">{stats.Sales.mean.toFixed(2)}</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-sans font-medium text-slate-900">Std Dev (σ)</td>
                <td className="py-2.5 px-4">{stats.TV.std.toFixed(2)}</td>
                <td className="py-2.5 px-4">{stats.Radio.std.toFixed(2)}</td>
                <td className="py-2.5 px-4">{stats.Newspaper.std.toFixed(2)}</td>
                <td className="py-2.5 px-4 text-blue-700 font-bold">{stats.Sales.std.toFixed(2)}</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-sans font-medium text-slate-900">Min</td>
                <td className="py-2.5 px-4">{stats.TV.min.toFixed(1)}</td>
                <td className="py-2.5 px-4">{stats.Radio.min.toFixed(1)}</td>
                <td className="py-2.5 px-4">{stats.Newspaper.min.toFixed(1)}</td>
                <td className="py-2.5 px-4 text-blue-700 font-bold">{stats.Sales.min.toFixed(1)}</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-sans font-medium text-slate-900">Median (50%)</td>
                <td className="py-2.5 px-4">{stats.TV.median.toFixed(1)}</td>
                <td className="py-2.5 px-4">{stats.Radio.median.toFixed(1)}</td>
                <td className="py-2.5 px-4">{stats.Newspaper.median.toFixed(1)}</td>
                <td className="py-2.5 px-4 text-blue-700 font-bold">{stats.Sales.median.toFixed(1)}</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-sans font-medium text-slate-900">Max</td>
                <td className="py-2.5 px-4">{stats.TV.max.toFixed(1)}</td>
                <td className="py-2.5 px-4">{stats.Radio.max.toFixed(1)}</td>
                <td className="py-2.5 px-4">{stats.Newspaper.max.toFixed(1)}</td>
                <td className="py-2.5 px-4 text-blue-700 font-bold">{stats.Sales.max.toFixed(1)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Interactive Data Table */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-slate-900">Dataset Records (200 rows)</h3>
            <span className="text-xs text-slate-500">Showing {filteredData.length} records matching current filter</span>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search values..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setPage(1);
              }}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-800"
            />
          </div>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-lg">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 w-16">Row</th>
                <th
                  onClick={() => handleSort('TV')}
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors"
                >
                  <div className="flex items-center gap-1.5">
                    <span>TV ($000s)</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('Radio')}
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Radio ($000s)</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('Newspaper')}
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Newspaper ($000s)</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('Sales')}
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors text-blue-700"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Sales (000s units)</span>
                    <ArrowUpDown className="w-3 h-3 text-blue-500" />
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {paginatedData.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-2.5 px-4 text-slate-400">{(page - 1) * rowsPerPage + idx + 1}</td>
                  <td className="py-2.5 px-4 text-slate-900">${row.TV.toFixed(1)}k</td>
                  <td className="py-2.5 px-4 text-slate-900">${row.Radio.toFixed(1)}k</td>
                  <td className="py-2.5 px-4 text-slate-900">${row.Newspaper.toFixed(1)}k</td>
                  <td className="py-2.5 px-4 font-bold text-blue-700">{row.Sales.toFixed(1)}k</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between text-xs text-slate-600 pt-2">
          <div>
            Page {page} of {Math.max(1, totalPages)}
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 disabled:cursor-not-allowed rounded-md font-medium text-slate-700 transition-colors"
            >
              Previous
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages || totalPages === 0}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 disabled:cursor-not-allowed rounded-md font-medium text-slate-700 transition-colors"
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
