import React, { useState } from 'react';
import { FileCode, Download, ExternalLink, Code2, Check, BookOpen } from 'lucide-react';

export const NotebookTab: React.FC = () => {
  const [activeSection, setActiveSection] = useState<number>(1);

  const sections = [
    {
      id: 1,
      title: 'Section 1: Introduction & Problem Formulation',
      badge: 'Theory & Scope',
      content: (
        <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
          <p>
            Explains sales prediction, advertising expenditure across TV, Radio, and Newspaper, and why regression is the appropriate formulation instead of classification (predicting a continuous sales quantity rather than discrete categories).
          </p>
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 font-mono text-[11px] text-slate-800">
            <div>Target Variable: Sales (thousands of units)</div>
            <div>Features Matrix: TV, Radio, Newspaper (thousands of dollars spend)</div>
          </div>
        </div>
      )
    },
    {
      id: 2,
      title: 'Section 2: Import Libraries',
      badge: 'Setup',
      content: (
        <div className="space-y-2">
          <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg font-mono text-xs overflow-x-auto">
{`import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score`}
          </pre>
        </div>
      )
    },
    {
      id: 3,
      title: 'Section 3: Load and Understand Data',
      badge: 'Data Hygiene',
      content: (
        <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
          <p>Loads <code>Advertising.csv</code>, inspects <code>head()</code>, <code>shape</code> (200, 5), drops exported index column <code>Unnamed: 0</code>, checks <code>info()</code>, <code>isnull().sum()</code> (0 nulls), and computes <code>describe()</code>.</p>
          <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg font-mono text-xs overflow-x-auto">
{`df_raw = pd.read_csv('../data/Advertising.csv')
if 'Unnamed: 0' in df_raw.columns:
    df = df_raw.drop(columns=['Unnamed: 0'])
df.columns = [col.capitalize() for col in df.columns]
print("Shape:", df.shape) # (200, 4)
print("Missing values:", df.isnull().sum().to_dict()) # Zero missing`}
          </pre>
        </div>
      )
    },
    {
      id: 4,
      title: 'Section 4: Exploratory Data Analysis (EDA)',
      badge: 'Visualization',
      content: (
        <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
          <p>Generates pairplot, three individual scatter plots with OLS regression lines for TV, Radio, and Newspaper vs. Sales, and the Pearson correlation matrix heatmap.</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
              <strong className="text-slate-900 block mb-1">Generated Figures:</strong>
              <ul className="list-disc pl-4 text-slate-600 space-y-1">
                <li><code>pairplot.png</code></li>
                <li><code>tv_vs_sales.png</code> (r = 0.782)</li>
                <li><code>radio_vs_sales.png</code> (r = 0.576)</li>
                <li><code>newspaper_vs_sales.png</code> (r = 0.228)</li>
                <li><code>correlation_heatmap.png</code></li>
              </ul>
            </div>
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-900">
              <strong className="block mb-1">Statistical Note:</strong>
              Pearson correlation measures linear association; correlation does not imply causality.
            </div>
          </div>
        </div>
      )
    },
    {
      id: 5,
      title: 'Section 5: Prepare Data (Train/Test Split)',
      badge: 'Partitioning',
      content: (
        <div className="space-y-2">
          <p className="text-xs text-slate-600">80/20 train/test split with seed 42 to prevent data leakage.</p>
          <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg font-mono text-xs overflow-x-auto">
{`X = df[['TV', 'Radio', 'Newspaper']]
y = df['Sales']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
# Training set: 160 observations; Testing set: 40 observations`}
          </pre>
        </div>
      )
    },
    {
      id: 6,
      title: 'Section 6: Baseline Linear Regression',
      badge: 'Baseline Model',
      content: (
        <div className="space-y-2 text-xs text-slate-700">
          <p>Fits Ordinary Least Squares, prints equation and sample predictions:</p>
          <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg font-mono text-xs overflow-x-auto">
{`lr = LinearRegression()
lr.fit(X_train, y_train)

# Output Learned Equation:
# Predicted Sales = 2.9791 + (0.0447 * TV) + (0.1892 * Radio) + (0.0028 * Newspaper)`}
          </pre>
        </div>
      )
    },
    {
      id: 7,
      title: 'Section 7: Random Forest Regressor',
      badge: 'Ensemble Model',
      content: (
        <div className="space-y-2 text-xs text-slate-700">
          <p>Trains Random Forest Regressor with <code>random_state=42</code> on identical training split to model non-linear interactions.</p>
          <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg font-mono text-xs overflow-x-auto">
{`rf = RandomForestRegressor(random_state=42)
rf.fit(X_train, y_train)
rf_preds = rf.predict(X_test)`}
          </pre>
        </div>
      )
    },
    {
      id: 8,
      title: 'Section 8: Model Evaluation & Comparison',
      badge: 'Empirical Metrics',
      content: (
        <div className="space-y-2 text-xs text-slate-700">
          <p>Computes MAE, RMSE, and R² score for both models on unseen test observations:</p>
          <div className="overflow-x-auto">
            <table className="w-full border border-slate-200 text-xs">
              <thead className="bg-slate-100 font-semibold">
                <tr>
                  <th className="p-2 text-left">Model</th>
                  <th className="p-2 text-left">MAE</th>
                  <th className="p-2 text-left">RMSE</th>
                  <th className="p-2 text-left">R² Score</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                <tr>
                  <td className="p-2 font-sans font-medium">Linear Regression</td>
                  <td className="p-2">1.4608</td>
                  <td className="p-2">1.7816</td>
                  <td className="p-2">0.8994</td>
                </tr>
                <tr className="bg-emerald-50/50">
                  <td className="p-2 font-sans font-bold text-emerald-800">Random Forest Regressor</td>
                  <td className="p-2 font-bold text-emerald-700">0.6201</td>
                  <td className="p-2 font-bold text-emerald-700">0.7686</td>
                  <td className="p-2 font-bold text-emerald-700">0.9813</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )
    },
    {
      id: 9,
      title: 'Section 9: Actual vs. Predicted Sales',
      badge: 'Fidelity Plot',
      content: (
        <div className="space-y-2 text-xs text-slate-700">
          <p>Plots test ground truth vs. Random Forest predictions against red perfect-fit trajectory line (saved to <code>outputs/actual_vs_predicted.png</code>).</p>
        </div>
      )
    },
    {
      id: 10,
      title: 'Section 10: Residual Analysis',
      badge: 'Diagnostics',
      content: (
        <div className="space-y-2 text-xs text-slate-700">
          <p>Plots residuals (y - ŷ) centered around zero horizontal line (saved to <code>outputs/residual_plot.png</code>) to diagnose bias and homoscedasticity.</p>
        </div>
      )
    },
    {
      id: 11,
      title: 'Section 11: Advertising Channel Impact',
      badge: 'Impact Analysis',
      content: (
        <div className="space-y-2 text-xs text-slate-700">
          <p>Contrasts TV (highest correlation 0.782, highest RF importance 62.5%) against Radio (highest unit slope 0.1892) and Newspaper (1.3% importance), with rigorous warning distinguishing correlation vs. causality.</p>
        </div>
      )
    },
    {
      id: 12,
      title: 'Section 12: Final Conclusion & Limitations',
      badge: 'Executive Synthesis',
      content: (
        <div className="space-y-2 text-xs text-slate-700">
          <p>Final project conclusion summarizing methodology, real empirical metrics, business marketing budget recommendations, and future improvements (time-series ad-stock decay modeling).</p>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Banner */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <FileCode className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-bold text-slate-900">Jupyter Notebook Structure & Execution Walkthrough</h2>
          </div>
          <p className="text-xs text-slate-600 mt-1">
            Browse the 12 structured sections of <code className="bg-slate-100 px-1 py-0.5 rounded text-blue-700 font-mono">Sales_Prediction.ipynb</code>, executed end-to-end with zero errors.
          </p>
        </div>

        <a
          href="/Sales_Prediction.ipynb"
          download="Sales_Prediction.ipynb"
          className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-md shadow-xs transition-colors shrink-0"
        >
          <Download className="w-4 h-4" />
          <span>Download Executed .ipynb File</span>
        </a>
      </div>

      {/* Two Column Layout: Section List + Section Content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Navigation (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wide">Notebook Sections</span>
            <span className="text-[11px] text-slate-500">12 Sections</span>
          </div>

          <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto">
            {sections.map((s) => {
              const isActive = activeSection === s.id;
              return (
                <button
                  key={s.id}
                  onClick={() => setActiveSection(s.id)}
                  className={`w-full text-left p-3.5 transition-colors flex items-start justify-between gap-2 text-xs ${
                    isActive ? 'bg-blue-50/80 border-l-4 border-blue-600 font-semibold text-blue-950' : 'hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="truncate">{s.title}</div>
                    <span className="text-[10px] text-slate-400 font-normal">{s.badge}</span>
                  </div>
                  {isActive && <Check className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Detail (7 cols) */}
        <div className="lg:col-span-7 bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          {(() => {
            const current = sections.find((s) => s.id === activeSection) || sections[0];
            return (
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h3 className="text-base font-bold text-slate-900">{current.title}</h3>
                  <span className="text-xs text-blue-700 font-semibold bg-blue-50 px-2 py-0.5 rounded">
                    {current.badge}
                  </span>
                </div>
                <div>{current.content}</div>
              </div>
            );
          })()}
        </div>
      </div>
    </div>
  );
};
