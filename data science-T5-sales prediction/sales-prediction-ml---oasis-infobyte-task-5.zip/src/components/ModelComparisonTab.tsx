import React from 'react';
import { Award, BarChart2, CheckCircle2, ChevronRight, HelpCircle, ArrowRight } from 'lucide-react';
import { MLResultsSummary } from '../types';

interface ModelComparisonTabProps {
  results: MLResultsSummary;
  onNavigateTab: (tabId: string) => void;
}

export const ModelComparisonTab: React.FC<ModelComparisonTabProps> = ({ results, onNavigateTab }) => {
  const lr = results.linear_regression;
  const rf = results.random_forest;

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Champion Banner */}
      <div className="bg-white p-6 rounded-xl border border-emerald-200 bg-emerald-50/20 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-emerald-700" />
            <h2 className="text-lg font-bold text-slate-900">Champion Model: Random Forest Regressor</h2>
          </div>
          <p className="text-xs text-slate-600 max-w-2xl leading-relaxed">
            Evaluated on identical unseen test set (40 samples, 20% split, random_state=42). Random Forest achieves an <strong className="text-emerald-800">R² of 0.9813</strong> and cuts RMSE by more than <strong className="text-emerald-800">56%</strong> compared to the baseline linear model by capturing synergistic TV & Radio interactions.
          </p>
        </div>

        <button
          onClick={() => onNavigateTab('simulator')}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-md shadow-xs transition-colors shrink-0"
        >
          <span>Test in Simulator</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Metrics Head-to-Head Table */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-slate-900">Calculated Test Metrics Comparison</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Evaluation Metric</th>
                <th className="py-3 px-4">Baseline: Linear Regression</th>
                <th className="py-3 px-4 text-emerald-800 font-bold">Random Forest Regressor</th>
                <th className="py-3 px-4">Relative Improvement</th>
                <th className="py-3 px-4">Metric Meaning & Optimal Goal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              <tr>
                <td className="py-3 px-4 font-sans font-semibold text-slate-900">Mean Absolute Error (MAE)</td>
                <td className="py-3 px-4 text-slate-700">{lr.mae.toFixed(4)}</td>
                <td className="py-3 px-4 font-bold text-emerald-700 bg-emerald-50/40">{rf.mae.toFixed(4)}</td>
                <td className="py-3 px-4 font-sans text-xs text-emerald-700 font-semibold">-57.5% (lower error)</td>
                <td className="py-3 px-4 font-sans text-xs text-slate-600">Average error magnitude in thousands of units (lower is better).</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-sans font-semibold text-slate-900">Root Mean Squared Error (RMSE)</td>
                <td className="py-3 px-4 text-slate-700">{lr.rmse.toFixed(4)}</td>
                <td className="py-3 px-4 font-bold text-emerald-700 bg-emerald-50/40">{rf.rmse.toFixed(4)}</td>
                <td className="py-3 px-4 font-sans text-xs text-emerald-700 font-semibold">-56.8% (penalizes spikes)</td>
                <td className="py-3 px-4 font-sans text-xs text-slate-600">Standard deviation of residuals (lower is better).</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-sans font-semibold text-slate-900">R² Score (Variance Explained)</td>
                <td className="py-3 px-4 text-slate-700">{lr.r2.toFixed(4)}</td>
                <td className="py-3 px-4 font-bold text-emerald-700 bg-emerald-50/40">{rf.r2.toFixed(4)}</td>
                <td className="py-3 px-4 font-sans text-xs text-emerald-700 font-semibold">+9.1% absolute gain</td>
                <td className="py-3 px-4 font-sans text-xs text-slate-600">Fraction of target variance accounted for (higher is better, max 1.0).</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Visual Chart and Model Details Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Model Comparison Chart */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-blue-600" />
              <h3 className="text-base font-bold text-slate-900">Visual Metrics Comparison</h3>
            </div>
            <p className="text-xs text-slate-500 mt-1">Generated by notebook evaluation script (MAE, RMSE, R²).</p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-center">
            <img
              src="/outputs/model_comparison.png"
              alt="Model Comparison Bar Chart"
              className="max-h-[260px] w-auto object-contain rounded-md"
            />
          </div>

          <div className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100">
            <strong>Key Insight:</strong> Random Forest drops MAE from 1.46 to 0.62 and RMSE from 1.78 to 0.77. On average, Random Forest predictions are within 620 units of actual sales.
          </div>
        </div>

        {/* Learned Equation & Tree Importances */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-slate-900">Mathematical Specifications</h3>

          {/* Linear Model Section */}
          <div className="p-4 rounded-lg bg-blue-50/40 border border-blue-100 space-y-2">
            <div className="text-xs font-semibold text-blue-900 uppercase">Multiple Linear Regression Equation</div>
            <div className="p-2.5 bg-white rounded border border-blue-200 font-mono text-xs text-blue-950 font-bold overflow-x-auto">
              Predicted Sales = 2.9791 + (0.0447 × TV) + (0.1892 × Radio) + (0.0028 × Newspaper)
            </div>
            <div className="text-xs text-slate-700 space-y-1 pt-1">
              <div>• <strong>Intercept (β₀ = 2.9791):</strong> Baseline expected sales (~2,979 units) when zero advertising budget is spent.</div>
              <div>• <strong>β_TV (0.0447):</strong> +1 unit ($1,000) spend on TV yields ~44.7 additional units sold (holding Radio & Newspaper constant).</div>
              <div>• <strong>β_Radio (0.1892):</strong> +1 unit ($1,000) spend on Radio yields ~189.2 additional units sold (highest unit slope).</div>
              <div>• <strong>β_Newspaper (0.0028):</strong> Negligible marginal impact (~2.8 units per $1,000 spend).</div>
            </div>
          </div>

          {/* Random Forest Section */}
          <div className="p-4 rounded-lg bg-emerald-50/40 border border-emerald-100 space-y-2">
            <div className="text-xs font-semibold text-emerald-900 uppercase">Random Forest Feature Importances (Gini Impurity)</div>
            <div className="space-y-2 pt-1 font-mono text-xs">
              <div>
                <div className="flex justify-between font-sans text-xs mb-1">
                  <span className="font-semibold text-slate-800">TV Advertising</span>
                  <span className="text-emerald-700 font-bold">{(rf.feature_importances.TV * 100).toFixed(2)}%</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div className="bg-blue-600 h-full rounded-full" style={{ width: `${rf.feature_importances.TV * 100}%` }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between font-sans text-xs mb-1">
                  <span className="font-semibold text-slate-800">Radio Advertising</span>
                  <span className="text-emerald-700 font-bold">{(rf.feature_importances.Radio * 100).toFixed(2)}%</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-600 h-full rounded-full" style={{ width: `${rf.feature_importances.Radio * 100}%` }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between font-sans text-xs mb-1">
                  <span className="font-semibold text-slate-800">Newspaper Advertising</span>
                  <span className="text-emerald-700 font-bold">{(rf.feature_importances.Newspaper * 100).toFixed(2)}%</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div className="bg-amber-600 h-full rounded-full" style={{ width: `${rf.feature_importances.Newspaper * 100}%` }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Sample Test Predictions Table */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-slate-900">Sample Test Predictions vs. Ground Truth</h3>
        <p className="text-xs text-slate-500">
          First 10 records from the test split showing actual sales, Linear Regression prediction, Random Forest prediction, and residuals.
        </p>

        <div className="overflow-x-auto border border-slate-200 rounded-lg">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Test Row</th>
                <th className="py-2.5 px-3">TV ($000s)</th>
                <th className="py-2.5 px-3">Radio ($000s)</th>
                <th className="py-2.5 px-3">Newspaper ($000s)</th>
                <th className="py-2.5 px-3 font-bold text-slate-900">Actual Sales</th>
                <th className="py-2.5 px-3 text-blue-700">Linear Reg Pred</th>
                <th className="py-2.5 px-3 text-emerald-700 font-bold">Random Forest Pred</th>
                <th className="py-2.5 px-3">RF Residual (y - ŷ)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {results.sample_test_predictions.map((p, i) => (
                <tr key={i} className="hover:bg-slate-50 transition-colors">
                  <td className="py-2.5 px-3 text-slate-400 font-sans">#{p.index}</td>
                  <td className="py-2.5 px-3">${p.tv.toFixed(1)}k</td>
                  <td className="py-2.5 px-3">${p.radio.toFixed(1)}k</td>
                  <td className="py-2.5 px-3">${p.newspaper.toFixed(1)}k</td>
                  <td className="py-2.5 px-3 font-bold text-slate-900 bg-slate-50">{p.actual_sales.toFixed(1)}k</td>
                  <td className="py-2.5 px-3 text-blue-700">{p.lr_pred.toFixed(2)}k</td>
                  <td className="py-2.5 px-3 text-emerald-700 font-bold bg-emerald-50/30">{p.rf_pred.toFixed(2)}k</td>
                  <td className="py-2.5 px-3 text-slate-600">{p.residual >= 0 ? `+${p.residual.toFixed(2)}` : p.residual.toFixed(2)}k</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
