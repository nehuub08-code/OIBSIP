import React, { useState } from 'react';
import { Eye, ZoomIn, Info, AlertTriangle, ArrowUpDown, TrendingUp } from 'lucide-react';
import { MLResultsSummary } from '../types';

interface EdaGalleryTabProps {
  results: MLResultsSummary;
}

export const EdaGalleryTab: React.FC<EdaGalleryTabProps> = ({ results }) => {
  const [activeModalImg, setActiveModalImg] = useState<{ src: string; title: string; desc: string } | null>(null);

  const edaCharts = [
    {
      id: 'pairplot',
      title: 'Pairplot Matrix with KDE Diagonals',
      src: '/outputs/pairplot.png',
      caption: 'Multivariate distributions across all 4 variables (TV, Radio, Newspaper, Sales)',
      insight: 'The KDE density on the diagonal reveals TV spend is widely dispersed up to $300k, while Radio is concentrated under $50k. The scatter plots visibly show strong positive slope for TV vs Sales and moderate slope for Radio vs Sales, while Newspaper shows high vertical dispersion.',
      badge: 'Bivariate Distributions'
    },
    {
      id: 'heatmap',
      title: 'Correlation Matrix Heatmap',
      src: '/outputs/correlation_heatmap.png',
      caption: 'Annotated Pearson correlation coefficients between advertising channels and sales',
      insight: 'TV has the highest linear association with Sales (r = 0.782), followed by Radio (r = 0.576). Newspaper displays weak linear correlation (r = 0.228) and moderate collinearity with Radio (r = 0.354). Collinearity explains why Newspaper loses all predictive significance once Radio is in the regression equation.',
      badge: 'Pearson Matrix'
    },
    {
      id: 'tv',
      title: 'TV Advertising Spend vs. Sales',
      src: '/outputs/tv_vs_sales.png',
      caption: 'Scatter plot with Ordinary Least Squares (OLS) trendline (r = 0.782)',
      insight: 'Clear positive upward trajectory. As TV advertising rises from $0k to $300k, sales scale from ~5k to ~25k units. Notice the slight parabolic curvature at high spend, showing modest diminishing returns that non-linear tree models leverage.',
      badge: 'Channel X₁ (r = 0.782)'
    },
    {
      id: 'radio',
      title: 'Radio Advertising Spend vs. Sales',
      src: '/outputs/radio_vs_sales.png',
      caption: 'Scatter plot with OLS trendline (r = 0.576)',
      insight: 'Moderate positive linear relationship. At any given radio spend, there is vertical spread because TV spending accounts for much of the variance. However, the steeper slope confirms high incremental responsiveness.',
      badge: 'Channel X₂ (r = 0.576)'
    },
    {
      id: 'newspaper',
      title: 'Newspaper Advertising Spend vs. Sales',
      src: '/outputs/newspaper_vs_sales.png',
      caption: 'Scatter plot with OLS trendline (r = 0.228)',
      insight: 'Very diffuse cloud with weak slope. Observations with high newspaper advertising ($80k–$110k) frequently exhibit low sales ($10k–$15k), demonstrating low predictive power and weak marginal return.',
      badge: 'Channel X₃ (r = 0.228)'
    }
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Intro box */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Exploratory Data Analysis (EDA) Gallery</h2>
          <p className="text-xs text-slate-600 mt-1">
            Visual inspection of distributions, bivariate scatter plots with regression trendlines, and correlation matrices.
          </p>
        </div>

        <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800">
          <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
          <span><strong>Core Principle:</strong> Correlation evaluates linear co-movement, not causal proof.</span>
        </div>
      </div>

      {/* Grid of Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {edaCharts.map((chart) => (
          <div key={chart.id} className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div>
                <span className="text-[11px] font-semibold text-blue-600">{chart.badge}</span>
                <h3 className="text-sm font-bold text-slate-900 mt-0.5">{chart.title}</h3>
              </div>
              <button
                onClick={() => setActiveModalImg({ src: chart.src, title: chart.title, desc: chart.insight })}
                className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-blue-600 p-1.5 rounded-md hover:bg-slate-200 transition-colors"
                title="Expand figure"
              >
                <ZoomIn className="w-4 h-4" />
                <span className="hidden sm:inline">Zoom</span>
              </button>
            </div>

            <div className="p-4 bg-slate-100/50 flex items-center justify-center min-h-[300px]">
              <img
                src={chart.src}
                alt={chart.title}
                className="max-h-[340px] w-auto object-contain rounded-md shadow-xs border border-slate-200 bg-white"
                loading="lazy"
              />
            </div>

            <div className="p-4 space-y-2 flex-1 flex flex-col justify-between border-t border-slate-100 bg-white">
              <p className="text-xs text-slate-500 italic">{chart.caption}</p>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 text-xs text-slate-700 leading-relaxed">
                <strong className="text-slate-900">Statistical Interpretation: </strong>
                {chart.insight}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Correlation Interpretation Matrix Table */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-slate-900">Numerical Pearson Correlation Matrix</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Feature</th>
                <th className="py-3 px-4">TV</th>
                <th className="py-3 px-4">Radio</th>
                <th className="py-3 px-4">Newspaper</th>
                <th className="py-3 px-4 text-blue-700 font-bold">Sales (Target)</th>
                <th className="py-3 px-4">Linear Strength vs. Sales</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700 font-mono">
              <tr>
                <td className="py-3 px-4 font-sans font-semibold text-slate-900">TV</td>
                <td className="py-3 px-4 text-slate-400">1.0000</td>
                <td className="py-3 px-4">0.0548</td>
                <td className="py-3 px-4">0.0566</td>
                <td className="py-3 px-4 font-bold text-blue-700 bg-blue-50/50">0.7822</td>
                <td className="py-3 px-4 font-sans text-xs text-emerald-700 font-semibold">Strong Positive Linear</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-sans font-semibold text-slate-900">Radio</td>
                <td className="py-3 px-4">0.0548</td>
                <td className="py-3 px-4 text-slate-400">1.0000</td>
                <td className="py-3 px-4 text-amber-700">0.3541</td>
                <td className="py-3 px-4 font-bold text-blue-700 bg-blue-50/50">0.5762</td>
                <td className="py-3 px-4 font-sans text-xs text-blue-700 font-semibold">Moderate Positive Linear</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-sans font-semibold text-slate-900">Newspaper</td>
                <td className="py-3 px-4">0.0566</td>
                <td className="py-3 px-4 text-amber-700">0.3541</td>
                <td className="py-3 px-4 text-slate-400">1.0000</td>
                <td className="py-3 px-4 font-bold text-blue-700 bg-blue-50/50">0.2283</td>
                <td className="py-3 px-4 font-sans text-xs text-slate-500 font-semibold">Weak Linear</td>
              </tr>
              <tr className="bg-blue-50/30">
                <td className="py-3 px-4 font-sans font-bold text-blue-900">Sales</td>
                <td className="py-3 px-4 font-bold text-blue-700">0.7822</td>
                <td className="py-3 px-4 font-bold text-blue-700">0.5762</td>
                <td className="py-3 px-4 font-bold text-blue-700">0.2283</td>
                <td className="py-3 px-4 text-slate-400">1.0000</td>
                <td className="py-3 px-4 font-sans text-xs text-blue-800 font-bold">Target Variable</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Zoom */}
      {activeModalImg && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full border border-slate-200 overflow-hidden flex flex-col">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <h3 className="text-base font-bold text-slate-900">{activeModalImg.title}</h3>
              <button
                onClick={() => setActiveModalImg(null)}
                className="text-xs px-2.5 py-1 text-slate-600 hover:text-slate-900 hover:bg-slate-200 rounded-md"
              >
                Close
              </button>
            </div>
            <div className="p-6 bg-slate-100 flex items-center justify-center max-h-[70vh] overflow-auto">
              <img src={activeModalImg.src} alt={activeModalImg.title} className="max-w-full h-auto object-contain rounded-md shadow-md bg-white" />
            </div>
            <div className="p-4 border-t border-slate-200 bg-white text-xs text-slate-700 leading-relaxed">
              {activeModalImg.desc}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
