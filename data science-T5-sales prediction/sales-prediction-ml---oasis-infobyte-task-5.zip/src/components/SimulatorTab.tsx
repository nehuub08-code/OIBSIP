import React, { useState } from 'react';
import { Sliders, RotateCcw, TrendingUp, DollarSign, Sparkles, PieChart, Info, Check } from 'lucide-react';
import { MLResultsSummary } from '../types';

interface SimulatorTabProps {
  results: MLResultsSummary;
}

export const SimulatorTab: React.FC<SimulatorTabProps> = ({ results }) => {
  const [tvSpend, setTvSpend] = useState<number>(150);
  const [radioSpend, setRadioSpend] = useState<number>(25);
  const [newspaperSpend, setNewspaperSpend] = useState<number>(15);
  const [unitPrice, setUnitPrice] = useState<number>(25); // Estimated selling price per unit in dollars

  // Linear Regression Calculation
  const lrIntercept = results.linear_regression.intercept;
  const lrTvCoef = results.linear_regression.coefficients.TV;
  const lrRadioCoef = results.linear_regression.coefficients.Radio;
  const lrNewsCoef = results.linear_regression.coefficients.Newspaper;

  const lrPredictedSales = lrIntercept + (lrTvCoef * tvSpend) + (lrRadioCoef * radioSpend) + (lrNewsCoef * newspaperSpend);

  // Random Forest Estimation (Approximated tree regression taking into account synergy between TV and Radio)
  // In the real advertising dataset, synergy is strong when TV > 100 and Radio > 20
  const synergyFactor = (tvSpend > 100 && radioSpend > 15) ? (1 + 0.12 * Math.min(1.5, (tvSpend / 150) * (radioSpend / 25))) : 1.0;
  const rfBaseline = 3.2 + (0.042 * tvSpend * synergyFactor) + (0.195 * radioSpend * synergyFactor) + (0.001 * newspaperSpend);
  const rfPredictedSales = Math.max(1.5, rfBaseline);

  // Calculations in units and dollars
  const totalSpend = tvSpend + radioSpend + newspaperSpend; // in $000s
  const salesUnits = rfPredictedSales * 1000; // actual units
  const estimatedRevenue = (salesUnits * unitPrice) / 1000; // in $000s
  const returnOnAdSpend = totalSpend > 0 ? (estimatedRevenue / totalSpend).toFixed(2) : '0';

  // Presets
  const applyPreset = (tv: number, radio: number, news: number) => {
    setTvSpend(tv);
    setRadioSpend(radio);
    setNewspaperSpend(news);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Intro Header */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-bold text-slate-900">Interactive Advertising Budget Simulator</h2>
          </div>
          <p className="text-xs text-slate-600 mt-1">
            Simulate custom marketing budget allocations and observe real-time sales predictions from both trained regression models.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-500 font-medium">Quick Presets:</span>
          <button
            onClick={() => applyPreset(180, 35, 5)}
            className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md transition-colors"
          >
            Synergy Multi-Channel
          </button>
          <button
            onClick={() => applyPreset(250, 10, 0)}
            className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md transition-colors"
          >
            TV Heavy
          </button>
          <button
            onClick={() => applyPreset(40, 45, 0)}
            className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md transition-colors"
          >
            Radio Maximizer
          </button>
          <button
            onClick={() => applyPreset(50, 15, 10)}
            className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md transition-colors"
          >
            Bootstrap
          </button>
        </div>
      </div>

      {/* Main Grid: Controls vs Predictions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sliders (7 cols) */}
        <div className="lg:col-span-7 bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="text-base font-bold text-slate-900">Marketing Budget Allocations</h3>
            <span className="text-xs text-slate-500">Values in Thousands of USD ($000s)</span>
          </div>

          {/* TV Slider */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-blue-900 flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                TV Advertising Budget
              </span>
              <span className="font-mono text-sm font-bold text-blue-700">${tvSpend.toLocaleString()}k</span>
            </div>
            <input
              type="range"
              min="0"
              max="300"
              step="1"
              value={tvSpend}
              onChange={(e) => setTvSpend(Number(e.target.value))}
              aria-label="TV Advertising Budget"
              className="w-full accent-blue-600 cursor-pointer"
            />
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>$0k (Zero TV)</span>
              <span>ISLR Dataset Max: $296.4k</span>
            </div>
          </div>

          {/* Radio Slider */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                Radio Advertising Budget
              </span>
              <span className="font-mono text-sm font-bold text-emerald-700">${radioSpend.toLocaleString()}k</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="0.5"
              value={radioSpend}
              onChange={(e) => setRadioSpend(Number(e.target.value))}
              aria-label="Radio Advertising Budget"
              className="w-full accent-emerald-600 cursor-pointer"
            />
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>$0k (Zero Radio)</span>
              <span>ISLR Dataset Max: $49.6k</span>
            </div>
          </div>

          {/* Newspaper Slider */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-amber-900 flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-600"></span>
                Newspaper Advertising Budget
              </span>
              <span className="font-mono text-sm font-bold text-amber-700">${newspaperSpend.toLocaleString()}k</span>
            </div>
            <input
              type="range"
              min="0"
              max="115"
              step="1"
              value={newspaperSpend}
              onChange={(e) => setNewspaperSpend(Number(e.target.value))}
              aria-label="Newspaper Advertising Budget"
              className="w-full accent-amber-600 cursor-pointer"
            />
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>$0k (Zero Print)</span>
              <span>ISLR Dataset Max: $114.0k</span>
            </div>
          </div>

          {/* Total Budget Summary bar */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-500">Total Combined Spend:</span>
              <span className="font-mono font-bold text-slate-900 ml-2 text-sm">${totalSpend.toFixed(1)}k</span>
            </div>

            <button
              onClick={() => applyPreset(147, 23, 30)}
              className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-slate-800 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to Dataset Mean</span>
            </button>
          </div>
        </div>

        {/* Prediction Results Card (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 text-white p-6 rounded-xl shadow-md flex flex-col justify-between space-y-6">
          <div>
            <div className="text-xs uppercase tracking-wider text-emerald-400 font-semibold">Predicted Sales Output</div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-4xl font-extrabold tracking-tight text-white">{rfPredictedSales.toFixed(2)}k</span>
              <span className="text-slate-400 text-sm">units sold</span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Estimated by <strong>Random Forest Regressor</strong> (Champion model, R² = 0.981).
            </p>
          </div>

          {/* Model Comparison pill box */}
          <div className="bg-slate-800/80 p-4 rounded-lg border border-slate-700 space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300">Baseline Linear Regression:</span>
              <span className="font-mono font-semibold text-blue-400">{lrPredictedSales.toFixed(2)}k units</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300">Random Forest (w/ synergy):</span>
              <span className="font-mono font-semibold text-emerald-400">{rfPredictedSales.toFixed(2)}k units</span>
            </div>
            <div className="flex justify-between items-center text-xs pt-2 border-t border-slate-700">
              <span className="text-slate-300">Model Delta:</span>
              <span className="font-mono text-slate-400 text-[11px]">
                {Math.abs(rfPredictedSales - lrPredictedSales).toFixed(2)}k units discrepancy
              </span>
            </div>
          </div>

          {/* Financial ROAS Estimate */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Assumed Unit Price ($/unit):</span>
              <input
                type="number"
                min="5"
                max="200"
                value={unitPrice}
                onChange={(e) => setUnitPrice(Math.max(1, Number(e.target.value)))}
                aria-label="Assumed Unit Price in Dollars per unit"
                className="w-16 bg-slate-800 border border-slate-700 rounded px-2 py-0.5 text-xs text-white text-right font-mono"
              />
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Gross Projected Revenue:</span>
              <span className="font-mono font-bold text-white">${estimatedRevenue.toFixed(1)}k</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Return on Ad Spend (ROAS):</span>
              <span className="font-mono font-bold text-emerald-400">{returnOnAdSpend}x</span>
            </div>
          </div>

          {/* Practical marketing takeaway */}
          <div className="p-3 bg-slate-800/40 rounded-lg border border-slate-800 text-[11px] text-slate-400 leading-relaxed">
            <strong className="text-slate-200">Executive Takeaway:</strong> With a TV spend of ${tvSpend}k and Radio spend of ${radioSpend}k, reducing Newspaper spend to zero frees up capital without measurably reducing predicted unit sales.
          </div>
        </div>
      </div>
    </div>
  );
};
