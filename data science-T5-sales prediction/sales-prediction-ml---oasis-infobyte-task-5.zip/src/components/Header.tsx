import React from 'react';
import { Download, FolderTree, FileCode, Database, CheckCircle2 } from 'lucide-react';

interface HeaderProps {
  onOpenRepoModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenRepoModal }) => {
  return (
    <header className="border-b border-slate-200 bg-white sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
              <span className="font-semibold text-slate-700">Oasis Infobyte</span>
              <span aria-hidden="true">·</span>
              <span>Data Science Internship</span>
              <span aria-hidden="true">·</span>
              <span className="text-blue-600 font-medium">Task 5: Sales Prediction Using Python</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Advertising Budget & Product Sales Regression Engine
            </h1>
            <p className="text-sm text-slate-600 mt-0.5">
              Comparative predictive modeling across TV, Radio & Newspaper channels using Multiple Linear Regression and Random Forest.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onOpenRepoModal}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
              title="View repository folder layout"
            >
              <FolderTree className="w-3.5 h-3.5 text-slate-600" />
              <span>Project Structure</span>
            </button>

            <a
              href="/outputs/Sales_Prediction.ipynb"
              download="Sales_Prediction.ipynb"
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-md transition-colors"
            >
              <FileCode className="w-3.5 h-3.5 text-blue-600" />
              <span>Download Notebook (.ipynb)</span>
            </a>

            <a
              href="/Advertising.csv"
              download="Advertising.csv"
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-md transition-colors"
            >
              <Database className="w-3.5 h-3.5 text-emerald-600" />
              <span>Download Dataset (.csv)</span>
            </a>
          </div>
        </div>

        {/* Verification banner line */}
        <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-y-2">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1 text-emerald-600 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Dataset Verified (200 records)
            </span>
            <span aria-hidden="true">·</span>
            <span>80/20 Train/Test Split (random_state=42)</span>
            <span aria-hidden="true">·</span>
            <span>R²: 0.981 (Random Forest) vs 0.899 (Linear Reg)</span>
          </div>

          <div className="text-slate-400">
            Path: <code className="bg-slate-100 px-1 py-0.5 rounded text-[11px] text-slate-600">OIBSIP/DataScience/Task5_Sales_Prediction/</code>
          </div>
        </div>
      </div>
    </header>
  );
};
