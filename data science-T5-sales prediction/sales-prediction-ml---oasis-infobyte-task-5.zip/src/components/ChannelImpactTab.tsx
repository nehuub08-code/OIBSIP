import React from 'react';
import { Compass, Scale, AlertTriangle, TrendingUp, BarChart, Tv, Radio as RadioIcon, Newspaper } from 'lucide-react';
import { MLResultsSummary } from '../types';

interface ChannelImpactTabProps {
  results: MLResultsSummary;
}

export const ChannelImpactTab: React.FC<ChannelImpactTabProps> = ({ results }) => {
  const lr = results.linear_regression;
  const rf = results.random_forest;
  const corr = results.correlations.Sales;

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Question Header */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2">
          <Compass className="w-5 h-5 text-blue-600" />
          <h2 className="text-lg font-bold text-slate-900">
            Research Question: Which Advertising Channel Has the Highest Impact on Predicted Sales?
          </h2>
        </div>
        <p className="text-xs text-slate-600 mt-1 max-w-3xl leading-relaxed">
          In data science, the term "highest impact" can refer to multiple distinct mathematical properties: bivariate linear correlation, multivariate unit sensitivity (regression coefficient), or overall variance explained in non-linear trees (feature importance).
        </p>
      </div>

      {/* Multi-Dimensional Comparison Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* TV Card */}
        <div className="bg-white rounded-xl border-2 border-blue-500 shadow-sm overflow-hidden flex flex-col justify-between">
          <div className="p-5 border-b border-blue-100 bg-blue-50/40">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 font-bold text-blue-900 text-sm">
                <Tv className="w-4 h-4 text-blue-600" />
                Television (TV)
              </span>
              <span className="text-[11px] font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded">
                Highest Variance Driver
              </span>
            </div>
            <p className="text-xs text-blue-800/80 mt-1">Scale: $0.7k – $296.4k (Mean: $147.0k)</p>
          </div>

          <div className="p-5 space-y-4 text-xs font-mono">
            <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
              <span className="font-sans text-slate-600">Pearson Correlation (r):</span>
              <span className="font-bold text-blue-700">{corr.TV.toFixed(4)} (Rank #1)</span>
            </div>
            <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
              <span className="font-sans text-slate-600">Linear Slope (β):</span>
              <span className="font-bold text-slate-800">+{lr.coefficients.TV.toFixed(4)} / $1k</span>
            </div>
            <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
              <span className="font-sans text-slate-600">RF Feature Importance:</span>
              <span className="font-bold text-blue-700">{(rf.feature_importances.TV * 100).toFixed(2)}% (Rank #1)</span>
            </div>
            <p className="font-sans text-xs text-slate-600 leading-relaxed pt-1">
              TV advertising accounts for <strong className="text-slate-900">over 62% of total sales variance</strong>. Due to its large operational budget ceiling, it drives the lion's share of overall baseline demand.
            </p>
          </div>
        </div>

        {/* Radio Card */}
        <div className="bg-white rounded-xl border-2 border-emerald-500 shadow-sm overflow-hidden flex flex-col justify-between">
          <div className="p-5 border-b border-emerald-100 bg-emerald-50/40">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 font-bold text-emerald-900 text-sm">
                <RadioIcon className="w-4 h-4 text-emerald-600" />
                Radio Broadcast
              </span>
              <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                Highest Unit Efficiency
              </span>
            </div>
            <p className="text-xs text-emerald-800/80 mt-1">Scale: $0.0k – $49.6k (Mean: $23.3k)</p>
          </div>

          <div className="p-5 space-y-4 text-xs font-mono">
            <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
              <span className="font-sans text-slate-600">Pearson Correlation (r):</span>
              <span className="font-bold text-slate-800">{corr.Radio.toFixed(4)} (Rank #2)</span>
            </div>
            <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
              <span className="font-sans text-slate-600">Linear Slope (β):</span>
              <span className="font-bold text-emerald-700">+{lr.coefficients.Radio.toFixed(4)} / $1k (Rank #1)</span>
            </div>
            <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
              <span className="font-sans text-slate-600">RF Feature Importance:</span>
              <span className="font-bold text-slate-800">{(rf.feature_importances.Radio * 100).toFixed(2)}% (Rank #2)</span>
            </div>
            <p className="font-sans text-xs text-slate-600 leading-relaxed pt-1">
              Radio produces the <strong className="text-slate-900">highest incremental return per $1,000 spend</strong> (+189.2 units vs +44.7 units for TV). However, its effective budget cap is lower before saturation occurs.
            </p>
          </div>
        </div>

        {/* Newspaper Card */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col justify-between">
          <div className="p-5 border-b border-slate-100 bg-slate-50">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 font-bold text-slate-800 text-sm">
                <Newspaper className="w-4 h-4 text-amber-600" />
                Print Newspaper
              </span>
              <span className="text-[11px] font-medium text-slate-500 bg-slate-200 px-2 py-0.5 rounded">
                Negligible Impact
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">Scale: $0.3k – $114.0k (Mean: $30.6k)</p>
          </div>

          <div className="p-5 space-y-4 text-xs font-mono">
            <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
              <span className="font-sans text-slate-600">Pearson Correlation (r):</span>
              <span className="font-bold text-slate-500">{corr.Newspaper.toFixed(4)} (Rank #3)</span>
            </div>
            <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
              <span className="font-sans text-slate-600">Linear Slope (β):</span>
              <span className="font-bold text-slate-500">+{lr.coefficients.Newspaper.toFixed(4)} / $1k (Rank #3)</span>
            </div>
            <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
              <span className="font-sans text-slate-600">RF Feature Importance:</span>
              <span className="font-bold text-slate-500">{(rf.feature_importances.Newspaper * 100).toFixed(2)}% (Rank #3)</span>
            </div>
            <p className="font-sans text-xs text-slate-600 leading-relaxed pt-1">
              Newspaper's apparent weak bivariate correlation ($r = 0.228$) is mostly a collinear reflection of Radio ($r = 0.354$). Once TV and Radio are in the model, Newspaper contributes <strong className="text-slate-900">almost 0 incremental value (1.3%)</strong>.
            </p>
          </div>
        </div>
      </div>

      {/* Critical Analytical Distinctions */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2">
          <Scale className="w-5 h-5 text-indigo-600" />
          <h3 className="text-base font-bold text-slate-900">Why Raw Coefficients vs Correlations Differ</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-700 leading-relaxed">
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-100 space-y-2">
            <div className="font-bold text-slate-900 uppercase">1. Feature Scale & Range Variance</div>
            <p>
              In Multiple Linear Regression, coefficients depend directly on feature units. TV spending spans up to <strong>$300k</strong>, whereas Radio only spans up to <strong>$50k</strong>. While Radio has a larger coefficient per single unit (0.189 vs 0.045), multiplying the TV coefficient across typical $150k-$250k expenditures generates a massive total contribution of 6 to 11 units of sales, dominating Radio's total contribution.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg border border-slate-100 space-y-2">
            <div className="font-bold text-slate-900 uppercase">2. Synergy & Multi-Channel Interaction</div>
            <p>
              In real enterprise marketing, TV ads build broad brand recall, making targeted Radio ads significantly more impactful when heard in a vehicle. Linear models treat channels in isolation ($y = \beta_1 X_1 + \beta_2 X_2$), failing to capture the synergistic term ($X_1 \cdot X_2$). Random Forest captures this synergy, allocating 62.5% importance to TV and 36.2% to Radio.
            </p>
          </div>
        </div>

        {/* Warning banner */}
        <div className="p-4 rounded-lg bg-amber-50 border border-amber-200 flex items-start gap-3 text-xs text-amber-900 leading-relaxed">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <strong className="font-bold">Crucial Mentorship Reminder on Causality vs. Prediction:</strong>
            <p className="mt-0.5">
              These conclusions establish <em>predictive utility</em> within the domain of this historical dataset. Do not tell your internship evaluators that "increasing TV spend by $10,000 will cause sales to grow by 447 units." In reality, brand creative quality, market saturation, competitor counter-programming, and economic recessions modulate real causal outcomes.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
