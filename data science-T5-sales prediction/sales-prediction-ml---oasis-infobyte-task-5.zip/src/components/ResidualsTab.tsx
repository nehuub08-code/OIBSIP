import React from 'react';
import { Activity, ShieldAlert, CheckCircle2, FileQuestion, ArrowRight } from 'lucide-react';
import { MLResultsSummary } from '../types';

interface ResidualsTabProps {
  results: MLResultsSummary;
}

export const ResidualsTab: React.FC<ResidualsTabProps> = ({ results }) => {
  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-purple-600" />
          <h2 className="text-lg font-bold text-slate-900">Diagnostic Residual & Prediction Fidelity Analysis</h2>
        </div>
        <p className="text-xs text-slate-600 mt-1 max-w-3xl leading-relaxed">
          Evaluating the validity of statistical modeling assumptions through actual vs. predicted correlation plots and residual error diagnostics on the unseen 20% test partition.
        </p>
      </div>

      {/* Visual Diagnostics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Actual vs Predicted Plot */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <span className="text-[11px] font-semibold text-blue-600">Model Prediction Accuracy</span>
            <h3 className="text-base font-bold text-slate-900 mt-0.5">Actual vs. Predicted Sales</h3>
            <p className="text-xs text-slate-500 mt-1">
              Scatter plot comparing observed ground truth to predictions from the champion model against the ideal y = x reference line.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-center">
            <img
              src="/outputs/actual_vs_predicted.png"
              alt="Actual vs Predicted Sales Plot"
              className="max-h-[320px] w-auto object-contain rounded-md"
            />
          </div>

          <div className="text-xs text-slate-700 space-y-2 bg-slate-50 p-4 rounded-lg border border-slate-100 leading-relaxed">
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
              <div>
                <strong className="text-slate-900">Tight Diagonal Clustering:</strong> Data points cluster tightly along the dashed 45° red reference line across the entire sales spectrum (from ~5k up to ~27k units).
              </div>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
              <div>
                <strong className="text-slate-900">Absence of Systematic Compression:</strong> The model does not suffer from under-predicting high-sales peaks or over-predicting low-sales baselines.
              </div>
            </div>
          </div>
        </div>

        {/* Residual Diagnostic Plot */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <span className="text-[11px] font-semibold text-purple-600">Error Dispersion</span>
            <h3 className="text-base font-bold text-slate-900 mt-0.5">Residual Analysis (e = y - ŷ)</h3>
            <p className="text-xs text-slate-500 mt-1">
              Distribution of prediction errors plotted against predicted sales values with a zero-residual reference line.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-center">
            <img
              src="/outputs/residual_plot.png"
              alt="Residual Plot"
              className="max-h-[320px] w-auto object-contain rounded-md"
            />
          </div>

          <div className="text-xs text-slate-700 space-y-2 bg-slate-50 p-4 rounded-lg border border-slate-100 leading-relaxed">
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-purple-600 mt-0.5 shrink-0" />
              <div>
                <strong className="text-slate-900">Symmetric Zero Dispersion:</strong> Residuals fluctuate symmetrically above and below the horizontal zero line, indicating zero systematic bias.
              </div>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-purple-600 mt-0.5 shrink-0" />
              <div>
                <strong className="text-slate-900">Homoscedastic Stability:</strong> The absence of a prominent widening funnel pattern demonstrates roughly constant error variance across predicted sales ranges.
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Residual Diagnostics Interpretation Guide */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-slate-900">Data Science Residual Interpretation Guide</h3>
        <p className="text-xs text-slate-600">
          How to evaluate residual plots during an internship review:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div className="p-4 rounded-lg bg-emerald-50/50 border border-emerald-100 space-y-1">
            <div className="font-bold text-emerald-900">1. Random Scatter</div>
            <p className="text-slate-600 leading-relaxed">
              Residuals randomly scattered around zero confirm the model captured the dominant mathematical signals without leaving unmodeled linear components.
            </p>
          </div>

          <div className="p-4 rounded-lg bg-amber-50/50 border border-amber-100 space-y-1">
            <div className="font-bold text-amber-900">2. Curved Patterns</div>
            <p className="text-slate-600 leading-relaxed">
              A U-shape or inverted parabola indicates an unmodeled non-linear relationship (e.g. quadratic decay or saturation) in linear regression.
            </p>
          </div>

          <div className="p-4 rounded-lg bg-blue-50/50 border border-blue-100 space-y-1">
            <div className="font-bold text-blue-900">3. Funnel Shape (Heteroscedasticity)</div>
            <p className="text-slate-600 leading-relaxed">
              If errors expand as sales increase, prediction uncertainty is higher for large accounts, suggesting a log-transformation or weighted regression.
            </p>
          </div>

          <div className="p-4 rounded-lg bg-rose-50/50 border border-rose-100 space-y-1">
            <div className="font-bold text-rose-900">4. Isolated Outliers</div>
            <p className="text-slate-600 leading-relaxed">
              Points with |residual| &gt; 3 standard deviations indicate atypical markets (e.g. sudden viral publicity or supply bottlenecks).
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
