import React from 'react';
import { Target, TrendingUp, Layers, CheckCircle2, ArrowRight, ShieldCheck, BarChart3, AlertCircle } from 'lucide-react';
import { MLResultsSummary } from '../types';

interface OverviewTabProps {
  results: MLResultsSummary;
  onNavigateTab: (tabId: string) => void;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({ results, onNavigateTab }) => {
  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Hero KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs font-medium text-slate-500 uppercase tracking-wider">Dataset Volume</div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-slate-900">{results.summary.total_samples}</span>
            <span className="text-xs text-slate-500">observations</span>
          </div>
          <div className="mt-2 text-xs text-emerald-600 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>0 Missing Values · 0 Duplicates</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs font-medium text-slate-500 uppercase tracking-wider">Baseline Linear Reg R²</div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-blue-600">{(results.linear_regression.r2 * 100).toFixed(1)}%</span>
            <span className="text-xs text-slate-500">variance explained</span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            RMSE: {results.linear_regression.rmse.toFixed(3)} · MAE: {results.linear_regression.mae.toFixed(3)}
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs border-emerald-200 bg-emerald-50/20">
          <div className="text-xs font-medium text-emerald-700 uppercase tracking-wider">Champion Random Forest R²</div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-emerald-700">{(results.random_forest.r2 * 100).toFixed(1)}%</span>
            <span className="text-xs text-emerald-600 font-medium">test set</span>
          </div>
          <div className="mt-2 text-xs text-emerald-600 font-medium">
            RMSE: {results.random_forest.rmse.toFixed(3)} · MAE: {results.random_forest.mae.toFixed(3)}
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs font-medium text-slate-500 uppercase tracking-wider">Highest Impact Channel</div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-bold text-purple-700">TV & Radio</span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            TV: 62.5% Variance · Radio: Highest Unit Slope (0.189)
          </div>
        </div>
      </div>

      {/* Problem Formulation & Scientific Context */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <Target className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-bold text-slate-900">Task Objective & Formulation</h2>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            The core objective of Oasis Infobyte Data Science Task 5 is to analyze the relationship between advertising expenditures across multiple media vehicles (<strong className="text-slate-900">Television</strong>, <strong className="text-slate-900">Radio</strong>, and <strong className="text-slate-900">Newspaper</strong>) and product <strong className="text-slate-900">Sales</strong>, formulating an optimal predictive model.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="p-4 rounded-lg bg-slate-50 border border-slate-100 space-y-2">
              <div className="text-xs font-semibold text-slate-800 uppercase tracking-wide">Why is this Regression, Not Classification?</div>
              <p className="text-xs text-slate-600 leading-relaxed">
                In classification, the model predicts discrete class categories (e.g., will sales be high or low). Here, our target variable <code className="text-blue-700 font-mono">Sales</code> is a continuous real-valued number (thousands of units sold). Regression algorithms predict precise numerical values rather than group memberships.
              </p>
            </div>

            <div className="p-4 rounded-lg bg-slate-50 border border-slate-100 space-y-2">
              <div className="text-xs font-semibold text-slate-800 uppercase tracking-wide">Business & Economic Rationale</div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Enterprises operate under constrained marketing budgets. Knowing each channel's expected sales return prevents over-investing in diminishing channels (e.g. Newspaper) and unlocks cross-channel promotional synergies between TV reach and Radio frequency.
              </p>
            </div>
          </div>

          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => onNavigateTab('simulator')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-md shadow-xs transition-colors"
            >
              <span>Launch Live Budget Simulator</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onNavigateTab('comparison')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-md transition-colors"
            >
              <span>Inspect Evaluation Metrics</span>
            </button>
          </div>
        </div>

        {/* Feature & Variable Card */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-600" />
            <h3 className="text-base font-bold text-slate-900">Variables & Dimensions</h3>
          </div>

          <div className="space-y-3">
            <div className="p-3 rounded-lg bg-blue-50/50 border border-blue-100">
              <div className="flex justify-between text-xs">
                <span className="font-bold text-blue-900">TV (Feature X₁)</span>
                <span className="text-blue-700 font-mono">$0.7k – $296.4k</span>
              </div>
              <div className="text-xs text-slate-600 mt-1">High reach, primary sales driver with 0.782 correlation.</div>
            </div>

            <div className="p-3 rounded-lg bg-emerald-50/50 border border-emerald-100">
              <div className="flex justify-between text-xs">
                <span className="font-bold text-emerald-900">Radio (Feature X₂)</span>
                <span className="text-emerald-700 font-mono">$0.0k – $49.6k</span>
              </div>
              <div className="text-xs text-slate-600 mt-1">Highest unit efficiency (0.189 sales units per $1k spend).</div>
            </div>

            <div className="p-3 rounded-lg bg-amber-50/50 border border-amber-100">
              <div className="flex justify-between text-xs">
                <span className="font-bold text-amber-900">Newspaper (Feature X₃)</span>
                <span className="text-amber-700 font-mono">$0.3k – $114.0k</span>
              </div>
              <div className="text-xs text-slate-600 mt-1">Negligible impact (0.0028 coefficient); near redundant.</div>
            </div>

            <div className="p-3 rounded-lg bg-purple-50/50 border border-purple-100">
              <div className="flex justify-between text-xs">
                <span className="font-bold text-purple-900">Sales (Target y)</span>
                <span className="text-purple-700 font-mono">1.6k – 27.0k units</span>
              </div>
              <div className="text-xs text-slate-600 mt-1">Mean: 14.02k units · Std Dev: 5.22k units.</div>
            </div>
          </div>
        </div>
      </div>

      {/* Verification Checklist */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <h3 className="text-base font-bold text-slate-900">Oasis Infobyte Task 5 Completion Checklist</h3>
          </div>
          <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
            100% Verified
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          {[
            'Classic Advertising.csv sourced from ISLR benchmark',
            'Data hygiene: index dropped, 0 nulls, 0 duplicates',
            'Full EDA: Pairplot with KDE & 3 scatter trendlines',
            'Annotated Pearson correlation heatmap generated',
            '80/20 train/test split strictly seeded (random_state=42)',
            'Baseline Multiple Linear Regression trained',
            'Random Forest Regressor trained on identical split',
            'Test MAE, RMSE, and R² calculated and compared',
            'Actual vs. Predicted scatter plot with y=x identity line',
            'Residual error diagnostic plot with zero baseline',
            'Comparative channel impact (Correlation vs Coef vs Importance)',
            'Executable Jupyter Notebook (.ipynb) with real cell outputs',
            'Professional GitHub README.md with relative image paths',
            'Minimal reproducible requirements.txt specification',
            'Interactive web dashboard & budget prediction simulator'
          ].map((item, idx) => (
            <div key={idx} className="flex items-start gap-2 p-2.5 rounded-lg bg-slate-50 border border-slate-100">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
              <span className="text-slate-700">{item}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
