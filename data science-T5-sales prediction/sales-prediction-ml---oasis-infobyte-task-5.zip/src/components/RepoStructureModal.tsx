import React from 'react';
import { X, Folder, FileText, Image, FileCode, Check } from 'lucide-react';

interface RepoStructureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RepoStructureModal: React.FC<RepoStructureModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const files = [
    { name: 'Advertising.csv', path: 'OIBSIP/DataScience/Task5_Sales_Prediction/data/Advertising.csv', type: 'data', desc: 'Authentic 200-row ISLR dataset with TV, Radio, Newspaper spend & Sales' },
    { name: 'Sales_Prediction.ipynb', path: 'OIBSIP/DataScience/Task5_Sales_Prediction/notebooks/Sales_Prediction.ipynb', type: 'notebook', desc: 'Fully executed 12-section Jupyter Notebook with real outputs & markdown notes' },
    { name: 'pairplot.png', path: 'OIBSIP/DataScience/Task5_Sales_Prediction/outputs/pairplot.png', type: 'img', desc: 'Pairwise feature distributions and bivariate KDE plots' },
    { name: 'tv_vs_sales.png', path: 'OIBSIP/DataScience/Task5_Sales_Prediction/outputs/tv_vs_sales.png', type: 'img', desc: 'TV advertising spend vs Sales with linear regression trendline (r = 0.782)' },
    { name: 'radio_vs_sales.png', path: 'OIBSIP/DataScience/Task5_Sales_Prediction/outputs/radio_vs_sales.png', type: 'img', desc: 'Radio advertising spend vs Sales with trendline (r = 0.576)' },
    { name: 'newspaper_vs_sales.png', path: 'OIBSIP/DataScience/Task5_Sales_Prediction/outputs/newspaper_vs_sales.png', type: 'img', desc: 'Newspaper spend vs Sales showing weak correlation (r = 0.228)' },
    { name: 'correlation_heatmap.png', path: 'OIBSIP/DataScience/Task5_Sales_Prediction/outputs/correlation_heatmap.png', type: 'img', desc: 'Annotated Pearson correlation coefficient matrix' },
    { name: 'model_comparison.png', path: 'OIBSIP/DataScience/Task5_Sales_Prediction/outputs/model_comparison.png', type: 'img', desc: 'Side-by-side bar chart of MAE, RMSE, and R² scores for both models' },
    { name: 'actual_vs_predicted.png', path: 'OIBSIP/DataScience/Task5_Sales_Prediction/outputs/actual_vs_predicted.png', type: 'img', desc: 'Actual vs Predicted scatter plot against y=x perfect-prediction reference line' },
    { name: 'residual_plot.png', path: 'OIBSIP/DataScience/Task5_Sales_Prediction/outputs/residual_plot.png', type: 'img', desc: 'Diagnostic residual errors vs predicted values centered at zero' },
    { name: 'README.md', path: 'OIBSIP/DataScience/Task5_Sales_Prediction/README.md', type: 'doc', desc: 'Comprehensive GitHub documentation with embedded output charts and methodology' },
    { name: 'requirements.txt', path: 'OIBSIP/DataScience/Task5_Sales_Prediction/requirements.txt', type: 'doc', desc: 'Minimal, pinned dependencies for pandas, numpy, scikit-learn, matplotlib, seaborn, jupyter' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div>
            <h3 className="text-base font-semibold text-slate-900">Project Folder Structure</h3>
            <p className="text-xs text-slate-500 mt-0.5">Compliant with Oasis Infobyte Data Science Task 5 specifications</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-4 text-xs font-mono">
          <div className="bg-slate-900 text-slate-200 p-4 rounded-lg leading-relaxed text-xs">
            <div className="text-blue-400 font-bold">OIBSIP/</div>
            <div className="pl-4 text-slate-400">└── <span className="text-slate-200">DataScience/</span></div>
            <div className="pl-8 text-slate-400">└── <span className="text-emerald-400 font-semibold">Task5_Sales_Prediction/</span></div>
            <div className="pl-12 text-slate-400">├── <span className="text-amber-400">data/</span></div>
            <div className="pl-16 text-slate-300">└── Advertising.csv</div>
            <div className="pl-12 text-slate-400">├── <span className="text-purple-400">notebooks/</span></div>
            <div className="pl-16 text-slate-300">└── Sales_Prediction.ipynb</div>
            <div className="pl-12 text-slate-400">├── <span className="text-pink-400">outputs/</span></div>
            <div className="pl-16 text-slate-300">├── pairplot.png</div>
            <div className="pl-16 text-slate-300">├── tv_vs_sales.png</div>
            <div className="pl-16 text-slate-300">├── radio_vs_sales.png</div>
            <div className="pl-16 text-slate-300">├── newspaper_vs_sales.png</div>
            <div className="pl-16 text-slate-300">├── correlation_heatmap.png</div>
            <div className="pl-16 text-slate-300">├── model_comparison.png</div>
            <div className="pl-16 text-slate-300">├── actual_vs_predicted.png</div>
            <div className="pl-16 text-slate-300">└── residual_plot.png</div>
            <div className="pl-12 text-slate-400">├── README.md</div>
            <div className="pl-12 text-slate-400">└── requirements.txt</div>
          </div>

          <div className="space-y-2 pt-2">
            <h4 className="font-sans font-semibold text-slate-800 text-sm">File Inventory & Verification Status</h4>
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden font-sans">
              {files.map((file, i) => (
                <div key={i} className="flex items-start gap-3 p-3 bg-white hover:bg-slate-50 transition-colors">
                  <Check className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-semibold text-slate-900">{file.name}</span>
                      <span className="text-[11px] text-slate-400 truncate">{file.path}</span>
                    </div>
                    <p className="text-xs text-slate-600 mt-0.5">{file.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-md transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
