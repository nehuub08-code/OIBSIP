export interface CustomCommand {
  trigger: string;
  action: 'speak' | 'open_url';
  value: string;
  description?: string;
}

export interface AssistantConfig {
  assistant_name: string;
  language: string;
  speech_rate: number;
  speech_volume: number;
  weather_default_city: string;
  temperature_unit: string;
  custom_commands: CustomCommand[];
}

export interface LogMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  intent?: string;
  metadata?: Record<string, any>;
}

export interface ActiveReminder {
  id: string;
  task: string;
  totalSeconds: number;
  remainingSeconds: number;
  createdAt: Date;
}

export interface UnitTestResult {
  name: string;
  description: string;
  passed: boolean;
  category: 'Beginner' | 'Advanced' | 'Safety';
  output?: string;
}

export interface PythonFileItem {
  name: string;
  path: string;
  language: string;
  description: string;
  studentExplanation: string[];
  content: string;
}
