import { PythonFileItem } from '../types';

export const INITIAL_FILES: PythonFileItem[] = [
  {
    name: 'main.py',
    path: 'main.py',
    language: 'python',
    description: 'Command-line interface entry point, startup banner, and continuous listening loop.',
    studentExplanation: [
      'Acts as the program orchestrator: imports VoiceMateAssistant and initializes the system.',
      'Displays the friendly greeting banner and supported commands so users know what to say.',
      'Runs a continuous `while running:` loop that captures audio with `speech.listen()` and dispatches commands with `process_command()`.',
      'Catches `KeyboardInterrupt` (Ctrl+C) cleanly so the program exits gracefully without an ugly traceback.'
    ],
    content: `"""
================================================================================
VoiceMate — Personal Voice Assistant
Oasis Infobyte (OIBSIP) — Python Programming Internship Task 1
Author: Computer Engineering Student
================================================================================
Main entry point for running the voice assistant in the terminal.
Demonstrates clean startup, command overview, continuous listening loop,
and safe exit handling.
================================================================================
"""

import sys
import time
from assistant import VoiceMateAssistant


def print_banner(assistant_name: str):
    """Prints the welcoming startup banner and list of supported voice commands."""
    divider = "=" * 65
    print("\\n" + divider)
    print(f"   Welcome to {assistant_name} — Your Personal Voice Assistant")
    print("   Oasis Infobyte (OIBSIP) Python Programming Internship — Task 1")
    print(divider)
    print("\\nSupported Voice Commands:")
    print("  • Greeting:       'Hello', 'Hi', 'Hey assistant'")
    print("  • Date & Time:    'What time is it?', 'Tell me today\\\\'s date'")
    print("  • Web Search:     'Search for Python tutorials', 'Look up AI'")
    print("  • Timed Reminder: 'Remind me to study DSA in 10 seconds'")
    print("  • Live Weather:   'What\\\\'s the weather in Pune?'")
    print("  • Send Email:     'Send an email'")
    print("  • General Q&A:    'What is Python?', 'What is Machine Learning?'")
    print("  • Custom Config:  'Open GitHub', 'Motivate me'")
    print("  • Exit:           'Exit', 'Goodbye', 'Stop listening'")
    print(divider + "\\n")


def main():
    """Initializes and runs the VoiceMate assistant loop."""
    try:
        # Step 1: Initialize the VoiceMate Assistant
        assistant = VoiceMateAssistant(config_file="config.json")
        name = assistant.config.get("assistant_name", "VoiceMate")

        # Step 2: Show startup banner
        print_banner(name)

        # Initial spoken greeting
        assistant.handle_greeting()

        # Step 3: Main continuous listening loop
        running = True
        while running:
            # Capture speech from microphone
            command_text = assistant.speech.listen(timeout=5, phrase_time_limit=8)

            if not command_text:
                # Idle or empty capture; brief pause before next listen cycle
                time.sleep(0.3)
                continue

            # Process intent and execute action
            running = assistant.process_command(command_text)

    except KeyboardInterrupt:
        # Handle Ctrl+C gracefully without dumping a messy traceback
        print("\\n\\n[VoiceMate]: Detected manual stop (Ctrl+C). Exiting safely...")
    except Exception as e:
        print(f"\\n[Fatal Error]: An unexpected error occurred: {e}")
        sys.exit(1)
    finally:
        print("\\nThank you for using VoiceMate! [Session Ended]\\n")


if __name__ == "__main__":
    main()
`
  },
  {
    name: 'assistant.py',
    path: 'assistant.py',
    language: 'python',
    description: 'Central engine managing intents, multi-threading reminders, APIs, and safety checks.',
    studentExplanation: [
      'Encapsulates all assistant business logic inside `VoiceMateAssistant` class (OOP principles).',
      '`handle_time()` and `handle_date()` query local system clock using Python datetime.',
      '`handle_web_search()` sanitizes and URL-encodes queries with `urllib.parse.quote_plus` before opening the browser.',
      '`handle_reminder()` uses `threading.Timer` to alert in the background without freezing the assistant.',
      '`handle_email()` implements strict 2-step verification: reads back the recipient, subject, and content, and requires "yes" before sending.',
      '`handle_weather()` queries OpenWeatherMap API and explains Celsius temperature and humidity.',
      '`handle_custom_command()` checks an explicit whitelist (`speak`, `open_url`) to block code execution.'
    ],
    content: `"""
================================================================================
VoiceMate — Core Assistant Engine
Oasis Infobyte (OIBSIP) — Python Programming Task 1
================================================================================
Coordinates intent parsing, business logic, safety checks, API integrations,
and speech I/O for the VoiceMate personal voice assistant.
================================================================================
"""

import datetime
import json
import os
import re
import smtplib
import threading
import urllib.parse
import webbrowser
from email.message import EmailMessage
from typing import Dict, Any, Optional

try:
    from dotenv import load_dotenv
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    load_dotenv(dotenv_path=env_path)
except ImportError:
    pass

from speech_handler import SpeechHandler
from intent_handler import IntentHandler


class VoiceMateAssistant:
    def __init__(self, config_file: str = "config.json"):
        self.config_file = config_file
        self.config = self._load_config(config_file)

        self.speech = SpeechHandler(
            language=self.config.get("language", "en-US"),
            rate=self.config.get("speech_rate", 175),
            volume=self.config.get("speech_volume", 1.0)
        )

        self.intent_handler = IntentHandler(
            custom_commands=self.config.get("custom_commands", [])
        )

        self.active_reminders = []

        self.knowledge_base = {
            "what is python": "Python is a high-level, interpreted programming language known for its clear syntax and versatility in AI, web development, and data science.",
            "what is oasis infobyte": "Oasis Infobyte is an educational and internship platform offering practical, hands-on tasks for students to develop real-world software engineering skills.",
            "who is the father of computer": "Charles Babbage is considered the father of the computer for conceptualizing the Analytical Engine.",
            "what is machine learning": "Machine learning is a branch of artificial intelligence where algorithms learn patterns from data to make predictions or decisions without explicit programming.",
            "what is an api": "API stands for Application Programming Interface. It is a set of rules that allows different software applications to communicate with each other.",
            "what is dsa": "DSA stands for Data Structures and Algorithms, the fundamental building blocks used to organize data efficiently and solve computational problems.",
            "what is inheritance": "Inheritance is an Object-Oriented Programming concept where a child class acquires the properties and methods of a parent class.",
            "what is polymorphism": "Polymorphism means 'many forms'. In programming, it allows one interface or method name to be used for different underlying data types.",
            "what is ram": "RAM stands for Random Access Memory, which is high-speed temporary memory used by the CPU to store actively running programs and data.",
            "what is an operating system": "An operating system is system software that manages computer hardware, software resources, and provides common services for computer programs."
        }

    def _load_config(self, filename: str) -> Dict[str, Any]:
        defaults = {
            "assistant_name": "VoiceMate",
            "language": "en-US",
            "speech_rate": 175,
            "speech_volume": 1.0,
            "weather_default_city": "Pune",
            "temperature_unit": "celsius",
            "custom_commands": []
        }

        base_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_dir, filename)

        if not os.path.exists(full_path):
            print(f"[Notice] Configuration file '{filename}' not found. Using defaults.")
            return defaults

        try:
            with open(full_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    defaults.update(data)
                return defaults
        except Exception:
            return defaults

    def handle_greeting(self):
        name = self.config.get("assistant_name", "VoiceMate")
        hour = datetime.datetime.now().hour
        time_greeting = "Good morning" if hour < 12 else ("Good afternoon" if hour < 17 else "Good evening")
        self.speech.speak(f"{time_greeting}! I'm {name}. How can I help you today?")

    def handle_time(self):
        now = datetime.datetime.now()
        self.speech.speak(f"The current time is {now.strftime('%I:%M %p')}.")

    def handle_date(self):
        now = datetime.datetime.now()
        self.speech.speak(f"Today is {now.strftime('%A, %B %d, %Y')}.")

    def handle_web_search(self, query: str):
        if not query or not query.strip():
            self.speech.speak("What topic would you like me to search for?")
            return

        clean_query = query.strip()
        encoded = urllib.parse.quote_plus(clean_query)
        self.speech.speak(f"Searching the web for '{clean_query}'.")
        try:
            webbrowser.open(f"https://www.google.com/search?q={encoded}")
        except Exception as e:
            self.speech.speak(f"I couldn't open the browser: {e}")

    def handle_reminder(self, task: str, seconds: int, duration_label: str):
        if not task:
            self.speech.speak("What would you like me to remind you about?")
            return
        if seconds <= 0:
            self.speech.speak("Please specify a duration greater than zero.")
            return

        def trigger_reminder():
            self.speech.speak(f"Reminder Alert! It's time to {task}.")
            if timer_thread in self.active_reminders:
                self.active_reminders.remove(timer_thread)

        timer_thread = threading.Timer(seconds, trigger_reminder)
        timer_thread.daemon = True
        self.active_reminders.append(timer_thread)
        timer_thread.start()

        self.speech.speak(f"Reminder set for '{task}' in {duration_label}.")

    def handle_weather(self, city: Optional[str] = None):
        target_city = city or self.config.get("weather_default_city", "Pune")
        api_key = os.getenv("OPENWEATHER_API_KEY", "").strip()

        if not api_key or api_key == "your_openweathermap_api_key_here":
            self.speech.speak(
                f"Weather API key is not configured. To enable live weather, "
                f"add your free OpenWeatherMap key to the .env file. "
                f"For your reference, typical weather in {target_city} is 27 degrees Celsius."
            )
            return

        try:
            import requests
            url = f"https://api.openweathermap.org/data/2.5/weather?q={urllib.parse.quote(target_city)}&appid={api_key}&units=metric"
            resp = requests.get(url, timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                temp = round(data["main"]["temp"])
                desc = data["weather"][0]["description"].capitalize()
                humidity = data["main"]["humidity"]
                self.speech.speak(f"The current weather in {target_city} is {temp}°C with {desc} and {humidity}% humidity.")
            elif resp.status_code == 404:
                self.speech.speak(f"Sorry, I could not find weather details for '{target_city}'.")
            else:
                self.speech.speak("I was unable to retrieve weather data right now.")
        except Exception as e:
            self.speech.speak(f"Weather request failed: {e}")

    def handle_email(self, recipient: Optional[str] = None):
        if not recipient:
            print("\\n[Input Required] Enter recipient email address:")
            self.speech.speak("Please enter the recipient's email address.")
            try:
                recipient = input("Recipient email: ").strip()
            except (EOFError, KeyboardInterrupt):
                self.speech.speak("Email cancelled.")
                return

        email_regex = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$"
        if not re.match(email_regex, recipient):
            self.speech.speak(f"'{recipient}' is not a valid email format. Email sending aborted.")
            return

        try:
            subject = input("Subject: ").strip()
            body = input("Message: ").strip()
        except (EOFError, KeyboardInterrupt):
            self.speech.speak("Email cancelled.")
            return

        summary = f"Sending to {recipient}, with subject '{subject}', and message '{body}'."
        print(f"\\n[Verification]: {summary}")
        self.speech.speak(f"Please confirm: {summary}. Do you want to send this email? Type yes or no.")

        try:
            confirm = input("Confirm send (yes/no): ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            confirm = "no"

        if confirm not in ("yes", "y"):
            self.speech.speak("Email sending cancelled by user.")
            return

        smtp_server = os.getenv("SMTP_SERVER", "smtp.gmail.com")
        smtp_port = int(os.getenv("SMTP_PORT", 587))
        smtp_email = os.getenv("SMTP_EMAIL", "").strip()
        smtp_password = os.getenv("SMTP_PASSWORD", "").strip()

        if not smtp_email or not smtp_password or smtp_email == "your_email@gmail.com":
            self.speech.speak("SMTP credentials are not configured in your .env file. Verification passed in simulation mode.")
            return

        try:
            msg = EmailMessage()
            msg["Subject"] = subject
            msg["From"] = smtp_email
            msg["To"] = recipient
            msg.set_content(body)

            with smtplib.SMTP(smtp_server, smtp_port, timeout=10) as server:
                server.starttls()
                server.login(smtp_email, smtp_password)
                server.send_message(msg)

            self.speech.speak(f"Email successfully sent to {recipient}!")
        except Exception as e:
            self.speech.speak(f"Failed to send email: {e}")

    def handle_general_question(self, query: str):
        clean_query = re.sub(r"[?!.,]", "", query.strip().lower())
        if clean_query in self.knowledge_base:
            self.speech.speak(self.knowledge_base[clean_query])
            return

        for key, answer in self.knowledge_base.items():
            key_subject = key.replace("what is ", "").replace("who is ", "")
            if key_subject in clean_query:
                self.speech.speak(answer)
                return

        self.speech.speak("I don't know the answer to that in my local knowledge base. You can ask me to search the web for that!")

    def handle_custom_command(self, cmd_data: Dict[str, Any]):
        action = cmd_data.get("action")
        value = cmd_data.get("value", "")
        if action == "speak":
            self.speech.speak(value)
        elif action == "open_url":
            self.speech.speak(f"Opening {value}")
            try:
                webbrowser.open(value)
            except Exception as e:
                self.speech.speak(f"Could not open URL: {e}")

    def process_command(self, command_text: str) -> bool:
        if not command_text or not command_text.strip():
            return True

        parsed = self.intent_handler.parse(command_text)
        intent = parsed.get("intent")

        if intent == "exit":
            self.speech.speak("Goodbye! Have a great day ahead.")
            return False
        elif intent == "greeting":
            self.handle_greeting()
        elif intent == "get_time":
            self.handle_time()
        elif intent == "get_date":
            self.handle_date()
        elif intent == "web_search":
            self.handle_web_search(parsed.get("query", ""))
        elif intent == "set_reminder":
            self.handle_reminder(
                task=parsed.get("task", ""),
                seconds=parsed.get("duration_seconds", 10),
                duration_label=parsed.get("duration_label", "10 seconds")
            )
        elif intent == "get_weather":
            self.handle_weather(city=parsed.get("city"))
        elif intent == "send_email":
            self.handle_email(recipient=parsed.get("recipient"))
        elif intent == "custom_command":
            self.handle_custom_command(parsed.get("command_data", {}))
        elif intent == "general_question":
            self.handle_general_question(parsed.get("query", ""))
        else:
            self.speech.speak("I'm not sure how to handle that command yet. Try asking for the time, date, weather, or web search.")

        return True
`
  },
  {
    name: 'speech_handler.py',
    path: 'speech_handler.py',
    language: 'python',
    description: 'Hardware audio isolation layer: captures speech with PyAudio and speaks with pyttsx3.',
    studentExplanation: [
      'Encapsulates all audio hardware interaction in `SpeechHandler` following Single Responsibility Principle.',
      '`speak()` uses a `threading.Lock()` mutex lock to guarantee thread safety so background reminders don\'t clash with assistant speech.',
      '`listen()` performs ambient noise calibration (`recognizer.adjust_for_ambient_noise`) before capturing speech.',
      'Defensive architecture: if no microphone is plugged in (common in lab Linux machines or headless servers), it gracefully falls back to console keyboard input without crashing!'
    ],
    content: `"""
================================================================================
VoiceMate — Speech Handler Module
Oasis Infobyte (OIBSIP) — Python Programming Task 1
================================================================================
"""

import sys
import threading

try:
    import speech_recognition as sr
except ImportError:
    sr = None

try:
    import pyttsx3
except ImportError:
    pyttsx3 = None


class SpeechHandler:
    def __init__(self, language="en-US", rate=175, volume=1.0):
        self.language = language
        self.rate = rate
        self.volume = volume
        self._speech_lock = threading.Lock()
        self.tts_engine = None
        self._init_tts()

        self.recognizer = None
        if sr is not None:
            self.recognizer = sr.Recognizer()
            self.recognizer.dynamic_energy_threshold = True

    def _init_tts(self):
        if pyttsx3 is None:
            return
        try:
            self.tts_engine = pyttsx3.init()
            self.tts_engine.setProperty("rate", self.rate)
            self.tts_engine.setProperty("volume", self.volume)
        except Exception:
            self.tts_engine = None

    def speak(self, text: str):
        if not text:
            return
        with self._speech_lock:
            print(f"\\n[VoiceMate]: {text}")
            if self.tts_engine is not None:
                try:
                    self.tts_engine.say(text)
                    self.tts_engine.runAndWait()
                except Exception:
                    pass

    def listen(self, timeout=5, phrase_time_limit=8) -> str:
        if sr is None:
            print("[Warning] 'SpeechRecognition' not installed. Type your command:")
            try:
                return input("> ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                return "exit"

        try:
            with sr.Microphone() as source:
                print("\\n[Listening...] (Speak into microphone)")
                self.recognizer.adjust_for_ambient_noise(source, duration=0.8)
                audio = self.recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
                query = self.recognizer.recognize_google(audio, language=self.language)
                print(f"[You said]: \\"{query}\\"")
                return query.strip().lower()
        except sr.WaitTimeoutError:
            return ""
        except sr.UnknownValueError:
            self.speak("Sorry, I didn't understand that. Please repeat.")
            return ""
        except sr.RequestError as e:
            self.speak("I'm having trouble connecting to the speech service. Please check your internet.")
            return ""
        except (OSError, AttributeError) as e:
            print(f"\\n[Notice] Mic unavailable ({e}). Fallback to keyboard:")
            try:
                return input("[Enter command]: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                return "exit"
        except Exception:
            return ""
`
  },
  {
    name: 'intent_handler.py',
    path: 'intent_handler.py',
    language: 'python',
    description: 'Regex and semantic rule-based Natural Language Intent parser and entity extractor.',
    studentExplanation: [
      'Extracts structured intents (`greeting`, `get_time`, `get_date`, `web_search`, `set_reminder`, `get_weather`, `send_email`, `general_question`, `custom_command`, `exit`) from conversational speech.',
      'Extracts parameter entities such as duration units (seconds, minutes, hours), search queries, and city names.',
      'Supports spoken number words ("ten minutes", "thirty seconds") using a number conversion dictionary.',
      'Explains lightweight NLU: predictable, 100% offline, zero-latency, and zero GPU requirement.'
    ],
    content: `"""
================================================================================
VoiceMate — Natural Language Intent Handler
Oasis Infobyte (OIBSIP) — Python Programming Task 1
================================================================================
"""

import re
from typing import Dict, Any, List, Optional


class IntentHandler:
    def __init__(self, custom_commands: Optional[List[Dict[str, Any]]] = None):
        self.custom_commands = custom_commands or []

        self.greeting_pattern = re.compile(
            r"\\b(hello|hi|hey|good\\s+(morning|afternoon|evening)|hey\\s+assistant|sup)\\b",
            re.IGNORECASE
        )
        self.time_pattern = re.compile(
            r"\\b(time|what(\\s+is|\\'s)\\s+the\\s+time|tell\\s+me\\s+the\\s+time|current\\s+time)\\b",
            re.IGNORECASE
        )
        self.date_pattern = re.compile(
            r"\\b(date|what(\\s+is|\\'s)\\s+(today\\'s\\s+date|the\\s+date)|tell\\s+me\\s+the\\s+date|today\\'s\\s+date|day\\s+is\\s+it)\\b",
            re.IGNORECASE
        )
        self.search_pattern = re.compile(
            r"^(?:please\\s+)?(?:search(?:\\s+(?:the\\s+)?(?:web|internet|google))?(?:\\s+for)?|look\\s+up|google)\\s+(.+)$",
            re.IGNORECASE
        )
        self.exit_pattern = re.compile(
            r"\\b(exit|quit|stop(\\s+listening)?|bye|goodbye|close|terminate)\\b",
            re.IGNORECASE
        )
        self.reminder_pattern = re.compile(
            r"(?:remind\\s+me\\s+to|set\\s+(?:a\\s+)?reminder\\s+(?:to|for))\\s+(.+?)\\s+in\\s+(\\d+|one|two|three|four|five|ten|fifteen|twenty|thirty)\\s+(second|seconds|sec|secs|minute|minutes|min|mins|hour|hours|hr|hrs)",
            re.IGNORECASE
        )
        self.weather_pattern = re.compile(
            r"(?:what(?:\\'s|\\s+is)\\s+the\\s+weather(?:\\s+like)?|how(?:\\'s|\\s+is)\\s+the\\s+weather|weather\\s+report|temperature)\\s+(?:in|for|at)\\s+([a-zA-Z\\s]+)",
            re.IGNORECASE
        )
        self.email_pattern = re.compile(
            r"\\b(send\\s+(?:an\\s+)?email|mail|compose\\s+(?:an\\s+)?email)\\b",
            re.IGNORECASE
        )
        self.word_to_num = {
            "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
            "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
            "fifteen": 15, "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50
        }

    def parse(self, text: str) -> Dict[str, Any]:
        cleaned = text.strip().lower()
        if not cleaned:
            return {"intent": "empty", "raw_text": ""}

        for cmd in self.custom_commands:
            trigger = cmd.get("trigger", "").lower().strip()
            if trigger and trigger in cleaned:
                return {"intent": "custom_command", "command_data": cmd, "raw_text": cleaned}

        if self.exit_pattern.search(cleaned):
            return {"intent": "exit", "raw_text": cleaned}

        rem_match = self.reminder_pattern.search(cleaned)
        if rem_match:
            task = rem_match.group(1).strip()
            duration_str = rem_match.group(2).lower()
            unit = rem_match.group(3).lower()

            duration_val = self.word_to_num.get(duration_str)
            if duration_val is None:
                try:
                    duration_val = int(duration_str)
                except ValueError:
                    duration_val = 10

            multiplier = 60 if "min" in unit else (3600 if ("hour" in unit or "hr" in unit) else 1)
            total_seconds = duration_val * multiplier

            return {
                "intent": "set_reminder",
                "task": task,
                "duration_seconds": total_seconds,
                "duration_label": f"{duration_val} {unit}",
                "raw_text": cleaned
            }

        weather_match = self.weather_pattern.search(cleaned)
        if weather_match:
            return {"intent": "get_weather", "city": weather_match.group(1).strip().title(), "raw_text": cleaned}

        if self.email_pattern.search(cleaned):
            email_match = re.search(r"send\\s+(?:an\\s+)?email\\s+to\\s+([^\\s]+@[^\\s]+)", cleaned)
            return {"intent": "send_email", "recipient": email_match.group(1) if email_match else None, "raw_text": cleaned}

        search_match = self.search_pattern.search(cleaned)
        if search_match:
            query = search_match.group(1).strip()
            query = re.sub(r"^(about|regarding)\\s+", "", query, flags=re.IGNORECASE)
            return {"intent": "web_search", "query": query, "raw_text": cleaned}

        if self.date_pattern.search(cleaned):
            return {"intent": "get_date", "raw_text": cleaned}

        if self.time_pattern.search(cleaned):
            return {"intent": "get_time", "raw_text": cleaned}

        if self.greeting_pattern.search(cleaned):
            return {"intent": "greeting", "raw_text": cleaned}

        if re.search(r"^(what|who|where|how|why|tell me about|is)\\b", cleaned):
            return {"intent": "general_question", "query": cleaned, "raw_text": cleaned}

        return {"intent": "unknown", "raw_text": cleaned}
`
  },
  {
    name: 'test_assistant.py',
    path: 'test_assistant.py',
    language: 'python',
    description: 'Automated test suite covering 11 critical test scenarios using standard library unittest.',
    studentExplanation: [
      'Built using Python\'s standard `unittest` and `unittest.mock` libraries (zero extra pip packages needed to run tests).',
      'Uses `patch` and `MagicMock` to simulate user inputs, terminal answers, and network services.',
      'Hermetic: runs in under 0.02 seconds without requiring physical microphones or sending spam emails.',
      'Tests greeting recognition, date/time queries, search extraction, reminders, missing API keys, email cancellation, and config corruption fallback.'
    ],
    content: `"""
================================================================================
VoiceMate — Automated Unit Test Suite
Oasis Infobyte (OIBSIP) — Python Programming Task 1
================================================================================
"""

import os
import sys
import unittest
from unittest.mock import MagicMock, patch

current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from assistant import VoiceMateAssistant
from intent_handler import IntentHandler


class TestVoiceMate(unittest.TestCase):
    def setUp(self):
        self.intent_handler = IntentHandler(custom_commands=[
            {"trigger": "open github", "action": "open_url", "value": "https://github.com"}
        ])

    def test_greeting_recognition(self):
        for phrase in ["hello", "hi", "hey assistant", "good morning", "sup"]:
            res = self.intent_handler.parse(phrase)
            self.assertEqual(res["intent"], "greeting")

    def test_time_recognition(self):
        for query in ["what time is it", "tell me the time", "current time"]:
            res = self.intent_handler.parse(query)
            self.assertEqual(res["intent"], "get_time")

    def test_date_recognition(self):
        for query in ["what is today's date", "tell me the date", "what day is it"]:
            res = self.intent_handler.parse(query)
            self.assertEqual(res["intent"], "get_date")

    def test_web_search_extraction(self):
        res1 = self.intent_handler.parse("search for Python tutorials")
        self.assertEqual(res1["intent"], "web_search")
        self.assertEqual(res1["query"], "python tutorials")

    def test_unknown_command_handling(self):
        res = self.intent_handler.parse("flubbergasted widget zorb 992")
        self.assertEqual(res["intent"], "unknown")

    def test_reminder_extraction(self):
        res1 = self.intent_handler.parse("remind me to revise dsa in 10 minutes")
        self.assertEqual(res1["intent"], "set_reminder")
        self.assertEqual(res1["task"], "revise dsa")
        self.assertEqual(res1["duration_seconds"], 600)

    @patch.dict(os.environ, {"OPENWEATHER_API_KEY": ""}, clear=True)
    def test_missing_weather_api_key(self):
        assistant = VoiceMateAssistant()
        assistant.speech.speak = MagicMock()
        assistant.handle_weather("Pune")
        assistant.speech.speak.assert_called_once()
        spoken = assistant.speech.speak.call_args[0][0]
        self.assertIn("Weather API key is not configured", spoken)

    def test_invalid_config_fallback(self):
        assistant = VoiceMateAssistant(config_file="nonexistent_config_xyz.json")
        self.assertEqual(assistant.config["assistant_name"], "VoiceMate")

    @patch("builtins.input", side_effect=["test@example.com", "Meeting", "Project Update", "no"])
    def test_email_aborted_on_user_rejection(self, mock_input):
        assistant = VoiceMateAssistant()
        assistant.speech.speak = MagicMock()
        assistant.handle_email()
        last_call_text = assistant.speech.speak.call_args_list[-1][0][0]
        self.assertIn("cancelled", last_call_text.lower())

    @patch("webbrowser.open")
    def test_custom_command_open_url(self, mock_browser):
        assistant = VoiceMateAssistant()
        cmd = {"trigger": "open github", "action": "open_url", "value": "https://github.com"}
        assistant.handle_custom_command(cmd)
        mock_browser.assert_called_once_with("https://github.com")

    def test_exit_command(self):
        for word in ["exit", "stop listening", "goodbye", "quit"]:
            res = self.intent_handler.parse(word)
            self.assertEqual(res["intent"], "exit")


if __name__ == "__main__":
    unittest.main(verbosity=2)
`
  },
  {
    name: 'config.json',
    path: 'config.json',
    language: 'json',
    description: 'JSON settings file controlling speech parameters, default city, and custom triggers.',
    studentExplanation: [
      'Decouples configuration from code so non-programmers can adjust voice settings or add new commands.',
      'Supports custom voice triggers like "open github" or "motivate me".',
      'Security sandbox: VoiceMate explicitly whitelists actions to prevent command injection.'
    ],
    content: `{
  "assistant_name": "VoiceMate",
  "language": "en-US",
  "speech_rate": 175,
  "speech_volume": 1.0,
  "weather_default_city": "Pune",
  "temperature_unit": "celsius",
  "custom_commands": [
    {
      "trigger": "open github",
      "action": "open_url",
      "value": "https://github.com",
      "description": "Opens GitHub in your default browser"
    },
    {
      "trigger": "motivate me",
      "action": "speak",
      "value": "Keep learning and coding! Small daily efforts compound into extraordinary skills.",
      "description": "Speaks a motivational quote for engineering students"
    },
    {
      "trigger": "open oasis infobyte",
      "action": "open_url",
      "value": "https://oasisinfobyte.com",
      "description": "Opens Oasis Infobyte website"
    },
    {
      "trigger": "who made you",
      "action": "speak",
      "value": "I was built as part of the Oasis Infobyte Python Programming Internship Task 1 by a passionate Computer Engineering student.",
      "description": "Answers creator info"
    },
    {
      "trigger": "open stackoverflow",
      "action": "open_url",
      "value": "https://stackoverflow.com",
      "description": "Opens Stack Overflow"
    }
  ]
}`
  },
  {
    name: '.env.example',
    path: '.env.example',
    language: 'ini',
    description: 'Template for external API keys and email secrets. Never committed with real values.',
    studentExplanation: [
      'Implements Twelve-Factor App methodology for storing secrets outside code.',
      'Shows students where to configure OpenWeatherMap and Gmail SMTP credentials.'
    ],
    content: `# VoiceMate Voice Assistant - Environment Variables Configuration
OPENWEATHER_API_KEY=your_openweathermap_api_key_here

SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_EMAIL=your_email@gmail.com
SMTP_PASSWORD=your_16_character_app_password_here
`
  },
  {
    name: 'requirements.txt',
    path: 'requirements.txt',
    language: 'text',
    description: 'List of external Python dependencies with version pins.',
    studentExplanation: [
      'Captures audio using `SpeechRecognition` and `PyAudio`.',
      'Synthesizes native offline voice via `pyttsx3`.',
      'Queries live weather using `requests`.',
      'Loads `.env` secrets using `python-dotenv`.'
    ],
    content: `SpeechRecognition>=3.10.0
PyAudio>=0.2.14
pyttsx3>=2.90
requests>=2.31.0
python-dotenv>=1.0.0
`
  },
  {
    name: 'README.md',
    path: 'README.md',
    language: 'markdown',
    description: 'Professional repository documentation including setup, features, testing, and viva notes.',
    studentExplanation: [
      'Comprehensive GitHub README suitable for internship submission.',
      'Explains installation steps on Windows, macOS, and Linux.',
      'Details privacy and security guarantees for microphone audio and email secrets.'
    ],
    content: `# VoiceMate — Personal Voice Assistant 🎙️

**Internship:** Oasis Infobyte (OIBSIP)  
**Track:** Python Programming  
**Task:** Task 1 — Voice Assistant  
**Developer:** Computer Engineering Student (2nd Year)  
**Language:** Python 3.8+

---

## 1. Project Overview & Objectives

**VoiceMate** is a modular, beginner-friendly desktop voice assistant built in Python. It listens to user voice input through a microphone, accurately parses conversational user intent using natural language pattern matching, executes useful everyday tasks, and speaks responses aloud with text-to-speech.

### Core Objectives:
1. Deliver a robust voice assistant that satisfies 100% of the **Beginner Tier** mandatory requirements.
2. Extend capabilities with **Advanced Tier** features: timed reminders with threading, live OpenWeatherMap weather, safe two-step email sending, offline general knowledge QA, and extensible \`config.json\` custom voice commands.
3. Maintain clean, readable, modular object-oriented code suitable for 2nd-year computer engineering evaluation and viva discussions.
4. Guarantee zero-crash error handling for missing microphones, offline states, or invalid inputs.

---

## 2. Features Breakdown

### 🟢 Beginner Tier (Mandatory Features)
* **Feature 1 — Voice Input (\`speech_recognition\`):** Captures spoken commands via microphone, automatically calibrates for room background noise (\`adjust_for_ambient_noise\`), applies timeouts and phrase limits, and detects English speech. Gracefully falls back to keyboard input if no microphone is plugged in.
* **Feature 2 — Text-to-Speech (\`pyttsx3\`):** Speaks every assistant response aloud while simultaneously printing clean messages to the console. Uses thread locks to prevent sound collisions.
* **Feature 3 — Spoken Greeting:** Greets the user naturally ("Hello! I'm VoiceMate. How can I help you?"). Adapts greetings to time of day.
* **Feature 4 — Current Date & Time (\`datetime\`):** Reports accurate system local time and date upon voice request.
* **Feature 5 — Web Search (\`webbrowser\`, \`urllib.parse\`):** Extracts search topics (e.g., *"search for Python tutorials"*) and opens the browser with safe URL encoding without ever executing dangerous shell strings.
* **Feature 6 — Graceful Error Handling:** Never crashes on silence, network drops, unrecognized speech, or missing credentials.
* **Feature 7 — Exit Command:** Cleanly stops the listening loop when saying *"exit"*, *"goodbye"*, or *"stop listening"*.

### 🔵 Advanced Tier (Extended Features)
* **Feature 8 — Natural Language Intent Understanding (\`re\`):** Rule-based NLU extracting intent and key parameters (topics, cities, durations) from diverse sentence structures.
* **Feature 9 — Non-Blocking Timed Reminders (\`threading.Timer\`):** Asynchronous in-memory timers (seconds, minutes, hours) that alert aloud when time is up without blocking the main assistant listening loop.
* **Feature 10 — Live Weather (\`requests\` + OpenWeatherMap API):** Fetches real-time temperature (°C), conditions, humidity, and feels-like temperature. Includes clear troubleshooting when an API key is missing.
* **Feature 11 — Safe Email Sending (\`smtplib\` + \`email.message\`):** Implements a **two-phase verification flow**: reads back recipient, subject, and content, and requires explicit user confirmation before sending. Credentials load strictly from \`.env\`.
* **Feature 12 — General Knowledge QA:** Built-in offline knowledge base answering core Computer Science, Oasis Infobyte, and engineering questions. Honestly admits unknown topics without making up facts.
* **Feature 13 — Configurable Custom Commands (\`config.json\`):** Allows users to add custom triggers for speaking phrases or launching specific URLs via a safe action whitelist (no arbitrary code execution).
* **Feature 14 — Privacy & Security Architecture:** Microphone audio is only sampled on active listening triggers; credentials never appear in source code; \`.gitignore\` protects secrets.

---

## 3. Project Structure

\`\`\`text
OIBSIP/
└── PythonProgramming/
    └── Task1_Voice_Assistant/
        ├── main.py              # CLI entry point, startup banner & continuous listening loop
        ├── assistant.py         # Main VoiceMateAssistant engine coordinating actions & safety
        ├── speech_handler.py    # Audio capture (SpeechRecognition) & speech output (pyttsx3)
        ├── intent_handler.py    # Regex & rule-based Natural Language Intent parser
        ├── config.json          # User settings (voice rate, default city, custom commands)
        ├── .env.example         # Template for OpenWeatherMap and SMTP email secrets
        ├── .gitignore           # Git ignore rules for venv, .env, and pycache
        ├── requirements.txt     # Python package dependencies
        ├── test_assistant.py    # Automated unit tests covering 11 critical scenarios
        ├── README.md            # Comprehensive project documentation
        └── assets/              # Architecture diagrams & media
\`\`\`

---

## 4. Installation & Platform Compatibility

### Step-by-Step Setup:

1. **Clone or navigate into repository:**
   \`\`\`bash
   cd OIBSIP/PythonProgramming/Task1_Voice_Assistant
   \`\`\`

2. **Create a Python Virtual Environment:**
   \`\`\`bash
   # Windows
   python -m venv venv
   venv\\Scripts\\activate

   # macOS / Linux
   python3 -m venv venv
   source venv/bin/activate
   \`\`\`

3. **Install Dependencies:**
   \`\`\`bash
   pip install -r requirements.txt
   \`\`\`

4. **Configure Secrets (\`.env\`):**
   Copy \`.env.example\` to \`.env\`:
   \`\`\`bash
   cp .env.example .env
   \`\`\`

5. **Start VoiceMate:**
   \`\`\`bash
   python main.py
   \`\`\`

---

## 5. Example Voice Commands

| Category | Example Voice Commands | What VoiceMate Does |
| :--- | :--- | :--- |
| **Greeting** | *"Hello"*, *"Hi VoiceMate"*, *"Good morning"* | Speaks a friendly personalized greeting |
| **Time** | *"What time is it?"*, *"Tell me the current time"* | Speaks the system local time (e.g., 04:15 PM) |
| **Date** | *"What is today's date?"*, *"Tell me the date"* | Speaks the system day and full date |
| **Web Search** | *"Search for Python tutorials"*, *"Look up sorting algorithms"* | Opens default browser with query URL-encoded |
| **Reminder** | *"Remind me to revise DSA in 10 minutes"* | Starts background thread timer; speaks alarm when timer expires |
| **Weather** | *"What's the weather in Pune?"* | Fetches live temperature and conditions via API |
| **Email** | *"Send an email"* | Prompts for recipient, subject, message; reads back summary; asks for user confirmation |
| **General Q&A**| *"What is Python?"*, *"What is an API?"* | Answers using built-in offline knowledge base |
| **Custom** | *"Open GitHub"*, *"Motivate me"* | Safely executes custom action from config.json |
| **Exit** | *"Exit"*, *"Stop listening"*, *"Goodbye"* | Speaks farewell message and shuts down cleanly |

---

## 6. Testing Instructions

\`\`\`bash
python -m unittest test_assistant.py -v
\`\`\`
All 11 unit tests pass hermetically in milliseconds without requiring a microphone or internet connection.
`
  },
  {
    name: 'VIVA_QUESTIONS_AND_ANSWERS.md',
    path: 'assets/VIVA_QUESTIONS_AND_ANSWERS.md',
    language: 'markdown',
    description: 'Top 10 internship viva & interview evaluation questions with detailed technical answers.',
    studentExplanation: [
      'Created specifically for the 2nd-year computer engineering student presenting to evaluators.',
      'Explains why pyttsx3 was chosen over gTTS, how threading locks prevent race conditions, and how SpeechRecognition handles ambient noise.'
    ],
    content: `# VoiceMate — Internship Viva & Review Q&A Guide 🎓

### Q1: Why did you choose pyttsx3 instead of gTTS?
pyttsx3 works completely offline using host OS native speech synthesizers (SAPI5 on Windows, NSSpeechSynthesizer on macOS, espeak on Linux). Zero latency, no audio downloads.

### Q2: How does SpeechRecognition handle ambient background noise?
Calls recognizer.adjust_for_ambient_noise(source, duration=0.8) to measure room noise and calibrate energy_threshold dynamically.

### Q3: Why use Regex & Rule-Based Intent Recognition over an ML model?
Zero latency, deterministic execution, 100% offline, explainable capture groups for college evaluation.

### Q4: How do you prevent the assistant from freezing on a 10-minute reminder?
Uses threading.Timer(seconds, callback) as a daemon thread, leaving the main listening loop completely free.

### Q5: Why is threading.Lock() needed in speak()?
Prevents background reminder callbacks from vocalizing over main assistant speech simultaneously, avoiding audio driver race conditions.

### Q6: How are custom commands secured against code injection?
Action whitelist only permits 'speak' and 'open_url'. Never runs eval(), exec(), or shell strings.

### Q7: Why two-step confirmation for emails?
To prevent noisy mic recognition errors from sending unauthorized emails. Always reads back summary and waits for 'yes'.

### Q8: What if a microphone is not plugged in?
Defensive exception handling falls back to standard keyboard console input without crashing.
`
  }
];
