/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TopNav } from './components/TopNav';
import { VoiceStudio } from './components/VoiceStudio';
import { CodeExplorer } from './components/CodeExplorer';
import { TestRunner } from './components/TestRunner';
import { VivaAndChecklist } from './components/VivaAndChecklist';
import { INITIAL_FILES } from './data/projectFiles';
import { PythonFileItem, AssistantConfig } from './types';
import { exportProjectAsZip } from './utils/zipExport';

export default function App() {
  const [activeTab, setActiveTab] = useState<'studio' | 'code' | 'tests' | 'viva'>('studio');
  const [files, setFiles] = useState<PythonFileItem[]>(INITIAL_FILES);
  const [isExporting, setIsExporting] = useState(false);
  const [config, setConfig] = useState<AssistantConfig>({
    assistant_name: 'VoiceMate',
    language: 'en-US',
    speech_rate: 175,
    speech_volume: 1.0,
    weather_default_city: 'Pune',
    temperature_unit: 'celsius',
    custom_commands: [
      {
        trigger: 'open github',
        action: 'open_url',
        value: 'https://github.com',
        description: 'Opens GitHub in your default browser',
      },
      {
        trigger: 'motivate me',
        action: 'speak',
        value: 'Keep learning and coding! Small daily efforts compound into extraordinary skills.',
        description: 'Speaks a motivational quote for engineering students',
      },
      {
        trigger: 'open oasis infobyte',
        action: 'open_url',
        value: 'https://oasisinfobyte.com',
        description: 'Opens Oasis Infobyte website',
      },
      {
        trigger: 'who made you',
        action: 'speak',
        value: 'I was built as part of the Oasis Infobyte Python Programming Internship Task 1 by a passionate Computer Engineering student.',
        description: 'Answers creator info',
      },
      {
        trigger: 'open stackoverflow',
        action: 'open_url',
        value: 'https://stackoverflow.com',
        description: 'Opens Stack Overflow',
      },
    ],
  });

  // Fetch real files from local disk via server API on load
  useEffect(() => {
    fetch('/api/python-files')
      .then((res) => {
        if (res.ok) return res.json();
        return null;
      })
      .then((data: Record<string, string> | null) => {
        if (!data) return;
        setFiles((prev) =>
          prev.map((item) => {
            if (data[item.path]) {
              return { ...item, content: data[item.path] };
            }
            return item;
          })
        );
      })
      .catch(() => {
        // Fallback silently to pre-bundled files
      });
  }, []);

  const handleExportZip = async () => {
    setIsExporting(true);
    try {
      const fileRecord: Record<string, string> = {};
      for (const f of files) {
        fileRecord[f.path] = f.content;
      }
      // Also ensure .gitignore and .env.example are added
      fileRecord['.gitignore'] = `# Python Bytecode\n__pycache__/\n*.py[cod]\n.env\nvenv/\n`;
      fileRecord['.env.example'] = `# Environment Variables\nOPENWEATHER_API_KEY=your_openweathermap_api_key_here\nSMTP_SERVER=smtp.gmail.com\nSMTP_PORT=587\nSMTP_EMAIL=your_email@gmail.com\nSMTP_PASSWORD=your_app_password_here\n`;
      fileRecord['requirements.txt'] = `SpeechRecognition>=3.10.0\nPyAudio>=0.2.14\npyttsx3>=2.90\nrequests>=2.31.0\npython-dotenv>=1.0.0\n`;

      await exportProjectAsZip(fileRecord);
    } catch (err) {
      console.error('Failed to export zip:', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Top Bar adhering to Top Bar Contract */}
      <TopNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onExportZip={handleExportZip}
        isExporting={isExporting}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTab === 'studio' && <VoiceStudio config={config} />}
        {activeTab === 'code' && (
          <CodeExplorer
            files={files}
            config={config}
            onUpdateConfig={(newConfig) => setConfig(newConfig)}
          />
        )}
        {activeTab === 'tests' && <TestRunner />}
        {activeTab === 'viva' && <VivaAndChecklist />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/90 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span>VoiceMate Voice Assistant</span>
            <span aria-hidden="true">·</span>
            <span>Oasis Infobyte Internship (OIBSIP)</span>
            <span aria-hidden="true">·</span>
            <span>Task 1: Python Programming</span>
          </div>
          <div>
            Built with Python 3, speech_recognition, pyttsx3, and multi-threading.
          </div>
        </div>
      </footer>
    </div>
  );
}
