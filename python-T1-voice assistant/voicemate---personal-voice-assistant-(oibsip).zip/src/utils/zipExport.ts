import JSZip from 'jszip';

export async function exportProjectAsZip(files: Record<string, string>): Promise<void> {
  const zip = new JSZip();

  // Root folder inside the zip matching Oasis Infobyte structure
  const root = zip.folder('OIBSIP/PythonProgramming/Task1_Voice_Assistant');
  if (!root) return;

  for (const [relativePath, content] of Object.entries(files)) {
    root.file(relativePath, content);
  }

  const blob = await zip.generateAsync({ type: 'blob' });
  const downloadUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = downloadUrl;
  anchor.download = 'OIBSIP_Task1_Voice_Assistant_VoiceMate.zip';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(downloadUrl);
}
