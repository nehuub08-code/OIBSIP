import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Send,
  Clock,
  Calendar,
  CloudSun,
  Mail,
  Search,
  HelpCircle,
  Sparkles,
  AlertCircle,
  Play,
  RotateCcw,
  CheckCircle2,
  X
} from 'lucide-react';
import { AssistantConfig, LogMessage, ActiveReminder } from '../types';

interface VoiceStudioProps {
  config: AssistantConfig;
}

export const VoiceStudio: React.FC<VoiceStudioProps> = ({ config }) => {
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [speechSynthesisMuted, setSpeechSynthesisMuted] = useState(false);
  const [speechRate, setSpeechRate] = useState(1.0);
  const [messages, setMessages] = useState<LogMessage[]>([
    {
      id: 'init-1',
      sender: 'system',
      text: 'VoiceMate initialized. Ready for voice or text commands.',
      timestamp: new Date().toLocaleTimeString(),
    },
    {
      id: 'init-2',
      sender: 'assistant',
      text: `Hello! I'm ${config.assistant_name}. How can I help you today?`,
      timestamp: new Date().toLocaleTimeString(),
      intent: 'greeting',
    },
  ]);
  const [activeReminders, setActiveReminders] = useState<ActiveReminder[]>([]);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailForm, setEmailForm] = useState({
    recipient: 'mentor@oasisinfobyte.com',
    subject: 'OIBSIP Task 1 Voice Assistant Submission',
    body: 'Hello Mentor, I have completed Task 1 Voice Assistant with all beginner and advanced features.',
  });
  const [weatherCity, setWeatherCity] = useState(config.weather_default_city || 'Pune');
  const [weatherData, setWeatherData] = useState({
    city: 'Pune',
    temp: 28,
    condition: 'Clear Sky',
    humidity: 45,
    feelsLike: 29,
  });

  const chatBottomRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Scroll to bottom of terminal log on new message
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Speech Recognition setup (Web Speech API)
  useEffect(() => {
    const SpeechRecognitionAPI =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognitionAPI) {
      const recognition = new SpeechRecognitionAPI();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = config.language || 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          handleProcessCommand(transcript);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, [config.language]);

  // Active reminders countdown interval (Feature 9)
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveReminders((prev) => {
        const updated: ActiveReminder[] = [];
        for (const rem of prev) {
          if (rem.remainingSeconds <= 1) {
            // Trigger reminder alarm
            triggerReminderAlert(rem.task);
          } else {
            updated.push({
              ...rem,
              remainingSeconds: rem.remainingSeconds - 1,
            });
          }
        }
        return updated;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [speechSynthesisMuted, speechRate]);

  // Trigger sound and assistant voice alert when reminder completes
  const triggerReminderAlert = (task: string) => {
    const alertMsg = `Reminder Alert! It's time to ${task}.`;
    addMessage('assistant', alertMsg, 'set_reminder');
    speakResponse(alertMsg);

    // Audio chime using Web Audio API
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
      osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.15); // A5
      gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.4);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.4);
    } catch {
      // AudioContext fallback
    }
  };

  // Text-to-Speech function (Feature 2)
  const speakResponse = (text: string) => {
    if (speechSynthesisMuted || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = speechRate;
    utterance.lang = config.language || 'en-US';
    window.speechSynthesis.speak(utterance);
  };

  const addMessage = (sender: 'user' | 'assistant' | 'system', text: string, intent?: string) => {
    setMessages((prev) => [
      ...prev,
      {
        id: `${Date.now()}-${Math.random()}`,
        sender,
        text,
        timestamp: new Date().toLocaleTimeString(),
        intent,
      },
    ]);
  };

  const toggleListening = () => {
    if (!recognitionRef.current) {
      addMessage(
        'system',
        'Web Speech Recognition API is not supported in this browser. Please type commands in the box below.'
      );
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
      } catch (err) {
        console.error('Recognition start error:', err);
      }
    }
  };

  // Command intent parser matching Python backend logic
  const handleProcessCommand = (command: string) => {
    const raw = command.trim();
    if (!raw) return;

    addMessage('user', raw);
    const lower = raw.toLowerCase();

    // 1. Check custom commands from config
    for (const cmd of config.custom_commands) {
      if (cmd.trigger && lower.includes(cmd.trigger.toLowerCase())) {
        if (cmd.action === 'speak') {
          addMessage('assistant', cmd.value, 'custom_command');
          speakResponse(cmd.value);
        } else if (cmd.action === 'open_url') {
          const resp = `Opening ${cmd.value}`;
          addMessage('assistant', resp, 'custom_command');
          speakResponse(resp);
          window.open(cmd.value, '_blank', 'noopener,noreferrer');
        }
        return;
      }
    }

    // 2. Exit command (Feature 7)
    if (/\b(exit|stop listening|goodbye|bye|quit)\b/i.test(lower)) {
      const farewell = 'Goodbye! Have a great day ahead.';
      addMessage('assistant', farewell, 'exit');
      speakResponse(farewell);
      if (isListening) {
        recognitionRef.current?.stop();
        setIsListening(false);
      }
      return;
    }

    // 3. Greeting (Feature 3)
    if (/\b(hello|hi|hey|good (morning|afternoon|evening)|hey assistant)\b/i.test(lower)) {
      const hour = new Date().getHours();
      const timeGreet = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
      const resp = `${timeGreet}! I'm ${config.assistant_name}. How can I assist you with your tasks today?`;
      addMessage('assistant', resp, 'greeting');
      speakResponse(resp);
      return;
    }

    // 4. Date & Time (Feature 4)
    if (/\b(time|what('s| is) the time|tell me the time|current time)\b/i.test(lower)) {
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const resp = `The current time is ${timeStr}.`;
      addMessage('assistant', resp, 'get_time');
      speakResponse(resp);
      return;
    }

    if (/\b(date|what('s| is) today's date|tell me the date|today's date|day is it)\b/i.test(lower)) {
      const now = new Date();
      const dateStr = now.toLocaleDateString([], {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
      const resp = `Today is ${dateStr}.`;
      addMessage('assistant', resp, 'get_date');
      speakResponse(resp);
      return;
    }

    // 5. Web Search (Feature 5)
    const searchMatch = lower.match(
      /^(?:please\s+)?(?:search(?:\s+(?:the\s+)?(?:web|internet|google))?(?:\s+for)?|look\s+up|google)\s+(.+)$/i
    );
    if (searchMatch) {
      let query = searchMatch[1].trim();
      query = query.replace(/^(about|regarding)\s+/i, '');
      const resp = `Searching the web for '${query}'. Opening Google results in a new tab.`;
      addMessage('assistant', resp, 'web_search');
      speakResponse(resp);
      window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, '_blank', 'noopener,noreferrer');
      return;
    }

    // 6. Timed Reminder (Feature 9)
    const reminderMatch = lower.match(
      /(?:remind\s+me\s+to|set\s+(?:a\s+)?reminder\s+(?:to|for))\s+(.+?)\s+in\s+(\d+|one|two|three|four|five|ten|fifteen|twenty|thirty)\s+(second|seconds|sec|secs|minute|minutes|min|mins|hour|hours|hr|hrs)/i
    );
    if (reminderMatch) {
      const task = reminderMatch[1].trim();
      const durStr = reminderMatch[2].toLowerCase();
      const unit = reminderMatch[3].toLowerCase();

      const wordMap: Record<string, number> = {
        one: 1, two: 2, three: 3, four: 4, five: 5,
        ten: 10, fifteen: 15, twenty: 20, thirty: 30,
      };
      let durVal = wordMap[durStr] || parseInt(durStr, 10) || 10;
      let totalSeconds = durVal;
      if (unit.includes('min')) totalSeconds = durVal * 60;
      if (unit.includes('hour') || unit.includes('hr')) totalSeconds = durVal * 3600;

      const newReminder: ActiveReminder = {
        id: `${Date.now()}`,
        task,
        totalSeconds,
        remainingSeconds: totalSeconds,
        createdAt: new Date(),
      };
      setActiveReminders((prev) => [...prev, newReminder]);

      const resp = `Reminder set for '${task}' in ${durVal} ${unit}. I will alert you as soon as the timer ends!`;
      addMessage('assistant', resp, 'set_reminder');
      speakResponse(resp);
      return;
    }

    // 7. Live Weather (Feature 10)
    const weatherMatch = lower.match(
      /(?:what(?:'s|\s+is)\s+the\s+weather(?:\s+like)?|how(?:'s|\s+is)\s+the\s+weather|weather\s+report|temperature)\s+(?:in|for|at)\s+([a-zA-Z\s]+)/i
    );
    if (weatherMatch || /\b(weather|temperature|forecast)\b/i.test(lower)) {
      const city = weatherMatch ? weatherMatch[1].trim() : weatherCity;
      const capitalizedCity = city.charAt(0).toUpperCase() + city.slice(1);
      
      // Update weather demo card
      setWeatherData({
        city: capitalizedCity,
        temp: capitalizedCity.toLowerCase() === 'pune' ? 28 : (capitalizedCity.toLowerCase() === 'mumbai' ? 31 : 24),
        condition: 'Clear Sky',
        humidity: 48,
        feelsLike: 29,
      });

      const resp = `The weather in ${capitalizedCity} is currently 28°C with Clear Sky and 48% humidity. In Python, this integrates with the OpenWeatherMap API using the key in .env.`;
      addMessage('assistant', resp, 'get_weather');
      speakResponse(resp);
      return;
    }

    // 8. Email Sending (Feature 11)
    if (/\b(send\s+(?:an\s+)?email|mail|compose\s+(?:an\s+)?email)\b/i.test(lower)) {
      setShowEmailModal(true);
      const resp =
        "Initiating email sending protocol. Feature 11 requires a strict two-step verification: I'll read back the recipient, subject, and message, and wait for your explicit confirmation before dispatching.";
      addMessage('assistant', resp, 'send_email');
      speakResponse(resp);
      return;
    }

    // 9. General Question QA (Feature 12)
    const knowledgeBase: Record<string, string> = {
      'what is python':
        'Python is a high-level, interpreted programming language known for its clear syntax and versatility in AI, web development, and data science.',
      'what is oasis infobyte':
        'Oasis Infobyte is an educational internship platform offering practical hands-on tasks for students to develop real-world software engineering skills.',
      'what is machine learning':
        'Machine learning is a subset of artificial intelligence where algorithms learn patterns from training data to make predictions without being explicitly programmed.',
      'who is the father of computer':
        'Charles Babbage is considered the father of the computer for designing the Analytical Engine in the 1830s.',
      'what is an api':
        'API stands for Application Programming Interface. It provides a structured set of rules for different applications to exchange data seamlessly.',
      'what is dsa':
        'DSA stands for Data Structures and Algorithms, the fundamental tools used to organize memory efficiently and solve computational problems.',
      'what is inheritance':
        'Inheritance is an Object-Oriented Programming concept where a child class inherits methods and attributes from a parent class to promote code reuse.',
    };

    for (const [key, answer] of Object.entries(knowledgeBase)) {
      const subject = key.replace('what is ', '').replace('who is ', '');
      if (lower.includes(subject)) {
        addMessage('assistant', answer, 'general_question');
        speakResponse(answer);
        return;
      }
    }

    if (/^(what|who|where|how|why|tell me about|is)\b/i.test(lower)) {
      const resp =
        "I don't have the answer to that in my local offline knowledge base. In Python, VoiceMate can search Google for that topic, or answer questions about Python, computing, and Oasis Infobyte!";
      addMessage('assistant', resp, 'general_question');
      speakResponse(resp);
      return;
    }

    // Unknown command (Feature 6)
    const fallback =
      "I'm not sure how to handle that command yet. Try asking for the time, today's date, weather, web search, or setting a reminder.";
    addMessage('assistant', fallback, 'unknown');
    speakResponse(fallback);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    handleProcessCommand(inputText);
    setInputText('');
  };

  const executeSampleCommand = (cmd: string) => {
    handleProcessCommand(cmd);
  };

  const confirmEmailSend = () => {
    setShowEmailModal(false);
    const resp = `Verification confirmed! Email has been dispatched to ${emailForm.recipient} with subject '${emailForm.subject}'. In Python, smtplib uses SSL/TLS and app credentials from .env safely.`;
    addMessage('assistant', resp, 'send_email');
    speakResponse(resp);
  };

  const cancelEmailSend = () => {
    setShowEmailModal(false);
    const resp = 'Email dispatch cancelled by user. Security protocol respected.';
    addMessage('assistant', resp, 'send_email');
    speakResponse(resp);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Voice Assistant Header Banner */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-medium text-indigo-400">
              <span>Oasis Infobyte Internship</span>
              <span aria-hidden="true">·</span>
              <span>Python Programming Task 1</span>
              <span aria-hidden="true">·</span>
              <span>Interactive Voice Studio</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              VoiceMate Personal Voice Assistant
            </h1>
            <p className="text-sm text-slate-400 max-w-2xl">
              Talk directly using your microphone or click sample commands below. Voice responses,
              reminders, web searches, and intent parsing run in real time.
            </p>
          </div>

          {/* Audio Controls */}
          <div className="flex items-center gap-4 bg-slate-950/80 border border-slate-800/80 rounded-xl px-4 py-2.5">
            <button
              onClick={() => setSpeechSynthesisMuted(!speechSynthesisMuted)}
              className="flex items-center gap-2 text-xs font-medium text-slate-300 hover:text-white transition-colors"
              title={speechSynthesisMuted ? 'Unmute Voice Responses' : 'Mute Voice Responses'}
            >
              {speechSynthesisMuted ? (
                <VolumeX className="w-4 h-4 text-rose-400" />
              ) : (
                <Volume2 className="w-4 h-4 text-emerald-400" />
              )}
              <span>{speechSynthesisMuted ? 'Muted' : 'Speaking Aloud'}</span>
            </button>
            <div className="h-4 w-px bg-slate-800" />
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span>Speed:</span>
              <input
                type="range"
                min="0.7"
                max="1.5"
                step="0.1"
                value={speechRate}
                onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                className="w-16 accent-indigo-500"
              />
              <span className="font-mono text-slate-300 tabular-nums">{speechRate}x</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Studio Grid: Left Console & Chat, Right Utilities */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Interactive Terminal & Voice Input */}
        <div className="lg:col-span-2 space-y-4 flex flex-col">
          {/* Terminal Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl flex flex-col h-[520px] shadow-sm overflow-hidden">
            {/* Terminal Header */}
            <div className="bg-slate-950/80 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                <span className="ml-2 font-mono text-xs text-slate-400">
                  VoiceMate Terminal Output (main.py)
                </span>
              </div>
              <button
                onClick={() =>
                  setMessages([
                    {
                      id: 'cleared',
                      sender: 'system',
                      text: 'Terminal session cleared. Ready for next command.',
                      timestamp: new Date().toLocaleTimeString(),
                    },
                  ])
                }
                className="text-xs text-slate-500 hover:text-slate-300 transition-colors flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            </div>

            {/* Terminal Message Stream */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 font-mono text-xs sm:text-sm">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`p-3 rounded-xl border ${
                    msg.sender === 'user'
                      ? 'bg-indigo-950/40 border-indigo-900/60 text-indigo-200 ml-8'
                      : msg.sender === 'assistant'
                      ? 'bg-slate-800/60 border-slate-700/60 text-slate-200 mr-8'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 text-xs'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1 text-xs opacity-75 font-sans">
                    <span className="font-semibold">
                      {msg.sender === 'user'
                        ? '[You]'
                        : msg.sender === 'assistant'
                        ? `[${config.assistant_name}]`
                        : '[System]'}
                    </span>
                    <div className="flex items-center gap-2">
                      {msg.intent && (
                        <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                          {msg.intent}
                        </span>
                      )}
                      <span className="tabular-nums text-slate-500">{msg.timestamp}</span>
                    </div>
                  </div>
                  <p className="whitespace-pre-wrap leading-relaxed font-sans">{msg.text}</p>
                </div>
              ))}
              <div ref={chatBottomRef} />
            </div>

            {/* Input Bar */}
            <div className="p-4 bg-slate-950 border-t border-slate-800">
              <form onSubmit={handleManualSubmit} className="flex items-center gap-3">
                {/* Voice Record Button */}
                <button
                  type="button"
                  onClick={toggleListening}
                  className={`relative p-3 rounded-xl transition-all flex items-center justify-center shrink-0 ${
                    isListening
                      ? 'bg-rose-600 text-white shadow-lg shadow-rose-900/50 animate-pulse'
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                  }`}
                  title={isListening ? 'Stop Listening' : 'Speak via Microphone'}
                >
                  {isListening ? <Mic className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  {isListening && (
                    <span className="absolute -top-1 -right-1 w-3 h-3 bg-rose-400 rounded-full animate-ping" />
                  )}
                </button>

                {/* Text input */}
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder={
                    isListening
                      ? 'Listening to microphone... speak now!'
                      : 'Type a voice command or click quick prompts below...'
                  }
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                />

                <button
                  type="submit"
                  disabled={!inputText.trim()}
                  className="p-3 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 rounded-xl transition-colors shrink-0"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>

              {/* Listening Status Indicator */}
              <div className="mt-2 flex items-center justify-between text-xs text-slate-500 px-1">
                <span>
                  {isListening
                    ? 'Microphone active · Capturing speech in real time...'
                    : 'Click microphone or type to test intents'}
                </span>
                <span className="font-mono text-[11px]">pyttsx3 + SpeechRecognition</span>
              </div>
            </div>
          </div>

          {/* Quick Voice Prompt Chips */}
          <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Interactive Test Voice Prompts (Click to Execute):
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => executeSampleCommand('Hello')}
                className="px-3 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700/60 transition-colors"
              >
                👋 "Hello" (Greeting)
              </button>
              <button
                onClick={() => executeSampleCommand('What time is it?')}
                className="px-3 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700/60 transition-colors"
              >
                ⏰ "What time is it?"
              </button>
              <button
                onClick={() => executeSampleCommand("What is today's date?")}
                className="px-3 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700/60 transition-colors"
              >
                📅 "Tell me the date"
              </button>
              <button
                onClick={() => executeSampleCommand('Search for Python tutorials')}
                className="px-3 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700/60 transition-colors"
              >
                🔍 "Search for Python tutorials"
              </button>
              <button
                onClick={() => executeSampleCommand('Remind me to revise DSA in 10 seconds')}
                className="px-3 py-1.5 text-xs bg-indigo-950/60 hover:bg-indigo-900/60 text-indigo-300 rounded-lg border border-indigo-800/60 transition-colors"
              >
                ⏳ "Remind me in 10 seconds"
              </button>
              <button
                onClick={() => executeSampleCommand("What's the weather in Pune?")}
                className="px-3 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700/60 transition-colors"
              >
                ⛅ "Weather in Pune"
              </button>
              <button
                onClick={() => executeSampleCommand('Send an email')}
                className="px-3 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700/60 transition-colors"
              >
                ✉️ "Send an email" (Verification)
              </button>
              <button
                onClick={() => executeSampleCommand('What is Machine Learning?')}
                className="px-3 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700/60 transition-colors"
              >
                💡 "What is Machine Learning?"
              </button>
              <button
                onClick={() => executeSampleCommand('Open GitHub')}
                className="px-3 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700/60 transition-colors"
              >
                ⚡ "Open GitHub" (Custom config)
              </button>
              <button
                onClick={() => executeSampleCommand('Motivate me')}
                className="px-3 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700/60 transition-colors"
              >
                ✨ "Motivate me" (Custom quote)
              </button>
              <button
                onClick={() => executeSampleCommand('Exit')}
                className="px-3 py-1.5 text-xs bg-rose-950/40 hover:bg-rose-900/50 text-rose-300 rounded-lg border border-rose-900/60 transition-colors"
              >
                🛑 "Exit" (Clean Shutdown)
              </button>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Live Assistant Features (Reminders, Weather, Email Status) */}
        <div className="space-y-6">
          {/* Active Reminders Card (Feature 9) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-indigo-400" />
                <h3 className="font-semibold text-white text-sm">
                  Active Reminders (Threading)
                </h3>
              </div>
              <span className="text-xs text-slate-400 font-mono tabular-nums">
                {activeReminders.length} Active
              </span>
            </div>

            {activeReminders.length === 0 ? (
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 text-center text-xs text-slate-500">
                No active timers. Say <span className="text-slate-300">"Remind me to study DSA in 10 seconds"</span> to spawn a background thread!
              </div>
            ) : (
              <div className="space-y-2.5">
                {activeReminders.map((rem) => {
                  const pct = Math.round((rem.remainingSeconds / rem.totalSeconds) * 100);
                  return (
                    <div
                      key={rem.id}
                      className="p-3 bg-slate-950 border border-indigo-900/40 rounded-xl space-y-2"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-medium text-slate-200 truncate">{rem.task}</span>
                        <span className="font-mono text-indigo-400 font-semibold tabular-nums">
                          {rem.remainingSeconds}s
                        </span>
                      </div>
                      <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-indigo-500 h-full transition-all duration-1000 rounded-full"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
            <p className="text-[11px] text-slate-500 leading-normal">
              * In Python, this runs via <code className="text-slate-400">threading.Timer</code> with a speech mutex lock to avoid speech collision.
            </p>
          </div>

          {/* Live Weather Card (Feature 10) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CloudSun className="w-5 h-5 text-amber-400" />
                <h3 className="font-semibold text-white text-sm">
                  Live Weather (OpenWeatherMap)
                </h3>
              </div>
              <span className="text-xs font-mono text-slate-400">{weatherData.city}</span>
            </div>

            <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800/80 flex items-center justify-between">
              <div>
                <div className="text-3xl font-bold text-white font-mono tabular-nums">
                  {weatherData.temp}°C
                </div>
                <div className="text-xs text-slate-400 mt-1">{weatherData.condition}</div>
              </div>
              <div className="text-right text-xs text-slate-400 space-y-1">
                <div>Feels like: {weatherData.feelsLike}°C</div>
                <div>Humidity: {weatherData.humidity}%</div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span>Test City:</span>
              <button
                onClick={() => executeSampleCommand("What's the weather in Pune?")}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-slate-300"
              >
                Pune
              </button>
              <button
                onClick={() => executeSampleCommand("What's the weather in Mumbai?")}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-slate-300"
              >
                Mumbai
              </button>
              <button
                onClick={() => executeSampleCommand("What's the weather in Delhi?")}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-slate-300"
              >
                Delhi
              </button>
            </div>
          </div>

          {/* Safe Email Sending Architecture (Feature 11) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-3">
            <div className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-emerald-400" />
              <h3 className="font-semibold text-white text-sm">
                Safe Email Dispatch Protocol
              </h3>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Feature 11 enforces <strong>two-phase verification</strong>: VoiceMate never sends an email based on single unclear voice detection. It reads back the summary and waits for confirmation.
            </p>
            <button
              onClick={() => setShowEmailModal(true)}
              className="w-full py-2 px-3 text-xs font-medium text-emerald-300 bg-emerald-950/50 hover:bg-emerald-900/50 border border-emerald-800/60 rounded-xl transition-colors text-center"
            >
              Test Email Verification Flow
            </button>
          </div>
        </div>
      </div>

      {/* Two-Step Email Confirmation Modal (Feature 11) */}
      {showEmailModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-semibold text-white">
                  Email Verification Dialog (Feature 11)
                </h3>
              </div>
              <button
                onClick={cancelEmailSend}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="text-slate-400 font-medium block mb-1">Recipient Address:</label>
                <input
                  type="email"
                  value={emailForm.recipient}
                  onChange={(e) => setEmailForm({ ...emailForm, recipient: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200"
                />
              </div>

              <div>
                <label className="text-slate-400 font-medium block mb-1">Email Subject:</label>
                <input
                  type="text"
                  value={emailForm.subject}
                  onChange={(e) => setEmailForm({ ...emailForm, subject: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200"
                />
              </div>

              <div>
                <label className="text-slate-400 font-medium block mb-1">Message Content:</label>
                <textarea
                  rows={3}
                  value={emailForm.body}
                  onChange={(e) => setEmailForm({ ...emailForm, body: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200"
                />
              </div>

              <div className="p-3 bg-emerald-950/40 border border-emerald-900/60 rounded-xl space-y-1">
                <div className="font-semibold text-emerald-300">
                  Assistant Read-Back & Confirmation:
                </div>
                <p className="text-emerald-200/90 italic">
                  "Sending to {emailForm.recipient}, with subject '{emailForm.subject}'. Do you want to send this email? Confirm with Yes or No."
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={cancelEmailSend}
                className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white bg-slate-800 rounded-lg"
              >
                No (Cancel)
              </button>
              <button
                onClick={confirmEmailSend}
                className="px-4 py-2 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm"
              >
                Yes (Confirm & Send)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
