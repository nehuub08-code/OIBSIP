import React, { useState } from 'react';
import {
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  GraduationCap,
  ListChecks,
  HelpCircle,
  ShieldCheck,
  Code2,
  FileCode2,
  Lock
} from 'lucide-react';

interface ChecklistItem {
  id: number;
  name: string;
  tier: 'Beginner' | 'Advanced';
  file: string;
  func: string;
  description: string;
  testCovered: boolean;
}

export const VivaAndChecklist: React.FC = () => {
  const [expandedViva, setExpandedViva] = useState<number | null>(0);

  const checklist: ChecklistItem[] = [
    {
      id: 1,
      name: 'Feature 1: Voice Input',
      tier: 'Beginner',
      file: 'speech_handler.py',
      func: 'SpeechHandler.listen()',
      description: 'Microphone audio capture, ambient noise calibration, timeouts, English transcription, fallback to keyboard.',
      testCovered: true,
    },
    {
      id: 2,
      name: 'Feature 2: Text-to-Speech',
      tier: 'Beginner',
      file: 'speech_handler.py',
      func: 'SpeechHandler.speak()',
      description: 'Prints responses in terminal as well as speaking aloud via pyttsx3. Thread-safe speech lock.',
      testCovered: true,
    },
    {
      id: 3,
      name: 'Feature 3: Greeting',
      tier: 'Beginner',
      file: 'assistant.py',
      func: 'handle_greeting()',
      description: 'Supports "Hello", "Hi", "Hey assistant" with time-of-day greetings.',
      testCovered: true,
    },
    {
      id: 4,
      name: 'Feature 4: Current Date & Time',
      tier: 'Beginner',
      file: 'assistant.py',
      func: 'handle_time(), handle_date()',
      description: 'Retrieves computer local time and calendar date using Python datetime module.',
      testCovered: true,
    },
    {
      id: 5,
      name: 'Feature 5: Web Search',
      tier: 'Beginner',
      file: 'assistant.py',
      func: 'handle_web_search()',
      description: 'Extracts search query, safely URL encodes, and opens default browser without shell injection.',
      testCovered: true,
    },
    {
      id: 6,
      name: 'Feature 6: Graceful Error Handling',
      tier: 'Beginner',
      file: 'assistant.py / speech_handler.py',
      func: 'listen(), process_command()',
      description: 'Handles silence, background noise, unavailable mic, unknown commands without crashing.',
      testCovered: true,
    },
    {
      id: 7,
      name: 'Feature 7: Exit Command',
      tier: 'Beginner',
      file: 'main.py / assistant.py',
      func: 'process_command()',
      description: 'Supports "exit", "stop listening", "goodbye". Speaks farewell and closes listening loop.',
      testCovered: true,
    },
    {
      id: 8,
      name: 'Feature 8: Natural Language Intent Understanding',
      tier: 'Advanced',
      file: 'intent_handler.py',
      func: 'IntentHandler.parse()',
      description: 'Regex-based entity extraction for topics, duration units, city names from diverse sentences.',
      testCovered: true,
    },
    {
      id: 9,
      name: 'Feature 9: Timed Reminders',
      tier: 'Advanced',
      file: 'assistant.py',
      func: 'handle_reminder()',
      description: 'Multi-threaded background timers using threading.Timer without freezing the main listening loop.',
      testCovered: true,
    },
    {
      id: 10,
      name: 'Feature 10: Live Weather',
      tier: 'Advanced',
      file: 'assistant.py',
      func: 'handle_weather()',
      description: 'Queries OpenWeatherMap API with key from .env; explains Celsius temperature, humidity, conditions.',
      testCovered: true,
    },
    {
      id: 11,
      name: 'Feature 11: Email Sending',
      tier: 'Advanced',
      file: 'assistant.py',
      func: 'handle_email()',
      description: 'Two-phase verification: reads back recipient, subject, and message; requires explicit "yes" confirmation.',
      testCovered: true,
    },
    {
      id: 12,
      name: 'Feature 12: General Knowledge Questions',
      tier: 'Advanced',
      file: 'assistant.py',
      func: 'handle_general_question()',
      description: 'Curated offline knowledge base of Computer Science & Python topics; honestly admits unknown queries.',
      testCovered: true,
    },
    {
      id: 13,
      name: 'Feature 13: Configurable Custom Commands',
      tier: 'Advanced',
      file: 'config.json / assistant.py',
      func: 'handle_custom_command()',
      description: 'Loads voice triggers from config.json with strict action whitelist (speak, open_url).',
      testCovered: true,
    },
    {
      id: 14,
      name: 'Feature 14: Privacy and Security',
      tier: 'Advanced',
      file: '.env.example / .gitignore / README.md',
      func: 'Security Architecture',
      description: 'Audio sampled only on command, secrets isolated in .env, .gitignore prevents git leaks.',
      testCovered: true,
    },
  ];

  const vivaQuestions = [
    {
      q: '1. Why did you choose pyttsx3 instead of gTTS (Google Text-to-Speech)?',
      a: 'pyttsx3 runs completely offline using the local operating system synthesizers (SAPI5 on Windows, NSSpeechSynthesizer on macOS, and espeak on Linux). It operates with zero latency, does not create network traffic, and works without an internet connection. In contrast, gTTS makes an external HTTP request for every spoken phrase, saves an MP3 file to disk, and requires another player to play it back.',
    },
    {
      q: '2. How does SpeechRecognition handle ambient room noise?',
      a: 'We invoke recognizer.adjust_for_ambient_noise(source, duration=0.8) as soon as the microphone input stream opens. During that brief sample, the engine measures the background sound floor and dynamically calibrates the energy_threshold. Any acoustic input below that threshold is treated as silence or ambient room noise, preventing false-positive triggers.',
    },
    {
      q: '3. Why choose Regex & Rule-Based Intent Recognition over a large Machine Learning model?',
      a: 'For a desktop assistant handling defined tasks (setting alarms, checking weather, time/date, searching topics), regex pattern matching offers:\n1. Zero latency: Instant string evaluation without GPU overhead.\n2. Deterministic execution: Every intent pattern can be unit-tested hermetically.\n3. Low resource footprint: Standard Python runs it in milliseconds without gigabytes of heavy model weights.\n4. Explainability: As a student, I can walk evaluators through each regular expression capture group.',
    },
    {
      q: '4. How do you prevent the assistant from freezing when a 10-minute reminder is set?',
      a: 'If we used time.sleep(600), the main execution thread would block and freeze, preventing any further voice capture. Instead, we use threading.Timer(seconds, callback). This creates a lightweight background thread that sleeps independently while the main thread immediately continues its listening loop. We also set daemon=True so the background timer terminates cleanly if the user exits.',
    },
    {
      q: '5. Why is a threading.Lock() mutex lock needed in SpeechHandler.speak()?',
      a: 'When an asynchronous reminder timer expires, its background thread calls speak(). If the user is actively speaking to the assistant on the main thread at that exact moment, both threads would attempt to invoke pyttsx3 simultaneously. Without a lock, this triggers audio driver race conditions, overlapping speech, or fatal segmentation faults. The threading.Lock() ensures that only one response is vocalized at a time.',
    },
    {
      q: '6. How does the application prevent arbitrary code execution from config.json?',
      a: 'config.json only accepts actions from a strict whitelist: "speak" and "open_url". The code never passes configuration values into eval(), exec(), or subprocess.run(shell=True). URLs are strictly opened via Python\'s webbrowser.open().',
    },
    {
      q: '7. Why is a two-step confirmation implemented for email sending?',
      a: 'Voice recognition in noisy environments can occasionally mishear words. Because sending an email creates a permanent real-world action, VoiceMate reads back the extracted recipient, subject, and message, and strictly waits for explicit user confirmation ("yes"). If the user says "no" or cancels, the transaction is safely aborted.',
    },
    {
      q: '8. How does the codebase handle missing physical microphones?',
      a: 'Inside speech_handler.py, the listen() function catches OSError and AttributeError (which occur if PyAudio fails or no microphone is plugged in). Instead of crashing with a traceback, it automatically falls back to standard keyboard input (input()), allowing the assistant to be demonstrated even on headless servers or PCs without a mic.',
    },
    {
      q: '9. How are API keys and sensitive credentials handled?',
      a: 'We adhere to the Twelve-Factor App methodology: no passwords, email addresses, or API keys are hard-coded in Python files. Configuration is loaded from environment variables using python-dotenv. A template .env.example is committed to GitHub, while .env is listed in .gitignore to prevent credential leakage.',
    },
    {
      q: '10. How are the unit tests designed without requiring an actual microphone or internet?',
      a: 'Our test suite test_assistant.py uses Python\'s standard unittest.mock (patch and MagicMock). We mock the audio capture, user terminal input, and external network requests. This allows all 11 unit tests to run hermetically in milliseconds on any machine without needing a microphone or live network connection.',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-medium text-indigo-400">
            <span>Oasis Infobyte Internship Task 1</span>
            <span aria-hidden="true">·</span>
            <span>Evaluation Readiness</span>
            <span aria-hidden="true">·</span>
            <span>Computer Engineering</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Requirements Checklist & Viva Preparation Guide
          </h2>
          <p className="text-sm text-slate-400 max-w-2xl">
            Review the 14 completed requirements mapped to exact Python files, plus 10 technical viva interview questions with answers for your internship presentation.
          </p>
        </div>
      </div>

      {/* 14-Feature Completion Checklist */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ListChecks className="w-5 h-5 text-indigo-400" />
            <h3 className="text-lg font-bold text-white">
              Oasis Infobyte Task 1 Feature Completion Matrix (14 / 14 Completed)
            </h3>
          </div>
          <span className="text-xs font-mono text-emerald-400 font-semibold px-2.5 py-1 rounded bg-emerald-950/60 border border-emerald-900/60">
            100% COMPLETE
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase font-mono border-b border-slate-800">
                <tr>
                  <th className="px-4 py-3">Feature & Description</th>
                  <th className="px-4 py-3">Tier</th>
                  <th className="px-4 py-3">Python Module & Function</th>
                  <th className="px-4 py-3">Automated Test</th>
                  <th className="px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {checklist.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="px-4 py-3.5 space-y-0.5">
                      <div className="font-semibold text-slate-200">{item.name}</div>
                      <div className="text-slate-400 text-[11px] max-w-md">{item.description}</div>
                    </td>
                    <td className="px-4 py-3.5 whitespace-nowrap">
                      <span
                        className={`font-mono text-[10px] px-2 py-0.5 rounded border ${
                          item.tier === 'Beginner'
                            ? 'bg-slate-950 text-slate-400 border-slate-800'
                            : 'bg-indigo-950/60 text-indigo-300 border-indigo-900/60'
                        }`}
                      >
                        {item.tier}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 font-mono text-[11px] text-slate-300">
                      <div>{item.file}</div>
                      <div className="text-slate-500 text-[10px]">{item.func}</div>
                    </td>
                    <td className="px-4 py-3.5 whitespace-nowrap">
                      <span className="text-emerald-400 font-medium">Covered in test suite</span>
                    </td>
                    <td className="px-4 py-3.5 whitespace-nowrap">
                      <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Completed</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Top 10 Viva Review Questions */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <GraduationCap className="w-5 h-5 text-indigo-400" />
          <h3 className="text-lg font-bold text-white">
            Top 10 Internship Viva / Interview Review Questions & Answers
          </h3>
        </div>
        <p className="text-xs text-slate-400">
          Click any question below to expand the technical answer prepared for 2nd-year computer engineering evaluation.
        </p>

        <div className="space-y-3">
          {vivaQuestions.map((viva, idx) => {
            const isExpanded = expandedViva === idx;
            return (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setExpandedViva(isExpanded ? null : idx)}
                  className="w-full text-left px-5 py-4 flex items-center justify-between gap-4 hover:bg-slate-800/40 transition-colors"
                >
                  <span className="font-semibold text-sm text-slate-200">{viva.q}</span>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-indigo-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
                  )}
                </button>

                {isExpanded && (
                  <div className="px-5 pb-5 pt-1 text-xs text-slate-300 border-t border-slate-800/60 leading-relaxed whitespace-pre-wrap bg-slate-950/40 font-sans">
                    {viva.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
