import React, { useState } from 'react';
import {
  FileCode,
  FolderTree,
  Copy,
  Check,
  BookOpen,
  FileText,
  Sliders,
  Settings,
  ShieldCheck,
  Save,
  Plus,
  Trash2
} from 'lucide-react';
import { PythonFileItem, AssistantConfig } from '../types';

interface CodeExplorerProps {
  files: PythonFileItem[];
  config: AssistantConfig;
  onUpdateConfig: (newConfig: AssistantConfig) => void;
}

export const CodeExplorer: React.FC<CodeExplorerProps> = ({
  files,
  config,
  onUpdateConfig,
}) => {
  const [selectedFile, setSelectedFile] = useState<PythonFileItem>(files[0] || {} as any);
  const [copied, setCopied] = useState(false);
  const [showConfigEditor, setShowConfigEditor] = useState(false);
  const [editableConfig, setEditableConfig] = useState<AssistantConfig>(config);
  const [newTrigger, setNewTrigger] = useState('');
  const [newAction, setNewAction] = useState<'speak' | 'open_url'>('speak');
  const [newValue, setNewValue] = useState('');

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleAddCustomCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTrigger.trim() || !newValue.trim()) return;

    const updated = {
      ...editableConfig,
      custom_commands: [
        ...editableConfig.custom_commands,
        {
          trigger: newTrigger.trim().toLowerCase(),
          action: newAction,
          value: newValue.trim(),
          description: `Custom command for ${newTrigger}`,
        },
      ],
    };
    setEditableConfig(updated);
    onUpdateConfig(updated);
    setNewTrigger('');
    setNewValue('');
  };

  const handleRemoveCustomCommand = (index: number) => {
    const updated = {
      ...editableConfig,
      custom_commands: editableConfig.custom_commands.filter((_, i) => i !== index),
    };
    setEditableConfig(updated);
    onUpdateConfig(updated);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Codebase & Architecture Explorer
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Inspect clean Python modules, line-by-line engineering explanations, and configure custom commands.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowConfigEditor(!showConfigEditor)}
            className={`px-3.5 py-2 rounded-lg text-xs font-medium border flex items-center gap-2 transition-colors ${
              showConfigEditor
                ? 'bg-indigo-600 text-white border-indigo-500'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>{showConfigEditor ? 'Close Config Editor' : 'Edit config.json'}</span>
          </button>
        </div>
      </div>

      {/* Optional Interactive config.json Editor (Feature 13) */}
      {showConfigEditor && (
        <div className="bg-slate-900 border border-indigo-800/80 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-semibold text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-400" />
                <span>Feature 13 — Custom Commands Configuration Editor (config.json)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Add voice triggers dynamically. VoiceMate validates permitted actions (speak, open_url) to maintain security.
              </p>
            </div>
          </div>

          {/* Form to add custom command */}
          <form onSubmit={handleAddCustomCommand} className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div>
              <label className="text-xs text-slate-400 block mb-1">Spoken Voice Trigger:</label>
              <input
                type="text"
                placeholder="e.g. open linkedin"
                value={newTrigger}
                onChange={(e) => setNewTrigger(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Permitted Action:</label>
              <select
                value={newAction}
                onChange={(e) => setNewAction(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              >
                <option value="speak">speak (Text response)</option>
                <option value="open_url">open_url (Safe Browser launch)</option>
              </select>
            </div>
            <div className="sm:col-span-2 flex items-end gap-2">
              <div className="flex-1">
                <label className="text-xs text-slate-400 block mb-1">Response Text or URL:</label>
                <input
                  type="text"
                  placeholder="e.g. https://linkedin.com or text to speak"
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Add Command</span>
              </button>
            </div>
          </form>

          {/* Current Registered Custom Commands */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-slate-300">
              Active Registered Commands in config.json:
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {editableConfig.custom_commands.map((cmd, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl flex items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-0.5 truncate">
                    <div className="font-semibold text-indigo-300">
                      Trigger: "{cmd.trigger}"
                    </div>
                    <div className="text-slate-400 truncate">
                      Action: <span className="font-mono text-slate-300">{cmd.action}</span> · Value: {cmd.value}
                    </div>
                  </div>
                  <button
                    onClick={() => handleRemoveCustomCommand(idx)}
                    className="p-1.5 text-slate-500 hover:text-rose-400 transition-colors shrink-0"
                    title="Remove Command"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Code Viewer Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Column: File Tree */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-slate-400 px-2">
            <FolderTree className="w-4 h-4" />
            <span>Repository Files</span>
          </div>

          <div className="space-y-1">
            {files.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono transition-colors flex items-center justify-between ${
                    isSelected
                      ? 'bg-indigo-600 text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileCode className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{file.name}</span>
                  </div>
                  {file.name.endsWith('.py') && (
                    <span className="text-[10px] opacity-75 font-sans">.py</span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="pt-4 border-t border-slate-800 px-2 space-y-2">
            <div className="text-[11px] font-semibold text-slate-400">Project Directory:</div>
            <div className="text-[11px] font-mono text-slate-500 bg-slate-950 p-2 rounded-lg break-all">
              OIBSIP/PythonProgramming/Task1_Voice_Assistant/
            </div>
          </div>
        </div>

        {/* Right 3 Columns: Code Content & Explanation */}
        <div className="lg:col-span-3 space-y-6">
          {/* Code Viewer Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
            {/* Header */}
            <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-indigo-400" />
                <span className="font-mono text-xs font-medium text-slate-200">
                  {selectedFile.path}
                </span>
                <span className="text-xs text-slate-500">
                  · {selectedFile.content.split('\n').length} lines
                </span>
              </div>
              <button
                onClick={handleCopyCode}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition-colors"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy File</span>
                  </>
                )}
              </button>
            </div>

            {/* Code Block with line numbers */}
            <div className="overflow-x-auto max-h-[500px] overflow-y-auto bg-slate-950 p-4 font-mono text-xs text-slate-300 leading-relaxed">
              <pre className="flex">
                <span className="select-none text-slate-600 text-right pr-4 font-mono border-r border-slate-800">
                  {selectedFile.content
                    .split('\n')
                    .map((_, i) => `${i + 1}\n`)
                    .join('')}
                </span>
                <code className="pl-4 text-slate-200 font-mono flex-1 whitespace-pre">
                  {selectedFile.content}
                </code>
              </pre>
            </div>
          </div>

          {/* Student Explanation Panel for Viva/Review */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center gap-2 text-indigo-400 font-semibold text-sm">
              <BookOpen className="w-4 h-4" />
              <span>Logic Breakdown for Internship Review & Viva ({selectedFile.name})</span>
            </div>
            <p className="text-xs text-slate-400">
              {selectedFile.description}
            </p>
            <div className="space-y-2 pt-2">
              {selectedFile.studentExplanation?.map((item, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                  <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-1.5 shrink-0" />
                  <span className="leading-relaxed">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
