import React from 'react';
import { Download, Sparkles } from 'lucide-react';

interface TopNavProps {
  activeTab: 'studio' | 'code' | 'tests' | 'viva';
  setActiveTab: (tab: 'studio' | 'code' | 'tests' | 'viva') => void;
  onExportZip: () => void;
  isExporting: boolean;
}

export const TopNav: React.FC<TopNavProps> = ({
  activeTab,
  setActiveTab,
  onExportZip,
  isExporting,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element Brand Zone */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-lg bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 font-bold">
            VM
          </div>
          <span className="text-lg font-bold tracking-tight text-white whitespace-nowrap">
            VoiceMate
          </span>
          <span className="hidden sm:inline text-xs text-slate-500 whitespace-nowrap">
            · OIBSIP Task 1
          </span>
        </div>

        {/* Zone 2: 4 clean single-line nav links */}
        <nav className="hidden md:flex items-center gap-1 sm:gap-2 text-sm font-medium text-slate-400">
          <button
            onClick={() => setActiveTab('studio')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'studio'
                ? 'bg-slate-800 text-white font-semibold'
                : 'hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            Voice Studio
          </button>
          <button
            onClick={() => setActiveTab('code')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'code'
                ? 'bg-slate-800 text-white font-semibold'
                : 'hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            Codebase Explorer
          </button>
          <button
            onClick={() => setActiveTab('tests')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'tests'
                ? 'bg-slate-800 text-white font-semibold'
                : 'hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            Python Test Runner
          </button>
          <button
            onClick={() => setActiveTab('viva')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'viva'
                ? 'bg-slate-800 text-white font-semibold'
                : 'hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            Checklist & Viva Prep
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onExportZip}
            disabled={isExporting}
            className="flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-lg transition-colors shadow-sm disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting ? 'Packaging...' : 'Export Project (.zip)'}</span>
          </button>
        </div>
      </div>

      {/* Mobile nav tabs */}
      <div className="md:hidden flex items-center justify-around px-2 py-2 border-t border-slate-800/80 bg-slate-900/40 text-xs overflow-x-auto">
        <button
          onClick={() => setActiveTab('studio')}
          className={`px-2.5 py-1 rounded ${activeTab === 'studio' ? 'bg-slate-800 text-white font-semibold' : 'text-slate-400'}`}
        >
          Studio
        </button>
        <button
          onClick={() => setActiveTab('code')}
          className={`px-2.5 py-1 rounded ${activeTab === 'code' ? 'bg-slate-800 text-white font-semibold' : 'text-slate-400'}`}
        >
          Code
        </button>
        <button
          onClick={() => setActiveTab('tests')}
          className={`px-2.5 py-1 rounded ${activeTab === 'tests' ? 'bg-slate-800 text-white font-semibold' : 'text-slate-400'}`}
        >
          Tests
        </button>
        <button
          onClick={() => setActiveTab('viva')}
          className={`px-2.5 py-1 rounded ${activeTab === 'viva' ? 'bg-slate-800 text-white font-semibold' : 'text-slate-400'}`}
        >
          Viva & Checklist
        </button>
      </div>
    </header>
  );
};
