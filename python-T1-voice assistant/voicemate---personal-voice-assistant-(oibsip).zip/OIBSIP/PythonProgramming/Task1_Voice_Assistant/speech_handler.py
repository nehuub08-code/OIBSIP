"""
================================================================================
VoiceMate — Speech Handler Module
Oasis Infobyte (OIBSIP) — Python Programming Task 1
================================================================================
Handles voice input (Microphone + SpeechRecognition) and voice output (pyttsx3).
Designed with beginner-friendly explanations, thread-safe speech locks, and
defensive fallbacks for systems without audio drivers or physical microphones.
================================================================================
"""

import sys
import threading

# We import third-party modules inside try-except blocks so the codebase
# can still run or be inspected even before libraries are installed.
try:
    import speech_recognition as sr
except ImportError:
    sr = None

try:
    import pyttsx3
except ImportError:
    pyttsx3 = None


class SpeechHandler:
    """
    SpeechHandler manages all audio input and spoken output for VoiceMate.
    
    Why separate this?
    Keeping audio code in its own module follows the Single Responsibility
    Principle (SRP). If you ever want to switch from Google Speech to Vosk (offline)
    or change TTS engines, you only need to modify this file!
    """

    def __init__(self, language="en-US", rate=175, volume=1.0):
        """
        Initialize the speech recognition and text-to-speech engines.
        
        :param language: Language code for speech recognition (default: 'en-US')
        :param rate: Speed of spoken words per minute (default: 175)
        :param volume: Volume level between 0.0 and 1.0 (default: 1.0)
        """
        self.language = language
        self.rate = rate
        self.volume = volume

        # Thread lock prevents multiple threads (e.g. background reminders)
        # from calling the TTS engine simultaneously and crashing or talking over.
        self._speech_lock = threading.Lock()

        # Initialize pyttsx3 Text-To-Speech engine
        self.tts_engine = None
        self._init_tts()

        # Initialize SpeechRecognition recognizer
        self.recognizer = None
        if sr is not None:
            self.recognizer = sr.Recognizer()
            # Dynamic energy threshold adapts to room background noise
            self.recognizer.dynamic_energy_threshold = True

    def _init_tts(self):
        """Safely initializes the pyttsx3 text-to-speech engine."""
        if pyttsx3 is None:
            return

        try:
            self.tts_engine = pyttsx3.init()
            self.tts_engine.setProperty("rate", self.rate)
            self.tts_engine.setProperty("volume", self.volume)
        except Exception as e:
            # If system audio driver (ALSA/PulseAudio/SAPI) is not available,
            # we keep self.tts_engine as None so the program prints text cleanly.
            self.tts_engine = None

    def speak(self, text: str):
        """
        Prints the message to the console AND speaks it aloud using pyttsx3.
        
        Uses a threading lock to ensure reminders and direct user responses
        do not overlap or cause sound engine race conditions.
        """
        if not text:
            return

        with self._speech_lock:
            # Feature 2 Requirement: Always print to terminal as well as speaking
            print(f"\n[VoiceMate]: {text}")

            if self.tts_engine is not None:
                try:
                    self.tts_engine.say(text)
                    self.tts_engine.runAndWait()
                except Exception:
                    # In case of runtime audio interruption, fail silently
                    # because the response was already printed in the terminal.
                    pass

    def listen(self, timeout=5, phrase_time_limit=8) -> str:
        """
        Captures microphone input and converts spoken audio into text.
        
        Feature 1 Requirements:
        - Adjusts for ambient noise.
        - Sets timeout and phrase limit.
        - Returns recognized English text in lowercase.
        - Handles speech errors gracefully.
        
        :param timeout: Maximum seconds to wait for speech to begin.
        :param phrase_time_limit: Maximum seconds for a single phrase.
        :return: Transcribed text string, or empty string on failure.
        """
        if sr is None:
            print("[Warning] 'SpeechRecognition' library is not installed.")
            print("[Fallback] Type your command below instead:")
            try:
                return input("> ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                return "exit"

        try:
            with sr.Microphone() as source:
                print("\n[Listening...] (Speak into your microphone)")
                # Adjust for background noise in the student's room/lab
                self.recognizer.adjust_for_ambient_noise(source, duration=0.8)

                # Capture audio from microphone
                audio = self.recognizer.listen(
                    source,
                    timeout=timeout,
                    phrase_time_limit=phrase_time_limit
                )

                print("[Processing speech...]")
                # Convert audio to text using Google Speech Recognition service
                query = self.recognizer.recognize_google(audio, language=self.language)
                print(f"[You said]: \"{query}\"")
                return query.strip().lower()

        except sr.WaitTimeoutError:
            # User stayed silent after listening started
            print("[Info] No speech detected (listening timed out).")
            return ""

        except sr.UnknownValueError:
            # Speech was heard but could not be understood
            # Feature 1 Requirement: "Sorry, I didn't understand that. Please repeat."
            self.speak("Sorry, I didn't understand that. Please repeat.")
            return ""

        except sr.RequestError as e:
            # Internet is down or Google Speech Recognition service is unreachable
            print(f"[Error] Network connection failed for speech service: {e}")
            self.speak("I'm having trouble connecting to the speech service. Please check your internet.")
            return ""

        except (OSError, AttributeError) as e:
            # Physical microphone not detected or PyAudio not installed
            print(f"\n[Notice] Microphone unavailable ({e}). Switching to keyboard input mode.")
            try:
                text_input = input("[Enter command]: ").strip().lower()
                return text_input
            except (EOFError, KeyboardInterrupt):
                return "exit"

        except Exception as e:
            print(f"[Unexpected audio error]: {e}")
            return ""
