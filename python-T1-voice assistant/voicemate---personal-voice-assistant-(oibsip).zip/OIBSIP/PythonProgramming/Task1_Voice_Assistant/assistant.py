"""
================================================================================
VoiceMate — Core Assistant Engine
Oasis Infobyte (OIBSIP) — Python Programming Task 1
================================================================================
Coordinates intent parsing, business logic, safety checks, API integrations,
and speech I/O for the VoiceMate personal voice assistant.
================================================================================
"""

import datetime
import json
import os
import re
import smtplib
import threading
import urllib.parse
import webbrowser
from email.message import EmailMessage
from typing import Dict, Any, Optional

# Attempt to load python-dotenv for .env support
try:
    from dotenv import load_dotenv
    # Look for .env in the same folder as this script
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    load_dotenv(dotenv_path=env_path)
except ImportError:
    pass

# Import local project modules
from speech_handler import SpeechHandler
from intent_handler import IntentHandler


class VoiceMateAssistant:
    """
    Main Assistant Class that integrates speech, intent analysis, and actions.
    
    Designed specifically for 2nd-year computer engineering students:
    - Clean object-oriented structure
    - Modular methods for each feature
    - Comprehensive error resilience (will never crash unexpectedly)
    """

    def __init__(self, config_file: str = "config.json"):
        """
        Initializes configuration, speech handlers, and active state.
        """
        self.config_file = config_file
        self.config = self._load_config(config_file)

        # Initialize speech handler with settings from config
        self.speech = SpeechHandler(
            language=self.config.get("language", "en-US"),
            rate=self.config.get("speech_rate", 175),
            volume=self.config.get("speech_volume", 1.0)
        )

        # Initialize intent parser with registered custom commands
        self.intent_handler = IntentHandler(
            custom_commands=self.config.get("custom_commands", [])
        )

        # Active background reminders list
        self.active_reminders = []

        # Local offline knowledge base (Feature 12)
        # Allows zero-dependency general question answering without paid APIs
        self.knowledge_base = {
            "what is python": "Python is a high-level, interpreted programming language known for its clear syntax and versatility in AI, web development, and data science.",
            "what is oasis infobyte": "Oasis Infobyte is an educational and internship platform offering practical, hands-on tasks for students to develop real-world software engineering skills.",
            "who is the father of computer": "Charles Babbage is considered the father of the computer for conceptualizing the Analytical Engine.",
            "what is machine learning": "Machine learning is a branch of artificial intelligence where algorithms learn patterns from data to make predictions or decisions without explicit programming.",
            "what is an api": "API stands for Application Programming Interface. It is a set of rules that allows different software applications to communicate with each other.",
            "what is dsa": "DSA stands for Data Structures and Algorithms, the fundamental building blocks used to organize data efficiently and solve computational problems.",
            "what is inheritance": "Inheritance is an Object-Oriented Programming concept where a child class acquires the properties and methods of a parent class.",
            "what is polymorphism": "Polymorphism means 'many forms'. In programming, it allows one interface or method name to be used for different underlying data types.",
            "what is ram": "RAM stands for Random Access Memory, which is high-speed temporary memory used by the CPU to store actively running programs and data.",
            "what is an operating system": "An operating system is system software that manages computer hardware, software resources, and provides common services for computer programs."
        }

    def _load_config(self, filename: str) -> Dict[str, Any]:
        """
        Loads and validates config.json.
        Gracefully falls back to default settings if file is missing or corrupted.
        """
        defaults = {
            "assistant_name": "VoiceMate",
            "language": "en-US",
            "speech_rate": 175,
            "speech_volume": 1.0,
            "weather_default_city": "Pune",
            "temperature_unit": "celsius",
            "custom_commands": []
        }

        # Resolve relative to script location
        base_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_dir, filename)

        if not os.path.exists(full_path):
            print(f"[Notice] Configuration file '{filename}' not found. Using defaults.")
            return defaults

        try:
            with open(full_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                # Validate that data is a dictionary
                if isinstance(data, dict):
                    defaults.update(data)
                return defaults
        except json.JSONDecodeError as e:
            print(f"[Warning] Invalid JSON in '{filename}' ({e}). Using default configuration.")
            return defaults
        except Exception as e:
            print(f"[Warning] Could not read '{filename}': {e}. Using default configuration.")
            return defaults

    # --------------------------------------------------------------------------
    # Feature 3: Greeting
    # --------------------------------------------------------------------------
    def handle_greeting(self):
        """Greets the user politely with the assistant name."""
        name = self.config.get("assistant_name", "VoiceMate")
        hour = datetime.datetime.now().hour
        if hour < 12:
            time_greeting = "Good morning"
        elif hour < 17:
            time_greeting = "Good afternoon"
        else:
            time_greeting = "Good evening"

        response = f"{time_greeting}! I'm {name}. How can I help you today?"
        self.speech.speak(response)

    # --------------------------------------------------------------------------
    # Feature 4: Current Date & Time
    # --------------------------------------------------------------------------
    def handle_time(self):
        """Speaks the current system local time."""
        now = datetime.datetime.now()
        current_time = now.strftime("%I:%M %p")
        self.speech.speak(f"The current time is {current_time}.")

    def handle_date(self):
        """Speaks the current system local date."""
        now = datetime.datetime.now()
        current_date = now.strftime("%A, %B %d, %Y")
        self.speech.speak(f"Today is {current_date}.")

    # --------------------------------------------------------------------------
    # Feature 5: Web Search
    # --------------------------------------------------------------------------
    def handle_web_search(self, query: str):
        """
        Extracts search query, safely URL-encodes it, and opens in default browser.
        Never executes spoken text as shell or Python code.
        """
        if not query or not query.strip():
            self.speech.speak("What topic would you like me to search for?")
            return

        clean_query = query.strip()
        encoded_query = urllib.parse.quote_plus(clean_query)
        search_url = f"https://www.google.com/search?q={encoded_query}"

        self.speech.speak(f"Searching the web for '{clean_query}'.")
        try:
            webbrowser.open(search_url)
        except Exception as e:
            self.speech.speak(f"I couldn't open the browser: {e}")

    # --------------------------------------------------------------------------
    # Feature 9: Timed Reminders (Threading & Time)
    # --------------------------------------------------------------------------
    def handle_reminder(self, task: str, seconds: int, duration_label: str):
        """
        Schedules a non-blocking background reminder using threading.Timer.
        
        Important Student Note:
        - Reminders exist in memory while the Python application is running.
        - If the user exits the app before the timer fires, the reminder ends.
        - Speech lock inside speech_handler prevents reminder from talking over active speech.
        """
        if not task:
            self.speech.speak("What would you like me to remind you about?")
            return

        if seconds <= 0:
            self.speech.speak("Please specify a duration greater than zero.")
            return

        def trigger_reminder():
            # Spoken when the background timer elapses
            self.speech.speak(f"Reminder Alert! It's time to {task}.")
            # Remove from active reminders list
            if timer_thread in self.active_reminders:
                self.active_reminders.remove(timer_thread)

        # Create daemon thread timer so program exit isn't blocked if user quits
        timer_thread = threading.Timer(seconds, trigger_reminder)
        timer_thread.daemon = True
        self.active_reminders.append(timer_thread)
        timer_thread.start()

        self.speech.speak(f"Reminder set for '{task}' in {duration_label}.")

    # --------------------------------------------------------------------------
    # Feature 10: Live Weather (OpenWeatherMap API)
    # --------------------------------------------------------------------------
    def handle_weather(self, city: Optional[str] = None):
        """
        Retrieves current weather using OpenWeatherMap API with env key.
        Handles missing credentials, unknown cities, and network errors gracefully.
        """
        target_city = city or self.config.get("weather_default_city", "Pune")
        api_key = os.getenv("OPENWEATHER_API_KEY", "").strip()

        # Check for missing or placeholder API key
        if not api_key or api_key == "your_openweathermap_api_key_here":
            self.speech.speak(
                f"Weather API key is not configured. To enable live weather, "
                f"add your free OpenWeatherMap key to the .env file. "
                f"For your reference, typical weather in {target_city} is 27 degrees Celsius."
            )
            return

        # Attempt to make requests call
        try:
            import requests
            url = f"https://api.openweathermap.org/data/2.5/weather?q={urllib.parse.quote(target_city)}&appid={api_key}&units=metric"
            response = requests.get(url, timeout=5)

            if response.status_code == 200:
                data = response.json()
                temp = round(data["main"]["temp"])
                feels_like = round(data["main"]["feels_like"])
                desc = data["weather"][0]["description"].capitalize()
                humidity = data["main"]["humidity"]

                speech_msg = (
                    f"The current weather in {target_city} is {temp}°C with {desc}. "
                    f"It feels like {feels_like}°C with {humidity}% humidity."
                )
                self.speech.speak(speech_msg)

            elif response.status_code == 404:
                self.speech.speak(f"Sorry, I could not find weather details for '{target_city}'. Please check the city name.")
            elif response.status_code == 401:
                self.speech.speak("The OpenWeatherMap API key provided in your .env file is invalid or still activating.")
            else:
                self.speech.speak("I was unable to retrieve weather data right now. Please try again later.")

        except Exception as e:
            self.speech.speak(f"Weather service request failed: {e}")

    # --------------------------------------------------------------------------
    # Feature 11: Email Sending (smtplib + email.message + Confirmation)
    # --------------------------------------------------------------------------
    def handle_email(self, recipient: Optional[str] = None):
        """
        Guides the user through sending an email with strict verification.
        
        Security Requirements:
        - Prompts for confirmation before sending.
        - Reads back recipient, subject, and message.
        - Validates recipient email syntax.
        - Secrets loaded strictly from .env.
        """
        # Step 1: Get recipient
        if not recipient:
            print("\n[Input Required] Enter recipient email address:")
            self.speech.speak("Please enter or specify the recipient's email address.")
            try:
                recipient = input("Recipient email: ").strip()
            except (EOFError, KeyboardInterrupt):
                self.speech.speak("Email cancelled.")
                return

        # Basic email validation
        email_regex = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
        if not re.match(email_regex, recipient):
            self.speech.speak(f"'{recipient}' is not a valid email format. Email sending aborted.")
            return

        # Step 2: Get subject
        print("\n[Input Required] Enter email subject:")
        self.speech.speak("What is the subject of the email?")
        try:
            subject = input("Subject: ").strip()
        except (EOFError, KeyboardInterrupt):
            self.speech.speak("Email cancelled.")
            return

        # Step 3: Get message body
        print("\n[Input Required] Enter email message content:")
        self.speech.speak("What message would you like to send?")
        try:
            body = input("Message: ").strip()
        except (EOFError, KeyboardInterrupt):
            self.speech.speak("Email cancelled.")
            return

        # Step 4: Read back and require explicit confirmation
        summary = f"Sending to {recipient}, with subject '{subject}', and message '{body}'."
        print(f"\n[Verification]: {summary}")
        self.speech.speak(f"Please confirm: {summary}. Do you want to send this email? Type yes or no.")

        try:
            confirm = input("Confirm send (yes/no): ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            confirm = "no"

        if confirm not in ("yes", "y"):
            self.speech.speak("Email sending cancelled by user.")
            return

        # Step 5: Check SMTP credentials
        smtp_server = os.getenv("SMTP_SERVER", "smtp.gmail.com")
        smtp_port = int(os.getenv("SMTP_PORT", 587))
        smtp_email = os.getenv("SMTP_EMAIL", "").strip()
        smtp_password = os.getenv("SMTP_PASSWORD", "").strip()

        if not smtp_email or not smtp_password or smtp_email == "your_email@gmail.com":
            self.speech.speak(
                "SMTP credentials are not configured in your .env file. "
                "To send actual emails, add your SMTP_EMAIL and App Password to .env. "
                "Simulating email dispatch: verification passed successfully!"
            )
            return

        # Step 6: Send via smtplib
        try:
            msg = EmailMessage()
            msg["Subject"] = subject
            msg["From"] = smtp_email
            msg["To"] = recipient
            msg.set_content(body)

            with smtplib.SMTP(smtp_server, smtp_port, timeout=10) as server:
                server.starttls()
                server.login(smtp_email, smtp_password)
                server.send_message(msg)

            self.speech.speak(f"Email successfully sent to {recipient}!")

        except smtplib.SMTPAuthenticationError:
            self.speech.speak("SMTP authentication failed. If using Gmail, make sure to generate an App Password.")
        except Exception as e:
            self.speech.speak(f"Failed to send email due to connection error: {e}")

    # --------------------------------------------------------------------------
    # Feature 12: General Knowledge Questions
    # --------------------------------------------------------------------------
    def handle_general_question(self, query: str):
        """
        Looks up question in local offline knowledge base.
        Honestly admits when an answer is not known without fabricating facts.
        """
        clean_query = query.strip().lower()
        # Remove trailing question marks and extra spaces
        clean_query = re.sub(r"[?!.,]", "", clean_query)

        # Direct dictionary match
        if clean_query in self.knowledge_base:
            self.speech.speak(self.knowledge_base[clean_query])
            return

        # Keyword match
        for key, answer in self.knowledge_base.items():
            # Check if main subject from key appears in query
            key_subject = key.replace("what is ", "").replace("who is ", "")
            if key_subject in clean_query:
                self.speech.speak(answer)
                return

        # Honest response requirement
        self.speech.speak(
            "I don't know the answer to that in my local knowledge base. "
            "You can ask me to search the web for that, or ask about Python and computing!"
        )

    # --------------------------------------------------------------------------
    # Feature 13: Custom Commands Execution
    # --------------------------------------------------------------------------
    def handle_custom_command(self, cmd_data: Dict[str, Any]):
        """
        Executes a validated custom command from config.json.
        Only explicitly permitted actions ('speak', 'open_url') are allowed.
        NEVER executes arbitrary code or shell commands.
        """
        action = cmd_data.get("action")
        value = cmd_data.get("value", "")

        if action == "speak":
            self.speech.speak(value)
        elif action == "open_url":
            self.speech.speak(f"Opening {value}")
            try:
                webbrowser.open(value)
            except Exception as e:
                self.speech.speak(f"Could not open URL: {e}")
        else:
            print(f"[Warning] Unsupported custom action type '{action}' ignored for security.")

    # --------------------------------------------------------------------------
    # Central Intent Dispatcher
    # --------------------------------------------------------------------------
    def process_command(self, command_text: str) -> bool:
        """
        Parses text and executes the corresponding action.
        
        :param command_text: Raw or recognized voice string.
        :return: True if assistant should continue running, False if exit requested.
        """
        if not command_text or not command_text.strip():
            return True

        parsed = self.intent_handler.parse(command_text)
        intent = parsed.get("intent")

        if intent == "exit":
            self.speech.speak("Goodbye! Have a great day ahead.")
            return False

        elif intent == "greeting":
            self.handle_greeting()

        elif intent == "get_time":
            self.handle_time()

        elif intent == "get_date":
            self.handle_date()

        elif intent == "web_search":
            self.handle_web_search(parsed.get("query", ""))

        elif intent == "set_reminder":
            self.handle_reminder(
                task=parsed.get("task", ""),
                seconds=parsed.get("duration_seconds", 10),
                duration_label=parsed.get("duration_label", "10 seconds")
            )

        elif intent == "get_weather":
            self.handle_weather(city=parsed.get("city"))

        elif intent == "send_email":
            self.handle_email(recipient=parsed.get("recipient"))

        elif intent == "custom_command":
            self.handle_custom_command(parsed.get("command_data", {}))

        elif intent == "general_question":
            self.handle_general_question(parsed.get("query", ""))

        else:
            # Feature 6: Graceful error handling for unsupported commands
            self.speech.speak(
                "I'm not sure how to handle that command yet. "
                "Try saying 'help' or ask for the time, date, weather, or web search."
            )

        return True
