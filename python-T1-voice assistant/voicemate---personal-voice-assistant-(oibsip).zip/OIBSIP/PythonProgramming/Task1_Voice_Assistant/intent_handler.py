"""
================================================================================
VoiceMate — Natural Language Intent Handler
Oasis Infobyte (OIBSIP) — Python Programming Task 1
================================================================================
Identifies user intentions from conversational spoken text using regular
expressions and semantic keyword patterns. Extracts actionable parameters
such as search topics, reminder timers, and weather city names.
================================================================================
"""

import re
from typing import Dict, Any, List, Optional


class IntentHandler:
    """
    IntentHandler extracts intents and entities from natural voice inputs.
    
    Why use Rule-Based & Regex Pattern Matching?
    For a desktop voice assistant with a focused set of tasks, regular expressions
    and structured pattern matching offer:
    1. Zero inference latency (instant response).
    2. 100% offline capability (no GPU or giant ML weights required).
    3. Deterministic, easily testable and explainable logic for college evaluation.
    """

    def __init__(self, custom_commands: Optional[List[Dict[str, Any]]] = None):
        """
        :param custom_commands: List of custom command dictionaries loaded from config.json
        """
        self.custom_commands = custom_commands or []

        # Intent Regex Patterns
        # Feature 3: Greeting
        self.greeting_pattern = re.compile(
            r"\b(hello|hi|hey|good\s+(morning|afternoon|evening)|hey\s+assistant|sup)\b",
            re.IGNORECASE
        )

        # Feature 4: Time
        self.time_pattern = re.compile(
            r"\b(time|what(\s+is|\'s)\s+the\s+time|tell\s+me\s+the\s+time|current\s+time)\b",
            re.IGNORECASE
        )

        # Feature 4: Date
        self.date_pattern = re.compile(
            r"\b(date|what(\s+is|\'s)\s+(today\'s\s+date|the\s+date)|tell\s+me\s+the\s+date|today\'s\s+date|day\s+is\s+it)\b",
            re.IGNORECASE
        )

        # Feature 5: Web Search
        # Supports: "search for python tutorials", "look up machine learning", "search google for ai"
        self.search_pattern = re.compile(
            r"^(?:please\s+)?(?:search(?:\s+(?:the\s+)?(?:web|internet|google))?(?:\s+for)?|look\s+up|google)\s+(.+)$",
            re.IGNORECASE
        )

        # Feature 7: Exit
        self.exit_pattern = re.compile(
            r"\b(exit|quit|stop(\s+listening)?|bye|goodbye|close|terminate)\b",
            re.IGNORECASE
        )

        # Feature 9: Timed Reminders
        # Supports: "remind me to revise dsa in 10 minutes", "set a reminder for meeting in 30 seconds"
        self.reminder_pattern = re.compile(
            r"(?:remind\s+me\s+to|set\s+(?:a\s+)?reminder\s+(?:to|for))\s+(.+?)\s+in\s+(\d+|one|two|three|four|five|ten|fifteen|twenty|thirty)\s+(second|seconds|sec|secs|minute|minutes|min|mins|hour|hours|hr|hrs)",
            re.IGNORECASE
        )

        # Feature 10: Weather
        # Supports: "what's the weather in Pune?", "how is the weather like in Mumbai"
        self.weather_pattern = re.compile(
            r"(?:what(?:\'s|\s+is)\s+the\s+weather(?:\s+like)?|how(?:\'s|\s+is)\s+the\s+weather|weather\s+report|temperature)\s+(?:in|for|at)\s+([a-zA-Z\s]+)",
            re.IGNORECASE
        )
        self.weather_general_pattern = re.compile(
            r"\b(weather|temperature|forecast)\b",
            re.IGNORECASE
        )

        # Feature 11: Email Sending
        self.email_pattern = re.compile(
            r"\b(send\s+(?:an\s+)?email|mail|compose\s+(?:an\s+)?email)\b",
            re.IGNORECASE
        )

        # Number word-to-integer mapping for spoken numbers
        self.word_to_num = {
            "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
            "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
            "fifteen": 15, "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50
        }

    def parse(self, text: str) -> Dict[str, Any]:
        """
        Parses raw spoken text into an intent dictionary with extracted parameters.
        
        :param text: Lowercase recognized spoken string.
        :return: Dict containing 'intent' and associated entity parameters.
        """
        cleaned = text.strip().lower()
        if not cleaned:
            return {"intent": "empty", "raw_text": ""}

        # 1. Check Custom Commands from config.json first (highest priority customization)
        for cmd in self.custom_commands:
            trigger = cmd.get("trigger", "").lower().strip()
            if trigger and trigger in cleaned:
                return {
                    "intent": "custom_command",
                    "command_data": cmd,
                    "raw_text": cleaned
                }

        # 2. Check Exit intent
        if self.exit_pattern.search(cleaned):
            return {"intent": "exit", "raw_text": cleaned}

        # 3. Check Reminder intent (Feature 9)
        rem_match = self.reminder_pattern.search(cleaned)
        if rem_match:
            task = rem_match.group(1).strip()
            duration_str = rem_match.group(2).lower()
            unit = rem_match.group(3).lower()

            # Convert number word or digits
            duration_val = self.word_to_num.get(duration_str)
            if duration_val is None:
                try:
                    duration_val = int(duration_str)
                except ValueError:
                    duration_val = 10

            # Convert unit to total seconds
            multiplier = 1
            if "min" in unit:
                multiplier = 60
            elif "hour" in unit or "hr" in unit:
                multiplier = 3600
            
            total_seconds = duration_val * multiplier

            return {
                "intent": "set_reminder",
                "task": task,
                "duration_seconds": total_seconds,
                "duration_label": f"{duration_val} {unit}",
                "raw_text": cleaned
            }

        # 4. Check Weather intent (Feature 10)
        weather_match = self.weather_pattern.search(cleaned)
        if weather_match:
            city = weather_match.group(1).strip().title()
            return {
                "intent": "get_weather",
                "city": city,
                "raw_text": cleaned
            }
        elif self.weather_general_pattern.search(cleaned):
            # User simply asked "what is the weather?" without city
            return {
                "intent": "get_weather",
                "city": None,
                "raw_text": cleaned
            }

        # 5. Check Email intent (Feature 11)
        if self.email_pattern.search(cleaned):
            # Check if recipient or subject was spoken in the same sentence
            email_match = re.search(r"send\s+(?:an\s+)?email\s+to\s+([^\s]+@[^\s]+)", cleaned)
            recipient = email_match.group(1) if email_match else None
            return {
                "intent": "send_email",
                "recipient": recipient,
                "raw_text": cleaned
            }

        # 6. Check Web Search intent (Feature 5)
        search_match = self.search_pattern.search(cleaned)
        if search_match:
            query = search_match.group(1).strip()
            # Clean up residual filler words
            query = re.sub(r"^(about|regarding)\s+", "", query, flags=re.IGNORECASE)
            return {
                "intent": "web_search",
                "query": query,
                "raw_text": cleaned
            }

        # 7. Check Date intent (Feature 4)
        if self.date_pattern.search(cleaned):
            return {"intent": "get_date", "raw_text": cleaned}

        # 8. Check Time intent (Feature 4)
        if self.time_pattern.search(cleaned):
            return {"intent": "get_time", "raw_text": cleaned}

        # 9. Check Greeting intent (Feature 3)
        if self.greeting_pattern.search(cleaned):
            return {"intent": "greeting", "raw_text": cleaned}

        # 10. General Question intent (Feature 12)
        # Any interrogative command starting with what, who, how, why, tell me
        if re.search(r"^(what|who|where|how|why|tell me about|is)\b", cleaned):
            return {
                "intent": "general_question",
                "query": cleaned,
                "raw_text": cleaned
            }

        # Fallback unknown intent
        return {"intent": "unknown", "raw_text": cleaned}
