# VoiceMate — Internship Viva & Review Q&A Guide 🎓

This guide is prepared specifically for **2nd-year Computer Engineering students** presenting **Oasis Infobyte Task 1: Voice Assistant** during their internship evaluation.

---

### Q1: Why did you choose `pyttsx3` instead of `gTTS` (Google Text-to-Speech)?
**Answer:**  
`pyttsx3` works completely offline using the host operating system's native speech synthesizers (SAPI5 on Windows, NSSpeechSynthesizer on macOS, and espeak on Linux). It does not require an active internet connection to synthesize voice, has zero latency, and allows fine-tuning speech rate and volume. In contrast, `gTTS` requires an internet request for every sentence, saves an MP3 file to disk, and requires another player to play it back.

---

### Q2: How does `SpeechRecognition` deal with ambient background noise in a room?
**Answer:**  
We call `recognizer.adjust_for_ambient_noise(source, duration=0.8)` immediately after opening the microphone stream. During that brief sample, the `SpeechRecognition` engine measures the ambient room sound level and dynamically adjusts the energy threshold (`energy_threshold`). Any sound quieter than this threshold is filtered out as background noise, preventing accidental triggers from fans or distant chatter.

---

### Q3: Why did you choose Regex & Rule-Based Intent Recognition instead of a large Machine Learning model?
**Answer:**  
For a desktop voice assistant handling structured tasks (setting alarms, checking weather, time/date, searching topics), regex-based parsing offers:
1. **Zero latency:** Instant string matching without GPU overhead.
2. **Deterministic behavior:** We can unit-test every pattern reliably.
3. **Low resource footprint:** Works instantly on standard computers without downloading gigabytes of model weights.
4. **Explainability:** As a student, I can clearly explain the capture groups and regex syntax to evaluators.

---

### Q4: How do you prevent the assistant from freezing when setting a 10-minute reminder?
**Answer:**  
If we used `time.sleep(600)`, the main thread would block and freeze, preventing the assistant from listening to further commands.  
Instead, we use `threading.Timer(seconds, callback)`. This spawns a lightweight background thread that sleeps independently while the main thread immediately continues its listening loop. We also set `daemon=True` so that if the user terminates the program, the background timer thread does not hang the process.

---

### Q5: Why is `threading.Lock()` necessary in `SpeechHandler.speak()`?
**Answer:**  
When a background reminder timer elapses, its callback thread invokes `speak()`. At that exact moment, the user might be speaking to the assistant on the main thread. Without a thread lock, both threads would simultaneously call `pyttsx3`, causing audio driver race conditions, scrambled speech, or runtime crashes. The mutex lock guarantees mutual exclusion—only one thread speaks at a time.

---

### Q6: How does the application prevent arbitrary code execution from `config.json`?
**Answer:**  
`config.json` only accepts predefined action types from a strict whitelist: `"speak"` and `"open_url"`. The code never passes configuration values into `eval()`, `exec()`, or `subprocess.run(shell=True)`. URLs are only launched in the default system browser via `webbrowser.open()`.

---

### Q7: Why is a two-step confirmation implemented for email sending?
**Answer:**  
Voice recognition in noisy environments can occasionally mishear words. Because sending an email creates a permanent real-world communication, VoiceMate reads back the extracted recipient, subject, and message, and strictly waits for explicit confirmation (`"yes"`). If the user says `"no"` or cancels, the transaction is safely aborted.

---

### Q8: How is the codebase designed to handle missing physical microphones?
**Answer:**  
Inside `speech_handler.py`, the `listen()` function catches `OSError` and `AttributeError` (which occur if PyAudio fails or no microphone is plugged in). Instead of crashing with a traceback, it automatically falls back to standard keyboard input (`input()`), allowing the assistant to be demonstrated even on headless servers or PCs without a mic.

---

### Q9: How are API keys and sensitive credentials handled?
**Answer:**  
We adhere to the Twelve-Factor App methodology:
- No passwords, email addresses, or API keys are hard-coded in Python files.
- Configuration is loaded from environment variables using `python-dotenv`.
- A template `.env.example` is committed to GitHub, while `.env` is listed in `.gitignore` to prevent credential leakage.

---

### Q10: How are the unit tests designed without requiring an actual microphone or internet?
**Answer:**  
Our test suite `test_assistant.py` uses Python's standard `unittest.mock` (`patch` and `MagicMock`). We mock the audio capture, user terminal input, and external network requests. This allows all 11 unit tests to run hermetically in milliseconds on any machine without needing a microphone or live network connection.
