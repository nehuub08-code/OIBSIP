# VoiceMate — Personal Voice Assistant 🎙️

**Internship:** Oasis Infobyte (OIBSIP)  
**Track:** Python Programming  
**Task:** Task 1 — Voice Assistant  
**Developer:** Computer Engineering Student (2nd Year)  
**Language:** Python 3.8+

---

## 1. Project Overview & Objectives

**VoiceMate** is a modular, beginner-friendly desktop voice assistant built in Python. It listens to user voice input through a microphone, accurately parses conversational user intent using natural language pattern matching, executes useful everyday tasks, and speaks responses aloud with text-to-speech.

### Core Objectives:
1. Deliver a robust voice assistant that satisfies 100% of the **Beginner Tier** mandatory requirements.
2. Extend capabilities with **Advanced Tier** features: timed reminders with threading, live OpenWeatherMap weather, safe two-step email sending, offline general knowledge QA, and extensible `config.json` custom voice commands.
3. Maintain clean, readable, modular object-oriented code suitable for 2nd-year computer engineering evaluation and viva discussions.
4. Guarantee zero-crash error handling for missing microphones, offline states, or invalid inputs.

---

## 2. Features Breakdown

### 🟢 Beginner Tier (Mandatory Features)
* **Feature 1 — Voice Input (`speech_recognition`):** Captures spoken commands via microphone, automatically calibrates for room background noise (`adjust_for_ambient_noise`), applies timeouts and phrase limits, and detects English speech. Gracefully falls back to keyboard input if no microphone is plugged in.
* **Feature 2 — Text-to-Speech (`pyttsx3`):** Speaks every assistant response aloud while simultaneously printing clean messages to the console. Uses thread locks to prevent sound collisions.
* **Feature 3 — Spoken Greeting:** Greets the user naturally ("Hello! I'm VoiceMate. How can I help you?"). Adapts greetings to time of day.
* **Feature 4 — Current Date & Time (`datetime`):** Reports accurate system local time and date upon voice request.
* **Feature 5 — Web Search (`webbrowser`, `urllib.parse`):** Extracts search topics (e.g., *"search for Python tutorials"*) and opens the browser with safe URL encoding without ever executing dangerous shell strings.
* **Feature 6 — Graceful Error Handling:** Never crashes on silence, network drops, unrecognized speech, or missing credentials.
* **Feature 7 — Exit Command:** Cleanly stops the listening loop when saying *"exit"*, *"goodbye"*, or *"stop listening"*.

### 🔵 Advanced Tier (Extended Features)
* **Feature 8 — Natural Language Intent Understanding (`re`):** Rule-based NLU extracting intent and key parameters (topics, cities, durations) from diverse sentence structures.
* **Feature 9 — Non-Blocking Timed Reminders (`threading.Timer`):** Asynchronous in-memory timers (seconds, minutes, hours) that alert aloud when time is up without blocking the main assistant listening loop.
* **Feature 10 — Live Weather (`requests` + OpenWeatherMap API):** Fetches real-time temperature (°C), conditions, humidity, and feels-like temperature. Includes clear troubleshooting when an API key is missing.
* **Feature 11 — Safe Email Sending (`smtplib` + `email.message`):** Implements a **two-phase verification flow**: reads back recipient, subject, and content, and requires explicit user confirmation before sending. Credentials load strictly from `.env`.
* **Feature 12 — General Knowledge QA:** Built-in offline knowledge base answering core Computer Science, Oasis Infobyte, and engineering questions. Honestly admits unknown topics without making up facts.
* **Feature 13 — Configurable Custom Commands (`config.json`):** Allows users to add custom triggers for speaking phrases or launching specific URLs via a safe action whitelist (no arbitrary code execution).
* **Feature 14 — Privacy & Security Architecture:** Microphone audio is only sampled on active listening triggers; credentials never appear in source code; `.gitignore` protects secrets.

---

## 3. Project Structure

```text
OIBSIP/
└── PythonProgramming/
    └── Task1_Voice_Assistant/
        ├── main.py              # CLI entry point, startup banner & continuous listening loop
        ├── assistant.py         # Main VoiceMateAssistant engine coordinating actions & safety
        ├── speech_handler.py    # Audio capture (SpeechRecognition) & speech output (pyttsx3)
        ├── intent_handler.py    # Regex & rule-based Natural Language Intent parser
        ├── config.json          # User settings (voice rate, default city, custom commands)
        ├── .env.example         # Template for OpenWeatherMap and SMTP email secrets
        ├── .gitignore           # Git ignore rules for venv, .env, and pycache
        ├── requirements.txt     # Python package dependencies
        ├── test_assistant.py    # Automated unit tests covering 11 critical scenarios
        ├── README.md            # Comprehensive project documentation
        └── assets/              # Architecture diagrams & media
```

### Module Responsibilities:
* `main.py` is the front door. It welcomes the user and orchestrates the input/output loop.
* `speech_handler.py` isolates hardware audio dependencies. If PyAudio is missing, it lets the user type in terminal without breaking.
* `intent_handler.py` turns raw strings like `"search for machine learning"` into structured data: `{"intent": "web_search", "query": "machine learning"}`.
* `assistant.py` executes the actual business logic for each intent.

---

## 4. Installation & Platform Compatibility

### Prerequisites:
* Python 3.8, 3.9, 3.10, 3.11, or 3.12 installed.
* Working microphone and speakers / headphones.

### Platform-Specific Audio Driver Setup:

#### 🪟 Windows:
Windows has built-in SAPI5 speech support.
```bash
pip install pipwin
pipwin install pyaudio
```
*(Or install directly with `pip install pyaudio` on modern Python versions).*

#### 🍏 macOS:
macOS requires PortAudio for microphone access:
```bash
brew install portaudio
pip install pyaudio
```

#### 🐧 Linux (Ubuntu / Debian / Fedora):
Linux requires ALSA/PulseAudio development headers and `espeak` for TTS:
```bash
sudo apt update
sudo apt install python3-pyaudio portaudio19-dev libespeak1 ffmpeg
```

---

### Step-by-Step Setup:

1. **Clone or navigate into the repository:**
   ```bash
   cd OIBSIP/PythonProgramming/Task1_Voice_Assistant
   ```

2. **Create a Python Virtual Environment:**
   ```bash
   # Windows
   python -m venv venv
   venv\Scripts\activate

   # macOS / Linux
   python3 -m venv venv
   source venv/bin/activate
   ```

3. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure Secrets (`.env`):**
   Copy `.env.example` to `.env`:
   ```bash
   # Windows
   copy .env.example .env

   # macOS / Linux
   cp .env.example .env
   ```
   Open `.env` in any text editor and fill in your optional API keys:
   * **OpenWeatherMap API Key:** Free key from [OpenWeatherMap](https://home.openweathermap.org/users/sign_up).
   * **Gmail SMTP App Password:** If testing email, generate an App Password from [Google Account Security](https://myaccount.google.com/apppasswords).

5. **Start VoiceMate:**
   ```bash
   python main.py
   ```

---

## 5. Example Voice Commands

| Category | Example Voice Commands | What VoiceMate Does |
| :--- | :--- | :--- |
| **Greeting** | *"Hello"*, *"Hi VoiceMate"*, *"Good morning"* | Speaks a friendly personalized greeting |
| **Time** | *"What time is it?"*, *"Tell me the current time"* | Speaks the system local time (e.g., 04:15 PM) |
| **Date** | *"What is today's date?"*, *"Tell me the date"* | Speaks the system day and full date |
| **Web Search** | *"Search for Python tutorials"*, *"Look up sorting algorithms"* | Opens default browser with query URL-encoded |
| **Reminder** | *"Remind me to revise DSA in 10 minutes"*, *"Remind me to drink water in 30 seconds"* | Starts background thread timer; speaks alarm when timer expires |
| **Weather** | *"What's the weather in Pune?"*, *"How is the weather in London?"* | Fetches live temperature and conditions via API |
| **Email** | *"Send an email"* | Prompts for recipient, subject, message; reads back summary; asks for user confirmation |
| **General Q&A**| *"What is Python?"*, *"What is Oasis Infobyte?"*, *"What is an API?"* | Answers using built-in offline knowledge base |
| **Custom** | *"Open GitHub"*, *"Motivate me"* | Safely executes custom action from `config.json` |
| **Exit** | *"Exit"*, *"Stop listening"*, *"Goodbye"* | Speaks farewell message and shuts down cleanly |

---

## 6. How to Add Custom Voice Commands

Open `config.json` and add a new item inside `"custom_commands"`:

```json
{
  "trigger": "open university portal",
  "action": "open_url",
  "value": "https://sppucar.unipune.ac.in",
  "description": "Opens university student portal"
}
```

Permitted actions are strictly restricted to:
* `"speak"`: Speaks out the provided text value.
* `"open_url"`: Opens the provided URL in the default web browser.

Arbitrary code execution or system shell commands are explicitly prohibited for security.

---

## 7. Testing Instructions

### Automated Unit Tests (Zero-Dependency):
VoiceMate includes a complete test suite mocking microphone inputs, external APIs, and email servers so tests can be run instantly anywhere:

```bash
python -m unittest test_assistant.py -v
```

**Verified Test Cases:**
1. `test_greeting_recognition`: Verifies greetings map to the correct intent.
2. `test_time_recognition`: Verifies time queries.
3. `test_date_recognition`: Verifies date queries.
4. `test_web_search_extraction`: Tests query extraction without command artifacts.
5. `test_unknown_command_handling`: Ensures unknown speech fails gracefully.
6. `test_reminder_extraction`: Tests integer and word durations (seconds/minutes).
7. `test_missing_weather_api_key`: Tests informative message when API key is missing.
8. `test_invalid_config_fallback`: Tests automatic fallback to safe defaults.
9. `test_email_aborted_on_user_rejection`: Tests safety check when user declines email confirmation.
10. `test_custom_command_open_url`: Tests custom command URL dispatch.
11. `test_exit_command`: Tests clean shutdown keywords.

### Manual Microphone & Audio Testing:
1. Run `python main.py`.
2. Speak clearly into your microphone when the prompt displays `[Listening...]`.
3. Verify that the assistant prints `[You said]: "<your phrase>"` and responds aloud.
4. If your room has background noise, VoiceMate's ambient noise calibration adjusts automatically.

---

## 8. Privacy & Security Architecture

1. **Microphone Audio:**
   * Audio is sampled only during the active `listen()` cycle (5-second timeout).
   * It is never recorded, saved to audio files, or streamed in the background.
   * Transcriptions use standard Google Speech Recognition endpoints with no user identification.
2. **Secrets & API Keys:**
   * All API keys and email credentials reside in `.env`.
   * `.gitignore` prevents secrets from ever being committed to GitHub.
3. **Email Safety:**
   * VoiceMate will **never** automatically send an email. It always reads back the full message and waits for explicit "yes" confirmation.
4. **Custom Commands Sandbox:**
   * `config.json` uses an action whitelist (`speak`, `open_url`). No `exec()`, `eval()`, or shell commands are allowed.

---

## 9. Known Limitations & Future Improvements

### Current Limitations:
* Reminders are maintained in-memory while the program runs. Closing the terminal stops active reminders.
* Speech recognition relies on an internet connection for Google Speech Recognition (offline mode can be added with `Vosk` or `PocketSphinx`).
* The general knowledge QA uses an offline curated dictionary and does not search Wikipedia dynamically without an extra library.

### Future Scope:
* Integration of offline speech recognition via `vosk` for 100% air-gapped environments.
* SQLite persistent database for reminders and user task history.
* Graphical User Interface (GUI) built with PyQt or Tkinter.
* Google Calendar or Spotify API integrations.

---

## 10. Acknowledgment

This project was built and documented as part of the **Oasis Infobyte Internship Program (OIBSIP)** under the **Python Programming Track (Task 1: Voice Assistant)**. Special thanks to the Oasis Infobyte mentors for providing structured real-world learning assignments.
