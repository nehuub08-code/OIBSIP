"""
================================================================================
VoiceMate — Personal Voice Assistant
Oasis Infobyte (OIBSIP) — Python Programming Internship Task 1
Author: Computer Engineering Student
================================================================================
Main entry point for running the voice assistant in the terminal.
Demonstrates clean startup, command overview, continuous listening loop,
and safe exit handling.
================================================================================
"""

import sys
import time
from assistant import VoiceMateAssistant


def print_banner(assistant_name: str):
    """Prints the welcoming startup banner and list of supported voice commands."""
    divider = "=" * 65
    print("\n" + divider)
    print(f"   Welcome to {assistant_name} — Your Personal Voice Assistant")
    print("   Oasis Infobyte (OIBSIP) Python Programming Internship — Task 1")
    print(divider)
    print("\nSupported Voice Commands:")
    print("  • Greeting:       'Hello', 'Hi', 'Hey assistant'")
    print("  • Date & Time:    'What time is it?', 'Tell me today\\'s date'")
    print("  • Web Search:     'Search for Python tutorials', 'Look up AI'")
    print("  • Timed Reminder: 'Remind me to study DSA in 10 seconds'")
    print("  • Live Weather:   'What\\'s the weather in Pune?'")
    print("  • Send Email:     'Send an email'")
    print("  • General Q&A:    'What is Python?', 'What is Machine Learning?'")
    print("  • Custom Config:  'Open GitHub', 'Motivate me'")
    print("  • Exit:           'Exit', 'Goodbye', 'Stop listening'")
    print(divider + "\n")


def main():
    """Initializes and runs the VoiceMate assistant loop."""
    try:
        # Step 1: Initialize the VoiceMate Assistant
        assistant = VoiceMateAssistant(config_file="config.json")
        name = assistant.config.get("assistant_name", "VoiceMate")

        # Step 2: Show startup banner
        print_banner(name)

        # Initial spoken greeting
        assistant.handle_greeting()

        # Step 3: Main continuous listening loop
        running = True
        while running:
            # Capture speech from microphone
            command_text = assistant.speech.listen(timeout=5, phrase_time_limit=8)

            if not command_text:
                # Idle or empty capture; brief pause before next listen cycle
                time.sleep(0.3)
                continue

            # Process intent and execute action
            running = assistant.process_command(command_text)

    except KeyboardInterrupt:
        # Handle Ctrl+C gracefully without dumping a messy traceback
        print("\n\n[VoiceMate]: Detected manual stop (Ctrl+C). Exiting safely...")
    except Exception as e:
        print(f"\n[Fatal Error]: An unexpected error occurred: {e}")
        sys.exit(1)
    finally:
        print("\nThank you for using VoiceMate! [Session Ended]\n")


if __name__ == "__main__":
    main()
