"""
================================================================================
VoiceMate — Automated Unit Test Suite
Oasis Infobyte (OIBSIP) — Python Programming Task 1
================================================================================
Comprehensive test cases verifying:
1. Greeting recognition
2. Date and time recognition
3. Web search topic extraction
4. Unknown command handling
5. Reminder duration & unit extraction
6. Missing weather API key handling
7. Invalid configuration file resilience
8. Email confirmation verification before dispatch
9. Custom command execution safety whitelist

Runs purely on Python's built-in `unittest` module without needing a physical
microphone, audio hardware, or external internet connections!
================================================================================
"""

import os
import sys
import unittest
from unittest.mock import MagicMock, patch

# Ensure assistant modules are importable
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from assistant import VoiceMateAssistant
from intent_handler import IntentHandler


class TestVoiceMate(unittest.TestCase):
    """Unit tests for VoiceMate Voice Assistant."""

    def setUp(self):
        """Set up test instances before each test method."""
        self.intent_handler = IntentHandler(custom_commands=[
            {"trigger": "open github", "action": "open_url", "value": "https://github.com"}
        ])

    # --------------------------------------------------------------------------
    # Test 1: Greeting Recognition
    # --------------------------------------------------------------------------
    def test_greeting_recognition(self):
        """Test variations of greetings map to 'greeting' intent."""
        test_phrases = ["hello", "hi", "hey assistant", "good morning", "sup"]
        for phrase in test_phrases:
            res = self.intent_handler.parse(phrase)
            self.assertEqual(
                res["intent"], "greeting",
                f"Failed to identify greeting for phrase: '{phrase}'"
            )

    # --------------------------------------------------------------------------
    # Test 2: Date and Time Recognition
    # --------------------------------------------------------------------------
    def test_time_recognition(self):
        """Test time query recognition."""
        time_queries = [
            "what time is it",
            "tell me the time",
            "current time",
            "what's the time"
        ]
        for query in time_queries:
            res = self.intent_handler.parse(query)
            self.assertEqual(
                res["intent"], "get_time",
                f"Failed on time query: '{query}'"
            )

    def test_date_recognition(self):
        """Test date query recognition."""
        date_queries = [
            "what is today's date",
            "tell me the date",
            "what day is it",
            "today's date"
        ]
        for query in date_queries:
            res = self.intent_handler.parse(query)
            self.assertEqual(
                res["intent"], "get_date",
                f"Failed on date query: '{query}'"
            )

    # --------------------------------------------------------------------------
    # Test 3: Web Search Topic Extraction
    # --------------------------------------------------------------------------
    def test_web_search_extraction(self):
        """Test that search topic is cleanly extracted without command keywords."""
        res1 = self.intent_handler.parse("search for Python tutorials")
        self.assertEqual(res1["intent"], "web_search")
        self.assertEqual(res1["query"], "python tutorials")

        res2 = self.intent_handler.parse("look up machine learning algorithms")
        self.assertEqual(res2["intent"], "web_search")
        self.assertEqual(res2["query"], "machine learning algorithms")

        res3 = self.intent_handler.parse("search the web for AI engineering")
        self.assertEqual(res3["intent"], "web_search")
        self.assertEqual(res3["query"], "ai engineering")

    # --------------------------------------------------------------------------
    # Test 4: Unknown Command Handling
    # --------------------------------------------------------------------------
    def test_unknown_command_handling(self):
        """Test that unsupported gibberish yields 'unknown' or graceful handling."""
        res = self.intent_handler.parse("flubbergasted widget zorb 992")
        self.assertEqual(res["intent"], "unknown")

    # --------------------------------------------------------------------------
    # Test 5: Reminder Duration & Task Extraction
    # --------------------------------------------------------------------------
    def test_reminder_extraction(self):
        """Test reminder task, number, and duration extraction for seconds/minutes."""
        # Test 1: Minutes with digit
        res1 = self.intent_handler.parse("remind me to revise dsa in 10 minutes")
        self.assertEqual(res1["intent"], "set_reminder")
        self.assertEqual(res1["task"], "revise dsa")
        self.assertEqual(res1["duration_seconds"], 600)

        # Test 2: Seconds with word
        res2 = self.intent_handler.parse("set a reminder to drink water in thirty seconds")
        self.assertEqual(res2["intent"], "set_reminder")
        self.assertEqual(res2["task"], "drink water")
        self.assertEqual(res2["duration_seconds"], 30)

    # --------------------------------------------------------------------------
    # Test 6: Missing Weather API Key Handling
    # --------------------------------------------------------------------------
    @patch.dict(os.environ, {"OPENWEATHER_API_KEY": ""}, clear=True)
    def test_missing_weather_api_key(self):
        """Test assistant explains missing API key gracefully without crashing."""
        assistant = VoiceMateAssistant()
        assistant.speech.speak = MagicMock()

        assistant.handle_weather("Pune")
        assistant.speech.speak.assert_called_once()
        spoken_text = assistant.speech.speak.call_args[0][0]
        self.assertIn("Weather API key is not configured", spoken_text)

    # --------------------------------------------------------------------------
    # Test 7: Invalid Configuration File Resilience
    # --------------------------------------------------------------------------
    def test_invalid_config_fallback(self):
        """Test assistant defaults safely if config.json contains malformed data."""
        # Point to a nonexistent file
        assistant = VoiceMateAssistant(config_file="nonexistent_config_xyz.json")
        self.assertEqual(assistant.config["assistant_name"], "VoiceMate")
        self.assertEqual(assistant.config["language"], "en-US")

    # --------------------------------------------------------------------------
    # Test 8: Email Confirmation Before Sending
    # --------------------------------------------------------------------------
    @patch("builtins.input", side_effect=["test@example.com", "Meeting", "Project Update", "no"])
    def test_email_aborted_on_user_rejection(self, mock_input):
        """Test that email is cancelled if the user does not confirm 'yes'."""
        assistant = VoiceMateAssistant()
        assistant.speech.speak = MagicMock()

        assistant.handle_email()
        # Verify speech output confirms cancellation
        last_call_text = assistant.speech.speak.call_args_list[-1][0][0]
        self.assertIn("cancelled", last_call_text.lower())

    # --------------------------------------------------------------------------
    # Test 9: Custom Command Whitelist Execution
    # --------------------------------------------------------------------------
    @patch("webbrowser.open")
    def test_custom_command_open_url(self, mock_browser):
        """Test custom command safely opens permitted URL."""
        assistant = VoiceMateAssistant()
        assistant.speech.speak = MagicMock()

        cmd = {"trigger": "open github", "action": "open_url", "value": "https://github.com"}
        assistant.handle_custom_command(cmd)

        mock_browser.assert_called_once_with("https://github.com")

    # --------------------------------------------------------------------------
    # Test 10: Exit Intent
    # --------------------------------------------------------------------------
    def test_exit_command(self):
        """Test exit keywords return 'exit' intent."""
        for word in ["exit", "stop listening", "goodbye", "quit"]:
            res = self.intent_handler.parse(word)
            self.assertEqual(res["intent"], "exit")


if __name__ == "__main__":
    unittest.main(verbosity=2)
