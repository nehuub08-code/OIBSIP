import express from 'express';
import { createServer as createViteServer } from 'vite';
import { exec } from 'child_process';
import path from 'path';
import fs from 'fs';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API endpoint to execute the real Python unit test suite
  app.post('/api/run-tests', (req, res) => {
    const testPath = path.resolve('OIBSIP/PythonProgramming/Task1_Voice_Assistant/test_assistant.py');
    exec(`python3 "${testPath}"`, { timeout: 10000 }, (error, stdout, stderr) => {
      res.json({
        success: !error,
        code: error ? error.code : 0,
        stdout: stdout || '',
        stderr: stderr || '',
        timestamp: new Date().toISOString()
      });
    });
  });

  // API endpoint to execute a Python one-liner or assistant intent test
  app.post('/api/run-python-command', (req, res) => {
    const { command } = req.body;
    if (!command || typeof command !== 'string') {
      return res.status(400).json({ error: 'Command string is required' });
    }

    // Sanitize: run only through test script or intent parser
    const safeCommand = command.replace(/"/g, '\\"');
    const script = `
import sys
import os
sys.path.insert(0, 'OIBSIP/PythonProgramming/Task1_Voice_Assistant')
from assistant import VoiceMateAssistant

assistant = VoiceMateAssistant('OIBSIP/PythonProgramming/Task1_Voice_Assistant/config.json')
parsed = assistant.intent_handler.parse("${safeCommand}")
print(f"INTENT: {parsed.get('intent')}")
print(f"DATA: {parsed}")
`;
    exec(`python3 -c "${script.replace(/\n/g, '; ')}"`, { timeout: 5000 }, (error, stdout, stderr) => {
      res.json({
        success: !error,
        stdout: stdout || '',
        stderr: stderr || '',
      });
    });
  });

  // API endpoint to read the exact files on disk
  app.get('/api/python-files', (req, res) => {
    const baseDir = path.resolve('OIBSIP/PythonProgramming/Task1_Voice_Assistant');
    const fileList = [
      'main.py',
      'assistant.py',
      'speech_handler.py',
      'intent_handler.py',
      'config.json',
      '.env.example',
      '.gitignore',
      'requirements.txt',
      'test_assistant.py',
      'README.md',
      'assets/architecture.txt',
      'assets/VIVA_QUESTIONS_AND_ANSWERS.md'
    ];

    const results: Record<string, string> = {};
    for (const relPath of fileList) {
      const fullPath = path.join(baseDir, relPath);
      if (fs.existsSync(fullPath)) {
        results[relPath] = fs.readFileSync(fullPath, 'utf-8');
      }
    }

    res.json(results);
  });

  // In development, mount Vite dev server middlewares
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // In production, serve dist static files
    app.use(express.static(path.resolve('dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve('dist/index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`VoiceMate Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
