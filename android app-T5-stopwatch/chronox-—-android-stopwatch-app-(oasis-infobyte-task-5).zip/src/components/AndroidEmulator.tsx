import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Flag, 
  Smartphone, 
  RotateCw, 
  Home, 
  Square, 
  ChevronLeft, 
  Wifi, 
  BatteryMedium, 
  Signal, 
  Sparkles, 
  CheckCircle2, 
  Layers,
  Activity,
  Maximize2
} from 'lucide-react';
import { playHapticSound } from '../utils/audio';

export interface LapRecord {
  id: number;
  lapNumber: number;
  totalTime: number;
  splitTime: number;
}

export type TimerState = 'INITIAL' | 'RUNNING' | 'PAUSED';

interface AndroidEmulatorProps {
  onStateChange?: (state: {
    timerState: TimerState;
    elapsedMs: number;
    lapCount: number;
    isBackgrounded: boolean;
  }) => void;
  overrideControls?: {
    action: 'start' | 'pause' | 'reset' | 'lap' | 'background' | 'foreground' | null;
    timestamp: number;
  };
}

export const AndroidEmulator: React.FC<AndroidEmulatorProps> = ({ 
  onStateChange, 
  overrideControls 
}) => {
  // Stopwatch timing state
  const [timerState, setTimerState] = useState<TimerState>('INITIAL');
  const [elapsedMs, setElapsedMs] = useState<number>(0);
  const [laps, setLaps] = useState<LapRecord[]>([]);

  // SystemClock / Handler references (1:1 with Java logic)
  const startTimeRef = useRef<number>(0);
  const timeBuffRef = useRef<number>(0);
  const isRunningRef = useRef<boolean>(false);
  const timerLoopRef = useRef<number | null>(null);
  const lastLapElapsedRef = useRef<number>(0);
  const lapCounterRef = useRef<number>(1);

  // Android OS Simulation states
  const [isBackgrounded, setIsBackgrounded] = useState<boolean>(false);
  const [isLandscape, setIsLandscape] = useState<boolean>(false);
  const [systemTime, setSystemTime] = useState<string>('12:25');
  const [lifecycleLog, setLifecycleLog] = useState<string>('onCreate() -> onResume()');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Real-time status bar time updater
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setSystemTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  // Sync state change up to parent for test runner & demo studio
  useEffect(() => {
    onStateChange?.({
      timerState,
      elapsedMs,
      lapCount: laps.length,
      isBackgrounded
    });
  }, [timerState, elapsedMs, laps.length, isBackgrounded, onStateChange]);

  // Handle external programmatic commands (from Demo Video runner or Automated test suite)
  useEffect(() => {
    if (!overrideControls || !overrideControls.action) return;

    switch (overrideControls.action) {
      case 'start':
        handleStart();
        break;
      case 'pause':
        handlePause();
        break;
      case 'reset':
        handleReset();
        break;
      case 'lap':
        handleLap();
        break;
      case 'background':
        handleHome();
        break;
      case 'foreground':
        handleSwitchBack();
        break;
    }
  }, [overrideControls]);

  // Main UI update loop simulating Android Handler.postDelayed(runnable, 25)
  const runTimerLoop = useCallback(() => {
    if (!isRunningRef.current) return;

    // Direct monotonic clock math: (SystemClock.elapsedRealtime() - startTime) + timeBuff
    const now = performance.now();
    const currentElapsed = Math.floor((now - startTimeRef.current) + timeBuffRef.current);
    setElapsedMs(currentElapsed);

    timerLoopRef.current = window.setTimeout(runTimerLoop, 25);
  }, []);

  // START
  const handleStart = useCallback(() => {
    if (isRunningRef.current) return;
    if (soundEnabled) playHapticSound('click');

    // SystemClock.elapsedRealtime()
    startTimeRef.current = performance.now();
    isRunningRef.current = true;
    setTimerState('RUNNING');
    setLifecycleLog('Handler.post(timerRunnable) scheduled');

    if (timerLoopRef.current) {
      clearTimeout(timerLoopRef.current);
    }
    timerLoopRef.current = window.setTimeout(runTimerLoop, 25);
  }, [runTimerLoop, soundEnabled]);

  // PAUSE
  const handlePause = useCallback(() => {
    if (!isRunningRef.current) return;
    if (soundEnabled) playHapticSound('pause');

    // Freeze total time into timeBuff
    const now = performance.now();
    timeBuffRef.current += (now - startTimeRef.current);
    isRunningRef.current = false;
    setTimerState('PAUSED');
    setLifecycleLog('Handler.removeCallbacks(runnable) -> timeBuff updated');

    if (timerLoopRef.current) {
      clearTimeout(timerLoopRef.current);
      timerLoopRef.current = null;
    }
    setElapsedMs(Math.floor(timeBuffRef.current));
  }, [soundEnabled]);

  // RESET
  const handleReset = useCallback(() => {
    if (soundEnabled) playHapticSound('reset');

    // Stop loops
    if (timerLoopRef.current) {
      clearTimeout(timerLoopRef.current);
      timerLoopRef.current = null;
    }
    isRunningRef.current = false;
    startTimeRef.current = 0;
    timeBuffRef.current = 0;
    lastLapElapsedRef.current = 0;
    lapCounterRef.current = 1;

    setElapsedMs(0);
    setLaps([]);
    setTimerState('INITIAL');
    setLifecycleLog('Stopwatch reset to 00:00:00.00 & laps cleared');
  }, [soundEnabled]);

  // LAP
  const handleLap = useCallback(() => {
    if (!isRunningRef.current) return;
    if (soundEnabled) playHapticSound('lap');

    const now = performance.now();
    const currentTotal = Math.floor((now - startTimeRef.current) + timeBuffRef.current);
    const split = laps.length === 0 ? currentTotal : (currentTotal - lastLapElapsedRef.current);
    lastLapElapsedRef.current = currentTotal;

    const newLap: LapRecord = {
      id: Date.now() + Math.random(),
      lapNumber: lapCounterRef.current++,
      totalTime: currentTotal,
      splitTime: split
    };

    setLaps(prev => [newLap, ...prev]);
    setLifecycleLog(`Lap ${newLap.lapNumber} recorded: +${formatLapTime(split)}`);
  }, [laps.length, soundEnabled]);

  // ANDROID LIFECYCLE: onPause (simulate pressing Home button or switching apps)
  const handleHome = useCallback(() => {
    setIsBackgrounded(true);
    setLifecycleLog('Activity.onPause() -> UI callbacks stopped, monotonic clock continues');
    
    // In Android: handler.removeCallbacks(runnable) is called in onPause()
    if (timerLoopRef.current) {
      clearTimeout(timerLoopRef.current);
      timerLoopRef.current = null;
    }
  }, []);

  // ANDROID LIFECYCLE: onResume (simulate opening ChronoX from app switcher / launcher)
  const handleSwitchBack = useCallback(() => {
    setIsBackgrounded(false);
    setLifecycleLog('Activity.onResume() -> reattached UI handler, 0ms drift verified!');

    // In Android: if isRunning, post runnable immediately to resume UI refresh
    if (isRunningRef.current) {
      // Immediate recalculation using monotonic clock:
      const now = performance.now();
      const currentElapsed = Math.floor((now - startTimeRef.current) + timeBuffRef.current);
      setElapsedMs(currentElapsed);
      timerLoopRef.current = window.setTimeout(runTimerLoop, 25);
    }
  }, [runTimerLoop]);

  // Cleanup on unmount (simulating onDestroy)
  useEffect(() => {
    return () => {
      if (timerLoopRef.current) {
        clearTimeout(timerLoopRef.current);
      }
    };
  }, []);

  // Time formatters
  const hours = Math.floor(elapsedMs / 3600000);
  const minutes = Math.floor((elapsedMs % 3600000) / 60000);
  const seconds = Math.floor((elapsedMs % 60000) / 1000);
  const centiseconds = Math.floor((elapsedMs % 1000) / 10);

  const formattedHours = hours.toString().padStart(2, '0');
  const formattedMinutes = minutes.toString().padStart(2, '0');
  const formattedSeconds = seconds.toString().padStart(2, '0');
  const formattedCentis = centiseconds.toString().padStart(2, '0');

  // Fastest & slowest lap analysis
  const minSplit = laps.length >= 2 ? Math.min(...laps.map(l => l.splitTime)) : -1;
  const maxSplit = laps.length >= 2 ? Math.max(...laps.map(l => l.splitTime)) : -1;

  return (
    <div className="flex flex-col items-center w-full">
      {/* Device Toolbar Controls */}
      <div className="w-full max-w-[420px] mb-4 flex items-center justify-between px-2 text-xs text-slate-500">
        <div className="flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-slate-600" />
          <span className="font-medium text-slate-700">Google Pixel 8 Pro · Android 14</span>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`cursor-pointer transition-colors ${soundEnabled ? 'text-cyan-600 font-medium' : 'text-slate-400'}`}
            title="Toggle haptic audio"
          >
            {soundEnabled ? 'Audio On' : 'Audio Off'}
          </button>
          <span aria-hidden="true">·</span>
          <button
            onClick={() => setIsLandscape(!isLandscape)}
            className="flex items-center gap-1 cursor-pointer text-slate-600 hover:text-slate-900 transition-colors"
            title="Rotate Device"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>{isLandscape ? 'Portrait' : 'Landscape'}</span>
          </button>
        </div>
      </div>

      {/* Realistic Android Phone Chassis */}
      <div 
        className={`relative transition-all duration-300 bg-slate-950 p-3 rounded-[48px] shadow-2xl border-[6px] border-slate-800 shadow-slate-950/40 select-none ${
          isLandscape 
            ? 'w-[720px] h-[390px]' 
            : 'w-[370px] sm:w-[390px] h-[780px]'
        }`}
      >
        {/* Hardware details: Side buttons */}
        <div className="absolute -right-[10px] top-28 w-[4px] h-12 bg-slate-700 rounded-r-sm" />
        <div className="absolute -right-[10px] top-44 w-[4px] h-20 bg-slate-700 rounded-r-sm" />

        {/* Inner Screen Bezel */}
        <div className="relative w-full h-full bg-[#0F172A] rounded-[38px] overflow-hidden flex flex-col border border-slate-800/80">
          
          {/* Status Bar */}
          <div className="w-full h-8 px-6 pt-2 flex items-center justify-between text-[11px] font-medium text-slate-300 z-30 shrink-0">
            <span className="tabular-nums tracking-tight">{systemTime}</span>

            {/* Front Camera Hole Punch */}
            <div className="w-3.5 h-3.5 bg-black rounded-full border border-slate-800/60 flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-slate-900 rounded-full" />
            </div>

            <div className="flex items-center gap-1.5 text-slate-300">
              <Signal className="w-3 h-3" />
              <Wifi className="w-3 h-3" />
              <span className="text-[10px] tabular-nums">98%</span>
              <BatteryMedium className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* SCREEN CONTENT: Either ChronoX Activity OR Background Home Screen */}
          {isBackgrounded ? (
            /* SIMULATED ANDROID HOME SCREEN */
            <div className="flex-1 flex flex-col justify-between p-6 bg-gradient-to-b from-slate-900 via-indigo-950/40 to-slate-950 animate-fadeIn">
              {/* Home Screen Clock Widget */}
              <div className="text-center pt-8">
                <div className="text-5xl font-light text-white tracking-tight">{systemTime}</div>
                <div className="text-xs text-slate-400 mt-1">Tuesday, Oct 27 · 72°F Sunny</div>
              </div>

              {/* Ongoing Notification Banner for ChronoX in Background */}
              <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-3.5 shadow-lg backdrop-blur-md">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded bg-cyan-500 flex items-center justify-center text-white text-[10px] font-bold">
                      CX
                    </div>
                    <span className="text-xs font-semibold text-white">ChronoX Stopwatch</span>
                  </div>
                  <span className="text-[10px] text-cyan-400 font-mono">
                    {timerState === 'RUNNING' ? 'Running' : 'Paused'}
                  </span>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <div className="font-mono text-lg font-bold text-slate-100 tabular-nums">
                    {formattedHours}:{formattedMinutes}:{formattedSeconds}
                    <span className="text-xs text-cyan-400">.{formattedCentis}</span>
                  </div>
                  <button
                    onClick={handleSwitchBack}
                    className="px-3 py-1 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                  >
                    Resume App
                  </button>
                </div>
                <p className="text-[10px] text-slate-400 mt-2">
                  Activity in background. Monotonic clock (<code className="text-cyan-300">SystemClock.elapsedRealtime</code>) is tracking accurately with zero drift.
                </p>
              </div>

              {/* App Icons Grid */}
              <div className="grid grid-cols-4 gap-4 pb-2">
                <button
                  onClick={handleSwitchBack}
                  className="flex flex-col items-center gap-1 group cursor-pointer"
                >
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-500 flex items-center justify-center shadow-md group-hover:scale-105 transition-transform border border-cyan-400/40 relative">
                    <Activity className="w-6 h-6 text-white" />
                    {timerState === 'RUNNING' && (
                      <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-slate-900" />
                    )}
                  </div>
                  <span className="text-[11px] text-slate-200 font-medium">ChronoX</span>
                </button>

                <div className="flex flex-col items-center gap-1 opacity-60">
                  <div className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center border border-slate-700">
                    <span className="text-xs text-slate-400 font-bold">Files</span>
                  </div>
                  <span className="text-[11px] text-slate-400">Files</span>
                </div>

                <div className="flex flex-col items-center gap-1 opacity-60">
                  <div className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center border border-slate-700">
                    <span className="text-xs text-slate-400 font-bold">Photos</span>
                  </div>
                  <span className="text-[11px] text-slate-400">Photos</span>
                </div>

                <div className="flex flex-col items-center gap-1 opacity-60">
                  <div className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center border border-slate-700">
                    <span className="text-xs text-slate-400 font-bold">Settings</span>
                  </div>
                  <span className="text-[11px] text-slate-400">Settings</span>
                </div>
              </div>
            </div>
          ) : (
            /* ACTIVE CHRONOX STOPWATCH SCREEN (Java + XML UI) */
            <div className="flex-1 flex flex-col justify-between px-5 pt-3 pb-2 overflow-hidden">
              
              {/* App Top Bar */}
              <div className="flex items-center justify-between pb-3 shrink-0 border-b border-slate-800/80">
                <div>
                  <h1 className="text-lg font-bold text-white tracking-wide">ChronoX</h1>
                  <p className="text-[11px] text-slate-400">By Neha Vinod Borkar</p>
                </div>
                <div className="text-right">
                  <span className="text-[11px] font-medium text-cyan-400">Task 5 · Android</span>
                  <p className="text-[10px] text-slate-500 font-mono">Handler / SystemClock</p>
                </div>
              </div>

              {/* Big Digital Timer Display Container */}
              <div className="my-3 py-6 px-4 bg-slate-800/70 border border-slate-700/60 rounded-3xl flex flex-col items-center justify-center relative overflow-hidden shadow-inner shrink-0">
                {/* Subtle pulse ring when running */}
                {timerState === 'RUNNING' && (
                  <div className="absolute inset-0 border-2 border-cyan-500/30 rounded-3xl animate-pulse pointer-events-none" />
                )}

                <span className="text-[10px] font-bold text-slate-400 tracking-widest uppercase mb-1">
                  High Precision Stopwatch
                </span>

                {/* Digital Clock Display */}
                <div className="flex items-baseline justify-center font-mono font-bold text-white tabular-nums tracking-tight">
                  <span className="text-4xl sm:text-[42px] leading-none drop-shadow-sm">
                    {formattedHours}:{formattedMinutes}:{formattedSeconds}
                  </span>
                  <span className="text-2xl text-cyan-400 ml-1 leading-none">
                    .{formattedCentis}
                  </span>
                </div>

                <div className="text-[10px] text-slate-400 font-mono mt-2 tracking-wider">
                  HOURS : MINUTES : SECONDS . CENTISECONDS
                </div>
              </div>

              {/* Action Buttons Matrix */}
              <div className="flex flex-col gap-2.5 shrink-0">
                {/* Row 1: Start & Pause */}
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={handleStart}
                    disabled={timerState === 'RUNNING'}
                    className={`h-13 rounded-2xl font-semibold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      timerState === 'RUNNING'
                        ? 'bg-emerald-600/30 text-white/40 cursor-not-allowed border border-emerald-500/20'
                        : 'bg-emerald-500 hover:bg-emerald-400 active:scale-[0.98] text-slate-950 font-bold shadow-lg shadow-emerald-500/20'
                    }`}
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Start</span>
                  </button>

                  <button
                    onClick={handlePause}
                    disabled={timerState !== 'RUNNING'}
                    className={`h-13 rounded-2xl font-semibold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      timerState !== 'RUNNING'
                        ? 'bg-amber-600/30 text-white/40 cursor-not-allowed border border-amber-500/20'
                        : 'bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-slate-950 font-bold shadow-lg shadow-amber-500/20'
                    }`}
                  >
                    <Pause className="w-4 h-4 fill-current" />
                    <span>Pause</span>
                  </button>
                </div>

                {/* Row 2: Lap & Reset */}
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={handleLap}
                    disabled={timerState !== 'RUNNING'}
                    className={`h-11 rounded-xl font-medium text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      timerState !== 'RUNNING'
                        ? 'bg-slate-800/40 text-slate-500 cursor-not-allowed border border-slate-800'
                        : 'bg-slate-800 hover:bg-slate-700 active:scale-[0.98] text-slate-100 border border-slate-700 shadow-sm'
                    }`}
                  >
                    <Flag className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Lap</span>
                  </button>

                  <button
                    onClick={handleReset}
                    className="h-11 rounded-xl font-medium text-xs flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-700 active:scale-[0.98] text-slate-100 border border-slate-700 shadow-sm transition-all cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-rose-400" />
                    <span>Reset</span>
                  </button>
                </div>
              </div>

              {/* Scrollable Lap Records Section */}
              <div className="flex-1 min-h-0 flex flex-col mt-4">
                <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 px-1 pb-1.5 border-b border-slate-800 shrink-0">
                  <span>LAP RECORDS ({laps.length})</span>
                  <span className="font-mono text-[10px]">SPLIT / OVERALL</span>
                </div>

                <div className="flex-1 overflow-y-auto mt-2 pr-1 space-y-1.5 custom-scrollbar">
                  {laps.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center p-4">
                      <div className="w-10 h-10 rounded-full bg-slate-800/80 flex items-center justify-center mb-2">
                        <Flag className="w-4 h-4 text-slate-500" />
                      </div>
                      <p className="text-xs text-slate-400 font-medium">No laps recorded yet</p>
                      <p className="text-[10px] text-slate-500 mt-0.5">
                        Tap "Lap" while running to record interval splits
                      </p>
                    </div>
                  ) : (
                    laps.map(lap => {
                      const isFastest = minSplit > 0 && lap.splitTime === minSplit && minSplit !== maxSplit;
                      const isSlowest = maxSplit > 0 && lap.splitTime === maxSplit && minSplit !== maxSplit;

                      return (
                        <div
                          key={lap.id}
                          className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 rounded-xl px-3 py-2 flex items-center justify-between transition-colors"
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-white font-mono">
                              Lap {lap.lapNumber.toString().padStart(2, '0')}
                            </span>
                            {isFastest && (
                              <span className="text-[9px] font-semibold text-emerald-400 uppercase tracking-tight">
                                Best
                              </span>
                            )}
                            {isSlowest && (
                              <span className="text-[9px] font-semibold text-rose-400 uppercase tracking-tight">
                                Slowest
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-3 font-mono tabular-nums">
                            <span
                              className={`text-xs ${
                                isFastest 
                                  ? 'text-emerald-400 font-semibold' 
                                  : isSlowest 
                                    ? 'text-rose-400 font-semibold' 
                                    : 'text-slate-400'
                              }`}
                            >
                              +{formatLapTime(lap.splitTime)}
                            </span>
                            <span className="text-xs text-slate-200 font-semibold">
                              {formatLapTime(lap.totalTime)}
                            </span>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

            </div>
          )}

          {/* Android Navigation Bar (Back, Home, Recents) */}
          <div className="w-full h-11 bg-slate-950/90 border-t border-slate-900 flex items-center justify-around px-8 shrink-0 z-30">
            <button 
              onClick={() => {
                if (isBackgrounded) handleSwitchBack();
                else handleHome();
              }}
              title="Android Back Button"
              className="p-2 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <button 
              onClick={handleHome}
              title="Android Home Button (Simulates onPause)"
              className="p-2 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <div className="w-3.5 h-3.5 border-2 border-slate-400 rounded-full hover:border-white transition-colors" />
            </button>

            <button 
              onClick={handleHome}
              title="Android Recents / App Switcher Button"
              className="p-2 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <Square className="w-4 h-4 text-slate-400 hover:text-white transition-colors" />
            </button>
          </div>

        </div>
      </div>

      {/* Android Activity Lifecycle & Monotonic Clock Diagnostics Box */}
      <div className="w-full max-w-[420px] mt-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-3 text-xs">
        <div className="flex items-center justify-between text-slate-400 mb-2 font-medium">
          <span className="flex items-center gap-1.5 text-slate-300">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            <span>Android Lifecycle Telemetry</span>
          </span>
          <span className="font-mono text-[10px] text-cyan-400">
            State: {timerState}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-400 mb-2">
          <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800/80">
            <div className="text-[10px] text-slate-500">SystemClock (now)</div>
            <div className="text-white font-semibold truncate">{Math.floor(performance.now())} ms</div>
          </div>
          <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800/80">
            <div className="text-[10px] text-slate-500">timeBuff (accumulated)</div>
            <div className="text-white font-semibold">{Math.floor(timeBuffRef.current)} ms</div>
          </div>
        </div>

        <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
          <span className="text-slate-500">Log:</span>
          <span className="text-emerald-400 font-mono truncate">{lifecycleLog}</span>
        </div>
      </div>
    </div>
  );
};

function formatLapTime(millis: number): string {
  const minutes = Math.floor((millis % 3600000) / 60000);
  const seconds = Math.floor((millis % 60000) / 1000);
  const centis = Math.floor((millis % 1000) / 10);
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.${centis.toString().padStart(2, '0')}`;
}
