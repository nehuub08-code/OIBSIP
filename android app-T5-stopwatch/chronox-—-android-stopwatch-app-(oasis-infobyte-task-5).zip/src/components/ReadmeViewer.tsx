import React, { useState } from 'react';
import { ANDROID_PROJECT_FILES } from '../data/androidFiles';
import { Copy, Check, Download, FileText, CheckCircle2 } from 'lucide-react';

export const ReadmeViewer: React.FC = () => {
  const readmeFile = ANDROID_PROJECT_FILES.find(f => f.name === 'README.md') || ANDROID_PROJECT_FILES[ANDROID_PROJECT_FILES.length - 1];
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(readmeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([readmeFile.content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'README.md';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full flex flex-col gap-6">
      {/* Header Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white">
              Official Task 5 README.md
            </h2>
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              All 12 Sections Complete
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Ready for submission into the <code className="text-cyan-300 font-mono">OIBSIP/Task5_Stopwatch/README.md</code> GitHub repository.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400 font-semibold">Copied Markdown</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-slate-400" />
                <span>Copy Full README</span>
              </>
            )}
          </button>

          <button
            onClick={handleDownload}
            className="px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-md shadow-cyan-500/20 active:scale-95"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download README.md</span>
          </button>
        </div>
      </div>

      {/* Rendered Document View */}
      <div className="bg-[#0B1120] border border-slate-800 rounded-2xl p-6 sm:p-8 font-sans text-slate-200 text-sm leading-relaxed overflow-x-auto shadow-sm">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="border-b border-slate-800 pb-4">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              ChronoX — Android Stopwatch Application
            </h1>
            <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-slate-400">
              <span className="font-semibold text-cyan-400">Oasis Infobyte Internship (OIBSIP) — Task 5</span>
              <span>·</span>
              <span>Track: Android App Development</span>
              <span>·</span>
              <span>Developer: Neha Vinod Borkar</span>
            </div>
          </div>

          <div className="space-y-4 text-xs sm:text-sm text-slate-300">
            <h2 className="text-lg font-bold text-white border-b border-slate-800/80 pb-1.5">
              1. Project Overview & Architecture
            </h2>
            <p>
              <strong>ChronoX</strong> is a high-precision, production-grade Android Stopwatch application engineered using <strong>Android Studio, Java, and XML</strong>. Designed for the Oasis Infobyte Task 5 evaluation, it satisfies all official criteria including monotonic timing with <code className="text-cyan-300 font-mono">SystemClock.elapsedRealtime()</code>, smooth UI updates scheduled via Android <code className="text-cyan-300 font-mono">Handler</code> and <code className="text-cyan-300 font-mono">Runnable</code>, robust button state control, activity lifecycle continuity (<code className="text-cyan-300 font-mono">onPause</code> and <code className="text-cyan-300 font-mono">onResume</code>), and bonus lap recording with split analysis.
            </p>

            <h2 className="text-lg font-bold text-white border-b border-slate-800/80 pb-1.5 mt-6">
              2. Core Button State Transitions
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <div className="text-slate-400 font-bold mb-1">INITIAL STATE</div>
                <div>Start: <span className="text-emerald-400">Enabled</span></div>
                <div>Pause: <span className="text-slate-500">Disabled</span></div>
                <div>Lap: <span className="text-slate-500">Disabled</span></div>
                <div>Reset: <span className="text-emerald-400">Enabled</span></div>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <div className="text-slate-400 font-bold mb-1">RUNNING STATE</div>
                <div>Start: <span className="text-slate-500">Disabled</span></div>
                <div>Pause: <span className="text-amber-400">Enabled</span></div>
                <div>Lap: <span className="text-cyan-400">Enabled</span></div>
                <div>Reset: <span className="text-emerald-400">Enabled</span></div>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <div className="text-slate-400 font-bold mb-1">PAUSED STATE</div>
                <div>Start: <span className="text-emerald-400">Enabled</span></div>
                <div>Pause: <span className="text-slate-500">Disabled</span></div>
                <div>Lap: <span className="text-slate-500">Disabled</span></div>
                <div>Reset: <span className="text-emerald-400">Enabled</span></div>
              </div>
            </div>

            <h2 className="text-lg font-bold text-white border-b border-slate-800/80 pb-1.5 mt-6">
              3. Monotonic System Clock vs. Naive Increments
            </h2>
            <p>
              In Android, standard timer loops that increment by fixed amounts (<code className="text-cyan-300 font-mono">millisecondTime += 10</code>) suffer severe timing drift whenever garbage collection or layout passes delay the main Looper. ChronoX calculates elapsed time directly from hardware ticks:
            </p>
            <pre className="p-3 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs text-cyan-300 overflow-x-auto">
              millisecondTime = (SystemClock.elapsedRealtime() - startTime) + timeBuff;
            </pre>
            <p>
              This ensures 100% mathematical accuracy regardless of message posting delays.
            </p>

            <h2 className="text-lg font-bold text-white border-b border-slate-800/80 pb-1.5 mt-6">
              4. GitHub Submission Directory Structure
            </h2>
            <pre className="p-3 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs text-slate-300 overflow-x-auto">
{`OIBSIP/
└── Task5_Stopwatch/
    ├── app/
    │   ├── src/main/java/com/nehaborkar/chronox/
    │   │   ├── MainActivity.java
    │   │   ├── LapItem.java
    │   │   └── LapAdapter.java
    │   ├── src/main/res/
    │   │   ├── layout/activity_main.xml
    │   │   ├── layout/item_lap.xml
    │   │   ├── values/colors.xml
    │   │   ├── values/strings.xml
    │   │   └── values/themes.xml
    │   └── AndroidManifest.xml
    ├── build.gradle
    ├── settings.gradle
    └── README.md`}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
