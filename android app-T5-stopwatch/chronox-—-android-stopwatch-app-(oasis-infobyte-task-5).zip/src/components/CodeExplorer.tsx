import React, { useState } from 'react';
import { ANDROID_PROJECT_FILES, AndroidFile } from '../data/androidFiles';
import { 
  FileCode2, 
  Copy, 
  Check, 
  Download, 
  FolderTree, 
  Folder, 
  FileText, 
  Info,
  ChevronRight,
  Sparkles,
  FileBox
} from 'lucide-react';

export const CodeExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidFile>(ANDROID_PROJECT_FILES[0]);
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([selectedFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = selectedFile.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full flex flex-col lg:flex-row gap-6 items-start">
      {/* File Tree Navigation (Android Studio Project Structure) */}
      <div className="w-full lg:w-80 shrink-0 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-sm">
        <div className="flex items-center gap-2 pb-3 mb-3 border-b border-slate-800 text-xs font-semibold text-slate-300">
          <FolderTree className="w-4 h-4 text-cyan-400" />
          <span>Android Studio Project Explorer</span>
        </div>

        <div className="space-y-1 text-xs">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider px-2 py-1">
            OIBSIP · Task 5 Stopwatch
          </div>

          {ANDROID_PROJECT_FILES.map((file) => {
            const isSelected = selectedFile.name === file.name;
            return (
              <button
                key={file.path}
                onClick={() => setSelectedFile(file)}
                className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-xl text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-500/15 text-cyan-300 font-medium border border-cyan-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                {file.language === 'java' && (
                  <FileCode2 className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-cyan-400' : 'text-amber-400'}`} />
                )}
                {file.language === 'xml' && (
                  <FileCode2 className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-cyan-400' : 'text-emerald-400'}`} />
                )}
                {file.language === 'gradle' && (
                  <FileBox className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-cyan-400' : 'text-blue-400'}`} />
                )}
                {file.language === 'markdown' && (
                  <FileText className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-cyan-400' : 'text-purple-400'}`} />
                )}
                <span className="truncate">{file.name}</span>
              </button>
            );
          })}
        </div>

        {/* Quick Tips Box */}
        <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] text-slate-400 space-y-2">
          <div className="flex items-start gap-1.5 text-slate-300 font-medium">
            <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
            <span>Second-Year Ready Architecture</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            Written cleanly with zero excessive libraries. Uses standard Android <code className="text-cyan-300">Handler</code>, <code className="text-cyan-300">Runnable</code>, and <code className="text-cyan-300">SystemClock</code>.
          </p>
        </div>
      </div>

      {/* Code Viewer Panel */}
      <div className="flex-1 w-full bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-sm flex flex-col">
        {/* Header Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-4 bg-slate-950/70 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-white font-mono">
                {selectedFile.name}
              </span>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                {selectedFile.language}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Path: <span className="font-mono text-cyan-400/90">{selectedFile.path}</span>
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>Copy Code</span>
                </>
              )}
            </button>

            <button
              onClick={handleDownloadFile}
              className="px-3 py-1.5 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer border border-cyan-500/30"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File</span>
            </button>
          </div>
        </div>

        {/* File Rationale Callout */}
        <div className="px-5 py-3 bg-slate-900/50 border-b border-slate-800 text-xs text-slate-300 flex items-start gap-2">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
          <span>{selectedFile.description}</span>
        </div>

        {/* Code Content Container with Line Numbers */}
        <div className="p-4 overflow-x-auto max-h-[620px] custom-scrollbar bg-[#0B1120]">
          <pre className="font-mono text-xs text-slate-200 leading-relaxed">
            <code>
              {selectedFile.content.split('\n').map((line, idx) => (
                <div key={idx} className="table-row">
                  <span className="table-cell text-right pr-4 text-slate-600 select-none text-[11px] w-10">
                    {idx + 1}
                  </span>
                  <span className="table-cell whitespace-pre">
                    {formatSyntax(line, selectedFile.language)}
                  </span>
                </div>
              ))}
            </code>
          </pre>
        </div>
      </div>
    </div>
  );
};

// Lightweight syntax highlight formatter
function formatSyntax(line: string, language: string): React.ReactNode {
  if (language === 'java') {
    if (line.trim().startsWith('//') || line.trim().startsWith('/*') || line.trim().startsWith('*')) {
      return <span className="text-slate-500 italic">{line}</span>;
    }
    if (line.includes('@Override') || line.includes('@NonNull')) {
      return <span className="text-amber-400">{line}</span>;
    }
    if (line.includes('public class') || line.includes('private void') || line.includes('public static')) {
      return <span className="text-cyan-300 font-semibold">{line}</span>;
    }
  }

  if (language === 'xml') {
    if (line.trim().startsWith('<!--')) {
      return <span className="text-slate-500 italic">{line}</span>;
    }
    if (line.includes('<TextView') || line.includes('<MaterialButton') || line.includes('<ConstraintLayout')) {
      return <span className="text-cyan-300 font-semibold">{line}</span>;
    }
  }

  return line;
}
