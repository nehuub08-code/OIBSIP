import React, { useState, useEffect, useRef } from 'react';
import { 
  Video, 
  Play, 
  RotateCcw, 
  CheckCircle2, 
  Download, 
  Sparkles, 
  Info, 
  Clock, 
  User, 
  Layers,
  ChevronRight,
  FileVideo
} from 'lucide-react';

interface DemoVideoStudioProps {
  onTriggerAction?: (action: 'start' | 'pause' | 'reset' | 'lap' | 'background' | 'foreground') => void;
}

export const DemoVideoStudio: React.FC<DemoVideoStudioProps> = ({ onTriggerAction }) => {
  const [isPlayingDemo, setIsPlayingDemo] = useState<boolean>(false);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [showTitleCard, setShowTitleCard] = useState<boolean>(true);
  const [titleCardCountdown, setTitleCardCountdown] = useState<number>(3);
  const [recordingState, setRecordingState] = useState<'idle' | 'recording' | 'recorded'>('idle');
  const [videoBlobUrl, setVideoBlobUrl] = useState<string | null>(null);

  const demoSteps = [
    {
      title: "Step 0: Mandatory Introductory Title Card",
      duration: 3000,
      description: "Displays developer credentials for at least 2 seconds as required by Oasis Infobyte.",
      action: () => {
        setShowTitleCard(true);
        onTriggerAction?.('reset');
      }
    },
    {
      title: "Step 1: Initial Timer Display Verification",
      duration: 2500,
      description: "Demonstrating the initial state showing 00:00:00.00 and disabled Pause/Lap controls.",
      action: () => {
        setShowTitleCard(false);
        onTriggerAction?.('reset');
      }
    },
    {
      title: "Step 2: Starting the Stopwatch",
      duration: 3500,
      description: "Tapping Start. Handler schedules periodic UI updates; Start button is disabled.",
      action: () => {
        setShowTitleCard(false);
        onTriggerAction?.('start');
      }
    },
    {
      title: "Step 3: Pausing the Timer",
      duration: 2500,
      description: "Tapping Pause. Freezes displayed elapsed time and stops scheduled UI callbacks.",
      action: () => {
        setShowTitleCard(false);
        onTriggerAction?.('pause');
      }
    },
    {
      title: "Step 4: Resuming from Paused Time",
      duration: 3000,
      description: "Tapping Start again. Seamlessly resumes from accumulated timeBuff without resetting.",
      action: () => {
        setShowTitleCard(false);
        onTriggerAction?.('start');
      }
    },
    {
      title: "Step 5: Recording Lap 1 & Lap 2",
      duration: 4000,
      description: "Recording multiple split times to demonstrate dynamic lap insertion and split deltas.",
      action: async () => {
        setShowTitleCard(false);
        onTriggerAction?.('lap');
        await new Promise(r => setTimeout(r, 1500));
        onTriggerAction?.('lap');
      }
    },
    {
      title: "Step 6: Resetting the Timer",
      duration: 2500,
      description: "Tapping Reset. Returns display to 00:00:00.00, cancels callbacks, and clears laps.",
      action: () => {
        setShowTitleCard(false);
        onTriggerAction?.('reset');
      }
    },
    {
      title: "Step 7: Activity Lifecycle Demonstration (onPause / onResume)",
      duration: 4500,
      description: "Starts timer, switches to Android home screen (onPause), and resumes (onResume) with 0ms drift.",
      action: async () => {
        setShowTitleCard(false);
        onTriggerAction?.('start');
        await new Promise(r => setTimeout(r, 1200));
        onTriggerAction?.('background');
        await new Promise(r => setTimeout(r, 1800));
        onTriggerAction?.('foreground');
      }
    }
  ];

  // Automated presentation runner
  const startDemoRun = async () => {
    setIsPlayingDemo(true);
    setCurrentStepIndex(0);

    for (let i = 0; i < demoSteps.length; i++) {
      setCurrentStepIndex(i);
      await demoSteps[i].action();
      await new Promise(r => setTimeout(r, demoSteps[i].duration));
    }

    setIsPlayingDemo(false);
  };

  const handleStopDemo = () => {
    setIsPlayingDemo(false);
    setShowTitleCard(false);
    onTriggerAction?.('reset');
  };

  return (
    <div className="w-full flex flex-col gap-6">
      {/* Intro Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white">
              Official Task 5 Demo Video Studio & Presenter
            </h2>
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              Oasis Infobyte Compliant
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Automated walkthrough fulfilling all 7 mandatory demonstration criteria + 2-second title card.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isPlayingDemo ? (
            <button
              onClick={handleStopDemo}
              className="px-4 py-2.5 rounded-xl font-semibold text-xs bg-rose-600 hover:bg-rose-500 text-white transition-all cursor-pointer shadow-md"
            >
              Stop Walkthrough
            </button>
          ) : (
            <button
              onClick={startDemoRun}
              className="px-4 py-2.5 rounded-xl font-semibold text-xs bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md shadow-cyan-500/20 active:scale-95"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Run Automated Video Sequence</span>
            </button>
          )}
        </div>
      </div>

      {/* Mandatory First-Frame Title Card Preview */}
      <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 relative overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Mandatory First-Frame Title Card (Required for $\ge 2$ Seconds)</span>
          </span>
          <span className="text-xs text-slate-400">Section 12 Specification</span>
        </div>

        {/* The Exact Submission Title Card */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950 border border-cyan-500/40 rounded-2xl p-8 sm:p-10 shadow-2xl relative text-center">
          <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center mx-auto mb-4 text-cyan-400">
            <Video className="w-8 h-8" />
          </div>

          <div className="space-y-2 max-w-lg mx-auto">
            <div className="text-xs font-bold uppercase tracking-widest text-cyan-400">
              OASIS INFOBYTE INTERNSHIP (OIBSIP)
            </div>
            
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Full Name: <span className="text-cyan-300">Neha Vinod Borkar</span>
            </h1>

            <div className="text-base sm:text-lg font-semibold text-slate-200">
              Assigned Track: <span className="text-white">Android App Development</span>
            </div>

            <div className="text-sm sm:text-base font-medium text-slate-300">
              Task Title: <span className="text-emerald-400 font-semibold">Task 5 — Stopwatch (ChronoX)</span>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-400">
            <span>Java & XML Architecture</span>
            <span aria-hidden="true">·</span>
            <span>Handler & Monotonic SystemClock</span>
            <span aria-hidden="true">·</span>
            <span>Zero-Drift Lifecycle Handling</span>
          </div>
        </div>
      </div>

      {/* Sequence Roadmap & Live Progress */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {demoSteps.map((step, idx) => {
          const isActive = isPlayingDemo && currentStepIndex === idx;
          const isCompleted = isPlayingDemo && currentStepIndex > idx;

          return (
            <div
              key={idx}
              className={`p-4 rounded-xl border transition-all ${
                isActive
                  ? 'bg-cyan-950/40 border-cyan-500 shadow-md ring-1 ring-cyan-500/30'
                  : isCompleted
                    ? 'bg-slate-900/60 border-emerald-500/30'
                    : 'bg-slate-900/80 border-slate-800'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  {isCompleted ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : isActive ? (
                    <Clock className="w-4 h-4 text-cyan-400 shrink-0 animate-spin" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-600 flex items-center justify-center text-[10px] text-slate-400 font-mono shrink-0">
                      {idx}
                    </div>
                  )}
                  <h4 className={`text-xs font-bold ${isActive ? 'text-cyan-300' : 'text-slate-200'}`}>
                    {step.title}
                  </h4>
                </div>
                <span className="text-[10px] font-mono text-slate-500 shrink-0">
                  {(step.duration / 1000).toFixed(1)}s
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-2 pl-6">
                {step.description}
              </p>
            </div>
          );
        })}
      </div>

      {/* Video Presentation Script & Recording Guidance */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 text-xs text-slate-300 space-y-3">
        <div className="flex items-center gap-2 font-semibold text-white">
          <Info className="w-4 h-4 text-cyan-400" />
          <span>Recommended 60-Second Narration Script for Neha Vinod Borkar</span>
        </div>
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 space-y-2 text-slate-300 font-sans leading-relaxed">
          <p>
            <strong>"Hello everyone, I am Neha Vinod Borkar.</strong> This is my project submission for Oasis Infobyte Task 5 — Android Stopwatch Application titled <strong>ChronoX</strong>."
          </p>
          <p>
            "The app is developed in Java using standard Android Studio and XML. As you can see, it launches cleanly with <code>00:00:00.00</code>. When I tap <strong>Start</strong>, the Handler triggers a monotonic timing loop calculating elapsed time using <code>SystemClock.elapsedRealtime()</code>. Notice that the Start button is immediately disabled to prevent multiple loops."
          </p>
          <p>
            "When I tap <strong>Pause</strong>, the timer freezes the exact millisecond and stops callbacks to preserve battery. When I tap <strong>Start</strong> again, it seamlessly resumes from the accumulated <code>timeBuff</code>."
          </p>
          <p>
            "Next, the <strong>Lap</strong> button records split intervals and overall time, automatically highlighting the fastest lap in green. Finally, when the app is backgrounded via the Home button, <code>onPause()</code> stops the UI thread, and when reopened, <code>onResume()</code> recalculates elapsed time with zero drift. Thank you!"
          </p>
        </div>
      </div>
    </div>
  );
};
