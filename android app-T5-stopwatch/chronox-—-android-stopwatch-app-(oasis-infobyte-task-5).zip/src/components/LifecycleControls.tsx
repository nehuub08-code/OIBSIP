import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Flag, 
  Smartphone, 
  Zap, 
  Flame, 
  ShieldCheck, 
  Home, 
  CheckCircle2, 
  Layers,
  ArrowRight
} from 'lucide-react';
import { TimerState } from './AndroidEmulator';

interface LifecycleControlsProps {
  timerState: TimerState;
  elapsedMs: number;
  lapCount: number;
  isBackgrounded: boolean;
  onAction: (action: 'start' | 'pause' | 'reset' | 'lap' | 'background' | 'foreground') => void;
}

export const LifecycleControls: React.FC<LifecycleControlsProps> = ({
  timerState,
  elapsedMs,
  lapCount,
  isBackgrounded,
  onAction
}) => {
  const [stressTesting, setStressTesting] = useState<boolean>(false);
  const [stressResult, setStressResult] = useState<string | null>(null);

  // Rapid button tap test (Item #12 on the testing checklist)
  const handleRapidTapStressTest = async () => {
    setStressTesting(true);
    setStressResult(null);

    // Spam Start, Pause, Lap rapidly to prove no duplicate loops or crashed callbacks
    for (let i = 0; i < 6; i++) {
      onAction('start');
      await new Promise(r => setTimeout(r, 60));
      onAction('lap');
      await new Promise(r => setTimeout(r, 60));
      onAction('pause');
      await new Promise(r => setTimeout(r, 60));
      onAction('start');
      await new Promise(r => setTimeout(r, 60));
    }

    setStressTesting(false);
    setStressResult('Stress Test Passed: Zero duplicate Handler loops detected!');
  };

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <h3 className="text-sm font-bold text-white">
            Android Activity Lifecycle & Stress Lab
          </h3>
        </div>
        <span className="text-xs font-mono text-cyan-400">
          State: <strong className="text-white">{timerState}</strong>
        </span>
      </div>

      <p className="text-xs text-slate-300 leading-relaxed">
        Test how ChronoX handles hardware events, app switching (<code className="text-cyan-300">onPause</code> / <code className="text-cyan-300">onResume</code>), and rapid button tapping without timing drift or memory leaks.
      </p>

      {/* Action Buttons for Lifecycle Simulation */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Simulate Background / onPause */}
        <button
          onClick={() => onAction(isBackgrounded ? 'foreground' : 'background')}
          className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
            isBackgrounded
              ? 'bg-cyan-500/15 border-cyan-500 text-cyan-200'
              : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700 text-slate-200'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold flex items-center gap-1.5">
              <Home className="w-3.5 h-3.5 text-cyan-400" />
              <span>{isBackgrounded ? 'Resume App (onResume)' : 'Press Home (onPause)'}</span>
            </span>
            <span className="text-[10px] font-mono text-slate-400">
              {isBackgrounded ? 'Active: Home' : 'Active: App'}
            </span>
          </div>
          <p className="text-[11px] text-slate-400">
            {isBackgrounded
              ? 'Click to return to ChronoX and verify zero drift in elapsed time.'
              : 'Simulates minimizing the app to test background monotonic tracking.'}
          </p>
        </button>

        {/* Rapid Button Tap Stress Test */}
        <button
          onClick={handleRapidTapStressTest}
          disabled={stressTesting}
          className="p-3 rounded-xl border bg-slate-800/80 hover:bg-slate-800 border-slate-700 text-slate-200 text-left transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold flex items-center gap-1.5 text-amber-300">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>Rapid Tap Stress Test</span>
            </span>
            <span className="text-[10px] font-mono text-slate-400">
              {stressTesting ? 'Testing...' : 'Checklist #12'}
            </span>
          </div>
          <p className="text-[11px] text-slate-400">
            Spams Start/Pause/Lap to verify single-loop guard and debounce stability.
          </p>
        </button>
      </div>

      {stressResult && (
        <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{stressResult}</span>
        </div>
      )}

      {/* Button State Rule Guide */}
      <div className="pt-2 border-t border-slate-800">
        <div className="text-[11px] font-semibold text-slate-400 mb-2">
          Strict Button State Matrix (Oasis Infobyte Requirement)
        </div>
        <div className="grid grid-cols-3 gap-2 text-[10px] font-mono">
          <div className={`p-2 rounded-lg border ${timerState === 'INITIAL' ? 'bg-cyan-950/40 border-cyan-500 text-cyan-200' : 'bg-slate-950 border-slate-800 text-slate-400'}`}>
            <div className="font-bold text-slate-300 mb-1">INITIAL</div>
            <div>Start: ON</div>
            <div>Pause: OFF</div>
            <div>Lap: OFF</div>
            <div>Reset: ON</div>
          </div>
          <div className={`p-2 rounded-lg border ${timerState === 'RUNNING' ? 'bg-cyan-950/40 border-cyan-500 text-cyan-200' : 'bg-slate-950 border-slate-800 text-slate-400'}`}>
            <div className="font-bold text-slate-300 mb-1">RUNNING</div>
            <div>Start: OFF</div>
            <div>Pause: ON</div>
            <div>Lap: ON</div>
            <div>Reset: ON</div>
          </div>
          <div className={`p-2 rounded-lg border ${timerState === 'PAUSED' ? 'bg-cyan-950/40 border-cyan-500 text-cyan-200' : 'bg-slate-950 border-slate-800 text-slate-400'}`}>
            <div className="font-bold text-slate-300 mb-1">PAUSED</div>
            <div>Start: ON</div>
            <div>Pause: OFF</div>
            <div>Lap: OFF</div>
            <div>Reset: ON</div>
          </div>
        </div>
      </div>
    </div>
  );
};
