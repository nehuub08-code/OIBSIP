import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES } from '../data/androidFiles';

/**
 * Generates and triggers the download of the complete Android Studio project as a .zip file.
 * Folder structure matches the required Oasis Infobyte GitHub submission:
 * OIBSIP/Task5_Stopwatch/...
 */
export async function downloadAndroidProjectZip(): Promise<void> {
  const zip = new JSZip();
  const rootFolder = zip.folder('OIBSIP/Task5_Stopwatch');

  if (!rootFolder) {
    throw new Error('Could not create root zip folder');
  }

  // Add all files
  for (const file of ANDROID_PROJECT_FILES) {
    rootFolder.file(file.path, file.content);
  }

  // Generate binary zip
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'OIBSIP-Task5-Stopwatch-Neha-Vinod-Borkar.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
