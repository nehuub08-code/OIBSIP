/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Download, 
  Smartphone, 
  FileCode2, 
  CheckCircle2, 
  Video, 
  FileText, 
  Sparkles,
  Zap,
  Info,
  Clock,
  ExternalLink,
  Github
} from 'lucide-react';
import { AndroidEmulator, TimerState } from './components/AndroidEmulator';
import { LifecycleControls } from './components/LifecycleControls';
import { CodeExplorer } from './components/CodeExplorer';
import { TestingChecklist } from './components/TestingChecklist';
import { DemoVideoStudio } from './components/DemoVideoStudio';
import { ReadmeViewer } from './components/ReadmeViewer';
import { downloadAndroidProjectZip } from './utils/zipExport';

type TabType = 'emulator' | 'code' | 'checklist' | 'demo' | 'readme';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('emulator');
  const [isZipping, setIsZipping] = useState<boolean>(false);

  // Synced emulator state
  const [emulatorState, setEmulatorState] = useState<{
    timerState: TimerState;
    elapsedMs: number;
    lapCount: number;
    isBackgrounded: boolean;
  }>({
    timerState: 'INITIAL',
    elapsedMs: 0,
    lapCount: 0,
    isBackgrounded: false
  });

  // Programmatic action dispatch to emulator (from checklist or demo video)
  const [overrideControls, setOverrideControls] = useState<{
    action: 'start' | 'pause' | 'reset' | 'lap' | 'background' | 'foreground' | null;
    timestamp: number;
  }>({
    action: null,
    timestamp: 0
  });

  const handleTriggerAction = (action: 'start' | 'pause' | 'reset' | 'lap' | 'background' | 'foreground') => {
    setOverrideControls({
      action,
      timestamp: Date.now()
    });
  };

  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      await downloadAndroidProjectZip();
    } catch (err) {
      console.error('Failed to generate project zip:', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#090D16] text-slate-100 font-sans flex flex-col selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* 
        TOP BAR CONTRACT:
        Zone 1: Single text element wordmark
        Zone 2: 4-5 concise single-line nav links
        Zone 3: 1 primary action button
      */}
      <header className="sticky top-0 z-50 bg-[#090D16]/90 backdrop-blur-md border-b border-slate-800/80 px-6 py-3.5 flex items-center justify-between gap-8">
        
        {/* Zone 1: Brand Wordmark */}
        <a 
          href="#emulator" 
          onClick={(e) => { e.preventDefault(); setActiveTab('emulator'); }}
          className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 flex items-center gap-2 hover:text-cyan-400 transition-colors"
        >
          <div className="w-7 h-7 rounded-lg bg-cyan-500 flex items-center justify-center text-slate-950 font-black text-xs shadow-md shadow-cyan-500/30">
            CX
          </div>
          <span>ChronoX</span>
        </a>

        {/* Zone 2: Single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
          <button
            onClick={() => setActiveTab('emulator')}
            className={`whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer ${
              activeTab === 'emulator' ? 'text-white font-semibold' : ''
            }`}
          >
            Live Emulator
          </button>
          <button
            onClick={() => setActiveTab('code')}
            className={`whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer ${
              activeTab === 'code' ? 'text-white font-semibold' : ''
            }`}
          >
            Project Files & Code
          </button>
          <button
            onClick={() => setActiveTab('checklist')}
            className={`whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer ${
              activeTab === 'checklist' ? 'text-white font-semibold' : ''
            }`}
          >
            Testing Checklist
          </button>
          <button
            onClick={() => setActiveTab('demo')}
            className={`whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer ${
              activeTab === 'demo' ? 'text-white font-semibold' : ''
            }`}
          >
            Demo Video Studio
          </button>
          <button
            onClick={() => setActiveTab('readme')}
            className={`whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer ${
              activeTab === 'readme' ? 'text-white font-semibold' : ''
            }`}
          >
            Task 5 README
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 active:scale-95 transition-all rounded-xl shadow-md shadow-cyan-400/20 whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-2"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isZipping ? 'Bundling ZIP...' : 'Download Project (.ZIP)'}</span>
          </button>
        </div>
      </header>

      {/* Hero Header Banner with Unboxed Metadata */}
      <section className="border-b border-slate-800/80 bg-gradient-to-b from-slate-900/60 to-transparent px-6 py-6 sm:py-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            {/* Unboxed metadata line with typographic bullet separators */}
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 font-medium mb-1.5">
              <span className="text-cyan-400 font-semibold">Oasis Infobyte Internship</span>
              <span aria-hidden="true">·</span>
              <span>Task 5: Stopwatch Application</span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-300">Developer: Neha Vinod Borkar</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono text-slate-400">Android Studio · Java · XML</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              ChronoX — Android Stopwatch Engineering Suite
            </h1>
          </div>

          {/* Quick Segmented View Tabs for mobile & tablet */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl overflow-x-auto shrink-0 custom-scrollbar">
            <button
              onClick={() => setActiveTab('emulator')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'emulator'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Emulator</span>
            </button>
            <button
              onClick={() => setActiveTab('code')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'code'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileCode2 className="w-3.5 h-3.5" />
              <span>Project Code</span>
            </button>
            <button
              onClick={() => setActiveTab('checklist')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'checklist'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Checklist</span>
            </button>
            <button
              onClick={() => setActiveTab('demo')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'demo'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              <span>Demo Video</span>
            </button>
            <button
              onClick={() => setActiveTab('readme')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'readme'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>README</span>
            </button>
          </div>
        </div>
      </section>

      {/* Main Workspace Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        
        {/* TAB 1: LIVE ANDROID EMULATOR & WORKBENCH */}
        {activeTab === 'emulator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left: Pixel 8 Pro Interactive Chassis */}
            <div className="lg:col-span-5 flex justify-center">
              <AndroidEmulator 
                onStateChange={setEmulatorState}
                overrideControls={overrideControls}
              />
            </div>

            {/* Right: Technical Explanation, Lifecycle Lab & Formula Breakdown */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Lifecycle & Stress Testing Controller */}
              <LifecycleControls 
                timerState={emulatorState.timerState}
                elapsedMs={emulatorState.elapsedMs}
                lapCount={emulatorState.lapCount}
                isBackgrounded={emulatorState.isBackgrounded}
                onAction={handleTriggerAction}
              />

              {/* The Core Monotonic Clock Calculation Deep Dive */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-cyan-400" />
                  <h3 className="text-sm font-bold text-white">
                    Technical Deep Dive: Handler, Runnable & Monotonic Timing
                  </h3>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  The primary technical requirement of Oasis Infobyte Task 5 is avoiding timer drift caused by delayed UI updates. In Android, the UI thread (Main Looper) can experience delays during layout passes or garbage collection.
                </p>

                {/* Calculation Cards */}
                <div className="space-y-3 font-mono text-xs">
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <div className="text-[11px] text-rose-400 font-bold mb-1">
                      ❌ Flawed Approach (Accumulator Drift)
                    </div>
                    <code className="text-slate-400 text-[11px] block">
                      millisecondTime += 10; // If Handler executes after 25ms, time lags!
                    </code>
                  </div>

                  <div className="p-3 bg-slate-950 rounded-xl border border-emerald-500/30">
                    <div className="text-[11px] text-emerald-400 font-bold mb-1">
                      ✅ ChronoX Implementation (Monotonic Realtime)
                    </div>
                    <code className="text-cyan-300 text-[11px] block">
                      millisecondTime = (SystemClock.elapsedRealtime() - startTime) + timeBuff;
                    </code>
                    <div className="text-[10px] text-slate-400 font-sans mt-2">
                      Elapsed time is computed dynamically against hardware boot ticks. Even if a frame takes 40ms to draw, the displayed millisecond value remains 100% mathematically exact!
                    </div>
                  </div>
                </div>

                {/* Activity Lifecycle Callout */}
                <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-1.5">
                  <div className="font-semibold text-slate-200">
                    Why onPause() & onResume() Preserve Time Without Wasting Battery:
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    When minimized (<code className="text-cyan-300">onPause</code>), <code className="text-cyan-300">handler.removeCallbacks(runnable)</code> pauses CPU redraws. When restored (<code className="text-cyan-300">onResume</code>), <code className="text-cyan-300">SystemClock.elapsedRealtime() - startTime</code> naturally accounts for wall time spent in background!
                  </p>
                </div>
              </div>

              {/* Submission Information Card */}
              <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-400">
                <div>
                  <span className="font-semibold text-slate-300">Repository Submission:</span>{' '}
                  <span className="font-mono text-cyan-300">OIBSIP/Task5_Stopwatch</span>
                </div>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => setActiveTab('code')}
                    className="text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer"
                  >
                    Inspect Java Source →
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 2: ANDROID STUDIO PROJECT FILES & CODE */}
        {activeTab === 'code' && (
          <CodeExplorer />
        )}

        {/* TAB 3: OASIS INFOBYTE TESTING CHECKLIST */}
        {activeTab === 'checklist' && (
          <TestingChecklist onTriggerAction={handleTriggerAction} />
        )}

        {/* TAB 4: DEMO VIDEO STUDIO & TITLE CARD */}
        {activeTab === 'demo' && (
          <DemoVideoStudio onTriggerAction={handleTriggerAction} />
        )}

        {/* TAB 5: TASK 5 OFFICIAL README */}
        {activeTab === 'readme' && (
          <ReadmeViewer />
        )}

      </main>

      {/* Footer following Anti-Slop Discipline */}
      <footer className="border-t border-slate-800/80 bg-[#090D16] py-6 px-6 mt-12">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">ChronoX Stopwatch</span>
            <span aria-hidden="true">·</span>
            <span>Task 5 Android App Development</span>
            <span aria-hidden="true">·</span>
            <span>Oasis Infobyte Internship (OIBSIP)</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>Developer: <strong className="text-slate-300 font-medium">Neha Vinod Borkar</strong></span>
            <span aria-hidden="true">·</span>
            <button 
              onClick={handleDownloadZip}
              className="text-cyan-400 hover:text-cyan-300 cursor-pointer font-medium"
            >
              Download Project ZIP
            </button>
          </div>
        </div>
      </footer>

    </div>
  );
}
