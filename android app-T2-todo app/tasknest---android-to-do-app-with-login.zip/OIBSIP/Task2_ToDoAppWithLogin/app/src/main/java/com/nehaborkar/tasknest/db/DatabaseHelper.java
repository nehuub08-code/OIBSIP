package com.nehaborkar.tasknest.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.nehaborkar.tasknest.model.Task;
import com.nehaborkar.tasknest.model.User;
import com.nehaborkar.tasknest.security.PasswordUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * SQLite Database Helper for TaskNest.
 * 
 * Manages the 'users' and 'tasks' tables with:
 * - Foreign Key enforcement (tasks.user_id -> users.id)
 * - Strict user-specific task isolation (all updates/deletes scope by task_id AND user_id)
 * - Parameterized queries and ContentValues to prevent SQL injection
 * - Cryptographically salted PBKDF2 password verification
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tasknest.db";
    private static final int DATABASE_VERSION = 1;

    // Users table definition
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USER_NAME = "name";
    public static final String COL_USER_EMAIL = "email";
    public static final String COL_USER_PASSWORD_HASH = "password_hash";
    public static final String COL_USER_PASSWORD_SALT = "password_salt";
    public static final String COL_USER_CREATED_AT = "created_at";

    // Tasks table definition
    public static final String TABLE_TASKS = "tasks";
    public static final String COL_TASK_ID = "id";
    public static final String COL_TASK_USER_ID = "user_id";
    public static final String COL_TASK_TITLE = "title";
    public static final String COL_TASK_NOTES = "notes";
    public static final String COL_TASK_IS_COMPLETED = "is_completed";
    public static final String COL_TASK_CREATED_AT = "created_at";

    // SQL statement to create Users table
    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + " ("
            + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COL_USER_NAME + " TEXT NOT NULL, "
            + COL_USER_EMAIL + " TEXT UNIQUE NOT NULL, "
            + COL_USER_PASSWORD_HASH + " TEXT NOT NULL, "
            + COL_USER_PASSWORD_SALT + " TEXT NOT NULL, "
            + COL_USER_CREATED_AT + " TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
            + ");";

    // SQL statement to create Tasks table with Foreign Key
    private static final String CREATE_TABLE_TASKS = "CREATE TABLE " + TABLE_TASKS + " ("
            + COL_TASK_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COL_TASK_USER_ID + " INTEGER NOT NULL, "
            + COL_TASK_TITLE + " TEXT NOT NULL, "
            + COL_TASK_NOTES + " TEXT, "
            + COL_TASK_IS_COMPLETED + " INTEGER NOT NULL DEFAULT 0, "
            + COL_TASK_CREATED_AT + " TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
            + "FOREIGN KEY (" + COL_TASK_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_ID + ") ON DELETE CASCADE"
            + ");";

    // Index on user_id for rapid retrieval of user-specific tasks
    private static final String CREATE_INDEX_TASKS_USER_ID = "CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON "
            + TABLE_TASKS + "(" + COL_TASK_USER_ID + ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        // Explicitly enable foreign key constraints in SQLite
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_TASKS);
        db.execSQL(CREATE_INDEX_TASKS_USER_ID);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Upgrade policy for schema migrations
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TASKS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // =========================================================================
    // USER AUTHENTICATION & MANAGEMENT
    // =========================================================================

    /**
     * Checks whether an email is already registered (case-insensitive check).
     */
    public boolean isEmailRegistered(String email) {
        if (email == null) return false;
        SQLiteDatabase db = this.getReadableDatabase();
        String normalizedEmail = email.trim().toLowerCase();
        Cursor cursor = null;
        try {
            cursor = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID},
                    "LOWER(" + COL_USER_EMAIL + ") = ?",
                    new String[]{normalizedEmail},
                    null, null, null
            );
            return (cursor != null && cursor.getCount() > 0);
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    /**
     * Registers a new user with PBKDF2WithHmacSHA256 hashed password and random salt.
     * @return User ID if registration succeeds, -1 if email is duplicate or insertion failed.
     */
    public long registerUser(String name, String email, String plainPassword) {
        if (name == null || email == null || plainPassword == null) {
            return -1;
        }

        String normalizedEmail = email.trim().toLowerCase();
        if (isEmailRegistered(normalizedEmail)) {
            return -1; // Duplicate email prevention
        }

        // Generate cryptographic salt and derive PBKDF2 hash
        byte[] salt = PasswordUtils.generateSalt();
        String saltHex = PasswordUtils.bytesToHex(salt);
        String hashHex = PasswordUtils.hashPasswordToHex(plainPassword, salt);

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USER_NAME, name.trim());
        values.put(COL_USER_EMAIL, normalizedEmail);
        values.put(COL_USER_PASSWORD_HASH, hashHex);
        values.put(COL_USER_PASSWORD_SALT, saltHex);

        return db.insert(TABLE_USERS, null, values);
    }

    /**
     * Authenticates a user using email and password.
     * Uses constant-time PBKDF2 verification against stored salt & hash.
     * 
     * @return User model if credentials are valid, null otherwise.
     */
    public User authenticateUser(String email, String plainPassword) {
        if (email == null || plainPassword == null) {
            return null;
        }

        String normalizedEmail = email.trim().toLowerCase();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID, COL_USER_NAME, COL_USER_EMAIL, COL_USER_PASSWORD_HASH, COL_USER_PASSWORD_SALT},
                    "LOWER(" + COL_USER_EMAIL + ") = ?",
                    new String[]{normalizedEmail},
                    null, null, null
            );

            if (cursor != null && cursor.moveToFirst()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_USER_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_NAME));
                String storedEmail = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_EMAIL));
                String storedHashHex = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_PASSWORD_HASH));
                String storedSaltHex = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_PASSWORD_SALT));

                // Verify password securely using constant-time comparison
                boolean passwordMatches = PasswordUtils.verifyPassword(plainPassword, storedSaltHex, storedHashHex);
                if (passwordMatches) {
                    return new User(id, name, storedEmail, storedHashHex, storedSaltHex);
                }
            }
        } finally {
            if (cursor != null) cursor.close();
        }

        // Return null for any authentication failure (no credential leaking)
        return null;
    }

    /**
     * Retrieve user profile by user ID.
     */
    public User getUserById(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID, COL_USER_NAME, COL_USER_EMAIL, COL_USER_PASSWORD_HASH, COL_USER_PASSWORD_SALT},
                    COL_USER_ID + " = ?",
                    new String[]{String.valueOf(userId)},
                    null, null, null
            );
            if (cursor != null && cursor.moveToFirst()) {
                return new User(
                        cursor.getLong(cursor.getColumnIndexOrThrow(COL_USER_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_EMAIL)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_PASSWORD_HASH)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_PASSWORD_SALT))
                );
            }
        } finally {
            if (cursor != null) cursor.close();
        }
        return null;
    }

    // =========================================================================
    // USER-SPECIFIC TASK MANAGEMENT (CRITICAL DATA ISOLATION)
    // =========================================================================

    /**
     * Inserts a task strictly bound to the authenticated user's ID.
     */
    public long insertTask(long userId, String title, String notes) {
        if (title == null || title.trim().isEmpty() || userId <= 0) {
            return -1;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TASK_USER_ID, userId);
        values.put(COL_TASK_TITLE, title.trim());
        values.put(COL_TASK_NOTES, notes != null ? notes.trim() : "");
        values.put(COL_TASK_IS_COMPLETED, 0); // New tasks start as incomplete

        return db.insert(TABLE_TASKS, null, values);
    }

    /**
     * Retrieves all tasks strictly owned by the specified user.
     * Orders: Incomplete tasks first, then sorted by most recent.
     */
    public List<Task> getTasksForUser(long userId) {
        List<Task> tasks = new ArrayList<>();
        if (userId <= 0) return tasks;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.query(
                    TABLE_TASKS,
                    new String[]{COL_TASK_ID, COL_TASK_USER_ID, COL_TASK_TITLE, COL_TASK_NOTES, COL_TASK_IS_COMPLETED, COL_TASK_CREATED_AT},
                    COL_TASK_USER_ID + " = ?",
                    new String[]{String.valueOf(userId)},
                    null, null,
                    COL_TASK_IS_COMPLETED + " ASC, " + COL_TASK_ID + " DESC"
            );

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    long id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_TASK_ID));
                    long ownerId = cursor.getLong(cursor.getColumnIndexOrThrow(COL_TASK_USER_ID));
                    String title = cursor.getString(cursor.getColumnIndexOrThrow(COL_TASK_TITLE));
                    String notes = cursor.getString(cursor.getColumnIndexOrThrow(COL_TASK_NOTES));
                    boolean isCompleted = cursor.getInt(cursor.getColumnIndexOrThrow(COL_TASK_IS_COMPLETED)) == 1;
                    String createdAt = cursor.getString(cursor.getColumnIndexOrThrow(COL_TASK_CREATED_AT));

                    tasks.add(new Task(id, ownerId, title, notes, isCompleted, createdAt));
                } while (cursor.moveToNext());
            }
        } finally {
            if (cursor != null) cursor.close();
        }

        return tasks;
    }

    /**
     * Updates completion status of a task strictly scoped by both taskId AND userId.
     * Equivalent to: UPDATE tasks SET is_completed = ? WHERE id = ? AND user_id = ?
     * 
     * @return true if updated, false if task was not found or belongs to another user.
     */
    public boolean updateTaskCompletion(long taskId, long userId, boolean isCompleted) {
        if (taskId <= 0 || userId <= 0) return false;

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TASK_IS_COMPLETED, isCompleted ? 1 : 0);

        int rowsAffected = db.update(
                TABLE_TASKS,
                values,
                COL_TASK_ID + " = ? AND " + COL_TASK_USER_ID + " = ?",
                new String[]{String.valueOf(taskId), String.valueOf(userId)}
        );

        return rowsAffected > 0;
    }

    /**
     * Deletes a task permanently, strictly scoped by taskId AND userId.
     * Equivalent to: DELETE FROM tasks WHERE id = ? AND user_id = ?
     * 
     * @return true if deleted, false if task belongs to another user or not found.
     */
    public boolean deleteTask(long taskId, long userId) {
        if (taskId <= 0 || userId <= 0) return false;

        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(
                TABLE_TASKS,
                COL_TASK_ID + " = ? AND " + COL_TASK_USER_ID + " = ?",
                new String[]{String.valueOf(taskId), String.valueOf(userId)}
        );

        return rowsDeleted > 0;
    }
}
