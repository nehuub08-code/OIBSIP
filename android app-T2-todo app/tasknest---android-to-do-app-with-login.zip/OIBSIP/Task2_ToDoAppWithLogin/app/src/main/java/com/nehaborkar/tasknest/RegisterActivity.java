package com.nehaborkar.tasknest;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.nehaborkar.tasknest.db.DatabaseHelper;

/**
 * RegisterActivity for TaskNest.
 * 
 * Implements client-side validation, duplicate email prevention,
 * and PBKDF2 salt generation with 10,000 rounds before inserting into SQLite.
 */
public class RegisterActivity extends AppCompatActivity {

    private EditText etFullName;
    private EditText etEmail;
    private EditText etPassword;
    private EditText etConfirmPassword;
    private Button btnRegister;
    private TextView tvGoToLogin;
    private ImageView ivBack;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new DatabaseHelper(this);

        initViews();
        setupListeners();
    }

    private void initViews() {
        etFullName = findViewById(R.id.etFullName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnRegister = findViewById(R.id.btnRegister);
        tvGoToLogin = findViewById(R.id.tvGoToLogin);
        ivBack = findViewById(R.id.ivBack);
    }

    private void setupListeners() {
        btnRegister.setOnClickListener(v -> performRegistration());
        tvGoToLogin.setOnClickListener(v -> finish());
        ivBack.setOnClickListener(v -> finish());
    }

    private void performRegistration() {
        String name = etFullName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();
        String confirmPassword = etConfirmPassword.getText().toString();

        // 1. Validate full name
        if (TextUtils.isEmpty(name)) {
            etFullName.setError(getString(R.string.err_name_required));
            etFullName.requestFocus();
            return;
        }

        // 2. Validate email format
        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError(getString(R.string.err_invalid_email));
            etEmail.requestFocus();
            return;
        }

        // 3. Validate password length (min 8 characters)
        if (TextUtils.isEmpty(password) || password.length() < 8) {
            etPassword.setError(getString(R.string.err_password_short));
            etPassword.requestFocus();
            return;
        }

        // 4. Validate confirm password match
        if (!password.equals(confirmPassword)) {
            etConfirmPassword.setError(getString(R.string.err_password_mismatch));
            etConfirmPassword.requestFocus();
            return;
        }

        // 5. Prevent duplicate email registration
        if (dbHelper.isEmailRegistered(email)) {
            etEmail.setError(getString(R.string.err_email_exists));
            etEmail.requestFocus();
            Toast.makeText(this, R.string.err_email_exists, Toast.LENGTH_LONG).show();
            return;
        }

        // 6. Secure registration into SQLite (PBKDF2 salted hash derived internally)
        long newUserId = dbHelper.registerUser(name, email, password);

        if (newUserId != -1) {
            Toast.makeText(this, R.string.msg_register_success, Toast.LENGTH_LONG).show();
            finish(); // Return to LoginActivity
        } else {
            Toast.makeText(this, "Registration failed. Please check inputs and try again.", Toast.LENGTH_LONG).show();
        }
    }
}
