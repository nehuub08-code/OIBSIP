package com.nehaborkar.tasknest.model;

/**
 * Model representing a registered User in TaskNest.
 * Passwords are never stored in plain text.
 */
public class User {
    private long id;
    private String name;
    private String email;
    private String passwordHash;
    private String passwordSalt;

    public User() {
    }

    public User(long id, String name, String email, String passwordHash, String passwordSalt) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.passwordHash = passwordHash;
        this.passwordSalt = passwordSalt;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getPasswordSalt() {
        return passwordSalt;
    }

    public void setPasswordSalt(String passwordSalt) {
        this.passwordSalt = passwordSalt;
    }
}
