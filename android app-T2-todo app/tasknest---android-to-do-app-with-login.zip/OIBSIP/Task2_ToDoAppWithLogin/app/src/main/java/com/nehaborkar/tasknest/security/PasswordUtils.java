package com.nehaborkar.tasknest.security;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Enterprise-grade password hashing utility for TaskNest.
 * 
 * Cryptographic Specifications:
 * - Algorithm: PBKDF2WithHmacSHA256
 * - Salt: 16 bytes (128 bits) generated via java.security.SecureRandom
 * - Iterations: 10,000 rounds (balanced for Android responsiveness and resistance to brute-force)
 * - Derived Key Length: 256 bits (32 bytes)
 * - Comparison: Constant-time byte comparison using MessageDigest.isEqual to defend against timing attacks.
 * 
 * Passwords are NEVER stored or transmitted in plain text.
 * No MD5 or single-round SHA-256 is used.
 */
public final class PasswordUtils {

    public static final String ALGORITHM = "PBKDF2WithHmacSHA256";
    public static final int ITERATION_COUNT = 10000;
    public static final int KEY_LENGTH_BITS = 256;
    public static final int SALT_LENGTH_BYTES = 16;

    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private PasswordUtils() {
        // Utility class, do not instantiate
    }

    /**
     * Generates a cryptographically strong pseudo-random salt.
     * @return 16-byte random salt.
     */
    public static byte[] generateSalt() {
        byte[] salt = new byte[SALT_LENGTH_BYTES];
        SECURE_RANDOM.nextBytes(salt);
        return salt;
    }

    /**
     * Hashes a password using PBKDF2WithHmacSHA256.
     * 
     * @param password Char array of user password (preferred over String to allow memory wiping)
     * @param salt Cryptographic salt
     * @return 256-bit derived key bytes
     */
    public static byte[] hashPassword(char[] password, byte[] salt) {
        if (password == null || salt == null) {
            throw new IllegalArgumentException("Password and salt must not be null");
        }
        try {
            KeySpec spec = new PBEKeySpec(password, salt, ITERATION_COUNT, KEY_LENGTH_BITS);
            SecretKeyFactory factory = SecretKeyFactory.getInstance(ALGORITHM);
            return factory.generateSecret(spec).getEncoded();
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException("Error hashing password with " + ALGORITHM, e);
        }
    }

    /**
     * Convenience method for String password hashing.
     * Converts result to hex representation for clean database persistence.
     */
    public static String hashPasswordToHex(String password, byte[] salt) {
        if (password == null) {
            return null;
        }
        byte[] hash = hashPassword(password.toCharArray(), salt);
        return bytesToHex(hash);
    }

    /**
     * Constant-time password verification against stored salt and hash.
     * Defends against timing side-channel analysis.
     * 
     * @param submittedPassword The password string submitted during login attempt
     * @param storedSaltHex The hex-encoded salt stored in SQLite users table
     * @param storedHashHex The hex-encoded password hash stored in SQLite users table
     * @return true if password matches, false otherwise
     */
    public static boolean verifyPassword(String submittedPassword, String storedSaltHex, String storedHashHex) {
        if (submittedPassword == null || storedSaltHex == null || storedHashHex == null) {
            return false;
        }
        try {
            byte[] salt = hexToBytes(storedSaltHex);
            byte[] expectedHash = hexToBytes(storedHashHex);
            byte[] computedHash = hashPassword(submittedPassword.toCharArray(), salt);

            // Constant-time comparison
            return MessageDigest.isEqual(expectedHash, computedHash);
        } catch (Exception e) {
            // Malformed salt/hash data fails closed safely without crashing
            return false;
        }
    }

    /**
     * Converts a byte array into a lowercase hex string.
     */
    public static String bytesToHex(byte[] bytes) {
        if (bytes == null) return null;
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    /**
     * Converts a hex string back into a byte array.
     */
    public static byte[] hexToBytes(String hex) {
        if (hex == null || hex.length() % 2 != 0) {
            throw new IllegalArgumentException("Invalid hex string");
        }
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }
}
