package com.nehaborkar.tasknest;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.nehaborkar.tasknest.db.DatabaseHelper;
import com.nehaborkar.tasknest.model.User;
import com.nehaborkar.tasknest.session.SessionManager;

/**
 * LoginActivity for TaskNest.
 * 
 * Verifies credentials against local SQLite database using PBKDF2WithHmacSHA256.
 * Auto-restores session if already authenticated.
 * Developed by Neha Vinod Borkar for Oasis Infobyte Task 2.
 */
public class LoginActivity extends AppCompatActivity {

    private EditText etEmail;
    private EditText etPassword;
    private Button btnLogin;
    private TextView tvGoToRegister;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize SessionManager & Database
        sessionManager = new SessionManager(this);
        dbHelper = new DatabaseHelper(this);

        // Session Auto-Restoration: If user is already logged in, skip Login screen
        if (sessionManager.isLoggedIn()) {
            navigateToTaskList();
            return;
        }

        setContentView(R.layout.activity_login);

        initViews();
        setupListeners();
    }

    private void initViews() {
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvGoToRegister = findViewById(R.id.tvGoToRegister);
    }

    private void setupListeners() {
        btnLogin.setOnClickListener(v -> performLogin());

        tvGoToRegister.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    private void performLogin() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();

        // Validation: Empty checks
        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, R.string.err_empty_fields, Toast.LENGTH_SHORT).show();
            if (TextUtils.isEmpty(email)) {
                etEmail.setError(getString(R.string.err_empty_fields));
            } else {
                etPassword.setError(getString(R.string.err_empty_fields));
            }
            return;
        }

        // Authenticate via SQLite using PBKDF2 hash verification
        User authenticatedUser = dbHelper.authenticateUser(email, password);

        if (authenticatedUser != null) {
            // Save authenticated session (never saves password or password hash)
            sessionManager.createLoginSession(
                    authenticatedUser.getId(),
                    authenticatedUser.getName(),
                    authenticatedUser.getEmail()
            );

            Toast.makeText(this, "Welcome, " + authenticatedUser.getName() + "!", Toast.LENGTH_SHORT).show();
            navigateToTaskList();
        } else {
            // Friendly generic error: does not disclose whether the email exists
            Toast.makeText(this, R.string.err_invalid_credentials, Toast.LENGTH_LONG).show();
            etPassword.setError(getString(R.string.err_invalid_credentials));
        }
    }

    private void navigateToTaskList() {
        Intent intent = new Intent(LoginActivity.this, TaskListActivity.class);
        startActivity(intent);
        finish(); // Prevent user from returning to Login via Back button
    }
}
