package com.nehaborkar.tasknest;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.nehaborkar.tasknest.adapter.TaskAdapter;
import com.nehaborkar.tasknest.db.DatabaseHelper;
import com.nehaborkar.tasknest.model.Task;
import com.nehaborkar.tasknest.session.SessionManager;

import java.util.List;

/**
 * TaskListActivity for TaskNest.
 * 
 * Main workspace after authentication.
 * Enforces strict user isolation: all query, insert, update, and delete calls
 * require both task ID and current user ID.
 */
public class TaskListActivity extends AppCompatActivity implements TaskAdapter.OnTaskActionListener {

    private TextView tvGreeting;
    private TextView tvUserEmail;
    private TextView tvProgressRatio;
    private ProgressBar pbTaskProgress;
    private RecyclerView rvTasks;
    private LinearLayout llEmptyState;
    private Button btnEmptyAddTask;
    private FloatingActionButton fabAddTask;
    private ImageButton btnLogout;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private TaskAdapter taskAdapter;

    private long currentUserId;
    private String currentUserName;
    private String currentUserEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sessionManager = new SessionManager(this);
        dbHelper = new DatabaseHelper(this);

        // Security check: verify active session
        if (!sessionManager.isLoggedIn()) {
            sessionManager.logoutUser();
            finish();
            return;
        }

        currentUserId = sessionManager.getUserId();
        currentUserName = sessionManager.getUserName();
        currentUserEmail = sessionManager.getUserEmail();

        setContentView(R.layout.activity_task_list);

        initViews();
        setupRecyclerView();
        setupListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUserTasks();
    }

    private void initViews() {
        tvGreeting = findViewById(R.id.tvGreeting);
        tvUserEmail = findViewById(R.id.tvUserEmail);
        tvProgressRatio = findViewById(R.id.tvProgressRatio);
        pbTaskProgress = findViewById(R.id.pbTaskProgress);
        rvTasks = findViewById(R.id.rvTasks);
        llEmptyState = findViewById(R.id.llEmptyState);
        btnEmptyAddTask = findViewById(R.id.btnEmptyAddTask);
        fabAddTask = findViewById(R.id.fabAddTask);
        btnLogout = findViewById(R.id.btnLogout);

        // Set user greeting
        tvGreeting.setText(getString(R.string.greeting_prefix) + currentUserName + " 👋");
        tvUserEmail.setText(currentUserEmail);
    }

    private void setupRecyclerView() {
        taskAdapter = new TaskAdapter(this);
        rvTasks.setLayoutManager(new LinearLayoutManager(this));
        rvTasks.setAdapter(taskAdapter);
    }

    private void setupListeners() {
        fabAddTask.setOnClickListener(v -> showAddTaskDialog());
        btnEmptyAddTask.setOnClickListener(v -> showAddTaskDialog());
        btnLogout.setOnClickListener(v -> showLogoutConfirmationDialog());
    }

    /**
     * Loads tasks strictly for the current user from SQLite.
     * Updates the empty state and progress indicator.
     */
    private void loadUserTasks() {
        List<Task> tasks = dbHelper.getTasksForUser(currentUserId);
        taskAdapter.setTasks(tasks);

        int totalCount = tasks.size();
        int completedCount = 0;
        for (Task t : tasks) {
            if (t.isCompleted()) {
                completedCount++;
            }
        }

        if (totalCount == 0) {
            rvTasks.setVisibility(View.GONE);
            llEmptyState.setVisibility(View.VISIBLE);
            tvProgressRatio.setText("0 / 0 completed");
            pbTaskProgress.setProgress(0);
        } else {
            rvTasks.setVisibility(View.VISIBLE);
            llEmptyState.setVisibility(View.GONE);
            tvProgressRatio.setText(completedCount + " of " + totalCount + " done");
            int progressPercent = (int) (((float) completedCount / totalCount) * 100);
            pbTaskProgress.setProgress(progressPercent);
        }
    }

    /**
     * Opens dialog to create a new task.
     */
    private void showAddTaskDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_task, null);
        EditText etTaskTitle = dialogView.findViewById(R.id.etTaskTitle);
        EditText etTaskNotes = dialogView.findViewById(R.id.etTaskNotes);
        Button btnCancelTask = dialogView.findViewById(R.id.btnCancelTask);
        Button btnSaveTask = dialogView.findViewById(R.id.btnSaveTask);

        AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                .setView(dialogView)
                .setCancelable(true)
                .create();

        btnCancelTask.setOnClickListener(v -> dialog.dismiss());

        btnSaveTask.setOnClickListener(v -> {
            String title = etTaskTitle.getText().toString().trim();
            String notes = etTaskNotes.getText().toString().trim();

            if (TextUtils.isEmpty(title)) {
                etTaskTitle.setError(getString(R.string.err_task_title_required));
                etTaskTitle.requestFocus();
                return;
            }

            // Insert task with authenticated user's ID
            long newTaskId = dbHelper.insertTask(currentUserId, title, notes);
            if (newTaskId != -1) {
                Toast.makeText(TaskListActivity.this, R.string.msg_task_created, Toast.LENGTH_SHORT).show();
                dialog.dismiss();
                loadUserTasks();
            } else {
                Toast.makeText(TaskListActivity.this, "Failed to create task", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    /**
     * Checkbox toggle callback: Updates completion in SQLite with user isolation check.
     */
    @Override
    public void onToggleComplete(Task task, boolean isCompleted) {
        boolean updated = dbHelper.updateTaskCompletion(task.getId(), currentUserId, isCompleted);
        if (updated) {
            task.setCompleted(isCompleted);
            loadUserTasks();
        } else {
            Toast.makeText(this, "Could not update task status", Toast.LENGTH_SHORT).show();
            loadUserTasks(); // Reload to restore correct state
        }
    }

    /**
     * Delete callback: Prompts confirmation before permanent SQLite deletion.
     */
    @Override
    public void onDeleteTask(Task task) {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.dialog_delete_title)
                .setMessage(R.string.dialog_delete_message)
                .setNegativeButton(R.string.btn_cancel, (dialog, which) -> dialog.dismiss())
                .setPositiveButton(R.string.btn_delete, (dialog, which) -> {
                    // Strictly scoped delete: requires both task ID and current user ID
                    boolean deleted = dbHelper.deleteTask(task.getId(), currentUserId);
                    if (deleted) {
                        Toast.makeText(TaskListActivity.this, R.string.msg_task_deleted, Toast.LENGTH_SHORT).show();
                        loadUserTasks();
                    } else {
                        Toast.makeText(TaskListActivity.this, "Failed to delete task", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    /**
     * Logout confirmation dialog.
     */
    private void showLogoutConfirmationDialog() {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.dialog_logout_title)
                .setMessage(R.string.dialog_logout_message)
                .setNegativeButton(R.string.btn_cancel, (dialog, which) -> dialog.dismiss())
                .setPositiveButton(R.string.btn_logout, (dialog, which) -> {
                    Toast.makeText(TaskListActivity.this, R.string.msg_logged_out, Toast.LENGTH_SHORT).show();
                    sessionManager.logoutUser();
                    finish();
                })
                .show();
    }
}
