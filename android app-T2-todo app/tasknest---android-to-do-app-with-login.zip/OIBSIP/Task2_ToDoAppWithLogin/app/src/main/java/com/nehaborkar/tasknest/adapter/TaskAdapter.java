package com.nehaborkar.tasknest.adapter;

import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.nehaborkar.tasknest.R;
import com.nehaborkar.tasknest.model.Task;

import java.util.ArrayList;
import java.util.List;

/**
 * RecyclerView Adapter for displaying task cards in TaskNest.
 * Handles strikethrough for completed tasks, toggle callbacks, and delete clicks.
 */
public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    public interface OnTaskActionListener {
        void onToggleComplete(Task task, boolean isCompleted);
        void onDeleteTask(Task task);
    }

    private List<Task> taskList = new ArrayList<>();
    private final OnTaskActionListener listener;

    public TaskAdapter(OnTaskActionListener listener) {
        this.listener = listener;
    }

    public void setTasks(List<Task> tasks) {
        this.taskList = (tasks != null) ? tasks : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.bind(task, listener);
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {
        private final CheckBox cbCompleted;
        private final TextView tvTaskTitle;
        private final TextView tvTaskNotes;
        private final TextView tvCreatedAt;
        private final ImageButton btnDeleteTask;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            cbCompleted = itemView.findViewById(R.id.cbCompleted);
            tvTaskTitle = itemView.findViewById(R.id.tvTaskTitle);
            tvTaskNotes = itemView.findViewById(R.id.tvTaskNotes);
            tvCreatedAt = itemView.findViewById(R.id.tvCreatedAt);
            btnDeleteTask = itemView.findViewById(R.id.btnDeleteTask);
        }

        public void bind(final Task task, final OnTaskActionListener listener) {
            tvTaskTitle.setText(task.getTitle());

            // Handle optional notes
            if (task.getNotes() != null && !task.getNotes().trim().isEmpty()) {
                tvTaskNotes.setVisibility(View.VISIBLE);
                tvTaskNotes.setText(task.getNotes());
            } else {
                tvTaskNotes.setVisibility(View.GONE);
            }

            // Date stamp display
            if (task.getCreatedAt() != null && !task.getCreatedAt().isEmpty()) {
                tvCreatedAt.setText("Created: " + task.getCreatedAt());
            } else {
                tvCreatedAt.setText("Created recently");
            }

            // Remove existing listener to prevent recursive callbacks during recycling
            cbCompleted.setOnCheckedChangeListener(null);
            cbCompleted.setChecked(task.isCompleted());

            // Update strikethrough styling and colors based on status
            applyCompletionStyle(task.isCompleted());

            cbCompleted.setOnCheckedChangeListener((buttonView, isChecked) -> {
                applyCompletionStyle(isChecked);
                if (listener != null) {
                    listener.onToggleComplete(task, isChecked);
                }
            });

            btnDeleteTask.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDeleteTask(task);
                }
            });
        }

        private void applyCompletionStyle(boolean isCompleted) {
            if (isCompleted) {
                tvTaskTitle.setPaintFlags(tvTaskTitle.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                tvTaskTitle.setTextColor(ContextCompat.getColor(itemView.getContext(), R.color.text_completed));
                tvTaskNotes.setPaintFlags(tvTaskNotes.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                tvTaskNotes.setTextColor(ContextCompat.getColor(itemView.getContext(), R.color.text_completed));
            } else {
                tvTaskTitle.setPaintFlags(tvTaskTitle.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                tvTaskTitle.setTextColor(ContextCompat.getColor(itemView.getContext(), R.color.text_primary));
                tvTaskNotes.setPaintFlags(tvTaskNotes.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                tvTaskNotes.setTextColor(ContextCompat.getColor(itemView.getContext(), R.color.text_secondary));
            }
        }
    }
}
