package com.nehaborkar.tasknest.session;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.nehaborkar.tasknest.LoginActivity;

/**
 * Manages the local user login session using Android SharedPreferences.
 * 
 * Note: Never store passwords or password hashes in SharedPreferences.
 * Stored session keys:
 * - KEY_USER_ID: Long (Primary Key from SQLite users table)
 * - KEY_USER_NAME: String
 * - KEY_USER_EMAIL: String
 * - KEY_IS_LOGGED_IN: Boolean
 */
public class SessionManager {

    private static final String PREF_NAME = "TaskNestSessionPref";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_USER_ID = "userId";
    private static final String KEY_USER_NAME = "userName";
    private static final String KEY_USER_EMAIL = "userEmail";

    private final SharedPreferences pref;
    private final SharedPreferences.Editor editor;
    private final Context context;

    public SessionManager(Context context) {
        this.context = context.getApplicationContext();
        this.pref = this.context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        this.editor = pref.edit();
    }

    /**
     * Create local login session after successful authentication.
     */
    public void createLoginSession(long userId, String name, String email) {
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putLong(KEY_USER_ID, userId);
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_EMAIL, email);
        editor.apply();
    }

    /**
     * Check if user is currently logged in.
     */
    public boolean isLoggedIn() {
        return pref.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    /**
     * Retrieves the authenticated user's ID for query scoping.
     */
    public long getUserId() {
        return pref.getLong(KEY_USER_ID, -1);
    }

    /**
     * Retrieves the authenticated user's full name.
     */
    public String getUserName() {
        return pref.getString(KEY_USER_NAME, "");
    }

    /**
     * Retrieves the authenticated user's email address.
     */
    public String getUserEmail() {
        return pref.getString(KEY_USER_EMAIL, "");
    }

    /**
     * Clears session details and redirects user to LoginActivity.
     * Clears the entire Activity back stack to prevent navigating back to authenticated screens.
     */
    public void logoutUser() {
        editor.clear();
        editor.apply();

        Intent intent = new Intent(context, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);
    }
}
