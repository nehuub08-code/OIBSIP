package com.nehaborkar.tasknest;

import static org.junit.Assert.*;

import com.nehaborkar.tasknest.security.PasswordUtils;

import org.junit.Test;

/**
 * Unit tests for PBKDF2WithHmacSHA256 password hashing and validation.
 */
public class PasswordUtilsTest {

    @Test
    public void testSaltGenerationIsRandomAndUnique() {
        byte[] salt1 = PasswordUtils.generateSalt();
        byte[] salt2 = PasswordUtils.generateSalt();

        assertNotNull(salt1);
        assertNotNull(salt2);
        assertEquals(PasswordUtils.SALT_LENGTH_BYTES, salt1.length);
        assertEquals(PasswordUtils.SALT_LENGTH_BYTES, salt2.length);

        // Verify two randomly generated salts are not identical
        assertFalse(PasswordUtils.bytesToHex(salt1).equals(PasswordUtils.bytesToHex(salt2)));
    }

    @Test
    public void testPasswordVerificationSuccess() {
        String originalPassword = "SecurePassword@2026";
        byte[] salt = PasswordUtils.generateSalt();
        String saltHex = PasswordUtils.bytesToHex(salt);
        String hashHex = PasswordUtils.hashPasswordToHex(originalPassword, salt);

        assertNotNull(hashHex);
        assertTrue(PasswordUtils.verifyPassword(originalPassword, saltHex, hashHex));
    }

    @Test
    public void testPasswordVerificationFailsOnWrongPassword() {
        String originalPassword = "CorrectPassword123";
        String wrongPassword = "WrongPassword456";

        byte[] salt = PasswordUtils.generateSalt();
        String saltHex = PasswordUtils.bytesToHex(salt);
        String hashHex = PasswordUtils.hashPasswordToHex(originalPassword, salt);

        assertFalse(PasswordUtils.verifyPassword(wrongPassword, saltHex, hashHex));
    }

    @Test
    public void testSafeHandlingOfNullAndMalformedInputs() {
        assertFalse(PasswordUtils.verifyPassword(null, "abcdef", "123456"));
        assertFalse(PasswordUtils.verifyPassword("test", null, "123456"));
        assertFalse(PasswordUtils.verifyPassword("test", "abcdef", null));
        assertFalse(PasswordUtils.verifyPassword("test", "invalid_odd_hex", "1234"));
    }
}
