package com.nehaborkar.tasknest;

import static org.junit.Assert.*;

import com.nehaborkar.tasknest.model.Task;
import com.nehaborkar.tasknest.model.User;

import org.junit.Test;

/**
 * Unit test validating user isolation invariant contracts.
 */
public class TaskIsolationLogicTest {

    @Test
    public void testTaskOwnershipContract() {
        User userA = new User(101L, "Neha Borkar", "neha@example.com", "hashA", "saltA");
        User userB = new User(102L, "Second User", "user2@example.com", "hashB", "saltB");

        Task taskA = new Task(1L, userA.getId(), "Prepare Oasis Task 2 Submission", "Check all requirements", false, "2026-10-27");
        Task taskB = new Task(2L, userB.getId(), "Independent Task For User B", "Private notes", false, "2026-10-27");

        // Verify task owners are isolated
        assertEquals(101L, taskA.getUserId());
        assertEquals(102L, taskB.getUserId());
        assertNotEquals(taskA.getUserId(), taskB.getUserId());
    }
}
