# TaskNest — Android To-Do App with Login

> **Oasis Infobyte Android App Development Internship (OIBSIP)**  
> **Task 2:** To-Do App with Login  
> **Intern Name:** Neha Vinod Borkar  
> **Track:** Android App Development  
> **Platform:** Android (Java & XML Layouts)  
> **Local Database:** SQLite via `SQLiteOpenHelper` with Foreign Keys  
> **Security:** PBKDF2WithHmacSHA256 with Per-User Cryptographic Salt  

---

## 📋 Table of Contents
1. [Project Overview](#1-project-overview)
2. [Key Features](#2-key-features)
3. [Architecture & Project Structure](#3-architecture--project-structure)
4. [Database Schema (SQLite)](#4-database-schema-sqlite)
5. [Security & Password Hashing](#5-security--password-hashing)
6. [User-Specific Task Isolation](#6-user-specific-task-isolation)
7. [Session Management](#7-session-management)
8. [Setup and Running in Android Studio](#8-setup-and-running-in-android-studio)
9. [20-Point Testing Checklist](#9-20-point-testing-checklist)
10. [Demo Video Guidelines](#10-demo-video-guidelines)
11. [Known Limitations](#11-known-limitations)

---

## 1. Project Overview
**TaskNest** is a native Android productivity application built in Java, XML layouts, and local SQLite database storage. It fulfills all technical specifications of the **Oasis Infobyte Internship Task 2**, featuring user registration, secure login, persistent task management, real-time completion tracking, strikethrough styling, and strict multi-user task isolation.

---

## 2. Key Features

- **🔐 Robust Authentication & Registration:**
  - Case-insensitive email uniqueness enforcement.
  - Client-side validation: valid email pattern, password minimum 8 characters, password confirmation match.
  - Generic authentication error messages to prevent account enumeration.

- **🛡️ Cryptographic Password Security:**
  - Zero plain-text passwords stored or logged.
  - Implements Java's `PBKDF2WithHmacSHA256` with 10,000 rounds of hashing and 256-bit derived keys.
  - Unique 16-byte random salt generated via `java.security.SecureRandom` for every user.
  - Constant-time verification using `MessageDigest.isEqual` to protect against timing attacks.

- **🗄️ SQLite Database with Foreign Keys:**
  - Managed through `DatabaseHelper.java` (`SQLiteOpenHelper`).
  - Strict foreign-key constraint (`tasks.user_id -> users.id`) with cascade support.
  - Parameterized queries and `ContentValues` throughout (100% immune to SQL injection).
  - Index on `tasks(user_id)` for high-performance task queries.

- **👤 Strict User Data Isolation:**
  - All read queries explicitly filter by `user_id = ?`.
  - All update and delete operations strictly check both task ID and current user ID:
    ```sql
    UPDATE tasks SET is_completed = ? WHERE id = ? AND user_id = ?
    DELETE FROM tasks WHERE id = ? AND user_id = ?
    ```
  - User A cannot view, modify, or delete tasks belonging to User B.

- **📝 Clean To-Do Management:**
  - Add tasks with title (required) and optional notes.
  - Mark complete / incomplete with instant visual feedback and strikethrough styling.
  - Delete task with permanent deletion confirmation dialog.
  - Empty-state view with friendly illustration: *"No tasks yet. Add your first task and make today productive!"*
  - Real-time progress bar and counter (`X of Y done`).

- **📱 User Experience & UI Design:**
  - Soft lavender, blue, and teal color accents on light backgrounds.
  - Rounded cards, clear typography, and responsive XML ConstraintLayouts.

---

## 3. Architecture & Project Structure

The project follows clean Separation of Concerns (SoC) for readability:

```
OIBSIP/Task2_ToDoAppWithLogin/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── AndroidManifest.xml
│   │   │   ├── java/com/nehaborkar/tasknest/
│   │   │   │   ├── LoginActivity.java         # Sign-in activity & session routing
│   │   │   │   ├── RegisterActivity.java      # Registration with validation & PBKDF2
│   │   │   │   ├── TaskListActivity.java      # Main dashboard, task CRUD & isolation
│   │   │   │   ├── adapter/
│   │   │   │   │   └── TaskAdapter.java       # RecyclerView adapter with strikethrough
│   │   │   │   ├── db/
│   │   │   │   │   └── DatabaseHelper.java    # SQLiteOpenHelper, schema & queries
│   │   │   │   ├── model/
│   │   │   │   │   ├── Task.java              # Task entity
│   │   │   │   │   └── User.java              # User entity
│   │   │   │   ├── security/
│   │   │   │   │   └── PasswordUtils.java     # PBKDF2WithHmacSHA256 & SecureRandom
│   │   │   │   └── session/
│   │   │   │       └── SessionManager.java    # SharedPreferences session management
│   │   │   └── res/
│   │   │       ├── drawable/                  # Vector drawables & background shapes
│   │   │       ├── layout/                    # XML layouts (login, register, dashboard, dialog)
│   │   │       └── values/                    # colors.xml, strings.xml, themes.xml
│   │   └── test/java/com/nehaborkar/tasknest/
│   │       ├── PasswordUtilsTest.java         # PBKDF2 & salt verification tests
│   │       └── TaskIsolationLogicTest.java    # Data isolation contract unit tests
│   └── build.gradle                           # Module build config
├── build.gradle                               # Project build config
├── settings.gradle
├── gradle.properties
└── README.md
```

---

## 4. Database Schema (SQLite)

### Table: `users`
| Column Name | Data Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique user identifier |
| `name` | TEXT | NOT NULL | User's full name |
| `email` | TEXT | UNIQUE NOT NULL | Normalized case-insensitive email |
| `password_hash` | TEXT | NOT NULL | PBKDF2 derived key in hexadecimal |
| `password_salt` | TEXT | NOT NULL | 16-byte random salt in hexadecimal |
| `created_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Account creation date |

### Table: `tasks`
| Column Name | Data Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique task identifier |
| `user_id` | INTEGER | NOT NULL, REFERENCES users(id) ON DELETE CASCADE | Owner foreign key |
| `title` | TEXT | NOT NULL | Task title / description |
| `notes` | TEXT | NULLABLE | Optional details or remarks |
| `is_completed` | INTEGER | NOT NULL DEFAULT 0 | 0 = Incomplete, 1 = Completed |
| `created_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Task creation timestamp |

*Index:* `CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON tasks(user_id);`

---

## 5. Security & Password Hashing

### The Problem with MD5 or Single SHA-256
MD5 and single-round SHA-256 are fast hash functions intended for file checksums, not password storage. Modern GPUs can compute billions of SHA-256 hashes per second, making dictionary and rainbow-table attacks trivial.

### The PBKDF2 Solution Implemented in TaskNest
TaskNest utilizes standard Java Cryptography Architecture (`javax.crypto.SecretKeyFactory`):
1. **Algorithm:** `PBKDF2WithHmacSHA256` (Password-Based Key Derivation Function 2 with HMAC-SHA256 pseudorandom function).
2. **Salt:** 16 bytes (128 bits) generated via `java.security.SecureRandom`. Ensures identical passwords result in completely different hashes.
3. **Iteration Count:** 10,000 iterations to make brute-force exponentially expensive while maintaining seamless performance on Android devices.
4. **Key Length:** 256 bits (32 bytes).
5. **Constant-Time Verification:** `MessageDigest.isEqual` is used to prevent side-channel timing attacks that could deduce byte differences.
6. **No Plaintext Logging:** Passwords and sensitive arrays are handled carefully and never logged in Logcat.

---

## 6. User-Specific Task Isolation

Data privacy is enforced at the database query level:
- When User 1 logs in, `sessionManager.getUserId()` returns `1`.
- When fetching tasks:
  ```java
  db.query("tasks", columns, "user_id = ?", new String[]{"1"}, ...);
  ```
- When marking complete:
  ```java
  db.update("tasks", values, "id = ? AND user_id = ?", new String[]{String.valueOf(taskId), "1"});
  ```
- When deleting a task:
  ```java
  db.delete("tasks", "id = ? AND user_id = ?", new String[]{String.valueOf(taskId), "1"});
  ```
Even if an attacker guessed another user's task ID, SQLite will not alter or reveal the record because the `user_id` check fails.

---

## 7. Session Management

Implemented using Android `SharedPreferences`:
- **Login:** Saves `KEY_USER_ID`, `KEY_USER_NAME`, `KEY_USER_EMAIL`, and `KEY_IS_LOGGED_IN = true`.
- **Restoration:** If `isLoggedIn()` is true on launch, `LoginActivity` immediately navigates to `TaskListActivity`.
- **Logout:** Clears all keys in `SharedPreferences` and launches `LoginActivity` with flags:
  ```java
  intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
  ```
  This empties the Android Activity back-stack so tapping the hardware Back button cannot return to the authenticated screen.

---

## 8. Setup and Running in Android Studio

### Prerequisites
- **Android Studio:** Hedgehog (2023.1.1) or newer / Iguana / Jellyfish / Ladybug
- **JDK:** Java 17 (recommended default)
- **Android SDK:**
  - `minSdk`: 24 (Android 7.0 Nougat)
  - `targetSdk` / `compileSdk`: 34 (Android 14)

### Steps to Run
1. Clone or open the repository folder in Android Studio:
   `File -> Open -> Select OIBSIP/Task2_ToDoAppWithLogin`
2. Let Gradle sync dependencies automatically.
3. Select an Android Virtual Device (AVD) emulator or connected physical Android device (API 24+).
4. Click **Run 'app'** (`Shift + F10` or the Green Play button).

---

## 9. 20-Point Testing Checklist

| # | Test Scenario | Status | Verification Detail |
| :- | :--- | :---: | :--- |
| 1 | Login screen opens for a new user | ✅ PASS | Verified initial launcher intent opens LoginActivity |
| 2 | Empty login fields are rejected | ✅ PASS | Validation error displayed on empty email or password |
| 3 | User can register successfully | ✅ PASS | Valid name, email, password registered and saved to SQLite |
| 4 | Invalid email and mismatched passwords rejected | ✅ PASS | Handled with inline error indicators |
| 5 | Duplicate email registration is prevented | ✅ PASS | `isEmailRegistered` blocks duplicate email addresses |
| 6 | Two accounts can register independently | ✅ PASS | Account 1 (Neha) and Account 2 (Test) created independently |
| 7 | Valid login opens the correct user's task list | ✅ PASS | Authenticates via PBKDF2 and loads user's dashboard |
| 8 | Invalid login is rejected | ✅ PASS | Generic error displayed without disclosing account existence |
| 9 | New task created with title and optional notes | ✅ PASS | Inserts task with current `user_id` into SQLite |
| 10 | Empty task titles rejected | ✅ PASS | Input validation prompts user to provide title |
| 11 | Tasks remain after closing and reopening app | ✅ PASS | SQLite database persists records across process restarts |
| 12 | Tasks can be marked complete and incomplete | ✅ PASS | Checkbox toggles `is_completed` (0 or 1) |
| 13 | Completed tasks show strikethrough styling | ✅ PASS | `Paint.STRIKE_THRU_TEXT_FLAG` applied dynamically |
| 14 | Tasks can be permanently deleted | ✅ PASS | Confirmation dialog confirms and executes deletion |
| 15 | Deleting last task displays empty state | ✅ PASS | Empty illustration and prompt displayed when task count is 0 |
| 16 | User A cannot see or modify User B's tasks | ✅ PASS | User isolation verified via scoped `user_id` queries |
| 17 | Logging out returns to Login and clears session | ✅ PASS | SharedPreferences cleared and redirected |
| 18 | Back navigation after logout does not reopen screen | ✅ PASS | `FLAG_ACTIVITY_CLEAR_TASK` clears task back-stack |
| 19 | Session restoration behaves correctly after relaunch | ✅ PASS | Auto-opens TaskListActivity if user is already logged in |
| 20 | Repeated database operations do not cause crashes | ✅ PASS | Cursors and DB transactions safely handled |

---

## 10. Demo Video Guidelines

For Oasis Infobyte submission, record the running app on an Android emulator or device:
- **Title Frame (at least 2 seconds):**
  - **Full Name:** Neha Vinod Borkar
  - **Assigned Track:** Android App Development
  - **Task Title:** Task 2 — To-Do App with Login
- **Flow to Demonstrate:**
  1. Register User 1.
  2. Sign in with User 1 credentials.
  3. Add multiple tasks (one with notes).
  4. Mark a task as completed (observe strikethrough).
  5. Delete a task with confirmation dialog.
  6. Force close and reopen app (observe session & tasks persist).
  7. Log out.
  8. Register/Log in as User 2 and demonstrate User 2 has an empty task list (User 1's tasks are completely isolated!).

---

## 11. Known Limitations
- **Local SQLite Scope:** This is a standalone local-only Android application. SQLite data is stored on the physical device or emulator sandbox. It is not connected to a remote cloud server.
- **Biometric Authentication:** Future versions could integrate AndroidX BiometricPrompt for fingerprint/face unlock.

---
*Created with pride by **Neha Vinod Borkar** for the Oasis Infobyte Internship Program.*
