import React, { useState, useEffect } from 'react';
import { PhoneSimulator } from './components/PhoneSimulator';
import { DatabaseInspector } from './components/DatabaseInspector';
import { TestRunner } from './components/TestRunner';
import { CodeExplorer } from './components/CodeExplorer';
import { DemoVideoMode } from './components/DemoVideoMode';
import { DatabaseHelperService, SessionManagerService } from './services/db';
import {
  Smartphone,
  Database,
  CheckCircle,
  FileCode2,
  Video,
  ShieldCheck,
  Sparkles,
  ExternalLink,
  Github,
  Award,
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'emulator' | 'database' | 'tests' | 'code' | 'video'>('emulator');

  // Auto-seed initial sample accounts on first boot if database is brand new
  useEffect(() => {
    const existingUsers = DatabaseHelperService.getAllUsers();
    if (existingUsers.length === 0) {
      DatabaseHelperService.seedDemoData();
    }
  }, []);

  return (
    <div className="min-h-screen bg-[#F4F6FC] text-[#1E2238] font-sans flex flex-col">
      {/* Top Application Header */}
      <header className="bg-white border-b border-[#E4E7F4] sticky top-0 z-40 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#6C5CE7] to-[#0984E3] flex items-center justify-center text-white shadow-md shadow-indigo-100">
              <CheckCircle className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-extrabold tracking-tight text-[#1E2238]">TaskNest</h1>
                <span className="text-[10px] bg-indigo-50 text-[#6C5CE7] font-bold px-2 py-0.5 rounded-full border border-indigo-100">
                  Android Studio Project
                </span>
              </div>
              <p className="text-xs text-[#636B83] font-medium">
                Oasis Infobyte Internship • Task 2: To-Do App with Login
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex flex-col text-right">
              <span className="text-xs font-bold text-gray-900">Neha Vinod Borkar</span>
              <span className="text-[11px] text-gray-500">Android App Development Track</span>
            </div>

            <div className="h-8 w-px bg-gray-200 hidden md:block"></div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => DatabaseHelperService.seedDemoData()}
                className="text-xs font-semibold px-3 py-1.5 bg-indigo-50 text-[#6C5CE7] hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer"
                title="Reset test data for Neha and Rahul"
              >
                Reset Demo Data
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex overflow-x-auto gap-1 border-t border-gray-100 py-1">
          <button
            type="button"
            onClick={() => setActiveTab('emulator')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'emulator'
                ? 'bg-[#6C5CE7] text-white shadow-sm'
                : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Android Device Emulator</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('database')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'database'
                ? 'bg-[#6C5CE7] text-white shadow-sm'
                : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Live SQLite Inspector</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('tests')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'tests'
                ? 'bg-[#6C5CE7] text-white shadow-sm'
                : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
            }`}
          >
            <CheckCircle className="w-4 h-4" />
            <span>20-Point Test Suite</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('code')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'code'
                ? 'bg-[#6C5CE7] text-white shadow-sm'
                : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
            }`}
          >
            <FileCode2 className="w-4 h-4" />
            <span>Code & Android Studio (.ZIP)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('video')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'video'
                ? 'bg-[#6C5CE7] text-white shadow-sm'
                : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
            }`}
          >
            <Video className="w-4 h-4" />
            <span>Demo Video Mode</span>
          </button>
        </div>
      </header>

      {/* Main Body View */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'emulator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Phone Emulator Column */}
            <div className="lg:col-span-6 flex justify-center">
              <PhoneSimulator />
            </div>

            {/* Side Explanations & Quick Testing Guide */}
            <div className="lg:col-span-6 space-y-4">
              {/* Internship Project Banner */}
              <div className="bg-gradient-to-br from-[#6C5CE7] to-[#0984E3] rounded-2xl p-5 text-white shadow-md">
                <div className="flex items-center gap-2 text-indigo-100 text-xs font-semibold">
                  <Award className="w-4 h-4 text-[#00B894]" />
                  <span>Oasis Infobyte Internship Program</span>
                </div>
                <h2 className="text-xl font-extrabold mt-1">TaskNest — Android To-Do App</h2>
                <p className="text-xs text-indigo-100 mt-1 leading-relaxed">
                  Developed by <span className="font-bold text-white">Neha Vinod Borkar</span> using native Java, XML layouts, SQLiteOpenHelper with Foreign Key constraints, and PBKDF2WithHmacSHA256 password security.
                </p>
              </div>

              {/* Quick Testing Instructions */}
              <div className="bg-white rounded-2xl p-5 border border-gray-200 shadow-xs space-y-3">
                <h3 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#6C5CE7]" />
                  <span>Interactive Verification Guide</span>
                </h3>

                <div className="space-y-2 text-xs text-gray-600">
                  <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
                    <p className="font-bold text-gray-800">1. Test Authentication & Passwords</p>
                    <p className="mt-0.5">
                      Use the quick-fill buttons on the login screen or register a new user. Passwords are encrypted with PBKDF2 (10,000 iterations) and 16-byte random salt.
                    </p>
                  </div>

                  <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
                    <p className="font-bold text-gray-800">2. Test User Isolation (Critical Requirement)</p>
                    <p className="mt-0.5">
                      Log in as <strong>Neha Borkar</strong> and add a task. Then log out and log in as <strong>Rahul Sharma</strong>. Notice that Rahul cannot see Neha's tasks, and Neha cannot see Rahul's!
                    </p>
                  </div>

                  <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
                    <p className="font-bold text-gray-800">3. Test Persistence across App Restarts</p>
                    <p className="mt-0.5">
                      Click the <strong>"Restart App (Test Persistence)"</strong> button above the phone. The local SQLite database and SharedPreferences session restore automatically.
                    </p>
                  </div>

                  <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
                    <p className="font-bold text-gray-800">4. Test Strikethrough & Delete Confirmation</p>
                    <p className="mt-0.5">
                      Check a task to see strikethrough styling. Click the trash icon to test the deletion confirmation dialog.
                    </p>
                  </div>
                </div>
              </div>

              {/* Security & SQLite Overview */}
              <div className="bg-white rounded-2xl p-5 border border-gray-200 shadow-xs">
                <h3 className="text-sm font-bold text-gray-900 flex items-center gap-2 mb-2">
                  <ShieldCheck className="w-4 h-4 text-[#00B894]" />
                  <span>Architecture & Security Specifications</span>
                </h3>
                <ul className="space-y-1.5 text-xs text-gray-600">
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#6C5CE7]" />
                    <span><strong>Database:</strong> SQLite with foreign-key enforcement (<code className="text-[#6C5CE7]">ON DELETE CASCADE</code>)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#6C5CE7]" />
                    <span><strong>Hashing:</strong> PBKDF2WithHmacSHA256, 10,000 rounds, 256-bit derived key</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#6C5CE7]" />
                    <span><strong>Salt:</strong> 16-byte random salt generated via <code className="text-[#6C5CE7]">SecureRandom</code></span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#6C5CE7]" />
                    <span><strong>Session:</strong> Local <code className="text-[#6C5CE7]">SharedPreferences</code> with zero plaintext credentials</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#6C5CE7]" />
                    <span><strong>Queries:</strong> 100% Parameterized queries with <code className="text-[#6C5CE7]">ContentValues</code></span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'database' && <DatabaseInspector />}
        {activeTab === 'tests' && <TestRunner />}
        {activeTab === 'code' && <CodeExplorer />}
        {activeTab === 'video' && <DemoVideoMode />}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-6 mt-12 text-center text-xs text-gray-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>
            <strong>TaskNest</strong> • Built for Oasis Infobyte Android App Development Internship Task 2
          </p>
          <p>
            Developer: <strong>Neha Vinod Borkar</strong> • Repository: <code className="text-[#6C5CE7]">OIBSIP</code>
          </p>
        </div>
      </footer>
    </div>
  );
}
