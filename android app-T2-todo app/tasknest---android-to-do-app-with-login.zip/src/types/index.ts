export interface UserRecord {
  id: number;
  name: string;
  email: string;
  password_hash: string;
  password_salt: string;
  created_at: string;
}

export interface TaskRecord {
  id: number;
  user_id: number;
  title: string;
  notes: string;
  is_completed: number; // 0 = incomplete, 1 = completed
  created_at: string;
}

export interface SessionData {
  isLoggedIn: boolean;
  userId: number;
  userName: string;
  userEmail: string;
}

export interface TestCase {
  id: number;
  title: string;
  description: string;
  status: 'idle' | 'running' | 'passed' | 'failed';
  details?: string;
}
