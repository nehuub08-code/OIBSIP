import { UserRecord, TaskRecord, SessionData } from '../types';
import { generateSalt, hashPassword, verifyPassword, bytesToHex } from './crypto';

const STORAGE_KEY_USERS = 'tasknest_sqlite_users';
const STORAGE_KEY_TASKS = 'tasknest_sqlite_tasks';
const STORAGE_KEY_SESSION = 'tasknest_shared_pref_session';

type DbChangeListener = () => void;
const listeners: Set<DbChangeListener> = new Set();

export function subscribeToDb(listener: DbChangeListener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function notifyDbChange() {
  listeners.forEach((fn) => fn());
}

// Low-level storage access
function getStoredUsers(): UserRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_USERS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveUsers(users: UserRecord[]): void {
  localStorage.setItem(STORAGE_KEY_USERS, JSON.stringify(users));
  notifyDbChange();
}

function getStoredTasks(): TaskRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_TASKS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveTasks(tasks: TaskRecord[]): void {
  localStorage.setItem(STORAGE_KEY_TASKS, JSON.stringify(tasks));
  notifyDbChange();
}

// Database helper functions mirroring DatabaseHelper.java
export const DatabaseHelperService = {
  isEmailRegistered(email: string): boolean {
    const norm = email.trim().toLowerCase();
    const users = getStoredUsers();
    return users.some((u) => u.email.toLowerCase() === norm);
  },

  async registerUser(name: string, email: string, password: string): Promise<UserRecord | null> {
    const normEmail = email.trim().toLowerCase();
    if (this.isEmailRegistered(normEmail)) {
      return null;
    }

    const salt = generateSalt();
    const saltHex = bytesToHex(salt);
    const hashHex = await hashPassword(password, salt);

    const users = getStoredUsers();
    const nextId = users.length > 0 ? Math.max(...users.map((u) => u.id)) + 1 : 1;

    const newUser: UserRecord = {
      id: nextId,
      name: name.trim(),
      email: normEmail,
      password_hash: hashHex,
      password_salt: saltHex,
      created_at: new Date().toISOString().replace('T', ' ').substring(0, 19),
    };

    users.push(newUser);
    saveUsers(users);
    return newUser;
  },

  async authenticateUser(email: string, password: string): Promise<UserRecord | null> {
    const normEmail = email.trim().toLowerCase();
    const users = getStoredUsers();
    const user = users.find((u) => u.email.toLowerCase() === normEmail);

    if (!user) return null;

    const matches = await verifyPassword(password, user.password_salt, user.password_hash);
    return matches ? user : null;
  },

  getUserById(userId: number): UserRecord | null {
    const users = getStoredUsers();
    return users.find((u) => u.id === userId) || null;
  },

  getAllUsers(): UserRecord[] {
    return getStoredUsers();
  },

  // Task Operations - Strictly Scoped to User ID
  insertTask(userId: number, title: string, notes: string): TaskRecord | null {
    if (!title.trim() || userId <= 0) return null;

    const tasks = getStoredTasks();
    const nextId = tasks.length > 0 ? Math.max(...tasks.map((t) => t.id)) + 1 : 1;

    const newTask: TaskRecord = {
      id: nextId,
      user_id: userId,
      title: title.trim(),
      notes: notes ? notes.trim() : '',
      is_completed: 0,
      created_at: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }),
    };

    tasks.push(newTask);
    saveTasks(tasks);
    return newTask;
  },

  getTasksForUser(userId: number): TaskRecord[] {
    const tasks = getStoredTasks();
    return tasks
      .filter((t) => t.user_id === userId)
      .sort((a, b) => {
        if (a.is_completed !== b.is_completed) {
          return a.is_completed - b.is_completed;
        }
        return b.id - a.id;
      });
  },

  updateTaskCompletion(taskId: number, userId: number, isCompleted: boolean): boolean {
    const tasks = getStoredTasks();
    const index = tasks.findIndex((t) => t.id === taskId && t.user_id === userId);
    if (index === -1) return false;

    tasks[index].is_completed = isCompleted ? 1 : 0;
    saveTasks(tasks);
    return true;
  },

  deleteTask(taskId: number, userId: number): boolean {
    const tasks = getStoredTasks();
    const initialLen = tasks.length;
    const filtered = tasks.filter((t) => !(t.id === taskId && t.user_id === userId));

    if (filtered.length !== initialLen) {
      saveTasks(filtered);
      return true;
    }
    return false;
  },

  getAllTasks(): TaskRecord[] {
    return getStoredTasks();
  },

  clearDatabase() {
    localStorage.removeItem(STORAGE_KEY_USERS);
    localStorage.removeItem(STORAGE_KEY_TASKS);
    SessionManagerService.clearSession();
    notifyDbChange();
  },

  async seedDemoData() {
    this.clearDatabase();

    // Account 1: Neha Vinod Borkar (Intern)
    const user1 = await this.registerUser('Neha Vinod Borkar', 'neha@example.com', 'NehaBorkar@2026');
    if (user1) {
      this.insertTask(
        user1.id,
        'Implement PBKDF2WithHmacSHA256 password security',
        'Use SecureRandom 16-byte salt and constant-time check'
      );
      this.insertTask(
        user1.id,
        'Design responsive XML layouts with soft lavender palette',
        'activity_login, activity_register, activity_task_list, and dialogs'
      );
      this.insertTask(
        user1.id,
        'Verify SQLite Foreign Key and User Isolation',
        'Enforce user_id constraints on all queries, updates, and deletes'
      );
      const doneTask = this.insertTask(
        user1.id,
        'Review Oasis Infobyte Task 2 Guidelines',
        'Confirmed repository name OIBSIP and deliverables'
      );
      if (doneTask) {
        this.updateTaskCompletion(doneTask.id, user1.id, true);
      }
    }

    // Account 2: Rahul Sharma (For testing user isolation)
    const user2 = await this.registerUser('Rahul Sharma', 'rahul@example.com', 'TestingPass123');
    if (user2) {
      this.insertTask(
        user2.id,
        'Rahul\'s Private Task: Review Android SQLite schema',
        'This task must NEVER be visible to Neha Borkar!'
      );
      this.insertTask(
        user2.id,
        'Prepare separate internship report',
        'Independent user data test'
      );
    }

    notifyDbChange();
  },
};

// Session Manager mirroring SessionManager.java (SharedPreferences)
export const SessionManagerService = {
  getSession(): SessionData {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_SESSION);
      if (!raw) {
        return { isLoggedIn: false, userId: -1, userName: '', userEmail: '' };
      }
      return JSON.parse(raw);
    } catch {
      return { isLoggedIn: false, userId: -1, userName: '', userEmail: '' };
    }
  },

  setSession(user: UserRecord): void {
    const data: SessionData = {
      isLoggedIn: true,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
    };
    localStorage.setItem(STORAGE_KEY_SESSION, JSON.stringify(data));
    notifyDbChange();
  },

  clearSession(): void {
    localStorage.removeItem(STORAGE_KEY_SESSION);
    notifyDbChange();
  },
};
