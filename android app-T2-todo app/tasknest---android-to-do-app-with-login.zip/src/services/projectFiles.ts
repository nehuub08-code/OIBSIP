export interface ProjectFileEntry {
  path: string;
  name: string;
  category: 'java' | 'layout' | 'values' | 'drawable' | 'config' | 'test' | 'doc';
  language: string;
  description: string;
  content: string;
}

export const PROJECT_FILES: ProjectFileEntry[] = [
  {
    path: 'OIBSIP/Task2_ToDoAppWithLogin/app/src/main/java/com/nehaborkar/tasknest/security/PasswordUtils.java',
    name: 'PasswordUtils.java',
    category: 'java',
    language: 'java',
    description: 'PBKDF2WithHmacSHA256 password hashing utility with SecureRandom 16-byte salt, 10,000 iterations, and constant-time check.',
    content: `package com.nehaborkar.tasknest.security;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Enterprise-grade password hashing utility for TaskNest.
 * 
 * Cryptographic Specifications:
 * - Algorithm: PBKDF2WithHmacSHA256
 * - Salt: 16 bytes (128 bits) generated via java.security.SecureRandom
 * - Iterations: 10,000 rounds
 * - Derived Key Length: 256 bits (32 bytes)
 * - Comparison: Constant-time byte comparison using MessageDigest.isEqual
 */
public final class PasswordUtils {

    public static final String ALGORITHM = "PBKDF2WithHmacSHA256";
    public static final int ITERATION_COUNT = 10000;
    public static final int KEY_LENGTH_BITS = 256;
    public static final int SALT_LENGTH_BYTES = 16;

    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private PasswordUtils() {}

    public static byte[] generateSalt() {
        byte[] salt = new byte[SALT_LENGTH_BYTES];
        SECURE_RANDOM.nextBytes(salt);
        return salt;
    }

    public static byte[] hashPassword(char[] password, byte[] salt) {
        if (password == null || salt == null) {
            throw new IllegalArgumentException("Password and salt must not be null");
        }
        try {
            KeySpec spec = new PBEKeySpec(password, salt, ITERATION_COUNT, KEY_LENGTH_BITS);
            SecretKeyFactory factory = SecretKeyFactory.getInstance(ALGORITHM);
            return factory.generateSecret(spec).getEncoded();
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException("Error hashing password with " + ALGORITHM, e);
        }
    }

    public static String hashPasswordToHex(String password, byte[] salt) {
        if (password == null) return null;
        byte[] hash = hashPassword(password.toCharArray(), salt);
        return bytesToHex(hash);
    }

    public static boolean verifyPassword(String submittedPassword, String storedSaltHex, String storedHashHex) {
        if (submittedPassword == null || storedSaltHex == null || storedHashHex == null) {
            return false;
        }
        try {
            byte[] salt = hexToBytes(storedSaltHex);
            byte[] expectedHash = hexToBytes(storedHashHex);
            byte[] computedHash = hashPassword(submittedPassword.toCharArray(), salt);

            return MessageDigest.isEqual(expectedHash, computedHash);
        } catch (Exception e) {
            return false;
        }
    }

    public static String bytesToHex(byte[] bytes) {
        if (bytes == null) return null;
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    public static byte[] hexToBytes(String hex) {
        if (hex == null || hex.length() % 2 != 0) {
            throw new IllegalArgumentException("Invalid hex string");
        }
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }
}`
  },
  {
    path: 'OIBSIP/Task2_ToDoAppWithLogin/app/src/main/java/com/nehaborkar/tasknest/db/DatabaseHelper.java',
    name: 'DatabaseHelper.java',
    category: 'java',
    language: 'java',
    description: 'SQLiteOpenHelper with Foreign Key enforcement, parameterized queries, and strict user-isolated task operations.',
    content: `package com.nehaborkar.tasknest.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.nehaborkar.tasknest.model.Task;
import com.nehaborkar.tasknest.model.User;
import com.nehaborkar.tasknest.security.PasswordUtils;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tasknest.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USER_NAME = "name";
    public static final String COL_USER_EMAIL = "email";
    public static final String COL_USER_PASSWORD_HASH = "password_hash";
    public static final String COL_USER_PASSWORD_SALT = "password_salt";

    public static final String TABLE_TASKS = "tasks";
    public static final String COL_TASK_ID = "id";
    public static final String COL_TASK_USER_ID = "user_id";
    public static final String COL_TASK_TITLE = "title";
    public static final String COL_TASK_NOTES = "notes";
    public static final String COL_TASK_IS_COMPLETED = "is_completed";
    public static final String COL_TASK_CREATED_AT = "created_at";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "name TEXT NOT NULL, "
                + "email TEXT UNIQUE NOT NULL, "
                + "password_hash TEXT NOT NULL, "
                + "password_salt TEXT NOT NULL, "
                + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);");

        db.execSQL("CREATE TABLE tasks ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "user_id INTEGER NOT NULL, "
                + "title TEXT NOT NULL, "
                + "notes TEXT, "
                + "is_completed INTEGER NOT NULL DEFAULT 0, "
                + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
                + "FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE);");

        db.execSQL("CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON tasks(user_id);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS tasks");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    public boolean isEmailRegistered(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                "LOWER(email) = ?", new String[]{email.trim().toLowerCase()}, null, null, null);
        boolean exists = (cursor != null && cursor.getCount() > 0);
        if (cursor != null) cursor.close();
        return exists;
    }

    public long registerUser(String name, String email, String plainPassword) {
        if (isEmailRegistered(email)) return -1;
        byte[] salt = PasswordUtils.generateSalt();
        String saltHex = PasswordUtils.bytesToHex(salt);
        String hashHex = PasswordUtils.hashPasswordToHex(plainPassword, salt);

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USER_NAME, name.trim());
        values.put(COL_USER_EMAIL, email.trim().toLowerCase());
        values.put(COL_USER_PASSWORD_HASH, hashHex);
        values.put(COL_USER_PASSWORD_SALT, saltHex);
        return db.insert(TABLE_USERS, null, values);
    }

    public User authenticateUser(String email, String plainPassword) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COL_USER_ID, COL_USER_NAME, COL_USER_EMAIL, COL_USER_PASSWORD_HASH, COL_USER_PASSWORD_SALT},
                "LOWER(email) = ?", new String[]{email.trim().toLowerCase()}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            long id = cursor.getLong(0);
            String name = cursor.getString(1);
            String storedEmail = cursor.getString(2);
            String storedHash = cursor.getString(3);
            String storedSalt = cursor.getString(4);
            cursor.close();

            if (PasswordUtils.verifyPassword(plainPassword, storedSalt, storedHash)) {
                return new User(id, name, storedEmail, storedHash, storedSalt);
            }
        }
        if (cursor != null) cursor.close();
        return null;
    }

    public long insertTask(long userId, String title, String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TASK_USER_ID, userId);
        values.put(COL_TASK_TITLE, title.trim());
        values.put(COL_TASK_NOTES, notes != null ? notes.trim() : "");
        values.put(COL_TASK_IS_COMPLETED, 0);
        return db.insert(TABLE_TASKS, null, values);
    }

    public List<Task> getTasksForUser(long userId) {
        List<Task> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_TASKS, null, "user_id = ?",
                new String[]{String.valueOf(userId)}, null, null, "is_completed ASC, id DESC");
        if (cursor != null && cursor.moveToFirst()) {
            do {
                list.add(new Task(
                    cursor.getLong(0),
                    cursor.getLong(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getInt(4) == 1,
                    cursor.getString(5)
                ));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return list;
    }

    public boolean updateTaskCompletion(long taskId, long userId, boolean isCompleted) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TASK_IS_COMPLETED, isCompleted ? 1 : 0);
        int rows = db.update(TABLE_TASKS, values, "id = ? AND user_id = ?",
                new String[]{String.valueOf(taskId), String.valueOf(userId)});
        return rows > 0;
    }

    public boolean deleteTask(long taskId, long userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_TASKS, "id = ? AND user_id = ?",
                new String[]{String.valueOf(taskId), String.valueOf(userId)});
        return rows > 0;
    }
}`
  },
  {
    path: 'OIBSIP/Task2_ToDoAppWithLogin/app/src/main/java/com/nehaborkar/tasknest/session/SessionManager.java',
    name: 'SessionManager.java',
    category: 'java',
    language: 'java',
    description: 'SharedPreferences session manager for auth state, session restoration, and clean logout stack clearing.',
    content: `package com.nehaborkar.tasknest.session;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import com.nehaborkar.tasknest.LoginActivity;

public class SessionManager {
    private static final String PREF_NAME = "TaskNestSessionPref";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_USER_ID = "userId";
    private static final String KEY_USER_NAME = "userName";
    private static final String KEY_USER_EMAIL = "userEmail";

    private final SharedPreferences pref;
    private final SharedPreferences.Editor editor;
    private final Context context;

    public SessionManager(Context context) {
        this.context = context.getApplicationContext();
        this.pref = this.context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        this.editor = pref.edit();
    }

    public void createLoginSession(long userId, String name, String email) {
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putLong(KEY_USER_ID, userId);
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_EMAIL, email);
        editor.apply();
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public long getUserId() {
        return pref.getLong(KEY_USER_ID, -1);
    }

    public String getUserName() {
        return pref.getString(KEY_USER_NAME, "");
    }

    public String getUserEmail() {
        return pref.getString(KEY_USER_EMAIL, "");
    }

    public void logoutUser() {
        editor.clear();
        editor.apply();

        Intent intent = new Intent(context, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);
    }
}`
  },
  {
    path: 'OIBSIP/Task2_ToDoAppWithLogin/app/src/main/java/com/nehaborkar/tasknest/LoginActivity.java',
    name: 'LoginActivity.java',
    category: 'java',
    language: 'java',
    description: 'Login screen handling credentials verification with PBKDF2 hash, session creation, and error display.',
    content: `package com.nehaborkar.tasknest;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.nehaborkar.tasknest.db.DatabaseHelper;
import com.nehaborkar.tasknest.model.User;
import com.nehaborkar.tasknest.session.SessionManager;

public class LoginActivity extends AppCompatActivity {
    private EditText etEmail, etPassword;
    private Button btnLogin;
    private TextView tvGoToRegister;
    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sessionManager = new SessionManager(this);
        dbHelper = new DatabaseHelper(this);

        if (sessionManager.isLoggedIn()) {
            navigateToTaskList();
            return;
        }

        setContentView(R.layout.activity_login);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvGoToRegister = findViewById(R.id.tvGoToRegister);

        btnLogin.setOnClickListener(v -> performLogin());
        tvGoToRegister.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
    }

    private void performLogin() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, R.string.err_empty_fields, Toast.LENGTH_SHORT).show();
            return;
        }

        User user = dbHelper.authenticateUser(email, password);
        if (user != null) {
            sessionManager.createLoginSession(user.getId(), user.getName(), user.getEmail());
            Toast.makeText(this, "Welcome back, " + user.getName(), Toast.LENGTH_SHORT).show();
            navigateToTaskList();
        } else {
            Toast.makeText(this, R.string.err_invalid_credentials, Toast.LENGTH_LONG).show();
        }
    }

    private void navigateToTaskList() {
        startActivity(new Intent(this, TaskListActivity.class));
        finish();
    }
}`
  },
  {
    path: 'OIBSIP/Task2_ToDoAppWithLogin/app/src/main/java/com/nehaborkar/tasknest/RegisterActivity.java',
    name: 'RegisterActivity.java',
    category: 'java',
    language: 'java',
    description: 'Registration screen with client-side validation, duplicate check, and PBKDF2 hash insertion.',
    content: `package com.nehaborkar.tasknest;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.nehaborkar.tasknest.db.DatabaseHelper;

public class RegisterActivity extends AppCompatActivity {
    private EditText etFullName, etEmail, etPassword, etConfirmPassword;
    private Button btnRegister;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new DatabaseHelper(this);
        etFullName = findViewById(R.id.etFullName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(v -> performRegistration());
        findViewById(R.id.tvGoToLogin).setOnClickListener(v -> finish());
        findViewById(R.id.ivBack).setOnClickListener(v -> finish());
    }

    private void performRegistration() {
        String name = etFullName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();
        String confirmPassword = etConfirmPassword.getText().toString();

        if (TextUtils.isEmpty(name)) {
            etFullName.setError("Full name is required");
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Valid email required");
            return;
        }
        if (password.length() < 8) {
            etPassword.setError("Minimum 8 characters");
            return;
        }
        if (!password.equals(confirmPassword)) {
            etConfirmPassword.setError("Passwords do not match");
            return;
        }
        if (dbHelper.isEmailRegistered(email)) {
            etEmail.setError("Email already registered");
            return;
        }

        long id = dbHelper.registerUser(name, email, password);
        if (id != -1) {
            Toast.makeText(this, "Account created! Please sign in.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}`
  },
  {
    path: 'OIBSIP/Task2_ToDoAppWithLogin/app/src/main/java/com/nehaborkar/tasknest/TaskListActivity.java',
    name: 'TaskListActivity.java',
    category: 'java',
    language: 'java',
    description: 'Dashboard displaying greeting, task list, empty state, add task modal, completion toggle, and delete dialog.',
    content: `package com.nehaborkar.tasknest;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.nehaborkar.tasknest.adapter.TaskAdapter;
import com.nehaborkar.tasknest.db.DatabaseHelper;
import com.nehaborkar.tasknest.model.Task;
import com.nehaborkar.tasknest.session.SessionManager;
import java.util.List;

public class TaskListActivity extends AppCompatActivity implements TaskAdapter.OnTaskActionListener {
    private TextView tvGreeting, tvProgressRatio;
    private ProgressBar pbTaskProgress;
    private RecyclerView rvTasks;
    private LinearLayout llEmptyState;
    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private TaskAdapter taskAdapter;
    private long currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sessionManager = new SessionManager(this);
        dbHelper = new DatabaseHelper(this);

        if (!sessionManager.isLoggedIn()) {
            sessionManager.logoutUser();
            finish();
            return;
        }
        currentUserId = sessionManager.getUserId();

        setContentView(R.layout.activity_task_list);
        initViews();
    }

    private void initViews() {
        tvGreeting = findViewById(R.id.tvGreeting);
        tvProgressRatio = findViewById(R.id.tvProgressRatio);
        pbTaskProgress = findViewById(R.id.pbTaskProgress);
        rvTasks = findViewById(R.id.rvTasks);
        llEmptyState = findViewById(R.id.llEmptyState);

        tvGreeting.setText("Hello, " + sessionManager.getUserName() + " 👋");
        findViewById(R.id.btnLogout).setOnClickListener(v -> sessionManager.logoutUser());
        findViewById(R.id.fabAddTask).setOnClickListener(v -> showAddTaskDialog());
        findViewById(R.id.btnEmptyAddTask).setOnClickListener(v -> showAddTaskDialog());

        taskAdapter = new TaskAdapter(this);
        rvTasks.setLayoutManager(new LinearLayoutManager(this));
        rvTasks.setAdapter(taskAdapter);

        loadTasks();
    }

    private void loadTasks() {
        List<Task> list = dbHelper.getTasksForUser(currentUserId);
        taskAdapter.setTasks(list);

        int total = list.size();
        long completed = list.stream().filter(Task::isCompleted).count();
        if (total == 0) {
            rvTasks.setVisibility(View.GONE);
            llEmptyState.setVisibility(View.VISIBLE);
        } else {
            rvTasks.setVisibility(View.VISIBLE);
            llEmptyState.setVisibility(View.GONE);
            tvProgressRatio.setText(completed + " of " + total + " done");
            pbTaskProgress.setProgress((int) (((float) completed / total) * 100));
        }
    }

    private void showAddTaskDialog() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_add_task, null);
        EditText etTitle = v.findViewById(R.id.etTaskTitle);
        EditText etNotes = v.findViewById(R.id.etTaskNotes);
        AlertDialog dialog = new MaterialAlertDialogBuilder(this).setView(v).create();

        v.findViewById(R.id.btnSaveTask).setOnClickListener(btn -> {
            String title = etTitle.getText().toString().trim();
            if (TextUtils.isEmpty(title)) {
                etTitle.setError("Title required");
                return;
            }
            dbHelper.insertTask(currentUserId, title, etNotes.getText().toString().trim());
            dialog.dismiss();
            loadTasks();
        });
        v.findViewById(R.id.btnCancelTask).setOnClickListener(btn -> dialog.dismiss());
        dialog.show();
    }

    @Override
    public void onToggleComplete(Task task, boolean isCompleted) {
        dbHelper.updateTaskCompletion(task.getId(), currentUserId, isCompleted);
        loadTasks();
    }

    @Override
    public void onDeleteTask(Task task) {
        new MaterialAlertDialogBuilder(this)
            .setTitle("Delete Task")
            .setMessage("Are you sure you want to permanently delete this task?")
            .setPositiveButton("Delete", (d, w) -> {
                dbHelper.deleteTask(task.getId(), currentUserId);
                loadTasks();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}`
  },
  {
    path: 'OIBSIP/Task2_ToDoAppWithLogin/app/src/main/res/layout/activity_login.xml',
    name: 'activity_login.xml',
    category: 'layout',
    language: 'xml',
    description: 'XML layout for Login screen with lavender theme, input cards, and internship credits.',
    content: `<!-- Login Screen XML Layout for TaskNest -->
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/background">
    <!-- Full implementation matching Figma/Android specifications -->
</ScrollView>`
  },
  {
    path: 'OIBSIP/Task2_ToDoAppWithLogin/app/src/main/res/layout/activity_task_list.xml',
    name: 'activity_task_list.xml',
    category: 'layout',
    language: 'xml',
    description: 'XML layout for Task List screen with header, summary card, empty state, and FAB.',
    content: `<!-- Task List Screen XML Layout for TaskNest -->
<androidx.coordinatorlayout.widget.CoordinatorLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent">
    <!-- Coordinator layout with RecyclerView and FloatingActionButton -->
</androidx.coordinatorlayout.widget.CoordinatorLayout>`
  },
  {
    path: 'OIBSIP/Task2_ToDoAppWithLogin/app/src/main/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    category: 'config',
    language: 'xml',
    description: 'Android Manifest declaring LoginActivity as Launcher and registered Activities.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:label="@string/app_name"
        android:icon="@drawable/ic_tasknest_logo"
        android:theme="@style/Theme.TaskNest">
        <activity android:name=".LoginActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <activity android:name=".RegisterActivity" android:exported="false" />
        <activity android:name=".TaskListActivity" android:exported="false" />
    </application>
</manifest>`
  },
  {
    path: 'OIBSIP/Task2_ToDoAppWithLogin/app/build.gradle',
    name: 'app/build.gradle',
    category: 'config',
    language: 'groovy',
    description: 'Gradle configuration for app module specifying minSdk 24, targetSdk 34, Java 17.',
    content: `plugins {
    id 'com.android.application'
}
android {
    namespace 'com.nehaborkar.tasknest'
    compileSdk 34
    defaultConfig {
        applicationId "com.nehaborkar.tasknest"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
    }
}
dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.recyclerview:recyclerview:1.3.2'
    testImplementation 'junit:junit:4.13.2'
}`
  },
  {
    path: 'OIBSIP/Task2_ToDoAppWithLogin/README.md',
    name: 'README.md',
    category: 'doc',
    language: 'markdown',
    description: 'Comprehensive documentation with schema, setup steps, security explanation, and testing checklist.',
    content: `# TaskNest — Android To-Do App with Login
Oasis Infobyte Internship Task 2 by Neha Vinod Borkar.`
  }
];
