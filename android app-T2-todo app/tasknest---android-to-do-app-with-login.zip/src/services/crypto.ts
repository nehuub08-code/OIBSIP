/**
 * Cryptographic utility mirroring PasswordUtils.java
 * Uses Web Crypto API:
 * - PBKDF2 with HMAC-SHA256
 * - 10,000 iterations
 * - 256-bit (32 bytes) key length
 * - 16-byte cryptographically secure random salt
 * - Constant-time comparison
 */

export const PBKDF2_ITERATIONS = 10000;
export const SALT_BYTE_LENGTH = 16;
export const KEY_LENGTH_BITS = 256;

export function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

export function hexToBytes(hex: string): Uint8Array {
  if (hex.length % 2 !== 0) throw new Error('Invalid hex string');
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.slice(i, i + 2), 16);
  }
  return bytes;
}

export function generateSalt(): Uint8Array {
  const salt = new Uint8Array(SALT_BYTE_LENGTH);
  window.crypto.getRandomValues(salt);
  return salt;
}

export async function hashPassword(password: string, salt: Uint8Array): Promise<string> {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );

  const derivedBits = await window.crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: salt as unknown as BufferSource,
      iterations: PBKDF2_ITERATIONS,
      hash: 'SHA-256',
    },
    keyMaterial,
    KEY_LENGTH_BITS
  );

  return bytesToHex(new Uint8Array(derivedBits));
}

export async function verifyPassword(
  submittedPassword: string,
  storedSaltHex: string,
  storedHashHex: string
): Promise<boolean> {
  try {
    const salt = hexToBytes(storedSaltHex);
    const computedHashHex = await hashPassword(submittedPassword, salt);

    // Constant-time comparison
    if (computedHashHex.length !== storedHashHex.length) return false;
    let diff = 0;
    for (let i = 0; i < computedHashHex.length; i++) {
      diff |= computedHashHex.charCodeAt(i) ^ storedHashHex.charCodeAt(i);
    }
    return diff === 0;
  } catch {
    return false;
  }
}
