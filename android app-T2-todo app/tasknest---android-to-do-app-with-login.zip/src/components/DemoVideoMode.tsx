import React, { useState, useEffect } from 'react';
import { Video, Play, Pause, RotateCcw, CheckCircle2, ChevronRight, Sparkles, User, Award } from 'lucide-react';

const DEMO_STEPS = [
  {
    step: 1,
    title: 'Registering a New Account',
    description: 'Enter Full Name, Email, Password, and Confirm Password. Demonstrates input validation, duplicate email check, and PBKDF2 hash generation.',
  },
  {
    step: 2,
    title: 'Logging In',
    description: 'Verify entered credentials against the stored PBKDF2 hash & salt in SQLite. Displays welcome greeting and opens TaskListActivity.',
  },
  {
    step: 3,
    title: 'Adding Tasks',
    description: 'Tap Add Task (+), enter required title and optional notes. Task is inserted into SQLite linked to user_id.',
  },
  {
    step: 4,
    title: 'Marking a Task Complete',
    description: 'Toggle checkbox. Demonstrates real-time SQLite update (is_completed = 1) and dynamic strikethrough styling.',
  },
  {
    step: 5,
    title: 'Deleting a Task',
    description: 'Tap delete icon. Displays confirmation dialog, then permanently removes record from SQLite tasks table.',
  },
  {
    step: 6,
    title: 'Closing and Reopening the App (Persistence)',
    description: 'Simulate app restart. Demonstrates session restoration and persistence of SQLite database records.',
  },
  {
    step: 7,
    title: 'Logging Out',
    description: 'Confirm logout in dialog. Clears SharedPreferences session and back-stack so Back button cannot reopen authenticated screen.',
  },
  {
    step: 8,
    title: 'Logging In with Second Account (User Isolation)',
    description: 'Sign in as second user (e.g. Rahul Sharma). Demonstrates that User 1 tasks are completely hidden and isolated!',
  },
];

export const DemoVideoMode: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [showTitleCard, setShowTitleCard] = useState(true);
  const [timerSeconds, setTimerSeconds] = useState(2);

  useEffect(() => {
    if (showTitleCard && timerSeconds > 0) {
      const t = setTimeout(() => {
        setTimerSeconds((prev) => prev - 1);
      }, 1000);
      return () => clearTimeout(t);
    }
  }, [showTitleCard, timerSeconds]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-5 border border-gray-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-[#6C5CE7] flex items-center justify-center">
              <Video className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-gray-900">Internship Demo Video Guide & Title Card</h2>
              <p className="text-xs text-gray-500">
                Official presentation requirements matching Section 19 of the Oasis Infobyte brief
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              setShowTitleCard(true);
              setTimerSeconds(2);
            }}
            className="px-3.5 py-1.5 text-xs font-semibold bg-indigo-50 text-[#6C5CE7] hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Show Title Frame (2+ sec)</span>
          </button>
        </div>
      </div>

      {/* Mandatory First-Frame Title Card Display */}
      {showTitleCard && (
        <div className="relative overflow-hidden bg-gradient-to-br from-[#1E2238] via-[#2A1B4E] to-[#111322] rounded-3xl p-8 text-white shadow-2xl border border-indigo-500/30">
          <div className="absolute top-4 right-4 flex items-center gap-2">
            <span className="text-xs bg-indigo-500/20 text-indigo-300 font-mono px-3 py-1 rounded-full border border-indigo-500/40">
              {timerSeconds > 0 ? `Displaying Frame: ${timerSeconds}s remaining` : '✓ 2-second Requirement Satisfied'}
            </span>
            <button
              type="button"
              onClick={() => setShowTitleCard(false)}
              className="text-gray-400 hover:text-white text-xs px-2 py-1 rounded-md bg-white/10"
            >
              Close
            </button>
          </div>

          <div className="max-w-xl mx-auto text-center space-y-4 py-4">
            <div className="inline-flex items-center gap-2 bg-[#6C5CE7]/20 border border-[#6C5CE7]/40 px-3 py-1 rounded-full text-indigo-300 text-xs font-semibold">
              <Award className="w-4 h-4 text-[#00B894]" />
              <span>Oasis Infobyte Internship Program (OIBSIP)</span>
            </div>

            <div className="space-y-1">
              <h1 className="text-3xl font-extrabold tracking-tight bg-gradient-to-r from-white via-indigo-100 to-indigo-300 bg-clip-text text-transparent">
                TaskNest — To-Do App with Login
              </h1>
              <p className="text-sm text-indigo-200">Task 2 Demonstration Video</p>
            </div>

            <div className="mt-6 bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10 text-left space-y-2.5 max-w-md mx-auto">
              <div className="flex justify-between items-center text-sm border-b border-white/10 pb-2">
                <span className="text-gray-400">Full Name:</span>
                <span className="font-bold text-white text-base">Neha Vinod Borkar</span>
              </div>
              <div className="flex justify-between items-center text-sm border-b border-white/10 pb-2">
                <span className="text-gray-400">Assigned Track:</span>
                <span className="font-semibold text-indigo-300">Android App Development</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-400">Task Title:</span>
                <span className="font-semibold text-emerald-400">Task 2 — To-Do App with Login</span>
              </div>
            </div>

            <p className="text-xs text-gray-400 pt-2">
              Technology Stack: Java • XML Layouts • SQLite Database • PBKDF2 Hashing
            </p>
          </div>
        </div>
      )}

      {/* 8-Step Video Demonstration Script */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-xs">
        <h3 className="text-sm font-bold text-gray-900 mb-4 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#6C5CE7]" />
          <span>Step-by-Step Recording Walkthrough (Demonstrate in this order):</span>
        </h3>

        <div className="space-y-3">
          {DEMO_STEPS.map((step, idx) => {
            const isCurrent = activeStep === idx;
            return (
              <div
                key={step.step}
                onClick={() => setActiveStep(idx)}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  isCurrent
                    ? 'bg-indigo-50/50 border-[#6C5CE7] shadow-xs'
                    : 'bg-white border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                      isCurrent
                        ? 'bg-[#6C5CE7] text-white shadow-sm'
                        : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {step.step}
                  </div>
                  <div className="flex-1">
                    <h4 className="text-xs font-bold text-gray-900 flex items-center justify-between">
                      <span>{step.title}</span>
                      {isCurrent && (
                        <span className="text-[10px] bg-indigo-100 text-[#6C5CE7] font-semibold px-2 py-0.5 rounded-full">
                          Current Demo Step
                        </span>
                      )}
                    </h4>
                    <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
