import React, { useState, useEffect } from 'react';
import { DatabaseHelperService, SessionManagerService, subscribeToDb } from '../../services/db';
import { TaskRecord, SessionData } from '../../types';
import {
  LogOut,
  Plus,
  Trash2,
  CheckCircle2,
  Circle,
  Calendar,
  AlertTriangle,
  X,
  FileText,
  Sparkles,
} from 'lucide-react';

interface TaskListScreenProps {
  onLogout: () => void;
}

export const TaskListScreen: React.FC<TaskListScreenProps> = ({ onLogout }) => {
  const [session, setSession] = useState<SessionData>(SessionManagerService.getSession());
  const [tasks, setTasks] = useState<TaskRecord[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [taskTitle, setTaskTitle] = useState('');
  const [taskNotes, setTaskNotes] = useState('');
  const [titleError, setTitleError] = useState('');
  const [taskToDelete, setTaskToDelete] = useState<TaskRecord | null>(null);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [feedbackToast, setFeedbackToast] = useState<string | null>(null);

  const loadTasks = () => {
    const curSession = SessionManagerService.getSession();
    setSession(curSession);
    if (curSession.userId > 0) {
      const userTasks = DatabaseHelperService.getTasksForUser(curSession.userId);
      setTasks(userTasks);
    }
  };

  useEffect(() => {
    loadTasks();
    const unsubscribe = subscribeToDb(() => {
      loadTasks();
    });
    return unsubscribe;
  }, []);

  const showToast = (msg: string) => {
    setFeedbackToast(msg);
    setTimeout(() => {
      setFeedbackToast(null);
    }, 2400);
  };

  // Toggle completion
  const handleToggleComplete = (task: TaskRecord) => {
    const nextState = task.is_completed === 1 ? false : true;
    const success = DatabaseHelperService.updateTaskCompletion(task.id, session.userId, nextState);
    if (success) {
      showToast(nextState ? 'Task marked complete! 🎉' : 'Task marked incomplete.');
    }
  };

  // Confirm delete
  const handleDeleteTask = () => {
    if (!taskToDelete) return;
    const success = DatabaseHelperService.deleteTask(taskToDelete.id, session.userId);
    if (success) {
      showToast('Task permanently deleted.');
    }
    setTaskToDelete(null);
  };

  // Create new task
  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanTitle = taskTitle.trim();
    if (!cleanTitle) {
      setTitleError('Task name cannot be empty.');
      return;
    }

    const newTask = DatabaseHelperService.insertTask(session.userId, cleanTitle, taskNotes);
    if (newTask) {
      setTaskTitle('');
      setTaskNotes('');
      setTitleError('');
      setShowAddModal(false);
      showToast('Task created successfully!');
    }
  };

  const completedCount = tasks.filter((t) => t.is_completed === 1).length;
  const totalCount = tasks.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return (
    <div className="relative h-full flex flex-col bg-[#F8F9FE] text-[#1E2238] select-none font-sans overflow-hidden">
      {/* Toast Notification */}
      {feedbackToast && (
        <div className="absolute top-14 left-4 right-4 z-50 bg-[#1E2238] text-white text-xs px-3.5 py-2.5 rounded-xl shadow-lg flex items-center justify-between animate-fade-in">
          <span>{feedbackToast}</span>
          <CheckCircle2 className="w-3.5 h-3.5 text-[#00B894]" />
        </div>
      )}

      {/* Header Bar */}
      <div className="bg-white px-5 pt-4 pb-3 border-b border-[#ECEEF6] flex items-center justify-between shrink-0">
        <div>
          <h2 className="text-base font-bold text-[#1E2238] flex items-center gap-1.5">
            Hello, {session.userName.split(' ')[0] || 'User'} 👋
          </h2>
          <p className="text-[11px] text-[#636B83] truncate max-w-[210px]">{session.userEmail}</p>
        </div>

        <button
          type="button"
          onClick={() => setShowLogoutConfirm(true)}
          className="w-8 h-8 rounded-full bg-gray-50 border border-gray-200 flex items-center justify-center text-gray-500 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
          title="Logout"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5 pb-20">
        {/* Progress Summary Card */}
        <div className="bg-gradient-to-br from-[#EEF0FD] to-[#E6F9F5] rounded-2xl p-4 border border-[#E4E7F4]">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#6C5CE7]">
                My Tasks
              </span>
              <p className="text-xs text-[#1E2238] font-semibold mt-0.5">
                {totalCount > 0 ? `${completedCount} of ${totalCount} completed` : 'No active tasks'}
              </p>
            </div>
            <div className="text-right">
              <span className="text-lg font-extrabold text-[#1E2238]">{progressPercent}%</span>
            </div>
          </div>

          <div className="w-full h-2 bg-white/70 rounded-full mt-2.5 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#6C5CE7] to-[#00B894] transition-all duration-300 rounded-full"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Task List or Empty State */}
        {tasks.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-center p-6 bg-white rounded-2xl border border-[#E4E7F4] mt-2">
            <div className="w-16 h-16 rounded-2xl bg-indigo-50 flex items-center justify-center text-[#6C5CE7] mb-3">
              <Sparkles className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-[#1E2238]">No tasks yet</h3>
            <p className="text-xs text-[#636B83] mt-1 max-w-[200px]">
              Add your first task and make today productive!
            </p>
            <button
              type="button"
              onClick={() => setShowAddModal(true)}
              className="mt-4 px-4 py-2 rounded-xl bg-gradient-to-r from-[#6C5CE7] to-[#0984E3] text-white text-xs font-bold shadow-md shadow-indigo-100 hover:opacity-95 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Your First Task</span>
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {tasks.map((task) => {
              const isDone = task.is_completed === 1;
              return (
                <div
                  key={task.id}
                  className={`group bg-white rounded-xl p-3 border transition-all ${
                    isDone
                      ? 'border-[#ECEEF6] bg-gray-50/50 opacity-80'
                      : 'border-[#E4E7F4] shadow-xs hover:border-[#6C5CE7]/30'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    {/* Checkbox */}
                    <button
                      type="button"
                      onClick={() => handleToggleComplete(task)}
                      className="mt-0.5 text-gray-400 hover:text-[#6C5CE7] transition-colors cursor-pointer shrink-0"
                    >
                      {isDone ? (
                        <CheckCircle2 className="w-5 h-5 text-[#00B894] fill-[#00B894]/15" />
                      ) : (
                        <Circle className="w-5 h-5 hover:stroke-[#6C5CE7]" />
                      )}
                    </button>

                    {/* Task Title & Notes */}
                    <div className="flex-1 min-w-0">
                      <p
                        className={`text-xs font-bold leading-snug transition-all ${
                          isDone
                            ? 'line-through text-gray-400 font-medium'
                            : 'text-[#1E2238]'
                        }`}
                      >
                        {task.title}
                      </p>

                      {task.notes && (
                        <p
                          className={`text-[11px] mt-1 leading-normal ${
                            isDone ? 'line-through text-gray-400' : 'text-[#636B83]'
                          }`}
                        >
                          {task.notes}
                        </p>
                      )}

                      <div className="flex items-center gap-1 text-[9px] text-gray-400 mt-1.5 font-medium">
                        <Calendar className="w-2.5 h-2.5" />
                        <span>{task.created_at}</span>
                      </div>
                    </div>

                    {/* Delete Action */}
                    <button
                      type="button"
                      onClick={() => setTaskToDelete(task)}
                      className="text-gray-300 hover:text-red-500 p-1 rounded-lg hover:bg-red-50 transition-colors cursor-pointer shrink-0"
                      title="Delete task"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Floating Add Task Button */}
      <div className="absolute bottom-5 right-5 z-20">
        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#6C5CE7] to-[#0984E3] text-white flex items-center justify-center shadow-lg shadow-indigo-300 hover:scale-105 active:scale-95 transition-all cursor-pointer"
          title="Add New Task"
        >
          <Plus className="w-6 h-6 stroke-[2.5]" />
        </button>
      </div>

      {/* Add Task Modal Dialog */}
      {showAddModal && (
        <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl w-full max-w-[290px] p-5 shadow-2xl border border-gray-100 animate-scale-up">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-[#1E2238]">Create New Task</h3>
              <button
                type="button"
                onClick={() => {
                  setShowAddModal(false);
                  setTitleError('');
                }}
                className="text-gray-400 hover:text-gray-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-[#1E2238] mb-1">
                  Task Title *
                </label>
                <input
                  type="text"
                  value={taskTitle}
                  onChange={(e) => {
                    setTaskTitle(e.target.value);
                    if (titleError) setTitleError('');
                  }}
                  placeholder="What needs to be done?"
                  className="w-full px-3 py-2 text-xs border border-[#ECEEF6] rounded-xl focus:outline-none focus:border-[#6C5CE7]"
                  autoFocus
                />
                {titleError && (
                  <p className="text-[10px] text-red-500 mt-1 font-medium">{titleError}</p>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#636B83] mb-1">
                  Notes (Optional)
                </label>
                <textarea
                  value={taskNotes}
                  onChange={(e) => setTaskNotes(e.target.value)}
                  placeholder="Add additional instructions or remarks..."
                  rows={2}
                  className="w-full px-3 py-2 text-xs border border-[#ECEEF6] rounded-xl focus:outline-none focus:border-[#6C5CE7] resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setTitleError('');
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-gray-500 hover:bg-gray-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-bold text-white bg-gradient-to-r from-[#6C5CE7] to-[#0984E3] rounded-lg shadow-sm hover:opacity-95 active:scale-95 cursor-pointer"
                >
                  Save Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      {taskToDelete && (
        <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-[280px] p-5 shadow-2xl border border-gray-100 text-center">
            <div className="w-10 h-10 rounded-full bg-red-50 text-red-500 mx-auto flex items-center justify-center mb-3">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-[#1E2238]">Delete Task?</h3>
            <p className="text-xs text-[#636B83] mt-1 leading-relaxed">
              Are you sure you want to permanently delete "{taskToDelete.title}"? This cannot be undone.
            </p>
            <div className="flex items-center justify-center gap-2 mt-4">
              <button
                type="button"
                onClick={() => setTaskToDelete(null)}
                className="px-3.5 py-1.5 text-xs font-semibold text-gray-500 hover:bg-gray-100 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteTask}
                className="px-4 py-1.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-sm cursor-pointer"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Logout Confirmation Dialog */}
      {showLogoutConfirm && (
        <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-[280px] p-5 shadow-2xl border border-gray-100 text-center">
            <div className="w-10 h-10 rounded-full bg-indigo-50 text-[#6C5CE7] mx-auto flex items-center justify-center mb-3">
              <LogOut className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-[#1E2238]">Log Out?</h3>
            <p className="text-xs text-[#636B83] mt-1 leading-relaxed">
              Are you sure you want to log out of TaskNest? Your local tasks will remain saved in SQLite.
            </p>
            <div className="flex items-center justify-center gap-2 mt-4">
              <button
                type="button"
                onClick={() => setShowLogoutConfirm(false)}
                className="px-3.5 py-1.5 text-xs font-semibold text-gray-500 hover:bg-gray-100 rounded-lg cursor-pointer"
              >
                Stay
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowLogoutConfirm(false);
                  SessionManagerService.clearSession();
                  onLogout();
                }}
                className="px-4 py-1.5 text-xs font-bold text-white bg-[#6C5CE7] hover:bg-[#5843E0] rounded-lg shadow-sm cursor-pointer"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
