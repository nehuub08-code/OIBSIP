import React, { useState } from 'react';
import { DatabaseHelperService } from '../../services/db';
import { User, Mail, Lock, CheckCircle2, ArrowLeft, ShieldCheck } from 'lucide-react';

interface RegisterScreenProps {
  onNavigateToLogin: () => void;
  onRegisterSuccess: (registeredEmail: string) => void;
}

export const RegisterScreen: React.FC<RegisterScreenProps> = ({
  onNavigateToLogin,
  onRegisterSuccess,
}) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    // 1. Name validation
    if (!fullName.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }

    // 2. Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.trim() || !emailRegex.test(email.trim())) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }

    // 3. Password length validation
    if (!password || password.length < 8) {
      setErrorMessage('Password must be at least 8 characters long.');
      return;
    }

    // 4. Confirm password match
    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }

    // 5. Duplicate email check in SQLite
    if (DatabaseHelperService.isEmailRegistered(email)) {
      setErrorMessage('An account with this email already exists.');
      return;
    }

    setIsLoading(true);
    try {
      // 6. Secure registration with PBKDF2 and random salt
      const user = await DatabaseHelperService.registerUser(fullName, email, password);
      if (user) {
        setSuccessMessage('Account registered successfully! Redirecting to login...');
        setTimeout(() => {
          onRegisterSuccess(email);
        }, 1200);
      } else {
        setErrorMessage('Failed to register account.');
      }
    } catch {
      setErrorMessage('An error occurred during registration.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-full flex flex-col justify-between p-6 bg-[#F8F9FE] text-[#1E2238] select-none font-sans">
      <div>
        {/* Top Header with Back Arrow */}
        <div className="flex items-center gap-2 mt-2">
          <button
            type="button"
            onClick={onNavigateToLogin}
            className="w-8 h-8 rounded-full bg-white border border-[#E4E7F4] flex items-center justify-center text-gray-600 hover:bg-gray-50 active:scale-95 transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-[#1E2238]">Join TaskNest</h1>
            <p className="text-[11px] text-[#636B83]">Create a private account to protect your to-dos</p>
          </div>
        </div>

        {/* Register Card */}
        <div className="mt-5 bg-white rounded-2xl p-5 shadow-sm border border-[#E4E7F4]">
          {errorMessage && (
            <div className="mb-3.5 p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-600 text-xs font-medium flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0"></span>
              {errorMessage}
            </div>
          )}

          {successMessage && (
            <div className="mb-3.5 p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-[#00B894] text-xs font-medium flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#00B894] shrink-0" />
              {successMessage}
            </div>
          )}

          <form onSubmit={handleRegister} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-[#1E2238] mb-1">Full Name</label>
              <div className="relative">
                <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Neha Borkar"
                  className="w-full pl-10 pr-3.5 py-2 text-xs bg-white border border-[#ECEEF6] rounded-xl focus:outline-none focus:border-[#6C5CE7] focus:ring-2 focus:ring-[#6C5CE7]/15 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#1E2238] mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-3.5 py-2 text-xs bg-white border border-[#ECEEF6] rounded-xl focus:outline-none focus:border-[#6C5CE7] focus:ring-2 focus:ring-[#6C5CE7]/15 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#1E2238] mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min. 8 characters"
                  className="w-full pl-10 pr-3.5 py-2 text-xs bg-white border border-[#ECEEF6] rounded-xl focus:outline-none focus:border-[#6C5CE7] focus:ring-2 focus:ring-[#6C5CE7]/15 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#1E2238] mb-1">Confirm Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter password"
                  className="w-full pl-10 pr-3.5 py-2 text-xs bg-white border border-[#ECEEF6] rounded-xl focus:outline-none focus:border-[#6C5CE7] focus:ring-2 focus:ring-[#6C5CE7]/15 transition-all"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-2 py-3 px-4 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-[#6C5CE7] to-[#0984E3] hover:opacity-95 active:scale-[0.99] transition-all shadow-md shadow-indigo-200 flex items-center justify-center gap-2 cursor-pointer"
            >
              {isLoading ? 'Deriving PBKDF2 Hash...' : 'Create Account'}
            </button>
          </form>

          {/* Back to Login link */}
          <div className="mt-4 text-center text-xs text-[#636B83]">
            <span>Already have an account? </span>
            <button
              type="button"
              onClick={onNavigateToLogin}
              className="font-bold text-[#6C5CE7] hover:underline cursor-pointer"
            >
              Sign In
            </button>
          </div>
        </div>
      </div>

      {/* Security notice */}
      <div className="mt-4 text-center text-[10px] text-gray-400 flex items-center justify-center gap-1">
        <ShieldCheck className="w-3.5 h-3.5 text-[#00B894]" />
        <span>16-byte cryptographic salt + PBKDF2 (10k iterations)</span>
      </div>
    </div>
  );
};
