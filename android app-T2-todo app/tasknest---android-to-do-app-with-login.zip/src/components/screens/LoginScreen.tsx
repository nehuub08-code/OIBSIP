import React, { useState } from 'react';
import { DatabaseHelperService, SessionManagerService } from '../../services/db';
import { Lock, Mail, CheckCircle2, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';

interface LoginScreenProps {
  onNavigateToRegister: () => void;
  onLoginSuccess: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onNavigateToRegister,
  onLoginSuccess,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage('');

    if (!email.trim() || !password) {
      setErrorMessage('Please enter both email and password.');
      return;
    }

    setIsLoading(true);
    try {
      const user = await DatabaseHelperService.authenticateUser(email, password);
      if (user) {
        SessionManagerService.setSession(user);
        onLoginSuccess();
      } else {
        // Generic error message without revealing if email exists
        setErrorMessage('Invalid email or password. Please try again.');
      }
    } catch (err) {
      setErrorMessage('Authentication error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickLogin = (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
    setErrorMessage('');
  };

  return (
    <div className="min-h-full flex flex-col justify-between p-6 bg-[#F8F9FE] text-[#1E2238] select-none font-sans">
      <div>
        {/* Top Branding */}
        <div className="flex flex-col items-center mt-4 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#6C5CE7] to-[#0984E3] flex items-center justify-center shadow-lg shadow-indigo-200">
            <CheckCircle2 className="w-9 h-9 text-white stroke-[2.5]" />
          </div>
          <h1 className="mt-3 text-2xl font-bold tracking-tight text-[#1E2238]">TaskNest</h1>
          <p className="text-xs text-[#636B83] mt-0.5 font-medium">Organize effortlessly, achieve daily.</p>
        </div>

        {/* Login Card */}
        <div className="mt-6 bg-white rounded-2xl p-5 shadow-sm border border-[#E4E7F4]">
          <div className="mb-4">
            <h2 className="text-lg font-bold text-[#1E2238]">Welcome Back</h2>
            <p className="text-xs text-[#636B83]">Sign in to manage your daily tasks</p>
          </div>

          {errorMessage && (
            <div className="mb-4 p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-600 text-xs font-medium flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0"></span>
              {errorMessage}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-[#1E2238] mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-white border border-[#ECEEF6] rounded-xl focus:outline-none focus:border-[#6C5CE7] focus:ring-2 focus:ring-[#6C5CE7]/15 transition-all"
                  autoComplete="email"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#1E2238] mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-white border border-[#ECEEF6] rounded-xl focus:outline-none focus:border-[#6C5CE7] focus:ring-2 focus:ring-[#6C5CE7]/15 transition-all"
                  autoComplete="current-password"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-2 py-3 px-4 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-[#6C5CE7] to-[#0984E3] hover:opacity-95 active:scale-[0.99] transition-all shadow-md shadow-indigo-200 flex items-center justify-center gap-2 cursor-pointer"
            >
              {isLoading ? (
                <span>Verifying Hash...</span>
              ) : (
                <>
                  <span>Sign In</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Pre-fill Pills */}
          <div className="mt-4 pt-3 border-t border-gray-100">
            <p className="text-[10px] text-gray-400 mb-1.5 font-medium flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#6C5CE7]" /> Quick autofill accounts:
            </p>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => handleQuickLogin('neha@example.com', 'NehaBorkar@2026')}
                className="text-[10px] py-1 px-2 text-left bg-indigo-50/70 hover:bg-indigo-100 text-[#6C5CE7] rounded-lg font-medium transition-colors truncate"
                title="Neha Vinod Borkar (Intern)"
              >
                👤 Neha Borkar
              </button>
              <button
                type="button"
                onClick={() => handleQuickLogin('rahul@example.com', 'TestingPass123')}
                className="text-[10px] py-1 px-2 text-left bg-blue-50/70 hover:bg-blue-100 text-[#0984E3] rounded-lg font-medium transition-colors truncate"
                title="Rahul Sharma (Second user to test isolation)"
              >
                👤 Rahul Sharma
              </button>
            </div>
          </div>

          {/* Register Link */}
          <div className="mt-4 text-center text-xs text-[#636B83]">
            <span>Don't have an account? </span>
            <button
              type="button"
              onClick={onNavigateToRegister}
              className="font-bold text-[#6C5CE7] hover:underline cursor-pointer"
            >
              Register here
            </button>
          </div>
        </div>
      </div>

      {/* Footer Details */}
      <div className="mt-6 text-center text-[10px] text-gray-400 space-y-1">
        <p className="font-semibold text-gray-500">Developed by Neha Vinod Borkar</p>
        <p>Oasis Infobyte Android App Development • Task 2</p>
        <div className="inline-flex items-center gap-1 text-[9px] text-[#00B894] bg-emerald-50 px-2 py-0.5 rounded-full font-medium">
          <ShieldCheck className="w-3 h-3" />
          <span>PBKDF2-HMAC-SHA256 • SQLite Local Storage</span>
        </div>
      </div>
    </div>
  );
};
