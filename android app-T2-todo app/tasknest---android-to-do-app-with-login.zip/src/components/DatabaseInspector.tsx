import React, { useState, useEffect } from 'react';
import { DatabaseHelperService, subscribeToDb } from '../services/db';
import { UserRecord, TaskRecord } from '../types';
import { Database, Key, ShieldCheck, RefreshCw, Trash2, CheckCircle2, User, Eye, EyeOff } from 'lucide-react';

export const DatabaseInspector: React.FC = () => {
  const [users, setUsers] = useState<UserRecord[]>([]);
  const [tasks, setTasks] = useState<TaskRecord[]>([]);
  const [selectedUserFilter, setSelectedUserFilter] = useState<number | 'all'>('all');
  const [revealedHashes, setRevealedHashes] = useState<Record<number, boolean>>({});

  const reloadData = () => {
    setUsers(DatabaseHelperService.getAllUsers());
    setTasks(DatabaseHelperService.getAllTasks());
  };

  useEffect(() => {
    reloadData();
    const unsub = subscribeToDb(reloadData);
    return unsub;
  }, []);

  const toggleHashReveal = (userId: number) => {
    setRevealedHashes((prev) => ({ ...prev, [userId]: !prev[userId] }));
  };

  const filteredTasks =
    selectedUserFilter === 'all'
      ? tasks
      : tasks.filter((t) => t.user_id === selectedUserFilter);

  return (
    <div className="space-y-6">
      {/* Top Banner & Control Bar */}
      <div className="bg-white rounded-2xl p-5 border border-gray-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-[#6C5CE7] flex items-center justify-center">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-gray-900">Live SQLite Database Inspector</h2>
              <p className="text-xs text-gray-500">
                Mirrors <code className="text-[#6C5CE7] font-semibold">tasknest.db</code> (SQLiteOpenHelper) in real time
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => DatabaseHelperService.seedDemoData()}
            className="px-3 py-1.5 text-xs font-semibold bg-indigo-50 text-[#6C5CE7] hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
            title="Populate test users and tasks for Neha Borkar and Rahul Sharma"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Seed Test Accounts</span>
          </button>
          <button
            type="button"
            onClick={() => DatabaseHelperService.clearDatabase()}
            className="px-3 py-1.5 text-xs font-semibold bg-red-50 text-red-600 hover:bg-red-100 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
            title="Wipe database to test empty states and first-time registration"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Wipe DB</span>
          </button>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-xs">
        <div className="px-5 py-3.5 bg-gray-50/70 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Key className="w-4 h-4 text-[#6C5CE7]" />
            <h3 className="text-sm font-bold text-gray-900">Table: users</h3>
            <span className="text-[11px] bg-indigo-100 text-[#6C5CE7] font-bold px-2 py-0.5 rounded-full">
              {users.length} {users.length === 1 ? 'record' : 'records'}
            </span>
          </div>
          <span className="text-[11px] text-emerald-600 font-semibold bg-emerald-50 px-2 py-0.5 rounded-md flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            PBKDF2-HMAC-SHA256 (Salted)
          </span>
        </div>

        <div className="overflow-x-auto">
          {users.length === 0 ? (
            <div className="p-8 text-center text-xs text-gray-400">
              No users registered yet. Register an account via the Android phone emulator above!
            </div>
          ) : (
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-gray-50 text-gray-500 font-semibold border-b border-gray-200">
                  <th className="py-2.5 px-4 w-12">id</th>
                  <th className="py-2.5 px-4">name</th>
                  <th className="py-2.5 px-4">email (UNIQUE)</th>
                  <th className="py-2.5 px-4">password_salt (16 bytes)</th>
                  <th className="py-2.5 px-4">password_hash (PBKDF2)</th>
                  <th className="py-2.5 px-4 w-32">created_at</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {users.map((u) => {
                  const isRevealed = !!revealedHashes[u.id];
                  return (
                    <tr key={u.id} className="hover:bg-gray-50/70">
                      <td className="py-2.5 px-4 font-mono font-bold text-[#6C5CE7]">{u.id}</td>
                      <td className="py-2.5 px-4 font-semibold text-gray-900 flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-gray-400" />
                        {u.name}
                      </td>
                      <td className="py-2.5 px-4 font-mono text-gray-700">{u.email}</td>
                      <td className="py-2.5 px-4 font-mono text-[11px] text-amber-700 max-w-[130px] truncate" title={u.password_salt}>
                        {u.password_salt}
                      </td>
                      <td className="py-2.5 px-4 font-mono text-[11px] text-gray-600 max-w-[200px]">
                        <div className="flex items-center gap-1.5">
                          <span className="truncate" title={u.password_hash}>
                            {isRevealed ? u.password_hash : `${u.password_hash.substring(0, 16)}••••••••`}
                          </span>
                          <button
                            type="button"
                            onClick={() => toggleHashReveal(u.id)}
                            className="text-gray-400 hover:text-gray-600 cursor-pointer shrink-0"
                          >
                            {isRevealed ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                          </button>
                        </div>
                      </td>
                      <td className="py-2.5 px-4 text-gray-400 text-[11px]">{u.created_at}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Tasks Table */}
      <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-xs">
        <div className="px-5 py-3.5 bg-gray-50/70 border-b border-gray-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-[#00B894]" />
            <h3 className="text-sm font-bold text-gray-900">Table: tasks</h3>
            <span className="text-[11px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
              {tasks.length} total
            </span>
          </div>

          {/* User isolation filter test */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500 font-medium">Filter by owner:</span>
            <div className="flex gap-1">
              <button
                type="button"
                onClick={() => setSelectedUserFilter('all')}
                className={`text-xs px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
                  selectedUserFilter === 'all'
                    ? 'bg-gray-900 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                All Users ({tasks.length})
              </button>
              {users.map((u) => (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => setSelectedUserFilter(u.id)}
                  className={`text-xs px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                    selectedUserFilter === u.id
                      ? 'bg-[#6C5CE7] text-white'
                      : 'bg-indigo-50 text-[#6C5CE7] hover:bg-indigo-100'
                  }`}
                >
                  <span>{u.name.split(' ')[0]}</span>
                  <span className="text-[10px] opacity-75">
                    ({tasks.filter((t) => t.user_id === u.id).length})
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          {filteredTasks.length === 0 ? (
            <div className="p-8 text-center text-xs text-gray-400">
              No tasks found in SQLite for this filter criteria.
            </div>
          ) : (
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-gray-50 text-gray-500 font-semibold border-b border-gray-200">
                  <th className="py-2.5 px-4 w-12">id</th>
                  <th className="py-2.5 px-4 w-28">user_id (FK)</th>
                  <th className="py-2.5 px-4">title</th>
                  <th className="py-2.5 px-4">notes</th>
                  <th className="py-2.5 px-4 w-28">is_completed</th>
                  <th className="py-2.5 px-4 w-28">created_at</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredTasks.map((t) => {
                  const owner = users.find((u) => u.id === t.user_id);
                  const isDone = t.is_completed === 1;
                  return (
                    <tr key={t.id} className="hover:bg-gray-50/70">
                      <td className="py-2.5 px-4 font-mono font-bold text-gray-500">{t.id}</td>
                      <td className="py-2.5 px-4">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md font-mono text-[11px] font-bold bg-indigo-50 text-[#6C5CE7]">
                          user #{t.user_id} {owner ? `(${owner.name.split(' ')[0]})` : ''}
                        </span>
                      </td>
                      <td className={`py-2.5 px-4 font-medium ${isDone ? 'line-through text-gray-400' : 'text-gray-900 font-semibold'}`}>
                        {t.title}
                      </td>
                      <td className={`py-2.5 px-4 text-gray-500 ${isDone ? 'line-through' : ''}`}>
                        {t.notes || <span className="text-gray-300 italic">none</span>}
                      </td>
                      <td className="py-2.5 px-4">
                        {isDone ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700">
                            <CheckCircle2 className="w-3 h-3" />
                            1 (Done)
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700">
                            0 (Pending)
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-4 text-gray-400 text-[11px]">{t.created_at}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
