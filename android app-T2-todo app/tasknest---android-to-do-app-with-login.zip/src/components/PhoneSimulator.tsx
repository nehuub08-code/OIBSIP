import React, { useState, useEffect } from 'react';
import { SessionManagerService, DatabaseHelperService, subscribeToDb } from '../services/db';
import { SessionData } from '../types';
import { LoginScreen } from './screens/LoginScreen';
import { RegisterScreen } from './screens/RegisterScreen';
import { TaskListScreen } from './screens/TaskListScreen';
import { Wifi, BatteryMedium, Signal, RefreshCw, Power } from 'lucide-react';

interface PhoneSimulatorProps {
  onStateChange?: () => void;
}

export const PhoneSimulator: React.FC<PhoneSimulatorProps> = ({ onStateChange }) => {
  const [currentScreen, setCurrentScreen] = useState<'login' | 'register' | 'task_list'>('login');
  const [currentTime, setCurrentTime] = useState('12:18');
  const [isAppRestarting, setIsAppRestarting] = useState(false);

  // Sync session state on load
  const syncWithSession = () => {
    const session: SessionData = SessionManagerService.getSession();
    if (session.isLoggedIn && session.userId > 0) {
      setCurrentScreen('task_list');
    } else {
      setCurrentScreen('login');
    }
  };

  useEffect(() => {
    syncWithSession();
    const unsub = subscribeToDb(() => {
      syncWithSession();
      if (onStateChange) onStateChange();
    });
    return unsub;
  }, []);

  // Time ticker
  useEffect(() => {
    const update = () => {
      const d = new Date();
      const h = d.getHours().toString().padStart(2, '0');
      const m = d.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${h}:${m}`);
    };
    update();
    const interval = setInterval(update, 30000);
    return () => clearInterval(interval);
  }, []);

  // Hardware Back Button Simulator
  const handleHardwareBack = () => {
    if (currentScreen === 'register') {
      setCurrentScreen('login');
    } else if (currentScreen === 'task_list') {
      // In Android, back stack is cleared on login; back button does NOT reopen login screen
      // It minimizes/exits app. We can flash a toast or restart.
    }
  };

  // Hardware Home / Force Close & Reopen Simulator
  const handleSimulateAppRelaunch = () => {
    setIsAppRestarting(true);
    setTimeout(() => {
      syncWithSession();
      setIsAppRestarting(false);
    }, 400);
  };

  return (
    <div className="flex flex-col items-center">
      {/* Device Toolbar Controls */}
      <div className="mb-3 flex items-center gap-2">
        <span className="text-xs font-semibold text-gray-500 bg-gray-100 px-2.5 py-1 rounded-lg">
          Google Pixel 8 • Android 14 (API 34)
        </span>
        <button
          type="button"
          onClick={handleSimulateAppRelaunch}
          className="text-xs flex items-center gap-1.5 px-3 py-1 bg-white border border-gray-200 rounded-lg text-gray-700 hover:bg-gray-50 active:scale-95 transition-all shadow-xs cursor-pointer font-medium"
          title="Simulate killing process and relaunching app to verify persistence"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-[#6C5CE7] ${isAppRestarting ? 'animate-spin' : ''}`} />
          <span>Restart App (Test Persistence)</span>
        </button>
      </div>

      {/* Smartphone Chassis Frame */}
      <div className="relative w-[360px] h-[720px] bg-neutral-900 rounded-[48px] p-3 shadow-2xl shadow-indigo-950/20 border-4 border-neutral-700/80 ring-1 ring-black/40">
        {/* Device Volume / Power Buttons */}
        <div className="absolute -left-4.5 top-28 w-1 h-12 bg-neutral-700 rounded-l-md"></div>
        <div className="absolute -left-4.5 top-44 w-1 h-12 bg-neutral-700 rounded-l-md"></div>
        <div className="absolute -right-4.5 top-32 w-1 h-14 bg-neutral-700 rounded-r-md"></div>

        {/* Screen Bezel Area */}
        <div className="relative w-full h-full bg-[#F8F9FE] rounded-[38px] overflow-hidden flex flex-col border border-neutral-800">
          {/* Android Status Bar */}
          <div className="h-7 px-5 bg-white/90 backdrop-blur-xs flex items-center justify-between text-[11px] font-bold text-gray-800 shrink-0 z-30 select-none">
            <span>{currentTime}</span>

            {/* Camera Punch-hole Notch */}
            <div className="w-3.5 h-3.5 bg-black rounded-full border border-neutral-800"></div>

            <div className="flex items-center gap-1.5 text-gray-700">
              <Signal className="w-3 h-3" />
              <Wifi className="w-3 h-3" />
              <BatteryMedium className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Active Screen Content */}
          <div className="flex-1 overflow-hidden relative">
            {isAppRestarting ? (
              <div className="h-full flex flex-col items-center justify-center bg-[#F8F9FE]">
                <div className="w-12 h-12 rounded-2xl bg-[#6C5CE7] flex items-center justify-center animate-pulse shadow-lg shadow-indigo-200">
                  <span className="text-white text-lg font-bold">TN</span>
                </div>
                <p className="text-xs text-gray-500 font-semibold mt-3">Restoring SQLite session...</p>
              </div>
            ) : currentScreen === 'login' ? (
              <LoginScreen
                onNavigateToRegister={() => setCurrentScreen('register')}
                onLoginSuccess={() => setCurrentScreen('task_list')}
              />
            ) : currentScreen === 'register' ? (
              <RegisterScreen
                onNavigateToLogin={() => setCurrentScreen('login')}
                onRegisterSuccess={() => setCurrentScreen('login')}
              />
            ) : (
              <TaskListScreen onLogout={() => setCurrentScreen('login')} />
            )}
          </div>

          {/* Android 3-Button Navigation Bar */}
          <div className="h-9 bg-neutral-900 flex items-center justify-around px-8 shrink-0 z-30 select-none">
            {/* Back Button */}
            <button
              type="button"
              onClick={handleHardwareBack}
              className="text-gray-400 hover:text-white active:scale-90 transition-all p-1 cursor-pointer"
              title="Android Back Button"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" />
              </svg>
            </button>

            {/* Home Button */}
            <button
              type="button"
              onClick={handleSimulateAppRelaunch}
              className="w-3.5 h-3.5 rounded-full border-2 border-gray-400 hover:border-white active:scale-90 transition-all cursor-pointer"
              title="Android Home Button"
            />

            {/* Recents Button */}
            <button
              type="button"
              onClick={handleSimulateAppRelaunch}
              className="w-3.5 h-3.5 rounded-xs border-2 border-gray-400 hover:border-white active:scale-90 transition-all cursor-pointer"
              title="Android Recents Button"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
