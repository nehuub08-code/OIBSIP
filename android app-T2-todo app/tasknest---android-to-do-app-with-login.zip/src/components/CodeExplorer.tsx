import React, { useState } from 'react';
import { PROJECT_FILES, ProjectFileEntry } from '../services/projectFiles';
import { FileCode, Download, Copy, Check, Folder, Layers, BookOpen, ExternalLink, Sparkles } from 'lucide-react';
import JSZip from 'jszip';

export const CodeExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<ProjectFileEntry>(PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();

      // Add all project files into the zip with their exact path structure
      for (const file of PROJECT_FILES) {
        zip.file(file.path, file.content);
      }

      // Add root settings.gradle and gradle.properties
      zip.file('OIBSIP/Task2_ToDoAppWithLogin/settings.gradle', `rootProject.name = "TaskNest"\ninclude ':app'\n`);
      zip.file('OIBSIP/Task2_ToDoAppWithLogin/gradle.properties', `org.gradle.jvmargs=-Xmx2048m\nandroid.useAndroidX=true\nandroid.nonTransitiveRClass=true\n`);

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'TaskNest-OIBSIP-NehaVinodBorkar.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Failed to generate ZIP', e);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-5 border border-gray-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-[#6C5CE7] flex items-center justify-center">
              <Folder className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-gray-900">Android Studio Project Source Explorer</h2>
              <p className="text-xs text-gray-500">
                Directory: <code className="text-[#6C5CE7] font-semibold">OIBSIP/Task2_ToDoAppWithLogin/</code> • Ready to import into Android Studio
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="px-4 py-2 bg-gradient-to-r from-[#6C5CE7] to-[#0984E3] text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-100 hover:opacity-95 active:scale-95 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{isZipping ? 'Generating ZIP...' : 'Download Android Studio Project (.ZIP)'}</span>
          </button>
        </div>
      </div>

      {/* Two-Pane File Browser */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 bg-white rounded-2xl border border-gray-200 shadow-xs overflow-hidden min-h-[580px]">
        {/* Left Column: File Tree */}
        <div className="md:col-span-4 border-r border-gray-200 p-4 bg-gray-50/50 flex flex-col">
          <span className="text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-2 px-2">
            Project Files
          </span>

          <div className="space-y-1 overflow-y-auto flex-1">
            {PROJECT_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  type="button"
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-2.5 rounded-xl text-xs flex items-center gap-2 transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-white text-[#6C5CE7] font-bold shadow-xs border border-indigo-100'
                      : 'text-gray-600 hover:bg-gray-100/80 font-medium'
                  }`}
                >
                  <FileCode
                    className={`w-4 h-4 shrink-0 ${
                      file.category === 'java'
                        ? 'text-[#6C5CE7]'
                        : file.category === 'layout'
                        ? 'text-[#0984E3]'
                        : file.category === 'config'
                        ? 'text-amber-500'
                        : 'text-gray-400'
                    }`}
                  />
                  <div className="truncate flex-1">
                    <p className="truncate leading-tight">{file.name}</p>
                    <p className="text-[10px] text-gray-400 font-mono truncate">{file.category}</p>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="mt-4 pt-3 border-t border-gray-200 text-[11px] text-gray-500 space-y-1">
            <p className="font-semibold text-gray-700">Developer:</p>
            <p>Neha Vinod Borkar</p>
            <p className="text-[10px] text-gray-400">Oasis Infobyte Android Track</p>
          </div>
        </div>

        {/* Right Column: Code Viewer */}
        <div className="md:col-span-8 p-5 flex flex-col">
          {/* Header */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-gray-100">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-gray-900">{selectedFile.name}</h3>
                <span className="text-[10px] bg-gray-100 text-gray-600 font-mono px-2 py-0.5 rounded-md font-semibold">
                  {selectedFile.language.toUpperCase()}
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-1">{selectedFile.description}</p>
            </div>

            <button
              type="button"
              onClick={handleCopy}
              className="px-3 py-1.5 text-xs font-semibold bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-600">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy File</span>
                </>
              )}
            </button>
          </div>

          {/* Code Window */}
          <div className="mt-3 flex-1 bg-[#1E2238] rounded-xl p-4 overflow-x-auto text-gray-200 font-mono text-xs leading-relaxed max-h-[480px]">
            <pre>
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
