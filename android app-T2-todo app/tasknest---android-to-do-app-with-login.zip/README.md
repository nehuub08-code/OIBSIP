# TaskNest — Android To-Do App with Login (OIBSIP Task 2)

**Developer:** Neha Vinod Borkar  
**Track:** Android App Development  
**Organization:** Oasis Infobyte  
**Task Title:** Task 2 — To-Do App with Login  

The complete, compilable Android Studio project files are located in:  
📁 **[`OIBSIP/Task2_ToDoAppWithLogin/`](./OIBSIP/Task2_ToDoAppWithLogin/)**

### Interactive Web Studio Applet
This web applet provides a full **Android Emulator & Interactive Simulator**, live **SQLite Database Inspector**, **20-Point Automated Test Runner**, **Demo Video Walkthrough Mode**, and **One-Click Project ZIP Downloader** for Neha Vinod Borkar's TaskNest project!
