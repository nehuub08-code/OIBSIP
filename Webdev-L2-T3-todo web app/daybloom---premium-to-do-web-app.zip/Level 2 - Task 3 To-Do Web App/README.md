# DayBloom — Premium To-Do Web App
> *“Make room for what matters.”*

**Oasis Infobyte Internship (OIBSIP)**  
**Track:** Web Development & Designing  
**Task:** Level 2 — Task 3: To-Do Web App  
**Intern:** Neha Vinod Borkar  

---

## 🌸 1. Project Overview

**DayBloom** is a beautifully crafted, mindful, and highly responsive productivity web application designed to help individuals organize daily tasks, prioritize meaningful work, and track real-time progress.

Built entirely with pure, standards-compliant **HTML5, CSS3, and Vanilla JavaScript**, DayBloom demonstrates clean software engineering principles: strict separation of concerns, zero runtime framework dependencies, safe DOM manipulation preventing XSS, full keyboard accessibility, dynamic real-time metrics, and resilient browser data persistence via `localStorage`.

---

## 🌟 2. Key Features

### 📋 Full CRUD Task Management
- **Add Tasks**: Specify title, optional description, priority (Low, Medium, High), due date, and category (Work, Study, Personal, Wellness, Other).
- **Edit Tasks**: Update title, description, priority, category, or due date in an accessible dialog without losing task creation history.
- **Delete Tasks**: Safe deletion flow with a confirmation dialog and a 5-second **Undo action** in the notification toast.
- **Toggle Completion**: One-click checkmark with visual strikethrough, subtle status updates, and dynamic recalculation of metrics.
- **Flag Important**: Star or flag high-priority items for instant filtering.

### 🔍 Filtering, Search & Sorting
- **Smart Filters**:
  - **All Tasks**: Complete overview with count badge.
  - **Today**: Automatically filters tasks whose due date matches today's date.
  - **Upcoming**: Shows future scheduled tasks.
  - **Important**: Gathers high-priority and starred items.
  - **Completed**: Reviews finished work.
- **Category Filter Tabs**: Quick-filter by tags (`💼 Work`, `📚 Study`, `🏠 Personal`, `🌱 Wellness`).
- **Live Search**: Instant real-time search across task titles, descriptions, and categories.
- **Flexible Sorting**: Sort by Newest First, Oldest First, Due Date (Soonest), Priority (High to Low), or Alphabetical (A–Z).

### 📊 Real-Time Dynamic Progress & Analytics
- **Live Completion Progress Bar**: Displays actual completion percentage (`(completed / total) * 100%`) with animated gradient fill.
- **Dynamic Motivational Greeting**: Context-aware subtitle updates according to progress (e.g., zero state, halfway momentum, 100% completion celebration).
- **Stat Cards**: Dynamic counters for Total, Completed, Remaining, and High-Priority tasks.
- **No hardcoded stats**: Every count and progress bar adjusts instantaneously upon any task mutation.

### 🎨 Visual Identity & Polish
- **Color Palette**: Deep indigo and midnight blue structure (`#1e1b4b`, `#0f172a`), soft lavender and pale blue surfaces (`#f8f9ff`, `#e0e7ff`), electric violet action accents (`#6366f1`), mint/teal completion badges (`#10b981`), and warm coral/amber priority indicators (`#e11d48`, `#d97706`).
- **Dark Mode Support**: Persistent dark/light theme switch adhering to WCAG AA/AAA contrast ratios and respecting system preferences.
- **Empty States**: Filter-tailored empty states with helpful guidance and quick reset actions.

### 💾 Data Persistence & Portability
- **Browser LocalStorage**: Tasks and theme settings remain intact across browser refreshes and restarts.
- **Data Safety**: Graceful fallback if storage data is corrupted or invalid.
- **Export & Import**: Download tasks as a portable `.json` backup file or restore tasks from an existing backup.

### ♿ Accessibility & Usability
- Semantic HTML (`<header>`, `<main>`, `<aside>`, `<section>`, `<footer>`, `<dialog>`).
- Visible focus rings for keyboard navigation.
- Accessible ARIA labels on all icon buttons (`aria-label`, `role="list"`, `aria-hidden`, `aria-modal`).
- Keyboard shortcuts:
  - `Enter` submits new tasks.
  - `Escape` dismisses modals.
  - `Alt + N` / `Ctrl + K` immediately focuses the task title input.
- Respects `prefers-reduced-motion` for motion-sensitive users.

---

## 🛠️ 3. Technologies Used

- **HTML5**: Semantic tags, accessible forms, modern input types (`date`, `radio`, `select`).
- **CSS3**: Custom properties (CSS variables), CSS Grid, Flexbox, responsive typography, media queries, smooth keyframe animations.
- **Vanilla JavaScript (ES6+)**: Modular state architecture, DOM events, LocalStorage API, FileReader API.
- **No External Frameworks**: Zero React, Vue, Bootstrap, or Tailwind runtime dependencies.

---

## 📁 4. Project Structure

```
OIBSIP/
└── Level 2 - Task 3 To-Do Web App/
    ├── index.html       # Semantic HTML5 markup, embedded SVGs & dialogs
    ├── style.css        # Pure CSS3 styles, design tokens & dark mode
    ├── script.js        # Vanilla JS logic, state machine & LocalStorage
    └── README.md        # Comprehensive documentation & testing report
```

---

## 🚀 5. How to Run Locally

Because this application relies exclusively on standard web technologies:

### Option A: Direct Browser Launch (Simplest)
1. Download or clone this repository.
2. Double-click `index.html` (or right-click → **Open with** → Google Chrome, Firefox, Edge, or Safari).
3. The application runs immediately with zero installation!

### Option B: Using VS Code Live Server
1. Open the project folder in **Visual Studio Code**.
2. Right-click `index.html` and select **Open with Live Server**.
3. View the app at `http://127.0.0.1:5500/index.html`.

### Option C: Using Node.js / Vite
```bash
npm install
npm run dev
```
Open `http://localhost:3000` in your browser.

---

## 💾 6. How LocalStorage is Used

Tasks are stored under the key `'daybloom_tasks_v1'` as a JSON-serialized array of task objects:

```json
[
  {
    "id": "task-17192839210-abcde",
    "title": "Complete internship evaluation",
    "description": "Double check all test cases and demo video.",
    "priority": "high",
    "dueDate": "2026-10-25",
    "category": "Study",
    "isCompleted": false,
    "isImportant": true,
    "createdAt": "2026-10-25T11:00:00.000Z",
    "completedAt": null
  }
]
```

### Safety & Resilience:
- Any task mutation (`add`, `edit`, `delete`, `toggle`, `clear`) immediately triggers `saveTasksToStorage()`.
- On application load, `loadTasksFromStorage()` wraps `JSON.parse` in a `try...catch` block. If stored data is corrupted or invalid, it gracefully recovers without crashing.
- Storage does not make misleading claims of multi-device synchronization; it operates as an intentional, fast local offline store.

---

## 🧪 7. Requirement-by-Requirement Testing Checklist

| # | Test Case / Requirement | Status | Verification Notes |
|---|-------------------------|:------:|--------------------|
| 1 | Add valid task | **PASS** | Adds task instantly, clears input, updates counter & shows toast. |
| 2 | Reject empty / whitespace titles | **PASS** | Form validation highlights input in coral with descriptive warning message. |
| 3 | Edit task | **PASS** | Opens modal with pre-populated fields; changes reflect in UI and storage. |
| 4 | Delete task | **PASS** | Confirmation modal prevents accidental deletion; includes 5-second Undo toast. |
| 5 | Mark complete / incomplete | **PASS** | Toggles strikethrough, changes icon to emerald checkmark, recalculates stats. |
| 6 | Filter by All, Today, Upcoming, Important, Completed | **PASS** | Each filter correctly subsets tasks with live count badges. |
| 7 | Dynamic progress statistics | **PASS** | Total, Completed, Remaining, High-Priority & percentage bar update dynamically. |
| 8 | Page refresh data persistence | **PASS** | Tasks and theme persist across page reload and browser restart. |
| 9 | Invalid localStorage handling | **PASS** | Handled via `try/catch` with fallback initialization; no crashes. |
| 10 | Long task titles & descriptions | **PASS** | CSS `word-break: break-word` prevents container overflow or layout breaking. |
| 11 | Keyboard interaction | **PASS** | Full Tab navigation, `Enter` submits form, `Escape` closes modals, `Alt+N` focuses input. |
| 12 | Responsive layouts | **PASS** | Verified on 360px, 390px, 768px, 1024px, and 1440px widths. |
| 13 | Safe user text handling | **PASS** | Rendered strictly via `textContent` and safe DOM nodes; immune to HTML injection. |
| 14 | Zero non-functional buttons | **PASS** | Every button, filter, sort option, and modal control performs its designated function. |

---

## 🎥 8. Mandatory Demo Video Sequence (Oasis Infobyte Guideline)

### Mandatory First 2 Seconds (Title Card):
The first **TWO SECONDS** of the video demonstration must visibly display:
- **Full Name:** Neha Vinod Borkar
- **Assigned Track:** Web Development & Designing
- **Task Title:** Level 2 — Task 3: To-Do Web App

> *Tip: Click the **“Demo Title Card”** button in DayBloom's header to open an on-screen title card optimized for video recording!*

### Suggested Demo Workflow:
1. Show the opening title card for at least 2 seconds.
2. Open DayBloom in full view (demonstrating current date, greeting, and overview metrics).
3. Add a new task (e.g. “Submit Oasis Infobyte Task 3”) with High priority and today's date.
4. Edit the task (update description and due date).
5. Mark the task as completed — notice the progress bar advancing and percentage updating.
6. Demonstrate filters: click **Completed**, **Today**, **Important**, and **All**.
7. Delete a task and briefly highlight the **Undo** toast notification.
8. Refresh the browser to prove that tasks remain saved in `localStorage`.
9. Toggle between Light Mode and Dark Mode.
10. Toggle the mobile responsive view in browser Developer Tools.

---

## ⚠️ 9. Known Limitations

- **Browser-Specific Storage**: Since data is stored in the browser's `localStorage`, tasks will not automatically sync across different browsers or separate devices unless exported and imported via the provided JSON backup feature.
- **Offline Attachments**: To keep the app lightweight and fast without server dependencies, task descriptions support text-only notes rather than binary file attachments.

---

## 👩‍💻 10. Student Submission Details

- **Intern Name:** Neha Vinod Borkar  
- **Email:** nehaborkar2408@gmail.com  
- **Internship Program:** Oasis Infobyte Internship (OIBSIP)  
- **Domain:** Web Development & Designing  
- **Submission Task:** Level 2 — Task 3: To-Do Web App  
- **Repository Name:** `OIBSIP`
