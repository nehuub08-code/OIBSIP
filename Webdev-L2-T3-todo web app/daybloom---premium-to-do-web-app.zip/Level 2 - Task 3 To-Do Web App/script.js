/**
 * DayBloom — Premium To-Do Web App
 * Oasis Infobyte Internship — Web Development & Designing
 * Level 2 — Task 3: To-Do Web App
 * 
 * Vanilla JavaScript Implementation
 * Features: Full CRUD, LocalStorage persistence, multi-criteria filtering,
 * search, sorting, dynamic real-time progress metrics, dark mode, accessible dialogs,
 * toast notifications with Undo, and safe DOM manipulation.
 */

'use strict';

// -----------------------------------------------------------------------------
// 1. Constants & Configuration
// -----------------------------------------------------------------------------
const STORAGE_KEY = 'daybloom_tasks_v1';
const THEME_KEY = 'daybloom_theme_v1';

// Sample starter tasks for new users to immediately experience the app
const INITIAL_DEMO_TASKS = [
  {
    id: 'task-1',
    title: 'Review Oasis Infobyte Level 2 Task 3 specifications',
    description: 'Ensure all requirements for UI/UX, accessibility, filters, and local persistence are thoroughly covered.',
    priority: 'high',
    dueDate: getRelativeDateString(0), // Today
    category: 'Study',
    isCompleted: true,
    isImportant: true,
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    completedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
  {
    id: 'task-2',
    title: 'Record demo video with mandatory 2-second title card',
    description: 'Display: Neha Vinod Borkar, Web Development & Designing, Level 2 - Task 3: To-Do Web App.',
    priority: 'high',
    dueDate: getRelativeDateString(0), // Today
    category: 'Work',
    isCompleted: false,
    isImportant: true,
    createdAt: new Date(Date.now() - 3600000 * 3).toISOString(),
    completedAt: null,
  },
  {
    id: 'task-3',
    title: 'Organise project repository structure (OIBSIP)',
    description: 'Organise index.html, style.css, script.js, and comprehensive README.md in the submission folder.',
    priority: 'medium',
    dueDate: getRelativeDateString(1), // Tomorrow
    category: 'Work',
    isCompleted: false,
    isImportant: false,
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    completedAt: null,
  },
  {
    id: 'task-4',
    title: 'Mindful evening walk and recharge',
    description: 'Take 30 minutes away from screens to reflect on progress and unwind.',
    priority: 'low',
    dueDate: getRelativeDateString(2),
    category: 'Wellness',
    isCompleted: false,
    isImportant: false,
    createdAt: new Date(Date.now() - 3600000 * 1).toISOString(),
    completedAt: null,
  }
];

// Helper to get formatted YYYY-MM-DD relative date
function getRelativeDateString(dayOffset) {
  const d = new Date();
  d.setDate(d.getDate() + dayOffset);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// -----------------------------------------------------------------------------
// 2. Application State
// -----------------------------------------------------------------------------
const state = {
  tasks: [],
  activeFilter: 'all', // 'all' | 'today' | 'upcoming' | 'important' | 'completed'
  activeCategory: 'all', // 'all' | 'Work' | 'Personal' | 'Study' | 'Wellness'
  searchQuery: '',
  sortBy: 'date-desc', // 'date-desc' | 'date-asc' | 'due-asc' | 'priority-desc' | 'title-asc'
  theme: 'light',
  taskPendingDeleteId: null,
  taskPendingEditId: null,
  lastDeletedTask: null,
  undoTimeoutId: null,
};

// -----------------------------------------------------------------------------
// 3. SVG Icon Templates (Accessible, embedded, zero external dependencies)
// -----------------------------------------------------------------------------
const ICONS = {
  check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"></polyline></svg>`,
  star: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>`,
  edit: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg>`,
  trash: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>`,
  calendar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>`,
  tag: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>`,
  flag: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path><line x1="4" y1="22" x2="4" y2="15"></line></svg>`,
  info: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`,
  sun: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>`,
  moon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>`,
};

// -----------------------------------------------------------------------------
// 4. DOM Elements Cache
// -----------------------------------------------------------------------------
const dom = {
  // Theme & Header
  themeToggleBtn: document.getElementById('theme-toggle-btn'),
  themeIconWrap: document.getElementById('theme-icon-wrap'),
  themeTextLabel: document.getElementById('theme-text-label'),
  headerCurrentDate: document.getElementById('header-current-date'),
  titleCardBtn: document.getElementById('title-card-btn'),
  mobileMenuToggle: document.getElementById('mobile-menu-toggle'),
  appSidebar: document.getElementById('app-sidebar'),

  // Filters & Counts
  filterBtns: document.querySelectorAll('.filter-btn'),
  mobileFilterTabs: document.querySelectorAll('.mobile-filter-tab'),
  categoryTagBtns: document.querySelectorAll('.category-tag-btn'),
  countAll: document.getElementById('count-all'),
  countToday: document.getElementById('count-today'),
  countUpcoming: document.getElementById('count-upcoming'),
  countImportant: document.getElementById('count-important'),
  countCompleted: document.getElementById('count-completed'),

  // Hero & Metrics
  heroGreeting: document.getElementById('hero-greeting'),
  heroSubtitle: document.getElementById('hero-subtitle'),
  heroProgressPercent: document.getElementById('hero-progress-percent'),
  heroProgressFill: document.getElementById('hero-progress-fill'),
  heroProgressCount: document.getElementById('hero-progress-count'),
  metricTotal: document.getElementById('metric-total'),
  metricCompleted: document.getElementById('metric-completed'),
  metricPending: document.getElementById('metric-pending'),
  metricImportant: document.getElementById('metric-important'),

  // Add Task Form
  taskForm: document.getElementById('add-task-form'),
  taskTitleInput: document.getElementById('task-title-input'),
  taskDescInput: document.getElementById('task-desc-input'),
  taskDueDateInput: document.getElementById('task-due-date-input'),
  taskCategorySelect: document.getElementById('task-category-select'),
  formErrorMsg: document.getElementById('form-error-msg'),

  // Controls & List
  currentViewTitle: document.getElementById('current-view-title'),
  currentViewCount: document.getElementById('current-view-count'),
  searchInput: document.getElementById('search-input'),
  sortSelect: document.getElementById('sort-select'),
  taskListContainer: document.getElementById('task-list-container'),
  emptyStateCard: document.getElementById('empty-state-card'),
  emptyStateTitle: document.getElementById('empty-state-title'),
  emptyStateDesc: document.getElementById('empty-state-desc'),
  emptyStateActionBtn: document.getElementById('empty-state-action-btn'),

  // Utilities
  clearCompletedBtn: document.getElementById('clear-completed-btn'),
  exportDataBtn: document.getElementById('export-data-btn'),
  importDataInput: document.getElementById('import-data-input'),
  importDataBtn: document.getElementById('import-data-btn'),

  // Edit Modal
  editModal: document.getElementById('edit-task-modal'),
  editForm: document.getElementById('edit-task-form'),
  editTitleInput: document.getElementById('edit-title-input'),
  editDescInput: document.getElementById('edit-desc-input'),
  editPriorityRadios: document.querySelectorAll('input[name="edit-priority"]'),
  editDueDateInput: document.getElementById('edit-due-date-input'),
  editCategorySelect: document.getElementById('edit-category-select'),
  editCloseBtn: document.getElementById('edit-modal-close-btn'),
  editCancelBtn: document.getElementById('edit-modal-cancel-btn'),
  editErrorMsg: document.getElementById('edit-error-msg'),

  // Delete Modal
  deleteModal: document.getElementById('delete-confirm-modal'),
  deleteTitlePreview: document.getElementById('delete-task-title-preview'),
  deleteCancelBtn: document.getElementById('delete-modal-cancel-btn'),
  deleteConfirmBtn: document.getElementById('delete-modal-confirm-btn'),
  deleteCloseBtn: document.getElementById('delete-modal-close-btn'),

  // Video Title Card Modal
  titleCardModal: document.getElementById('title-card-modal'),
  titleCardCloseBtn: document.getElementById('title-card-close-btn'),
  titleCardOkBtn: document.getElementById('title-card-ok-btn'),

  // Toast Container
  toastContainer: document.getElementById('toast-container'),
};

// -----------------------------------------------------------------------------
// 5. LocalStorage & State Synchronization
// -----------------------------------------------------------------------------
function loadTasksFromStorage() {
  try {
    const rawData = localStorage.getItem(STORAGE_KEY);
    if (!rawData) {
      // First visit: initialize with educational demo tasks
      state.tasks = [...INITIAL_DEMO_TASKS];
      saveTasksToStorage();
      return;
    }

    const parsed = JSON.parse(rawData);
    if (Array.isArray(parsed)) {
      // Sanitize and ensure each object matches schema
      state.tasks = parsed.filter(item => item && typeof item === 'object' && item.id && item.title);
    } else {
      console.warn('Invalid tasks format in localStorage; resetting.');
      state.tasks = [...INITIAL_DEMO_TASKS];
    }
  } catch (err) {
    console.error('Failed to parse localStorage data:', err);
    state.tasks = [...INITIAL_DEMO_TASKS];
  }
}

function saveTasksToStorage() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.tasks));
  } catch (err) {
    console.error('Failed to write to localStorage:', err);
    showToast('Storage quota exceeded or storage disabled.', 'danger');
  }
}

function loadThemeFromStorage() {
  const savedTheme = localStorage.getItem(THEME_KEY);
  if (savedTheme === 'dark' || savedTheme === 'light') {
    state.theme = savedTheme;
  } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    state.theme = 'dark';
  } else {
    state.theme = 'light';
  }
  applyTheme();
}

function applyTheme() {
  document.documentElement.setAttribute('data-theme', state.theme);
  if (dom.themeIconWrap) {
    dom.themeIconWrap.innerHTML = state.theme === 'dark' ? ICONS.sun : ICONS.moon;
  }
  if (dom.themeTextLabel) {
    dom.themeTextLabel.textContent = state.theme === 'dark' ? 'Light Mode' : 'Dark Mode';
  }
  localStorage.setItem(THEME_KEY, state.theme);
}

function toggleTheme() {
  state.theme = state.theme === 'dark' ? 'light' : 'dark';
  applyTheme();
  showToast(`Switched to ${state.theme} theme`, 'info');
}

// -----------------------------------------------------------------------------
// 6. Header Date & Greeting
// -----------------------------------------------------------------------------
function updateHeaderAndGreeting() {
  const now = new Date();
  
  // Format readable current date: "Sunday, Oct 25"
  const dateOptions = { weekday: 'short', month: 'short', day: 'numeric' };
  if (dom.headerCurrentDate) {
    dom.headerCurrentDate.textContent = now.toLocaleDateString(undefined, dateOptions);
  }

  // Greeting based on time of day
  const hour = now.getHours();
  let greeting = 'Good morning';
  if (hour >= 12 && hour < 17) {
    greeting = 'Good afternoon';
  } else if (hour >= 17) {
    greeting = 'Good evening';
  }

  if (dom.heroGreeting) {
    dom.heroGreeting.textContent = `${greeting}, Neha`;
  }
}

// -----------------------------------------------------------------------------
// 7. Filtering & Sorting Logic
// -----------------------------------------------------------------------------
function getFilteredAndSortedTasks() {
  const todayStr = getRelativeDateString(0);
  const query = state.searchQuery.trim().toLowerCase();

  return state.tasks.filter(task => {
    // 1. Primary Filter
    if (state.activeFilter === 'today') {
      if (task.dueDate !== todayStr) return false;
    } else if (state.activeFilter === 'upcoming') {
      if (!task.dueDate || task.dueDate <= todayStr) return false;
    } else if (state.activeFilter === 'important') {
      if (!task.isImportant && task.priority !== 'high') return false;
    } else if (state.activeFilter === 'completed') {
      if (!task.isCompleted) return false;
    }

    // 2. Category Filter
    if (state.activeCategory !== 'all') {
      if (task.category !== state.activeCategory) return false;
    }

    // 3. Search Query Filter
    if (query) {
      const matchTitle = task.title.toLowerCase().includes(query);
      const matchDesc = task.description && task.description.toLowerCase().includes(query);
      const matchCategory = task.category && task.category.toLowerCase().includes(query);
      if (!matchTitle && !matchDesc && !matchCategory) return false;
    }

    return true;
  }).sort((a, b) => {
    // Sorting
    switch (state.sortBy) {
      case 'date-asc':
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      case 'due-asc':
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return a.dueDate.localeCompare(b.dueDate);
      case 'priority-desc': {
        const pWeights = { high: 3, medium: 2, low: 1 };
        const weightA = (pWeights[a.priority] || 0) + (a.isImportant ? 0.5 : 0);
        const weightB = (pWeights[b.priority] || 0) + (b.isImportant ? 0.5 : 0);
        return weightB - weightA;
      }
      case 'title-asc':
        return a.title.localeCompare(b.title);
      case 'date-desc':
      default:
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
  });
}

// -----------------------------------------------------------------------------
// 8. Dynamic Statistics & Metrics Calculation
// -----------------------------------------------------------------------------
function updateMetricsAndBadges() {
  const todayStr = getRelativeDateString(0);
  
  const total = state.tasks.length;
  const completed = state.tasks.filter(t => t.isCompleted).length;
  const pending = total - completed;
  const todayCount = state.tasks.filter(t => t.dueDate === todayStr).length;
  const upcomingCount = state.tasks.filter(t => t.dueDate && t.dueDate > todayStr).length;
  const importantCount = state.tasks.filter(t => t.isImportant || t.priority === 'high').length;

  // Percentage
  const percent = total > 0 ? Math.round((completed / total) * 100) : 0;

  // Update Hero elements
  if (dom.heroProgressPercent) dom.heroProgressPercent.textContent = `${percent}%`;
  if (dom.heroProgressFill) dom.heroProgressFill.style.width = `${percent}%`;
  if (dom.heroProgressCount) {
    dom.heroProgressCount.textContent = `${completed} of ${total} tasks completed`;
  }

  // Update Hero Subtitle based on progress
  if (dom.heroSubtitle) {
    if (total === 0) {
      dom.heroSubtitle.textContent = 'Your slate is completely clean. Add your first task below to begin.';
    } else if (percent === 100) {
      dom.heroSubtitle.textContent = 'Splendid achievement! All tasks completed. Make room for what matters.';
    } else if (percent >= 50) {
      dom.heroSubtitle.textContent = `Great momentum! You've conquered ${completed} tasks already. Keep going!`;
    } else {
      dom.heroSubtitle.textContent = `You have ${pending} tasks in progress today. Take it step-by-step.`;
    }
  }

  // Update Metric Cards
  if (dom.metricTotal) dom.metricTotal.textContent = total;
  if (dom.metricCompleted) dom.metricCompleted.textContent = completed;
  if (dom.metricPending) dom.metricPending.textContent = pending;
  if (dom.metricImportant) dom.metricImportant.textContent = importantCount;

  // Update Sidebar Badges
  if (dom.countAll) dom.countAll.textContent = total;
  if (dom.countToday) dom.countToday.textContent = todayCount;
  if (dom.countUpcoming) dom.countUpcoming.textContent = upcomingCount;
  if (dom.countImportant) dom.countImportant.textContent = importantCount;
  if (dom.countCompleted) dom.countCompleted.textContent = completed;
}

// -----------------------------------------------------------------------------
// 9. Task Item Rendering (Safe DOM Construction)
// -----------------------------------------------------------------------------
function renderTasks() {
  updateMetricsAndBadges();

  const filteredTasks = getFilteredAndSortedTasks();

  // Update view title and count
  const filterTitles = {
    all: 'All Tasks',
    today: "Today's Tasks",
    upcoming: 'Upcoming Tasks',
    important: 'Important Tasks',
    completed: 'Completed Tasks',
  };

  if (dom.currentViewTitle) {
    dom.currentViewTitle.textContent = filterTitles[state.activeFilter] || 'Tasks';
  }
  if (dom.currentViewCount) {
    dom.currentViewCount.textContent = `${filteredTasks.length} ${filteredTasks.length === 1 ? 'task' : 'tasks'}`;
  }

  // Handle Empty State
  if (filteredTasks.length === 0) {
    dom.taskListContainer.innerHTML = '';
    dom.emptyStateCard.style.display = 'flex';
    
    // Customize empty state message based on filter
    if (state.searchQuery) {
      dom.emptyStateTitle.textContent = 'No matching tasks found';
      dom.emptyStateDesc.textContent = `No tasks match your search "${state.searchQuery}". Try a different keyword or clear the search.`;
    } else if (state.activeFilter === 'completed') {
      dom.emptyStateTitle.textContent = 'No completed tasks yet';
      dom.emptyStateDesc.textContent = 'Complete tasks by clicking their checkbox to track your progress here.';
    } else if (state.activeFilter === 'today') {
      dom.emptyStateTitle.textContent = 'Nothing scheduled for today';
      dom.emptyStateDesc.textContent = 'Your schedule is clear today. Add a new task or enjoy your free time!';
    } else if (state.activeFilter === 'upcoming') {
      dom.emptyStateTitle.textContent = 'No upcoming deadlines';
      dom.emptyStateDesc.textContent = 'You have no tasks scheduled for future dates. Plan ahead by adding due dates.';
    } else if (state.activeFilter === 'important') {
      dom.emptyStateTitle.textContent = 'No high-priority tasks';
      dom.emptyStateDesc.textContent = 'You have no flagged or high-priority tasks. High-priority items will appear here.';
    } else {
      dom.emptyStateTitle.textContent = 'No tasks in this list';
      dom.emptyStateDesc.textContent = 'Ready to organize your day? Add your first task using the form above.';
    }
    return;
  }

  // Hide empty state and populate list
  dom.emptyStateCard.style.display = 'none';
  dom.taskListContainer.innerHTML = '';

  const fragment = document.createDocumentFragment();

  filteredTasks.forEach(task => {
    const li = createTaskElement(task);
    fragment.appendChild(li);
  });

  dom.taskListContainer.appendChild(fragment);
}

function createTaskElement(task) {
  const li = document.createElement('li');
  li.className = `task-item ${task.isCompleted ? 'completed' : ''}`;
  li.setAttribute('data-id', task.id);

  // 1. Checkbox Button
  const checkBtn = document.createElement('button');
  checkBtn.className = 'task-checkbox-btn';
  checkBtn.setAttribute('type', 'button');
  checkBtn.setAttribute('aria-label', task.isCompleted ? `Mark "${task.title}" as incomplete` : `Mark "${task.title}" as complete`);
  checkBtn.innerHTML = ICONS.check;
  checkBtn.addEventListener('click', () => toggleTaskCompletion(task.id));

  // 2. Task Content Container
  const contentDiv = document.createElement('div');
  contentDiv.className = 'task-content';

  // Title line
  const titleLine = document.createElement('div');
  titleLine.className = 'task-title-line';

  const titleSpan = document.createElement('span');
  titleSpan.className = 'task-title';
  titleSpan.textContent = task.title; // Safe textContent avoids XSS
  titleLine.appendChild(titleSpan);
  contentDiv.appendChild(titleLine);

  // Description (if present)
  if (task.description && task.description.trim().length > 0) {
    const descP = document.createElement('p');
    descP.className = 'task-desc';
    descP.textContent = task.description; // Safe textContent
    contentDiv.appendChild(descP);
  }

  // Metadata Row (Priority, Due Date, Category)
  const metaRow = document.createElement('div');
  metaRow.className = 'task-meta-row';

  // Priority Badge
  const priorityBadge = document.createElement('span');
  priorityBadge.className = `badge badge-priority-${task.priority}`;
  priorityBadge.innerHTML = `${ICONS.flag} ${capitalize(task.priority)} Priority`;
  metaRow.appendChild(priorityBadge);

  // Due Date Badge
  if (task.dueDate) {
    const dueDateBadge = document.createElement('span');
    const { label, isOverdue, isToday } = formatDueDate(task.dueDate);
    dueDateBadge.className = `badge badge-due-date ${isOverdue ? 'overdue' : ''} ${isToday ? 'today' : ''}`;
    dueDateBadge.innerHTML = `${ICONS.calendar} ${label}`;
    metaRow.appendChild(dueDateBadge);
  }

  // Category Badge
  if (task.category) {
    const categoryBadge = document.createElement('span');
    categoryBadge.className = 'badge badge-category';
    categoryBadge.innerHTML = `${ICONS.tag} ${task.category}`;
    metaRow.appendChild(categoryBadge);
  }

  contentDiv.appendChild(metaRow);

  // 3. Action Buttons (Star, Edit, Delete)
  const actionsDiv = document.createElement('div');
  actionsDiv.className = 'task-actions';

  // Star / Important Button
  const starBtn = document.createElement('button');
  starBtn.className = `task-action-btn btn-star ${task.isImportant ? 'active' : ''}`;
  starBtn.setAttribute('type', 'button');
  starBtn.setAttribute('aria-label', task.isImportant ? 'Unmark important' : 'Mark as important');
  starBtn.innerHTML = ICONS.star;
  starBtn.addEventListener('click', () => toggleTaskImportant(task.id));

  // Edit Button
  const editBtn = document.createElement('button');
  editBtn.className = 'task-action-btn btn-edit';
  editBtn.setAttribute('type', 'button');
  editBtn.setAttribute('aria-label', `Edit task "${task.title}"`);
  editBtn.innerHTML = ICONS.edit;
  editBtn.addEventListener('click', () => openEditModal(task.id));

  // Delete Button
  const deleteBtn = document.createElement('button');
  deleteBtn.className = 'task-action-btn btn-delete';
  deleteBtn.setAttribute('type', 'button');
  deleteBtn.setAttribute('aria-label', `Delete task "${task.title}"`);
  deleteBtn.innerHTML = ICONS.trash;
  deleteBtn.addEventListener('click', () => promptDeleteTask(task.id));

  actionsDiv.appendChild(starBtn);
  actionsDiv.appendChild(editBtn);
  actionsDiv.appendChild(deleteBtn);

  // Assemble List Item
  li.appendChild(checkBtn);
  li.appendChild(contentDiv);
  li.appendChild(actionsDiv);

  return li;
}

// -----------------------------------------------------------------------------
// 10. Date Formatting & Helpers
// -----------------------------------------------------------------------------
function formatDueDate(dueDateStr) {
  if (!dueDateStr) return { label: '', isOverdue: false, isToday: false };

  const todayStr = getRelativeDateString(0);
  const tomorrowStr = getRelativeDateString(1);
  const yesterdayStr = getRelativeDateString(-1);

  if (dueDateStr === todayStr) {
    return { label: 'Due Today', isOverdue: false, isToday: true };
  }
  if (dueDateStr === tomorrowStr) {
    return { label: 'Due Tomorrow', isOverdue: false, isToday: false };
  }
  if (dueDateStr === yesterdayStr) {
    return { label: 'Overdue (Yesterday)', isOverdue: true, isToday: false };
  }
  if (dueDateStr < todayStr) {
    return { label: `Overdue (${dueDateStr})`, isOverdue: true, isToday: false };
  }

  // Format YYYY-MM-DD to readable "Oct 28"
  const parts = dueDateStr.split('-');
  if (parts.length === 3) {
    const d = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
    const label = d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    return { label: `Due ${label}`, isOverdue: false, isToday: false };
  }

  return { label: dueDateStr, isOverdue: false, isToday: false };
}

function capitalize(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// -----------------------------------------------------------------------------
// 11. Task Actions (CRUD Operations)
// -----------------------------------------------------------------------------
function handleAddTask(e) {
  e.preventDefault();

  const title = dom.taskTitleInput.value.trim();
  const description = dom.taskDescInput.value.trim();
  const dueDate = dom.taskDueDateInput.value;
  const category = dom.taskCategorySelect.value;
  
  // Get selected priority from radio buttons
  const priorityRadio = document.querySelector('input[name="task-priority"]:checked');
  const priority = priorityRadio ? priorityRadio.value : 'medium';

  // Validation: Reject empty or whitespace-only titles
  if (!title) {
    dom.taskTitleInput.classList.add('has-error');
    dom.formErrorMsg.textContent = 'Please enter a task title to continue.';
    dom.formErrorMsg.classList.add('visible');
    dom.taskTitleInput.focus();
    return;
  }

  // Clear validation error
  dom.taskTitleInput.classList.remove('has-error');
  dom.formErrorMsg.classList.remove('visible');

  // Create new task object
  const newTask = {
    id: 'task-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
    title,
    description,
    priority,
    dueDate: dueDate || null,
    category: category || 'General',
    isCompleted: false,
    isImportant: priority === 'high',
    createdAt: new Date().toISOString(),
    completedAt: null,
  };

  state.tasks.unshift(newTask);
  saveTasksToStorage();
  renderTasks();

  // Reset form
  dom.taskTitleInput.value = '';
  dom.taskDescInput.value = '';
  dom.taskDueDateInput.value = '';
  // Set default medium priority checked
  const medRadio = document.querySelector('input[name="task-priority"][value="medium"]');
  if (medRadio) medRadio.checked = true;

  showToast(`Added: "${newTask.title}"`, 'success');
}

function toggleTaskCompletion(taskId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;

  task.isCompleted = !task.isCompleted;
  task.completedAt = task.isCompleted ? new Date().toISOString() : null;

  saveTasksToStorage();
  renderTasks();

  if (task.isCompleted) {
    showToast(`Completed: "${task.title}"`, 'success');
  }
}

function toggleTaskImportant(taskId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;

  task.isImportant = !task.isImportant;
  saveTasksToStorage();
  renderTasks();

  showToast(task.isImportant ? `Marked as important` : `Unmarked important`, 'info');
}

// -----------------------------------------------------------------------------
// 12. Edit Task Modal Handling
// -----------------------------------------------------------------------------
function openEditModal(taskId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;

  state.taskPendingEditId = taskId;

  dom.editTitleInput.value = task.title;
  dom.editDescInput.value = task.description || '';
  dom.editDueDateInput.value = task.dueDate || '';
  dom.editCategorySelect.value = task.category || 'General';

  // Set priority radio
  dom.editPriorityRadios.forEach(radio => {
    radio.checked = radio.value === task.priority;
  });

  dom.editTitleInput.classList.remove('has-error');
  dom.editErrorMsg.classList.remove('visible');

  dom.editModal.classList.add('open');
  dom.editModal.setAttribute('aria-hidden', 'false');
  dom.editTitleInput.focus();
}

function closeEditModal() {
  dom.editModal.classList.remove('open');
  dom.editModal.setAttribute('aria-hidden', 'true');
  state.taskPendingEditId = null;
}

function handleSaveEdit(e) {
  e.preventDefault();

  if (!state.taskPendingEditId) return;

  const task = state.tasks.find(t => t.id === state.taskPendingEditId);
  if (!task) return;

  const title = dom.editTitleInput.value.trim();
  if (!title) {
    dom.editTitleInput.classList.add('has-error');
    dom.editErrorMsg.textContent = 'Task title cannot be blank.';
    dom.editErrorMsg.classList.add('visible');
    dom.editTitleInput.focus();
    return;
  }

  const selectedPriorityRadio = document.querySelector('input[name="edit-priority"]:checked');
  const priority = selectedPriorityRadio ? selectedPriorityRadio.value : task.priority;

  task.title = title;
  task.description = dom.editDescInput.value.trim();
  task.dueDate = dom.editDueDateInput.value || null;
  task.category = dom.editCategorySelect.value || 'General';
  task.priority = priority;
  if (priority === 'high') task.isImportant = true;

  saveTasksToStorage();
  renderTasks();
  closeEditModal();

  showToast('Task updated successfully', 'success');
}

// -----------------------------------------------------------------------------
// 13. Delete Confirmation & Undo Feature
// -----------------------------------------------------------------------------
function promptDeleteTask(taskId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;

  state.taskPendingDeleteId = taskId;
  if (dom.deleteTitlePreview) {
    dom.deleteTitlePreview.textContent = `"${task.title}"`;
  }

  dom.deleteModal.classList.add('open');
  dom.deleteModal.setAttribute('aria-hidden', 'false');
  dom.deleteCancelBtn.focus();
}

function closeDeleteModal() {
  dom.deleteModal.classList.remove('open');
  dom.deleteModal.setAttribute('aria-hidden', 'true');
  state.taskPendingDeleteId = null;
}

function confirmDeleteTask() {
  if (!state.taskPendingDeleteId) return;

  const taskIndex = state.tasks.findIndex(t => t.id === state.taskPendingDeleteId);
  if (taskIndex === -1) return;

  const [deletedTask] = state.tasks.splice(taskIndex, 1);
  state.lastDeletedTask = { task: deletedTask, index: taskIndex };

  saveTasksToStorage();
  renderTasks();
  closeDeleteModal();

  // Show Toast with Undo Button
  showToastWithUndo(`Deleted: "${deletedTask.title}"`);
}

function undoLastDelete() {
  if (!state.lastDeletedTask) return;

  const { task, index } = state.lastDeletedTask;
  state.tasks.splice(index, 0, task);
  state.lastDeletedTask = null;

  saveTasksToStorage();
  renderTasks();
  showToast('Task restored!', 'success');
}

// -----------------------------------------------------------------------------
// 14. Toast Notifications
// -----------------------------------------------------------------------------
function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  const iconSpan = document.createElement('span');
  iconSpan.className = 'toast-icon';
  iconSpan.innerHTML = type === 'success' ? ICONS.check : (type === 'danger' ? ICONS.trash : ICONS.info);

  const textSpan = document.createElement('span');
  textSpan.textContent = message;

  toast.appendChild(iconSpan);
  toast.appendChild(textSpan);

  dom.toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

function showToastWithUndo(message) {
  // Clear any existing undo timeout
  if (state.undoTimeoutId) {
    clearTimeout(state.undoTimeoutId);
  }

  const toast = document.createElement('div');
  toast.className = 'toast toast-danger';

  const iconSpan = document.createElement('span');
  iconSpan.className = 'toast-icon';
  iconSpan.innerHTML = ICONS.trash;

  const textSpan = document.createElement('span');
  textSpan.textContent = message;

  const undoBtn = document.createElement('button');
  undoBtn.className = 'toast-undo-btn';
  undoBtn.type = 'button';
  undoBtn.textContent = 'Undo';
  undoBtn.addEventListener('click', () => {
    undoLastDelete();
    toast.remove();
  });

  toast.appendChild(iconSpan);
  toast.appendChild(textSpan);
  toast.appendChild(undoBtn);

  dom.toastContainer.appendChild(toast);

  state.undoTimeoutId = setTimeout(() => {
    state.lastDeletedTask = null;
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 5000);
}

// -----------------------------------------------------------------------------
// 15. Student Title Card Modal (Oasis Infobyte Video Requirement)
// -----------------------------------------------------------------------------
function openTitleCardModal() {
  dom.titleCardModal.classList.add('open');
  dom.titleCardModal.setAttribute('aria-hidden', 'false');
  dom.titleCardOkBtn.focus();
}

function closeTitleCardModal() {
  dom.titleCardModal.classList.remove('open');
  dom.titleCardModal.setAttribute('aria-hidden', 'true');
}

// -----------------------------------------------------------------------------
// 16. Utility Actions: Clear Completed, Export, Import
// -----------------------------------------------------------------------------
function clearCompletedTasks() {
  const completedCount = state.tasks.filter(t => t.isCompleted).length;
  if (completedCount === 0) {
    showToast('No completed tasks to clear.', 'info');
    return;
  }

  if (window.confirm(`Are you sure you want to clear ${completedCount} completed task${completedCount > 1 ? 's' : ''}?`)) {
    state.tasks = state.tasks.filter(t => !t.isCompleted);
    saveTasksToStorage();
    renderTasks();
    showToast(`Cleared ${completedCount} completed task${completedCount > 1 ? 's' : ''}.`, 'success');
  }
}

function exportTasksToFile() {
  if (state.tasks.length === 0) {
    showToast('No tasks to export.', 'info');
    return;
  }

  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(state.tasks, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `daybloom-backup-${getRelativeDateString(0)}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
  showToast('Task backup downloaded!', 'success');
}

function importTasksFromFile(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(evt) {
    try {
      const parsed = JSON.parse(evt.target.result);
      if (Array.isArray(parsed)) {
        state.tasks = parsed;
        saveTasksToStorage();
        renderTasks();
        showToast(`Imported ${parsed.length} tasks!`, 'success');
      } else {
        showToast('Invalid JSON file format.', 'danger');
      }
    } catch (err) {
      console.error(err);
      showToast('Error parsing JSON backup file.', 'danger');
    }
  };
  reader.readAsText(file);
  e.target.value = ''; // reset file input
}

// -----------------------------------------------------------------------------
// 17. Event Listeners & Initialization
// -----------------------------------------------------------------------------
function initEventListeners() {
  // Theme Toggle
  if (dom.themeToggleBtn) {
    dom.themeToggleBtn.addEventListener('click', toggleTheme);
  }

  // Title Card Modal (Video Requirement)
  if (dom.titleCardBtn) {
    dom.titleCardBtn.addEventListener('click', openTitleCardModal);
  }
  if (dom.titleCardCloseBtn) dom.titleCardCloseBtn.addEventListener('click', closeTitleCardModal);
  if (dom.titleCardOkBtn) dom.titleCardOkBtn.addEventListener('click', closeTitleCardModal);

  // Mobile Menu Toggle
  if (dom.mobileMenuToggle) {
    dom.mobileMenuToggle.addEventListener('click', () => {
      const isOpen = dom.appSidebar.classList.toggle('mobile-open');
      dom.mobileMenuToggle.setAttribute('aria-expanded', isOpen);
    });
  }

  // Sidebar Filter Buttons
  dom.filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const filter = btn.getAttribute('data-filter');
      state.activeFilter = filter;

      dom.filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      // Sync mobile tabs
      dom.mobileFilterTabs.forEach(tab => {
        tab.classList.toggle('active', tab.getAttribute('data-filter') === filter);
      });

      // Close mobile drawer if open
      dom.appSidebar.classList.remove('mobile-open');

      renderTasks();
    });
  });

  // Mobile Filter Tabs
  dom.mobileFilterTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const filter = tab.getAttribute('data-filter');
      state.activeFilter = filter;

      dom.mobileFilterTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      // Sync desktop sidebar
      dom.filterBtns.forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-filter') === filter);
      });

      renderTasks();
    });
  });

  // Category Tag Buttons
  dom.categoryTagBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const cat = btn.getAttribute('data-category');
      state.activeCategory = cat;

      dom.categoryTagBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      renderTasks();
    });
  });

  // Search Input
  if (dom.searchInput) {
    dom.searchInput.addEventListener('input', e => {
      state.searchQuery = e.target.value;
      renderTasks();
    });
  }

  // Sort Select Dropdown
  if (dom.sortSelect) {
    dom.sortSelect.addEventListener('change', e => {
      state.sortBy = e.target.value;
      renderTasks();
    });
  }

  // Add Task Form
  if (dom.taskForm) {
    dom.taskForm.addEventListener('submit', handleAddTask);
  }

  // Clear validation state on input
  if (dom.taskTitleInput) {
    dom.taskTitleInput.addEventListener('input', () => {
      if (dom.taskTitleInput.value.trim()) {
        dom.taskTitleInput.classList.remove('has-error');
        dom.formErrorMsg.classList.remove('visible');
      }
    });
  }

  // Empty State Action
  if (dom.emptyStateActionBtn) {
    dom.emptyStateActionBtn.addEventListener('click', () => {
      state.activeFilter = 'all';
      state.activeCategory = 'all';
      state.searchQuery = '';
      if (dom.searchInput) dom.searchInput.value = '';

      dom.filterBtns.forEach(b => b.classList.toggle('active', b.getAttribute('data-filter') === 'all'));
      dom.mobileFilterTabs.forEach(t => t.classList.toggle('active', t.getAttribute('data-filter') === 'all'));
      dom.categoryTagBtns.forEach(b => b.classList.toggle('active', b.getAttribute('data-category') === 'all'));

      renderTasks();
      if (dom.taskTitleInput) dom.taskTitleInput.focus();
    });
  }

  // Edit Modal Events
  if (dom.editForm) dom.editForm.addEventListener('submit', handleSaveEdit);
  if (dom.editCloseBtn) dom.editCloseBtn.addEventListener('click', closeEditModal);
  if (dom.editCancelBtn) dom.editCancelBtn.addEventListener('click', closeEditModal);

  // Delete Modal Events
  if (dom.deleteConfirmBtn) dom.deleteConfirmBtn.addEventListener('click', confirmDeleteTask);
  if (dom.deleteCancelBtn) dom.deleteCancelBtn.addEventListener('click', closeDeleteModal);
  if (dom.deleteCloseBtn) dom.deleteCloseBtn.addEventListener('click', closeDeleteModal);

  // Close modals when clicking overlay backdrop
  [dom.editModal, dom.deleteModal, dom.titleCardModal].forEach(modal => {
    if (modal) {
      modal.addEventListener('click', e => {
        if (e.target === modal) {
          modal.classList.remove('open');
          modal.setAttribute('aria-hidden', 'true');
        }
      });
    }
  });

  // Keyboard Shortcuts: Escape to close modals, Alt+N to add task
  window.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      if (dom.editModal.classList.contains('open')) closeEditModal();
      if (dom.deleteModal.classList.contains('open')) closeDeleteModal();
      if (dom.titleCardModal.classList.contains('open')) closeTitleCardModal();
    }
    if ((e.altKey && e.key.toLowerCase() === 'n') || (e.ctrlKey && e.key.toLowerCase() === 'k')) {
      e.preventDefault();
      if (dom.taskTitleInput) dom.taskTitleInput.focus();
    }
  });

  // Utilities
  if (dom.clearCompletedBtn) dom.clearCompletedBtn.addEventListener('click', clearCompletedTasks);
  if (dom.exportDataBtn) dom.exportDataBtn.addEventListener('click', exportTasksToFile);
  if (dom.importDataBtn) {
    dom.importDataBtn.addEventListener('click', () => {
      if (dom.importDataInput) dom.importDataInput.click();
    });
  }
  if (dom.importDataInput) {
    dom.importDataInput.addEventListener('change', importTasksFromFile);
  }
}

// -----------------------------------------------------------------------------
// 18. App Bootstrap
// -----------------------------------------------------------------------------
function initApp() {
  loadThemeFromStorage();
  loadTasksFromStorage();
  updateHeaderAndGreeting();
  initEventListeners();
  renderTasks();
}

// Run when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}
