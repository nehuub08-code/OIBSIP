# OASIS INFOBYTE — GRAPHICS DESIGN INTERNSHIP
## TASK 3: BUSINESS CARD DESIGN — AIVANTA

### 1. Designer & Project Information
- **Designer Full Name:** Neha Vinod Borkar
- **Internship Track:** Graphics Design
- **Exact Task Title:** Business Card Design
- **GitHub Repository:** `OIBSIP`
- **Project Folder:** `OIBSIP/Graphics-Design/Task-3-Business-Card/`
- **Design Tools Used:** Figma, Adobe Illustrator, and High-Precision Vector Engine
- **Fictional Brand:** Aivanta
- **Industry:** Artificial Intelligence & Productivity Technology
- **Tagline:** Intelligence. In Motion.

---

### 2. Cardholder & Fictional Data Disclosure
- **Cardholder Name:** Aarav Mehta
- **Job Title:** AI Product Designer
- **Phone:** `+91 00000 00000`
- **Email:** `aarav@aivanta.example`
- **Website:** `www.aivanta.example`
- **Instagram:** `@aivanta.design`
- **LinkedIn:** `linkedin.com/company/aivanta-demo`

> **CRITICAL FICTIONAL DISCLAIMER:**  
> Aivanta is a fictional AI technology brand created for this OASIS INFOBYTE graphics design assignment. Aarav Mehta is a fictional persona. All contact credentials, telephone numbers, and email accounts utilize reserved illustrative domains (`.example`) and dummy phone digits. No real personal or corporate information is represented.

---

### 3. Exact Print Production Dimensions & Geometry
- **Trim Size:** 85.0 mm × 55.0 mm (European standard business card size)
- **Bleed Area:** 3.0 mm on all 4 sides (Top, Bottom, Left, Right)
- **Full Artwork with Bleed:** 91.0 mm × 61.0 mm
- **Safe Zone Margin:** 4.0 mm inside trim line (Safe Content Area: 77.0 mm × 47.0 mm)
- **Resolution:** 300 DPI minimum / Pure Scalable Vector
- **Color Model:** CMYK compliant for offset/digital print production (RGB hex referenced for screen display)

---

### 4. Brand Color Palette
| Color Name | Hex Code | CMYK Equivalent | Design Role |
| :--- | :--- | :--- | :--- |
| **Deep Navy** | `#101828` | C:87% M:75% Y:50% K:64% | Primary background; premium executive presence |
| **Electric Blue** | `#3867FF` | C:78% M:60% Y:0% K:0% | Primary accent; kinetic vector & active highlights |
| **Aqua** | `#48D9D0` | C:67% M:0% Y:30% K:0% | Subtle secondary accent; innovation terminal points |
| **Pure White** | `#FFFFFF` | C:0% M:0% Y:0% K:0% | High-contrast typography & intentional negative space |

---

### 5. Typography System
- **Display & Headings:** Space Grotesk (Semibold / Bold 700)
  - Used for: Brand Wordmark ("AIVANTA"), Cardholder Name ("Aarav Mehta"), and Primary Numbers.
- **Body & Contact Metadata:** Inter (Medium / Regular 400-500)
  - Used for: Job Title ("AI PRODUCT DESIGNER"), Contact details, category labels, and tagline ("INTELLIGENCE. IN MOTION.").
- **Font Limit Adherence:** Exactly 2 font families utilized across the entire identity system.

---

### 6. Design Architecture & Layout Rationale
- **FRONT SIDE (Brand & Professional Identity):**
  - Features the distinctive Aivanta kinetic "A" vector mark and wordmark in the top-left quadrant with ample breathing room.
  - The cardholder name "Aarav Mehta" commands immediate typographic authority.
  - An architectural Electric Blue hairline vector connected to an Aqua focal dot provides visual momentum connecting the name to the uppercase title "AI PRODUCT DESIGNER".
  - Anchored at the bottom by the quiet brand mantra: "INTELLIGENCE. IN MOTION."
  - Over 65% negative space preserved to project confidence, clarity, and sophistication.
- **BACK SIDE (Structured Contact & Networks):**
  - Led by a compact Aivanta logo glyph and hairline rule.
  - All four required communication channels (Direct Line, Inquiries Email, Digital Hub, Professional Network / LinkedIn, plus Instagram) organized in a vertical grid with generous line spacing.
  - High-precision vector micro QR code positioned in the bottom-right quadrant safely within the safe margin for seamless digital vCard scanning.

---

### 7. Deliverables & File Structure
```text
OIBSIP/
└── Graphics-Design/
    └── Task-3-Business-Card/
        ├── README.md
        ├── design-notes.md
        ├── source/
        │   ├── Aivanta-Front-Source.svg
        │   ├── Aivanta-Back-Source.svg
        │   └── Aivanta-Design-Tokens.json
        ├── exports/
        │   ├── Aivanta-Business-Card-Front.pdf
        │   ├── Aivanta-Business-Card-Back.pdf
        │   ├── Aivanta-Business-Card-Print-Ready.pdf
        │   ├── Aivanta-Business-Card-Front.png
        │   └── Aivanta-Business-Card-Back.png
        └── previews/
            └── Aivanta-Double-Sided-Preview.png
```

---

### 8. Final QA Verification Checklist
- [x] Original business card composition crafted for Aivanta.
- [x] Front contains Aivanta logo, full name (Aarav Mehta), and job title (AI Product Designer).
- [x] Back contains phone, email, website, LinkedIn, and Instagram handles.
- [x] Trim size is exactly 85 × 55 mm.
- [x] Bleed is exactly 3 mm on all four sides.
- [x] Full artwork with bleed measures exactly 91 × 61 mm.
- [x] No more than two font families used (Space Grotesk + Inter).
- [x] Whitespace, optical hierarchy, and alignment are deliberate.
- [x] Colors and logo are strictly consistent with the Aivanta Task 2 brand identity.
- [x] Text remains 100% legible at physical print scale (minimum 5.5pt / 1.3mm cap height).
- [x] Front and back exports share identical registration and trim boundaries.
- [x] Print-ready PDF exported with bleed and vector integrity.
- [x] High-resolution preview PNGs included.
- [x] Editable SVG source files provided in `source/`.
- [x] Complete README and design-notes included.
- [x] Fictional nature of contact information explicitly documented.
