# AIVANTA BUSINESS CARD DESIGN NOTES
## Technical Rationale, Optical Adjustments & Print Pre-Press Guide
**Designer:** Neha Vinod Borkar  
**Internship Track:** OASIS INFOBYTE Graphics Design — Task 3  

---

### 1. Optical Balance & Ergonomics
Business cards are tactile, intimate artifacts experienced at a reading distance of 25–35 cm. At this scale:
- The human eye perceives hairline strokes thinner than 0.15 mm as broken or faded under offset lithography. Therefore, all connective lines use a minimum stroke of 0.25 mm–0.5 mm.
- The name "Aarav Mehta" is set at 6.2 mm cap height (~17.5 pt) in Space Grotesk Bold, ensuring immediate optical dominance.
- The secondary metadata and contact rows use a 2.1 mm x-height (~6 pt) in Inter SemiBold, which exceeds standard print legibility thresholds (ISO 12647-2).

### 2. Bleed & Trim Tolerances
Industrial high-speed guillotine cutters encounter slight mechanical drift (typically ±0.5 mm to ±1.5 mm).
- By extending the background fill and non-critical ambient vector arcs through the 3.0 mm bleed zone (91 × 61 mm), any cutter drift produces clean edge-to-edge color without accidental white slivers.
- Essential typography and the vCard QR code are kept inside the 4.0 mm safe zone (77 × 47 mm), guaranteeing a minimum 4.0 mm clearance from the trimmed edge.

### 3. Vector Logo Geometry & Brand Continuity
The Aivanta logo mark was engineered around a dynamic 60-degree kinetic delta:
- The left ascending stem in Electric Blue (`#3867FF`) establishes stability and computational rigor.
- The forward looping wing in Aqua (`#48D9D0`) represents adaptive velocity, agility, and continuous motion.
- The central focal node (`#FFFFFF`) signifies core neural focus.
- The logo maintains identical proportions on both sides: 28 mm scale on Front, 18 mm scale on Back.

### 4. Reproduction in Figma / Adobe Illustrator / Canva
If opening or modifying in design software:
1. **Canvas Setup:** Create an artboard measuring **91 mm × 61 mm**.
2. **Guides:** Drag vertical guides at **3 mm** and **88 mm**, and horizontal guides at **3 mm** and **58 mm** to demarcate the 85 × 55 mm trim boundary.
3. **Safe Zone Guides:** Drag guides at **7 mm** and **84 mm** (vertical) and **7 mm** and **54 mm** (horizontal).
4. **Color Profile:** Convert working space to **U.S. Web Coated (SWOP) v2** or **ISO Coated v2 (ECI)** for offset print.
5. **PDF Export:** Export as **PDF/X-1a:2001** or **PDF/X-4** with trim marks enabled and 3 mm document bleed settings.
