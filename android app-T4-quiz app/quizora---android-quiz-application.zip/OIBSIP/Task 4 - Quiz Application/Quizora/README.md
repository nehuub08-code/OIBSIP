# Quizora — Android Quiz Application

> **Oasis Infobyte Internship — Task 4**  
> **Developer:** Neha Vinod Borkar  
> **Track:** Android App Development  
> **Repository:** OIBSIP  
> **Task Title:** Task 4 — Quiz Application  

---

## 📱 Project Overview

**Quizora** is a native, offline Android quiz application built using **Java** and **XML layouts** in **Android Studio**. It presents users with 10 engaging General Knowledge questions spanning astronomy, computer science, world geography, history, and natural sciences.

The application features:
- Immediate **green/red visual feedback** upon selecting an option.
- Answer-locking to prevent accidental multiple selections.
- Real-time progress bar and question counter.
- Dynamic score evaluation with customized feedback messages.
- Shuffled question order on each attempt while maintaining question-answer integrity.
- Zero network dependencies — runs 100% offline.

---

## 🛠️ Tech Stack & Requirements

| Property | Value |
|---|---|
| **Platform** | Native Android (AOSP) |
| **Language** | Java 8 (JDK 1.8) |
| **UI Framework** | Native Android XML Layouts & Material Components |
| **Minimum SDK** | API Level 21 (Android 5.0 Lollipop) |
| **Target / Compile SDK** | API Level 34 (Android 14) |
| **Build System** | Gradle 8.2.2 / Android Gradle Plugin 8.2.2 |
| **Architecture** | Model-View-Activity with Android Intents |

---

## 📂 Project Structure

```text
OIBSIP/
└── Task 4 - Quiz Application/
    └── Quizora/
        ├── app/
        │   ├── build.gradle
        │   └── src/
        │       └── main/
        │           ├── AndroidManifest.xml
        │           ├── java/com/nehaborkar/quizora/
        │           │   ├── MainActivity.java      // Welcome screen & start session
        │           │   ├── QuizActivity.java      // Question engine, feedback & scoring
        │           │   ├── ResultActivity.java    // Score breakdown & restart handling
        │           │   ├── data/
        │           │   │   └── QuizData.java      // Local offline question bank
        │           │   └── model/
        │           │       └── Question.java      // Question data model
        │           └── res/
        │               ├── drawable/              // Custom rounded card and badge styles
        │               ├── layout/
        │               │   ├── activity_main.xml
        │               │   ├── activity_quiz.xml
        │               │   └── activity_result.xml
        │               └── values/
        │                   ├── colors.xml
        │                   ├── strings.xml
        │                   └── themes.xml
        ├── build.gradle
        ├── settings.gradle
        └── README.md
```

---

## 🚀 How to Run in Android Studio

1. **Clone or Download the Repository:**
   ```bash
   git clone https://github.com/your-username/OIBSIP.git
   ```
2. **Open Project:**
   - Launch **Android Studio** (Hedgehog, Iguana, Koala, or Ladybug).
   - Click **File > Open...** and navigate to `OIBSIP/Task 4 - Quiz Application/Quizora`.
3. **Gradle Sync:**
   - Allow Android Studio to download dependencies and sync Gradle.
4. **Run Application:**
   - Select an Android Virtual Device (AVD, e.g., Pixel 7 API 34) or connect a physical phone with USB Debugging enabled.
   - Click the green **Run (Shift + F10)** button.

---

## 🧠 Question Shuffling & Scoring Logic

1. **Question Model (`Question.java`):**
   - Each question holds its prompt, an array of 4 distinct choices, the verified correct string, and an explanation.
   - Validation inside constructor guarantees exactly 4 options and that the correct answer exists within the options.

2. **Offline Bank & Shuffling (`QuizData.java`):**
   - Stores 15 high-quality General Knowledge questions offline.
   - Calling `QuizData.getShuffledQuiz(10)` clones the list, performs a pseudorandom `Collections.shuffle()`, and retrieves 10 questions.
   - Because each `Question` object encapsulates its own options and correct answer, shuffling preserves the integrity of each question.

3. **State & Single-Selection Locking (`QuizActivity.java`):**
   - As soon as an option card is tapped, `isAnswerSubmitted` becomes `true` and click listeners are immediately disabled.
   - Score increases by 1 if correct; incorrect counter increments if wrong.
   - The user cannot tap another choice or score multiple points.
   - `onSaveInstanceState` preserves state across screen orientation changes.

4. **Result Calculation & Performance Grading (`ResultActivity.java`):**
   - Receives total questions, correct count, incorrect count, and score via Android Intent extras.
   - Grading thresholds:
     - **9–10 Correct:** *"Excellent work! You have mastered these General Knowledge topics!"*
     - **7–8 Correct:** *"Great job! Strong understanding with great precision."*
     - **4–6 Correct:** *"Good effort — keep practicing! You're building a solid foundation."*
     - **0–3 Correct:** *"Keep learning. You can improve! Review the explanations and try again!"*

---

## ✅ Comprehensive Verification Checklist (17/17 Passed)

| # | Test Case | Status |
|---|---|---|
| 1 | Welcome screen opens with Quizora title and Start Quiz button | ✅ Verified |
| 2 | Start Quiz navigates to Question 1 of 10 | ✅ Verified |
| 3 | At least 10 distinct questions loaded offline | ✅ Verified (15 available, 10 selected) |
| 4 | Each question contains exactly 4 answer options | ✅ Verified |
| 5 | Selecting correct answer gives immediate Green feedback | ✅ Verified |
| 6 | Selecting wrong answer gives immediate Red feedback | ✅ Verified |
| 7 | Correct option is also highlighted in green upon wrong answer | ✅ Verified |
| 8 | Question cannot be scored more than once (selection lock) | ✅ Verified |
| 9 | Next button prevents skipping unanswered questions | ✅ Verified (Shows warning toast) |
| 10 | Question counter and progress bar update smoothly | ✅ Verified |
| 11 | Final question navigates to ResultActivity | ✅ Verified |
| 12 | Final score matches recorded answers | ✅ Verified |
| 13 | Correct + Incorrect counts equal total questions | ✅ Verified |
| 14 | Restart Quiz resets score to 0 and starts fresh session | ✅ Verified |
| 15 | Question order is shuffled for new sessions | ✅ Verified |
| 16 | Rapid clicking does not cause duplicate scoring or crashes | ✅ Verified |
| 17 | Responsive XML layouts look crisp on phones and tablets | ✅ Verified |

---

## 🎥 Demonstration Video Sequence

As specified in the internship guidelines, the video demonstration follows this exact flow:
1. **Title Card (2+ seconds):**
   - Full Name: Neha Vinod Borkar
   - Assigned Track: Android App Development
   - Task Title: Task 4 — Quiz Application
2. **Welcome Screen:** Tap **Start Quiz**.
3. **Question 1:** Select the correct answer (showcases green card, checkmark, and explanation).
4. **Question 2:** Select an incorrect answer (showcases red card, revealed correct answer, and explanation).
5. **Progression:** Move through questions demonstrating progress bar advancing.
6. **Results Screen:** Displays final score, percentage, correct/incorrect counters, and tailored message.
7. **Restart:** Tap **Restart Quiz** and verify questions are re-shuffled and score is reset to 0.

---

## 👩‍💻 Developer Information

- **Name:** Neha Vinod Borkar  
- **Email:** nehaborkar2408@gmail.com  
- **Internship:** Oasis Infobyte (OIP) Android App Development  
- **Task:** Task 4 — Quiz Application  
