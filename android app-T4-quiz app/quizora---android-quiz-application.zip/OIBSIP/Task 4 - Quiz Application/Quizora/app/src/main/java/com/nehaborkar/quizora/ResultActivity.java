package com.nehaborkar.quizora;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * ResultActivity — Displays the final quiz outcome.
 * 
 * Shows:
 * - "Quiz Completed!" header
 * - Final score: e.g. "7 / 10" and percentage "70%"
 * - Total correct answers
 * - Total incorrect answers
 * - Dynamic performance feedback message based on performance
 * - "Restart Quiz" button: fresh shuffled session
 * - "Back to Home" button: returns to MainActivity
 * 
 * Developer: Neha Vinod Borkar
 * Oasis Infobyte Task 4 — Quiz Application
 */
public class ResultActivity extends AppCompatActivity {

    private TextView tvScoreDisplay;
    private TextView tvScorePercent;
    private TextView tvPerformanceMessage;
    private TextView tvCorrectCount;
    private TextView tvIncorrectCount;
    private TextView tvTotalCount;

    private Button btnRestartQuiz;
    private Button btnBackHome;

    private int totalQuestions = 10;
    private int correctCount = 0;
    private int incorrectCount = 0;
    private int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        initViews();
        retrieveIntentData();
        populateResults();
        setupListeners();
    }

    private void initViews() {
        tvScoreDisplay = findViewById(R.id.tvScoreDisplay);
        tvScorePercent = findViewById(R.id.tvScorePercent);
        tvPerformanceMessage = findViewById(R.id.tvPerformanceMessage);
        tvCorrectCount = findViewById(R.id.tvCorrectCount);
        tvIncorrectCount = findViewById(R.id.tvIncorrectCount);
        tvTotalCount = findViewById(R.id.tvTotalCount);

        btnRestartQuiz = findViewById(R.id.btnRestartQuiz);
        btnBackHome = findViewById(R.id.btnBackHome);
    }

    private void retrieveIntentData() {
        Intent intent = getIntent();
        if (intent != null) {
            totalQuestions = intent.getIntExtra(QuizActivity.EXTRA_TOTAL_QUESTIONS, 10);
            correctCount = intent.getIntExtra(QuizActivity.EXTRA_CORRECT_COUNT, 0);
            incorrectCount = intent.getIntExtra(QuizActivity.EXTRA_INCORRECT_COUNT, 0);
            score = intent.getIntExtra(QuizActivity.EXTRA_SCORE, 0);
        }
    }

    private void populateResults() {
        // Display score "X / Y"
        tvScoreDisplay.setText(score + " / " + totalQuestions);

        // Percentage
        int percentage = totalQuestions > 0 ? (int) Math.round(((double) score / totalQuestions) * 100) : 0;
        tvScorePercent.setText(percentage + "% Score");

        // Stat cards
        tvCorrectCount.setText(String.valueOf(correctCount));
        tvIncorrectCount.setText(String.valueOf(incorrectCount));
        tvTotalCount.setText(String.valueOf(totalQuestions));

        // Performance evaluation based on actual score criteria
        String message;
        if (score >= 9) {
            message = "🌟 Excellent work!\nYou have mastered these General Knowledge topics!";
        } else if (score >= 7) {
            message = "👏 Great job!\nStrong understanding with great precision.";
        } else if (score >= 4) {
            message = "💡 Good effort — keep practicing!\nYou're building a solid foundation.";
        } else {
            message = "📚 Keep learning. You can improve!\nReview the explanations and try again!";
        }
        tvPerformanceMessage.setText(message);
    }

    private void setupListeners() {
        // Restart Quiz: launch new QuizActivity session (re-shuffled & fresh score)
        btnRestartQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultActivity.this, QuizActivity.class);
                startActivity(intent);
                finish(); // Close ResultActivity
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });

        // Back to Home: return to MainActivity
        btnBackHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });
    }
}
