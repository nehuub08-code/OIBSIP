package com.nehaborkar.quizora;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.nehaborkar.quizora.data.QuizData;
import com.nehaborkar.quizora.model.Question;

import java.util.ArrayList;
import java.util.List;

/**
 * QuizActivity — Handles question display, answer selection,
 * immediate green/red feedback, single-selection lock, and score calculation.
 * 
 * Developer: Neha Vinod Borkar
 * Oasis Infobyte Task 4 — Quiz Application
 */
public class QuizActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String EXTRA_TOTAL_QUESTIONS = "extra_total_questions";
    public static final String EXTRA_CORRECT_COUNT = "extra_correct_count";
    public static final String EXTRA_INCORRECT_COUNT = "extra_incorrect_count";
    public static final String EXTRA_SCORE = "extra_score";

    private static final int TOTAL_QUIZ_QUESTIONS = 10;

    // UI elements
    private TextView tvQuestionCounter;
    private TextView tvCategoryBadge;
    private TextView tvQuestionText;
    private ProgressBar progressBarQuiz;

    private LinearLayout[] optionCards;
    private TextView[] tvOptionLetters;
    private TextView[] tvOptionTexts;

    private LinearLayout layoutFeedback;
    private TextView tvFeedbackTitle;
    private TextView tvFeedbackExplanation;

    private Button btnNext;

    // State variables
    private ArrayList<Question> questionList;
    private int currentQuestionIndex = 0;
    private int correctCount = 0;
    private int incorrectCount = 0;
    private int score = 0;

    private boolean isAnswerSubmitted = false;
    private int selectedOptionIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        initViews();
        setupOptionClicks();

        if (savedInstanceState != null) {
            // Restore state on configuration change (e.g., screen rotation)
            questionList = (ArrayList<Question>) savedInstanceState.getSerializable("questionList");
            currentQuestionIndex = savedInstanceState.getInt("currentQuestionIndex", 0);
            correctCount = savedInstanceState.getInt("correctCount", 0);
            incorrectCount = savedInstanceState.getInt("incorrectCount", 0);
            score = savedInstanceState.getInt("score", 0);
            isAnswerSubmitted = savedInstanceState.getBoolean("isAnswerSubmitted", false);
            selectedOptionIndex = savedInstanceState.getInt("selectedOptionIndex", -1);
        } else {
            // Start fresh session with 10 shuffled questions
            questionList = new ArrayList<>(QuizData.getShuffledQuiz(TOTAL_QUIZ_QUESTIONS));
            currentQuestionIndex = 0;
            correctCount = 0;
            incorrectCount = 0;
            score = 0;
            isAnswerSubmitted = false;
            selectedOptionIndex = -1;
        }

        displayQuestion(currentQuestionIndex);

        // If answer was already submitted before orientation change, re-apply feedback
        if (isAnswerSubmitted && selectedOptionIndex != -1) {
            applyFeedbackUI(selectedOptionIndex);
        }
    }

    private void initViews() {
        tvQuestionCounter = findViewById(R.id.tvQuestionCounter);
        tvCategoryBadge = findViewById(R.id.tvCategoryBadge);
        tvQuestionText = findViewById(R.id.tvQuestionText);
        progressBarQuiz = findViewById(R.id.progressBarQuiz);

        optionCards = new LinearLayout[4];
        tvOptionLetters = new TextView[4];
        tvOptionTexts = new TextView[4];

        optionCards[0] = findViewById(R.id.layoutOption1);
        optionCards[1] = findViewById(R.id.layoutOption2);
        optionCards[2] = findViewById(R.id.layoutOption3);
        optionCards[3] = findViewById(R.id.layoutOption4);

        tvOptionLetters[0] = findViewById(R.id.tvOptionLetter1);
        tvOptionLetters[1] = findViewById(R.id.tvOptionLetter2);
        tvOptionLetters[2] = findViewById(R.id.tvOptionLetter3);
        tvOptionLetters[3] = findViewById(R.id.tvOptionLetter4);

        tvOptionTexts[0] = findViewById(R.id.tvOptionText1);
        tvOptionTexts[1] = findViewById(R.id.tvOptionText2);
        tvOptionTexts[2] = findViewById(R.id.tvOptionText3);
        tvOptionTexts[3] = findViewById(R.id.tvOptionText4);

        layoutFeedback = findViewById(R.id.layoutFeedback);
        tvFeedbackTitle = findViewById(R.id.tvFeedbackTitle);
        tvFeedbackExplanation = findViewById(R.id.tvFeedbackExplanation);

        btnNext = findViewById(R.id.btnNext);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onNextButtonClicked();
            }
        });
    }

    private void setupOptionClicks() {
        for (int i = 0; i < optionCards.length; i++) {
            optionCards[i].setOnClickListener(this);
        }
    }

    private void displayQuestion(int index) {
        if (index < 0 || index >= questionList.size()) return;

        Question currentQuestion = questionList.get(index);

        // Update Counter: "Question X of 10"
        tvQuestionCounter.setText(getString(R.string.question_counter, (index + 1), questionList.size()));

        // Update Progress Bar (10% per question)
        int progress = (int) (((index + 1) / (float) questionList.size()) * 100);
        progressBarQuiz.setProgress(progress);

        // Category & Question text
        tvCategoryBadge.setText(currentQuestion.getCategory());
        tvQuestionText.setText(currentQuestion.getQuestionText());

        // Update 4 options text
        String[] options = currentQuestion.getOptions();
        for (int i = 0; i < 4; i++) {
            tvOptionTexts[i].setText(options[i]);
            resetOptionStyle(i);
            optionCards[i].setClickable(true);
        }

        // Hide feedback container
        layoutFeedback.setVisibility(View.GONE);

        // Update Next button label on final question
        if (index == questionList.size() - 1) {
            btnNext.setText(R.string.view_results);
        } else {
            btnNext.setText(R.string.next_question);
        }

        // Reset per-question state
        isAnswerSubmitted = false;
        selectedOptionIndex = -1;
    }

    private void resetOptionStyle(int index) {
        optionCards[index].setBackgroundResource(R.drawable.bg_option_default);
        tvOptionLetters[index].setBackgroundResource(R.drawable.bg_option_badge_default);
        tvOptionLetters[index].setTextColor(ContextCompat.getColor(this, R.color.text_primary));
        tvOptionTexts[index].setTextColor(ContextCompat.getColor(this, R.color.text_primary));
    }

    @Override
    public void onClick(View v) {
        // Prevent answer change if already submitted
        if (isAnswerSubmitted) {
            return;
        }

        int clickedIndex = -1;
        int id = v.getId();
        if (id == R.id.layoutOption1) clickedIndex = 0;
        else if (id == R.id.layoutOption2) clickedIndex = 1;
        else if (id == R.id.layoutOption3) clickedIndex = 2;
        else if (id == R.id.layoutOption4) clickedIndex = 3;

        if (clickedIndex != -1) {
            handleAnswerSelection(clickedIndex);
        }
    }

    private void handleAnswerSelection(int optionIndex) {
        isAnswerSubmitted = true;
        selectedOptionIndex = optionIndex;

        // Disable all option clicks so user cannot change answer
        for (LinearLayout card : optionCards) {
            card.setClickable(false);
        }

        Question question = questionList.get(currentQuestionIndex);
        String selectedAnswer = question.getOptions()[optionIndex];
        boolean isCorrect = question.isCorrect(selectedAnswer);

        // Score update rule: single update per question
        if (isCorrect) {
            score++;
            correctCount++;
        } else {
            incorrectCount++;
        }

        applyFeedbackUI(optionIndex);
    }

    private void applyFeedbackUI(int optionIndex) {
        Question question = questionList.get(currentQuestionIndex);
        String selectedAnswer = question.getOptions()[optionIndex];
        boolean isCorrect = question.isCorrect(selectedAnswer);

        // Highlight selected answer
        if (isCorrect) {
            optionCards[optionIndex].setBackgroundResource(R.drawable.bg_option_correct);
            tvOptionLetters[optionIndex].setBackgroundResource(R.drawable.bg_option_badge_correct);
            tvOptionLetters[optionIndex].setTextColor(ContextCompat.getColor(this, R.color.white));
            tvOptionTexts[optionIndex].setTextColor(ContextCompat.getColor(this, R.color.feedback_correct_dark));

            // Positive Feedback Banner
            layoutFeedback.setVisibility(View.VISIBLE);
            layoutFeedback.setBackgroundResource(R.drawable.bg_feedback_correct);
            tvFeedbackTitle.setText("🎉 Correct!");
            tvFeedbackTitle.setTextColor(ContextCompat.getColor(this, R.color.feedback_correct_dark));
            tvFeedbackExplanation.setText(question.getExplanation());
        } else {
            // Selected was incorrect -> Red
            optionCards[optionIndex].setBackgroundResource(R.drawable.bg_option_wrong);
            tvOptionLetters[optionIndex].setBackgroundResource(R.drawable.bg_option_badge_wrong);
            tvOptionLetters[optionIndex].setTextColor(ContextCompat.getColor(this, R.color.white));
            tvOptionTexts[optionIndex].setTextColor(ContextCompat.getColor(this, R.color.feedback_wrong_dark));

            // Find correct option and highlight green
            for (int i = 0; i < 4; i++) {
                if (question.getOptions()[i].equalsIgnoreCase(question.getCorrectAnswer())) {
                    optionCards[i].setBackgroundResource(R.drawable.bg_option_correct);
                    tvOptionLetters[i].setBackgroundResource(R.drawable.bg_option_badge_correct);
                    tvOptionLetters[i].setTextColor(ContextCompat.getColor(this, R.color.white));
                    tvOptionTexts[i].setTextColor(ContextCompat.getColor(this, R.color.feedback_correct_dark));
                    break;
                }
            }

            // Negative Feedback Banner
            layoutFeedback.setVisibility(View.VISIBLE);
            layoutFeedback.setBackgroundResource(R.drawable.bg_feedback_wrong);
            tvFeedbackTitle.setText("❌ Not quite!");
            tvFeedbackTitle.setTextColor(ContextCompat.getColor(this, R.color.feedback_wrong_dark));
            tvFeedbackExplanation.setText("Correct Answer: " + question.getCorrectAnswer() + "\n" + question.getExplanation());
        }
    }

    private void onNextButtonClicked() {
        // Enforce answering current question
        if (!isAnswerSubmitted) {
            Toast.makeText(this, "Please select an answer to continue!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if more questions remain
        if (currentQuestionIndex < questionList.size() - 1) {
            currentQuestionIndex++;
            displayQuestion(currentQuestionIndex);
        } else {
            // All questions answered -> navigate to ResultActivity
            navigateToResults();
        }
    }

    private void navigateToResults() {
        Intent intent = new Intent(QuizActivity.this, ResultActivity.class);
        intent.putExtra(EXTRA_TOTAL_QUESTIONS, questionList.size());
        intent.putExtra(EXTRA_CORRECT_COUNT, correctCount);
        intent.putExtra(EXTRA_INCORRECT_COUNT, incorrectCount);
        intent.putExtra(EXTRA_SCORE, score);
        startActivity(intent);
        finish(); // Finish QuizActivity so Back button won't return to completed questions
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("questionList", questionList);
        outState.putInt("currentQuestionIndex", currentQuestionIndex);
        outState.putInt("correctCount", correctCount);
        outState.putInt("incorrectCount", incorrectCount);
        outState.putInt("score", score);
        outState.putBoolean("isAnswerSubmitted", isAnswerSubmitted);
        outState.putInt("selectedOptionIndex", selectedOptionIndex);
    }
}
