package com.nehaborkar.quizora.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Model representing a single Quiz Question.
 * Includes question prompt, exactly 4 answer options, the correct answer,
 * an explanation, and the topic category.
 * 
 * Developer: Neha Vinod Borkar
 * Oasis Infobyte Task 4 — Quiz Application
 */
public class Question implements Serializable {
    private String questionText;
    private String[] options;
    private String correctAnswer;
    private String explanation;
    private String category;

    public Question(String questionText, String[] options, String correctAnswer, String explanation, String category) {
        if (options == null || options.length != 4) {
            throw new IllegalArgumentException("Question must have exactly four options.");
        }
        boolean matchFound = false;
        for (String opt : options) {
            if (opt.equalsIgnoreCase(correctAnswer)) {
                matchFound = true;
                break;
            }
        }
        if (!matchFound) {
            throw new IllegalArgumentException("Correct answer must match one of the four options.");
        }

        this.questionText = questionText;
        this.options = options;
        this.correctAnswer = correctAnswer;
        this.explanation = explanation;
        this.category = category;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String[] getOptions() {
        return options;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public String getExplanation() {
        return explanation;
    }

    public String getCategory() {
        return category;
    }

    /**
     * Checks if a given answer is correct.
     */
    public boolean isCorrect(String selectedAnswer) {
        return correctAnswer != null && correctAnswer.equalsIgnoreCase(selectedAnswer);
    }
}
