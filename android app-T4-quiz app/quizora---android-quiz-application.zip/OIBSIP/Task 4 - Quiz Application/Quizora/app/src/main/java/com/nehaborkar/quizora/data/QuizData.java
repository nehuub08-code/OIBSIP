package com.nehaborkar.quizora.data;

import com.nehaborkar.quizora.model.Question;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Question bank for Quizora.
 * Contains 15 comprehensive General Knowledge questions spanning Science,
 * Geography, History, Computers, Space, and Literature.
 * Fully offline, no network or API keys required.
 * 
 * Developer: Neha Vinod Borkar
 * Oasis Infobyte Task 4 — Quiz Application
 */
public class QuizData {

    /**
     * Returns the master list of all available General Knowledge questions.
     */
    public static List<Question> getAllQuestions() {
        List<Question> questions = new ArrayList<>();

        questions.add(new Question(
                "Which planet in our solar system is known as the Red Planet?",
                new String[]{"Venus", "Mars", "Jupiter", "Saturn"},
                "Mars",
                "Mars appears reddish due to iron oxide (rust) covering its surface.",
                "Space & Astronomy"
        ));

        questions.add(new Question(
                "Who wrote the famous romantic tragedy 'Romeo and Juliet'?",
                new String[]{"Charles Dickens", "William Shakespeare", "Mark Twain", "Jane Austen"},
                "William Shakespeare",
                "William Shakespeare wrote Romeo and Juliet early in his career around 1595.",
                "Literature & Arts"
        ));

        questions.add(new Question(
                "What is widely considered the powerhouse of the biological cell?",
                new String[]{"Nucleus", "Mitochondria", "Ribosome", "Endoplasmic Reticulum"},
                "Mitochondria",
                "Mitochondria generate ATP (adenosine triphosphate), the chemical energy currency of cells.",
                "Science & Biology"
        ));

        questions.add(new Question(
                "What is the chemical symbol for Gold in the Periodic Table?",
                new String[]{"Gd", "Ag", "Au", "Fe"},
                "Au",
                "Au originates from 'Aurum', the Latin word signifying glowing dawn or gold.",
                "Science & Chemistry"
        ));

        questions.add(new Question(
                "Which is the longest river in the world by total length?",
                new String[]{"Amazon River", "Nile River", "Yangtze River", "Mississippi River"},
                "Nile River",
                "The Nile River extends approximately 6,650 km (4,132 miles) through northeastern Africa.",
                "Geography"
        ));

        questions.add(new Question(
                "In computer technology, what does the acronym 'RAM' stand for?",
                new String[]{"Read Access Memory", "Random Access Memory", "Run Action Module", "Real Audio Matrix"},
                "Random Access Memory",
                "RAM provides quick read/write storage that the processor accesses actively.",
                "Computer Science"
        ));

        questions.add(new Question(
                "In which year did Apollo 11 successfully land humans on the Moon?",
                new String[]{"1965", "1969", "1972", "1975"},
                "1969",
                "Commander Neil Armstrong stepped onto the lunar surface on July 20, 1969.",
                "History & Space"
        ));

        questions.add(new Question(
                "Which gas makes up approximately 78% of Earth's atmosphere?",
                new String[]{"Oxygen", "Carbon Dioxide", "Nitrogen", "Argon"},
                "Nitrogen",
                "Nitrogen comprises roughly 78.08% of dry air, with oxygen taking about 20.95%.",
                "Earth Science"
        ));

        questions.add(new Question(
                "Which Asian country is famously referred to as the 'Land of the Rising Sun'?",
                new String[]{"China", "Japan", "South Korea", "Thailand"},
                "Japan",
                "The name Nippon or Nihon means 'sun origin' relative to mainland Asia.",
                "Geography"
        ));

        questions.add(new Question(
                "Who is historically acclaimed as the 'Father of Computers'?",
                new String[]{"Alan Turing", "Charles Babbage", "John von Neumann", "Ada Lovelace"},
                "Charles Babbage",
                "Charles Babbage originated the concept of a programmable mechanical computer in the 1830s.",
                "Computer Science"
        ));

        questions.add(new Question(
                "What is the hardest naturally occurring mineral substance on Earth?",
                new String[]{"Titanium", "Graphene", "Diamond", "Quartz"},
                "Diamond",
                "Diamond scores a maximum 10 on Mohs scale because of its rigid covalent carbon lattice.",
                "Science"
        ));

        questions.add(new Question(
                "Which ocean is the largest and deepest on planet Earth?",
                new String[]{"Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"},
                "Pacific Ocean",
                "The Pacific Ocean spans more than 63 million square miles and holds Challenger Deep.",
                "Geography"
        ));

        questions.add(new Question(
                "Approximately what is the speed of light in a vacuum?",
                new String[]{"150,000 km/s", "300,000 km/s", "450,000 km/s", "600,000 km/s"},
                "300,000 km/s",
                "The speed of light in vacuum is exactly 299,792,458 m/s, approximately 300,000 km/s.",
                "Physics"
        ));

        questions.add(new Question(
                "Which programming language was originally used as the primary language for Android apps?",
                new String[]{"Swift", "Java", "Ruby", "PHP"},
                "Java",
                "Android SDK was built around Java, supported alongside Kotlin by Google.",
                "Technology"
        ));

        questions.add(new Question(
                "Which organ in the human body secretes insulin to regulate blood glucose?",
                new String[]{"Liver", "Kidney", "Pancreas", "Gallbladder"},
                "Pancreas",
                "The endocrine islets of the pancreas produce insulin and glucagon.",
                "Biology"
        ));

        return questions;
    }

    /**
     * Shuffles the questions and returns a subset of requested size (e.g. 10 questions).
     * The relationship between each question and its correct answer is strictly preserved.
     */
    public static List<Question> getShuffledQuiz(int questionCount) {
        List<Question> list = new ArrayList<>(getAllQuestions());
        Collections.shuffle(list);
        if (questionCount > 0 && questionCount <= list.size()) {
            return new ArrayList<>(list.subList(0, questionCount));
        }
        return list;
    }
}
