package com.nehaborkar.quizora;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * MainActivity — Welcome Screen for Quizora.
 * 
 * Features:
 * - App title and Quiz illustration/badge
 * - Heading: "Ready to Test Your Knowledge?"
 * - Description highlighting 10 General Knowledge questions
 * - "Start Quiz" button that launches QuizActivity with a fresh shuffled session
 * 
 * Developer: Neha Vinod Borkar
 * Oasis Infobyte Task 4 — Quiz Application
 */
public class MainActivity extends AppCompatActivity {

    private Button btnStartQuiz;
    private TextView tvSubheading, tvDeveloperCredit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupListeners();
    }

    private void initViews() {
        btnStartQuiz = findViewById(R.id.btnStartQuiz);
        tvSubheading = findViewById(R.id.tvSubheading);
        tvDeveloperCredit = findViewById(R.id.tvDeveloperCredit);
    }

    private void setupListeners() {
        btnStartQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Launch QuizActivity to start a new quiz session
                Intent intent = new Intent(MainActivity.this, QuizActivity.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });
    }
}
