import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES } from './androidProjectFiles';

export async function downloadAndroidProjectZip() {
  const zip = new JSZip();
  const rootFolder = zip.folder("Quizora");

  if (!rootFolder) return;

  // Add settings.gradle
  rootFolder.file("settings.gradle", `rootProject.name = "Quizora"\ninclude ':app'\n`);

  // Add root build.gradle
  rootFolder.file("build.gradle", `// Top-level build file
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath "com.android.tools.build:gradle:8.2.2"
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
`);

  // Add gradle.properties
  rootFolder.file("gradle.properties", `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\nandroid.enableJetifier=true\n`);

  // Add files from project
  for (const file of ANDROID_PROJECT_FILES) {
    rootFolder.file(file.path, file.content);
  }

  // Add README
  rootFolder.file("README.md", `# Quizora — Android Quiz Application
Developed by Neha Vinod Borkar for Oasis Infobyte Task 4.
Open this root folder directly in Android Studio.
`);

  const content = await zip.generateAsync({ type: 'blob' });
  const downloadUrl = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = downloadUrl;
  a.download = 'Quizora_Android_Studio_Project.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(downloadUrl);
}
