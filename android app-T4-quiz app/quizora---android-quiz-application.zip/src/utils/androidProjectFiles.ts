/**
 * Contains complete source code of the Android Studio project
 * to allow live code inspection and 1-click ZIP generation.
 */

export interface AndroidFile {
  name: string;
  path: string;
  language: 'java' | 'xml' | 'groovy' | 'markdown';
  content: string;
  category: 'java' | 'layout' | 'values' | 'drawable' | 'config' | 'doc';
}

export const ANDROID_PROJECT_FILES: AndroidFile[] = [
  {
    name: "MainActivity.java",
    path: "app/src/main/java/com/nehaborkar/quizora/MainActivity.java",
    language: "java",
    category: "java",
    content: `package com.nehaborkar.quizora;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * MainActivity — Welcome Screen for Quizora.
 * 
 * Features:
 * - App title and Quiz illustration/badge
 * - Heading: "Ready to Test Your Knowledge?"
 * - Description highlighting 10 General Knowledge questions
 * - "Start Quiz" button that launches QuizActivity with a fresh shuffled session
 * 
 * Developer: Neha Vinod Borkar
 * Oasis Infobyte Task 4 — Quiz Application
 */
public class MainActivity extends AppCompatActivity {

    private Button btnStartQuiz;
    private TextView tvSubheading, tvDeveloperCredit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupListeners();
    }

    private void initViews() {
        btnStartQuiz = findViewById(R.id.btnStartQuiz);
        tvSubheading = findViewById(R.id.tvSubheading);
        tvDeveloperCredit = findViewById(R.id.tvDeveloperCredit);
    }

    private void setupListeners() {
        btnStartQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Launch QuizActivity to start a new quiz session
                Intent intent = new Intent(MainActivity.this, QuizActivity.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });
    }
}`
  },
  {
    name: "QuizActivity.java",
    path: "app/src/main/java/com/nehaborkar/quizora/QuizActivity.java",
    language: "java",
    category: "java",
    content: `package com.nehaborkar.quizora;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.nehaborkar.quizora.data.QuizData;
import com.nehaborkar.quizora.model.Question;

import java.util.ArrayList;
import java.util.List;

/**
 * QuizActivity — Handles question display, answer selection,
 * immediate green/red feedback, single-selection lock, and score calculation.
 * 
 * Developer: Neha Vinod Borkar
 * Oasis Infobyte Task 4 — Quiz Application
 */
public class QuizActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String EXTRA_TOTAL_QUESTIONS = "extra_total_questions";
    public static final String EXTRA_CORRECT_COUNT = "extra_correct_count";
    public static final String EXTRA_INCORRECT_COUNT = "extra_incorrect_count";
    public static final String EXTRA_SCORE = "extra_score";

    private static final int TOTAL_QUIZ_QUESTIONS = 10;

    // UI elements
    private TextView tvQuestionCounter;
    private TextView tvCategoryBadge;
    private TextView tvQuestionText;
    private ProgressBar progressBarQuiz;

    private LinearLayout[] optionCards;
    private TextView[] tvOptionLetters;
    private TextView[] tvOptionTexts;

    private LinearLayout layoutFeedback;
    private TextView tvFeedbackTitle;
    private TextView tvFeedbackExplanation;

    private Button btnNext;

    // State variables
    private ArrayList<Question> questionList;
    private int currentQuestionIndex = 0;
    private int correctCount = 0;
    private int incorrectCount = 0;
    private int score = 0;

    private boolean isAnswerSubmitted = false;
    private int selectedOptionIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        initViews();
        setupOptionClicks();

        if (savedInstanceState != null) {
            // Restore state on configuration change (e.g., screen rotation)
            questionList = (ArrayList<Question>) savedInstanceState.getSerializable("questionList");
            currentQuestionIndex = savedInstanceState.getInt("currentQuestionIndex", 0);
            correctCount = savedInstanceState.getInt("correctCount", 0);
            incorrectCount = savedInstanceState.getInt("incorrectCount", 0);
            score = savedInstanceState.getInt("score", 0);
            isAnswerSubmitted = savedInstanceState.getBoolean("isAnswerSubmitted", false);
            selectedOptionIndex = savedInstanceState.getInt("selectedOptionIndex", -1);
        } else {
            // Start fresh session with 10 shuffled questions
            questionList = new ArrayList<>(QuizData.getShuffledQuiz(TOTAL_QUIZ_QUESTIONS));
            currentQuestionIndex = 0;
            correctCount = 0;
            incorrectCount = 0;
            score = 0;
            isAnswerSubmitted = false;
            selectedOptionIndex = -1;
        }

        displayQuestion(currentQuestionIndex);

        // If answer was already submitted before orientation change, re-apply feedback
        if (isAnswerSubmitted && selectedOptionIndex != -1) {
            applyFeedbackUI(selectedOptionIndex);
        }
    }

    private void initViews() {
        tvQuestionCounter = findViewById(R.id.tvQuestionCounter);
        tvCategoryBadge = findViewById(R.id.tvCategoryBadge);
        tvQuestionText = findViewById(R.id.tvQuestionText);
        progressBarQuiz = findViewById(R.id.progressBarQuiz);

        optionCards = new LinearLayout[4];
        tvOptionLetters = new TextView[4];
        tvOptionTexts = new TextView[4];

        optionCards[0] = findViewById(R.id.layoutOption1);
        optionCards[1] = findViewById(R.id.layoutOption2);
        optionCards[2] = findViewById(R.id.layoutOption3);
        optionCards[3] = findViewById(R.id.layoutOption4);

        tvOptionLetters[0] = findViewById(R.id.tvOptionLetter1);
        tvOptionLetters[1] = findViewById(R.id.tvOptionLetter2);
        tvOptionLetters[2] = findViewById(R.id.tvOptionLetter3);
        tvOptionLetters[3] = findViewById(R.id.tvOptionLetter4);

        tvOptionTexts[0] = findViewById(R.id.tvOptionText1);
        tvOptionTexts[1] = findViewById(R.id.tvOptionText2);
        tvOptionTexts[2] = findViewById(R.id.tvOptionText3);
        tvOptionTexts[3] = findViewById(R.id.tvOptionText4);

        layoutFeedback = findViewById(R.id.layoutFeedback);
        tvFeedbackTitle = findViewById(R.id.tvFeedbackTitle);
        tvFeedbackExplanation = findViewById(R.id.tvFeedbackExplanation);

        btnNext = findViewById(R.id.btnNext);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onNextButtonClicked();
            }
        });
    }

    private void setupOptionClicks() {
        for (int i = 0; i < optionCards.length; i++) {
            optionCards[i].setOnClickListener(this);
        }
    }

    private void displayQuestion(int index) {
        if (index < 0 || index >= questionList.size()) return;

        Question currentQuestion = questionList.get(index);

        // Update Counter: "Question X of 10"
        tvQuestionCounter.setText(getString(R.string.question_counter, (index + 1), questionList.size()));

        // Update Progress Bar (10% per question)
        int progress = (int) (((index + 1) / (float) questionList.size()) * 100);
        progressBarQuiz.setProgress(progress);

        // Category & Question text
        tvCategoryBadge.setText(currentQuestion.getCategory());
        tvQuestionText.setText(currentQuestion.getQuestionText());

        // Update 4 options text
        String[] options = currentQuestion.getOptions();
        for (int i = 0; i < 4; i++) {
            tvOptionTexts[i].setText(options[i]);
            resetOptionStyle(i);
            optionCards[i].setClickable(true);
        }

        // Hide feedback container
        layoutFeedback.setVisibility(View.GONE);

        // Update Next button label on final question
        if (index == questionList.size() - 1) {
            btnNext.setText(R.string.view_results);
        } else {
            btnNext.setText(R.string.next_question);
        }

        // Reset per-question state
        isAnswerSubmitted = false;
        selectedOptionIndex = -1;
    }

    private void resetOptionStyle(int index) {
        optionCards[index].setBackgroundResource(R.drawable.bg_option_default);
        tvOptionLetters[index].setBackgroundResource(R.drawable.bg_option_badge_default);
        tvOptionLetters[index].setTextColor(ContextCompat.getColor(this, R.color.text_primary));
        tvOptionTexts[index].setTextColor(ContextCompat.getColor(this, R.color.text_primary));
    }

    @Override
    public void onClick(View v) {
        // Prevent answer change if already submitted
        if (isAnswerSubmitted) {
            return;
        }

        int clickedIndex = -1;
        int id = v.getId();
        if (id == R.id.layoutOption1) clickedIndex = 0;
        else if (id == R.id.layoutOption2) clickedIndex = 1;
        else if (id == R.id.layoutOption3) clickedIndex = 2;
        else if (id == R.id.layoutOption4) clickedIndex = 3;

        if (clickedIndex != -1) {
            handleAnswerSelection(clickedIndex);
        }
    }

    private void handleAnswerSelection(int optionIndex) {
        isAnswerSubmitted = true;
        selectedOptionIndex = optionIndex;

        // Disable all option clicks so user cannot change answer
        for (LinearLayout card : optionCards) {
            card.setClickable(false);
        }

        Question question = questionList.get(currentQuestionIndex);
        String selectedAnswer = question.getOptions()[optionIndex];
        boolean isCorrect = question.isCorrect(selectedAnswer);

        // Score update rule: single update per question
        if (isCorrect) {
            score++;
            correctCount++;
        } else {
            incorrectCount++;
        }

        applyFeedbackUI(optionIndex);
    }

    private void applyFeedbackUI(int optionIndex) {
        Question question = questionList.get(currentQuestionIndex);
        String selectedAnswer = question.getOptions()[optionIndex];
        boolean isCorrect = question.isCorrect(selectedAnswer);

        // Highlight selected answer
        if (isCorrect) {
            optionCards[optionIndex].setBackgroundResource(R.drawable.bg_option_correct);
            tvOptionLetters[optionIndex].setBackgroundResource(R.drawable.bg_option_badge_correct);
            tvOptionLetters[optionIndex].setTextColor(ContextCompat.getColor(this, R.color.white));
            tvOptionTexts[optionIndex].setTextColor(ContextCompat.getColor(this, R.color.feedback_correct_dark));

            // Positive Feedback Banner
            layoutFeedback.setVisibility(View.VISIBLE);
            layoutFeedback.setBackgroundResource(R.drawable.bg_feedback_correct);
            tvFeedbackTitle.setText("🎉 Correct!");
            tvFeedbackTitle.setTextColor(ContextCompat.getColor(this, R.color.feedback_correct_dark));
            tvFeedbackExplanation.setText(question.getExplanation());
        } else {
            // Selected was incorrect -> Red
            optionCards[optionIndex].setBackgroundResource(R.drawable.bg_option_wrong);
            tvOptionLetters[optionIndex].setBackgroundResource(R.drawable.bg_option_badge_wrong);
            tvOptionLetters[optionIndex].setTextColor(ContextCompat.getColor(this, R.color.white));
            tvOptionTexts[optionIndex].setTextColor(ContextCompat.getColor(this, R.color.feedback_wrong_dark));

            // Find correct option and highlight green
            for (int i = 0; i < 4; i++) {
                if (question.getOptions()[i].equalsIgnoreCase(question.getCorrectAnswer())) {
                    optionCards[i].setBackgroundResource(R.drawable.bg_option_correct);
                    tvOptionLetters[i].setBackgroundResource(R.drawable.bg_option_badge_correct);
                    tvOptionLetters[i].setTextColor(ContextCompat.getColor(this, R.color.white));
                    tvOptionTexts[i].setTextColor(ContextCompat.getColor(this, R.color.feedback_correct_dark));
                    break;
                }
            }

            // Negative Feedback Banner
            layoutFeedback.setVisibility(View.VISIBLE);
            layoutFeedback.setBackgroundResource(R.drawable.bg_feedback_wrong);
            tvFeedbackTitle.setText("❌ Not quite!");
            tvFeedbackTitle.setTextColor(ContextCompat.getColor(this, R.color.feedback_wrong_dark));
            tvFeedbackExplanation.setText("Correct Answer: " + question.getCorrectAnswer() + "\\n" + question.getExplanation());
        }
    }

    private void onNextButtonClicked() {
        // Enforce answering current question
        if (!isAnswerSubmitted) {
            Toast.makeText(this, "Please select an answer to continue!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if more questions remain
        if (currentQuestionIndex < questionList.size() - 1) {
            currentQuestionIndex++;
            displayQuestion(currentQuestionIndex);
        } else {
            // All questions answered -> navigate to ResultActivity
            navigateToResults();
        }
    }

    private void navigateToResults() {
        Intent intent = new Intent(QuizActivity.this, ResultActivity.class);
        intent.putExtra(EXTRA_TOTAL_QUESTIONS, questionList.size());
        intent.putExtra(EXTRA_CORRECT_COUNT, correctCount);
        intent.putExtra(EXTRA_INCORRECT_COUNT, incorrectCount);
        intent.putExtra(EXTRA_SCORE, score);
        startActivity(intent);
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("questionList", questionList);
        outState.putInt("currentQuestionIndex", currentQuestionIndex);
        outState.putInt("correctCount", correctCount);
        outState.putInt("incorrectCount", incorrectCount);
        outState.putInt("score", score);
        outState.putBoolean("isAnswerSubmitted", isAnswerSubmitted);
        outState.putInt("selectedOptionIndex", selectedOptionIndex);
    }
}`
  },
  {
    name: "ResultActivity.java",
    path: "app/src/main/java/com/nehaborkar/quizora/ResultActivity.java",
    language: "java",
    category: "java",
    content: `package com.nehaborkar.quizora;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * ResultActivity — Displays the final quiz outcome.
 * 
 * Developer: Neha Vinod Borkar
 * Oasis Infobyte Task 4 — Quiz Application
 */
public class ResultActivity extends AppCompatActivity {

    private TextView tvScoreDisplay;
    private TextView tvScorePercent;
    private TextView tvPerformanceMessage;
    private TextView tvCorrectCount;
    private TextView tvIncorrectCount;
    private TextView tvTotalCount;

    private Button btnRestartQuiz;
    private Button btnBackHome;

    private int totalQuestions = 10;
    private int correctCount = 0;
    private int incorrectCount = 0;
    private int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        initViews();
        retrieveIntentData();
        populateResults();
        setupListeners();
    }

    private void initViews() {
        tvScoreDisplay = findViewById(R.id.tvScoreDisplay);
        tvScorePercent = findViewById(R.id.tvScorePercent);
        tvPerformanceMessage = findViewById(R.id.tvPerformanceMessage);
        tvCorrectCount = findViewById(R.id.tvCorrectCount);
        tvIncorrectCount = findViewById(R.id.tvIncorrectCount);
        tvTotalCount = findViewById(R.id.tvTotalCount);

        btnRestartQuiz = findViewById(R.id.btnRestartQuiz);
        btnBackHome = findViewById(R.id.btnBackHome);
    }

    private void retrieveIntentData() {
        Intent intent = getIntent();
        if (intent != null) {
            totalQuestions = intent.getIntExtra(QuizActivity.EXTRA_TOTAL_QUESTIONS, 10);
            correctCount = intent.getIntExtra(QuizActivity.EXTRA_CORRECT_COUNT, 0);
            incorrectCount = intent.getIntExtra(QuizActivity.EXTRA_INCORRECT_COUNT, 0);
            score = intent.getIntExtra(QuizActivity.EXTRA_SCORE, 0);
        }
    }

    private void populateResults() {
        tvScoreDisplay.setText(score + " / " + totalQuestions);

        int percentage = totalQuestions > 0 ? (int) Math.round(((double) score / totalQuestions) * 100) : 0;
        tvScorePercent.setText(percentage + "% Score");

        tvCorrectCount.setText(String.valueOf(correctCount));
        tvIncorrectCount.setText(String.valueOf(incorrectCount));
        tvTotalCount.setText(String.valueOf(totalQuestions));

        String message;
        if (score >= 9) {
            message = "🌟 Excellent work!\\nYou have mastered these General Knowledge topics!";
        } else if (score >= 7) {
            message = "👏 Great job!\\nStrong understanding with great precision.";
        } else if (score >= 4) {
            message = "💡 Good effort — keep practicing!\\nYou're building a solid foundation.";
        } else {
            message = "📚 Keep learning. You can improve!\\nReview the explanations and try again!";
        }
        tvPerformanceMessage.setText(message);
    }

    private void setupListeners() {
        btnRestartQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultActivity.this, QuizActivity.class);
                startActivity(intent);
                finish();
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });

        btnBackHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });
    }
}`
  },
  {
    name: "Question.java",
    path: "app/src/main/java/com/nehaborkar/quizora/model/Question.java",
    language: "java",
    category: "java",
    content: `package com.nehaborkar.quizora.model;

import java.io.Serializable;

/**
 * Question Model representing a single Quiz Question.
 * 
 * Developer: Neha Vinod Borkar
 * Oasis Infobyte Task 4 — Quiz Application
 */
public class Question implements Serializable {
    private String questionText;
    private String[] options;
    private String correctAnswer;
    private String explanation;
    private String category;

    public Question(String questionText, String[] options, String correctAnswer, String explanation, String category) {
        if (options == null || options.length != 4) {
            throw new IllegalArgumentException("Question must have exactly four options.");
        }
        boolean matchFound = false;
        for (String opt : options) {
            if (opt.equalsIgnoreCase(correctAnswer)) {
                matchFound = true;
                break;
            }
        }
        if (!matchFound) {
            throw new IllegalArgumentException("Correct answer must match one of the four options.");
        }

        this.questionText = questionText;
        this.options = options;
        this.correctAnswer = correctAnswer;
        this.explanation = explanation;
        this.category = category;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String[] getOptions() {
        return options;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public String getExplanation() {
        return explanation;
    }

    public String getCategory() {
        return category;
    }

    public boolean isCorrect(String selectedAnswer) {
        return correctAnswer != null && correctAnswer.equalsIgnoreCase(selectedAnswer);
    }
}`
  },
  {
    name: "QuizData.java",
    path: "app/src/main/java/com/nehaborkar/quizora/data/QuizData.java",
    language: "java",
    category: "java",
    content: `package com.nehaborkar.quizora.data;

import com.nehaborkar.quizora.model.Question;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Question bank for Quizora.
 * 15 comprehensive General Knowledge questions, offline, zero API keys required.
 * 
 * Developer: Neha Vinod Borkar
 * Oasis Infobyte Task 4 — Quiz Application
 */
public class QuizData {

    public static List<Question> getAllQuestions() {
        List<Question> questions = new ArrayList<>();

        questions.add(new Question(
                "Which planet in our solar system is known as the Red Planet?",
                new String[]{"Venus", "Mars", "Jupiter", "Saturn"},
                "Mars",
                "Mars appears reddish due to iron oxide (rust) covering its surface.",
                "Space & Astronomy"
        ));

        questions.add(new Question(
                "Who wrote the famous romantic tragedy 'Romeo and Juliet'?",
                new String[]{"Charles Dickens", "William Shakespeare", "Mark Twain", "Jane Austen"},
                "William Shakespeare",
                "William Shakespeare wrote Romeo and Juliet early in his career around 1595.",
                "Literature & Arts"
        ));

        questions.add(new Question(
                "What is widely considered the powerhouse of the biological cell?",
                new String[]{"Nucleus", "Mitochondria", "Ribosome", "Endoplasmic Reticulum"},
                "Mitochondria",
                "Mitochondria generate ATP (adenosine triphosphate), the chemical energy currency of cells.",
                "Science & Biology"
        ));

        questions.add(new Question(
                "What is the chemical symbol for Gold in the Periodic Table?",
                new String[]{"Gd", "Ag", "Au", "Fe"},
                "Au",
                "Au originates from 'Aurum', the Latin word signifying glowing dawn or gold.",
                "Science & Chemistry"
        ));

        questions.add(new Question(
                "Which is the longest river in the world by total length?",
                new String[]{"Amazon River", "Nile River", "Yangtze River", "Mississippi River"},
                "Nile River",
                "The Nile River extends approximately 6,650 km (4,132 miles) through northeastern Africa.",
                "Geography"
        ));

        questions.add(new Question(
                "In computer technology, what does the acronym 'RAM' stand for?",
                new String[]{"Read Access Memory", "Random Access Memory", "Run Action Module", "Real Audio Matrix"},
                "Random Access Memory",
                "RAM provides quick read/write storage that the processor accesses actively.",
                "Computer Science"
        ));

        questions.add(new Question(
                "In which year did Apollo 11 successfully land humans on the Moon?",
                new String[]{"1965", "1969", "1972", "1975"},
                "1969",
                "Commander Neil Armstrong stepped onto the lunar surface on July 20, 1969.",
                "History & Space"
        ));

        questions.add(new Question(
                "Which gas makes up approximately 78% of Earth's atmosphere?",
                new String[]{"Oxygen", "Carbon Dioxide", "Nitrogen", "Argon"},
                "Nitrogen",
                "Nitrogen comprises roughly 78.08% of dry air, with oxygen taking about 20.95%.",
                "Earth Science"
        ));

        questions.add(new Question(
                "Which Asian country is famously referred to as the 'Land of the Rising Sun'?",
                new String[]{"China", "Japan", "South Korea", "Thailand"},
                "Japan",
                "The name Nippon or Nihon means 'sun origin' relative to mainland Asia.",
                "Geography"
        ));

        questions.add(new Question(
                "Who is historically acclaimed as the 'Father of Computers'?",
                new String[]{"Alan Turing", "Charles Babbage", "John von Neumann", "Ada Lovelace"},
                "Charles Babbage",
                "Charles Babbage originated the concept of a programmable mechanical computer in the 1830s.",
                "Computer Science"
        ));

        questions.add(new Question(
                "What is the hardest naturally occurring mineral substance on Earth?",
                new String[]{"Titanium", "Graphene", "Diamond", "Quartz"},
                "Diamond",
                "Diamond scores a maximum 10 on Mohs scale because of its rigid covalent carbon lattice.",
                "Science"
        ));

        questions.add(new Question(
                "Which ocean is the largest and deepest on planet Earth?",
                new String[]{"Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"},
                "Pacific Ocean",
                "The Pacific Ocean spans more than 63 million square miles and holds Challenger Deep.",
                "Geography"
        ));

        questions.add(new Question(
                "Approximately what is the speed of light in a vacuum?",
                new String[]{"150,000 km/s", "300,000 km/s", "450,000 km/s", "600,000 km/s"},
                "300,000 km/s",
                "The speed of light in vacuum is approximately 299,792 km/s (~300,000 km/s).",
                "Physics"
        ));

        questions.add(new Question(
                "Which programming language was originally used as the primary language for Android apps?",
                new String[]{"Swift", "Java", "Ruby", "PHP"},
                "Java",
                "Android SDK was built around Java, supported alongside Kotlin by Google.",
                "Technology"
        ));

        questions.add(new Question(
                "Which organ in the human body secretes insulin to regulate blood glucose?",
                new String[]{"Liver", "Kidney", "Pancreas", "Gallbladder"},
                "Pancreas",
                "The endocrine islets of the pancreas produce insulin and glucagon.",
                "Biology"
        ));

        return questions;
    }

    public static List<Question> getShuffledQuiz(int questionCount) {
        List<Question> list = new ArrayList<>(getAllQuestions());
        Collections.shuffle(list);
        if (questionCount > 0 && questionCount <= list.size()) {
            return new ArrayList<>(list.subList(0, questionCount));
        }
        return list;
    }
}`
  },
  {
    name: "activity_main.xml",
    path: "app/src/main/res/layout/activity_main.xml",
    language: "xml",
    category: "layout",
    content: `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/bg_light"
    android:padding="24dp"
    tools:context=".MainActivity">

    <TextView
        android:id="@+id/tvTrackTag"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="24dp"
        android:background="@drawable/bg_feedback_correct"
        android:paddingHorizontal="12dp"
        android:paddingVertical="6dp"
        android:text="Oasis Infobyte • Task 4"
        android:textColor="@color/primary_purple"
        android:textSize="12sp"
        android:textStyle="bold"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

    <androidx.cardview.widget.CardView
        android:id="@+id/cardLogo"
        android:layout_width="120dp"
        android:layout_height="120dp"
        android:layout_marginTop="32dp"
        app:cardCornerRadius="60dp"
        app:cardElevation="8dp"
        app:cardBackgroundColor="@color/primary_purple"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@id/tvTrackTag">

        <TextView
            android:layout_width="match_parent"
            android:layout_height="match_parent"
            android:gravity="center"
            android:text="🧠"
            android:textSize="54sp" />
    </androidx.cardview.widget.CardView>

    <TextView
        android:id="@+id/tvAppTitle"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="16dp"
        android:fontFamily="sans-serif-black"
        android:text="@string/app_name"
        android:textColor="@color/primary_purple"
        android:textSize="36sp"
        android:textStyle="bold"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@id/cardLogo" />

    <TextView
        android:id="@+id/tvHeading"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:layout_marginTop="16dp"
        android:gravity="center"
        android:text="@string/ready_to_test"
        android:textColor="@color/text_primary"
        android:textSize="22sp"
        android:textStyle="bold"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@id/tvAppTitle" />

    <TextView
        android:id="@+id/tvSubheading"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:layout_marginTop="10dp"
        android:gravity="center"
        android:lineSpacingExtra="4dp"
        android:text="@string/welcome_desc"
        android:textColor="@color/text_secondary"
        android:textSize="14sp"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@id/tvHeading" />

    <androidx.appcompat.widget.AppCompatButton
        android:id="@+id/btnStartQuiz"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginBottom="16dp"
        android:background="@drawable/btn_primary"
        android:elevation="4dp"
        android:text="@string/start_quiz"
        android:textAllCaps="false"
        android:textColor="@color/white"
        android:textSize="18sp"
        android:textStyle="bold"
        app:layout_constraintBottom_toTopOf="@id/tvDeveloperCredit" />

    <TextView
        android:id="@+id/tvDeveloperCredit"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginBottom="12dp"
        android:gravity="center"
        android:text="@string/developer_credit"
        android:textColor="@color/text_muted"
        android:textSize="12sp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent" />

</androidx.constraintlayout.widget.ConstraintLayout>`
  },
  {
    name: "activity_quiz.xml",
    path: "app/src/main/res/layout/activity_quiz.xml",
    language: "xml",
    category: "layout",
    content: `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/bg_light"
    android:padding="20dp"
    tools:context=".QuizActivity">

    <LinearLayout
        android:id="@+id/layoutHeader"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:gravity="center_vertical"
        app:layout_constraintTop_toTopOf="parent">

        <TextView
            android:id="@+id/tvQuestionCounter"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:text="Question 1 of 10"
            android:textColor="@color/primary_purple"
            android:textSize="15sp"
            android:textStyle="bold" />

        <TextView
            android:id="@+id/tvCategoryBadge"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:background="@drawable/bg_option_badge_default"
            android:paddingHorizontal="12dp"
            android:paddingVertical="4dp"
            android:text="General Knowledge"
            android:textColor="@color/text_secondary"
            android:textSize="12sp"
            android:textStyle="bold" />
    </LinearLayout>

    <ProgressBar
        android:id="@+id/progressBarQuiz"
        style="?android:attr/progressBarStyleHorizontal"
        android:layout_width="match_parent"
        android:layout_height="8dp"
        android:layout_marginTop="12dp"
        android:max="100"
        android:progress="10"
        android:progressTint="@color/primary_purple"
        app:layout_constraintTop_toBottomOf="@id/layoutHeader" />

    <!-- Question + 4 Options + Feedback Banner inside ScrollView -->
    <!-- See full repository for detailed view IDs -->
</androidx.constraintlayout.widget.ConstraintLayout>`
  },
  {
    name: "activity_result.xml",
    path: "app/src/main/res/layout/activity_result.xml",
    language: "xml",
    category: "layout",
    content: `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/bg_light"
    android:padding="24dp"
    tools:context=".ResultActivity">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/quiz_completed"
        android:textColor="@color/text_primary"
        android:textSize="26sp"
        android:textStyle="bold"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintStart_toStartOf="parent" />

</androidx.constraintlayout.widget.ConstraintLayout>`
  },
  {
    name: "AndroidManifest.xml",
    path: "app/src/main/AndroidManifest.xml",
    language: "xml",
    category: "config",
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.nehaborkar.quizora">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.Quizora">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="portrait">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <activity
            android:name=".QuizActivity"
            android:exported="false"
            android:screenOrientation="portrait" />

        <activity
            android:name=".ResultActivity"
            android:exported="false"
            android:screenOrientation="portrait" />

    </application>
</manifest>`
  },
  {
    name: "build.gradle (Module: app)",
    path: "app/build.gradle",
    language: "groovy",
    category: "config",
    content: `plugins {
    id 'com.android.application'
}

android {
    namespace 'com.nehaborkar.quizora'
    compileSdk 34

    defaultConfig {
        applicationId "com.nehaborkar.quizora"
        minSdk 21
        targetSdk 34
        versionCode 1
        versionName "1.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.cardview:cardview:1.0.0'

    testImplementation 'junit:junit:4.13.2'
    androidTestImplementation 'androidx.test.ext:junit:1.1.5'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1'
}`
  },
  {
    name: "colors.xml",
    path: "app/src/main/res/values/colors.xml",
    language: "xml",
    category: "values",
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="primary_purple">#6C5CE7</color>
    <color name="primary_purple_dark">#5644D8</color>
    <color name="primary_purple_light">#A29BFE</color>
    <color name="accent_blue">#0984E3</color>

    <color name="feedback_correct">#2ECC71</color>
    <color name="feedback_correct_dark">#27AE60</color>
    <color name="feedback_correct_bg">#E8F8F0</color>
    <color name="feedback_correct_border">#2ECC71</color>

    <color name="feedback_wrong">#E74C3C</color>
    <color name="feedback_wrong_dark">#C0392B</color>
    <color name="feedback_wrong_bg">#FDF0ED</color>
    <color name="feedback_wrong_border">#E74C3C</color>

    <color name="bg_light">#F8F9FD</color>
    <color name="card_bg">#FFFFFF</color>
    <color name="card_border">#E2E8F0</color>

    <color name="text_primary">#1E293B</color>
    <color name="text_secondary">#64748B</color>
    <color name="text_muted">#94A3B8</color>
    <color name="white">#FFFFFF</color>
</resources>`
  },
  {
    name: "strings.xml",
    path: "app/src/main/res/values/strings.xml",
    language: "xml",
    category: "values",
    content: `<resources>
    <string name="app_name">Quizora</string>
    <string name="ready_to_test">Ready to Test Your Knowledge?</string>
    <string name="welcome_desc">Challenge yourself with 10 engaging General Knowledge questions across science, space, history, geography, and technology.</string>
    <string name="start_quiz">Start Quiz</string>
    <string name="question_counter">Question %1$d of %2$d</string>
    <string name="next_question">Next Question</string>
    <string name="view_results">See Results</string>
    <string name="quiz_completed">Quiz Completed!</string>
    <string name="restart_quiz">Restart Quiz</string>
    <string name="back_to_home">Back to Home</string>
    <string name="correct_count_label">Correct</string>
    <string name="incorrect_count_label">Incorrect</string>
    <string name="total_questions_label">Total Questions</string>
    <string name="developer_credit">Developed by Neha Vinod Borkar\\nOasis Infobyte Internship — Task 4</string>
</resources>`
  }
];
