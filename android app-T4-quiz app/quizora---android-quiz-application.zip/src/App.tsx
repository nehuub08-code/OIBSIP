import React, { useState } from 'react';
import { AndroidPhoneFrame } from './components/AndroidPhoneFrame';
import { WelcomeScreen } from './components/WelcomeScreen';
import { QuizScreen } from './components/QuizScreen';
import { ResultScreen } from './components/ResultScreen';
import { CodeInspector } from './components/CodeInspector';
import { TestSuiteModal } from './components/TestSuiteModal';
import { DemoVideoPlayer } from './components/DemoVideoPlayer';
import { getShuffledQuestions, QuestionItem } from './data/questionsData';
import { downloadAndroidProjectZip } from './utils/zipExport';
import { 
  Smartphone, 
  Code2, 
  ShieldCheck, 
  Video, 
  Download, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  FolderGit2, 
  Info,
  CheckCircle2
} from 'lucide-react';

export default function App() {
  // Navigation / View Tabs
  const [activeTab, setActiveTab] = useState<'phone' | 'code' | 'tests' | 'demo' | 'readme'>('phone');
  const [isExporting, setIsExporting] = useState(false);
  const [showMandatorySlate, setShowMandatorySlate] = useState(false);

  // Android Quiz Application State
  const [activeScreen, setActiveScreen] = useState<'welcome' | 'quiz' | 'result'>('welcome');
  const [questions, setQuestions] = useState<QuestionItem[]>(() => getShuffledQuestions(10));
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [incorrectCount, setIncorrectCount] = useState(0);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState<number | null>(null);

  // Start new quiz session
  const handleStartQuiz = () => {
    const shuffled = getShuffledQuestions(10);
    setQuestions(shuffled);
    setCurrentIndex(0);
    setScore(0);
    setCorrectCount(0);
    setIncorrectCount(0);
    setIsAnswerSubmitted(false);
    setSelectedOptionIndex(null);
    setActiveScreen('quiz');
  };

  // Answer selected on current question
  const handleAnswerSelected = (isCorrect: boolean) => {
    if (isAnswerSubmitted) return;

    // Find clicked index based on current question
    const currentQ = questions[currentIndex];
    // Find index
    const pickedIdx = currentQ.options.findIndex(opt => opt === (isCorrect ? currentQ.correctAnswer : currentQ.options.find(o => o !== currentQ.correctAnswer)));

    setIsAnswerSubmitted(true);
    setSelectedOptionIndex(pickedIdx >= 0 ? pickedIdx : 0);

    if (isCorrect) {
      setScore(prev => prev + 1);
      setCorrectCount(prev => prev + 1);
    } else {
      setIncorrectCount(prev => prev + 1);
    }
  };

  // Move to next question or results
  const handleNextQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setIsAnswerSubmitted(false);
      setSelectedOptionIndex(null);
    } else {
      setActiveScreen('result');
    }
  };

  // Restart quiz
  const handleRestartQuiz = () => {
    handleStartQuiz();
  };

  // Back to home
  const handleBackHome = () => {
    setActiveScreen('welcome');
    setIsAnswerSubmitted(false);
    setSelectedOptionIndex(null);
  };

  // Android Soft Button: Back
  const handleAndroidBack = () => {
    if (activeScreen === 'quiz') {
      if (confirm('Exit current quiz and return to Welcome screen?')) {
        handleBackHome();
      }
    } else if (activeScreen === 'result') {
      handleBackHome();
    }
  };

  // 1-Click ZIP Download
  const handleDownloadZip = async () => {
    setIsExporting(true);
    try {
      await downloadAndroidProjectZip();
    } finally {
      setIsExporting(false);
    }
  };

  // Demonstration simulation helper
  const handleSimulateStep = (stepNumber: number) => {
    if (stepNumber === 0) {
      setShowMandatorySlate(true);
      setActiveScreen('welcome');
    } else if (stepNumber === 1) {
      setShowMandatorySlate(false);
      setActiveScreen('welcome');
    } else if (stepNumber === 2) {
      setShowMandatorySlate(false);
      setActiveScreen('quiz');
      setCurrentIndex(0);
      setIsAnswerSubmitted(true);
      // Select correct
      const q = questions[0];
      const correctIdx = q.options.indexOf(q.correctAnswer);
      setSelectedOptionIndex(correctIdx >= 0 ? correctIdx : 0);
      setScore(1);
      setCorrectCount(1);
      setIncorrectCount(0);
    } else if (stepNumber === 3) {
      setShowMandatorySlate(false);
      setActiveScreen('quiz');
      setCurrentIndex(1);
      setIsAnswerSubmitted(true);
      // Select incorrect
      const q = questions[1];
      const wrongIdx = q.options.findIndex(opt => opt !== q.correctAnswer);
      setSelectedOptionIndex(wrongIdx >= 0 ? wrongIdx : 0);
      setIncorrectCount(1);
    } else if (stepNumber === 4) {
      setShowMandatorySlate(false);
      setActiveScreen('quiz');
      setCurrentIndex(5);
      setIsAnswerSubmitted(false);
      setSelectedOptionIndex(null);
      setScore(4);
      setCorrectCount(4);
      setIncorrectCount(1);
    } else if (stepNumber === 5) {
      setShowMandatorySlate(false);
      setActiveScreen('result');
      setScore(8);
      setCorrectCount(8);
      setIncorrectCount(2);
    } else if (stepNumber === 6) {
      setShowMandatorySlate(false);
      handleStartQuiz();
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Header */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-40 px-4 lg:px-8 py-3">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Logo & Internship Meta */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#6C5CE7] to-[#8054F7] flex items-center justify-center shadow-lg shadow-indigo-500/20 ring-2 ring-indigo-500/30">
              <span className="text-xl">🧠</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-black tracking-tight text-white">
                  Quizora
                </h1>
                <span className="text-[10px] bg-indigo-500/20 text-indigo-300 font-bold px-2 py-0.5 rounded-full border border-indigo-500/30">
                  Android Task 4
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                  Java & XML
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Developer: <strong className="text-slate-200">Neha Vinod Borkar</strong> • Oasis Infobyte Android Internship
              </p>
            </div>
          </div>

          {/* Action Header Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadZip}
              disabled={isExporting}
              className="flex items-center gap-2 bg-gradient-to-r from-[#6C5CE7] to-[#8054F7] hover:from-[#5644D8] hover:to-[#6C5CE7] text-white text-xs font-bold px-4 py-2 rounded-xl transition-all shadow-md shadow-indigo-500/20 active:scale-95 cursor-pointer disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{isExporting ? 'Generating ZIP...' : 'Download Android Studio (.ZIP)'}</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="max-w-7xl mx-auto flex items-center gap-2 mt-3 pt-2 border-t border-slate-800/60 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('phone')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'phone'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Interactive Android Phone</span>
          </button>

          <button
            onClick={() => setActiveTab('code')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'code'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Android Studio Code Explorer</span>
          </button>

          <button
            onClick={() => setActiveTab('tests')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'tests'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>17-Point Test Suite</span>
          </button>

          <button
            onClick={() => setActiveTab('demo')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'demo'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Video className="w-3.5 h-3.5" />
            <span>Demo Video Sequence</span>
          </button>

          <button
            onClick={() => setActiveTab('readme')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'readme'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FolderGit2 className="w-3.5 h-3.5" />
            <span>OIBSIP Submission Guide</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-8 flex flex-col justify-center">
        {activeTab === 'phone' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left: Device Simulator */}
            <div className="lg:col-span-5 flex justify-center relative">
              {/* Mandatory Opening Slate Overlay (if demo step 0 is active) */}
              {showMandatorySlate && (
                <div className="absolute inset-0 z-50 bg-slate-950/95 rounded-[50px] p-8 flex flex-col items-center justify-center text-center animate-fadeIn border border-indigo-500/40">
                  <span className="text-[11px] font-bold tracking-widest uppercase text-indigo-400 mb-2">
                    Oasis Infobyte Internship
                  </span>
                  <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl w-full shadow-2xl">
                    <p className="text-white font-extrabold text-base mb-1">
                      Full Name: <span className="text-emerald-400">Neha Vinod Borkar</span>
                    </p>
                    <p className="text-indigo-300 font-semibold text-sm mb-1">
                      Assigned Track: Android App Development
                    </p>
                    <p className="text-slate-300 font-medium text-xs">
                      Task Title: Task 4 — Quiz Application
                    </p>
                  </div>
                  <button
                    onClick={() => setShowMandatorySlate(false)}
                    className="mt-6 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-500 transition-all cursor-pointer"
                  >
                    Dismiss Opening Slate
                  </button>
                </div>
              )}

              <AndroidPhoneFrame
                onBackPressed={handleAndroidBack}
                onHomePressed={handleBackHome}
              >
                {activeScreen === 'welcome' && (
                  <WelcomeScreen onStartQuiz={handleStartQuiz} />
                )}

                {activeScreen === 'quiz' && (
                  <QuizScreen
                    questions={questions}
                    currentIndex={currentIndex}
                    onAnswerSelected={handleAnswerSelected}
                    onNextQuestion={handleNextQuestion}
                    isAnswerSubmitted={isAnswerSubmitted}
                    selectedOptionIndex={selectedOptionIndex}
                    score={score}
                  />
                )}

                {activeScreen === 'result' && (
                  <ResultScreen
                    score={score}
                    totalQuestions={questions.length}
                    correctCount={correctCount}
                    incorrectCount={incorrectCount}
                    onRestart={handleRestartQuiz}
                    onHome={handleBackHome}
                  />
                )}
              </AndroidPhoneFrame>
            </div>

            {/* Right: Feature Highlights & Quick Test Bench */}
            <div className="lg:col-span-7 space-y-6">
              {/* Architecture Highlight Card */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-white">
                        Native Android Implementation
                      </h3>
                      <p className="text-xs text-slate-400">
                        Built with Java, Android SDK 34 & Clean XML Architecture
                      </p>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded-full font-bold border border-emerald-500/20">
                    Offline Ready
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800/80">
                    <span className="font-bold text-indigo-400 block mb-1">
                      🟢 Immediate Answer Feedback
                    </span>
                    <p className="text-slate-400 leading-relaxed">
                      Instant green highlight for correct choices and red for incorrect. Reveals the true answer in green upon error with detailed educational explanation.
                    </p>
                  </div>

                  <div className="bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800/80">
                    <span className="font-bold text-indigo-400 block mb-1">
                      🔒 Single Selection Anti-Tamper
                    </span>
                    <p className="text-slate-400 leading-relaxed">
                      Options lock immediately once tapped. Prevents multiple votes or score inflation. Next button enforces completion before advancing.
                    </p>
                  </div>

                  <div className="bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800/80">
                    <span className="font-bold text-indigo-400 block mb-1">
                      🔀 Dynamic Shuffling Engine
                    </span>
                    <p className="text-slate-400 leading-relaxed">
                      Pulls 10 randomized questions from a 15-question bank. Preserves the exact association between questions and correct answers.
                    </p>
                  </div>

                  <div className="bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800/80">
                    <span className="font-bold text-indigo-400 block mb-1">
                      📊 Intelligent Evaluation
                    </span>
                    <p className="text-slate-400 leading-relaxed">
                      Displays final score (e.g. 8 / 10), percentage, breakdown counters, and graded feedback from &quot;Excellent work!&quot; to &quot;Keep practicing!&quot;.
                    </p>
                  </div>
                </div>

                {/* Quick Action Bar */}
                <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Try tapping the answers inside the Pixel 8 simulator!</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setActiveTab('code')}
                      className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all cursor-pointer"
                    >
                      Inspect Java & XML
                    </button>
                    <button
                      onClick={() => setActiveTab('tests')}
                      className="px-3.5 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-bold transition-all cursor-pointer"
                    >
                      Run 17-Point Tests
                    </button>
                  </div>
                </div>
              </div>

              {/* Developer Metadata Box */}
              <div className="bg-gradient-to-r from-purple-950/30 to-indigo-950/30 border border-purple-500/20 rounded-3xl p-5 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-purple-400">
                    Internship Details
                  </h4>
                  <p className="text-sm font-extrabold text-white mt-0.5">
                    Neha Vinod Borkar • Oasis Infobyte
                  </p>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">
                    Track: Android App Development | Task: 4 (Quiz Application)
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[11px] bg-slate-800 text-slate-300 px-3 py-1 rounded-full font-mono">
                    Repo: OIBSIP
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Android Studio Code Explorer */}
        {activeTab === 'code' && (
          <div className="h-[750px] w-full">
            <CodeInspector />
          </div>
        )}

        {/* Tab 3: 17-Point Test Suite */}
        {activeTab === 'tests' && (
          <div className="h-[750px] w-full">
            <TestSuiteModal />
          </div>
        )}

        {/* Tab 4: Demo Video Sequence Player */}
        {activeTab === 'demo' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-5 flex justify-center">
              <AndroidPhoneFrame
                onBackPressed={handleAndroidBack}
                onHomePressed={handleBackHome}
              >
                {activeScreen === 'welcome' && (
                  <WelcomeScreen onStartQuiz={handleStartQuiz} />
                )}

                {activeScreen === 'quiz' && (
                  <QuizScreen
                    questions={questions}
                    currentIndex={currentIndex}
                    onAnswerSelected={handleAnswerSelected}
                    onNextQuestion={handleNextQuestion}
                    isAnswerSubmitted={isAnswerSubmitted}
                    selectedOptionIndex={selectedOptionIndex}
                    score={score}
                  />
                )}

                {activeScreen === 'result' && (
                  <ResultScreen
                    score={score}
                    totalQuestions={questions.length}
                    correctCount={correctCount}
                    incorrectCount={incorrectCount}
                    onRestart={handleRestartQuiz}
                    onHome={handleBackHome}
                  />
                )}
              </AndroidPhoneFrame>
            </div>
            <div className="lg:col-span-7 h-[730px]">
              <DemoVideoPlayer onSimulateStep={handleSimulateStep} />
            </div>
          </div>
        )}

        {/* Tab 5: OIBSIP Submission Guide */}
        {activeTab === 'readme' && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 lg:p-8 max-w-4xl mx-auto shadow-2xl space-y-6">
            <div className="border-b border-slate-800 pb-4 flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-white">
                  OIBSIP GitHub Repository Submission Guide
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  How to push Quizora to your official Oasis Infobyte GitHub repository
                </p>
              </div>
              <button
                onClick={handleDownloadZip}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-4 py-2 rounded-xl transition-all flex items-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                Download Zip
              </button>
            </div>

            <div className="space-y-4 text-xs text-slate-300 leading-relaxed font-mono">
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <p className="text-indigo-400 font-bold mb-2"># 1. Required Repository Structure</p>
                <pre className="text-slate-400 text-[11px]">
{`OIBSIP/
└── Task 4 - Quiz Application/
    └── Quizora/
        ├── app/
        │   ├── build.gradle
        │   └── src/main/...
        ├── build.gradle
        ├── settings.gradle
        └── README.md`}
                </pre>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <p className="text-indigo-400 font-bold mb-2"># 2. Git Commands to Push to GitHub</p>
                <pre className="text-emerald-400 text-[11px] overflow-x-auto">
{`# In your local repository:
git checkout -b task-4-quizora
mkdir -p "Task 4 - Quiz Application"
# Extract the downloaded Quizora project into "Task 4 - Quiz Application/Quizora"
git add "Task 4 - Quiz Application/Quizora"
git commit -m "Add Task 4 - Quizora Android Quiz Application by Neha Vinod Borkar"
git push origin main`}
                </pre>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <p className="text-indigo-400 font-bold mb-2"># 3. Video Submission Checklist (Section 16)</p>
                <ul className="space-y-1.5 list-disc list-inside text-slate-300">
                  <li>First 2+ seconds must show: Name, Track, and Task Title slate.</li>
                  <li>Record welcome screen and tap Start Quiz.</li>
                  <li>Show a correct answer receiving green feedback.</li>
                  <li>Show an incorrect answer receiving red feedback with revealed correct answer.</li>
                  <li>Move through questions showing question counter and progress bar.</li>
                  <li>Display final score, correct/incorrect counters, and custom performance text.</li>
                  <li>Tap Restart Quiz and show that questions re-shuffle and score resets.</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-4 px-6 text-center text-xs text-slate-500">
        <p>
          Quizora Android Quiz Application • Developed by <strong className="text-slate-300">Neha Vinod Borkar</strong> for Oasis Infobyte (Task 4)
        </p>
      </footer>
    </div>
  );
}
