import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { RotateCcw, Home, Award, CheckCircle2, XCircle, Target } from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface ResultScreenProps {
  score: number;
  totalQuestions: number;
  correctCount: number;
  incorrectCount: number;
  onRestart: () => void;
  onHome: () => void;
}

export const ResultScreen: React.FC<ResultScreenProps> = ({
  score,
  totalQuestions,
  correctCount,
  incorrectCount,
  onRestart,
  onHome,
}) => {
  const percentage = Math.round((score / totalQuestions) * 100);

  useEffect(() => {
    if (score >= 7) {
      try {
        confetti({
          particleCount: 60,
          spread: 60,
          origin: { y: 0.6 }
        });
      } catch {
        // Ignore confetti errors
      }
    }
  }, [score]);

  // Performance message lookup matching Java ResultActivity
  const getPerformanceData = () => {
    if (score >= 9) {
      return {
        badge: "🌟 Outstanding",
        title: "Excellent work!",
        description: "You have mastered these General Knowledge topics!",
        color: "text-emerald-600",
        badgeBg: "bg-emerald-100 text-emerald-800"
      };
    } else if (score >= 7) {
      return {
        badge: "👏 Great Score",
        title: "Great job!",
        description: "Strong understanding with great precision.",
        color: "text-indigo-600",
        badgeBg: "bg-indigo-100 text-indigo-800"
      };
    } else if (score >= 4) {
      return {
        badge: "💡 Good Effort",
        title: "Good effort — keep practicing!",
        description: "You're building a solid foundation across topics.",
        color: "text-amber-600",
        badgeBg: "bg-amber-100 text-amber-800"
      };
    } else {
      return {
        badge: "📚 Keep Practicing",
        title: "Keep learning. You can improve!",
        description: "Review the explanations and try again to boost your score!",
        color: "text-rose-600",
        badgeBg: "bg-rose-100 text-rose-800"
      };
    }
  };

  const performance = getPerformanceData();

  return (
    <div className="flex flex-col h-full bg-[#F8F9FD] p-5 text-slate-800 justify-between select-none overflow-y-auto">
      {/* Top Banner */}
      <div className="flex flex-col items-center text-center pt-2">
        {/* Trophy Icon */}
        <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-[#6C5CE7] to-[#8054F7] flex items-center justify-center shadow-lg shadow-indigo-500/25 ring-4 ring-indigo-100 mb-3">
          <span className="text-4xl filter drop-shadow">🏆</span>
        </div>

        <h1 className="text-2xl font-black text-slate-800 tracking-tight">
          Quiz Completed!
        </h1>

        {/* Score Card */}
        <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-xs w-full mt-4 flex flex-col items-center">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Your Final Score
          </span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-5xl font-black text-[#6C5CE7]">{score}</span>
            <span className="text-2xl font-bold text-slate-300">/ {totalQuestions}</span>
          </div>

          <div className="flex items-center gap-2 mt-2">
            <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${performance.badgeBg}`}>
              {percentage}% Accuracy
            </span>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 w-full text-center">
            <h3 className={`text-sm font-bold ${performance.color}`}>
              {performance.title}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {performance.description}
            </p>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-2.5 w-full mt-4">
          {/* Correct */}
          <div className="bg-[#E8F8F0] border border-[#2ECC71]/30 rounded-2xl p-3 flex flex-col items-center">
            <CheckCircle2 className="w-5 h-5 text-[#2ECC71] mb-1" />
            <span className="text-xl font-black text-[#27AE60]">{correctCount}</span>
            <span className="text-[10px] font-bold text-[#27AE60]">Correct</span>
          </div>

          {/* Incorrect */}
          <div className="bg-[#FDF0ED] border border-[#E74C3C]/30 rounded-2xl p-3 flex flex-col items-center">
            <XCircle className="w-5 h-5 text-[#E74C3C] mb-1" />
            <span className="text-xl font-black text-[#C0392B]">{incorrectCount}</span>
            <span className="text-[10px] font-bold text-[#C0392B]">Incorrect</span>
          </div>

          {/* Total */}
          <div className="bg-white border border-slate-200/80 rounded-2xl p-3 flex flex-col items-center">
            <Target className="w-5 h-5 text-[#6C5CE7] mb-1" />
            <span className="text-xl font-black text-slate-700">{totalQuestions}</span>
            <span className="text-[10px] font-bold text-slate-500">Total</span>
          </div>
        </div>
      </div>

      {/* Buttons */}
      <div className="space-y-2 pt-4 pb-2">
        <button
          onClick={() => {
            playClickSound();
            onRestart();
          }}
          className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#6C5CE7] to-[#8054F7] text-white font-bold text-sm shadow-md shadow-indigo-500/25 hover:shadow-indigo-500/35 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          Restart Quiz
        </button>

        <button
          onClick={() => {
            playClickSound();
            onHome();
          }}
          className="w-full py-3 px-6 rounded-2xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <Home className="w-4 h-4 text-slate-500" />
          Back to Home
        </button>
      </div>
    </div>
  );
};
