import React from 'react';
import { Play, Sparkles, Award, Zap, HelpCircle } from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface WelcomeScreenProps {
  onStartQuiz: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onStartQuiz }) => {
  const handleStart = () => {
    playClickSound();
    onStartQuiz();
  };

  return (
    <div className="flex flex-col h-full bg-[#F8F9FD] p-6 text-slate-800 justify-between select-none overflow-y-auto">
      {/* Top Tag */}
      <div className="flex justify-center pt-2">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#E8F8F0] text-[#27AE60] border border-[#2ECC71]/30 shadow-xs">
          <Sparkles className="w-3.5 h-3.5" />
          Oasis Infobyte • Task 4
        </span>
      </div>

      {/* Hero Mascot & Title */}
      <div className="flex flex-col items-center text-center my-auto py-4">
        {/* Circle Badge */}
        <div className="relative mb-4">
          <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#6C5CE7] to-[#8054F7] flex items-center justify-center shadow-lg shadow-indigo-500/25 ring-4 ring-indigo-100">
            <span className="text-4xl filter drop-shadow">🧠</span>
          </div>
          <div className="absolute -bottom-1 -right-1 bg-amber-400 text-slate-900 rounded-full p-1.5 shadow-sm">
            <Award className="w-4 h-4" />
          </div>
        </div>

        <h1 className="text-3xl font-extrabold text-[#6C5CE7] tracking-tight">
          Quizora
        </h1>
        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mt-0.5">
          General Knowledge Quiz App
        </p>

        <h2 className="text-xl font-bold text-slate-800 mt-5 leading-snug">
          Ready to Test Your Knowledge?
        </h2>
        <p className="text-xs text-slate-500 mt-2 leading-relaxed max-w-[280px]">
          Challenge your mind with 10 engaging General Knowledge questions across science, space, history, and tech!
        </p>

        {/* Feature Cards Row */}
        <div className="grid grid-cols-3 gap-2 w-full mt-6">
          <div className="bg-white border border-slate-200/80 rounded-2xl p-2.5 flex flex-col items-center shadow-xs">
            <span className="text-lg font-black text-[#6C5CE7]">10</span>
            <span className="text-[10px] font-semibold text-slate-500">Questions</span>
          </div>
          <div className="bg-white border border-slate-200/80 rounded-2xl p-2.5 flex flex-col items-center shadow-xs">
            <Zap className="w-5 h-5 text-emerald-500 mb-0.5" />
            <span className="text-[10px] font-semibold text-slate-500">Instant Check</span>
          </div>
          <div className="bg-white border border-slate-200/80 rounded-2xl p-2.5 flex flex-col items-center shadow-xs">
            <HelpCircle className="w-5 h-5 text-sky-500 mb-0.5" />
            <span className="text-[10px] font-semibold text-slate-500">100% Offline</span>
          </div>
        </div>
      </div>

      {/* Action Button & Developer Tag */}
      <div className="space-y-3 pb-2">
        <button
          onClick={handleStart}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-[#6C5CE7] to-[#8054F7] text-white font-bold text-base shadow-lg shadow-indigo-500/30 hover:shadow-indigo-500/40 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <Play className="w-5 h-5 fill-white" />
          Start Quiz
        </button>

        <div className="text-center">
          <p className="text-[11px] text-slate-400 font-medium leading-tight">
            Developed by <span className="text-slate-600 font-semibold">Neha Vinod Borkar</span>
          </p>
          <p className="text-[10px] text-slate-400">
            Android App Development • Task 4
          </p>
        </div>
      </div>
    </div>
  );
};
