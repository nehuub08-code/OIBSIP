import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Video, CheckCircle2, MonitorPlay } from 'lucide-react';

interface DemoVideoPlayerProps {
  onSimulateStep: (stepNumber: number) => void;
}

export const DemoVideoPlayer: React.FC<DemoVideoPlayerProps> = ({ onSimulateStep }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      id: 0,
      title: "Title Card (Mandatory First Frame)",
      duration: "3 sec",
      description: "Mandatory 2+ second title card showing developer credentials."
    },
    {
      id: 1,
      title: "1. Welcome Screen & Start Quiz",
      duration: "4 sec",
      description: "Display Quizora branding, 10-question indicator, and tap 'Start Quiz'."
    },
    {
      id: 2,
      title: "2. Correct Answer (Green Feedback)",
      duration: "4 sec",
      description: "Select correct answer. Highlights green, awards point, shows positive explanation."
    },
    {
      id: 3,
      title: "3. Incorrect Answer (Red Feedback)",
      duration: "4 sec",
      description: "Select wrong answer. Highlights red and reveals correct answer in green."
    },
    {
      id: 4,
      title: "4. Progression Through Questions",
      duration: "5 sec",
      description: "Advancing through questions with counter 'Question X of 10' and progress bar."
    },
    {
      id: 5,
      title: "5. Results Screen & Score Totals",
      duration: "4 sec",
      description: "Displays final score, correct/incorrect counters, and custom performance evaluation."
    },
    {
      id: 6,
      title: "6. Restart Quiz & Reset Score",
      duration: "4 sec",
      description: "Tap 'Restart Quiz' to show questions re-shuffled and score reset to 0."
    }
  ];

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying) {
      timer = setTimeout(() => {
        if (currentStep < steps.length - 1) {
          const next = currentStep + 1;
          setCurrentStep(next);
          onSimulateStep(next);
        } else {
          setIsPlaying(false);
        }
      }, 3500);
    }
    return () => clearTimeout(timer);
  }, [isPlaying, currentStep, onSimulateStep, steps.length]);

  const handleStepSelect = (stepIndex: number) => {
    setCurrentStep(stepIndex);
    onSimulateStep(stepIndex);
  };

  const togglePlay = () => {
    if (currentStep === steps.length - 1) {
      setCurrentStep(0);
      onSimulateStep(0);
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
      {/* Top Bar */}
      <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
            <Video className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              Submission Video Guide & Simulator
              <span className="text-[10px] font-semibold bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full">
                Task 4 Demo (Section 16)
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Interactive timeline following Oasis Infobyte demo recording specifications
            </p>
          </div>
        </div>

        {/* Playback Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setCurrentStep(0);
              onSimulateStep(0);
              setIsPlaying(false);
            }}
            className="p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-all cursor-pointer"
            title="Reset"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={togglePlay}
            className="flex items-center gap-1.5 bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all shadow-md shadow-purple-500/20 cursor-pointer"
          >
            {isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5 fill-white" />
                <span>Pause</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>Autoplay Demo</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Mandatory Title Card Preview */}
      <div className="p-4 bg-slate-950/60 border-b border-slate-800">
        <div className="bg-gradient-to-r from-indigo-950/70 to-purple-950/70 border border-indigo-500/30 rounded-2xl p-4 text-center">
          <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-400">
            Mandatory Video Opening Slate (Must display for ≥ 2s)
          </span>
          <div className="mt-2 space-y-1 font-mono text-xs">
            <p className="text-white font-bold text-sm">
              Full Name: <span className="text-emerald-400">Neha Vinod Borkar</span>
            </p>
            <p className="text-slate-300">
              Assigned Track: <span className="text-indigo-300">Android App Development</span>
            </p>
            <p className="text-slate-300">
              Task Title: <span className="text-indigo-300">Task 4 — Quiz Application</span>
            </p>
          </div>
        </div>
      </div>

      {/* Steps Flow Timeline */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {steps.map((st) => {
          const isActive = currentStep === st.id;
          return (
            <button
              key={st.id}
              onClick={() => handleStepSelect(st.id)}
              className={`w-full text-left p-3.5 rounded-2xl border transition-all flex items-start justify-between cursor-pointer ${
                isActive
                  ? 'bg-purple-950/30 border-purple-500/40 ring-1 ring-purple-500/30 shadow-lg'
                  : 'bg-slate-950/30 border-slate-800/80 hover:bg-slate-800/40 text-slate-400'
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className={`w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center shrink-0 mt-0.5 ${
                    isActive ? 'bg-purple-500 text-white' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {st.id === 0 ? '★' : st.id}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className={`text-xs font-bold ${isActive ? 'text-white' : 'text-slate-300'}`}>
                      {st.title}
                    </h4>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {st.duration}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {st.description}
                  </p>
                </div>
              </div>

              {isActive && (
                <span className="text-[10px] bg-purple-500/20 text-purple-300 font-bold px-2 py-0.5 rounded-full shrink-0">
                  Active
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Recording Instructions */}
      <div className="p-4 bg-slate-950 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MonitorPlay className="w-4 h-4 text-indigo-400" />
          <span>Screen record this simulator or run in Android Studio Pixel Emulator</span>
        </div>
      </div>
    </div>
  );
};
