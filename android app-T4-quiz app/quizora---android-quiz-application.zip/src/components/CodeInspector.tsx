import React, { useState } from 'react';
import { ANDROID_PROJECT_FILES, AndroidFile } from '../utils/androidProjectFiles';
import { FileCode, Copy, Check, Folder, Download } from 'lucide-react';
import { downloadAndroidProjectZip } from '../utils/zipExport';

export const CodeInspector: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidFile>(ANDROID_PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsExporting(true);
    try {
      await downloadAndroidProjectZip();
    } finally {
      setIsExporting(false);
    }
  };

  const categories = [
    { key: 'java', label: 'Java Sources' },
    { key: 'layout', label: 'XML Layouts' },
    { key: 'values', label: 'XML Values' },
    { key: 'config', label: 'Manifest & Gradle' }
  ];

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
      {/* Top Bar */}
      <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold text-xs">
            AS
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              Android Studio Project Explorer
              <span className="text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full">
                Java & XML
              </span>
            </h3>
            <p className="text-xs text-slate-400 font-mono">
              com.nehaborkar.quizora
            </p>
          </div>
        </div>

        <button
          onClick={handleDownloadZip}
          disabled={isExporting}
          className="flex items-center gap-2 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition-all shadow-md shadow-indigo-500/20 cursor-pointer disabled:opacity-50"
        >
          <Download className="w-3.5 h-3.5" />
          {isExporting ? 'Zipping...' : 'Download Project (.ZIP)'}
        </button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar: File Tree */}
        <div className="w-64 bg-slate-950/70 border-r border-slate-800/80 p-3 overflow-y-auto space-y-4 shrink-0">
          {categories.map((cat) => {
            const files = ANDROID_PROJECT_FILES.filter(f => f.category === cat.key);
            if (files.length === 0) return null;

            return (
              <div key={cat.key}>
                <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-2 mb-1.5 flex items-center gap-1.5">
                  <Folder className="w-3.5 h-3.5 text-indigo-400" />
                  {cat.label}
                </div>
                <div className="space-y-1">
                  {files.map((file) => {
                    const isSelected = selectedFile.name === file.name;
                    return (
                      <button
                        key={file.name}
                        onClick={() => setSelectedFile(file)}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-mono transition-all flex items-center gap-2 cursor-pointer ${
                          isSelected
                            ? 'bg-indigo-600/20 text-indigo-300 font-semibold border border-indigo-500/30'
                            : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                        }`}
                      >
                        <FileCode className={`w-3.5 h-3.5 ${isSelected ? 'text-indigo-400' : 'text-slate-500'}`} />
                        <span className="truncate">{file.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Editor Area */}
        <div className="flex-1 flex flex-col bg-slate-900 overflow-hidden">
          {/* File Tab Header */}
          <div className="bg-slate-950/40 border-b border-slate-800 px-4 py-2 flex items-center justify-between">
            <div className="flex items-center gap-2 font-mono text-xs text-slate-300">
              <span className="text-slate-500">path:</span>
              <span className="text-indigo-400 font-semibold">{selectedFile.path}</span>
            </div>

            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700/60 transition-all cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400 font-medium">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>

          {/* Code Viewer with Line Numbers */}
          <div className="flex-1 overflow-auto p-4 font-mono text-xs text-slate-200 leading-relaxed bg-slate-950/20">
            <pre className="relative">
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
