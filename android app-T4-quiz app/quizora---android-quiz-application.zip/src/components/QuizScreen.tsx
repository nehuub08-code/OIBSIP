import React, { useState } from 'react';
import { QuestionItem } from '../data/questionsData';
import { playCorrectSound, playWrongSound, playClickSound } from '../utils/audio';
import { CheckCircle2, XCircle, ArrowRight, AlertCircle, Award } from 'lucide-react';

interface QuizScreenProps {
  questions: QuestionItem[];
  currentIndex: number;
  onAnswerSelected: (isCorrect: boolean) => void;
  onNextQuestion: () => void;
  isAnswerSubmitted: boolean;
  selectedOptionIndex: number | null;
  score: number;
}

export const QuizScreen: React.FC<QuizScreenProps> = ({
  questions,
  currentIndex,
  onAnswerSelected,
  onNextQuestion,
  isAnswerSubmitted,
  selectedOptionIndex,
  score,
}) => {
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const currentQuestion = questions[currentIndex];
  const totalQuestions = questions.length;
  const progressPercent = Math.round(((currentIndex + 1) / totalQuestions) * 100);

  const handleOptionClick = (optionText: string, index: number) => {
    if (isAnswerSubmitted) return; // Prevent multiple answers or tamper

    const isCorrect = optionText === currentQuestion.correctAnswer;
    if (isCorrect) {
      playCorrectSound();
    } else {
      playWrongSound();
    }

    onAnswerSelected(isCorrect);
  };

  const handleNextClick = () => {
    if (!isAnswerSubmitted) {
      setToastMessage("Please select an answer to continue!");
      setTimeout(() => setToastMessage(null), 2500);
      return;
    }
    playClickSound();
    onNextQuestion();
  };

  const isFinalQuestion = currentIndex === totalQuestions - 1;
  const optionLetters = ['A', 'B', 'C', 'D'];

  return (
    <div className="flex flex-col h-full bg-[#F8F9FD] p-5 text-slate-800 justify-between select-none relative overflow-y-auto">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="absolute top-4 left-4 right-4 z-50 animate-bounce">
          <div className="bg-slate-900/90 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-lg flex items-center gap-2 backdrop-blur-xs">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Top Header: Counter & Category */}
      <div>
        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-[#6C5CE7] tracking-wide">
              Question {currentIndex + 1} of {totalQuestions}
            </span>
            <span className="text-[10px] bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full font-bold">
              Score: {score}
            </span>
          </div>
          <span className="text-[11px] font-semibold text-slate-500 bg-slate-200/80 px-2.5 py-0.5 rounded-full truncate max-w-[140px]">
            {currentQuestion.category}
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden mt-3">
          <div
            className="bg-gradient-to-r from-[#6C5CE7] to-[#8054F7] h-full rounded-full transition-all duration-300 ease-out"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Question Card */}
        <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-xs mt-4">
          <h2 className="text-base font-bold text-slate-800 leading-snug">
            {currentQuestion.question}
          </h2>
        </div>
      </div>

      {/* Answer Options */}
      <div className="space-y-2.5 my-3">
        {currentQuestion.options.map((option, index) => {
          const isSelected = selectedOptionIndex === index;
          const isCorrectAnswer = option === currentQuestion.correctAnswer;
          
          let cardStyle = "bg-white border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/20";
          let badgeStyle = "bg-slate-100 text-slate-700";
          let textStyle = "text-slate-700 font-medium";

          if (isAnswerSubmitted) {
            if (isSelected) {
              if (isCorrectAnswer) {
                // Correctly chosen
                cardStyle = "bg-[#E8F8F0] border-[#2ECC71] ring-2 ring-[#2ECC71]/30 shadow-xs";
                badgeStyle = "bg-[#2ECC71] text-white";
                textStyle = "text-[#27AE60] font-bold";
              } else {
                // Wrong chosen
                cardStyle = "bg-[#FDF0ED] border-[#E74C3C] ring-2 ring-[#E74C3C]/30 shadow-xs";
                badgeStyle = "bg-[#E74C3C] text-white";
                textStyle = "text-[#C0392B] font-bold";
              }
            } else if (isCorrectAnswer) {
              // Reveal correct answer if user picked wrong
              cardStyle = "bg-[#E8F8F0] border-[#2ECC71] shadow-xs";
              badgeStyle = "bg-[#2ECC71] text-white";
              textStyle = "text-[#27AE60] font-bold";
            } else {
              // Other options dimmed
              cardStyle = "bg-slate-50 border-slate-200/60 opacity-60";
              badgeStyle = "bg-slate-200 text-slate-400";
              textStyle = "text-slate-400";
            }
          }

          return (
            <button
              key={index}
              onClick={() => handleOptionClick(option, index)}
              disabled={isAnswerSubmitted}
              className={`w-full text-left p-3.5 rounded-2xl border-2 transition-all flex items-center justify-between cursor-pointer disabled:cursor-default ${cardStyle}`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`w-7 h-7 rounded-full text-xs font-bold flex items-center justify-center shrink-0 transition-colors ${badgeStyle}`}
                >
                  {optionLetters[index]}
                </span>
                <span className={`text-sm ${textStyle}`}>{option}</span>
              </div>

              {/* Status Icons */}
              {isAnswerSubmitted && (
                <div>
                  {isCorrectAnswer && (
                    <CheckCircle2 className="w-5 h-5 text-[#2ECC71] shrink-0" />
                  )}
                  {isSelected && !isCorrectAnswer && (
                    <XCircle className="w-5 h-5 text-[#E74C3C] shrink-0" />
                  )}
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Immediate Feedback Explanation Box */}
      {isAnswerSubmitted && (
        <div
          className={`rounded-2xl p-3.5 border mb-3 animate-fadeIn ${
            currentQuestion.options[selectedOptionIndex ?? 0] === currentQuestion.correctAnswer
              ? "bg-[#E8F8F0] border-[#2ECC71]/40 text-emerald-950"
              : "bg-[#FDF0ED] border-[#E74C3C]/40 text-rose-950"
          }`}
        >
          <div className="flex items-center gap-1.5 font-bold text-xs">
            {currentQuestion.options[selectedOptionIndex ?? 0] === currentQuestion.correctAnswer ? (
              <span className="text-[#27AE60] flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" /> Correct!
              </span>
            ) : (
              <span className="text-[#C0392B] flex items-center gap-1">
                <XCircle className="w-4 h-4" /> Not quite! Correct: {currentQuestion.correctAnswer}
              </span>
            )}
          </div>
          <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
            {currentQuestion.explanation}
          </p>
        </div>
      )}

      {/* Next Button */}
      <button
        onClick={handleNextClick}
        className={`w-full py-3.5 px-6 rounded-2xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${
          isAnswerSubmitted
            ? "bg-gradient-to-r from-[#6C5CE7] to-[#8054F7] text-white shadow-indigo-500/30 hover:shadow-indigo-500/40 active:scale-[0.98]"
            : "bg-slate-200 text-slate-400 cursor-not-allowed shadow-none"
        }`}
      >
        <span>{isFinalQuestion ? "See Results" : "Next Question"}</span>
        <ArrowRight className="w-4 h-4" />
      </button>
    </div>
  );
};
