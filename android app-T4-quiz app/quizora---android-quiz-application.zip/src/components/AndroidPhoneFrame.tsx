import React from 'react';
import { Wifi, BatteryMedium, Signal, ChevronLeft, Circle, Square } from 'lucide-react';

interface AndroidPhoneFrameProps {
  children: React.ReactNode;
  onBackPressed?: () => void;
  onHomePressed?: () => void;
  title?: string;
}

export const AndroidPhoneFrame: React.FC<AndroidPhoneFrameProps> = ({
  children,
  onBackPressed,
  onHomePressed,
  title = "Quizora",
}) => {
  return (
    <div className="relative mx-auto select-none">
      {/* Outer Phone Bezel */}
      <div className="relative w-[360px] h-[730px] bg-slate-900 rounded-[50px] p-3.5 shadow-2xl ring-1 ring-slate-800 shadow-slate-950/40 flex flex-col justify-between">
        
        {/* Hardware Buttons on chassis */}
        {/* Volume buttons */}
        <div className="absolute -left-[5px] top-[140px] w-[5px] h-[45px] bg-slate-800 rounded-l-md" />
        <div className="absolute -left-[5px] top-[195px] w-[5px] h-[45px] bg-slate-800 rounded-l-md" />
        {/* Power button */}
        <div className="absolute -right-[5px] top-[160px] w-[5px] h-[65px] bg-slate-800 rounded-r-md" />

        {/* Screen Bezel / Inner display */}
        <div className="relative w-full h-full bg-[#F8F9FD] rounded-[38px] overflow-hidden flex flex-col border border-slate-700/30">
          
          {/* Android Status Bar */}
          <div className="h-7 w-full bg-[#F8F9FD] flex items-center justify-between px-6 pt-1 text-slate-800 text-[11px] font-bold z-30 shrink-0 select-none">
            {/* Clock */}
            <span>12:22</span>

            {/* Camera Punch Hole */}
            <div className="w-3.5 h-3.5 bg-black rounded-full ring-2 ring-slate-900/10" />

            {/* Status Icons */}
            <div className="flex items-center gap-1.5 text-slate-700">
              <Signal className="w-3 h-3 stroke-[2.5]" />
              <Wifi className="w-3 h-3 stroke-[2.5]" />
              <div className="flex items-center gap-0.5">
                <span className="text-[10px] font-semibold">98%</span>
                <BatteryMedium className="w-3.5 h-3.5 stroke-[2.5]" />
              </div>
            </div>
          </div>

          {/* Android App Content Area */}
          <div className="flex-1 overflow-hidden relative">
            {children}
          </div>

          {/* Android Navigation Bar */}
          <div className="h-10 w-full bg-[#F8F9FD] border-t border-slate-200/50 flex items-center justify-around px-8 py-1 z-30 shrink-0">
            {/* Back Button */}
            <button
              onClick={onBackPressed}
              title="Android Back"
              className="p-2 text-slate-400 hover:text-slate-700 active:scale-90 transition-transform cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4 stroke-[2.5]" />
            </button>
            {/* Home Button */}
            <button
              onClick={onHomePressed}
              title="Android Home"
              className="p-2 text-slate-400 hover:text-slate-700 active:scale-90 transition-transform cursor-pointer"
            >
              <Circle className="w-3.5 h-3.5 stroke-[2.5]" />
            </button>
            {/* Recents Button */}
            <button
              title="Android Overview / Recents"
              className="p-2 text-slate-400 hover:text-slate-700 active:scale-90 transition-transform cursor-pointer"
            >
              <Square className="w-3.5 h-3.5 stroke-[2.5]" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
