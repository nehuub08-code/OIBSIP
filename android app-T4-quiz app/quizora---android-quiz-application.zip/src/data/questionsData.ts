export interface QuestionItem {
  id: number;
  question: string;
  options: [string, string, string, string];
  correctAnswer: string;
  explanation: string;
  category: string;
}

export const MASTER_QUESTION_BANK: QuestionItem[] = [
  {
    id: 1,
    question: "Which planet in our solar system is known as the Red Planet?",
    options: ["Venus", "Mars", "Jupiter", "Saturn"],
    correctAnswer: "Mars",
    explanation: "Mars appears reddish due to iron oxide (rust) covering its rocky surface.",
    category: "Space & Astronomy"
  },
  {
    id: 2,
    question: "Who wrote the famous romantic tragedy 'Romeo and Juliet'?",
    options: ["Charles Dickens", "William Shakespeare", "Mark Twain", "Jane Austen"],
    correctAnswer: "William Shakespeare",
    explanation: "William Shakespeare wrote Romeo and Juliet in the late 16th century around 1595.",
    category: "Literature & Arts"
  },
  {
    id: 3,
    question: "What is widely considered the powerhouse of the biological cell?",
    options: ["Nucleus", "Mitochondria", "Ribosome", "Endoplasmic Reticulum"],
    correctAnswer: "Mitochondria",
    explanation: "Mitochondria generate ATP (adenosine triphosphate), the chemical energy currency of cells.",
    category: "Science & Biology"
  },
  {
    id: 4,
    question: "What is the chemical symbol for Gold in the Periodic Table?",
    options: ["Gd", "Ag", "Au", "Fe"],
    correctAnswer: "Au",
    explanation: "Au originates from 'Aurum', the Latin word signifying glowing dawn or gold.",
    category: "Science & Chemistry"
  },
  {
    id: 5,
    question: "Which is the longest river in the world by total length?",
    options: ["Amazon River", "Nile River", "Yangtze River", "Mississippi River"],
    correctAnswer: "Nile River",
    explanation: "The Nile River extends approximately 6,650 km (4,132 miles) through northeastern Africa.",
    category: "Geography"
  },
  {
    id: 6,
    question: "In computer technology, what does the acronym 'RAM' stand for?",
    options: ["Read Access Memory", "Random Access Memory", "Run Action Module", "Real Audio Matrix"],
    correctAnswer: "Random Access Memory",
    explanation: "RAM provides high-speed volatile read/write storage actively accessed by the CPU.",
    category: "Computer Science"
  },
  {
    id: 7,
    question: "In which year did Apollo 11 successfully land humans on the Moon?",
    options: ["1965", "1969", "1972", "1975"],
    correctAnswer: "1969",
    explanation: "Commander Neil Armstrong and Buzz Aldrin stepped onto the lunar surface on July 20, 1969.",
    category: "History & Space"
  },
  {
    id: 8,
    question: "Which gas makes up approximately 78% of Earth's atmosphere?",
    options: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Argon"],
    correctAnswer: "Nitrogen",
    explanation: "Nitrogen comprises roughly 78.08% of dry air, with oxygen taking about 20.95%.",
    category: "Earth Science"
  },
  {
    id: 9,
    question: "Which Asian country is famously referred to as the 'Land of the Rising Sun'?",
    options: ["China", "Japan", "South Korea", "Thailand"],
    correctAnswer: "Japan",
    explanation: "The name Nippon or Nihon means 'sun origin' relative to mainland Asia.",
    category: "Geography"
  },
  {
    id: 10,
    question: "Who is historically acclaimed as the 'Father of Computers'?",
    options: ["Alan Turing", "Charles Babbage", "John von Neumann", "Ada Lovelace"],
    correctAnswer: "Charles Babbage",
    explanation: "Charles Babbage originated the concept of a programmable mechanical computer in the 1830s.",
    category: "Computer Science"
  },
  {
    id: 11,
    question: "What is the hardest naturally occurring mineral substance on Earth?",
    options: ["Titanium", "Graphene", "Diamond", "Quartz"],
    correctAnswer: "Diamond",
    explanation: "Diamond scores a maximum 10 on Mohs scale because of its rigid covalent carbon lattice.",
    category: "Science"
  },
  {
    id: 12,
    question: "Which ocean is the largest and deepest on planet Earth?",
    options: ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"],
    correctAnswer: "Pacific Ocean",
    explanation: "The Pacific Ocean spans more than 63 million square miles and holds the Mariana Trench.",
    category: "Geography"
  },
  {
    id: 13,
    question: "Approximately what is the speed of light in a vacuum?",
    options: ["150,000 km/s", "300,000 km/s", "450,000 km/s", "600,000 km/s"],
    correctAnswer: "300,000 km/s",
    explanation: "The speed of light in vacuum is approximately 299,792 km/s (~300,000 km/s).",
    category: "Physics"
  },
  {
    id: 14,
    question: "Which programming language was originally used as the primary language for Android apps?",
    options: ["Swift", "Java", "Ruby", "PHP"],
    correctAnswer: "Java",
    explanation: "Android SDK was built around Java, supported alongside Kotlin by Google.",
    category: "Technology"
  },
  {
    id: 15,
    question: "Which organ in the human body secretes insulin to regulate blood glucose?",
    options: ["Liver", "Kidney", "Pancreas", "Gallbladder"],
    correctAnswer: "Pancreas",
    explanation: "The endocrine islets of Langerhans in the pancreas produce insulin and glucagon.",
    category: "Biology"
  }
];

/**
 * Returns a randomized subset of questions (default 10)
 * Preserves the exact question-correct answer relation.
 */
export function getShuffledQuestions(count = 10): QuestionItem[] {
  const shuffled = [...MASTER_QUESTION_BANK].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}
