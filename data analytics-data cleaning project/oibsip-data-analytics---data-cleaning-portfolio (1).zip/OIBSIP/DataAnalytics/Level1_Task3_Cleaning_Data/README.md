# OIBSIP Data Analytics — Level 1 Task 3: Cleaning Data

[![Track](https://img.shields.io/badge/Track-Data%20Analytics-blue.svg)](https://oasisinfobyte.com/)
[![Level](https://img.shields.io/badge/Level-1%20Task%203-green.svg)](https://oasisinfobyte.com/)
[![Python](https://img.shields.io/badge/Python-3.10%2B-brightgreen.svg)](https://www.python.org/)
[![Pandas](https://img.shields.io/badge/Pandas-2.3%2B-orange.svg)](https://pandas.pydata.org/)
[![Status](https://img.shields.io/badge/Status-Completed%20%26%20Verified-success.svg)](#)

---

## 1. Project Overview
This repository contains the complete submission for **Task 3 (Cleaning Data)** under **Level 1** of the **Oasis Infobyte Internship Program (OIBSIP) — Data Analytics Track**.

The core objective of this project is to take a contaminated, real-world Point-of-Sale (POS) transaction dataset containing over 10,000 corrupted and missing cells, and systematically transform it into a production-grade, 100% compliant analytical asset. The project demonstrates senior data engineering judgment, applying **domain-specific deterministic deduction** rather than naive automated imputations, and maintains an unbroken audit log of every transformation.

---

## 2. Key Highlights & Achievements
* **100% Defect Elimination:** Eliminated 10,082 effective missing/corrupted values across 8 columns.
* **Deterministic Pricing Recovery:** Reconstructed 479 missing unit prices using fixed cafe menu catalog mapping.
* **Cross-Field Mathematical Deduction:** Recomputed 479 missing total spent values, 456 quantities, 48 unit prices, and 489 missing item names with 100% mathematical precision.
* **Audited Outlier Retention:** Investigated 259 transactions at $25.00 flagged by the 1.5 × IQR rule; verified as legitimate multi-item catering orders (5 Salads @ $5.00) and retained to protect revenue fidelity.
* **Transparent Row Pruning:** Retained 9,514 verified transactions (95.14% retention rate), pruning only 486 unrecoverable entries (460 missing timestamps + 26 blank financials).
* **Secured Revenue:** Preserved **$84,868.50** in verified retail revenue.

---

## 3. Repository Folder Structure

```text
OIBSIP/
└── DataAnalytics/
    └── Level1_Task3_Cleaning_Data/
        ├── README.md                          # Project documentation and quickstart
        ├── requirements.txt                   # Dependency specifications
        ├── .gitignore                         # Version control exclusions
        ├── pipeline.py                        # Automated Python cleaning pipeline
        ├── build_and_execute_notebook.py      # Notebook generation and execution engine
        ├── data_cleaning.ipynb                # Executed Jupyter Notebook with outputs
        ├── data/
        │   ├── README.md                      # Dataset source, license, and schema details
        │   └── dirty_cafe_sales.csv           # Raw, immutable dataset (10,000 rows)
        ├── outputs/
        │   ├── cleaned_dataset.csv            # Clean, production-ready dataset (9,514 rows)
        │   ├── data_quality_report.csv        # Baseline audit and anomaly metrics
        │   ├── cleaning_log.csv               # 15-step chronological transformation audit
        │   └── before_after_summary.csv       # Comparative quality matrix
        └── reports/
            └── data_cleaning_report.md        # Comprehensive technical report
```

---

## 4. Dataset Source & Metadata
* **Dataset Title:** Cafe Sales - Dirty Data for Cleaning Training
* **Creator / Publisher:** Ahmed Mohamed
* **Original Host:** [Kaggle Dataset](https://www.kaggle.com/datasets/ahmedmohamed2003/cafe-sales-dirty-data-for-cleaning-training)
* **License:** Creative Commons Zero (CC0: Public Domain)
* **Dimensions:** 10,000 rows × 8 columns (~538 KB)
* **Unit of Observation:** A single POS customer purchase receipt

---

## 5. Environment Setup & Execution Guide

### 5.1 Clone & Navigate
```bash
git clone <YOUR_REPOSITORY_URL>
cd OIBSIP/DataAnalytics/Level1_Task3_Cleaning_Data/
```

### 5.2 Set Up Virtual Environment
```bash
# Create virtual environment
python -m venv .venv

# Activate environment:
# On Windows:
.venv\Scripts\activate
# On macOS / Linux:
source .venv/bin/activate
```

### 5.3 Install Dependencies
```bash
pip install -r requirements.txt
```

### 5.4 Run the Cleaning Pipeline
You can execute the automated cleaning pipeline via CLI:
```bash
python pipeline.py
```

### 5.5 Launch & Explore the Jupyter Notebook
```bash
jupyter notebook data_cleaning.ipynb
```

---

## 6. Before-Versus-After Quality Comparison

| Metric | Before Cleaning (Raw) | After Cleaning (Clean) | Net Improvement / Action |
|---|---:|---:|---|
| **Total Row Count** | 10,000 | 9,514 | -486 (-4.86% unrecoverable rows pruned) |
| **Total Column Count** | 8 | 8 | Preserved complete business schema |
| **Missing / Corrupted Cells** | 10,082 | 0 | **-10,082 (-100% defect elimination)** |
| **Exact Duplicate Rows** | 0 | 0 | 0 (Verified unique transaction keys) |
| **Columns with Target Types** | 1 (12.5%) | 8 (100.0%) | +7 (+87.5% schema compliance) |
| **Columns Checked for Types** | 8 | 8 | All 8 columns verified |
| **Statistical Outliers (IQR)** | 259 | 259 (Retained) | 0 removed (Genuine high-volume orders) |
| **Rows Removed (Unrecoverable)** | 0 | 486 | Audited: 460 missing dates + 26 empty rows |
| **Data Completeness Rate** | 87.40% | 100.00% | **+12.60% absolute improvement** |
| **Total Verified Revenue ($)** | $87,416.00 (Unvalidated) | **$84,868.50** | $84,868.50 clean revenue secured |

---

## 7. Cleaning Methodology Summary

1. **Placeholder Standardization:** Converted literal string errors (`"UNKNOWN"` and `"ERROR"`) to standard IEEE `NaN` across all columns.
2. **Deterministic Catalog Lookup:** Mapped unit prices from the cafe menu catalog (Cookie: $1.00, Tea: $1.50, Coffee: $2.00, Cake: $3.00, Juice: $3.00, Sandwich: $4.00, Smoothie: $4.00, Salad: $5.00).
3. **Cross-Field Mathematical Deduction:**
   * `Price Per Unit = Total Spent / Quantity`
   * `Total Spent = Quantity × Price Per Unit`
   * `Quantity = round(Total Spent / Price Per Unit)`
   * Reverse mapped unique prices ($1.00, $1.50, $2.00, $5.00) to recover item names.
4. **Categorical Null Handling:**
   * Handled ambiguous items ($3.00 and $4.00) by assigning `"Unspecified Item"`.
   * Preserved high-missingness fields (`Payment Method` and `Location`) by imputing `"Unknown"`, preventing mode imputation bias.
5. **Row Pruning:** Pruned 460 rows missing purchase dates and 26 rows with blank financials.
6. **Strict Schema Casting:** Formatted identifiers as strings, unit counts as `int64`, prices/totals as `float64`, and timestamps as ISO `YYYY-MM-DD`.
7. **Outlier Auditing:** Applied 1.5 × IQR rule on `Total Spent` (threshold: $24.00); retained 259 genuine $25.00 orders.
8. **Reload Validation:** Automated roundtrip assertion test verifying zero data loss on serialization.

---

## 8. Attribution & Acknowledgments
* **Host Organization:** Oasis Infobyte (OIBSIP) — Data Analytics Internship
* **Dataset Contributor:** Ahmed Mohamed (Kaggle)
* **License:** Creative Commons Zero (CC0: Public Domain)
