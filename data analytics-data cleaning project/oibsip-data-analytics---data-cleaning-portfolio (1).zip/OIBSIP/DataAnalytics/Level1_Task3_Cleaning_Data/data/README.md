# Dataset Documentation & Provenance

## 1. Dataset Overview
* **Dataset Title:** Cafe Sales - Dirty Data for Cleaning Training
* **Raw Filename:** `dirty_cafe_sales.csv`
* **File Location in Repository:** `OIBSIP/DataAnalytics/Level1_Task3_Cleaning_Data/data/dirty_cafe_sales.csv`
* **Author / Publisher:** Ahmed Mohamed
* **Original Host:** [Kaggle Dataset Hub](https://www.kaggle.com/datasets/ahmedmohamed2003/cafe-sales-dirty-data-for-cleaning-training)
* **Secondary Mirror:** [Hugging Face Datasets Mirror](https://huggingface.co/datasets/jason1966/ahmedmohamed2003_cafe-sales-dirty-data-for-cleaning-training)
* **License:** Creative Commons Zero (CC0: Public Domain)
* **File Size:** ~538 KB (10,000 rows × 8 columns)

---

## 2. Unit of Observation & Commercial Context
The dataset contains transaction logs captured by a cafe's electronic Point-of-Sale (POS) terminal over the calendar year 2023 (from `2023-01-01` to `2023-12-31`). 
Each individual row corresponds to a **single customer retail purchase receipt** containing order details, item quantity, pricing, customer tender method, and store channel.

---

## 3. Schema & Baseline Column Definitions

| Column Name | Raw Storage Type | Expected Semantic Type | Description |
|---|---|---|---|
| `Transaction ID` | `object` (string) | String Identifier | Unique transaction code (format: `TXN_XXXXXXX`). |
| `Item` | `object` (string) | Categorical String | Product purchased from the cafe catalog (e.g., Coffee, Cake, Salad). |
| `Quantity` | `object` (string) | Integer (`int64`) | Number of units purchased (1 to 5 units). |
| `Price Per Unit` | `object` (string) | Float (`float64`) | Fixed menu price in USD ($1.00 to $5.00). |
| `Total Spent` | `object` (string) | Float (`float64`) | Total transaction amount ($1.00 to $25.00), governed by `Quantity × Price Per Unit`. |
| `Payment Method` | `object` (string) | Categorical String | Payment method tendered (`Credit Card`, `Cash`, `Digital Wallet`). |
| `Location` | `object` (string) | Categorical String | Dining channel (`In-store`, `Takeaway`). |
| `Transaction Date` | `object` (string) | Datetime (`datetime64`) | Calendar date of purchase in ISO format (`YYYY-MM-DD`). |

---

## 4. Observed Raw Data Quality Anomalies

A baseline audit performed on the raw file revealed **10,082 effective missing/corrupted cells**:

1. **Masked String Placeholders:** The string tokens `"UNKNOWN"` (1,670 instances) and `"ERROR"` (1,166 instances) were stored as literal text in both numerical and categorical columns.
2. **Missing Values (`NaN`):** 6,826 standard null entries across 7 columns (only `Transaction ID` was 100% complete).
3. **Severe Attribute Incompleteness:** `Payment Method` was missing 3,178 values (31.78%), and `Location` was missing 3,961 values (39.61%).
4. **All Columns Stored as Objects:** Numerical features (`Quantity`, `Price Per Unit`, `Total Spent`) and timestamps were loaded as generic Python strings.
5. **Statistical Outliers:** In `Total Spent`, 259 transactions were valued at $25.00, exceeding the 1.5 × IQR upper boundary of $24.00 (verified as 5 salads @ $5.00).

---

## 5. Download & Replication Instructions

If you need to re-download the raw dataset from scratch:

```bash
# Option 1: Direct Download via cURL
curl -L -o data/dirty_cafe_sales.csv https://huggingface.co/datasets/jason1966/ahmedmohamed2003_cafe-sales-dirty-data-for-cleaning-training/raw/main/dirty_cafe_sales.csv

# Option 2: Kaggle CLI
kaggle datasets download -d ahmedmohamed2003/cafe-sales-dirty-data-for-cleaning-training
unzip cafe-sales-dirty-data-for-cleaning-training.zip -d data/
```

Verify integrity with:
```bash
wc -l data/dirty_cafe_sales.csv
# Expected output: 10001 (header + 10,000 data rows)
```
