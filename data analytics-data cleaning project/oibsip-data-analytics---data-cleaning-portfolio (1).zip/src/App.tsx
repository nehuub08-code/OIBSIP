import React, { useState, useMemo } from 'react';
import {
  Database,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  Download,
  BookOpen,
  Filter,
  Search,
  ArrowRight,
  TrendingUp,
  ShieldCheck,
  RefreshCw,
  Sparkles,
  Layers,
  Terminal,
  Code2,
  ExternalLink,
  ChevronRight,
  Copy,
  Check,
  Building,
  Info
} from 'lucide-react';
import projectData from './data/projectData.json';

type TabType = 'overview' | 'quality_audit' | 'audit_log' | 'data_explorer' | 'outliers' | 'notebook' | 'report' | 'setup';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [explorerMode, setExplorerMode] = useState<'clean' | 'raw'>('clean');
  const [searchTerm, setSearchTerm] = useState('');
  const [itemFilter, setItemFilter] = useState('ALL');
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 12;

  const summary = projectData.summary;
  const dqReport = projectData.dataQualityReport;
  const cleaningLog = projectData.cleaningLog;
  const beforeAfter = projectData.beforeAfterSummary;
  const cleanSample = projectData.cleanSample;
  const rawSample = projectData.rawSample;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const downloadCSV = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadCleaned = () => {
    // Generate CSV string from clean sample or headers
    const headers = Object.keys(cleanSample[0]).join(',');
    const rows = cleanSample.map((r: any) => Object.values(r).join(',')).join('\n');
    downloadCSV(`${headers}\n${rows}`, 'cleaned_dataset_sample.csv');
  };

  // Filtered dataset explorer
  const filteredData = useMemo(() => {
    const dataset = explorerMode === 'clean' ? cleanSample : rawSample;
    return dataset.filter((row: any) => {
      const matchesSearch = Object.values(row).some((val) =>
        String(val).toLowerCase().includes(searchTerm.toLowerCase())
      );
      const matchesItem = itemFilter === 'ALL' || row.Item === itemFilter;
      return matchesSearch && matchesItem;
    });
  }, [explorerMode, searchTerm, itemFilter, cleanSample, rawSample]);

  const totalPages = Math.ceil(filteredData.length / rowsPerPage);
  const paginatedData = filteredData.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);

  const uniqueItems = useMemo(() => {
    const items = new Set<string>();
    cleanSample.forEach((r: any) => items.add(r.Item));
    return ['ALL', ...Array.from(items)];
  }, [cleanSample]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased selection:bg-indigo-500 selection:text-white">
      {/* Top Banner */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-400 p-0.5 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Database className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-base tracking-tight text-white">OIBSIP Data Analytics</span>
                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Level 1 | Task 3
                </span>
                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  Verified Clean
                </span>
              </div>
              <p className="text-xs text-slate-400">Data Cleaning & Quality Engineering Portfolio Project</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadCleaned}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium shadow-md shadow-indigo-600/20 transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Download Cleaned CSV
            </button>
            <a
              href="#reports"
              onClick={() => setActiveTab('report')}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition"
            >
              <BookOpen className="w-3.5 h-3.5" />
              Audit Report
            </a>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex overflow-x-auto gap-1 border-t border-slate-800/80 scrollbar-none py-1">
          {[
            { id: 'overview', label: 'Executive Overview', icon: TrendingUp },
            { id: 'quality_audit', label: 'Quality Audit (Before)', icon: AlertTriangle },
            { id: 'audit_log', label: 'Cleaning Plan & Log (15 Steps)', icon: ShieldCheck },
            { id: 'data_explorer', label: 'Dataset Explorer (Raw vs Clean)', icon: FileSpreadsheet },
            { id: 'outliers', label: 'Outlier Analysis (IQR)', icon: Sparkles },
            { id: 'notebook', label: 'Jupyter Notebook (12 Sections)', icon: Code2 },
            { id: 'report', label: 'Final Technical Report', icon: BookOpen },
            { id: 'setup', label: 'Reproducibility & GitHub', icon: Terminal },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600/15 text-indigo-400 border border-indigo-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* KPI Metric Cards */}
        <section className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-3.5 shadow-sm">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Raw Ingestion</span>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-xl font-bold text-white">{summary.totalRawRows.toLocaleString()}</span>
              <span className="text-[11px] text-slate-400">8 cols</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">Cafe POS Receipts</p>
          </div>

          <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-3.5 shadow-sm">
            <span className="text-[11px] font-medium text-emerald-400 uppercase tracking-wider">Cleaned Rows</span>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-xl font-bold text-emerald-400">{summary.totalCleanRows.toLocaleString()}</span>
              <span className="text-[11px] text-emerald-400/90 font-semibold">{summary.retentionRate}%</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">High retention rate</p>
          </div>

          <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-3.5 shadow-sm">
            <span className="text-[11px] font-medium text-sky-400 uppercase tracking-wider">Nulls Eliminated</span>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-xl font-bold text-sky-400">{summary.totalMissingBefore.toLocaleString()}</span>
              <span className="text-[11px] text-sky-400/90 font-semibold">→ 0</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">100% data completeness</p>
          </div>

          <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-3.5 shadow-sm">
            <span className="text-[11px] font-medium text-amber-400 uppercase tracking-wider">Pruned Records</span>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-xl font-bold text-amber-400">{summary.prunedRows}</span>
              <span className="text-[11px] text-slate-400">-4.86%</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">460 dates + 26 blanks</p>
          </div>

          <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-3.5 shadow-sm">
            <span className="text-[11px] font-medium text-indigo-400 uppercase tracking-wider">Outliers Verified</span>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-xl font-bold text-indigo-400">259</span>
              <span className="text-[11px] text-indigo-400/90 font-semibold">Retained</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">5 Salads @ $5.00 ($25)</p>
          </div>

          <div className="bg-slate-900 border border-slate-800/80 rounded-xl p-3.5 shadow-sm">
            <span className="text-[11px] font-medium text-purple-400 uppercase tracking-wider">Secured Revenue</span>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-xl font-bold text-purple-400">${summary.totalRevenueClean.toLocaleString()}</span>
              <span className="text-[11px] text-emerald-400 font-semibold">100%</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">Audit-ready revenue</p>
          </div>
        </section>

        {/* TAB 1: EXECUTIVE OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Before vs After Quality Summary */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <div>
                  <h2 className="text-base font-semibold text-white flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-indigo-400" />
                    Before vs After Data Quality Matrix
                  </h2>
                  <p className="text-xs text-slate-400">
                    Comprehensive audit comparing the raw contaminated dataset against the validated output
                  </p>
                </div>
                <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Outputs Verified in outputs/before_after_summary.csv
                </span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-800/60 text-slate-300 font-semibold uppercase tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="px-4 py-3">Quality Metric</th>
                      <th className="px-4 py-3">Before Cleaning (Raw)</th>
                      <th className="px-4 py-3">After Cleaning (Final)</th>
                      <th className="px-4 py-3">Variance / Net Impact</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
                    {beforeAfter.map((item: any, i: number) => (
                      <tr key={i} className="hover:bg-slate-800/30 transition">
                        <td className="px-4 py-2.5 font-sans font-medium text-white">{item.metric}</td>
                        <td className="px-4 py-2.5 text-rose-300">{item.before_cleaning}</td>
                        <td className="px-4 py-2.5 text-emerald-400 font-bold">{item.after_cleaning}</td>
                        <td className="px-4 py-2.5 font-sans text-xs text-indigo-300">{item.delta}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Core Architectural Decision Framework */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
                <div className="h-8 w-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold">
                  1
                </div>
                <h3 className="font-semibold text-sm text-white">Deterministic Price Recovery</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Rather than guessing prices with mean/median imputation, we leveraged the cafe menu catalog (Cookie=$1.0, Tea=$1.5, Coffee=$2.0, Cake=$3.0, Juice=$3.0, Sandwich=$4.0, Smoothie=$4.0, Salad=$5.0) to recover 479 unit prices with 100% precision.
                </p>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
                <div className="h-8 w-8 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center font-bold">
                  2
                </div>
                <h3 className="font-semibold text-sm text-white">Cross-Field Math Deduction</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Used the transactional identity <code className="text-sky-300">Total Spent = Quantity × Price</code> to compute 479 missing totals, 456 missing quantities, and recovered 489 missing item names through unique price tags ($1.00, $1.50, $2.00, $5.00).
                </p>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
                <div className="h-8 w-8 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center font-bold">
                  3
                </div>
                <h3 className="font-semibold text-sm text-white">Prudent Outlier Retention</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  259 orders at $25.00 exceeded the statistical threshold ($24.00). Investigation proved every order was 5 Salads @ $5.00. Retaining these orders protected $6,475 in genuine catering revenue from arbitrary deletion.
                </p>
              </div>
            </div>

            {/* Product & Payment Distribution Preview */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-indigo-400" />
                  Cleaned Menu Item Distribution
                </h3>
                <div className="space-y-2">
                  {Object.entries(projectData.itemDistribution).map(([item, count]: any) => (
                    <div key={item} className="flex items-center justify-between text-xs">
                      <span className="text-slate-300 font-medium">{item}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-32 bg-slate-800 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-indigo-500 h-full rounded-full"
                            style={{ width: `${(count / 1400) * 100}%` }}
                          />
                        </div>
                        <span className="font-mono text-slate-400 w-12 text-right">{count}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
                  Payment & Ordering Channels
                </h3>
                <div className="space-y-4">
                  <div>
                    <span className="text-xs font-medium text-slate-400 mb-1.5 block">Payment Method Tender</span>
                    <div className="grid grid-cols-2 gap-2">
                      {Object.entries(projectData.paymentDistribution).map(([method, count]: any) => (
                        <div key={method} className="bg-slate-800/60 border border-slate-700/50 p-2.5 rounded-lg text-xs">
                          <span className="text-slate-400 block text-[11px]">{method}</span>
                          <span className="font-bold text-white font-mono mt-0.5 block">{count.toLocaleString()} orders</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="text-xs font-medium text-slate-400 mb-1.5 block">Dining Location</span>
                    <div className="grid grid-cols-3 gap-2">
                      {Object.entries(projectData.locationDistribution).map(([loc, count]: any) => (
                        <div key={loc} className="bg-slate-800/60 border border-slate-700/50 p-2.5 rounded-lg text-xs">
                          <span className="text-slate-400 block text-[11px]">{loc}</span>
                          <span className="font-bold text-white font-mono mt-0.5 block">{count.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: DATA QUALITY REPORT */}
        {activeTab === 'quality_audit' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <div>
                  <h2 className="text-base font-semibold text-white flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    Initial Data Quality Report (Raw Assessment)
                  </h2>
                  <p className="text-xs text-slate-400">
                    Baseline profile generated before transformations. Saved to <code className="text-indigo-300">outputs/data_quality_report.csv</code>.
                  </p>
                </div>
                <span className="text-xs text-slate-400 font-mono">10,000 raw rows × 8 columns</span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-800/60 text-slate-300 font-semibold uppercase tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="px-3.5 py-3">Column Name</th>
                      <th className="px-3.5 py-3">Raw Dtype</th>
                      <th className="px-3.5 py-3">Standard Nulls</th>
                      <th className="px-3.5 py-3">String Placeholders</th>
                      <th className="px-3.5 py-3">Effective Missing</th>
                      <th className="px-3.5 py-3">Missing Rate</th>
                      <th className="px-3.5 py-3">Unique Values</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
                    {dqReport.map((col: any, idx: number) => {
                      const isClean = col['Total Effective Missing'] === 0;
                      const isSevere = col['Missing Pct (%)'] > 30;
                      return (
                        <tr key={idx} className="hover:bg-slate-800/30 transition">
                          <td className="px-3.5 py-2.5 font-sans font-medium text-white flex items-center gap-1.5">
                            {isClean ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                            ) : (
                              <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                            )}
                            {col.Column}
                          </td>
                          <td className="px-3.5 py-2.5 text-slate-400">{col['Raw Dtype']}</td>
                          <td className="px-3.5 py-2.5">{col['Standard Nulls']}</td>
                          <td className="px-3.5 py-2.5 text-amber-300">{col['Placeholder Strings']}</td>
                          <td className="px-3.5 py-2.5 text-rose-300 font-bold">{col['Total Effective Missing']}</td>
                          <td className="px-3.5 py-2.5">
                            <span
                              className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                                isClean
                                  ? 'bg-emerald-500/10 text-emerald-400'
                                  : isSevere
                                  ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                                  : 'bg-amber-500/10 text-amber-400'
                              }`}
                            >
                              {col['Missing Pct (%)']}%
                            </span>
                          </td>
                          <td className="px-3.5 py-2.5 text-slate-300">{col['Unique Values']}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-xs text-slate-300 space-y-2">
              <h3 className="font-semibold text-white flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-indigo-400" />
                Senior Analyst Diagnostic Commentary
              </h3>
              <p className="leading-relaxed">
                Notice that standard pandas null counting (<code className="text-indigo-300">df.isna().sum()</code>) only captured 6,826 nulls, completely missing the <strong>3,256 placeholder text strings</strong> (<code className="text-amber-300">'UNKNOWN'</code> and <code className="text-amber-300">'ERROR'</code>). This demonstrates why rigorous data profiling must check for masked text tokens before converting types or calculating imputation statistics.
              </p>
            </div>
          </div>
        )}

        {/* TAB 3: CLEANING LOG & AUDIT */}
        {activeTab === 'audit_log' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <div>
                  <h2 className="text-base font-semibold text-white flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    Complete Chronological Cleaning Audit Log (15 Steps)
                  </h2>
                  <p className="text-xs text-slate-400">
                    Transparent, reproducible record saved to <code className="text-indigo-300">outputs/cleaning_log.csv</code>.
                  </p>
                </div>
                <span className="text-xs font-medium px-2.5 py-1 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  15 Verifiable Stages
                </span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-800/60 text-slate-300 font-semibold uppercase tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="px-3 py-3 w-12 text-center">#</th>
                      <th className="px-3.5 py-3">Stage & Target Column</th>
                      <th className="px-3.5 py-3">Issue Detected</th>
                      <th className="px-3.5 py-3">Action Performed</th>
                      <th className="px-3.5 py-3 text-right">Affected</th>
                      <th className="px-3.5 py-3">Verification Result</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-300">
                    {cleaningLog.map((log: any) => (
                      <tr key={log.step_number} className="hover:bg-slate-800/30 transition">
                        <td className="px-3 py-3 text-center font-mono font-bold text-indigo-400">{log.step_number}</td>
                        <td className="px-3.5 py-3">
                          <span className="font-medium text-white block">{log.stage}</span>
                          <span className="text-[11px] text-slate-400 font-mono">{log.target_column}</span>
                        </td>
                        <td className="px-3.5 py-3 text-slate-300 max-w-xs">{log.issue_detected}</td>
                        <td className="px-3.5 py-3 text-slate-200 max-w-sm">{log.action_performed}</td>
                        <td className="px-3.5 py-3 font-mono font-semibold text-right text-indigo-300">
                          {log.records_affected.toLocaleString()}
                        </td>
                        <td className="px-3.5 py-3 text-emerald-400 font-mono text-[11px]">
                          {log.verification_result}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: DATASET EXPLORER */}
        {activeTab === 'data_explorer' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
                <div>
                  <h2 className="text-base font-semibold text-white flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-sky-400" />
                    Interactive Dataset Explorer
                  </h2>
                  <p className="text-xs text-slate-400">
                    Switch between the raw contaminated dataset and the cleaned analytical dataset
                  </p>
                </div>

                {/* Toggle Raw vs Cleaned */}
                <div className="flex items-center gap-2 bg-slate-950 p-1 rounded-xl border border-slate-800">
                  <button
                    onClick={() => {
                      setExplorerMode('clean');
                      setCurrentPage(1);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                      explorerMode === 'clean'
                        ? 'bg-emerald-600 text-white shadow'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Cleaned Dataset (9,514)
                  </button>
                  <button
                    onClick={() => {
                      setExplorerMode('raw');
                      setCurrentPage(1);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                      explorerMode === 'raw'
                        ? 'bg-amber-600 text-white shadow'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Raw Dataset (10,000)
                  </button>
                </div>
              </div>

              {/* Filters & Search */}
              <div className="flex flex-wrap items-center gap-3 mb-4">
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => {
                      setSearchTerm(e.target.value);
                      setCurrentPage(1);
                    }}
                    placeholder="Search by Transaction ID, Item, Payment, or Date..."
                    className="w-full pl-9 pr-3 py-1.5 bg-slate-800/80 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <Filter className="w-3.5 h-3.5 text-slate-400" />
                  <select
                    value={itemFilter}
                    onChange={(e) => {
                      setItemFilter(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="bg-slate-800/80 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
                  >
                    {uniqueItems.map((item) => (
                      <option key={item} value={item}>
                        {item === 'ALL' ? 'All Items' : item}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={handleDownloadCleaned}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition ml-auto"
                >
                  <Download className="w-3.5 h-3.5" />
                  Export Sample CSV
                </button>
              </div>

              {/* Data Table */}
              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-800/70 text-slate-300 font-semibold uppercase tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="px-3.5 py-2.5">Transaction ID</th>
                      <th className="px-3.5 py-2.5">Item</th>
                      <th className="px-3.5 py-2.5">Quantity</th>
                      <th className="px-3.5 py-2.5">Price Per Unit</th>
                      <th className="px-3.5 py-2.5">Total Spent</th>
                      <th className="px-3.5 py-2.5">Payment Method</th>
                      <th className="px-3.5 py-2.5">Location</th>
                      <th className="px-3.5 py-2.5">Transaction Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
                    {paginatedData.map((row: any, idx: number) => (
                      <tr key={idx} className="hover:bg-slate-800/30 transition">
                        <td className="px-3.5 py-2 text-indigo-400 font-medium">{row['Transaction ID']}</td>
                        <td className="px-3.5 py-2 font-sans text-slate-200">
                          {row.Item === 'UNKNOWN' || row.Item === 'ERROR' || row.Item === 'NaN' ? (
                            <span className="text-rose-400 font-mono font-bold bg-rose-500/10 px-1.5 py-0.5 rounded">
                              {row.Item}
                            </span>
                          ) : (
                            row.Item
                          )}
                        </td>
                        <td className="px-3.5 py-2">
                          {row.Quantity === 'UNKNOWN' || row.Quantity === 'ERROR' || row.Quantity === 'NaN' ? (
                            <span className="text-rose-400 font-mono font-bold bg-rose-500/10 px-1.5 py-0.5 rounded">
                              {row.Quantity}
                            </span>
                          ) : (
                            row.Quantity
                          )}
                        </td>
                        <td className="px-3.5 py-2">
                          {row['Price Per Unit'] === 'UNKNOWN' || row['Price Per Unit'] === 'ERROR' || row['Price Per Unit'] === 'NaN' ? (
                            <span className="text-rose-400 font-mono font-bold bg-rose-500/10 px-1.5 py-0.5 rounded">
                              {row['Price Per Unit']}
                            </span>
                          ) : (
                            `$${parseFloat(row['Price Per Unit']).toFixed(2)}`
                          )}
                        </td>
                        <td className="px-3.5 py-2 font-bold text-white">
                          {row['Total Spent'] === 'UNKNOWN' || row['Total Spent'] === 'ERROR' || row['Total Spent'] === 'NaN' ? (
                            <span className="text-rose-400 font-mono font-bold bg-rose-500/10 px-1.5 py-0.5 rounded">
                              {row['Total Spent']}
                            </span>
                          ) : (
                            `$${parseFloat(row['Total Spent']).toFixed(2)}`
                          )}
                        </td>
                        <td className="px-3.5 py-2 font-sans text-slate-300">
                          {row['Payment Method'] === 'UNKNOWN' || row['Payment Method'] === 'ERROR' || row['Payment Method'] === 'NaN' ? (
                            <span className="text-rose-400 font-mono font-bold bg-rose-500/10 px-1.5 py-0.5 rounded">
                              {row['Payment Method']}
                            </span>
                          ) : (
                            row['Payment Method']
                          )}
                        </td>
                        <td className="px-3.5 py-2 font-sans text-slate-300">
                          {row.Location === 'UNKNOWN' || row.Location === 'ERROR' || row.Location === 'NaN' ? (
                            <span className="text-rose-400 font-mono font-bold bg-rose-500/10 px-1.5 py-0.5 rounded">
                              {row.Location}
                            </span>
                          ) : (
                            row.Location
                          )}
                        </td>
                        <td className="px-3.5 py-2 text-slate-400">
                          {row['Transaction Date'] === 'UNKNOWN' || row['Transaction Date'] === 'ERROR' || row['Transaction Date'] === 'NaN' ? (
                            <span className="text-rose-400 font-mono font-bold bg-rose-500/10 px-1.5 py-0.5 rounded">
                              {row['Transaction Date']}
                            </span>
                          ) : (
                            row['Transaction Date']
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              <div className="flex items-center justify-between text-xs text-slate-400 mt-4">
                <span>
                  Showing {(currentPage - 1) * rowsPerPage + 1} to{' '}
                  {Math.min(currentPage * rowsPerPage, filteredData.length)} of {filteredData.length} records
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage((p) => p - 1)}
                    className="px-2.5 py-1 rounded bg-slate-800 disabled:opacity-40 hover:bg-slate-700 transition"
                  >
                    Previous
                  </button>
                  <span className="px-2 font-mono">
                    Page {currentPage} of {totalPages || 1}
                  </span>
                  <button
                    disabled={currentPage >= totalPages}
                    onClick={() => setCurrentPage((p) => p + 1)}
                    className="px-2.5 py-1 rounded bg-slate-800 disabled:opacity-40 hover:bg-slate-700 transition"
                  >
                    Next
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: OUTLIER ANALYSIS */}
        {activeTab === 'outliers' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
              <div>
                <h2 className="text-base font-semibold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  Outlier Detection & Domain Judgment (IQR Method)
                </h2>
                <p className="text-xs text-slate-400">
                  Statistical formula: <code className="text-indigo-300">IQR = Q3 - Q1</code>, Upper Threshold ={' '}
                  <code className="text-indigo-300">Q3 + 1.5 × IQR</code>
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-800/40 border border-slate-800 p-4 rounded-xl">
                  <span className="text-xs font-semibold text-slate-400 uppercase">Quantity</span>
                  <div className="mt-2 space-y-1 text-xs">
                    <p className="text-slate-300">Q1: 2.0 | Q3: 4.0 (IQR: 2.0)</p>
                    <p className="text-slate-400 font-mono">Thresholds: [-1.0, 7.0]</p>
                    <p className="text-emerald-400 font-bold mt-2">0 Outliers Detected</p>
                  </div>
                </div>

                <div className="bg-slate-800/40 border border-slate-800 p-4 rounded-xl">
                  <span className="text-xs font-semibold text-slate-400 uppercase">Price Per Unit</span>
                  <div className="mt-2 space-y-1 text-xs">
                    <p className="text-slate-300">Q1: $2.00 | Q3: $4.00 (IQR: $2.00)</p>
                    <p className="text-slate-400 font-mono">Thresholds: [-$1.00, $7.00]</p>
                    <p className="text-emerald-400 font-bold mt-2">0 Outliers Detected</p>
                  </div>
                </div>

                <div className="bg-slate-800/40 border border-slate-800 p-4 rounded-xl">
                  <span className="text-xs font-semibold text-amber-400 uppercase">Total Spent</span>
                  <div className="mt-2 space-y-1 text-xs">
                    <p className="text-slate-300">Q1: $4.00 | Q3: $12.00 (IQR: $8.00)</p>
                    <p className="text-amber-300 font-mono font-bold">Upper Threshold: $24.00</p>
                    <p className="text-amber-400 font-bold mt-2">259 Transactions @ $25.00</p>
                  </div>
                </div>
              </div>

              {/* RETAIN Decision Card */}
              <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/30 rounded-xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
                  <CheckCircle2 className="w-4 h-4" />
                  Senior Analyst Decision: RETAIN ALL 259 TRANSACTIONS
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Every single transaction flagged at $25.00 was audited at the individual order line item level. All 259
                  records consist of <strong>5 units of Salad @ $5.00 = $25.00</strong>. This represents a legitimate
                  corporate lunch or catering order. Capping these transactions to $24.00 or deleting them would artificially
                  censor genuine retail revenue and bias average transaction value metrics downward.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: JUPYTER NOTEBOOK */}
        {activeTab === 'notebook' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-base font-semibold text-white flex items-center gap-2">
                    <Code2 className="w-4 h-4 text-indigo-400" />
                    Jupyter Notebook Architecture (data_cleaning.ipynb)
                  </h2>
                  <p className="text-xs text-slate-400">
                    Fully executed 31-cell Jupyter Notebook with markdown commentary and live outputs
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono px-2.5 py-1 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    Kernel: Python 3 (ipykernel)
                  </span>
                </div>
              </div>

              <div className="space-y-3">
                {[
                  { section: '1', title: 'Introduction & Project Context', type: 'Markdown', desc: 'Overview of data cleaning, dirty cafe sales dataset, and domain principles.' },
                  { section: '2', title: 'Import Libraries & Load Raw Dataset', type: 'Code & Output', desc: 'Relative path loading, immutability of raw dataset, head/info checks.' },
                  { section: '3', title: 'Generate Initial Data Quality Report', type: 'Code & Output', desc: 'Profilers for standard nulls, string placeholders (UNKNOWN/ERROR), saving data_quality_report.csv.' },
                  { section: '4', title: 'Create Structured Cleaning Plan', type: 'Markdown Table', desc: 'Explicit roadmap mapping column, issue, planned action, rationale, and risks.' },
                  { section: '5', title: 'Handle Missing Data (Catalog & Math Deduction)', type: 'Code & Output', desc: 'Converting UNKNOWN/ERROR to NaN, menu catalog mapping, cross-field math, categorical imputation.' },
                  { section: '6', title: 'Identify & Audit Duplicate Rows', type: 'Code & Output', desc: 'Exact duplicate check (0 found), Transaction ID collision check (10,000 unique keys).' },
                  { section: '7', title: 'Standardize Inconsistent Formatting', type: 'Code & Output', desc: 'Whitespace stripping, ISO 8601 YYYY-MM-DD date normalization.' },
                  { section: '8', title: 'Detect & Handle Outliers (IQR Method)', type: 'Code & Output', desc: '1.5*IQR calculations on numerical features; audit and retention of $25 salad orders.' },
                  { section: '9', title: 'Correct Data Types', type: 'Code & Output', desc: 'Schema enforcement: int64, float64, clean strings, and date strings.' },
                  { section: '10', title: 'Produce Before-Versus-After Summary Table', type: 'Code & Output', desc: 'Comparative 10-metric matrix; saved to outputs/before_after_summary.csv.' },
                  { section: '11', title: 'Maintain Chronological Cleaning Log', type: 'Code & Output', desc: '15-step audit trail; saved to outputs/cleaning_log.csv.' },
                  { section: '12', title: 'Save Cleaned Dataset & Roundtrip Validation', type: 'Code & Output', desc: 'Exported outputs/cleaned_dataset.csv; reload assertion tests passing.' },
                ].map((s) => (
                  <div key={s.section} className="bg-slate-800/40 border border-slate-800/80 p-3.5 rounded-xl flex items-start gap-3">
                    <span className="h-6 w-6 rounded bg-indigo-600/20 text-indigo-400 font-mono text-xs font-bold flex items-center justify-center shrink-0">
                      {s.section}
                    </span>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-xs text-white">{s.title}</h3>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                          {s.type}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">{s.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: FINAL REPORT */}
        {activeTab === 'report' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-6 max-w-4xl mx-auto">
              <div className="border-b border-slate-800 pb-4">
                <span className="text-xs font-semibold uppercase text-indigo-400 tracking-wider">
                  OIBSIP Data Analytics — Level 1 Task 3
                </span>
                <h1 className="text-xl font-bold text-white mt-1">Data Cleaning & Quality Engineering Report</h1>
                <p className="text-xs text-slate-400 mt-1">
                  Full Markdown Report located in <code className="text-indigo-300">reports/data_cleaning_report.md</code>
                </p>
              </div>

              <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
                <h2 className="text-sm font-bold text-white uppercase tracking-wider text-indigo-400">
                  1. Executive Summary
                </h2>
                <p>
                  This project presents the systematic data cleaning and transformation of the 10,000-row <strong>Cafe Sales</strong> transaction dataset. Raw transaction streams generated by Point-of-Sale (POS) terminals frequently contain missing sensor logs, corrupted string placeholders, unstandardized text, unparsed dates, and mixed data types.
                </p>
                <p>
                  The final cleaned analytical asset achieved a <strong>100% completeness rate</strong>, eliminating <strong>10,082 effective defects</strong>, preserving <strong>$84,868.50 in verified revenue</strong>, and establishing a fully audited 15-step transformation log.
                </p>

                <h2 className="text-sm font-bold text-white uppercase tracking-wider text-indigo-400 pt-2">
                  2. Key Methodological Contributions
                </h2>
                <ul className="list-disc pl-5 space-y-1.5 text-slate-300">
                  <li>
                    <strong>Deterministic Catalog Recovery:</strong> Mapped fixed cafe pricing to resolve 479 missing unit prices without statistical variance.
                  </li>
                  <li>
                    <strong>Reverse Mathematical Deduction:</strong> Used transaction identities to recover 489 missing item names, 479 total spent figures, and 456 quantities.
                  </li>
                  <li>
                    <strong>Anti-Bias Categorical Imputation:</strong> Avoided skewing payment processor market shares by assigning explicit <code className="text-indigo-300">"Unknown"</code> labels rather than false modes.
                  </li>
                  <li>
                    <strong>Outlier Auditing:</strong> Retained 259 legitimate $25.00 salad catering orders to prevent revenue censorship.
                  </li>
                </ul>

                <h2 className="text-sm font-bold text-white uppercase tracking-wider text-indigo-400 pt-2">
                  3. Deliverables Summary
                </h2>
                <p>
                  All generated artifacts have been verified and persisted to disk:
                </p>
                <div className="grid grid-cols-2 gap-2 font-mono text-[11px] text-slate-400 pt-1">
                  <div className="bg-slate-800/60 p-2 rounded">outputs/cleaned_dataset.csv (9,514 rows)</div>
                  <div className="bg-slate-800/60 p-2 rounded">outputs/data_quality_report.csv</div>
                  <div className="bg-slate-800/60 p-2 rounded">outputs/cleaning_log.csv (15 steps)</div>
                  <div className="bg-slate-800/60 p-2 rounded">outputs/before_after_summary.csv</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 8: SETUP & GITHUB */}
        {activeTab === 'setup' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
              <div>
                <h2 className="text-base font-semibold text-white flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  Reproducibility & GitHub Submission Guide
                </h2>
                <p className="text-xs text-slate-400">
                  Step-by-step terminal instructions to set up the Python environment, execute the pipeline, and publish to GitHub
                </p>
              </div>

              {/* Command Cards */}
              <div className="space-y-3">
                <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-xl">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-slate-300">1. Virtual Environment & Dependencies</span>
                    <button
                      onClick={() =>
                        copyToClipboard(
                          'python -m venv .venv\nsource .venv/bin/activate\npip install -r requirements.txt',
                          'venv'
                        )
                      }
                      className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
                    >
                      {copiedCmd === 'venv' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedCmd === 'venv' ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <pre className="text-xs font-mono text-emerald-400 bg-slate-900 p-2.5 rounded overflow-x-auto">
{`# Create virtual environment
python -m venv .venv

# Activate (macOS / Linux)
source .venv/bin/activate
# On Windows: .venv\\Scripts\\activate

# Install dependencies
pip install -r requirements.txt`}
                  </pre>
                </div>

                <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-xl">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-slate-300">2. Run Cleaning Pipeline & Notebook</span>
                    <button
                      onClick={() =>
                        copyToClipboard('python pipeline.py\njupyter notebook data_cleaning.ipynb', 'run')
                      }
                      className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
                    >
                      {copiedCmd === 'run' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedCmd === 'run' ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <pre className="text-xs font-mono text-emerald-400 bg-slate-900 p-2.5 rounded overflow-x-auto">
{`# Execute the automated cleaning pipeline
python pipeline.py

# Launch interactive Jupyter Notebook
jupyter notebook data_cleaning.ipynb`}
                  </pre>
                </div>

                <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-xl">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-slate-300">3. GitHub Stage & Push Instructions</span>
                    <button
                      onClick={() =>
                        copyToClipboard(
                          'git status\ngit add OIBSIP/DataAnalytics/Level1_Task3_Cleaning_Data/\ngit commit -m "Add data cleaning project (Level 1 Task 3)"\ngit push origin main',
                          'git'
                        )
                      }
                      className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
                    >
                      {copiedCmd === 'git' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedCmd === 'git' ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <pre className="text-xs font-mono text-emerald-400 bg-slate-900 p-2.5 rounded overflow-x-auto">
{`# Stage only this task directory
git status
git add OIBSIP/DataAnalytics/Level1_Task3_Cleaning_Data/
git diff --cached
git commit -m "Add complete data cleaning project (OIBSIP Level 1 Task 3)"
git push origin main`}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
          <div>
            <span>Oasis Infobyte Internship Program (OIBSIP) — Data Analytics</span>
            <span className="mx-2">•</span>
            <span>Level 1 | Task 3: Cleaning Data</span>
          </div>
          <div className="flex items-center gap-3">
            <span>Dataset: Ahmed Mohamed (CC0 Public Domain)</span>
            <span>•</span>
            <span className="text-emerald-400 font-medium">9,514 Clean Records Verified</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
