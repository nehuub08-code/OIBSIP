# Unitify — Smart Unit Converter
### Oasis Infobyte | Android App Development Internship | Task 1

**Full Name:** Neha Vinod Borkar  
**Assigned Track:** Android App Development  
**Task Title:** Task 1 — Unit Converter Application  
**Repository Name:** OIBSIP  
**Tagline:** *Every measurement, simplified.*

---

## 📱 Project Overview
**Unitify** is a modern, responsive, and robust native Android application built using **Java and XML layouts**. Designed as part of the Oasis Infobyte Android Development Internship program, Unitify solves real-world measurement conversion challenges across **Length, Weight, Temperature, and Volume** with precision mathematics and an intuitive Material Design 3 interface.

---

## 🚀 Key Features

- **Four Conversion Categories:**
  1. **Length:** Millimetres (mm), Centimetres (cm), Metres (m), Kilometres (km), Inches (in), Feet (ft), Yards (yd), Miles (mi). Uses Metres as the common base unit.
  2. **Weight:** Milligrams (mg), Grams (g), Kilograms (kg), Ounces (oz), Pounds (lb), Metric tonnes (t). Uses Grams as the common base unit.
  3. **Temperature:** Celsius (°C), Fahrenheit (°F), Kelvin (K). Implements exact thermodynamic formulas with strict **physical absolute zero bounds checking**.
  4. **Volume (Bonus):** Millilitres (mL), Litres (L), US cups, US fluid ounces, US gallons. Uses Litres as the base unit.

- **Dynamic Category Switching:**
  - Automatically resets unit Spinners to appropriate defaults.
  - Clears stale results to prevent confusing states.
  - Adapts numeric keyboard hints (permits negative numbers for temperature).

- **Strict Input Validation:**
  - Rejects empty values with Android `Toast`: *"Please enter a value."*
  - Rejects non-numeric/alphabetic input: *"Please enter a valid number."*
  - Handles excessive numbers, NaN, and infinity gracefully.
  - Enforces physical laws: Rejects temperatures below absolute zero (e.g. `< -273.15 °C`, `< 0 K`, `< -459.67 °F`).

- **User-Centric Polish:**
  - **Unit Swap Button:** Inverts source and target units instantly with a single tap.
  - **Clear Input:** One-tap button to reset input and focus.
  - **Copy to Clipboard:** Copies formatted result string for instant sharing.
  - **Clean Decimal Formatting:** Removes trailing zeros (e.g., `1` instead of `1.000000`).
  - **100% Offline:** Operates entirely locally without internet access or external APIs.

---

## 🛠️ Technology Stack

- **IDE:** Android Studio Iguana / Jellyfish (Hedgehog+ compatible)
- **Programming Language:** Java (JDK 8 / 11 / 17)
- **UI Architecture:** XML Layouts, Material Design Components (`MaterialButtonToggleGroup`, `CardView`, `Spinner`, `EditText`)
- **Minimum SDK:** API 21 (Android 5.0 Lollipop - 99.8% device coverage)
- **Target SDK:** API 34 (Android 14)
- **Architecture Pattern:** Clean separation of concerns with `ConversionUtils.java` for formulas and `MainActivity.java` for UI lifecycle.

---

## 📐 Mathematical Formulas

### Length (Base: Metres)
- $1\text{ mm} = 0.001\text{ m}$
- $1\text{ cm} = 0.01\text{ m}$
- $1\text{ km} = 1000\text{ m}$
- $1\text{ in} = 0.0254\text{ m}$
- $1\text{ ft} = 0.3048\text{ m}$
- $1\text{ yd} = 0.9144\text{ m}$
- $1\text{ mi} = 1609.344\text{ m}$

### Weight (Base: Grams)
- $1\text{ mg} = 0.001\text{ g}$
- $1\text{ kg} = 1000\text{ g}$
- $1\text{ oz} = 28.349523125\text{ g}$
- $1\text{ lb} = 453.59237\text{ g}$
- $1\text{ metric tonne} = 1,000,000\text{ g}$

### Temperature (Direct Formulas)
- **°C to °F:** $^\circ\text{F} = (^\circ\text{C} \times 9/5) + 32$
- **°F to °C:** $^\circ\text{C} = (^\circ\text{F} - 32) \times 5/9$
- **°C to K:** $\text{K} = ^\circ\text{C} + 273.15$
- **K to °C:** $^\circ\text{C} = \text{K} - 273.15$
- **°F to K:** $\text{K} = (^\circ\text{F} - 32) \times 5/9 + 273.15$
- **K to °F:** $^\circ\text{F} = (\text{K} - 273.15) \times 9/5 + 32$

---

## 🧪 Comprehensive Verification & Test Cases

| Category | Input Value & Unit | Target Unit | Expected Output | Verification Status |
| :--- | :--- | :--- | :--- | :--- |
| **Length** | 100 cm | Metre (m) | `1 m` | **PASS** |
| **Length** | 1 km | Metre (m) | `1000 m` | **PASS** |
| **Length** | 12 in | Foot (ft) | `1 ft` | **PASS** |
| **Length** | 1 mi | Kilometre (km) | `1.609344 km` | **PASS** |
| **Weight** | 1000 g | Kilogram (kg) | `1 kg` | **PASS** |
| **Weight** | 1 kg | Gram (g) | `1000 g` | **PASS** |
| **Weight** | 1 lb | Gram (g) | `453.59237 g` | **PASS** |
| **Temperature** | 0 °C | Fahrenheit (°F) | `32 °F` | **PASS** |
| **Temperature** | 100 °C | Fahrenheit (°F) | `212 °F` | **PASS** |
| **Temperature** | 32 °F | Celsius (°C) | `0 °C` | **PASS** |
| **Temperature** | 0 °C | Kelvin (K) | `273.15 K` | **PASS** |
| **Temperature** | -40 °C | Fahrenheit (°F) | `-40 °F` | **PASS** |
| **Temperature** | -274 °C | Any | *Toast: Absolute Zero Error* | **PASS** |
| **Temperature** | -1 K | Any | *Toast: Absolute Zero Error* | **PASS** |
| **Validation** | *(empty)* | Any | *Toast: "Please enter a value."* | **PASS** |
| **Validation** | `abc` | Any | *Toast: "Please enter a valid number."*| **PASS** |

---

## 📂 Project Structure

```
OIBSIP/
└── Task1-UnitConverter/
    ├── app/
    │   ├── build.gradle
    │   └── src/
    │       └── main/
    │           ├── AndroidManifest.xml
    │           ├── java/
    │           │   └── com/example/unitify/
    │           │       ├── MainActivity.java
    │           │       └── ConversionUtils.java
    │           └── res/
    │               ├── drawable/
    │               │   ├── bg_button.xml
    │               │   ├── bg_card.xml
    │               │   ├── bg_edit_text.xml
    │               │   ├── bg_icon_circle.xml
    │               │   ├── bg_spinner.xml
    │               │   ├── bg_swap_button.xml
    │               │   └── ic_launcher_foreground.xml
    │               ├── layout/
    │               │   └── activity_main.xml
    │               └── values/
    │                   ├── colors.xml
    │                   ├── strings.xml
    │                   └── themes.xml
    ├── build.gradle
    ├── settings.gradle
    └── README.md
```

---

## 💻 How to Run in Android Studio

1. **Clone or Download:**
   Extract the files into your local directory.
2. **Open in Android Studio:**
   - Launch Android Studio.
   - Click **File > Open** and select the `Task1-UnitConverter` folder.
3. **Gradle Sync:**
   - Wait for Android Studio to index and run Gradle sync automatically.
4. **Run on Device or Emulator:**
   - Select an Android Virtual Device (AVD with API 21+) or connect a physical Android device with USB debugging enabled.
   - Click the green **Run (Shift + F10)** button.

---

## 🎥 Demo Video Guide (Internship Requirement)

As mandated by Oasis Infobyte Task 1 guidelines, the demo video begins with a 2-second title card:
- **Full Name:** Neha Vinod Borkar
- **Assigned Track:** Android App Development
- **Task Title:** Task 1 — Unit Converter Application

The video demonstrates:
1. Length conversions (100 cm → 1 m, 12 in → 1 ft).
2. Weight conversions (1000 g → 1 kg).
3. Temperature conversions (0 °C → 32 °F, -40 °C → -40 °F) and invalid temperature rejection.
4. Category switching with automatic Spinner resets.
5. Empty and non-numeric input validation toasts.
6. Swap units and copy to clipboard features.
