package com.example.unitify;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButtonToggleGroup;

import java.util.List;

/**
 * MainActivity.java
 * Oasis Infobyte - Android App Development Internship (Task 1)
 * Project: Unitify - Smart Unit Converter
 * Intern: Neha Vinod Borkar
 *
 * Implements Android native Views:
 * - MaterialButtonToggleGroup for Category selection
 * - Spinners for Source (From) and Target (To) units
 * - EditText for numeric input
 * - Button for conversion with click listener
 * - TextView for displaying formatted results
 * - ImageButton for swapping units and copying results
 * - Toast messages for input validation
 */
public class MainActivity extends AppCompatActivity {

    // UI View References
    private MaterialButtonToggleGroup toggleGroupCategory;
    private EditText editTextValue;
    private Spinner spinnerFromUnit;
    private Spinner spinnerToUnit;
    private Button buttonConvert;
    private ImageButton buttonSwapUnits;
    private ImageButton buttonClearInput;
    private ImageButton buttonCopyResult;
    private ImageButton buttonAbout;
    private TextView textViewResult;
    private TextView textViewFormula;
    private TextView textViewEmptyPlaceholder;
    private View cardResult;

    // Adapters for Spinners
    private ArrayAdapter<String> adapterFrom;
    private ArrayAdapter<String> adapterTo;

    // State Tracking
    private int selectedCategoryIndex = 0; // 0: Length, 1: Weight, 2: Temperature, 3: Volume
    private String lastResultText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupCategoryToggle();
        setupSpinners();
        setupConvertButton();
        setupActionButtons();

        // Populate initial category (Length)
        updateUnitSpinners(0);
    }

    /**
     * Binds all XML layout view IDs to Java member variables.
     */
    private void initializeViews() {
        toggleGroupCategory = findViewById(R.id.toggleGroupCategory);
        editTextValue = findViewById(R.id.editTextValue);
        spinnerFromUnit = findViewById(R.id.spinnerFromUnit);
        spinnerToUnit = findViewById(R.id.spinnerToUnit);
        buttonConvert = findViewById(R.id.buttonConvert);
        buttonSwapUnits = findViewById(R.id.buttonSwapUnits);
        buttonClearInput = findViewById(R.id.buttonClearInput);
        buttonCopyResult = findViewById(R.id.buttonCopyResult);
        buttonAbout = findViewById(R.id.buttonAbout);
        textViewResult = findViewById(R.id.textViewResult);
        textViewFormula = findViewById(R.id.textViewFormula);
        textViewEmptyPlaceholder = findViewById(R.id.textViewEmptyPlaceholder);
        cardResult = findViewById(R.id.cardResult);
    }

    /**
     * Configures the Category selection toggle group.
     */
    private void setupCategoryToggle() {
        toggleGroupCategory.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (isChecked) {
                if (checkedId == R.id.btnCategoryLength) {
                    onCategoryChanged(0);
                } else if (checkedId == R.id.btnCategoryWeight) {
                    onCategoryChanged(1);
                } else if (checkedId == R.id.btnCategoryTemperature) {
                    onCategoryChanged(2);
                } else if (checkedId == R.id.btnCategoryVolume) {
                    onCategoryChanged(3);
                }
            }
        });
    }

    /**
     * Handles switching between measurement categories:
     * - Updates unit Spinners
     * - Resets source and target units to valid defaults
     * - Clears previous conversion result
     */
    private void onCategoryChanged(int categoryIndex) {
        selectedCategoryIndex = categoryIndex;
        updateUnitSpinners(categoryIndex);
        clearConversionResult();

        // Provide keyboard input hints (allow minus sign for Temperature)
        if (categoryIndex == 2) {
            editTextValue.setHint("Enter value (e.g., -40 or 100)");
        } else {
            editTextValue.setHint("Enter value (e.g., 100)");
        }
    }

    /**
     * Populates both unit Spinners based on the selected category.
     */
    private void updateUnitSpinners(int categoryIndex) {
        List<String> units = ConversionUtils.getUnitsForCategory(categoryIndex);

        adapterFrom = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, units);
        adapterFrom.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFromUnit.setAdapter(adapterFrom);

        adapterTo = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, units);
        adapterTo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerToUnit.setAdapter(adapterTo);

        // Set sensible defaults (From: index 0, To: index 1 if available)
        spinnerFromUnit.setSelection(0);
        if (units.size() > 1) {
            spinnerToUnit.setSelection(1);
        } else {
            spinnerToUnit.setSelection(0);
        }
    }

    private void setupSpinners() {
        // Clear result whenever user modifies either spinner selection
        AdapterView.OnItemSelectedListener listener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                clearConversionResult();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        };
        spinnerFromUnit.setOnItemSelectedListener(listener);
        spinnerToUnit.setOnItemSelectedListener(listener);
    }

    /**
     * Connects Convert button to conversion logic with comprehensive input validation.
     */
    private void setupConvertButton() {
        buttonConvert.setOnClickListener(v -> performConversion());
    }

    /**
     * Validates input and executes conversion via ConversionUtils.
     */
    private void performConversion() {
        String inputStr = editTextValue.getText().toString().trim();

        // 1. Validation: Empty input
        if (TextUtils.isEmpty(inputStr)) {
            Toast.makeText(this, "Please enter a value.", Toast.LENGTH_SHORT).show();
            clearConversionResult();
            return;
        }

        // 2. Validation: Non-numeric parsing
        double inputValue;
        try {
            inputValue = Double.parseDouble(inputStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid number.", Toast.LENGTH_SHORT).show();
            clearConversionResult();
            return;
        }

        // 3. Validation: NaN or Infinite
        if (Double.isNaN(inputValue) || Double.isInfinite(inputValue)) {
            Toast.makeText(this, "Please enter a valid finite number.", Toast.LENGTH_SHORT).show();
            clearConversionResult();
            return;
        }

        if (spinnerFromUnit.getSelectedItem() == null || spinnerToUnit.getSelectedItem() == null) {
            Toast.makeText(this, "Please select valid units.", Toast.LENGTH_SHORT).show();
            return;
        }

        String fromUnit = spinnerFromUnit.getSelectedItem().toString();
        String toUnit = spinnerToUnit.getSelectedItem().toString();

        try {
            double convertedValue;
            String formulaText = "";

            switch (selectedCategoryIndex) {
                case 0: // Length
                    convertedValue = ConversionUtils.convertLength(inputValue, fromUnit, toUnit);
                    formulaText = "Converted using base unit Metre (m)";
                    break;

                case 1: // Weight
                    convertedValue = ConversionUtils.convertWeight(inputValue, fromUnit, toUnit);
                    formulaText = "Converted using base unit Gram (g)";
                    break;

                case 2: // Temperature
                    if (!ConversionUtils.isValidTemperature(inputValue, fromUnit)) {
                        Toast.makeText(this, "Temperature cannot be below absolute zero.", Toast.LENGTH_LONG).show();
                        clearConversionResult();
                        return;
                    }
                    convertedValue = ConversionUtils.convertTemperature(inputValue, fromUnit, toUnit);
                    formulaText = getTemperatureFormulaLabel(fromUnit, toUnit);
                    break;

                case 3: // Volume
                    convertedValue = ConversionUtils.convertVolume(inputValue, fromUnit, toUnit);
                    formulaText = "Converted using base unit Litre (L)";
                    break;

                default:
                    Toast.makeText(this, "Invalid category selected.", Toast.LENGTH_SHORT).show();
                    return;
            }

            // Display formatted results
            String formattedInput = ConversionUtils.formatResult(inputValue);
            String formattedOutput = ConversionUtils.formatResult(convertedValue);

            lastResultText = formattedInput + " " + fromUnit + " = " + formattedOutput + " " + toUnit;

            textViewResult.setText(formattedOutput + " " + getUnitShortSymbol(toUnit));
            textViewFormula.setText(lastResultText + "\n" + formulaText);

            textViewResult.setVisibility(View.VISIBLE);
            textViewFormula.setVisibility(View.VISIBLE);
            buttonCopyResult.setVisibility(View.VISIBLE);
            textViewEmptyPlaceholder.setVisibility(View.GONE);

        } catch (IllegalArgumentException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            clearConversionResult();
        } catch (Exception e) {
            Toast.makeText(this, "Error during conversion. Check input.", Toast.LENGTH_SHORT).show();
            clearConversionResult();
        }
    }

    /**
     * Additional Features:
     * - Swap From/To units
     * - Clear input
     * - Copy result to clipboard
     * - About dialog
     */
    private void setupActionButtons() {
        // Swap units
        buttonSwapUnits.setOnClickListener(v -> {
            int fromPos = spinnerFromUnit.getSelectedItemPosition();
            int toPos = spinnerToUnit.getSelectedItemPosition();
            spinnerFromUnit.setSelection(toPos);
            spinnerToUnit.setSelection(fromPos);

            // Re-convert if input exists
            if (!TextUtils.isEmpty(editTextValue.getText().toString().trim())) {
                performConversion();
            }
        });

        // Clear input
        buttonClearInput.setOnClickListener(v -> {
            editTextValue.setText("");
            clearConversionResult();
            editTextValue.requestFocus();
        });

        // Copy result to clipboard
        buttonCopyResult.setOnClickListener(v -> {
            if (!TextUtils.isEmpty(lastResultText)) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("Unitify Result", lastResultText);
                if (clipboard != null) {
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(this, "Result copied to clipboard!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // About section
        buttonAbout.setOnClickListener(v -> showAboutDialog());
    }

    private void clearConversionResult() {
        lastResultText = "";
        textViewResult.setText("");
        textViewFormula.setText("");
        textViewResult.setVisibility(View.GONE);
        textViewFormula.setVisibility(View.GONE);
        buttonCopyResult.setVisibility(View.GONE);
        textViewEmptyPlaceholder.setVisibility(View.VISIBLE);
    }

    private void showAboutDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Unitify — Smart Unit Converter")
            .setMessage("Oasis Infobyte Internship Project (OIBSIP)\n" +
                        "Task 1: Unit Converter Application\n\n" +
                        "Candidate: Neha Vinod Borkar\n" +
                        "Track: Android App Development\n\n" +
                        "Features:\n" +
                        "• Length, Weight, Temperature, and Volume conversions\n" +
                        "• Strict Absolute Zero temperature limits\n" +
                        "• Precision formatting & swap functionality\n" +
                        "• Offline execution with native Android Views")
            .setPositiveButton("Close", (dialog, which) -> dialog.dismiss())
            .show();
    }

    private String getTemperatureFormulaLabel(String fromUnit, String toUnit) {
        if (fromUnit.contains("Celsius") && toUnit.contains("Fahrenheit")) return "Formula: °F = (°C × 9/5) + 32";
        if (fromUnit.contains("Fahrenheit") && toUnit.contains("Celsius")) return "Formula: °C = (°F - 32) × 5/9";
        if (fromUnit.contains("Celsius") && toUnit.contains("Kelvin")) return "Formula: K = °C + 273.15";
        if (fromUnit.contains("Kelvin") && toUnit.contains("Celsius")) return "Formula: °C = K - 273.15";
        if (fromUnit.contains("Fahrenheit") && toUnit.contains("Kelvin")) return "Formula: K = (°F - 32) × 5/9 + 273.15";
        if (fromUnit.contains("Kelvin") && toUnit.contains("Fahrenheit")) return "Formula: °F = (K - 273.15) × 9/5 + 32";
        return "Same unit conversion";
    }

    private String getUnitShortSymbol(String fullUnit) {
        int start = fullUnit.indexOf('(');
        int end = fullUnit.indexOf(')');
        if (start != -1 && end != -1) {
            return fullUnit.substring(start + 1, end);
        }
        return fullUnit;
    }
}
