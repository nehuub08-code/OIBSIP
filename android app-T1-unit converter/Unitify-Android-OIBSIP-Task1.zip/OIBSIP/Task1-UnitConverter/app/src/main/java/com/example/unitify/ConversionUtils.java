package com.example.unitify;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * ConversionUtils.java
 * Oasis Infobyte - Android App Development Internship (Task 1)
 * Project: Unitify - Smart Unit Converter
 * Intern: Neha Vinod Borkar
 *
 * Dedicated Java utility class containing conversion mathematics,
 * absolute zero bounds checking, and clean numeric formatting.
 */
public final class ConversionUtils {

    // Physical Absolute Zero constants
    public static final double ABSOLUTE_ZERO_CELSIUS = -273.15;
    public static final double ABSOLUTE_ZERO_FAHRENHEIT = -459.67;
    public static final double ABSOLUTE_ZERO_KELVIN = 0.0;

    // Private constructor to prevent instantiation of utility class
    private ConversionUtils() {
    }

    /**
     * Retrieve list of unit names for a given category.
     *
     * @param category Index or category identifier (0: Length, 1: Weight, 2: Temperature, 3: Volume)
     * @return List of user-friendly unit names for Spinners
     */
    public static List<String> getUnitsForCategory(int category) {
        switch (category) {
            case 0: // Length
                return Arrays.asList(
                    "Millimetres (mm)",
                    "Centimetres (cm)",
                    "Metres (m)",
                    "Kilometres (km)",
                    "Inches (in)",
                    "Feet (ft)",
                    "Yards (yd)",
                    "Miles (mi)"
                );
            case 1: // Weight
                return Arrays.asList(
                    "Milligrams (mg)",
                    "Grams (g)",
                    "Kilograms (kg)",
                    "Ounces (oz)",
                    "Pounds (lb)",
                    "Metric tonnes (t)"
                );
            case 2: // Temperature
                return Arrays.asList(
                    "Celsius (°C)",
                    "Fahrenheit (°F)",
                    "Kelvin (K)"
                );
            case 3: // Volume
                return Arrays.asList(
                    "Millilitres (mL)",
                    "Litres (L)",
                    "US cups",
                    "US fluid ounces",
                    "US gallons"
                );
            default:
                return new ArrayList<>();
        }
    }

    // =========================================================================
    // 1. LENGTH CONVERSIONS (Base Unit: Metres)
    // =========================================================================

    /**
     * Get conversion factor to base unit (Metre)
     */
    private static double getLengthFactorToBase(String unit) {
        if (unit.contains("(mm)") || unit.equalsIgnoreCase("Millimetres")) return 0.001;
        if (unit.contains("(cm)") || unit.equalsIgnoreCase("Centimetres")) return 0.01;
        if (unit.contains("(m)") || unit.equalsIgnoreCase("Metres")) return 1.0;
        if (unit.contains("(km)") || unit.equalsIgnoreCase("Kilometres")) return 1000.0;
        if (unit.contains("(in)") || unit.equalsIgnoreCase("Inches")) return 0.0254;
        if (unit.contains("(ft)") || unit.equalsIgnoreCase("Feet")) return 0.3048;
        if (unit.contains("(yd)") || unit.equalsIgnoreCase("Yards")) return 0.9144;
        if (unit.contains("(mi)") || unit.equalsIgnoreCase("Miles")) return 1609.344;
        throw new IllegalArgumentException("Unknown length unit: " + unit);
    }

    /**
     * Converts length from source unit to target unit via base unit (Metres).
     *
     * @param value    Numeric input value
     * @param fromUnit Source unit name
     * @param toUnit   Target unit name
     * @return Converted length
     */
    public static double convertLength(double value, String fromUnit, String toUnit) {
        double fromFactor = getLengthFactorToBase(fromUnit);
        double toFactor = getLengthFactorToBase(toUnit);

        // Step 1: Convert source value into base unit (Metres)
        double inMetres = value * fromFactor;

        // Step 2: Convert base value into target unit
        return inMetres / toFactor;
    }

    // =========================================================================
    // 2. WEIGHT CONVERSIONS (Base Unit: Grams)
    // =========================================================================

    /**
     * Get conversion factor to base unit (Gram)
     */
    private static double getWeightFactorToBase(String unit) {
        if (unit.contains("(mg)") || unit.equalsIgnoreCase("Milligrams")) return 0.001;
        if (unit.contains("(g)") || unit.equalsIgnoreCase("Grams")) return 1.0;
        if (unit.contains("(kg)") || unit.equalsIgnoreCase("Kilograms")) return 1000.0;
        if (unit.contains("(oz)") || unit.equalsIgnoreCase("Ounces")) return 28.349523125;
        if (unit.contains("(lb)") || unit.equalsIgnoreCase("Pounds")) return 453.59237;
        if (unit.contains("(t)") || unit.equalsIgnoreCase("Metric tonnes")) return 1000000.0;
        throw new IllegalArgumentException("Unknown weight unit: " + unit);
    }

    /**
     * Converts weight from source unit to target unit via base unit (Grams).
     *
     * @param value    Numeric input value
     * @param fromUnit Source unit name
     * @param toUnit   Target unit name
     * @return Converted weight
     */
    public static double convertWeight(double value, String fromUnit, String toUnit) {
        double fromFactor = getWeightFactorToBase(fromUnit);
        double toFactor = getWeightFactorToBase(toUnit);

        // Step 1: Convert source value into base unit (Grams)
        double inGrams = value * fromFactor;

        // Step 2: Convert base value into target unit
        return inGrams / toFactor;
    }

    // =========================================================================
    // 3. TEMPERATURE CONVERSIONS (Exact Mathematical Formulas)
    // =========================================================================

    /**
     * Checks if temperature is at or above physical absolute zero.
     *
     * @param value Numeric value
     * @param unit  Temperature unit ("Celsius", "Fahrenheit", "Kelvin")
     * @return true if valid, false if below absolute zero
     */
    public static boolean isValidTemperature(double value, String unit) {
        if (unit.contains("Kelvin") || unit.contains("(K)")) {
            return value >= ABSOLUTE_ZERO_KELVIN;
        }
        if (unit.contains("Celsius") || unit.contains("(°C)")) {
            return value >= ABSOLUTE_ZERO_CELSIUS;
        }
        if (unit.contains("Fahrenheit") || unit.contains("(°F)")) {
            return value >= ABSOLUTE_ZERO_FAHRENHEIT;
        }
        return true;
    }

    /**
     * Converts temperature using direct formulas with strict absolute zero validation.
     *
     * @param value    Numeric value
     * @param fromUnit Source unit
     * @param toUnit   Target unit
     * @return Converted temperature
     * @throws IllegalArgumentException if input is below absolute zero
     */
    public static double convertTemperature(double value, String fromUnit, String toUnit) {
        if (!isValidTemperature(value, fromUnit)) {
            throw new IllegalArgumentException("Temperature cannot be below absolute zero.");
        }

        // Normalize unit keys
        String from = fromUnit.contains("Celsius") ? "C" : fromUnit.contains("Fahrenheit") ? "F" : "K";
        String to = toUnit.contains("Celsius") ? "C" : toUnit.contains("Fahrenheit") ? "F" : "K";

        if (from.equals(to)) {
            return value;
        }

        // Direct mathematical formulas:
        if (from.equals("C") && to.equals("F")) {
            return (value * 9.0 / 5.0) + 32.0;
        } else if (from.equals("F") && to.equals("C")) {
            return (value - 32.0) * 5.0 / 9.0;
        } else if (from.equals("C") && to.equals("K")) {
            return value + 273.15;
        } else if (from.equals("K") && to.equals("C")) {
            return value - 273.15;
        } else if (from.equals("F") && to.equals("K")) {
            return ((value - 32.0) * 5.0 / 9.0) + 273.15;
        } else if (from.equals("K") && to.equals("F")) {
            return ((value - 273.15) * 9.0 / 5.0) + 32.0;
        }

        throw new IllegalArgumentException("Unknown temperature conversion combination.");
    }

    // =========================================================================
    // 4. VOLUME CONVERSIONS (Base Unit: Litres)
    // =========================================================================

    /**
     * Get conversion factor to base unit (Litre)
     */
    private static double getVolumeFactorToBase(String unit) {
        if (unit.contains("(mL)") || unit.equalsIgnoreCase("Millilitres")) return 0.001;
        if (unit.contains("(L)") || unit.equalsIgnoreCase("Litres")) return 1.0;
        if (unit.contains("cups")) return 0.2365882365;
        if (unit.contains("fluid ounces")) return 0.0295735295625;
        if (unit.contains("gallons")) return 3.785411784;
        throw new IllegalArgumentException("Unknown volume unit: " + unit);
    }

    /**
     * Converts volume from source unit to target unit via base unit (Litres).
     *
     * @param value    Numeric input value
     * @param fromUnit Source unit name
     * @param toUnit   Target unit name
     * @return Converted volume
     */
    public static double convertVolume(double value, String fromUnit, String toUnit) {
        double fromFactor = getVolumeFactorToBase(fromUnit);
        double toFactor = getVolumeFactorToBase(toUnit);

        // Step 1: to base unit (Litres)
        double inLitres = value * fromFactor;

        // Step 2: to target unit
        return inLitres / toFactor;
    }

    // =========================================================================
    // 5. RESULT FORMATTING (Eliminating unnecessary trailing zeros)
    // =========================================================================

    /**
     * Formats a double value cleanly, removing unnecessary trailing decimal zeros
     * while preserving up to 6 significant decimal places.
     *
     * @param value Double value to format
     * @return Clean string representation (e.g. "1" instead of "1.000000")
     */
    public static String formatResult(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value)) {
            return "Error";
        }

        // Avoid tiny -0.0 artifacts
        if (Math.abs(value) < 1e-12) {
            return "0";
        }

        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(6, RoundingMode.HALF_UP).stripTrailingZeros();
        return bd.toPlainString();
    }
}
