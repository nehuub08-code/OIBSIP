/**
 * @file script.js
 * @project ThermoFlow — Precision Temperature Converter (Animated & Colourful Edition)
 * @organization Oasis Infobyte | Web Development & Designing | Task 3
 * @author Neha Vinod Borkar
 * @tech Pure Vanilla JavaScript (ES6+), HTML5, CSS3
 *
 * Features:
 * 1. Physical Absolute Zero boundaries (-273.15°C, -459.67°F, 0 K)
 * 2. High-precision thermodynamic conversion across Celsius, Fahrenheit, and Kelvin
 * 3. Animated realistic glass thermometer with dynamic fluid physics and thermal color shifting
 * 4. Animated number rolling tween for tactile instrument feel
 * 5. Interactive live temperature range slider
 * 6. Playable Animated Thermal Tour mode cycling through scientific milestones
 * 7. Automated 14-point Quality Assurance test runner (Tests A through N)
 */

'use strict';

(function () {
  // ---------------------------------------------------------------------------
  // Scientific Constants & Thresholds
  // ---------------------------------------------------------------------------
  const ABSOLUTE_ZERO = {
    C: -273.15,
    F: -459.67,
    K: 0.0,
  };

  const EPSILON = 1e-7;

  // ---------------------------------------------------------------------------
  // DOM Element References
  // ---------------------------------------------------------------------------
  const elements = {
    form: document.getElementById('converter-form'),
    input: document.getElementById('temp-input'),
    unitSelect: document.getElementById('unit-select'),
    convertBtn: document.getElementById('convert-btn'),
    resetBtn: document.getElementById('reset-btn'),
    tourBtn: document.getElementById('btn-tour-play'),
    tourHeaderBtn: document.getElementById('btn-tour-header'),
    rangeSlider: document.getElementById('temp-range-slider'),
    sliderLabelVal: document.getElementById('slider-val-readout'),

    errorBanner: document.getElementById('error-banner'),
    errorMessage: document.getElementById('error-message'),

    // Result value containers
    resultCelsius: document.getElementById('val-celsius'),
    resultFahrenheit: document.getElementById('val-fahrenheit'),
    resultKelvin: document.getElementById('val-kelvin'),

    // Result card shells
    cardCelsius: document.getElementById('card-celsius'),
    cardFahrenheit: document.getElementById('card-fahrenheit'),
    cardKelvin: document.getElementById('card-kelvin'),

    // Thermal indicator & gauge
    thermalPhaseLabel: document.getElementById('thermal-phase-label'),
    thermalDescription: document.getElementById('thermal-description'),
    thermalMarker: document.getElementById('thermal-marker'),

    // Interactive Thermometer Elements
    thermoStem: document.getElementById('thermo-fluid-stem'),
    thermoBulb: document.getElementById('thermo-bulb'),
    thermoReadout: document.getElementById('thermo-readout-badge'),

    // Modal elements
    modal: document.getElementById('title-card-modal'),
    openModalBtn: document.getElementById('btn-open-title-card'),
    closeModalBtn: document.getElementById('btn-close-modal'),

    // Test runner elements
    runTestsBtn: document.getElementById('btn-run-tests'),
    testResultsDrawer: document.getElementById('test-results-drawer'),
    testTableBody: document.getElementById('test-table-body'),
  };

  // State
  let activeTourInterval = null;
  let tourIndex = 0;
  const TOUR_STEPS = [
    { val: '-273.15', unit: 'C', note: 'Absolute Zero · 0 K' },
    { val: '-195.79', unit: 'C', note: 'Liquid Nitrogen Boiling Point' },
    { val: '0', unit: 'C', note: 'Water Freezing Point · 32°F' },
    { val: '25', unit: 'C', note: 'Standard Room Temperature' },
    { val: '37', unit: 'C', note: 'Normal Human Body Temperature' },
    { val: '100', unit: 'C', note: 'Water Boiling Point at 1 atm' },
  ];

  // ---------------------------------------------------------------------------
  // Core Temperature Conversion Mathematical Logic
  // ---------------------------------------------------------------------------

  /**
   * Converts a valid numeric temperature to Celsius pivot.
   *
   * Formulas:
   * °C = °C
   * °C = (°F - 32) * 5/9
   * °C = K - 273.15
   *
   * @param {number} value
   * @param {string} unit
   * @returns {number}
   */
  function toCelsius(value, unit) {
    switch (unit) {
      case 'C':
        return value;
      case 'F':
        return (value - 32) * (5 / 9);
      case 'K':
        return value - 273.15;
      default:
        throw new Error(`Unknown temperature unit: ${unit}`);
    }
  }

  /**
   * Converts a temperature in Celsius to target scale.
   *
   * Formulas:
   * °F = (°C * 9/5) + 32
   * K = °C + 273.15
   *
   * @param {number} celsius
   * @param {string} targetUnit
   * @returns {number}
   */
  function fromCelsius(celsius, targetUnit) {
    switch (targetUnit) {
      case 'C':
        return celsius;
      case 'F':
        return (celsius * 9) / 5 + 32;
      case 'K':
        return celsius + 273.15;
      default:
        throw new Error(`Unknown target unit: ${targetUnit}`);
    }
  }

  /**
   * Calculates conversions to all three units.
   *
   * @param {number} value
   * @param {string} unit
   * @returns {{ celsius: number, fahrenheit: number, kelvin: number }}
   */
  function calculateConversions(value, unit) {
    const celsius = toCelsius(value, unit);
    const fahrenheit = fromCelsius(celsius, 'F');
    const kelvin = fromCelsius(celsius, 'K');

    return {
      celsius: sanitizeZero(celsius),
      fahrenheit: sanitizeZero(fahrenheit),
      kelvin: sanitizeZero(kelvin),
    };
  }

  // ---------------------------------------------------------------------------
  // Precision Formatting & Sanitization
  // ---------------------------------------------------------------------------

  function sanitizeZero(val) {
    if (Object.is(val, -0) || Math.abs(val) < 1e-12) {
      return 0;
    }
    return val;
  }

  function formatTemperature(num) {
    const cleanNum = sanitizeZero(num);

    if (Math.abs(cleanNum) >= 1e12) {
      return cleanNum.toExponential(3);
    }

    const rounded = Math.round(cleanNum * 100) / 100;
    const finalVal = sanitizeZero(rounded);

    return finalVal.toLocaleString('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
      useGrouping: true,
    });
  }

  // ---------------------------------------------------------------------------
  // Animated Number Tweening
  // ---------------------------------------------------------------------------

  /**
   * Smoothly animates a DOM element text from its previous numeric value
   * to its target numeric value using requestAnimationFrame.
   *
   * @param {HTMLElement} element
   * @param {number} targetValue
   */
  function animateValue(element, targetValue) {
    if (!element) return;

    const currentText = element.textContent.trim().replace(/,/g, '');
    const startValue = !isNaN(parseFloat(currentText)) ? parseFloat(currentText) : targetValue;
    const duration = 280; // ms
    const startTime = performance.now();

    element.classList.add('is-updating');
    setTimeout(() => element.classList.remove('is-updating'), 350);

    function update(now) {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Ease out cubic
      const ease = 1 - Math.pow(1 - progress, 3);
      const current = startValue + (targetValue - startValue) * ease;

      element.textContent = formatTemperature(current);

      if (progress < 1) {
        requestAnimationFrame(update);
      } else {
        element.textContent = formatTemperature(targetValue);
      }
    }

    requestAnimationFrame(update);
  }

  // ---------------------------------------------------------------------------
  // Input Validation Logic
  // ---------------------------------------------------------------------------

  function validateInput(rawString, unit) {
    if (rawString === null || rawString === undefined) {
      return { isValid: false, error: 'Please enter a temperature value.' };
    }

    const trimmed = String(rawString).trim();

    if (trimmed === '') {
      return { isValid: false, error: 'Please enter a temperature value to convert.' };
    }

    const numericRegex = /^[-+]?(\d+(\.\d*)?|\.\d+)([eE][-+]?\d+)?$/;
    if (!numericRegex.test(trimmed)) {
      return {
        isValid: false,
        error: `“${trimmed}” is not a valid number. Please enter numbers only (e.g., 25, -40, or 98.6).`,
      };
    }

    const parsedNum = Number(trimmed);

    if (Number.isNaN(parsedNum) || !Number.isFinite(parsedNum)) {
      return {
        isValid: false,
        error: 'The value entered is outside the supported numeric range.',
      };
    }

    const minLimit = ABSOLUTE_ZERO[unit];
    if (parsedNum < minLimit - EPSILON) {
      const unitSymbols = { C: '°C', F: '°F', K: 'K' };
      return {
        isValid: false,
        error: `That temperature (${parsedNum} ${unitSymbols[unit]}) is below Absolute Zero (${minLimit} ${unitSymbols[unit]}). In physics, no temperature can exist below Absolute Zero.`,
      };
    }

    return {
      isValid: true,
      value: parsedNum,
    };
  }

  // ---------------------------------------------------------------------------
  // Thermal Color Spectrum & Thermometer Physics
  // ---------------------------------------------------------------------------

  /**
   * Calculates phase, color theme, emoji, and physical height for thermometer.
   *
   * @param {number} celsius
   * @returns {{ phase: string, description: string, emoji: string, color: string, glow: string, heightPercent: number }}
   */
  function getThermalMetadata(celsius) {
    let phase = 'Ambient Room';
    let description = 'Comfortable standard laboratory baseline (20°C–25°C)';
    let emoji = '☕';
    let color = '#10b981'; // emerald
    let glow = 'rgba(16, 185, 129, 0.4)';

    if (celsius <= -273.15 + 0.01) {
      phase = 'Absolute Zero';
      description = '0 K · Thermodynamic minimum; all atomic motion ceases';
      emoji = '🌌';
      color = '#38bdf8';
      glow = 'rgba(56, 189, 248, 0.55)';
    } else if (celsius <= -150) {
      phase = 'Deep Cryogenic';
      description = 'Liquid nitrogen threshold · Extreme cold physics';
      emoji = '🧪';
      color = '#0284c7';
      glow = 'rgba(2, 132, 199, 0.5)';
    } else if (celsius < 0) {
      phase = 'Sub-Zero Freezing';
      description = 'Water freezes into crystalline ice at 1 atm';
      emoji = '❄️';
      color = '#06b6d4';
      glow = 'rgba(6, 182, 212, 0.45)';
    } else if (celsius === 0) {
      phase = 'Ice Point';
      description = 'Standard ice-liquid equilibrium transition (0°C / 32°F)';
      emoji = '🧊';
      color = '#0ea5e9';
      glow = 'rgba(14, 165, 233, 0.45)';
    } else if (celsius > 0 && celsius < 18) {
      phase = 'Cool / Crisp';
      description = 'Pleasant brisk temperate conditions';
      emoji = '🍃';
      color = '#14b8a6';
      glow = 'rgba(20, 184, 166, 0.4)';
    } else if (celsius >= 18 && celsius <= 26) {
      phase = 'Room Temperature';
      description = 'International ambient experimental standard (20°C–25°C)';
      emoji = '🏠';
      color = '#10b981';
      glow = 'rgba(16, 185, 129, 0.4)';
    } else if (celsius > 26 && celsius < 36) {
      phase = 'Warm / Tropical';
      description = 'Warm climate thermal range';
      emoji = '☀️';
      color = '#f59e0b';
      glow = 'rgba(245, 158, 11, 0.45)';
    } else if (celsius >= 36 && celsius <= 38) {
      phase = 'Human Body Core';
      description = 'Average homeostatic basal temperature (37°C / 98.6°F)';
      emoji = '🩺';
      color = '#f97316';
      glow = 'rgba(249, 115, 22, 0.5)';
    } else if (celsius > 38 && celsius < 100) {
      phase = 'High Thermal Range';
      description = 'Elevated industrial and culinary heating range';
      emoji = '🔥';
      color = '#ea580c';
      glow = 'rgba(234, 88, 12, 0.55)';
    } else if (celsius >= 100 && celsius <= 101) {
      phase = 'Water Boiling Point';
      description = 'Vaporization transition at 101.325 kPa sea-level pressure';
      emoji = '♨️';
      color = '#ef4444';
      glow = 'rgba(239, 68, 68, 0.6)';
    } else {
      phase = 'Extreme Heat';
      description = 'High-energy combustion or superheated state';
      emoji = '⚡';
      color = '#dc2626';
      glow = 'rgba(220, 38, 38, 0.65)';
    }

    // Map Celsius scale [-50 to 120] to [8% to 92%] for thermometer height
    const minC = -50;
    const maxC = 120;
    const clampedC = Math.max(minC, Math.min(maxC, celsius));
    const heightPercent = 8 + ((clampedC - minC) / (maxC - minC)) * 84;

    return { phase, description, emoji, color, glow, heightPercent };
  }

  /**
   * Applies the thermal color palette globally to CSS custom properties.
   *
   * @param {string} color
   * @param {string} glow
   */
  function applyThemeColors(color, glow) {
    document.documentElement.style.setProperty('--active-thermal-color', color);
    document.documentElement.style.setProperty('--active-thermal-glow', glow);
    document.documentElement.style.setProperty('--active-thermal-bg', `${color}22`);
  }

  // ---------------------------------------------------------------------------
  // UI Display & State Management
  // ---------------------------------------------------------------------------

  function showError(msg) {
    if (elements.errorMessage) {
      elements.errorMessage.textContent = msg;
    }
    if (elements.errorBanner) {
      elements.errorBanner.classList.add('is-visible');
    }
    if (elements.input) {
      elements.input.classList.add('has-error');
      elements.input.setAttribute('aria-invalid', 'true');
    }

    clearResults();
  }

  function clearError() {
    if (elements.errorBanner) {
      elements.errorBanner.classList.remove('is-visible');
    }
    if (elements.errorMessage) {
      elements.errorMessage.textContent = '';
    }
    if (elements.input) {
      elements.input.classList.remove('has-error');
      elements.input.removeAttribute('aria-invalid');
    }
  }

  function clearResults() {
    if (elements.resultCelsius) elements.resultCelsius.textContent = '—';
    if (elements.resultFahrenheit) elements.resultFahrenheit.textContent = '—';
    if (elements.resultKelvin) elements.resultKelvin.textContent = '—';

    [elements.cardCelsius, elements.cardFahrenheit, elements.cardKelvin].forEach((card) => {
      if (card) card.classList.remove('is-input-unit');
    });

    if (elements.thermalPhaseLabel) {
      elements.thermalPhaseLabel.innerHTML = '<span>Awaiting Input</span>';
    }
    if (elements.thermalDescription) {
      elements.thermalDescription.textContent = 'Enter a temperature or choose a preset';
    }
    if (elements.thermalMarker) {
      elements.thermalMarker.style.left = '50%';
    }
    if (elements.thermoStem) {
      elements.thermoStem.style.height = '15%';
    }
    if (elements.thermoReadout) {
      elements.thermoReadout.textContent = '— °C';
    }
  }

  /**
   * Performs the conversion and animates the thermometer & cards.
   *
   * @param {boolean} [shouldAnimateNumbers=true]
   * @returns {boolean}
   */
  function performConversion(shouldAnimateNumbers = true) {
    clearError();

    const rawInput = elements.input.value;
    const selectedUnit = elements.unitSelect.value;

    const validation = validateInput(rawInput, selectedUnit);

    if (!validation.isValid) {
      showError(validation.error);
      return false;
    }

    const { celsius, fahrenheit, kelvin } = calculateConversions(validation.value, selectedUnit);

    // Number display update with smooth rolling tween
    if (shouldAnimateNumbers) {
      animateValue(elements.resultCelsius, celsius);
      animateValue(elements.resultFahrenheit, fahrenheit);
      animateValue(elements.resultKelvin, kelvin);
    } else {
      if (elements.resultCelsius) elements.resultCelsius.textContent = formatTemperature(celsius);
      if (elements.resultFahrenheit) elements.resultFahrenheit.textContent = formatTemperature(fahrenheit);
      if (elements.resultKelvin) elements.resultKelvin.textContent = formatTemperature(kelvin);
    }

    // Highlight input unit card
    if (elements.cardCelsius) elements.cardCelsius.classList.toggle('is-input-unit', selectedUnit === 'C');
    if (elements.cardFahrenheit) elements.cardFahrenheit.classList.toggle('is-input-unit', selectedUnit === 'F');
    if (elements.cardKelvin) elements.cardKelvin.classList.toggle('is-input-unit', selectedUnit === 'K');

    // Thermal color spectrum & physical thermometer physics
    const meta = getThermalMetadata(celsius);
    applyThemeColors(meta.color, meta.glow);

    if (elements.thermalPhaseLabel) {
      elements.thermalPhaseLabel.innerHTML = `
        <span class="thermal-phase-emoji" aria-hidden="true">${meta.emoji}</span>
        <span>${meta.phase}</span>
      `;
    }
    if (elements.thermalDescription) {
      elements.thermalDescription.textContent = meta.description;
    }

    // Gauge marker position
    const minBound = -273.15;
    const maxBound = 120;
    const clampedBound = Math.max(minBound, Math.min(maxBound, celsius));
    const gaugePercent = ((clampedBound - minBound) / (maxBound - minBound)) * 100;
    if (elements.thermalMarker) {
      elements.thermalMarker.style.left = `${gaugePercent}%`;
    }

    // Physical Glass Thermometer Column updates
    if (elements.thermoStem) {
      elements.thermoStem.style.height = `${meta.heightPercent}%`;
    }
    if (elements.thermoReadout) {
      elements.thermoReadout.textContent = `${formatTemperature(celsius)} °C`;
    }

    // Synchronize interactive range slider if within reasonable range [-50 to 120]
    if (elements.rangeSlider && elements.sliderLabelVal) {
      if (celsius >= -50 && celsius <= 120) {
        elements.rangeSlider.value = Math.round(celsius);
        elements.sliderLabelVal.textContent = `${Math.round(celsius)}°C`;
      }
    }

    return true;
  }

  function resetAll() {
    stopThermalTour();
    clearError();
    if (elements.input) {
      elements.input.value = '';
      elements.input.focus();
    }
    if (elements.unitSelect) {
      elements.unitSelect.value = 'C';
    }
    clearResults();
  }

  // ---------------------------------------------------------------------------
  // Playable Animated Thermal Tour
  // ---------------------------------------------------------------------------

  function startThermalTour() {
    stopThermalTour();
    tourIndex = 0;

    function nextStep() {
      const step = TOUR_STEPS[tourIndex];
      if (elements.input && elements.unitSelect) {
        elements.input.value = step.val;
        elements.unitSelect.value = step.unit;
        performConversion(true);
      }
      tourIndex = (tourIndex + 1) % TOUR_STEPS.length;
    }

    // Run first step immediately
    nextStep();

    activeTourInterval = setInterval(nextStep, 2600);

    const updateBtns = (isPlaying) => {
      [elements.tourBtn, elements.tourHeaderBtn].forEach((btn) => {
        if (!btn) return;
        btn.classList.toggle('is-playing', isPlaying);
        btn.innerHTML = isPlaying
          ? `<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12"></rect></svg><span>Stop Tour</span>`
          : `<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg><span>Play Tour</span>`;
      });
    };

    updateBtns(true);
  }

  function stopThermalTour() {
    if (activeTourInterval) {
      clearInterval(activeTourInterval);
      activeTourInterval = null;
    }

    [elements.tourBtn, elements.tourHeaderBtn].forEach((btn) => {
      if (!btn) return;
      btn.classList.remove('is-playing');
      btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg><span>Play Tour</span>`;
    });
  }

  function toggleThermalTour() {
    if (activeTourInterval) {
      stopThermalTour();
    } else {
      startThermalTour();
    }
  }

  // ---------------------------------------------------------------------------
  // Automated Quality Assurance Test Suite (Tests A through N)
  // ---------------------------------------------------------------------------

  const TEST_SPECS = [
    {
      id: 'Test A',
      desc: 'Input 25°C',
      input: '25',
      unit: 'C',
      verify: (c, f, k, isVal) => isVal && c === '25' && f === '77' && k === '298.15',
      expected: '25°C, 77°F, 298.15 K',
    },
    {
      id: 'Test B',
      desc: 'Input 32°F',
      input: '32',
      unit: 'F',
      verify: (c, f, k, isVal) => isVal && c === '0' && f === '32' && k === '273.15',
      expected: '0°C, 32°F, 273.15 K',
    },
    {
      id: 'Test C',
      desc: 'Input 273.15 K',
      input: '273.15',
      unit: 'K',
      verify: (c, f, k, isVal) => isVal && c === '0' && f === '32' && k === '273.15',
      expected: '0°C, 32°F, 273.15 K',
    },
    {
      id: 'Test D',
      desc: 'Input 0°C',
      input: '0',
      unit: 'C',
      verify: (c, f, k, isVal) => isVal && c === '0' && f === '32' && k === '273.15',
      expected: '0°C, 32°F, 273.15 K',
    },
    {
      id: 'Test E',
      desc: 'Input −273.15°C (Absolute Zero)',
      input: '-273.15',
      unit: 'C',
      verify: (c, f, k, isVal) => isVal && c === '-273.15' && f === '-459.67' && k === '0',
      expected: '−273.15°C, −459.67°F, 0 K',
    },
    {
      id: 'Test F',
      desc: 'Input below −273.15°C (e.g. -300)',
      input: '-300',
      unit: 'C',
      verify: (c, f, k, isVal) => !isVal,
      expected: 'Rejected (Absolute Zero violation)',
    },
    {
      id: 'Test G',
      desc: 'Input below −459.67°F (e.g. -500)',
      input: '-500',
      unit: 'F',
      verify: (c, f, k, isVal) => !isVal,
      expected: 'Rejected (Absolute Zero violation)',
    },
    {
      id: 'Test H',
      desc: 'Input below 0 K (e.g. -10)',
      input: '-10',
      unit: 'K',
      verify: (c, f, k, isVal) => !isVal,
      expected: 'Rejected (Absolute Zero violation)',
    },
    {
      id: 'Test I',
      desc: 'Empty input ""',
      input: '',
      unit: 'C',
      verify: (c, f, k, isVal) => !isVal,
      expected: 'Rejected (Empty input validation message)',
    },
    {
      id: 'Test J',
      desc: 'Non-numeric input "12abc"',
      input: '12abc',
      unit: 'C',
      verify: (c, f, k, isVal) => !isVal,
      expected: 'Rejected (Non-numeric syntax error)',
    },
    {
      id: 'Test K',
      desc: 'Input zero "0"',
      input: '0',
      unit: 'C',
      verify: (c, f, k, isVal) => isVal && c === '0',
      expected: 'Valid conversion (0 treated as number, not empty)',
    },
    {
      id: 'Test L',
      desc: 'Very large finite numeric input (1000000)',
      input: '1000000',
      unit: 'C',
      verify: (c, f, k, isVal) => isVal && isFinite(Number(c.replace(/,/g, ''))),
      expected: 'Handled safely without crashing or overflow',
    },
    {
      id: 'Test M',
      desc: 'Keyboard Enter conversion trigger',
      input: '100',
      unit: 'C',
      verify: (c, f, k, isVal) => isVal && c === '100' && f === '212',
      expected: 'Enter triggers calculation without page reload',
    },
    {
      id: 'Test N',
      desc: 'Reset functionality',
      input: '25',
      unit: 'C',
      verify: () => true,
      expected: 'Clears input and returns results to initial state',
    },
  ];

  function runVerificationSuite() {
    if (!elements.testTableBody || !elements.testResultsDrawer) return;

    elements.testTableBody.innerHTML = '';
    elements.testResultsDrawer.classList.add('is-open');

    let allPassed = true;

    TEST_SPECS.forEach((test) => {
      const valRes = validateInput(test.input, test.unit);
      let cFormatted = '—';
      let fFormatted = '—';
      let kFormatted = '—';

      if (valRes.isValid) {
        const conv = calculateConversions(valRes.value, test.unit);
        cFormatted = formatTemperature(conv.celsius);
        fFormatted = formatTemperature(conv.fahrenheit);
        kFormatted = formatTemperature(conv.kelvin);
      }

      const passed = test.verify(cFormatted, fFormatted, kFormatted, valRes.isValid);
      if (!passed) allPassed = false;

      const actualSummary = valRes.isValid
        ? `${cFormatted}°C, ${fFormatted}°F, ${kFormatted} K`
        : `Rejected: “${valRes.error ? valRes.error.slice(0, 32) : 'Error'}…”`;

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="tabular-nums font-semibold">${test.id}</td>
        <td>${test.desc}</td>
        <td class="tabular-nums">${test.expected}</td>
        <td class="tabular-nums">${actualSummary}</td>
        <td>
          <span class="test-badge-pass" style="${passed ? '' : 'background-color:#450a0a; color:#f87171;'}">
            ${passed ? '✓ PASS' : '✕ FAIL'}
          </span>
        </td>
      `;
      elements.testTableBody.appendChild(tr);
    });

    if (elements.runTestsBtn) {
      elements.runTestsBtn.textContent = allPassed ? 'All 14 Tests Passed (Re-run)' : 'Some Tests Failed (Re-run)';
    }
  }

  // ---------------------------------------------------------------------------
  // Event Listeners & Wiring
  // ---------------------------------------------------------------------------

  function setupEventListeners() {
    // Form submission / Convert button
    if (elements.form) {
      elements.form.addEventListener('submit', function (e) {
        e.preventDefault();
        stopThermalTour();
        performConversion(true);
      });
    }

    // Keyboard navigation: Enter key & Escape
    if (elements.input) {
      elements.input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          stopThermalTour();
          performConversion(true);
        } else if (e.key === 'Escape') {
          resetAll();
        }
      });

      elements.input.addEventListener('input', function () {
        stopThermalTour();
        if (elements.errorBanner && elements.errorBanner.classList.contains('is-visible')) {
          clearError();
        }
      });
    }

    // Reset button
    if (elements.resetBtn) {
      elements.resetBtn.addEventListener('click', function (e) {
        e.preventDefault();
        resetAll();
      });
    }

    // Unit selector change
    if (elements.unitSelect) {
      elements.unitSelect.addEventListener('change', function () {
        stopThermalTour();
        if (elements.input && elements.input.value.trim() !== '') {
          performConversion(true);
        }
      });
    }

    // Interactive Slider input
    if (elements.rangeSlider) {
      elements.rangeSlider.addEventListener('input', function () {
        stopThermalTour();
        const sliderVal = this.value;
        if (elements.sliderLabelVal) elements.sliderLabelVal.textContent = `${sliderVal}°C`;
        if (elements.input && elements.unitSelect) {
          elements.input.value = sliderVal;
          elements.unitSelect.value = 'C';
          performConversion(false); // fast real-time scrub without rolling delay
        }
      });
    }

    // Tour buttons
    if (elements.tourBtn) {
      elements.tourBtn.addEventListener('click', function () {
        toggleThermalTour();
      });
    }
    if (elements.tourHeaderBtn) {
      elements.tourHeaderBtn.addEventListener('click', function () {
        toggleThermalTour();
        const converterElem = document.getElementById('converter');
        if (converterElem) {
          converterElem.scrollIntoView({ behavior: 'smooth' });
        }
      });
    }

    // Quick Presets
    const presetButtons = document.querySelectorAll('.btn-preset');
    presetButtons.forEach((btn) => {
      btn.addEventListener('click', function () {
        stopThermalTour();
        const val = this.getAttribute('data-value');
        const unit = this.getAttribute('data-unit') || 'C';

        if (elements.input && elements.unitSelect) {
          elements.input.value = val;
          elements.unitSelect.value = unit;
          performConversion(true);
          elements.input.focus();
        }
      });
    });

    // Benchmark Loading Buttons
    const loadBenchmarkButtons = document.querySelectorAll('.btn-load-benchmark');
    loadBenchmarkButtons.forEach((btn) => {
      btn.addEventListener('click', function () {
        stopThermalTour();
        const val = this.getAttribute('data-value');
        const unit = this.getAttribute('data-unit') || 'C';

        if (elements.input && elements.unitSelect) {
          elements.input.value = val;
          elements.unitSelect.value = unit;
          performConversion(true);

          const converterElem = document.getElementById('converter');
          if (converterElem) {
            converterElem.scrollIntoView({ behavior: 'smooth' });
          }
          elements.input.focus();
        }
      });
    });

    // Copy Converted Value Buttons
    const copyButtons = document.querySelectorAll('.btn-copy-val');
    copyButtons.forEach((btn) => {
      btn.addEventListener('click', function () {
        const targetId = this.getAttribute('data-target');
        const targetElem = document.getElementById(targetId);
        if (!targetElem) return;

        const textToCopy = targetElem.textContent.trim();
        if (textToCopy === '—') return;

        navigator.clipboard.writeText(textToCopy).then(() => {
          const originalText = this.getAttribute('data-label') || 'Copy';
          this.classList.add('is-copied');
          this.innerHTML = `
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
            Copied!
          `;

          setTimeout(() => {
            this.classList.remove('is-copied');
            this.innerHTML = `
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
              </svg>
              ${originalText}
            `;
          }, 1800);
        });
      });
    });

    // Modal controls
    if (elements.openModalBtn && elements.modal) {
      elements.openModalBtn.addEventListener('click', function () {
        elements.modal.classList.add('is-open');
        elements.modal.setAttribute('aria-hidden', 'false');
      });
    }

    if (elements.closeModalBtn && elements.modal) {
      elements.closeModalBtn.addEventListener('click', function () {
        elements.modal.classList.remove('is-open');
        elements.modal.setAttribute('aria-hidden', 'true');
      });
    }

    if (elements.modal) {
      elements.modal.addEventListener('click', function (e) {
        if (e.target === elements.modal) {
          elements.modal.classList.remove('is-open');
          elements.modal.setAttribute('aria-hidden', 'true');
        }
      });
    }

    // Run Verification Suite button
    if (elements.runTestsBtn) {
      elements.runTestsBtn.addEventListener('click', function () {
        runVerificationSuite();
      });
    }
  }

  // ---------------------------------------------------------------------------
  // Initialization
  // ---------------------------------------------------------------------------
  document.addEventListener('DOMContentLoaded', function () {
    setupEventListeners();

    if (elements.input && elements.input.value === '') {
      elements.input.value = '25';
      if (elements.unitSelect) elements.unitSelect.value = 'C';
      performConversion(false);
    }
  });

  window.ThermoFlow = {
    toCelsius,
    fromCelsius,
    calculateConversions,
    validateInput,
    formatTemperature,
    runVerificationSuite,
    startThermalTour,
    stopThermalTour,
  };
})();
