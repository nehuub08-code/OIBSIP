# ThermoFlow — Precision Temperature Converter
> **“Every degree, made simple.”**

An elegant, scientific, and responsive temperature converter web application built for the **Oasis Infobyte Web Development & Designing Internship** (OIBSIP).

---

## 1. Project Information
- **Internship Program:** Oasis Infobyte Internship in Web Development & Designing (OIBSIP)
- **Task Assigned:** Level 1 — Task 3: Temperature Converter Website
- **Candidate Name:** Neha Vinod Borkar
- **Application Brand:** ThermoFlow
- **Repository Track:** `OIBSIP/Web-Development-and-Designing-Level-1-Task-3-Temperature-Converter/`

---

## 2. Project Overview
**ThermoFlow** is an interactive, scientific-grade temperature translation tool that converts between **Celsius (°C)**, **Fahrenheit (°F)**, and **Kelvin (K)**. 

Designed following modern editorial and laboratory instrumentation principles, ThermoFlow prioritizes:
- **Immediate Clarity:** Displays all three temperature units simultaneously in high-contrast result cards.
- **Physical Boundary Rigor:** Enforces the fundamental thermodynamic floor of **Absolute Zero** (−273.15°C / −459.67°F / 0 K).
- **Educational Value:** Accompanied by physical transition benchmarks (freezing point, body temperature, boiling point at standard pressure), historical scale overviews, and exact mathematical formulas.
- **Zero-Dependency Architecture:** Crafted purely with semantic HTML5, modern CSS3, and Vanilla JavaScript—executable immediately in any modern web browser without a build step or server dependency.

---

## 3. Key Features
1. **Synchronous 3-Scale Results Display:**
   Entering a temperature in any selected unit instantly calculates and displays the equivalent across Celsius, Fahrenheit, and Kelvin simultaneously. The original input unit is clearly badged.
2. **Absolute Zero Physical Guard:**
   Prevents calculation of unphysical temperatures below Absolute Zero (−273.15°C, −459.67°F, or 0 K) with friendly, scientifically accurate error messages. Values *exactly* at Absolute Zero are fully permitted with floating-point tolerance.
3. **Comprehensive Input Validation:**
   - Detects and rejects empty or whitespace-only submissions.
   - Rejects non-numeric characters and strings (e.g. `12abc`).
   - Handles `0` safely as a valid numeric input.
   - Safeguards against `NaN` and `Infinity`.
4. **Sensible Decimal Precision & Formatting:**
   - Displays up to two decimal places by default.
   - Automatically removes redundant trailing zeros (e.g., `25` rather than `25.00`).
   - Eliminates floating-point negative zero (`-0`).
   - Uses scientific notation for exceedingly large numbers.
5. **Thermodynamic Spectrum Gauge:**
   A visual thermal tracker that indicates the temperature's physical zone (e.g., *Absolute Zero*, *Cryogenic*, *Sub-Zero Freezing*, *Room Temperature*, *Human Core*, *Water Boiling*).
6. **One-Click Quick Presets & Reference Benchmarks:**
   Preset buttons for 0°C, 25°C, 37°C, 100°C, and −273.15°C, plus interactive benchmark cards with one-click insertion.
7. **One-Click Clipboard Copying:**
   Individual copy buttons on each result card with feedback confirmation (`Copied!`).
8. **Built-in Quality Assurance Verification Suite:**
   An on-page interactive test runner that executes 14 mandatory test cases (Tests A through N) live in the browser.
9. **Demo Video Opening Title Card Modal:**
   Built-in full-screen title card modal displaying the candidate name (*Neha Vinod Borkar*), track (*Web Development & Designing*), and task title for the mandatory first 2 seconds of the demo recording.

---

## 4. Technologies Used
- **HTML5:** Semantic markup, accessible labels, ARIA live alerts, keyboard-navigable structure.
- **CSS3:** Custom properties (design tokens), `clamp()` fluid typography, flexbox and CSS grid layouts, high-contrast dark theme, `@media (prefers-reduced-motion: reduce)`.
- **Vanilla JavaScript (ES6+):** Pure functional mathematical converters, regular expression input filtering, clipboard integration, event delegation, zero external runtime libraries.

---

## 5. Mathematical Conversion Formulas

ThermoFlow converts the input value into **Celsius** as the internal baseline pivot, then computes the other scales:

### 1. Celsius as Input
- To Fahrenheit:
  $$\text{°F} = (\text{°C} \times \frac{9}{5}) + 32$$
- To Kelvin:
  $$\text{K} = \text{°C} + 273.15$$

### 2. Fahrenheit as Input
- To Celsius:
  $$\text{°C} = (\text{°F} - 32) \times \frac{5}{9}$$
- To Kelvin:
  $$\text{K} = (\text{°F} - 32) \times \frac{5}{9} + 273.15$$

### 3. Kelvin as Input
- To Celsius:
  $$\text{°C} = \text{K} - 273.15$$
- To Fahrenheit:
  $$\text{°F} = (\text{K} - 273.15) \times \frac{9}{5} + 32$$

---

## 6. Input Validation & Absolute Zero Rules

| Scale | Absolute Zero Threshold | Rejection Condition | Behavior |
| :--- | :--- | :--- | :--- |
| **Celsius (°C)** | $-273.15\text{ °C}$ | $< -273.15\text{ °C}$ | Error banner displayed; results cleared |
| **Fahrenheit (°F)** | $-459.67\text{ °F}$ | $< -459.67\text{ °F}$ | Error banner displayed; results cleared |
| **Kelvin (K)** | $0\text{ K}$ | $< 0\text{ K}$ | Error banner displayed; results cleared |

- Floating-point comparisons use an $\epsilon = 10^{-7}$ tolerance so exact boundaries (e.g., $-273.15$) are never rejected by rounding anomalies.
- All non-numeric inputs are filtered via the regular expression `/^[-+]?(\d+(\.\d*)?|\.\d+)([eE][-+]?\d+)?$/`.

---

## 7. Project Structure
```text
temperature-converter/
├── index.html        # Semantic HTML5 document & UI layout
├── style.css         # Modern scientific CSS3 styling & responsive rules
├── script.js         # Vanilla JavaScript conversion logic & test runner
└── README.md         # Comprehensive documentation & verification report
```

---

## 8. Instructions for Running Locally

No installation, build step, or package manager is required.

### Method 1: Direct File Opening
1. Clone or download the repository to your local machine.
2. Navigate to the `temperature-converter/` directory.
3. Double-click `index.html` (or right-click $\rightarrow$ **Open With** $\rightarrow$ Google Chrome / Mozilla Firefox / Safari / Microsoft Edge).

### Method 2: Local HTTP Server (Optional)
If preferred, you may serve the directory using Python's built-in server:
```bash
# In the project directory:
python3 -m http.server 8000
```
Then visit `http://localhost:8000` in your web browser.

---

## 9. Verification & Test Report

All 14 test requirements (Tests A through N) defined in the specification were evaluated:

| Test ID | Description | Input | Unit | Expected Output | Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Test A** | Standard Room Temperature | `25` | °C | `25°C`, `77°F`, `298.15 K` | **PASSED** |
| **Test B** | Fahrenheit Freezing Point | `32` | °F | `0°C`, `32°F`, `273.15 K` | **PASSED** |
| **Test C** | Kelvin Freezing Point | `273.15`| K | `0°C`, `32°F`, `273.15 K` | **PASSED** |
| **Test D** | Celsius Freezing Point | `0` | °C | `0°C`, `32°F`, `273.15 K` | **PASSED** |
| **Test E** | Absolute Zero Boundary | `-273.15`| °C | `−273.15°C`, `−459.67°F`, `0 K` | **PASSED** |
| **Test F** | Below Absolute Zero (Celsius)| `-300` | °C | Friendly Absolute Zero rejection | **PASSED** |
| **Test G** | Below Absolute Zero (Fahrenheit)| `-500` | °F | Friendly Absolute Zero rejection | **PASSED** |
| **Test H** | Below Absolute Zero (Kelvin) | `-10` | K | Friendly Absolute Zero rejection | **PASSED** |
| **Test I** | Empty input | `""` | °C | Rejection with clear prompt | **PASSED** |
| **Test J** | Non-numeric string | `"12abc"`| °C | Rejection; not treated as zero | **PASSED** |
| **Test K** | Input numeric zero | `0` | °C | Valid conversion (`0°C`, `32°F`, `273.15 K`) | **PASSED** |
| **Test L** | Extremely large numeric value| `1000000`| °C | Computed without overflow or NaN | **PASSED** |
| **Test M** | Keyboard Enter interaction | `100` | °C | Converts without page refresh | **PASSED** |
| **Test N** | Reset button interaction | Click Reset | Any | Restores input and clears results | **PASSED** |

You can execute this exact test suite live by clicking **"Run Verification Tests (A–N)"** inside the app.

---

## 10. Known Limitations
- The atmospheric boiling point reference (100°C) applies strictly at standard sea-level atmospheric pressure (101.325 kPa / 1 atm). At higher altitudes (e.g. Denver, CO or Mount Everest), the physical boiling point of water decreases.
- Temperatures above $10^{12}$ are displayed in scientific notation for formatting cleanliness.

---

## 11. Author & Attribution
- **Candidate:** Neha Vinod Borkar
- **Email:** nehaborkar2408@gmail.com
- **Internship:** Oasis Infobyte (OIBSIP) — Web Development & Designing
- **Task:** Task 3 — Temperature Converter Website
- **License:** Open for academic and internship evaluation.
