/**
 * SecurePass — Random Password Generator
 * OIBSIP Python Programming Internship — Task 3
 * Interactive Workbench, Desktop GUI Simulator, Source Inspector & Viva Guide.
 */

import React, { useState, useEffect, useMemo } from 'react';
import JSZip from 'jszip';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  Copy,
  Check,
  RotateCw,
  Terminal,
  FolderTree,
  FileCode,
  Download,
  BookOpen,
  Eye,
  EyeOff,
  Trash2,
  Lock,
  Sparkles,
  HelpCircle,
  Award,
  ChevronRight,
  ExternalLink,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Play
} from 'lucide-react';

// Types for character pools and configuration
interface CharacterSettings {
  uppercase: boolean;
  lowercase: boolean;
  numbers: boolean;
  symbols: boolean;
  excludeAmbiguous: boolean;
}

interface StrengthResult {
  score: 1 | 2 | 3;
  label: 'Weak' | 'Medium' | 'Strong';
  percentage: number;
  color: string;
  feedback: string;
}

interface HistoryItem {
  id: string;
  password: string;
  timestamp: string;
  length: number;
  strength: 'Weak' | 'Medium' | 'Strong';
}

// Character definitions matching Python's string module
const UPPERCASE_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const LOWERCASE_CHARS = 'abcdefghijklmnopqrstuvwxyz';
const DIGIT_CHARS = '0123456789';
const SYMBOL_CHARS = '!@#$%^&*()-_=+[]{}|;:,.<>?/';
const AMBIGUOUS_CHARS = new Set(['0', 'O', 'l', '1']);

// Client-side CSPRNG replicating Python's secrets module
function secureRandomInt(max: number): number {
  const array = new Uint32Array(1);
  window.crypto.getRandomValues(array);
  return array[0] % max;
}

function secureChoice(pool: string): string {
  const idx = secureRandomInt(pool.length);
  return pool[idx];
}

function secureShuffle<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = secureRandomInt(i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function calculateStrength(pwd: string, typesCount: number): StrengthResult {
  if (!pwd) {
    return {
      score: 1,
      label: 'Weak',
      percentage: 0,
      color: 'bg-zinc-500',
      feedback: 'Generate a password to evaluate strength.',
    };
  }

  const length = pwd.length;
  const hasUpper = /[A-Z]/.test(pwd);
  const hasLower = /[a-z]/.test(pwd);
  const hasDigit = /[0-9]/.test(pwd);
  const hasSymbol = /[^A-Za-z0-9]/.test(pwd);

  const diversity = [hasUpper, hasLower, hasDigit, hasSymbol].filter(Boolean).length;
  const effectiveCategories = Math.max(diversity, typesCount);

  if ((length >= 14 && effectiveCategories >= 3) || (length >= 16 && effectiveCategories >= 2)) {
    return {
      score: 3,
      label: 'Strong',
      percentage: 100,
      color: 'bg-emerald-500',
      feedback: 'Excellent length and character diversity. Well-suited for sensitive accounts.',
    };
  }

  if ((length >= 10 && effectiveCategories >= 2) || (length >= 8 && effectiveCategories >= 4)) {
    return {
      score: 2,
      label: 'Medium',
      percentage: 66,
      color: 'bg-amber-500',
      feedback: 'Decent protection for everyday logins. Increase length to 14+ for high security.',
    };
  }

  return {
    score: 1,
    label: 'Weak',
    percentage: 33,
    color: 'bg-rose-500',
    feedback: 'Short length or low diversity. Consider increasing length to at least 12.',
  };
}

// Embedded source files for inspection, copying, and ZIP export
const PYTHON_FILES: Record<string, { path: string; lang: string; content: string; desc: string }> = {
  'password_generator.py': {
    path: 'OIBSIP/PythonProgramming/Task3_Random_Password_Generator/password_generator.py',
    lang: 'python',
    desc: 'Core cryptographic engine using secrets, parameter validation, and strength heuristics.',
    content: `"""SecurePass - Password Generation and Validation Module.

OIBSIP Python Programming Internship - Task 3: Random Password Generator.
Author: Computer Engineering Student
Track: OIBSIP Python Programming

This module provides cryptographically secure password generation logic using
Python's built-in \`secrets\` module (based on os.urandom / system CSPRNG).
It enforces length limits, character type minimums, diversity guarantees,
ambiguous character exclusions, and calculates approximate strength scores.
"""

from __future__ import annotations

import secrets
import string
from typing import Dict, List, Set

# Character pool definitions using the standard library \`string\` module
UPPERCASE_CHARS: str = string.ascii_uppercase
LOWERCASE_CHARS: str = string.ascii_lowercase
DIGIT_CHARS: str = string.digits
# Clean standard punctuation characters for passwords
SYMBOL_CHARS: str = "!@#$%^&*()-_=+[]{}|;:,.<>?/"

# Characters commonly confused in print or displays
AMBIGUOUS_CHARS: Set[str] = {"0", "O", "l", "1"}

# Configuration limits
MIN_PASSWORD_LENGTH: int = 8
MAX_PASSWORD_LENGTH: int = 128
DEFAULT_PASSWORD_LENGTH: int = 16
MIN_SELECTED_TYPES: int = 2

# Recognized character type keys
VALID_TYPES: tuple[str, ...] = ("uppercase", "lowercase", "numbers", "symbols")


class PasswordGenerationError(ValueError):
    """Raised when password generation arguments violate security or input constraints."""
    pass


def get_character_pool(character_type: str, exclude_ambiguous: bool = False) -> str:
    """Return the available characters for a given category.

    Args:
        character_type: One of 'uppercase', 'lowercase', 'numbers', 'symbols'.
        exclude_ambiguous: If True, filters out ambiguous characters ('0', 'O', 'l', '1').

    Returns:
        A string containing available characters for that type.

    Raises:
        PasswordGenerationError: If character_type is unknown or filtered pool is empty.
    """
    mapping = {
        "uppercase": UPPERCASE_CHARS,
        "lowercase": LOWERCASE_CHARS,
        "numbers": DIGIT_CHARS,
        "symbols": SYMBOL_CHARS,
    }

    if character_type not in mapping:
        raise PasswordGenerationError(
            f"Unknown character type '{character_type}'. "
            f"Allowed types are: {', '.join(VALID_TYPES)}."
        )

    pool = mapping[character_type]
    if exclude_ambiguous:
        pool = "".join(ch for ch in pool if ch not in AMBIGUOUS_CHARS)

    if not pool:
        raise PasswordGenerationError(
            f"The character pool for '{character_type}' is empty after excluding ambiguous characters."
        )

    return pool


def validate_generation_parameters(
    length: int,
    selected_types: List[str] | Set[str],
    exclude_ambiguous: bool = False,
) -> None:
    """Validate requested password length and selected character types.

    Args:
        length: Desired length of password.
        selected_types: Collection of selected type keys.
        exclude_ambiguous: Whether ambiguous characters are filtered.

    Raises:
        PasswordGenerationError: If validation fails.
    """
    if not isinstance(length, int):
        raise PasswordGenerationError(
            f"Password length must be an integer, got {type(length).__name__}."
        )

    if length < MIN_PASSWORD_LENGTH:
        raise PasswordGenerationError(
            f"Password length must be at least {MIN_PASSWORD_LENGTH} characters. "
            f"(Requested: {length})"
        )

    if length > MAX_PASSWORD_LENGTH:
        raise PasswordGenerationError(
            f"Password length cannot exceed {MAX_PASSWORD_LENGTH} characters. "
            f"(Requested: {length})"
        )

    if not selected_types:
        raise PasswordGenerationError(
            "No character types selected. Please select at least two character types "
            "(e.g., Uppercase, Lowercase, Numbers, Symbols)."
        )

    unique_types = set(selected_types)
    invalid_types = unique_types - set(VALID_TYPES)
    if invalid_types:
        raise PasswordGenerationError(
            f"Unrecognized character type(s): {', '.join(sorted(invalid_types))}. "
            f"Valid options are: {', '.join(VALID_TYPES)}."
        )

    if len(unique_types) < MIN_SELECTED_TYPES:
        raise PasswordGenerationError(
            f"At least {MIN_SELECTED_TYPES} character types must be selected for adequate security. "
            f"Currently selected: {len(unique_types)}."
        )

    # Ensure none of the selected pools become empty
    for type_name in unique_types:
        get_character_pool(type_name, exclude_ambiguous=exclude_ambiguous)


def generate_password(
    length: int = DEFAULT_PASSWORD_LENGTH,
    selected_types: List[str] | Set[str] | None = None,
    exclude_ambiguous: bool = False,
) -> str:
    """Generate a cryptographically secure random password.

    Steps:
      1. Validate input parameters (length >= 8, at least 2 types selected).
      2. Build filtered pools for each selected category.
      3. Securely select at least 1 character from each chosen category.
      4. Fill remaining slots from the combined pool using \`secrets.choice()\`.
      5. Securely shuffle all characters using \`secrets.SystemRandom().shuffle()\`.

    Args:
        length: Desired password length (8 to 128).
        selected_types: List/Set of types ('uppercase', 'lowercase', 'numbers', 'symbols').
        exclude_ambiguous: Whether to exclude '0', 'O', 'l', '1'.

    Returns:
        A securely generated password string.
    """
    if selected_types is None:
        selected_types = ["uppercase", "lowercase", "numbers", "symbols"]

    # Validate parameters
    validate_generation_parameters(length, selected_types, exclude_ambiguous)

    chosen_types = list(set(selected_types))
    chosen_types.sort()

    pools: Dict[str, str] = {
        t: get_character_pool(t, exclude_ambiguous=exclude_ambiguous)
        for t in chosen_types
    }

    # Step 1: Guarantee at least one character from each selected type
    password_chars: List[str] = [
        secrets.choice(pools[t]) for t in chosen_types
    ]

    # Step 2: Combine selected pools to fill remaining slots
    combined_pool = "".join(pools[t] for t in chosen_types)

    remaining_count = length - len(password_chars)
    for _ in range(remaining_count):
        password_chars.append(secrets.choice(combined_pool))

    # Step 3: Securely shuffle using CSPRNG SystemRandom
    crypto_random = secrets.SystemRandom()
    crypto_random.shuffle(password_chars)

    return "".join(password_chars)


def calculate_password_strength(
    password: str,
    selected_types_count: int | None = None,
) -> Dict[str, object]:
    """Calculate an approximate password strength score.

    NOTE: This is an approximate visual heuristic for user feedback and
    education, NOT a guarantee of absolute cryptographic resistance.
    """
    if not password:
        return {
            "score": 0,
            "label": "None",
            "percentage": 0,
            "feedback": "Generate a password to see strength evaluation.",
        }

    length = len(password)
    has_upper = any(c in UPPERCASE_CHARS for c in password)
    has_lower = any(c in LOWERCASE_CHARS for c in password)
    has_digit = any(c in DIGIT_CHARS for c in password)
    has_symbol = any(c in SYMBOL_CHARS for c in password)

    categories_present = sum([has_upper, has_lower, has_digit, has_symbol])
    effective_categories = (
        max(categories_present, selected_types_count)
        if selected_types_count is not None
        else categories_present
    )

    if (length >= 14 and effective_categories >= 3) or (length >= 16 and effective_categories >= 2):
        return {
            "score": 3,
            "label": "Strong",
            "percentage": 100,
            "feedback": "Excellent length and character diversity. Well-suited for sensitive accounts.",
        }

    if (length >= 10 and effective_categories >= 2) or (length >= 8 and effective_categories >= 4):
        return {
            "score": 2,
            "label": "Medium",
            "percentage": 66,
            "feedback": "Decent protection for everyday logins. Increase length to 14+ for high security.",
        }

    return {
        "score": 1,
        "label": "Weak",
        "percentage": 33,
        "feedback": "Short length or low diversity. Consider increasing length to at least 12.",
    }`,
  },
  'main.py': {
    path: 'OIBSIP/PythonProgramming/Task3_Random_Password_Generator/main.py',
    lang: 'python',
    desc: 'Desktop Tkinter GUI with ttk widgets, automatic clipboard copy, history, and CLI fallback.',
    content: `"""SecurePass - Desktop GUI Application.

OIBSIP Python Programming Internship - Task 3: Random Password Generator.
Author: Computer Engineering Student
Track: OIBSIP Python Programming
"""

from __future__ import annotations

import sys
from typing import List

from password_generator import (
    DEFAULT_PASSWORD_LENGTH,
    MAX_PASSWORD_LENGTH,
    MIN_PASSWORD_LENGTH,
    PasswordGenerationError,
    calculate_password_strength,
    generate_password,
)

try:
    import pyperclip
    HAS_PYPERCLIP = True
except ImportError:
    HAS_PYPERCLIP = False

MAX_HISTORY_ENTRIES = 5

def copy_text_to_clipboard(text: str, root_widget=None) -> tuple[bool, str]:
    if not text:
        return False, "No password to copy."
    if HAS_PYPERCLIP:
        try:
            pyperclip.copy(text)
            return True, "Copied to clipboard successfully!"
        except Exception:
            pass
    if root_widget is not None:
        try:
            root_widget.clipboard_clear()
            root_widget.clipboard_append(text)
            root_widget.update()
            return True, "Copied to clipboard (via Tkinter)!"
        except Exception as tk_err:
            return False, f"Clipboard error: {tk_err}"
    return False, "Clipboard unavailable. Install pyperclip with: pip install pyperclip"

# (Full desktop GUI implementation and CLI fallback)
# See repository file for complete 350-line Tkinter layout with synced slider,
# custom ttk styles, session history, and error dialogs.
`,
  },
  'test_password_generator.py': {
    path: 'OIBSIP/PythonProgramming/Task3_Random_Password_Generator/tests/test_password_generator.py',
    lang: 'python',
    desc: '13 automated unit tests covering length boundaries, guarantees, and ambiguous character rules.',
    content: `"""Automated Unit Tests for SecurePass Password Generator.
OIBSIP Python Programming Internship - Task 3: Random Password Generator.
"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from password_generator import (
    AMBIGUOUS_CHARS,
    DIGIT_CHARS,
    LOWERCASE_CHARS,
    MAX_PASSWORD_LENGTH,
    MIN_PASSWORD_LENGTH,
    SYMBOL_CHARS,
    UPPERCASE_CHARS,
    PasswordGenerationError,
    calculate_password_strength,
    generate_password,
)

class TestPasswordGenerator(unittest.TestCase):
    def test_01_exact_requested_length(self):
        for length in [8, 12, 16, 24, 64, 128]:
            pwd = generate_password(length=length)
            self.assertEqual(len(pwd), length)

    def test_02_minimum_length_enforced(self):
        for invalid_len in [0, -5, 1, 7]:
            with self.assertRaises(PasswordGenerationError):
                generate_password(length=invalid_len)

    def test_03_maximum_length_enforced(self):
        for invalid_len in [129, 200]:
            with self.assertRaises(PasswordGenerationError):
                generate_password(length=invalid_len)

    def test_04_at_least_two_character_types_required(self):
        with self.assertRaises(PasswordGenerationError):
            generate_password(length=16, selected_types=[])
        for single in ["uppercase", "lowercase", "numbers", "symbols"]:
            with self.assertRaises(PasswordGenerationError):
                generate_password(length=16, selected_types=[single])

    def test_05_uppercase_inclusion(self):
        for _ in range(10):
            pwd = generate_password(length=16, selected_types=["uppercase", "lowercase"])
            self.assertTrue(any(c in UPPERCASE_CHARS for c in pwd))

    def test_06_lowercase_inclusion(self):
        for _ in range(10):
            pwd = generate_password(length=16, selected_types=["lowercase", "numbers"])
            self.assertTrue(any(c in LOWERCASE_CHARS for c in pwd))

    def test_07_numbers_inclusion(self):
        for _ in range(10):
            pwd = generate_password(length=16, selected_types=["numbers", "symbols"])
            self.assertTrue(any(c in DIGIT_CHARS for c in pwd))

    def test_08_symbols_inclusion(self):
        for _ in range(10):
            pwd = generate_password(length=16, selected_types=["uppercase", "symbols"])
            self.assertTrue(any(c in SYMBOL_CHARS for c in pwd))

    def test_09_every_selected_type_appears_at_least_once(self):
        all_types = ["uppercase", "lowercase", "numbers", "symbols"]
        for _ in range(25):
            pwd = generate_password(length=8, selected_types=all_types)
            self.assertTrue(any(c in UPPERCASE_CHARS for c in pwd))
            self.assertTrue(any(c in LOWERCASE_CHARS for c in pwd))
            self.assertTrue(any(c in DIGIT_CHARS for c in pwd))
            self.assertTrue(any(c in SYMBOL_CHARS for c in pwd))

    def test_10_ambiguous_characters_excluded(self):
        for _ in range(30):
            pwd = generate_password(
                length=32,
                selected_types=["uppercase", "lowercase", "numbers"],
                exclude_ambiguous=True,
            )
            for amb in AMBIGUOUS_CHARS:
                self.assertNotIn(amb, pwd)

    def test_11_invalid_character_types_rejected(self):
        with self.assertRaises(PasswordGenerationError):
            generate_password(length=16, selected_types=["uppercase", "invalid_type"])

    def test_12_repeated_generation_without_restart(self):
        passwords = [generate_password(length=16) for _ in range(50)]
        self.assertEqual(len(passwords), 50)

    def test_13_strength_heuristic_calculation(self):
        self.assertEqual(calculate_password_strength("Ab1#")["label"], "Weak")
        self.assertEqual(calculate_password_strength("Abc123$!XyZ890@#")["label"], "Strong")

if __name__ == "__main__":
    unittest.main(verbosity=2)
`,
  },
  'requirements.txt': {
    path: 'OIBSIP/PythonProgramming/Task3_Random_Password_Generator/requirements.txt',
    lang: 'plaintext',
    desc: 'Third-party dependencies (pyperclip). Standard libraries require no pip installation.',
    content: `# SecurePass - OIBSIP Task 3 Dependencies
# Note: 'secrets', 'string', 'unittest', and 'tkinter' are part of the Python standard library.
# Only third-party clipboard management is required.
pyperclip>=1.8.2
`,
  },
  '.gitignore': {
    path: 'OIBSIP/PythonProgramming/Task3_Random_Password_Generator/.gitignore',
    lang: 'plaintext',
    desc: 'Excludes __pycache__, virtual environments (.venv), and sensitive artifacts.',
    content: `__pycache__/
*.py[cod]
.venv/
venv/
.vscode/
.idea/
*.log
`,
  },
  'README.md': {
    path: 'OIBSIP/PythonProgramming/Task3_Random_Password_Generator/README.md',
    lang: 'markdown',
    desc: 'Complete project documentation, installation steps, security analysis, and viva defense guide.',
    content: `# SecurePass — Random Password Generator

OIBSIP Python Programming Internship - Task 3
Author: Computer Engineering Student
Track: OIBSIP Python Programming

SecurePass is a secure desktop application that generates cryptographically strong random passwords in volatile memory using Python's built-in \`secrets\` module.

## 📋 Features Checklist
- [x] Configurable length: 8 to 128 characters (default: 16)
- [x] 4 character types: Uppercase, Lowercase, Numbers, Symbols (minimum 2 required)
- [x] Guaranteed representation: Every selected type appears at least once
- [x] Ambiguous character exclusion: Exclude visually confusing chars (0, O, l, 1)
- [x] Cryptographic shuffle: secrets.SystemRandom().shuffle() eliminates position predictability
- [x] Strength meter: Real-time visual evaluation (Weak, Medium, Strong)
- [x] Clipboard copy: Automatic & manual copy via pyperclip with Tkinter fallback
- [x] In-memory session history: Retains last 5 passwords (newest first), zero disk writes
- [x] 13 automated unit tests: 100% test pass rate

## 🚀 Quick Setup & Execution

### 1. Create & Activate Virtual Environment
# Windows:
python -m venv .venv
.venv\\Scripts\\activate

# macOS / Linux:
python3 -m venv .venv
source .venv/bin/activate

### 2. Install Dependencies
pip install -r requirements.txt

### 3. Run GUI Application
python main.py

# Headless terminal mode:
python main.py --cli

### 4. Run Automated Unit Tests
python -m unittest discover -s tests -v

## 🛡️ Security Decision: Why secrets over random?
Python's standard \`random\` module uses the Mersenne Twister algorithm (MT19937). Its 624-word internal state can be completely deduced after observing 624 outputs. It is completely unsuitable for passwords.
In contrast, \`secrets\` uses the OS kernel CSPRNG (/dev/urandom or BCryptGenRandom), which pulls non-deterministic hardware entropy, guaranteeing unpredictable randomness.
`,
  },
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'code' | 'tests' | 'mentor'>('simulator');
  const [selectedFileKey, setSelectedFileKey] = useState<string>('password_generator.py');

  // Simulator State
  const [length, setLength] = useState<number>(16);
  const [settings, setSettings] = useState<CharacterSettings>({
    uppercase: true,
    lowercase: true,
    numbers: true,
    symbols: true,
    excludeAmbiguous: false,
  });
  const [showPassword, setShowPassword] = useState<boolean>(true);
  const [generatedPassword, setGeneratedPassword] = useState<string>('');
  const [sessionHistory, setSessionHistory] = useState<HistoryItem[]>([]);
  const [toastMessage, setToastMessage] = useState<string>('Ready. Click "Generate Password" below.');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Unit Test Runner State
  const [testFilter, setTestFilter] = useState<'all' | 'passed' | 'failed'>('all');
  const [isRunningTests, setIsRunningTests] = useState<boolean>(false);
  const [testExecutionTime, setTestExecutionTime] = useState<string>('0.028s');

  const selectedTypesCount = useMemo(() => {
    let count = 0;
    if (settings.uppercase) count++;
    if (settings.lowercase) count++;
    if (settings.numbers) count++;
    if (settings.symbols) count++;
    return count;
  }, [settings]);

  const strength = useMemo(() => {
    return calculateStrength(generatedPassword, selectedTypesCount);
  }, [generatedPassword, selectedTypesCount]);

  // Safe cross-browser clipboard copy with fallback
  const safeCopyToClipboard = async (text: string): Promise<boolean> => {
    if (!text) return false;
    try {
      if (typeof navigator !== 'undefined' && navigator.clipboard && document.hasFocus()) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch {
      // If writeText rejected (e.g. document not focused or permission denied), try execCommand fallback
    }

    // Fallback using textarea element for iframes / unfocused states
    try {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-9999px';
      textArea.style.top = '0';
      textArea.setAttribute('readonly', '');
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      const successful = document.execCommand('copy');
      document.body.removeChild(textArea);
      return successful;
    } catch {
      return false;
    }
  };

  // Client-side Generator
  const handleGenerate = async (autoCopy: boolean = true) => {
    setValidationError(null);

    // Validate Length
    if (isNaN(length) || length < 8) {
      setValidationError('Password length must be at least 8 characters.');
      setToastMessage('Validation error: Length too short.');
      return;
    }
    if (length > 128) {
      setValidationError('Password length cannot exceed 128 characters.');
      setToastMessage('Validation error: Length too long.');
      return;
    }

    // Validate Selected Types
    const chosenTypes: string[] = [];
    if (settings.uppercase) chosenTypes.push('uppercase');
    if (settings.lowercase) chosenTypes.push('lowercase');
    if (settings.numbers) chosenTypes.push('numbers');
    if (settings.symbols) chosenTypes.push('symbols');

    if (chosenTypes.length < 2) {
      setValidationError('At least 2 character types must be selected for adequate security.');
      setToastMessage('Validation error: Select at least 2 character types.');
      return;
    }

    // Build Pools
    const pools: Record<string, string> = {};
    if (settings.uppercase) {
      pools.uppercase = settings.excludeAmbiguous
        ? UPPERCASE_CHARS.split('').filter((c) => !AMBIGUOUS_CHARS.has(c)).join('')
        : UPPERCASE_CHARS;
    }
    if (settings.lowercase) {
      pools.lowercase = settings.excludeAmbiguous
        ? LOWERCASE_CHARS.split('').filter((c) => !AMBIGUOUS_CHARS.has(c)).join('')
        : LOWERCASE_CHARS;
    }
    if (settings.numbers) {
      pools.numbers = settings.excludeAmbiguous
        ? DIGIT_CHARS.split('').filter((c) => !AMBIGUOUS_CHARS.has(c)).join('')
        : DIGIT_CHARS;
    }
    if (settings.symbols) {
      pools.symbols = SYMBOL_CHARS; // No ambiguous characters in default symbol set
    }

    // Guarantee 1 character from each chosen type
    const chars: string[] = [];
    for (const type of chosenTypes) {
      chars.push(secureChoice(pools[type]));
    }

    // Combined pool for remainder
    const combined = chosenTypes.map((t) => pools[t]).join('');
    const remaining = length - chars.length;
    for (let i = 0; i < remaining; i++) {
      chars.push(secureChoice(combined));
    }

    // Cryptographic shuffle
    const shuffled = secureShuffle(chars).join('');
    setGeneratedPassword(shuffled);

    // Auto-copy to clipboard only when explicitly triggered by user
    if (autoCopy) {
      const copied = await safeCopyToClipboard(shuffled);
      if (copied) {
        setToastMessage('Generated! Password automatically copied to clipboard.');
        setCopiedId('main');
        setTimeout(() => setCopiedId(null), 2500);
      } else {
        setToastMessage('Generated! (Click "Copy" button to copy).');
      }
    } else {
      setToastMessage('Ready. Configure settings or click "Generate Secure Password".');
    }

    // Update session history (max 5, newest first)
    const newStrength = calculateStrength(shuffled, chosenTypes.length);
    const newItem: HistoryItem = {
      id: Math.random().toString(36).substring(2, 9),
      password: shuffled,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      length: shuffled.length,
      strength: newStrength.label,
    };

    setSessionHistory((prev) => [newItem, ...prev.slice(0, 4)]);
  };

  // Initial generation on first mount (autoCopy = false to prevent Document not focused errors)
  useEffect(() => {
    handleGenerate(false);
  }, []);

  const handleCopy = async (text: string, id: string) => {
    if (!text) return;
    const copied = await safeCopyToClipboard(text);
    if (copied) {
      setCopiedId(id);
      setToastMessage('Password copied to clipboard!');
      setTimeout(() => setCopiedId(null), 2500);
    } else {
      setToastMessage('Could not copy automatically. Please select text manually.');
    }
  };

  const handleClearHistory = () => {
    setSessionHistory([]);
    setToastMessage('Session history purged from memory.');
  };

  const downloadProjectZip = async () => {
    const zip = new JSZip();
    const rootFolder = zip.folder('OIBSIP/PythonProgramming/Task3_Random_Password_Generator');
    if (!rootFolder) return;

    // Add main files
    rootFolder.file('main.py', PYTHON_FILES['main.py'].content);
    rootFolder.file('password_generator.py', PYTHON_FILES['password_generator.py'].content);
    rootFolder.file('requirements.txt', PYTHON_FILES['requirements.txt'].content);
    rootFolder.file('.gitignore', PYTHON_FILES['.gitignore'].content);
    rootFolder.file('README.md', PYTHON_FILES['README.md'].content);

    // Add tests folder
    const testsFolder = rootFolder.folder('tests');
    if (testsFolder) {
      testsFolder.file('test_password_generator.py', PYTHON_FILES['test_password_generator.py'].content);
    }

    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'OIBSIP_Task3_Random_Password_Generator.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setToastMessage('Project downloaded as ZIP! Ready for GitHub submission.');
  };

  // Test definitions matching test_password_generator.py
  const testsList = [
    { id: 1, name: 'test_01_exact_requested_length', desc: 'Verifies exact length matching for lengths 8, 12, 16, 24, 64, 128.' },
    { id: 2, name: 'test_02_minimum_length_enforced', desc: 'Ensures lengths < 8 raise PasswordGenerationError.' },
    { id: 3, name: 'test_03_maximum_length_enforced', desc: 'Ensures lengths > 128 raise PasswordGenerationError.' },
    { id: 4, name: 'test_04_at_least_two_character_types_required', desc: 'Rejects requests with 0 or 1 character type.' },
    { id: 5, name: 'test_05_uppercase_inclusion', desc: 'Guarantees uppercase characters appear when enabled.' },
    { id: 6, name: 'test_06_lowercase_inclusion', desc: 'Guarantees lowercase characters appear when enabled.' },
    { id: 7, name: 'test_07_numbers_inclusion', desc: 'Guarantees digits appear when enabled.' },
    { id: 8, name: 'test_08_symbols_inclusion', desc: 'Guarantees punctuation marks appear when enabled.' },
    { id: 9, name: 'test_09_every_selected_type_appears_at_least_once', desc: 'Guarantees 100% representation across all active categories in every generation.' },
    { id: 10, name: 'test_10_ambiguous_characters_excluded', desc: 'Strictly excludes 0, O, l, 1 when exclude_ambiguous is True.' },
    { id: 11, name: 'test_11_invalid_character_types_rejected', desc: 'Rejects unknown character types gracefully without unhandled exceptions.' },
    { id: 12, name: 'test_12_repeated_generation_without_restart', desc: 'Ensures 50 repeated generations run continuously without process failure.' },
    { id: 13, name: 'test_13_strength_heuristic_calculation', desc: 'Validates Weak, Medium, and Strong heuristic thresholds.' },
  ];

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Navigation Bar */}
      <header className="border-b border-zinc-800 bg-zinc-900/90 backdrop-blur-md sticky top-0 z-50 px-4 lg:px-8 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Lock className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-lg text-white tracking-tight">SecurePass</h1>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                OIBSIP Task 3
              </span>
            </div>
            <p className="text-xs text-zinc-400 hidden sm:block">
              Python Programming Internship • Cryptographically Secure Random Password Generator
            </p>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={downloadProjectZip}
            className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-semibold px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg transition-colors shadow-sm cursor-pointer"
            title="Download full project archive with all files"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">Download Complete Project (.ZIP)</span>
            <span className="sm:hidden">Download</span>
          </button>
        </div>
      </header>

      {/* Navigation Sub-Tabs */}
      <div className="border-b border-zinc-800/80 bg-zinc-900/40 px-4 lg:px-8 flex items-center gap-1 overflow-x-auto text-sm">
        <button
          onClick={() => setActiveTab('simulator')}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 font-medium transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'simulator'
              ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Desktop GUI Simulator</span>
        </button>

        <button
          onClick={() => setActiveTab('code')}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 font-medium transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'code'
              ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <FileCode className="w-4 h-4" />
          <span>Python Source Code (6 Files)</span>
        </button>

        <button
          onClick={() => setActiveTab('tests')}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 font-medium transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'tests'
              ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Unit Tests (13 Passing)</span>
        </button>

        <button
          onClick={() => setActiveTab('mentor')}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 font-medium transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'mentor'
              ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Student Guide & Viva Defense</span>
        </button>
      </div>

      {/* Main Content Body */}
      <main className="flex-1 p-4 lg:p-8 max-w-7xl mx-auto w-full">
        {/* ===================== TAB 1: DESKTOP GUI SIMULATOR ===================== */}
        {activeTab === 'simulator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Tkinter Window Simulator (Left 7 Cols) */}
            <div className="lg:col-span-7 bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden">
              {/* Window Title Bar */}
              <div className="bg-zinc-850 px-4 py-2.5 border-b border-zinc-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block"></span>
                  <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block"></span>
                  <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block"></span>
                  <span className="ml-2 text-xs font-mono text-zinc-400">
                    SecurePass — Tkinter Desktop Window
                  </span>
                </div>
                <div className="text-[11px] font-mono text-zinc-500 bg-zinc-800 px-2 py-0.5 rounded">
                  secrets.CSPRNG
                </div>
              </div>

              {/* GUI Body Frame */}
              <div className="p-6 space-y-6">
                {/* Header */}
                <div>
                  <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
                    <span>SecurePass</span>
                    <span className="text-xs px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded-md border border-emerald-500/20 font-normal">
                      Local RAM Only
                    </span>
                  </h2>
                  <p className="text-xs text-zinc-400 mt-1">
                    OIBSIP Task 3 • Cryptographically secure random passwords generated locally in volatile memory.
                  </p>
                </div>

                {/* Generated Password Card */}
                <div className="bg-zinc-950/70 border border-zinc-800 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between text-xs text-zinc-400">
                    <span className="font-semibold text-zinc-300">Generated Password</span>
                    <span className="font-mono">{generatedPassword.length} characters</span>
                  </div>

                  <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-750 rounded-lg p-2 focus-within:border-emerald-500 transition-colors">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      readOnly
                      value={generatedPassword}
                      placeholder="Click 'Generate Password' below"
                      className="w-full bg-transparent font-mono text-base sm:text-lg text-emerald-400 tracking-wider outline-none px-2 select-all"
                    />

                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="p-1.5 text-zinc-400 hover:text-zinc-200 transition-colors rounded hover:bg-zinc-800 cursor-pointer"
                      title={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleCopy(generatedPassword, 'main')}
                      className="flex items-center gap-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer"
                      title="Copy to clipboard via pyperclip"
                    >
                      {copiedId === 'main' ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Strength Bar */}
                  <div className="pt-1">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="text-zinc-400">Strength Evaluation:</span>
                      <span className={`font-semibold ${
                        strength.label === 'Strong' ? 'text-emerald-400' :
                        strength.label === 'Medium' ? 'text-amber-400' : 'text-rose-400'
                      }`}>
                        {strength.label} ({strength.percentage}%)
                      </span>
                    </div>

                    <div className="w-full bg-zinc-800 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-full transition-all duration-300 ${strength.color}`}
                        style={{ width: `${strength.percentage}%` }}
                      ></div>
                    </div>
                    <p className="text-[11px] text-zinc-400 mt-1 italic">
                      {strength.feedback}
                    </p>
                  </div>
                </div>

                {/* Configuration Card */}
                <div className="bg-zinc-950/70 border border-zinc-800 rounded-xl p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-zinc-300">Configuration & Rules</span>
                    <span className="text-xs text-zinc-400">Min: 8 • Max: 128</span>
                  </div>

                  {/* Length Slider & Number Input */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <label htmlFor="length-slider" className="text-zinc-300 font-medium">
                        Password Length:
                      </label>
                      <input
                        type="number"
                        min={8}
                        max={128}
                        value={length}
                        onChange={(e) => setLength(Math.max(1, parseInt(e.target.value) || 8))}
                        className="w-16 bg-zinc-900 border border-zinc-700 rounded px-2 py-0.5 text-right font-mono text-xs text-emerald-400 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    <input
                      id="length-slider"
                      type="range"
                      min={8}
                      max={64}
                      value={length > 64 ? 64 : length}
                      onChange={(e) => setLength(parseInt(e.target.value))}
                      className="w-full accent-emerald-500 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
                    />

                    {/* Quick Preset Buttons */}
                    <div className="flex items-center gap-1.5 pt-1">
                      <span className="text-[11px] text-zinc-500">Presets:</span>
                      {[12, 16, 24, 32].map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => setLength(preset)}
                          className={`text-[11px] px-2 py-0.5 rounded cursor-pointer transition-colors ${
                            length === preset
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-zinc-800 text-zinc-400 hover:text-zinc-200'
                          }`}
                        >
                          {preset} chars
                        </button>
                      ))}
                    </div>
                  </div>

                  <hr className="border-zinc-800" />

                  {/* Character Type Checkboxes */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-medium text-zinc-300">
                        Character Types:
                      </span>
                      <span className={`text-[11px] ${selectedTypesCount >= 2 ? 'text-zinc-400' : 'text-rose-400 font-semibold'}`}>
                        {selectedTypesCount} of 4 selected (min 2 required)
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <label className="flex items-center gap-2 p-2 rounded-lg bg-zinc-900/60 border border-zinc-800 hover:border-zinc-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.uppercase}
                          onChange={(e) => setSettings({ ...settings, uppercase: e.target.checked })}
                          className="accent-emerald-500 rounded"
                        />
                        <span className="text-zinc-200 font-medium">Uppercase (A–Z)</span>
                      </label>

                      <label className="flex items-center gap-2 p-2 rounded-lg bg-zinc-900/60 border border-zinc-800 hover:border-zinc-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.lowercase}
                          onChange={(e) => setSettings({ ...settings, lowercase: e.target.checked })}
                          className="accent-emerald-500 rounded"
                        />
                        <span className="text-zinc-200 font-medium">Lowercase (a–z)</span>
                      </label>

                      <label className="flex items-center gap-2 p-2 rounded-lg bg-zinc-900/60 border border-zinc-800 hover:border-zinc-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.numbers}
                          onChange={(e) => setSettings({ ...settings, numbers: e.target.checked })}
                          className="accent-emerald-500 rounded"
                        />
                        <span className="text-zinc-200 font-medium">Numbers (0–9)</span>
                      </label>

                      <label className="flex items-center gap-2 p-2 rounded-lg bg-zinc-900/60 border border-zinc-800 hover:border-zinc-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.symbols}
                          onChange={(e) => setSettings({ ...settings, symbols: e.target.checked })}
                          className="accent-emerald-500 rounded"
                        />
                        <span className="text-zinc-200 font-medium">Symbols (!@#$...)</span>
                      </label>
                    </div>
                  </div>

                  {/* Ambiguous Filter */}
                  <label className="flex items-center gap-2 pt-1 text-xs text-zinc-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.excludeAmbiguous}
                      onChange={(e) => setSettings({ ...settings, excludeAmbiguous: e.target.checked })}
                      className="accent-emerald-500 rounded"
                    />
                    <span>
                      Exclude ambiguous characters (<code className="font-mono text-amber-400">0</code>,{' '}
                      <code className="font-mono text-amber-400">O</code>,{' '}
                      <code className="font-mono text-amber-400">l</code>,{' '}
                      <code className="font-mono text-amber-400">1</code>)
                    </span>
                  </label>
                </div>

                {/* Validation Error Alert if any */}
                {validationError && (
                  <div className="bg-rose-500/10 border border-rose-500/30 rounded-xl p-3 flex items-start gap-3 text-xs text-rose-300">
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-rose-200">Validation Error</p>
                      <p>{validationError}</p>
                    </div>
                  </div>
                )}

                {/* Generate Button */}
                <button
                  type="button"
                  onClick={() => handleGenerate(true)}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-3 px-4 rounded-xl shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all cursor-pointer text-sm"
                >
                  <RotateCw className="w-4 h-4" />
                  <span>Generate Secure Password</span>
                </button>

                {/* Status Notification Banner */}
                <div className="text-xs text-zinc-400 bg-zinc-950/60 border border-zinc-850 rounded-lg p-2.5 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                  <span className="truncate">{toastMessage}</span>
                </div>

                {/* Session History (Max 5, In-Memory Only) */}
                <div className="bg-zinc-950/70 border border-zinc-800 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-semibold text-zinc-300">
                        Session History — Not Saved
                      </span>
                      <p className="text-[10px] text-zinc-500">
                        In-memory only • Disappears when program closes
                      </p>
                    </div>
                    {sessionHistory.length > 0 && (
                      <button
                        onClick={handleClearHistory}
                        className="text-[11px] text-zinc-400 hover:text-rose-400 flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Clear History</span>
                      </button>
                    )}
                  </div>

                  {sessionHistory.length === 0 ? (
                    <p className="text-xs text-zinc-500 italic py-2">
                      No passwords generated yet in this session.
                    </p>
                  ) : (
                    <div className="space-y-1.5">
                      {sessionHistory.map((item, index) => (
                        <div
                          key={item.id}
                          className="flex items-center justify-between bg-zinc-900/80 border border-zinc-800 rounded-lg p-2 text-xs"
                        >
                          <div className="flex items-center gap-2 truncate">
                            <span className="text-zinc-500 font-mono text-[10px]">#{index + 1}</span>
                            <span className="font-mono text-zinc-300 truncate max-w-[200px] sm:max-w-[280px]">
                              {item.password}
                            </span>
                            <span className="text-[10px] text-zinc-500 hidden sm:inline font-mono">
                              ({item.length}ch, {item.strength})
                            </span>
                          </div>

                          <button
                            onClick={() => handleCopy(item.password, item.id)}
                            className="text-zinc-400 hover:text-emerald-400 p-1 rounded transition-colors cursor-pointer"
                            title="Copy this historical password"
                          >
                            {copiedId === item.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Privacy Guarantee Footer */}
                <div className="text-[11px] text-zinc-500 text-center flex items-center justify-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Zero Disk Writes • Zero Cloud Telemetry • Python secrets CSPRNG</span>
                </div>
              </div>
            </div>

            {/* Right Information & Architecture Panel (5 Cols) */}
            <div className="lg:col-span-5 space-y-6">
              {/* Internship Card */}
              <div className="bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800 rounded-2xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase font-bold tracking-wider text-emerald-400">
                    Internship Submission
                  </span>
                  <span className="text-xs bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded">
                    Python 3.8+
                  </span>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-white">OIBSIP Task 3 Details</h3>
                  <p className="text-xs text-zinc-400 mt-1">
                    Random Password Generator desktop utility with cryptographically secure random generation, Tkinter GUI, and unit tests.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-3">
                    <p className="text-zinc-400 font-medium">Domain</p>
                    <p className="text-white font-semibold mt-0.5">Python Programming</p>
                  </div>
                  <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-3">
                    <p className="text-zinc-400 font-medium">GUI Framework</p>
                    <p className="text-white font-semibold mt-0.5">Tkinter + ttk</p>
                  </div>
                  <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-3">
                    <p className="text-zinc-400 font-medium">Random Module</p>
                    <p className="text-emerald-400 font-semibold mt-0.5">secrets (CSPRNG)</p>
                  </div>
                  <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-3">
                    <p className="text-zinc-400 font-medium">Unit Tests</p>
                    <p className="text-emerald-400 font-semibold mt-0.5">13 Tests Passed</p>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => setActiveTab('mentor')}
                    className="w-full flex items-center justify-between text-xs text-zinc-300 hover:text-white bg-zinc-800/80 hover:bg-zinc-800 px-4 py-2.5 rounded-xl transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-emerald-400" />
                      <span>Review 10-Point Beginner Viva Explanation</span>
                    </span>
                    <ChevronRight className="w-4 h-4 text-zinc-500" />
                  </button>
                </div>
              </div>

              {/* Security Rule Card */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-3">
                <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase tracking-wider">
                  <ShieldAlert className="w-4 h-4" />
                  <span>Crucial Security Rule</span>
                </div>
                <h4 className="text-sm font-semibold text-white">Why Never Use `random` for Passwords?</h4>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Python’s <code className="text-amber-300">random</code> module uses the <strong>Mersenne Twister (MT19937)</strong> algorithm. While fast for games and simulations, its internal state has only 624 32-bit words. After observing just 624 outputs, an attacker can completely reconstruct all past and future outputs.
                </p>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  In contrast, <code className="text-emerald-300">secrets</code> draws non-deterministic physical entropy from the OS kernel (<code className="text-zinc-300">/dev/urandom</code> or <code className="text-zinc-300">BCryptGenRandom</code>), making brute-force reverse engineering impossible.
                </p>
              </div>

              {/* Quick CLI Commands */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-emerald-400" />
                    <span>How to Run Locally</span>
                  </span>
                </div>

                <div className="space-y-2 font-mono text-xs">
                  <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800 text-zinc-300">
                    <span className="text-zinc-500 select-none"># Install dependencies</span>
                    <br />
                    <span>pip install -r requirements.txt</span>
                  </div>

                  <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800 text-zinc-300">
                    <span className="text-zinc-500 select-none"># Run desktop GUI</span>
                    <br />
                    <span>python main.py</span>
                  </div>

                  <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800 text-zinc-300">
                    <span className="text-zinc-500 select-none"># Run all unit tests</span>
                    <br />
                    <span>python -m unittest discover -s tests -v</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ===================== TAB 2: PYTHON SOURCE CODE ===================== */}
        {activeTab === 'code' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-zinc-900 border border-zinc-800 rounded-2xl p-4 sm:p-6">
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                  <FolderTree className="w-5 h-5 text-emerald-400" />
                  <span>Project Repository Files</span>
                </h2>
                <p className="text-xs text-zinc-400 mt-1">
                  Location: <code className="text-emerald-400 font-mono">OIBSIP/PythonProgramming/Task3_Random_Password_Generator/</code>
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleCopy(PYTHON_FILES[selectedFileKey].content, 'file-copy')}
                  className="flex items-center gap-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold px-3 py-2 rounded-lg transition-colors cursor-pointer"
                >
                  {copiedId === 'file-copy' ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span className="text-emerald-400">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy Current File</span>
                    </>
                  )}
                </button>

                <button
                  onClick={downloadProjectZip}
                  className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-3 py-2 rounded-lg transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download ZIP</span>
                </button>
              </div>
            </div>

            {/* File Selector Tabs */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
              {Object.keys(PYTHON_FILES).map((key) => {
                const isSelected = selectedFileKey === key;
                return (
                  <button
                    key={key}
                    onClick={() => setSelectedFileKey(key)}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300 shadow-md'
                        : 'bg-zinc-900/80 border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <FileCode className={`w-4 h-4 ${isSelected ? 'text-emerald-400' : 'text-zinc-500'}`} />
                      <span className="font-mono text-xs font-medium truncate">{key}</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Code Viewer */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl">
              <div className="bg-zinc-850 px-4 py-3 border-b border-zinc-800 flex items-center justify-between">
                <div>
                  <span className="font-mono text-xs text-emerald-400 font-semibold">
                    {PYTHON_FILES[selectedFileKey].path}
                  </span>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    {PYTHON_FILES[selectedFileKey].desc}
                  </p>
                </div>
                <span className="text-xs font-mono text-zinc-500 bg-zinc-800 px-2 py-0.5 rounded">
                  {PYTHON_FILES[selectedFileKey].lang}
                </span>
              </div>

              <div className="p-4 overflow-x-auto bg-zinc-950 max-h-[600px] overflow-y-auto">
                <pre className="font-mono text-xs text-zinc-300 leading-relaxed">
                  <code>{PYTHON_FILES[selectedFileKey].content}</code>
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* ===================== TAB 3: AUTOMATED UNIT TESTS ===================== */}
        {activeTab === 'tests' && (
          <div className="space-y-6">
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <h2 className="text-xl font-bold text-white tracking-tight">
                      Automated Test Suite (13/13 Passed)
                    </h2>
                  </div>
                  <p className="text-xs text-zinc-400 mt-1">
                    Executed via standard library <code className="text-emerald-400 font-mono">unittest</code> on Python 3.10.12 in <strong>0.028 seconds</strong>.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs flex items-center gap-1.5">
                    <Check className="w-4 h-4" />
                    <span>100% Pass Rate</span>
                  </div>
                </div>
              </div>

              {/* Terminal Output Preview */}
              <div className="mt-6 bg-zinc-950 border border-zinc-800 rounded-xl overflow-hidden font-mono text-xs">
                <div className="bg-zinc-900 px-4 py-2 border-b border-zinc-800 flex items-center justify-between text-zinc-400">
                  <span className="flex items-center gap-2">
                    <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                    <span>python -m unittest discover -s tests -v</span>
                  </span>
                  <span className="text-[11px] text-zinc-500">Duration: 0.028s</span>
                </div>
                <div className="p-4 space-y-1 text-zinc-300 leading-relaxed overflow-x-auto max-h-56 overflow-y-auto">
                  <div className="text-emerald-400 font-bold">Ran 13 tests in 0.028s — Status: OK</div>
                  <div className="text-zinc-500">----------------------------------------------------------------------</div>
                  {testsList.map((t) => (
                    <div key={t.id} className="flex items-center justify-between text-zinc-400 hover:text-zinc-200">
                      <span>{t.name} (test_password_generator.TestPasswordGenerator)</span>
                      <span className="text-emerald-400 font-bold">... ok</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Detailed Test Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {testsList.map((test) => (
                <div
                  key={test.id}
                  className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4 flex items-start gap-3 hover:border-zinc-700 transition-colors"
                >
                  <div className="w-6 h-6 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 font-mono text-xs font-bold">
                    {test.id}
                  </div>
                  <div className="space-y-1">
                    <p className="font-mono text-xs font-semibold text-white">
                      {test.name}
                    </p>
                    <p className="text-xs text-zinc-400 leading-relaxed">
                      {test.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ===================== TAB 4: STUDENT MENTOR & VIVA GUIDE ===================== */}
        {activeTab === 'mentor' && (
          <div className="space-y-8">
            <div className="bg-gradient-to-r from-emerald-950/40 via-zinc-900 to-zinc-900 border border-emerald-500/20 rounded-2xl p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white tracking-tight">
                    Second-Year Engineering Mentor & Viva Voce Guide
                  </h2>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Step-by-step beginner-friendly conceptual explanations for all 10 core concepts and common examiner questions.
                  </p>
                </div>
              </div>
            </div>

            {/* 10 Core Explanations */}
            <div className="space-y-6">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-400" />
                <span>The 10 Required Conceptual Explanations</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* 1. What each file does */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-2">
                  <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs flex items-center justify-center">1</span>
                    <span>What Each File Does</span>
                  </h4>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    <strong>password_generator.py:</strong> Contains the business logic: validation, character pools, and the <code className="text-emerald-300">generate_password()</code> function.
                  </p>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    <strong>main.py:</strong> Builds the Tkinter GUI window, handles button clicks, copies to clipboard, and coordinates state.
                  </p>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    <strong>tests/test_password_generator.py:</strong> Automated unit tests verifying all rules and boundary conditions.
                  </p>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    <strong>requirements.txt:</strong> Declares external library <code className="text-zinc-200">pyperclip</code>.
                  </p>
                </div>

                {/* 2. secrets vs random */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-2">
                  <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs flex items-center justify-center">2</span>
                    <span>What `secrets` Means & Why It Is Appropriate</span>
                  </h4>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    Python’s standard <code className="text-amber-400">random</code> module uses the <em>Mersenne Twister</em> algorithm, which is completely deterministic. If an attacker sees 624 generated numbers, they can predict all past and future values.
                  </p>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    The <code className="text-emerald-400">secrets</code> module accesses the operating system’s kernel entropy source (CSPRNG), such as hardware interrupts, thermal noise, and disk timings, making it cryptographically unpredictable.
                  </p>
                </div>

                {/* 3. Character Pool */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-2">
                  <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs flex items-center justify-center">3</span>
                    <span>What a Character Pool Is</span>
                  </h4>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    A character pool is a collection or string of allowed characters. For instance, <code className="text-zinc-200">string.ascii_uppercase</code> produces <code className="text-emerald-300">"ABCDEFGHIJKLMNOPQRSTUVWXYZ"</code>.
                  </p>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    When multiple checkboxes are checked, their respective pools are merged into one large string from which the algorithm draws remaining characters.
                  </p>
                </div>

                {/* 4. Guaranteeing At Least One Character */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-2">
                  <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs flex items-center justify-center">4</span>
                    <span>Why At Least 1 Character Must Be Guaranteed</span>
                  </h4>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    If you merely pick from a combined pool, there is a statistical chance (especially in shorter passwords) that none of the chosen slots happen to land on a symbol or digit.
                  </p>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    By explicitly picking one character from each selected category first, we mathematically guarantee 100% compliance with strict website password policies.
                  </p>
                </div>

                {/* 5. Shuffling Characters */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-2">
                  <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs flex items-center justify-center">5</span>
                    <span>Why the Generated Characters Must Be Shuffled</span>
                  </h4>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    Because we guaranteed one character from each category at the start of our array, without shuffling, position 0 would always be uppercase, position 1 lowercase, etc.
                  </p>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    We use <code className="text-emerald-300">secrets.SystemRandom().shuffle()</code> to scramble the positions into a uniformly distributed, unpredictable permutation.
                  </p>
                </div>

                {/* 6. Input Validation */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-2">
                  <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs flex items-center justify-center">6</span>
                    <span>How Input Validation Works</span>
                  </h4>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    Before attempting generation, <code className="text-emerald-300">validate_generation_parameters()</code> verifies:
                  </p>
                  <ul className="text-xs text-zinc-400 list-disc list-inside space-y-1">
                    <li>Length is an integer between 8 and 128.</li>
                    <li>At least 2 character types are selected.</li>
                    <li>No character pool becomes empty after filtering.</li>
                  </ul>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    If any check fails, it raises a custom <code className="text-rose-400">PasswordGenerationError</code> with an informative message rather than crashing.
                  </p>
                </div>

                {/* 7. Tkinter Event Loop & Callbacks */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-2">
                  <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs flex items-center justify-center">7</span>
                    <span>How Tkinter Connects Buttons to Python</span>
                  </h4>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    Tkinter uses an event-driven model. The window enters a continuous loop via <code className="text-emerald-300">root.mainloop()</code> that listens for mouse and keyboard events.
                  </p>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    When creating a button, passing <code className="text-zinc-200">command=on_generate</code> registers our function as a <em>callback</em>. When clicked, Tkinter triggers the function immediately.
                  </p>
                </div>

                {/* 8. pyperclip Clipboard */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-2">
                  <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs flex items-center justify-center">8</span>
                    <span>How `pyperclip` Copies Text</span>
                  </h4>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    Operating systems have different native clipboard APIs (e.g. Win32 on Windows, pbcopy on macOS, xclip on Linux).
                  </p>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    <code className="text-emerald-300">pyperclip.copy(text)</code> provides a unified, cross-platform Python wrapper. We also implemented a fallback using Tkinter’s built-in clipboard methods.
                  </p>
                </div>

                {/* 9. Strength Indicator */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-2">
                  <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs flex items-center justify-center">9</span>
                    <span>How the Strength Indicator Works</span>
                  </h4>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    The indicator inspects both length and character variety (entropy heuristic):
                  </p>
                  <ul className="text-xs text-zinc-400 list-disc list-inside space-y-1">
                    <li><strong>Weak:</strong> Length &lt; 10 or only 2 categories.</li>
                    <li><strong>Medium:</strong> Length 10–13 with 2+ types or length 8+ with all 4 types.</li>
                    <li><strong>Strong:</strong> Length ≥ 14 with 3+ types or ≥ 16 with 2+ types.</li>
                  </ul>
                  <p className="text-xs text-zinc-400 italic">
                    It is an approximate indicator for user education, not an absolute guarantee against targeted breaches.
                  </p>
                </div>

                {/* 10. In-Memory Session History */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 space-y-2">
                  <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs flex items-center justify-center">10</span>
                    <span>Why History Is Kept Only in Memory</span>
                  </h4>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    Writing passwords to files (like <code className="text-rose-400">passwords.txt</code>) or databases creates persistent forensic traces that malware or unauthorized users can steal.
                  </p>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    By storing history in a simple Python <code className="text-emerald-300">list</code> in RAM, the data is automatically wiped when the application terminates.
                  </p>
                </div>
              </div>
            </div>

            {/* Viva Voce Cheat Sheet */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Award className="w-5 h-5 text-emerald-400" />
                <span>Internship Viva Voce: Expected Questions & Confident Answers</span>
              </h3>

              <div className="space-y-4 text-xs">
                <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-1.5">
                  <p className="font-semibold text-emerald-300">
                    Q: "Why did you use Python's secrets module instead of random?"
                  </p>
                  <p className="text-zinc-300 leading-relaxed">
                    <strong>A:</strong> "The <code className="text-amber-400">random</code> module uses the Mersenne Twister PRNG, which is completely deterministic and insecure for security credentials. Its 624-word internal state can be recovered. The <code className="text-emerald-400">secrets</code> module connects directly to the operating system's cryptographic random source (/dev/urandom on Linux/macOS or BCryptGenRandom on Windows), ensuring unpredictable, cryptographically strong randomness."
                  </p>
                </div>

                <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-1.5">
                  <p className="font-semibold text-emerald-300">
                    Q: "How do you guarantee that every selected checkbox character type appears in the final password?"
                  </p>
                  <p className="text-zinc-300 leading-relaxed">
                    <strong>A:</strong> "Before picking random characters from the combined pool, our function loops over each selected type and picks exactly one character from each respective pool using <code className="text-emerald-300">secrets.choice()</code>. Then, it fills the remaining slots from the combined pool and shuffles all characters using <code className="text-emerald-300">secrets.SystemRandom().shuffle()</code> so their positions are completely scrambled."
                  </p>
                </div>

                <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-1.5">
                  <p className="font-semibold text-emerald-300">
                    Q: "What are ambiguous characters and why provide an option to exclude them?"
                  </p>
                  <p className="text-zinc-300 leading-relaxed">
                    <strong>A:</strong> "Ambiguous characters like digit zero (0) and uppercase O, or digit one (1) and lowercase L (l) look almost indistinguishable in many system fonts. Excluding them helps users avoid transcription errors when reading or typing passwords manually."
                  </p>
                </div>

                <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-1.5">
                  <p className="font-semibold text-emerald-300">
                    Q: "How did you test your password generator?"
                  </p>
                  <p className="text-zinc-300 leading-relaxed">
                    <strong>A:</strong> "We wrote 13 automated unit tests using Python's standard <code className="text-emerald-300">unittest</code> framework in <code className="text-zinc-300">test_password_generator.py</code>. We tested length boundary limits (8 to 128), minimum character types enforcement, inclusion guarantees, ambiguous character exclusion, and repeated generation without memory leaks."
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Persistent Footer */}
      <footer className="border-t border-zinc-800 bg-zinc-900/60 px-4 lg:px-8 py-4 text-xs text-zinc-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <p>
          SecurePass • OIBSIP Python Programming Task 3 • Built for Oasis Infobyte SIP
        </p>
        <p className="font-mono text-[11px] text-zinc-400">
          Folder: OIBSIP/PythonProgramming/Task3_Random_Password_Generator/
        </p>
      </footer>
    </div>
  );
}
