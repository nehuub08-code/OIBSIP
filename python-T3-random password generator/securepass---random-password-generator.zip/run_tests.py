"""Quick test runner for SecurePass unit tests."""
import sys
import unittest

if __name__ == "__main__":
    loader = unittest.TestLoader()
    suite = loader.discover("OIBSIP/PythonProgramming/Task3_Random_Password_Generator/tests")
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(not result.wasSuccessful())
