# SecurePass — Random Password Generator

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![OIBSIP Task 3](https://img.shields.io/badge/OIBSIP-Task%203%20Python-orange.svg)](https://oasisinfobyte.com/)

**SecurePass** is a secure, beginner-friendly desktop application built for **Oasis Infobyte Summer Internship Program (OIBSIP) — Python Programming (Task 3)**.

Designed with clean software engineering principles, SecurePass generates cryptographically secure passwords strictly in volatile memory using Python's native `secrets` module, guarantees representation across selected character categories, provides heuristic strength metrics, automatically syncs with your clipboard, and maintains a clean 5-item session history without ever writing sensitive data to disk.

---

## 📋 Table of Contents

1. [Project Overview & Task Details](#project-overview--task-details)
2. [Key Features Checklist](#key-features-checklist)
3. [Technology Stack](#technology-stack)
4. [Project Structure](#project-structure)
5. [Prerequisites & Installation](#prerequisites--installation)
6. [Running the Application](#running-the-application)
7. [Running Automated Tests](#running-automated-tests)
8. [Why `secrets` Over `random`?](#why-secrets-over-random)
9. [Ambiguous Character Exclusion](#ambiguous-character-exclusion)
10. [Password Strength Heuristic](#password-strength-heuristic)
11. [Security and Privacy Architecture](#security-and-privacy-architecture)
12. [Manual Testing & Evaluation Guide](#manual-testing--evaluation-guide)
13. [Limitations & Future Scope](#limitations--future-scope)
14. [Screenshots](#screenshots)
15. [Conclusion](#conclusion)

---

## 1. Project Overview & Task Details

- **Internship:** Oasis Infobyte SIP (OIBSIP)
- **Domain:** Python Programming
- **Task Number:** Task 3 — Random Password Generator
- **Student Profile:** Second-Year Computer Engineering Undergraduate
- **Goal:** Build an advanced, secure, and visually appealing password generator while retaining clean, easily explainable code.

---

## 2. Key Features Checklist

- [x] **Configurable Password Length:** Numeric spinbox and synced visual slider (8 to 128 characters, defaulting to 16). Rejects invalid lengths with clear user-facing messages.
- [x] **Character Diversity Enforcement:** Checkboxes for Uppercase (`A-Z`), Lowercase (`a-z`), Numbers (`0-9`), and Symbols (`!@#$%...`). Requires at least **two** character types.
- [x] **Guaranteed Representation:** Mathematically ensures that every selected character type appears at least once in the final output before random padding and shuffling.
- [x] **Ambiguous Character Filter:** Checkbox to remove visually confusing characters (`0`, `O`, `l`, `1`) to avoid typographic mistakes when transcribing.
- [x] **Cryptographic Shuffling:** Shuffled using `secrets.SystemRandom().shuffle()` to eliminate predictable token positions.
- [x] **Password Strength Meter:** Dynamic visual progress bar and text assessment (`Weak`, `Medium`, `Strong`) based on length and entropy diversity.
- [x] **Automatic & Manual Clipboard Copy:** Seamless copying via `pyperclip` with graceful native Tkinter clipboard fallback and notification banners.
- [x] **In-Memory Session History:** Displays the last 5 generated passwords (newest first). Never written to disk, database, or console logs.
- [x] **Session Clear:** One-click button to purge historical items from memory.
- [x] **Zero Telemetry / Absolute Privacy:** No analytics, no disk logging, and no network calls.

---

## 3. Technology Stack

| Component | Technology | Rationale |
| :--- | :--- | :--- |
| **Language** | Python 3.8+ | Standard modern Python with type annotations. |
| **Security Engine** | `secrets` module | Built-in CSPRNG accessing `/dev/urandom` or CryptGenRandom. |
| **Character Sets** | `string` module | Standardized ASCII letters, digits, and punctuation constants. |
| **GUI Framework** | `tkinter` & `tkinter.ttk` | Standard cross-platform desktop UI library with themed widgets. |
| **Clipboard Support**| `pyperclip` | Reliable system clipboard integration. |
| **Testing** | `unittest` | Python standard testing framework for regression testing. |

---

## 4. Project Structure

```text
OIBSIP/PythonProgramming/Task3_Random_Password_Generator/
├── .gitignore                      # Ignores __pycache__, .venv, and temporary files
├── requirements.txt                # Lists external dependencies (pyperclip)
├── README.md                       # Comprehensive documentation and guide
├── password_generator.py           # Core cryptographic logic, validation & strength
├── main.py                         # Tkinter desktop GUI and CLI fallback
└── tests/
    └── test_password_generator.py  # 13 comprehensive unit tests
```

---

## 5. Prerequisites & Installation

### Step 1: Clone or Navigate to the Folder

```bash
cd OIBSIP/PythonProgramming/Task3_Random_Password_Generator
```

### Step 2: Create a Virtual Environment

```bash
python -m venv .venv
```

### Step 3: Activate the Virtual Environment

- **On Windows (Command Prompt):**
  ```cmd
  .venv\Scripts\activate.bat
  ```
- **On Windows (PowerShell):**
  ```powershell
  .venv\Scripts\Activate.ps1
  ```
- **On macOS / Linux:**
  ```bash
  source .venv/bin/activate
  ```

### Step 4: Install Dependencies

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

---

## 6. Running the Application

Launch the desktop graphical user interface:

```bash
python main.py
```

*Note:* If running in a headless Linux environment or server without an X display, SecurePass automatically falls back to an interactive command-line mode or you can explicitly trigger it via:

```bash
python main.py --cli
```

---

## 7. Running Automated Tests

Run all 13 automated unit tests with high verbosity:

```bash
python -m unittest discover -s tests -v
```

### Expected Output:

```text
test_01_exact_requested_length (test_password_generator.TestPasswordGenerator) ... ok
test_02_minimum_length_enforced (test_password_generator.TestPasswordGenerator) ... ok
test_03_maximum_length_enforced (test_password_generator.TestPasswordGenerator) ... ok
test_04_at_least_two_character_types_required (test_password_generator.TestPasswordGenerator) ... ok
test_05_uppercase_inclusion (test_password_generator.TestPasswordGenerator) ... ok
test_06_lowercase_inclusion (test_password_generator.TestPasswordGenerator) ... ok
test_07_numbers_inclusion (test_password_generator.TestPasswordGenerator) ... ok
test_08_symbols_inclusion (test_password_generator.TestPasswordGenerator) ... ok
test_09_every_selected_type_appears_at_least_once (test_password_generator.TestPasswordGenerator) ... ok
test_10_ambiguous_characters_excluded (test_password_generator.TestPasswordGenerator) ... ok
test_11_invalid_character_types_rejected (test_password_generator.TestPasswordGenerator) ... ok
test_12_repeated_generation_without_restart (test_password_generator.TestPasswordGenerator) ... ok
test_13_strength_heuristic_calculation (test_password_generator.TestPasswordGenerator) ... ok

----------------------------------------------------------------------
Ran 13 tests in 0.028s

OK
```

---

## 8. Why `secrets` Over `random`?

In Python, the `random` module relies on the **Mersenne Twister algorithm (MT19937)**:
- It is a **pseudo-random number generator (PRNG)** designed purely for statistical simulations, modeling, and games.
- Its internal state consists of only 624 32-bit integers.
- By observing just 624 generated outputs, an attacker can completely reverse-engineer the internal state and predict every future and past number generated!
- **Verdict:** `random` is completely unsafe for cryptography, tokens, and passwords.

In contrast, Python's `secrets` module:
- Uses the operating system's kernel-level **Cryptographically Secure Pseudo-Random Number Generator (CSPRNG)** (`/dev/urandom` on Unix-like OS, `BCryptGenRandom` on Windows).
- Draws physical hardware noise and entropy from device drivers, interrupts, and disk activity.
- Resists cryptanalytic attacks, making password prediction computationally infeasible.

---

## 9. Ambiguous Character Exclusion

Certain characters look almost identical in standard sans-serif system fonts:
- `0` (Digit Zero) vs `O` (Uppercase Letter O)
- `1` (Digit One) vs `l` (Lowercase Letter L) / `I` (Uppercase I)

When the **"Exclude ambiguous characters"** checkbox is enabled, SecurePass strips `0`, `O`, `l`, and `1` from all candidate character sets. This prevents transcription errors when human users manually type credentials into secondary devices or physical forms.

---

## 10. Password Strength Heuristic

SecurePass employs a transparent heuristic to educate users about password robustness:

| Rating | Conditions | Visual Meter | Recommendation |
| :--- | :--- | :--- | :--- |
| **Weak** | Length < 10 or only 2 categories | 33% (Red/Amber) | Increase length to 12+ and add more character types. |
| **Medium** | Length 10–13 with 2+ types, or 8+ with 4 types | 66% (Yellow/Blue) | Good for non-critical accounts. Consider 14+ for banking. |
| **Strong** | Length ≥ 14 with 3+ types, or ≥ 16 with 2+ types | 100% (Green) | Outstanding complexity and resistance against brute-force attacks. |

*Disclaimer:* This metric is an approximate educational heuristic based on character length and category diversity, not a guarantee of mathematical uncrackability. Real-world security also depends on dictionary word avoidance and breach exposure.

---

## 11. Security and Privacy Architecture

1. **Volatile Memory Only:** Passwords reside strictly inside Python's runtime variables. They are never written to `.txt`, `.json`, `.db`, or terminal logs.
2. **Session History Capped at 5:** Only the 5 most recent passwords in the active run are retained. When a 6th is generated, the oldest entry is dropped from RAM.
3. **Purge on Exit:** Closing the window immediately deallocates the process memory and eliminates all history.
4. **Clipboard Notice:** When copied, passwords enter the OS system clipboard. The user is reminded that third-party clipboard utilities can observe clipboard data.

---

## 12. Manual Testing & Evaluation Guide

Use this checklist during internship evaluation or presentation:

1. **Verify Default State:**
   - Launch `python main.py`.
   - Length defaults to `16`.
   - All 4 checkboxes are selected.
   - Ambiguous exclusion is unchecked.
2. **Boundary Validation:**
   - Set length to `5` and click *Generate Password*.
   - Confirm a friendly validation error is displayed: *"Password length must be at least 8 characters"*.
3. **Character Type Rule:**
   - Deselect all checkboxes except *Uppercase*.
   - Click *Generate Password*.
   - Confirm error: *"At least 2 character types must be selected"*.
4. **Ambiguous Character Test:**
   - Select *Numbers* and *Uppercase*.
   - Check *Exclude ambiguous characters*.
   - Generate length `64` password.
   - Search the output: neither `0`, `O`, `l`, nor `1` will be present.
5. **Session History:**
   - Generate 6 passwords in a row.
   - Verify the history box only retains 5 items (oldest dropped).
   - Click *Clear History* and ensure the list is wiped.
6. **Clipboard Operation:**
   - Generate a password, open a text editor (Notepad), and press `Ctrl+V`.
   - Verify the generated password pastes correctly.

---

## 13. Limitations & Future Scope

- **Pronounceable Mode:** Future versions could integrate diceware wordlists (EFF passphrases) for easier verbal recall.
- **Auto-Clear Clipboard:** Implement a background timer that clears the OS clipboard after 45 seconds.
- **Export Encrypted Vault:** Option to export generated passwords into an AES-256 encrypted file.

---

## 14. Screenshots

*(Place application screenshots in this section for your GitHub repository submission)*

```text
+-------------------------------------------------------------+
| SecurePass — Random Password Generator                      |
| OIBSIP Task 3 • Cryptographically secure passwords          |
+-------------------------------------------------------------+
| Generated Password: [ k9$Xw#8pM2!vR7@q                     ] |
| Strength: [████████████████████████] Strong (100%)          |
+-------------------------------------------------------------+
| Configuration & Rules:                                      |
| Length: [ 16 ] <------o------------>                        |
| [X] Uppercase (A-Z)       [X] Lowercase (a-z)               |
| [X] Numbers (0-9)         [X] Symbols (!@#$...)             |
| [X] Exclude ambiguous characters (0, O, l, 1)               |
+-------------------------------------------------------------+
| [⚡ Generate Secure Password]                               |
| Status: Generated! Automatically copied to clipboard.       |
+-------------------------------------------------------------+
| Session History — Not Saved (In-Memory Only, Max 5)         |
| 1. k9$Xw#8pM2!vR7@q                        [Copy]           |
| 2. P4#yZ9@wL1$bQ7!m                        [Copy]           |
|                                            [Clear History]  |
+-------------------------------------------------------------+
```

---

## 15. Conclusion

SecurePass successfully fulfills all criteria for **OIBSIP Task 3: Random Password Generator**. By combining Python's cryptographic `secrets` module, rigorous validation, clear modular architecture, and a modern Tkinter GUI, it provides a dependable tool for secure credential generation.
