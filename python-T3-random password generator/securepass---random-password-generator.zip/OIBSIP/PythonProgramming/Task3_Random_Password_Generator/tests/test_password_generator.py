"""Automated Unit Tests for SecurePass Password Generator.

OIBSIP Python Programming Internship - Task 3: Random Password Generator.

Test cases cover:
 1. Exact length matching
 2. Minimum length boundary enforcement (< 8)
 3. Maximum length boundary enforcement (> 128)
 4. Minimum character types requirement (>= 2)
 5. Uppercase character inclusion
 6. Lowercase character inclusion
 7. Numbers inclusion
 8. Symbols inclusion
 9. Guarantee that every selected type appears at least once
10. Ambiguous characters exclusion ('0', 'O', 'l', '1')
11. Safe handling of invalid types and pools
12. Multiple repeated generations without program restart
13. Strength calculation heuristic behavior
"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

# Add project root to sys.path so tests can be run from any working directory
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from password_generator import (  # noqa: E402
    AMBIGUOUS_CHARS,
    DIGIT_CHARS,
    LOWERCASE_CHARS,
    MAX_PASSWORD_LENGTH,
    MIN_PASSWORD_LENGTH,
    SYMBOL_CHARS,
    UPPERCASE_CHARS,
    PasswordGenerationError,
    calculate_password_strength,
    generate_password,
    get_character_pool,
    validate_generation_parameters,
)


class TestPasswordGenerator(unittest.TestCase):
    """Test suite for the password generation and validation functions."""

    def test_01_exact_requested_length(self):
        """Test that generated passwords strictly match the requested lengths."""
        test_lengths = [8, 12, 16, 24, 64, 128]
        for length in test_lengths:
            pwd = generate_password(length=length)
            self.assertEqual(
                len(pwd),
                length,
                f"Expected password of length {length}, got {len(pwd)}.",
            )

    def test_02_minimum_length_enforced(self):
        """Test that lengths below MIN_PASSWORD_LENGTH (8) raise PasswordGenerationError."""
        for invalid_len in [0, -5, 1, 7]:
            with self.assertRaises(PasswordGenerationError):
                generate_password(length=invalid_len)

    def test_03_maximum_length_enforced(self):
        """Test that lengths above MAX_PASSWORD_LENGTH (128) raise PasswordGenerationError."""
        for invalid_len in [129, 200, 500]:
            with self.assertRaises(PasswordGenerationError):
                generate_password(length=invalid_len)

    def test_04_at_least_two_character_types_required(self):
        """Test that selecting 0 or only 1 character type raises PasswordGenerationError."""
        # 0 types
        with self.assertRaises(PasswordGenerationError):
            generate_password(length=16, selected_types=[])

        # 1 type only
        for single in ["uppercase", "lowercase", "numbers", "symbols"]:
            with self.assertRaises(PasswordGenerationError):
                generate_password(length=16, selected_types=[single])

    def test_05_uppercase_inclusion(self):
        """Test that uppercase characters appear when uppercase is in selected types."""
        for _ in range(10):
            pwd = generate_password(
                length=16,
                selected_types=["uppercase", "lowercase"],
            )
            has_upper = any(c in UPPERCASE_CHARS for c in pwd)
            self.assertTrue(has_upper, "Expected uppercase characters in generated password.")

    def test_06_lowercase_inclusion(self):
        """Test that lowercase characters appear when lowercase is in selected types."""
        for _ in range(10):
            pwd = generate_password(
                length=16,
                selected_types=["lowercase", "numbers"],
            )
            has_lower = any(c in LOWERCASE_CHARS for c in pwd)
            self.assertTrue(has_lower, "Expected lowercase characters in generated password.")

    def test_07_numbers_inclusion(self):
        """Test that digits appear when numbers are in selected types."""
        for _ in range(10):
            pwd = generate_password(
                length=16,
                selected_types=["numbers", "symbols"],
            )
            has_digit = any(c in DIGIT_CHARS for c in pwd)
            self.assertTrue(has_digit, "Expected digits in generated password.")

    def test_08_symbols_inclusion(self):
        """Test that symbols appear when symbols are in selected types."""
        for _ in range(10):
            pwd = generate_password(
                length=16,
                selected_types=["uppercase", "symbols"],
            )
            has_symbol = any(c in SYMBOL_CHARS for c in pwd)
            self.assertTrue(has_symbol, "Expected symbols in generated password.")

    def test_09_every_selected_type_appears_at_least_once(self):
        """Test that EVERY selected type is represented at least once in each generated password."""
        all_types = ["uppercase", "lowercase", "numbers", "symbols"]
        for _ in range(25):
            pwd = generate_password(length=8, selected_types=all_types)
            self.assertTrue(any(c in UPPERCASE_CHARS for c in pwd), "Missing uppercase.")
            self.assertTrue(any(c in LOWERCASE_CHARS for c in pwd), "Missing lowercase.")
            self.assertTrue(any(c in DIGIT_CHARS for c in pwd), "Missing digits.")
            self.assertTrue(any(c in SYMBOL_CHARS for c in pwd), "Missing symbols.")

    def test_10_ambiguous_characters_excluded(self):
        """Test that '0', 'O', 'l', '1' are strictly excluded when exclude_ambiguous=True."""
        for _ in range(30):
            pwd = generate_password(
                length=32,
                selected_types=["uppercase", "lowercase", "numbers"],
                exclude_ambiguous=True,
            )
            for amb in AMBIGUOUS_CHARS:
                self.assertNotIn(
                    amb,
                    pwd,
                    f"Ambiguous character '{amb}' found in password when exclusion was active.",
                )

    def test_11_invalid_character_types_rejected(self):
        """Test that unrecognized character type keys raise PasswordGenerationError."""
        with self.assertRaises(PasswordGenerationError):
            generate_password(
                length=16,
                selected_types=["uppercase", "emojis"],  # 'emojis' is invalid
            )

    def test_12_repeated_generation_without_restart(self):
        """Test that calling generate_password repeatedly works seamlessly."""
        passwords = [generate_password(length=16) for _ in range(50)]
        self.assertEqual(len(passwords), 50)
        for pwd in passwords:
            self.assertEqual(len(pwd), 16)

    def test_13_strength_heuristic_calculation(self):
        """Test that strength heuristic assigns Weak, Medium, and Strong appropriately."""
        # Weak: short
        res_weak = calculate_password_strength("Ab1#")
        self.assertEqual(res_weak["label"], "Weak")

        # Medium: 10 chars with 2-3 types
        res_med = calculate_password_strength("Abcdefgh12")
        self.assertIn(res_med["label"], ["Medium", "Strong"])

        # Strong: 16 chars with all 4 types
        res_strong = calculate_password_strength("Abc123$!XyZ890@#")
        self.assertEqual(res_strong["label"], "Strong")
        self.assertEqual(res_strong["percentage"], 100)


if __name__ == "__main__":
    unittest.main(verbosity=2)
