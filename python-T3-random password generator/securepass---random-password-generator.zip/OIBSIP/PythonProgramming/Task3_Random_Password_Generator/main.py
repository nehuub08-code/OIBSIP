"""SecurePass - Desktop GUI Application.

OIBSIP Python Programming Internship - Task 3: Random Password Generator.
Author: Computer Engineering Student
Track: OIBSIP Python Programming

Features:
  - Tkinter + ttk modern desktop user interface
  - Cryptographically secure generation via `secrets` module
  - Configurable length (8 to 128 chars, default 16)
  - Character type checkboxes with minimum 2 requirement validation
  - Ambiguous character exclusion ('0', 'O', 'l', '1')
  - Automatic and manual clipboard copy via `pyperclip` (with Tkinter fallback)
  - Password strength meter (Weak, Medium, Strong)
  - In-memory session history of last 5 passwords (newest first)
  - Privacy safeguards: in-memory only, no disk writes, no telemetry
"""

from __future__ import annotations

import sys
from typing import List

# Import our secure password generation module
from password_generator import (
    DEFAULT_PASSWORD_LENGTH,
    MAX_PASSWORD_LENGTH,
    MIN_PASSWORD_LENGTH,
    PasswordGenerationError,
    calculate_password_strength,
    generate_password,
)

# Optional clipboard module pyperclip with graceful fallback to Tkinter's internal clipboard
try:
    import pyperclip  # type: ignore

    HAS_PYPERCLIP = True
except ImportError:
    HAS_PYPERCLIP = False


# Maximum number of passwords kept in volatile session memory
MAX_HISTORY_ENTRIES = 5


def copy_text_to_clipboard(text: str, root_widget=None) -> tuple[bool, str]:
    """Copy text to system clipboard using pyperclip or Tkinter fallback.

    Args:
        text: The string to copy.
        root_widget: Tk widget used as fallback if pyperclip is unavailable.

    Returns:
        tuple (success: bool, message: str)
    """
    if not text:
        return False, "No password to copy."

    # First attempt: pyperclip
    if HAS_PYPERCLIP:
        try:
            pyperclip.copy(text)
            return True, "Copied to clipboard successfully!"
        except Exception as err:
            pass  # Fall through to Tkinter fallback

    # Second attempt: Tkinter native clipboard
    if root_widget is not None:
        try:
            root_widget.clipboard_clear()
            root_widget.clipboard_append(text)
            root_widget.update()  # Finalize clipboard contents
            return True, "Copied to clipboard (via Tkinter)!"
        except Exception as tk_err:
            return False, f"Clipboard error: {tk_err}"

    return False, "Clipboard unavailable. Please install 'pyperclip' with: pip install pyperclip"


def run_cli_interactive():
    """Command-line interface fallback if Tkinter or a desktop display is unavailable."""
    print("=" * 65)
    print("  SecurePass - Random Password Generator (OIBSIP Task 3)")
    print("  Cryptographically secure passwords generated locally in memory")
    print("=" * 65)

    history: List[str] = []

    while True:
        print("\n--- Main Menu ---")
        print("1. Generate New Password")
        print("2. View Session History (Last 5, in-memory only)")
        print("3. Clear Session History")
        print("4. Exit")

        choice = input("Select an option (1-4): ").strip()
        if choice == "1":
            # Length input
            try:
                length_raw = input(
                    f"Enter password length [{MIN_PASSWORD_LENGTH}-{MAX_PASSWORD_LENGTH}] (default {DEFAULT_PASSWORD_LENGTH}): "
                ).strip()
                length = int(length_raw) if length_raw else DEFAULT_PASSWORD_LENGTH
            except ValueError:
                print("Error: Length must be a valid integer.")
                continue

            # Types input
            print("\nSelect character types (at least 2):")
            inc_upper = input("  Include Uppercase [A-Z]? (y/n, default y): ").strip().lower() != "n"
            inc_lower = input("  Include Lowercase [a-z]? (y/n, default y): ").strip().lower() != "n"
            inc_nums = input("  Include Numbers [0-9]? (y/n, default y): ").strip().lower() != "n"
            inc_syms = input("  Include Symbols [!@#$%...]? (y/n, default y): ").strip().lower() != "n"
            exc_ambig = input("  Exclude Ambiguous (0, O, l, 1)? (y/n, default n): ").strip().lower() == "y"

            selected = []
            if inc_upper:
                selected.append("uppercase")
            if inc_lower:
                selected.append("lowercase")
            if inc_nums:
                selected.append("numbers")
            if inc_syms:
                selected.append("symbols")

            try:
                password = generate_password(
                    length=length,
                    selected_types=selected,
                    exclude_ambiguous=exc_ambig,
                )
                strength = calculate_password_strength(password, len(selected))

                print("\n" + "=" * 50)
                print(f"Generated Password : {password}")
                print(f"Password Length    : {len(password)}")
                print(f"Strength Rating    : {strength['label']} ({strength['percentage']}%)")
                print(f"Strength Note      : {strength['feedback']}")
                print("=" * 50)

                # Attempt clipboard copy
                success, msg = copy_text_to_clipboard(password)
                print(f"Clipboard Status   : {msg}")

                # Update session history (newest first, max 5)
                history.insert(0, password)
                if len(history) > MAX_HISTORY_ENTRIES:
                    history.pop()

            except PasswordGenerationError as err:
                print(f"\n[Validation Error] {err}")

        elif choice == "2":
            print("\n--- Session History (Not Saved to Disk) ---")
            if not history:
                print("No passwords generated yet in this session.")
            else:
                for idx, pwd in enumerate(history, 1):
                    strength = calculate_password_strength(pwd)
                    print(f"  {idx}. {pwd}  [{strength['label']}, len={len(pwd)}]")
            print("Note: History is volatile and will disappear when the program exits.")

        elif choice == "3":
            history.clear()
            print("Session history cleared from memory.")

        elif choice == "4":
            print("\nThank you for using SecurePass! Stay secure.")
            break
        else:
            print("Invalid option. Please enter 1, 2, 3, or 4.")


def run_gui():
    """Launch the Tkinter desktop GUI for SecurePass."""
    try:
        import tkinter as tk
        from tkinter import messagebox, ttk
    except ImportError as err:
        print(f"[Notice] Tkinter is not installed on this system: {err}")
        print("Falling back to interactive terminal mode...\n")
        run_cli_interactive()
        return

    try:
        root = tk.Tk()
    except Exception as err:
        print(f"[Notice] Unable to initialize GUI display ({err}).")
        print("Running in interactive terminal mode instead...\n")
        run_cli_interactive()
        return

    root.title("SecurePass — Random Password Generator")
    root.geometry("620x740")
    root.minsize(540, 680)

    # Clean ttk styling
    style = ttk.Style(root)
    available_themes = style.theme_names()
    if "clam" in available_themes:
        style.theme_use("clam")

    # State variables
    length_var = tk.IntVar(value=DEFAULT_PASSWORD_LENGTH)
    upper_var = tk.BooleanVar(value=True)
    lower_var = tk.BooleanVar(value=True)
    numbers_var = tk.BooleanVar(value=True)
    symbols_var = tk.BooleanVar(value=True)
    ambiguous_var = tk.BooleanVar(value=False)
    show_password_var = tk.BooleanVar(value=True)

    current_password_var = tk.StringVar(value="")
    status_msg_var = tk.StringVar(value="Configure settings and click 'Generate Password'.")
    strength_label_var = tk.StringVar(value="Strength: Not Evaluated")
    strength_pct_var = tk.DoubleVar(value=0)

    # In-memory history list (stores up to 5 entries)
    session_history: List[str] = []

    # Container Frame
    main_frame = ttk.Frame(root, padding="16 16 16 16")
    main_frame.pack(fill=tk.BOTH, expand=True)

    # 1. Header Section
    header_frame = ttk.Frame(main_frame)
    header_frame.pack(fill=tk.X, pady=(0, 12))

    title_label = ttk.Label(
        header_frame,
        text="SecurePass",
        font=("Helvetica", 20, "bold"),
    )
    title_label.pack(anchor=tk.W)

    subtitle_label = ttk.Label(
        header_frame,
        text="OIBSIP Task 3 • Cryptographically secure random passwords generated locally in memory.",
        font=("Helvetica", 9),
    )
    subtitle_label.pack(anchor=tk.W, pady=(2, 0))

    # 2. Output Box Section
    output_card = ttk.LabelFrame(main_frame, text=" Generated Password ", padding="12")
    output_card.pack(fill=tk.X, pady=(0, 12))

    entry_frame = ttk.Frame(output_card)
    entry_frame.pack(fill=tk.X)

    password_entry = ttk.Entry(
        entry_frame,
        textvariable=current_password_var,
        font=("Consolas", 14, "bold"),
        justify="center",
    )
    password_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))

    def toggle_password_visibility():
        if show_password_var.get():
            password_entry.config(show="")
        else:
            password_entry.config(show="*")

    visibility_btn = ttk.Checkbutton(
        entry_frame,
        text="Show",
        variable=show_password_var,
        command=toggle_password_visibility,
    )
    visibility_btn.pack(side=tk.LEFT, padx=(0, 8))

    def on_copy_click():
        pwd = current_password_var.get()
        if not pwd:
            status_msg_var.set("Warning: No password has been generated yet.")
            return
        success, msg = copy_text_to_clipboard(pwd, root)
        status_msg_var.set(msg)
        if not success:
            messagebox.showwarning("Clipboard Notice", msg)

    copy_btn = ttk.Button(entry_frame, text="Copy", command=on_copy_click)
    copy_btn.pack(side=tk.RIGHT)

    # Strength Progress Bar & Label
    strength_frame = ttk.Frame(output_card)
    strength_frame.pack(fill=tk.X, pady=(10, 0))

    strength_bar = ttk.Progressbar(
        strength_frame,
        variable=strength_pct_var,
        maximum=100,
        length=200,
    )
    strength_bar.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))

    strength_display = ttk.Label(
        strength_frame,
        textvariable=strength_label_var,
        font=("Helvetica", 9, "bold"),
    )
    strength_display.pack(side=tk.RIGHT)

    # 3. Settings Section
    settings_card = ttk.LabelFrame(main_frame, text=" Configuration & Rules ", padding="12")
    settings_card.pack(fill=tk.X, pady=(0, 12))

    # Length row
    length_row = ttk.Frame(settings_card)
    length_row.pack(fill=tk.X, pady=(0, 8))

    ttk.Label(
        length_row,
        text=f"Password Length ({MIN_PASSWORD_LENGTH} - {MAX_PASSWORD_LENGTH}):",
        font=("Helvetica", 9, "bold"),
    ).pack(side=tk.LEFT)

    length_display_label = ttk.Label(
        length_row,
        text=str(DEFAULT_PASSWORD_LENGTH),
        font=("Helvetica", 10, "bold"),
    )
    length_display_label.pack(side=tk.RIGHT)

    # Slider + Spinbox synced
    slider_frame = ttk.Frame(settings_card)
    slider_frame.pack(fill=tk.X, pady=(0, 10))

    def on_length_changed(*args):
        val = length_var.get()
        length_display_label.config(text=str(val))

    length_var.trace_add("write", on_length_changed)

    slider = ttk.Scale(
        slider_frame,
        from_=MIN_PASSWORD_LENGTH,
        to=MAX_PASSWORD_LENGTH,
        orient=tk.HORIZONTAL,
        variable=length_var,
    )
    slider.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))

    spinbox = ttk.Spinbox(
        slider_frame,
        from_=MIN_PASSWORD_LENGTH,
        to=MAX_PASSWORD_LENGTH,
        textvariable=length_var,
        width=5,
    )
    spinbox.pack(side=tk.RIGHT)

    # Character Types Checkboxes
    types_label = ttk.Label(
        settings_card,
        text="Character Types (At least 2 required):",
        font=("Helvetica", 9, "bold"),
    )
    types_label.pack(anchor=tk.W, pady=(4, 4))

    types_grid = ttk.Frame(settings_card)
    types_grid.pack(fill=tk.X, pady=(0, 6))

    ttk.Checkbutton(
        types_grid,
        text="Uppercase (A–Z)",
        variable=upper_var,
    ).grid(row=0, column=0, sticky=tk.W, padx=(0, 16), pady=2)

    ttk.Checkbutton(
        types_grid,
        text="Lowercase (a–z)",
        variable=lower_var,
    ).grid(row=0, column=1, sticky=tk.W, pady=2)

    ttk.Checkbutton(
        types_grid,
        text="Numbers (0–9)",
        variable=numbers_var,
    ).grid(row=1, column=0, sticky=tk.W, padx=(0, 16), pady=2)

    ttk.Checkbutton(
        types_grid,
        text="Symbols (!@#$...)",
        variable=symbols_var,
    ).grid(row=1, column=1, sticky=tk.W, pady=2)

    # Ambiguous Exclude Option
    ttk.Separator(settings_card, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=8)

    ttk.Checkbutton(
        settings_card,
        text="Exclude ambiguous characters (0, O, l, 1)",
        variable=ambiguous_var,
    ).pack(anchor=tk.W)

    # 4. Generate Action Button
    def update_history_ui():
        # Clear existing list items in history frame
        for widget in history_items_frame.winfo_children():
            widget.destroy()

        if not session_history:
            ttk.Label(
                history_items_frame,
                text="No passwords generated yet in this session.",
                font=("Helvetica", 9, "italic"),
                foreground="gray",
            ).pack(anchor=tk.W, pady=4)
            return

        for idx, entry in enumerate(session_history, 1):
            row = ttk.Frame(history_items_frame)
            row.pack(fill=tk.X, pady=2)

            # Monospace text display (truncated for safety)
            display_text = entry if len(entry) <= 28 else entry[:25] + "..."
            ttk.Label(
                row,
                text=f"{idx}. {display_text}",
                font=("Consolas", 9),
            ).pack(side=tk.LEFT)

            # Copy button for individual history row
            def make_copy_callback(text_to_copy: str):
                return lambda: (
                    copy_text_to_clipboard(text_to_copy, root),
                    status_msg_var.set("Copied historical password to clipboard!"),
                )

            ttk.Button(
                row,
                text="Copy",
                width=5,
                command=make_copy_callback(entry),
            ).pack(side=tk.RIGHT)

    def on_generate():
        try:
            length = length_var.get()
        except tk.TclError:
            messagebox.showerror("Invalid Input", "Password length must be a valid number.")
            status_msg_var.set("Error: Invalid length input.")
            return

        selected_types: List[str] = []
        if upper_var.get():
            selected_types.append("uppercase")
        if lower_var.get():
            selected_types.append("lowercase")
        if numbers_var.get():
            selected_types.append("numbers")
        if symbols_var.get():
            selected_types.append("symbols")

        try:
            password = generate_password(
                length=length,
                selected_types=selected_types,
                exclude_ambiguous=ambiguous_var.get(),
            )
        except PasswordGenerationError as err:
            messagebox.showerror("Validation Error", str(err))
            status_msg_var.set(f"Validation error: {err}")
            return
        except Exception as err:
            messagebox.showerror("Generation Error", f"An unexpected error occurred: {err}")
            status_msg_var.set("Error generating password.")
            return

        # Update current output
        current_password_var.set(password)

        # Update strength rating
        strength_info = calculate_password_strength(password, len(selected_types))
        strength_pct_var.set(strength_info["percentage"])
        strength_label_var.set(f"Strength: {strength_info['label']}")

        # Automatic clipboard copy attempt
        copied, msg = copy_text_to_clipboard(password, root)
        if copied:
            status_msg_var.set("Generated! Password automatically copied to clipboard.")
        else:
            status_msg_var.set("Generated! (Clipboard auto-copy failed, click Copy manually).")

        # Update in-memory session history (newest first, max 5 entries)
        session_history.insert(0, password)
        if len(session_history) > MAX_HISTORY_ENTRIES:
            session_history.pop()

        update_history_ui()

    generate_btn = ttk.Button(
        main_frame,
        text="⚡ Generate Secure Password",
        command=on_generate,
    )
    generate_btn.pack(fill=tk.X, ipady=4, pady=(0, 10))

    # Status Bar Label
    status_label = ttk.Label(
        main_frame,
        textvariable=status_msg_var,
        font=("Helvetica", 9),
        foreground="#15803d",
        anchor=tk.W,
    )
    status_label.pack(fill=tk.X, pady=(0, 10))

    # 5. Session History Section (In-Memory Only)
    history_card = ttk.LabelFrame(
        main_frame,
        text=" Session History — Not Saved (In-Memory Only, Max 5) ",
        padding="10",
    )
    history_card.pack(fill=tk.BOTH, expand=True, pady=(0, 8))

    history_items_frame = ttk.Frame(history_card)
    history_items_frame.pack(fill=tk.BOTH, expand=True)

    def on_clear_history():
        session_history.clear()
        update_history_ui()
        status_msg_var.set("Session history cleared from memory.")

    clear_history_btn = ttk.Button(
        history_card,
        text="Clear History",
        command=on_clear_history,
    )
    clear_history_btn.pack(anchor=tk.E, pady=(4, 0))

    # Initial history render
    update_history_ui()

    # 6. Privacy & Safety Note
    privacy_label = ttk.Label(
        main_frame,
        text="🔒 Privacy Guarantee: Passwords exist solely in temporary RAM and vanish upon exit.",
        font=("Helvetica", 8, "italic"),
        foreground="#475569",
    )
    privacy_label.pack(side=tk.BOTTOM, pady=(4, 0))

    # Run the GUI event loop
    root.mainloop()


if __name__ == "__main__":
    # If explicitly requested with --cli, run CLI mode
    if len(sys.argv) > 1 and sys.argv[1] in ("--cli", "-c"):
        run_cli_interactive()
    else:
        run_gui()
