"""SecurePass - Password Generation and Validation Module.

OIBSIP Python Programming Internship - Task 3: Random Password Generator.
Author: Computer Engineering Student
Track: OIBSIP Python Programming

This module provides cryptographically secure password generation logic using
Python's built-in `secrets` module (based on os.urandom / system CSPRNG).
It enforces length limits, character type minimums, diversity guarantees,
ambiguous character exclusions, and calculates approximate strength scores.
"""

from __future__ import annotations

import secrets
import string
from typing import Dict, List, Set

# Character pool definitions using the standard library `string` module
UPPERCASE_CHARS: str = string.ascii_uppercase
LOWERCASE_CHARS: str = string.ascii_lowercase
DIGIT_CHARS: str = string.digits
# Clean standard punctuation characters for passwords
SYMBOL_CHARS: str = "!@#$%^&*()-_=+[]{}|;:,.<>?/"

# Characters commonly confused in print or displays
AMBIGUOUS_CHARS: Set[str] = {"0", "O", "l", "1"}

# Configuration limits
MIN_PASSWORD_LENGTH: int = 8
MAX_PASSWORD_LENGTH: int = 128
DEFAULT_PASSWORD_LENGTH: int = 16
MIN_SELECTED_TYPES: int = 2

# Recognized character type keys
VALID_TYPES: tuple[str, ...] = ("uppercase", "lowercase", "numbers", "symbols")


class PasswordGenerationError(ValueError):
    """Raised when password generation arguments violate security or input constraints."""
    pass


def get_character_pool(character_type: str, exclude_ambiguous: bool = False) -> str:
    """Return the available characters for a given category.

    Args:
        character_type: One of 'uppercase', 'lowercase', 'numbers', 'symbols'.
        exclude_ambiguous: If True, filters out ambiguous characters ('0', 'O', 'l', '1').

    Returns:
        A string containing available characters for that type.

    Raises:
        PasswordGenerationError: If character_type is unknown or filtered pool is empty.
    """
    mapping = {
        "uppercase": UPPERCASE_CHARS,
        "lowercase": LOWERCASE_CHARS,
        "numbers": DIGIT_CHARS,
        "symbols": SYMBOL_CHARS,
    }

    if character_type not in mapping:
        raise PasswordGenerationError(
            f"Unknown character type '{character_type}'. "
            f"Allowed types are: {', '.join(VALID_TYPES)}."
        )

    pool = mapping[character_type]
    if exclude_ambiguous:
        pool = "".join(ch for ch in pool if ch not in AMBIGUOUS_CHARS)

    if not pool:
        raise PasswordGenerationError(
            f"The character pool for '{character_type}' is empty after excluding ambiguous characters."
        )

    return pool


def validate_generation_parameters(
    length: int,
    selected_types: List[str] | Set[str],
    exclude_ambiguous: bool = False,
) -> None:
    """Validate requested password length and selected character types.

    Args:
        length: Desired length of password.
        selected_types: Collection of selected type keys.
        exclude_ambiguous: Whether ambiguous characters are filtered.

    Raises:
        PasswordGenerationError: If validation fails.
    """
    if not isinstance(length, int):
        raise PasswordGenerationError(
            f"Password length must be an integer, got {type(length).__name__}."
        )

    if length < MIN_PASSWORD_LENGTH:
        raise PasswordGenerationError(
            f"Password length must be at least {MIN_PASSWORD_LENGTH} characters. "
            f"(Requested: {length})"
        )

    if length > MAX_PASSWORD_LENGTH:
        raise PasswordGenerationError(
            f"Password length cannot exceed {MAX_PASSWORD_LENGTH} characters. "
            f"(Requested: {length})"
        )

    if not selected_types:
        raise PasswordGenerationError(
            "No character types selected. Please select at least two character types "
            "(e.g., Uppercase, Lowercase, Numbers, Symbols)."
        )

    unique_types = set(selected_types)
    invalid_types = unique_types - set(VALID_TYPES)
    if invalid_types:
        raise PasswordGenerationError(
            f"Unrecognized character type(s): {', '.join(sorted(invalid_types))}. "
            f"Valid options are: {', '.join(VALID_TYPES)}."
        )

    if len(unique_types) < MIN_SELECTED_TYPES:
        raise PasswordGenerationError(
            f"At least {MIN_SELECTED_TYPES} character types must be selected for adequate security. "
            f"Currently selected: {len(unique_types)}."
        )

    # Ensure none of the selected pools become empty
    for type_name in unique_types:
        get_character_pool(type_name, exclude_ambiguous=exclude_ambiguous)


def generate_password(
    length: int = DEFAULT_PASSWORD_LENGTH,
    selected_types: List[str] | Set[str] | None = None,
    exclude_ambiguous: bool = False,
) -> str:
    """Generate a cryptographically secure random password.

    Steps:
      1. Validate input parameters (length >= 8, at least 2 types selected).
      2. Build filtered pools for each selected category.
      3. Securely select at least 1 character from each chosen category.
      4. Fill remaining slots from the combined pool using `secrets.choice()`.
      5. Securely shuffle all characters using `secrets.SystemRandom().shuffle()`.

    Args:
        length: Desired password length (8 to 128).
        selected_types: List/Set of types ('uppercase', 'lowercase', 'numbers', 'symbols').
        exclude_ambiguous: Whether to exclude '0', 'O', 'l', '1'.

    Returns:
        A securely generated password string.
    """
    if selected_types is None:
        selected_types = ["uppercase", "lowercase", "numbers", "symbols"]

    # Validate parameters
    validate_generation_parameters(length, selected_types, exclude_ambiguous)

    chosen_types = list(set(selected_types))
    # Sort for deterministic processing order before shuffling
    chosen_types.sort()

    pools: Dict[str, str] = {
        t: get_character_pool(t, exclude_ambiguous=exclude_ambiguous)
        for t in chosen_types
    }

    # Step 1: Guarantee at least one character from each selected type
    password_chars: List[str] = [
        secrets.choice(pools[t]) for t in chosen_types
    ]

    # Step 2: Combine selected pools to fill remaining slots
    combined_pool = "".join(pools[t] for t in chosen_types)

    remaining_count = length - len(password_chars)
    for _ in range(remaining_count):
        password_chars.append(secrets.choice(combined_pool))

    # Step 3: Securely shuffle using CSPRNG SystemRandom
    # Avoids predictable placements (e.g. first char always uppercase)
    crypto_random = secrets.SystemRandom()
    crypto_random.shuffle(password_chars)

    return "".join(password_chars)


def calculate_password_strength(
    password: str,
    selected_types_count: int | None = None,
) -> Dict[str, object]:
    """Calculate an approximate password strength score.

    NOTE: This is an approximate visual heuristic for user feedback and
    education, NOT a guarantee of absolute cryptographic resistance or
    real-world crack time calculation.

    Heuristic criteria:
      - Length (< 10: short, 10-13: moderate, 14+: strong)
      - Category diversity (uppercase, lowercase, numbers, symbols present)

    Returns:
        dict:
          - score: 1 (Weak), 2 (Medium), 3 (Strong)
          - label: "Weak" | "Medium" | "Strong"
          - percentage: 33, 66, or 100 for visual progress bars
          - feedback: Brief educational advice
    """
    if not password:
        return {
            "score": 0,
            "label": "None",
            "percentage": 0,
            "feedback": "Generate a password to see strength evaluation.",
        }

    length = len(password)
    has_upper = any(c in UPPERCASE_CHARS for c in password)
    has_lower = any(c in LOWERCASE_CHARS for c in password)
    has_digit = any(c in DIGIT_CHARS for c in password)
    has_symbol = any(c in SYMBOL_CHARS for c in password)

    categories_present = sum([has_upper, has_lower, has_digit, has_symbol])
    effective_categories = (
        max(categories_present, selected_types_count)
        if selected_types_count is not None
        else categories_present
    )

    # Heuristic scoring logic:
    # Strong: Length >= 14 with at least 3 categories, OR Length >= 16 with at least 2 categories
    if (length >= 14 and effective_categories >= 3) or (length >= 16 and effective_categories >= 2):
        return {
            "score": 3,
            "label": "Strong",
            "percentage": 100,
            "feedback": "Excellent length and character diversity. Well-suited for sensitive accounts.",
        }

    # Medium: Length >= 10 with at least 2 categories, or Length >= 8 with 4 categories
    if (length >= 10 and effective_categories >= 2) or (length >= 8 and effective_categories >= 4):
        return {
            "score": 2,
            "label": "Medium",
            "percentage": 66,
            "feedback": "Decent protection for everyday logins. Increase length to 14+ for high security.",
        }

    # Weak
    return {
        "score": 1,
        "label": "Weak",
        "percentage": 33,
        "feedback": "Short length or low diversity. Consider increasing length to at least 12.",
    }
