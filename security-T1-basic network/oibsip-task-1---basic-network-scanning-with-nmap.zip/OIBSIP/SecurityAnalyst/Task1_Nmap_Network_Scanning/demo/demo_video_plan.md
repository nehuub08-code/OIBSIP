# DEMO VIDEO WALKTHROUGH & PRESENTATION PLAN
## Oasis Infobyte (OIBSIP) — Security Analyst Internship Track
### Task 1: Basic Network Scanning with Nmap

---

**Video Title:** Oasis Infobyte Task 1 — Basic Network Scanning & Security Assessment with Nmap  
**Presenter:** Security Analyst Intern  
**Target Duration:** 3 to 5 Minutes  
**Video Status:** [PENDING USER RECORDING & SUBMISSION URL INSERTION]  
**Deliverable Placeholder:** `https://youtu.be/PENDING_VIDEO_ID` or Google Drive Link  

---

## 1. OBJECTIVE & PRESENTATION GOALS

This video demonstrates practical network reconnaissance skills, adherence to strict ethical authorization, command execution in a live terminal, interpretation of Nmap output, and professional translation of raw scan results into actionable defensive security recommendations.

---

## 2. TIMED SCRIPT & STORYBOARD (0:00 - 5:00)

### Segment 1: Introduction (0:00 – 0:30)
- **Visual:** Terminal screen showing the project banner and working directory (`OIBSIP/SecurityAnalyst/Task1_Nmap_Network_Scanning`).
- **Spoken Script:**
  > "Hello everyone! My name is [Your Name], and this is my presentation for Task 1 of the Oasis Infobyte Security Analyst Internship: Basic Network Scanning with Nmap.
  > In this project, we are performing ethical, non-destructive network reconnaissance against an isolated, authorized lab environment to discover open ports, identify running services, detect the underlying operating system, and assess the security implications of these findings."

### Segment 2: Lab Setup & Nmap Installation Verification (0:30 – 1:15)
- **Visual:** Terminal executing `nmap --version` and `ip addr` (or `ifconfig`).
- **Command Shown:**
  ```bash
  nmap --version
  which nmap
  ip addr
  ```
- **Spoken Script:**
  > "Before touching any network tools, ethical guidelines require that we verify our environment and ensure we have explicit permission.
  > Here, I have verified our Nmap installation, showing version 7.93 compiled with OpenSSL and Libpcap.
  > Our target is an isolated virtual machine hosted locally on our private host-only network, completely isolated from any public or third-party networks."

### Segment 3: Basic Scan & Service-Version Detection (1:15 – 2:15)
- **Visual:** Terminal running basic scan, then running `-sV` service version detection.
- **Commands Shown:**
  ```bash
  nmap 192.168.56.101
  nmap -sV 192.168.56.101
  ```
- **Spoken Script:**
  > "First, we run a basic TCP port scan using `nmap <target>`. Nmap probes the top 1,000 common TCP ports. Notice that ports 22, 80, 3000, and 8080 show up as 'open', while the other 996 ports are closed.
  > Next, we execute `nmap -sV`. The `-sV` flag performs service-version detection by sending specialized application probes and banner grabs.
  > Rather than guessing based on port numbers, Nmap now reveals the exact running software: OpenSSH 8.9p1 on port 22, Apache 2.4.52 on port 80, Node.js Express on port 3000, and Werkzeug Python on port 8080."

### Segment 4: Operating System Fingerprinting (2:15 – 3:00)
- **Visual:** Running `sudo nmap -O <target>` and reviewing fingerprint output.
- **Command Shown:**
  ```bash
  sudo nmap -O 192.168.56.101
  ```
- **Spoken Script:**
  > "Now, we run operating system fingerprinting using `sudo nmap -O`.
  > Because OS detection analyzes low-level TCP/IP stack implementation nuances—such as TCP initial sequence numbers and window sizes—it requires raw socket creation privileges.
  > As shown here, Nmap accurately fingerprinted our target as a Linux 5.15 kernel system, perfectly matching our authorized Ubuntu 22.04 LTS lab VM."

### Segment 5: Security Risk Analysis & Hardening (3:00 – 4:00)
- **Visual:** Displaying the Security Analysis Report table in VS Code / Terminal.
- **Spoken Script:**
  > "As a security analyst, discovering open ports is only the first step. Next, we interpret what these mean defensively:
  > - Port 80 is serving HTTP without encryption. The immediate recommendation is enforcing TLS/HTTPS on port 443 with HSTS.
  > - Port 22 SSH should have password authentication disabled in favor of public keys, alongside Fail2ban to mitigate brute-force attempts.
  > - Ports 3000 and 8080 are development web servers. These should never be exposed to wildcard interfaces (0.0.0.0); they should be bound strictly to 127.0.0.1 or shielded behind a reverse proxy.
  > Crucially, an open port does not mean a machine is hacked or vulnerable—it represents an exposed attack surface that requires disciplined defense."

### Segment 6: Deliverables Review & Submission Wrap-Up (4:00 – 5:00)
- **Visual:** Displaying the repository layout: `README.md`, `nmap_scan_results.txt`, `reports/security_analysis.md`, `screenshots/`, and `scripts/run_authorized_scan.sh`.
- **Spoken Script:**
  > "To conclude, all deliverables have been systematically documented in our GitHub-ready repository:
  > We have our structured `nmap_scan_results.txt`, full markdown security report, high-resolution terminal evidence screenshots, an automated POSIX bash scanning script with IPv4 validation, and this demo video plan.
  > Thank you Oasis Infobyte for this engaging hands-on assignment!"

---

## 3. HOW TO RECORD YOUR SCREEN (FOR THE USER)

Follow these simple instructions to record your demonstration:

### Option A: OBS Studio (Linux, Windows, macOS — Free & Open Source)
1. Download from [https://obsproject.com/](https://obsproject.com/).
2. Under **Sources**, click `+` -> Select **Window Capture** or **Display Capture**.
3. Select your Terminal window.
4. Ensure your microphone is enabled under **Audio Mixer**.
5. Click **Start Recording**, follow the 5-minute script above, and click **Stop Recording**.
6. Export as MP4.

### Option B: Linux SimpleScreenRecorder
```bash
sudo apt update && sudo apt install simplescreenrecorder
simplescreenrecorder &
```
1. Select "Record a fixed rectangle" or "Record entire screen".
2. Select your audio input (PulseAudio).
3. Record and save to `demo/oibsip_task1_demo.mp4`.

### Option C: Windows Xbox Game Bar (Built-in)
1. Press `Win + G` or `Win + Alt + R` to start recording the active terminal or browser window.
2. Deliver the commentary.
3. Access the recorded video in `C:\Users\<User>\Videos\Captures`.

---

## 4. VIDEO UPLOAD & SUBMISSION CHECKLIST

- [ ] Video recorded following the 3–5 minute script.
- [ ] Audio is crisp and background noise is minimized.
- [ ] Commands and port numbers are clearly legible on screen.
- [ ] Uploaded to YouTube (Unlisted or Public) or Google Drive (Share setting: "Anyone with link can view").
- [ ] Link pasted into the top of this file and in `README.md`.
