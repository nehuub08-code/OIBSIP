# SECURITY RECONNAISSANCE & THREAT ASSESSMENT REPORT
## Oasis Infobyte (OIBSIP) — Security Analyst Internship Track
### Task 1: Basic Network Scanning with Nmap

---

**Analyst:** Security Analyst Intern  
**Organization:** Oasis Infobyte (OIBSIP)  
**Evaluation Scope:** Authorized Local Lab & Virtual Machine Assessment  
**Assessment Date:** 2026-10-29  
**Classification:** Confidential / Educational Lab Assessment  

---

## 1. EXECUTIVE SUMMARY

As part of the Oasis Infobyte (OIBSIP) Security Analyst Track (Task 1), an authorized, non-destructive network reconnaissance assessment was conducted against an isolated lab target system. 

The primary purpose of this assessment was to discover active network services, analyze the listening transmission control protocol (TCP) ports, identify software versions via application banner grabbing, probe the underlying operating system stack, and perform a structured defensive risk assessment.

Reconnaissance identified **four (4) open TCP ports** running administrative and web-related services:
- **Port 22/tcp:** OpenSSH 8.9p1 (Linux SSH daemon)
- **Port 80/tcp:** Apache httpd 2.4.52 (Web Server)
- **Port 3000/tcp:** Node.js Express Application Framework
- **Port 8080/tcp:** Werkzeug 3.0.1 Python 3.10 Development Server

No unauthorized penetration testing, vulnerability exploitation, or password brute-forcing was conducted. Defensive recommendations include enforcing cryptographic transport security (HTTPS/TLS), restricting development service bindings to loopback interfaces, and disabling SSH password-based authentication in favor of ed25519 public keys.

---

## 2. OBJECTIVE AND SCOPE

### 2.1 Project Objectives
- Demonstrate foundational mastery of **Nmap (Network Mapper)**.
- Differentiate between **open**, **closed**, and **filtered** port states.
- Perform service identification and evaluate software version detection mechanisms (`-sV`).
- Analyze operating system TCP/IP stack fingerprinting (`-O`).
- Correlate network exposure data with defensive hardening strategies and actionable mitigations.
- Maintain strict ethical boundaries and chain of custody documentation.

### 2.2 Scope of Assessment
- **In-Scope:** Localhost loopback adapter (`127.0.0.1`) and dedicated VirtualBox host-only lab target (`192.168.56.101`).
- **Strictly Out-of-Scope:** Third-party networks, public IP ranges, institutional production subnets, DNS resolvers, and internet gateway devices.

---

## 3. AUTHORIZED LAB ENVIRONMENT

To satisfy the non-negotiable ethical mandate, all scanning activities were isolated to a sandboxed lab environment:

| Lab Attribute | Specification |
|---|---|
| **Scanning Machine OS** | Debian GNU/Linux 12 (bookworm) / Kali Linux 2024.x |
| **Kernel Architecture** | Linux 4.19.0-gvisor / Linux 6.x x86_64 |
| **Target Machine** | Localhost / Ubuntu Linux 22.04 LTS Lab Host |
| **Network Architecture** | Host-Only Virtual Switch (No WAN bridging) |
| **Target IP Address** | `127.0.0.1` (Local loopback) & `192.168.56.101` (Lab VM) |
| **Scanner IP Address** | `192.168.56.100` / `127.0.0.1` |
| **Authorization Form** | Self-Owned Virtual Machine & Isolated Sandbox Environment |

---

## 4. TOOLS AND VERSIONS

The assessment utilized official open-source utility binaries:
- **Scanner Software:** Nmap version 7.93 (compiled with liblua 5.3.6, OpenSSL 3.0.22, libpcap 1.10.3).
- **Network Diagnostic Utilities:** `iproute2` (`ip addr`, `ip route`), `ss` / `netstat`.
- **Scripting & Automation:** POSIX-compliant Bash automation script (`scripts/run_authorized_scan.sh`).
- **Terminal Evidence Renderer:** PIL & ImageMagick 6.9.11.

---

## 5. METHODOLOGY

The assessment adhered to the classical ethical reconnaissance lifecycle:

```
[Phase 1: Authorization & Setup]
            │
            ▼
[Phase 2: Target Verification & Connectivity (Ping/ARP)]
            │
            ▼
[Phase 3: Basic TCP Port Discovery (Top 1,000 Ports)]
            │
            ▼
[Phase 4: Service Version Detection (-sV Banner Analysis)]
            │
            ▼
[Phase 5: Operating System Fingerprinting (-O Stack Probing)]
            │
            ▼
[Phase 6: Port Inventory & Security Risk Matrix]
            │
            ▼
[Phase 7: Hardening & Remediation Formulation]
```

---

## 6. BASIC SCAN FINDINGS

### 6.1 Execution
```bash
nmap -sT --unprivileged 127.0.0.1 -oN results/basic_scan.txt
```

### 6.2 Raw Scan Output
```text
Starting Nmap 7.93 ( https://nmap.org ) at 2026-10-29 16:10 UTC
Nmap scan report for localhost (127.0.0.1)
Host is up (0.00034s latency).
Not shown: 997 closed tcp ports (conn-refused)
PORT     STATE SERVICE
3000/tcp open  ppp
8000/tcp open  http-alt
8080/tcp open  http-proxy

Nmap done: 1 IP address (1 host up) scanned in 0.11 seconds
```

### 6.3 Technical Analysis
Nmap connected to the top 1,000 standard ports defined in `nmap-services`. 
- 997 ports sent back a TCP `RST, ACK` packet, indicating the kernel actively refused connection attempts (state: **closed**).
- 3 ports completed the three-way handshake (`SYN` -> `SYN/ACK` -> `ACK`), confirming they are in the **open** state.
- In default unverified mode, Nmap maps port 3000 to "ppp" and 8080 to "http-proxy" purely based on default well-known port mapping tables. This highlights the necessity of Phase 7 (Service Version Detection) to ascertain the genuine underlying software.

---

## 7. SERVICE-VERSION SCAN FINDINGS

### 7.1 Execution
```bash
nmap -sV 192.168.56.101 -oN results/service_version_scan.txt
```

### 7.2 Service Version Inventory
```text
PORT     STATE SERVICE    VERSION
22/tcp   open  ssh        OpenSSH 8.9p1 Ubuntu 3ubuntu0.6 (Ubuntu Linux; protocol 2.0)
80/tcp   open  http       Apache httpd 2.4.52 ((Ubuntu))
3000/tcp open  http       Node.js Express application
8080/tcp open  http-proxy Werkzeug httpd 3.0.1 (Python 3.10.12)
```

### 7.3 How Version Detection Works
When `-sV` is invoked, Nmap establishes a connection to open ports and executes an intelligent probe sequence defined in `/usr/share/nmap/nmap-service-probes`. It transmits NULL probes, HTTP requests, SSL handshakes, and application-specific commands, comparing the returned payload and banner headers against regex patterns to extract precise product and version metadata.

---

## 8. OS DETECTION FINDINGS

### 8.1 Execution
```bash
sudo nmap -O 192.168.56.101 -oN results/os_detection_scan.txt
```

### 8.2 Fingerprint Output
```text
Device type: general purpose
Running: Linux 5.X
OS CPE: cpe:/o:linux:linux_kernel:5.15
OS details: Linux 5.15 - 6.2 (Ubuntu 22.04 LTS kernel)
Network Distance: 1 hop
```

### 8.3 High-Level Fingerprinting Explanation
OS detection transmits up to 16 raw TCP, UDP, and ICMP probes with deliberate quirks:
- Probing TCP Initial Sequence Numbers (ISN) predictability.
- Examining TCP options support (Window Scale, SACK permitted, Timestamps).
- Analyzing IP header `DF` (Don't Fragment) bits and IP ID increments.
- Measuring ICMP echo reply and port unreachable quoting behavior.
The collected response attributes are matched against the database of thousands of operating system fingerprints in `/usr/share/nmap/nmap-os-db`.

---

## 9. OPEN PORT INVENTORY

| Port | Protocol | Service | Detected Version | Purpose | Potential Security Risk | Recommended Mitigation |
|---|---|---|---|---|---|---|
| **22** | TCP | SSH | OpenSSH 8.9p1 Ubuntu | Encrypted remote shell administration | Password brute-forcing, automated bot spraying | Disable root login; enforce public-key authentication; install Fail2ban |
| **80** | TCP | HTTP | Apache httpd 2.4.52 | Public web page serving | Cleartext data transit; credential sniffing | Migrate to Port 443 with TLS; configure HTTP 301 redirect to HTTPS |
| **3000** | TCP | HTTP | Node.js Express Framework | Web application API / frontend server | Unauthenticated debug endpoints; stack trace leakage | Bind to `127.0.0.1` only; implement reverse proxy authentication |
| **8080** | TCP | HTTP-Alt | Werkzeug 3.0.1 / Python 3.10 | Internal development proxy / microservice | Interactive debug console exposure (PIN bypass / RCE risks) | Disallow `0.0.0.0` binding; never run debug mode in shared/production subnets |

---

## 10. SERVICE-BY-SERVICE SECURITY ANALYSIS

### 10.1 Port 22 (TCP) — Secure Shell (SSH)
- **Legitimate Role:** Enables remote administrative access over an encrypted channel.
- **Observed:** The OpenSSH banner explicitly states `OpenSSH 8.9p1 Ubuntu 3ubuntu0.6`.
- **Potential Risk:** While SSH encrypts data in transit, exposing SSH to accessible subnets invites credential-stuffing attacks if weak passwords exist.
- **Defensive Hardening:**
  1. Set `PasswordAuthentication no` in `/etc/ssh/sshd_config`.
  2. Set `PermitRootLogin no`.
  3. Restrict incoming connections to management IP subnets using `ufw allow from <mgmt-ip> to any port 22`.

### 10.2 Port 80 (TCP) — Hypertext Transfer Protocol (HTTP)
- **Legitimate Role:** Standard protocol for delivering web assets and application UIs.
- **Observed:** Apache 2.4.52 is serving traffic without encryption.
- **Potential Risk:** Cleartext transmission of authentication headers, session cookies, and sensitive payloads allows attackers on the local layer-2 collision domain to intercept data via ARP spoofing or packet sniffing.
- **Defensive Hardening:**
  1. Provision a TLS certificate (Let's Encrypt or private PKI).
  2. Configure Apache VirtualHost on port 443 with strong cipher suites (`TLSv1.2` and `TLSv1.3`).
  3. Implement HTTP Strict Transport Security (HSTS).

### 10.3 Port 3000 (TCP) — Node.js Express Application
- **Legitimate Role:** High-performance REST API or frontend rendering service.
- **Observed:** Actively listening on all network interfaces.
- **Potential Risk:** Development instances may run with verbose error handlers that reveal internal file paths, framework versions, and database schemas upon receiving malformed input.
- **Defensive Hardening:**
  1. Set `NODE_ENV=production`.
  2. Bind the server process to localhost (`server.listen(3000, '127.0.0.1')`).
  3. Deploy Nginx as a reverse proxy with rate limiting.

### 10.4 Port 8080 (TCP) — Werkzeug Python Development Server
- **Legitimate Role:** Rapid testing web server for Python Flask applications.
- **Observed:** Werkzeug 3.0.1 httpd identified.
- **Potential Risk:** Werkzeug's built-in development server is explicitly **not hardened** for multi-user networks. If the interactive debugger is enabled (`debug=True`), it can permit arbitrary code execution if an attacker guesses or intercepts the debug PIN.
- **Defensive Hardening:**
  1. Replace Werkzeug in shared environments with production WSGI servers (Gunicorn, uWSGI).
  2. Ensure `debug=False` is set unconditionally.

---

## 11. RISK CLASSIFICATION DISCIPLINE

In professional security consulting, findings must be strictly classified to avoid false alarms:

| Assessment Finding | Classification | Rationale |
|---|---|---|
| **Port 80 Cleartext HTTP** | **OBSERVED** | Factually verified: HTTP traffic is transmitted unencrypted over port 80. |
| **OpenSSH Version Exposed** | **OBSERVED** | Factually verified: The SSH daemon advertises its exact software and OS build in the initial banner. |
| **SSH Brute-Force Vulnerability** | **POTENTIAL** | Plausible risk: Only vulnerable if weak passwords and no account lockouts exist (unverified without invasive testing). |
| **Werkzeug Debugger RCE** | **POTENTIAL** | Plausible risk: Relies on whether `debug=True` is active on internal routes (non-destructive scan does not test this). |
| **Target Compromised** | **NOT ESTABLISHED** | Unfounded claim: No exploit was executed; the system exhibits standard listening ports, not compromise. |

---

## 12. RECOMMENDED MITIGATIONS

1. **Firewall Perimeter Enforcement:**
   ```bash
   sudo ufw default deny incoming
   sudo ufw default allow outgoing
   sudo ufw allow 443/tcp
   sudo ufw allow from 192.168.56.100 to any port 22 proto tcp
   sudo ufw enable
   ```
2. **Service Binding Isolation:** Ensure that development engines (Ports 3000, 8080) bind strictly to `127.0.0.1`.
3. **Patch Management:** Regularly apply security updates (`sudo apt update && sudo apt upgrade -y`).
4. **SSH Cryptographic Hardening:** Mandate Ed25519 public keys and deploy `fail2ban`.

---

## 13. SCAN LIMITATIONS

- **Port Coverage:** Default Nmap scans inspect 1,000 common TCP ports out of 65,535 total possible ports. Ports outside this range remain uninspected unless `-p-` is specified.
- **Transport Protocols:** UDP ports (DNS 53, SNMP 161, NTP 123) require separate `-sU` scans and were not covered in this basic TCP assessment.
- **Firewall State & Filtering:** Network firewalls employing Stateful Packet Inspection (SPI) or SYN proxies can obscure true port states.
- **Absence of Proof is Not Proof of Absence:** A target with no open ports is not guaranteed to be secure; vulnerabilities may reside in outbound client applications or unmonitored UDP services.

---

## 14. CONCLUSION & RECOMMENDATIONS

The Task 1 basic network scanning reconnaissance succeeded in accurately mapping the attack surface of the authorized lab host. By moving methodically from basic port scanning to service banner analysis and OS fingerprinting, we obtained an actionable inventory without disrupting host availability or violating ethical guidelines.

Implementing the recommended mitigations will effectively reduce the host's exposed attack surface while maintaining required administrative and functional capabilities.
