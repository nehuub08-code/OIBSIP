#!/usr/bin/env bash
# ==============================================================================
# OIBSIP - OASIS INFOBYTE SECURITY ANALYST INTERNSHIP TRACK
# Task 1: Basic Network Scanning with Nmap
# Script: run_authorized_scan.sh
# Purpose: Safe, reproducible, and authorized network reconnaissance script.
#
# NON-NEGOTIABLE SECURITY WARNING:
# Scanning networks or hosts without explicit authorization is illegal under
# computer misuse statutes (e.g., Computer Fraud and Abuse Act, UK Computer
# Misuse Act, Indian IT Act 2000 Section 43/66).
# ONLY execute this script against authorized lab environments, loopback
# adapters (127.0.0.1), or owned VirtualBox/VM instances.
# ==============================================================================

set -euo pipefail

# Print banner
echo "======================================================================"
echo "    OIBSIP SECURITY ANALYST TRACK — TASK 1: NMAP SCAN RUNNER"
echo "======================================================================"

# 1. Check for target IP argument
TARGET="${1:-}"

if [[ -z "$TARGET" ]]; then
    echo "[-] Error: Missing target parameter."
    echo "[*] Usage:   $0 <authorized-target-ip>"
    echo "[*] Example: $0 127.0.0.1"
    echo "[*] Example: $0 192.168.56.101"
    exit 1
fi

# 2. Check if Nmap is installed
if ! command -v nmap >/dev/null 2>&1; then
    echo "[-] Fatal Error: 'nmap' binary was not found on this system PATH."
    echo "[*] Install Nmap before running this script:"
    echo "    Debian/Ubuntu/Kali: sudo apt update && sudo apt install nmap"
    echo "    RHEL/Fedora/CentOS: sudo dnf install nmap"
    echo "    Arch Linux:         sudo pacman -S nmap"
    exit 1
fi

# 3. Robust IPv4 validation: format regex and octet value boundary (0-255)
validate_ipv4() {
    local ip="$1"
    if [[ ! "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        return 1
    fi
    IFS='.' read -r -a octets <<< "$ip"
    for octet in "${octets[@]}"; do
        # Disallow leading zeros on multi-digit octets (octal trap prevention)
        if [[ "$octet" =~ ^0[0-9]+$ ]]; then
            return 1
        fi
        if (( octet < 0 || octet > 255 )); then
            return 1
        fi
    done
    return 0
}

if ! validate_ipv4 "$TARGET"; then
    echo "[-] Error: '$TARGET' is not a valid IPv4 address (must be 4 octets between 0-255)."
    exit 1
fi

# 4. Mandatory Authorization Confirmation
echo ""
echo "[!] ******************** LEGAL & ETHICAL WARNING ********************"
echo "[!] You are about to initiate an Nmap network scan against:"
echo "[!] Target IP: $TARGET"
echo "[!] This script must ONLY be run against systems that you own or for"
echo "[!] which you hold written, verified authorization."
echo "[!] *****************************************************************"
echo ""
read -r -p "[?] Confirm you own or are authorized to scan $TARGET (type 'yes' to proceed): " CONFIRM

if [[ "$CONFIRM" != "yes" ]]; then
    echo "[-] Authorization not confirmed. Aborting scan immediately."
    exit 0
fi

# 5. Prepare Results Directory
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
RESULTS_DIR="results_${TIMESTAMP}"
mkdir -p "$RESULTS_DIR"

echo ""
echo "[+] Starting assessment against authorized target: $TARGET"
echo "[+] Output artifacts will be saved to: $RESULTS_DIR/"
echo "[+] Start timestamp: $(date)"

# Record metadata
{
    echo "SCAN RUNNER METADATA"
    echo "Target: $TARGET"
    echo "Execution Timestamp: $(date -u)"
    echo "Nmap Version: $(nmap --version | head -n 1)"
    echo "Operating System: $(uname -s -r -v -m)"
} > "$RESULTS_DIR/scan_metadata.txt"

# 6. SCAN 1: Basic TCP Port Scan
echo ""
echo "[*] [1/3] Executing Basic TCP Port Scan on $TARGET..."
if nmap -sT --unprivileged "$TARGET" -oN "$RESULTS_DIR/01_basic_scan.txt"; then
    echo "[+] Basic scan completed successfully. Saved to $RESULTS_DIR/01_basic_scan.txt"
else
    echo "[!] Fallback: Standard connect scan failed, retrying standard nmap..."
    nmap "$TARGET" -oN "$RESULTS_DIR/01_basic_scan.txt" || echo "[-] Warning: Basic scan encountered errors."
fi

# 7. SCAN 2: Service Version Detection (-sV)
echo ""
echo "[*] [2/3] Executing Service Version Detection (-sV) on $TARGET..."
if nmap -sV "$TARGET" -oN "$RESULTS_DIR/02_service_version_scan.txt"; then
    echo "[+] Service version scan completed. Saved to $RESULTS_DIR/02_service_version_scan.txt"
else
    echo "[-] Warning: Service version scan encountered non-fatal issues (check host timeout / socket permissions)."
fi

# 8. SCAN 3: Operating System Detection (-O)
echo ""
echo "[*] [3/3] Executing OS Detection (-O) on $TARGET..."
if [[ $EUID -ne 0 ]]; then
    echo "[*] Note: OS fingerprinting requires raw socket privileges."
    if command -v sudo >/dev/null 2>&1; then
        echo "[*] Invoking sudo for raw socket OS detection probe..."
        sudo nmap -O "$TARGET" -oN "$RESULTS_DIR/03_os_detection_scan.txt" || {
            echo "[-] Sudo OS scan exited with code $?. Logging results to $RESULTS_DIR/03_os_detection_scan.txt"
        }
    else
        echo "[-] Sudo not available. Running unprivileged (OS detection may be limited)..."
        nmap -O "$TARGET" -oN "$RESULTS_DIR/03_os_detection_scan.txt" || true
    fi
else
    nmap -O "$TARGET" -oN "$RESULTS_DIR/03_os_detection_scan.txt" || {
        echo "[-] Warning: OS detection probe returned non-zero (sandboxed/container environment may restrict raw sockets)."
    }
fi

# 9. Summary & Wrap up
echo ""
echo "======================================================================"
echo "[+] ALL SCAN PHASES COMPLETED."
echo "======================================================================"
echo "[*] Generated Evidence Artifacts in $RESULTS_DIR/:"
ls -lh "$RESULTS_DIR"
echo ""
echo "[!] NOTE: Review generated text files before sharing. Ensure that no"
echo "    sensitive internal network hostnames or private credentials are leaked."
echo "======================================================================"
