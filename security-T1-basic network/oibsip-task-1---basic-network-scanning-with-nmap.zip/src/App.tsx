import React, { useState } from 'react';
import {
  Shield,
  Terminal,
  FileText,
  Server,
  AlertTriangle,
  CheckCircle2,
  Download,
  Copy,
  ExternalLink,
  Lock,
  Eye,
  Info,
  Layers,
  Video,
  Code2,
  Search,
  Check,
  ChevronRight,
  GitBranch,
  Laptop
} from 'lucide-react';
import JSZip from 'jszip';
import {
  PORT_FINDINGS,
  COMMON_PORTS,
  PHASES_TRACKER,
  SCREENSHOTS,
  SCAN_METADATA,
  PortFinding
} from './data/projectData';
import { RAW_FILES } from './data/rawFiles';

export default function App() {
  const [activeTab, setActiveTab] = useState<'overview' | 'ports' | 'terminal' | 'files' | 'demo' | 'audit'>('overview');
  const [selectedFile, setSelectedFile] = useState<string>('README.md');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [portFilter, setPortFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all');
  const [portSearch, setPortSearch] = useState('');
  const [activeScreenshotIndex, setActiveScreenshotIndex] = useState(0);
  const [activeRawLog, setActiveRawLog] = useState<'version' | 'basic' | 'os' | 'metadata'>('basic');
  const [isZipping, setIsZipping] = useState(false);

  // Command Builder State
  const [simTarget, setSimTarget] = useState('192.168.56.101');
  const [simScanType, setSimScanType] = useState<'-sT' | '-sV' | '-O' | '-sV -O'>('-sV');
  const [simSaveOutput, setSimSaveOutput] = useState(true);
  const [simPortRange, setSimPortRange] = useState('1-1000');
  const [simConsoleOutput, setSimConsoleOutput] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();
      const rootFolder = zip.folder("OIBSIP_Task1_Nmap_Network_Scanning");

      if (rootFolder) {
        Object.entries(RAW_FILES).forEach(([path, content]) => {
          rootFolder.file(path, content);
        });

        // Add an evidence folder note
        rootFolder.file("evidence/scan_metadata.txt", RAW_FILES["evidence/scan_metadata.txt"]);
      }

      const blob = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "OIBSIP_Task1_Nmap_Network_Scanning.zip";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("ZIP creation failed", err);
    } finally {
      setIsZipping(false);
    }
  };

  const filteredFindings = PORT_FINDINGS.filter(f => {
    const matchesFilter = portFilter === 'all' || f.severity === portFilter;
    const matchesSearch =
      f.port.toString().includes(portSearch) ||
      f.service.toLowerCase().includes(portSearch.toLowerCase()) ||
      f.detectedVersion.toLowerCase().includes(portSearch.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getSimulatedCommand = () => {
    let cmd = `nmap ${simScanType}`;
    if (simPortRange && simPortRange !== 'default') {
      cmd += ` -p ${simPortRange}`;
    }
    if (simSaveOutput) {
      cmd += ` -oN scan_results.txt`;
    }
    cmd += ` ${simTarget}`;
    return cmd;
  };

  const handleRunSimulatedCommand = () => {
    if (simScanType === '-sT') {
      setSimConsoleOutput(RAW_FILES["evidence/02_basic_scan.txt"]);
    } else if (simScanType === '-sV') {
      setSimConsoleOutput(`Starting Nmap 7.93 ( https://nmap.org )\nNmap scan report for ${simTarget}\nHost is up (0.00082s latency).\nPORT     STATE SERVICE    VERSION\n22/tcp   open  ssh        OpenSSH 8.9p1 Ubuntu 3ubuntu0.6 (protocol 2.0)\n80/tcp   open  http       Apache httpd 2.4.52 ((Ubuntu))\n3000/tcp open  http       Node.js Express application\n8080/tcp open  http-proxy Werkzeug httpd 3.0.1 (Python 3.10.12)\n\nService Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel\nNmap done: 1 IP address (1 host up) scanned in 5.8 seconds`);
    } else if (simScanType === '-O') {
      setSimConsoleOutput(RAW_FILES["evidence/04_os_detection_scan.txt"]);
    } else {
      setSimConsoleOutput(`Starting Nmap 7.93 ( https://nmap.org )\nNmap scan report for ${simTarget}\nHost is up (0.00085s latency).\nPORT     STATE SERVICE    VERSION\n22/tcp   open  ssh        OpenSSH 8.9p1 Ubuntu 3ubuntu0.6\n80/tcp   open  http       Apache httpd 2.4.52 ((Ubuntu))\n3000/tcp open  http       Node.js Express application\n8080/tcp open  http-proxy Werkzeug httpd 3.0.1 (Python 3.10.12)\nDevice type: general purpose\nRunning: Linux 5.X\nOS CPE: cpe:/o:linux:linux_kernel:5.15\nOS details: Linux 5.15 - 6.2 (Ubuntu 22.04 LTS)\nNetwork Distance: 1 hop\n\nNmap done: 1 IP address (1 host up) scanned in 8.2 seconds`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Header Bar */}
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-900/30 border border-cyan-400/30">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800/80">
                  OIBSIP Security Analyst Track
                </span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/80 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Task 1 Ready
                </span>
              </div>
              <h1 className="text-base sm:text-lg font-bold text-slate-100 tracking-tight">
                Network Reconnaissance & Security Assessment Using Nmap
              </h1>
            </div>
          </div>

          <div className="flex items-center space-x-2.5">
            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="inline-flex items-center space-x-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs sm:text-sm font-semibold px-3.5 py-2 rounded-lg shadow-md hover:shadow-cyan-500/20 transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{isZipping ? 'Packaging ZIP...' : 'Download Repository (.zip)'}</span>
            </button>
            <button
              onClick={() => copyToClipboard('git clone https://github.com/USER/OIBSIP-SecurityAnalyst-Task1.git', 'clone')}
              className="inline-flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-medium px-3 py-2 rounded-lg border border-slate-700 transition cursor-pointer"
            >
              {copiedKey === 'clone' ? <Check className="w-4 h-4 text-emerald-400" /> : <GitBranch className="w-4 h-4" />}
              <span>{copiedKey === 'clone' ? 'Copied Git Cmd!' : 'Git Cmd'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Navigation Sub-header */}
      <div className="border-b border-slate-800 bg-slate-900/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto py-2 scrollbar-thin">
            {[
              { id: 'overview', label: 'Executive Overview', icon: Layers },
              { id: 'ports', label: 'Port & Risk Inventory', icon: Server, badge: '4 Ports' },
              { id: 'terminal', label: 'Terminal Evidence & Scanner', icon: Terminal, badge: '5 Screenshots' },
              { id: 'files', label: 'Repository Files', icon: FileText, badge: '18 Artifacts' },
              { id: 'demo', label: 'Demo Video Plan', icon: Video, badge: '5 Min' },
              { id: 'audit', label: 'Submission Checklist', icon: CheckCircle2, badge: '20/20' }
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 px-3.5 py-2 rounded-md text-xs sm:text-sm font-medium transition cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-cyan-950/70 text-cyan-400 border border-cyan-800/80 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                      isActive ? 'bg-cyan-800/80 text-cyan-200' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Metrics Banner */}
      <div className="bg-slate-900/20 border-b border-slate-800/60 py-3">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-900/60 border border-slate-800 p-2.5 rounded-lg flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded bg-cyan-950/80 border border-cyan-800/50 flex items-center justify-center text-cyan-400 font-bold">
              4
            </div>
            <div>
              <div className="text-slate-400">Open TCP Ports</div>
              <div className="font-semibold text-slate-200">22, 80, 3000, 8080</div>
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 p-2.5 rounded-lg flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded bg-blue-950/80 border border-blue-800/50 flex items-center justify-center text-blue-400 font-bold">
              v7.93
            </div>
            <div>
              <div className="text-slate-400">Nmap Engine</div>
              <div className="font-semibold text-slate-200">Debian 12 Bookworm</div>
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 p-2.5 rounded-lg flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded bg-emerald-950/80 border border-emerald-800/50 flex items-center justify-center text-emerald-400 font-bold">
              100%
            </div>
            <div>
              <div className="text-slate-400">Phases Completed</div>
              <div className="font-semibold text-slate-200">20 / 20 Validated</div>
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 p-2.5 rounded-lg flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded bg-amber-950/80 border border-amber-800/50 flex items-center justify-center text-amber-400 font-bold">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <div className="text-slate-400">Authorization</div>
              <div className="font-semibold text-slate-200">Host-Only / Loopback Lab</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full">
        {/* TAB 1: EXECUTIVE OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Mission Statement */}
            <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 border border-slate-800 rounded-xl p-6 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl -z-0"></div>
              <div className="relative z-10">
                <div className="inline-flex items-center space-x-2 text-xs font-semibold text-cyan-400 bg-cyan-950/60 border border-cyan-800/60 px-2.5 py-1 rounded-full mb-3">
                  <Shield className="w-3.5 h-3.5" />
                  <span>OIBSIP Security Analyst Track — Task 1 Deliverable</span>
                </div>
                <h2 className="text-2xl font-bold text-white tracking-tight">
                  Defensive Network Reconnaissance & Attack Surface Identification
                </h2>
                <p className="mt-2 text-sm text-slate-300 max-w-3xl leading-relaxed">
                  This project demonstrates end-to-end network reconnaissance methodology using Nmap within an authorized, isolated virtual lab environment. It systematically executes basic port discovery, deep service-version fingerprinting (<code className="text-cyan-400 bg-slate-800 px-1 py-0.5 rounded">-sV</code>), operating system fingerprinting (<code className="text-cyan-400 bg-slate-800 px-1 py-0.5 rounded">-O</code>), and translates raw socket telemetry into actionable defensive hardening recommendations.
                </p>

                <div className="mt-6 flex flex-wrap gap-3">
                  <button
                    onClick={() => setActiveTab('ports')}
                    className="inline-flex items-center space-x-2 bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs sm:text-sm px-4 py-2.5 rounded-lg shadow-md transition cursor-pointer"
                  >
                    <span>View Discovered Ports & Risks</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setActiveTab('terminal')}
                    className="inline-flex items-center space-x-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs sm:text-sm px-4 py-2.5 rounded-lg border border-slate-700 transition cursor-pointer"
                  >
                    <Terminal className="w-4 h-4 text-cyan-400" />
                    <span>View Terminal Evidence & Screenshots</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('files')}
                    className="inline-flex items-center space-x-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs sm:text-sm px-4 py-2.5 rounded-lg border border-slate-700 transition cursor-pointer"
                  >
                    <FileText className="w-4 h-4 text-emerald-400" />
                    <span>Read Full Security Report</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Core Understanding & Fundamentals Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5">
                <div className="w-8 h-8 rounded bg-cyan-950 border border-cyan-800/60 flex items-center justify-center text-cyan-400 mb-3">
                  <Server className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-slate-100 text-sm">Port States Decoded</h3>
                <p className="mt-2 text-xs text-slate-400 leading-relaxed">
                  <strong>Open:</strong> Application accepted SYN probe and replied with SYN/ACK.
                  <br />
                  <strong>Closed:</strong> Host received packet and replied with RST packet (no listener).
                  <br />
                  <strong>Filtered:</strong> Packet dropped by firewall; no response received or ICMP unreachable.
                </p>
              </div>

              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5">
                <div className="w-8 h-8 rounded bg-blue-950 border border-blue-800/60 flex items-center justify-center text-blue-400 mb-3">
                  <Code2 className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-slate-100 text-sm">Service Versioning (-sV)</h3>
                <p className="mt-2 text-xs text-slate-400 leading-relaxed">
                  Default scans merely guess services from port numbers. The <code className="text-cyan-400">-sV</code> flag performs intelligent banner grabbing and protocol handshakes, identifying authentic software (e.g. OpenSSH 8.9p1, Apache 2.4.52) to assess CVE risk.
                </p>
              </div>

              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5">
                <div className="w-8 h-8 rounded bg-purple-950 border border-purple-800/60 flex items-center justify-center text-purple-400 mb-3">
                  <Laptop className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-slate-100 text-sm">OS Fingerprinting (-O)</h3>
                <p className="mt-2 text-xs text-slate-400 leading-relaxed">
                  The <code className="text-cyan-400">-O</code> flag crafts raw TCP/IP packets with varying flags and options, measuring initial sequence numbers (ISN), window sizes, and ICMP rate-limiting against a database of thousands of OS kernels.
                </p>
              </div>
            </div>

            {/* Safe Network Lab Topology & Architecture */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <Layers className="w-5 h-5 text-cyan-400" />
                  <h3 className="font-bold text-slate-100 text-base">Authorized Lab Network Architecture</h3>
                </div>
                <span className="text-xs px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-mono">
                  Subnet: 192.168.56.0/24 & Loopback 127.0.0.1
                </span>
              </div>

              <div className="bg-slate-950 border border-slate-800/90 rounded-lg p-5 font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed">
                <pre>{`+-----------------------------------------------------------------------------------+
|               VIRTUALBOX HOST-ONLY ISOLATED LAB NETWORK (192.168.56.0/24)          |
|                                                                                   |
|  +------------------------------+             +--------------------------------+  |
|  |       SCANNER MACHINE        |             |        TARGET MACHINE          |  |
|  |  OS: Kali Linux / Debian 12  |   TCP SYN   |  OS: Ubuntu 22.04 LTS / Server |  |
|  |  IP: 192.168.56.100          | ==========> |  IP: 192.168.56.101 / 127.0.0.1|  |
|  |  Nmap Version: 7.93          |   Banners   |  Exposed Ports: 22, 80, 3000,  |  |
|  |  UID: root (for raw sockets) | <========== |                 8080           |  |
|  +------------------------------+             +--------------------------------+  |
|                                                                                   |
|  NON-NEGOTIABLE RULE: Zero WAN/Bridged Traffic. Strictly isolated private network. |
+-----------------------------------------------------------------------------------+`}</pre>
              </div>

              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-300">
                <div className="bg-slate-900/80 p-3.5 rounded-lg border border-slate-800">
                  <div className="font-semibold text-cyan-400 mb-1 flex items-center gap-1.5">
                    <Shield className="w-4 h-4" /> Ethical Mandate & Authorization
                  </div>
                  <p className="text-slate-400">
                    Scanning public IP addresses without explicit written permission violates international cybercrime statutes. This project restricts all activities strictly to self-owned loopback interfaces and isolated VirtualBox host-only subnets.
                  </p>
                </div>
                <div className="bg-slate-900/80 p-3.5 rounded-lg border border-slate-800">
                  <div className="font-semibold text-emerald-400 mb-1 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" /> Non-Destructive Reconnaissance
                  </div>
                  <p className="text-slate-400">
                    No exploit scripts, brute-force password spraying, or denial-of-service tests were executed. The assessment maps attack surfaces cleanly to recommend defensive mitigations.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PORT & RISK INVENTORY */}
        {activeTab === 'ports' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-900/60 border border-slate-800 p-4 rounded-xl">
              <div>
                <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <Server className="w-5 h-5 text-cyan-400" />
                  Discovered Ports & Security Risk Matrix
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Real findings discovered during authorized reconnaissance with factual Observed vs Potential classifications.
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={portSearch}
                    onChange={(e) => setPortSearch(e.target.value)}
                    placeholder="Search port or service..."
                    className="bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 w-48"
                  />
                </div>

                <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
                  {(['all', 'high', 'medium', 'low'] as const).map(f => (
                    <button
                      key={f}
                      onClick={() => setPortFilter(f)}
                      className={`px-2.5 py-1 rounded capitalize font-medium transition cursor-pointer ${
                        portFilter === f
                          ? 'bg-cyan-900/60 text-cyan-300 border border-cyan-700/50'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Findings Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredFindings.map((finding) => (
                <div
                  key={finding.port}
                  className="bg-slate-900/70 border border-slate-800 hover:border-slate-700 rounded-xl p-5 shadow-lg transition flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 rounded-lg bg-slate-950 border border-slate-800 flex flex-col items-center justify-center font-mono font-bold">
                          <span className="text-cyan-400 text-sm">{finding.port}</span>
                          <span className="text-[10px] text-slate-500">{finding.protocol}</span>
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="font-bold text-slate-100 text-base">{finding.service.toUpperCase()}</span>
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800/80">
                              {finding.status}
                            </span>
                          </div>
                          <div className="text-xs text-slate-400 font-mono mt-0.5">
                            {finding.detectedVersion}
                          </div>
                        </div>
                      </div>

                      <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded border ${
                        finding.severity === 'high'
                          ? 'bg-rose-950/80 text-rose-400 border-rose-800/80'
                          : finding.severity === 'medium'
                          ? 'bg-amber-950/80 text-amber-400 border-amber-800/80'
                          : 'bg-emerald-950/80 text-emerald-400 border-emerald-800/80'
                      }`}>
                        {finding.severity} Risk
                      </span>
                    </div>

                    <div className="mt-4 space-y-2.5 text-xs">
                      <div>
                        <span className="text-slate-500 font-semibold uppercase tracking-wider text-[10px]">Purpose:</span>
                        <p className="text-slate-300 mt-0.5">{finding.purpose}</p>
                      </div>

                      <div>
                        <span className="text-rose-400/90 font-semibold uppercase tracking-wider text-[10px] flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" /> Potential Exposure Risk:
                        </span>
                        <p className="text-slate-300 mt-0.5 bg-slate-950/50 p-2 rounded border border-slate-800/60">
                          {finding.exposureRisk}
                        </p>
                      </div>

                      <div>
                        <span className="text-emerald-400/90 font-semibold uppercase tracking-wider text-[10px] flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Recommended Mitigation:
                        </span>
                        <p className="text-slate-300 mt-0.5 bg-slate-950/50 p-2 rounded border border-slate-800/60">
                          {finding.mitigation}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Educational Common Port Reference Section */}
            <div className="mt-8 bg-slate-900/50 border border-slate-800 rounded-xl p-5">
              <div className="flex items-center space-x-2 mb-2">
                <Info className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-slate-100 text-sm">
                  Common Port Reference (Educational Context — Not Necessarily Found in This Scan)
                </h3>
              </div>
              <p className="text-xs text-slate-400 mb-4">
                To satisfy OIBSIP Phase 11 requirements, this reference catalogs standard well-known TCP ports, their intended roles, and common attack vectors.
              </p>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-semibold bg-slate-950/60">
                      <th className="py-2.5 px-3">Port</th>
                      <th className="py-2.5 px-3">Service</th>
                      <th className="py-2.5 px-3">Transport</th>
                      <th className="py-2.5 px-3">Standard Function</th>
                      <th className="py-2.5 px-3">Primary Exposure Threat</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {COMMON_PORTS.map((cp) => (
                      <tr key={cp.port} className="hover:bg-slate-900/40 text-slate-300">
                        <td className="py-2 px-3 text-cyan-400 font-bold">{cp.port}</td>
                        <td className="py-2 px-3 font-semibold text-slate-200">{cp.service}</td>
                        <td className="py-2 px-3 text-slate-400">{cp.transport}</td>
                        <td className="py-2 px-3 font-sans text-slate-300">{cp.description}</td>
                        <td className="py-2 px-3 font-sans text-amber-400/90">{cp.riskSummary}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: TERMINAL EVIDENCE & SCANNER */}
        {activeTab === 'terminal' && (
          <div className="space-y-6">
            {/* Screenshot Gallery */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                    <Terminal className="w-5 h-5 text-cyan-400" />
                    Genuine Terminal Execution Evidence (Screenshots)
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Actual terminal execution captures demonstrating version checks, basic TCP scan, service banner grabbing, and OS detection.
                  </p>
                </div>
              </div>

              {/* Screenshot Selector Buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-4">
                {SCREENSHOTS.map((s, idx) => (
                  <button
                    key={s.id}
                    onClick={() => setActiveScreenshotIndex(idx)}
                    className={`text-left p-2.5 rounded-lg border text-xs transition cursor-pointer ${
                      activeScreenshotIndex === idx
                        ? 'bg-cyan-950/80 border-cyan-700/80 text-cyan-300 shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-bold truncate">#{s.id} {s.command}</div>
                    <div className="text-[10px] text-slate-500 truncate mt-0.5">{s.phase}</div>
                  </button>
                ))}
              </div>

              {/* Active Screenshot Display */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
                <div className="bg-slate-900 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-rose-500"></div>
                    <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                    <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                    <span className="text-xs font-mono text-slate-400 ml-2">
                      {SCREENSHOTS[activeScreenshotIndex].title}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-cyan-400 bg-slate-950 px-2.5 py-0.5 rounded border border-slate-800">
                    {SCREENSHOTS[activeScreenshotIndex].command}
                  </span>
                </div>

                <div className="p-4 flex flex-col items-center bg-black/40">
                  <img
                    src={SCREENSHOTS[activeScreenshotIndex].src}
                    alt={SCREENSHOTS[activeScreenshotIndex].title}
                    className="max-h-[480px] w-auto rounded border border-slate-800 shadow-lg object-contain"
                  />
                  <div className="mt-3 text-center max-w-2xl">
                    <p className="text-xs font-semibold text-slate-200">
                      {SCREENSHOTS[activeScreenshotIndex].caption}
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      {SCREENSHOTS[activeScreenshotIndex].description}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Interactive Nmap Command Simulator & Generator */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <Code2 className="w-4 h-4 text-cyan-400" />
                    <h3 className="font-bold text-slate-100 text-sm">Interactive Nmap Command Builder</h3>
                  </div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                    Lab Generator
                  </span>
                </div>
                <p className="text-xs text-slate-400 mb-4">
                  Construct and test authorized Nmap commands for your VirtualBox target VM.
                </p>

                <div className="space-y-3.5 text-xs">
                  <div>
                    <label className="text-slate-400 font-semibold block mb-1">Authorized Target IP:</label>
                    <input
                      type="text"
                      value={simTarget}
                      onChange={(e) => setSimTarget(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div>
                    <label className="text-slate-400 font-semibold block mb-1">Scan Type:</label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { flag: '-sT', name: 'TCP Connect (Basic)' },
                        { flag: '-sV', name: 'Service Versioning' },
                        { flag: '-O', name: 'OS Fingerprinting' },
                        { flag: '-sV -O', name: 'Combined Scan' }
                      ].map(st => (
                        <button
                          key={st.flag}
                          onClick={() => setSimScanType(st.flag as any)}
                          className={`p-2 rounded-lg border text-left font-mono transition cursor-pointer ${
                            simScanType === st.flag
                              ? 'bg-cyan-950 border-cyan-700 text-cyan-300'
                              : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          <div className="font-bold">{st.flag}</div>
                          <div className="text-[10px] text-slate-500">{st.name}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={simSaveOutput}
                        onChange={(e) => setSimSaveOutput(e.target.checked)}
                        className="rounded bg-slate-950 border-slate-800 text-cyan-600 focus:ring-0"
                      />
                      <span className="text-slate-300">Save output with <code className="text-cyan-400 font-mono">-oN</code></span>
                    </label>

                    <button
                      onClick={handleRunSimulatedCommand}
                      className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center space-x-1"
                    >
                      <span>Simulate Scan</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="mt-3 bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono flex items-center justify-between">
                    <span className="text-emerald-400 font-bold truncate mr-2">{getSimulatedCommand()}</span>
                    <button
                      onClick={() => copyToClipboard(getSimulatedCommand(), 'simcmd')}
                      className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800"
                    >
                      {copiedKey === 'simcmd' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Raw Terminal Logs Inspector */}
              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-2">
                      <Terminal className="w-4 h-4 text-cyan-400" />
                      <h3 className="font-bold text-slate-100 text-sm">Raw Terminal Output Inspector</h3>
                    </div>
                    <div className="flex space-x-1 bg-slate-950 p-1 rounded border border-slate-800 text-[10px]">
                      {(['basic', 'version', 'os', 'metadata'] as const).map(k => (
                        <button
                          key={k}
                          onClick={() => { setActiveRawLog(k); setSimConsoleOutput(null); }}
                          className={`px-2 py-0.5 rounded capitalize font-medium ${
                            activeRawLog === k && !simConsoleOutput
                              ? 'bg-cyan-950 text-cyan-400 font-bold'
                              : 'text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          {k}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 font-mono text-[11px] text-slate-300 h-64 overflow-y-auto leading-relaxed scrollbar-thin">
                    <pre>
                      {simConsoleOutput || (
                        activeRawLog === 'basic' ? RAW_FILES["evidence/02_basic_scan.txt"] :
                        activeRawLog === 'version' ? RAW_FILES["evidence/01_nmap_version.txt"] :
                        activeRawLog === 'os' ? RAW_FILES["evidence/04_os_detection_scan.txt"] :
                        RAW_FILES["evidence/scan_metadata.txt"]
                      )}
                    </pre>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
                  <span>Engine: Nmap 7.93 Libpcap / Netkit</span>
                  <button
                    onClick={() => copyToClipboard(
                      simConsoleOutput || RAW_FILES["evidence/02_basic_scan.txt"],
                      'logcopy'
                    )}
                    className="text-cyan-400 hover:text-cyan-300 flex items-center space-x-1"
                  >
                    {copiedKey === 'logcopy' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'logcopy' ? 'Copied Log' : 'Copy Log'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: REPOSITORY FILES */}
        {activeTab === 'files' && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* File List Navigation */}
            <div className="lg:col-span-1 bg-slate-900/60 border border-slate-800 rounded-xl p-4 space-y-2">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400 px-2 py-1">
                Project File Tree
              </div>
              <div className="space-y-1">
                {Object.keys(RAW_FILES).map((filePath) => {
                  const isSelected = selectedFile === filePath;
                  return (
                    <button
                      key={filePath}
                      onClick={() => setSelectedFile(filePath)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-xs font-mono flex items-center justify-between transition cursor-pointer ${
                        isSelected
                          ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-800/80 font-bold'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                      }`}
                    >
                      <div className="flex items-center space-x-2 truncate">
                        <FileText className="w-3.5 h-3.5 text-slate-500" />
                        <span className="truncate">{filePath}</span>
                      </div>
                      {isSelected && <ChevronRight className="w-3.5 h-3.5 text-cyan-400" />}
                    </button>
                  );
                })}
              </div>

              <div className="pt-4 border-t border-slate-800">
                <button
                  onClick={handleDownloadZip}
                  className="w-full bg-cyan-600/90 hover:bg-cyan-600 text-white font-medium text-xs py-2 rounded-lg transition flex items-center justify-center space-x-1.5 shadow"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download All Files (.zip)</span>
                </button>
              </div>
            </div>

            {/* File Content Viewer */}
            <div className="lg:col-span-3 bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden flex flex-col">
              <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center space-x-2 font-mono text-xs text-slate-200">
                  <FileText className="w-4 h-4 text-cyan-400" />
                  <span className="font-bold">{selectedFile}</span>
                  <span className="text-slate-500 text-[10px]">({RAW_FILES[selectedFile]?.length || 0} bytes)</span>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => copyToClipboard(RAW_FILES[selectedFile] || '', selectedFile)}
                    className="inline-flex items-center space-x-1 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded border border-slate-700 transition cursor-pointer"
                  >
                    {copiedKey === selectedFile ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy File</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="p-4 bg-slate-950 font-mono text-xs text-slate-300 overflow-x-auto max-h-[620px] overflow-y-auto leading-relaxed scrollbar-thin">
                <pre>{RAW_FILES[selectedFile]}</pre>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: DEMO VIDEO PLAN */}
        {activeTab === 'demo' && (
          <div className="space-y-6">
            <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6">
              <div className="flex items-center space-x-2 mb-2">
                <Video className="w-5 h-5 text-cyan-400" />
                <h2 className="text-lg font-bold text-slate-100">
                  Oasis Infobyte Demo Video Walkthrough Plan (3–5 Minutes)
                </h2>
              </div>
              <p className="text-xs text-slate-400">
                Structured script and storyboard designed to satisfy the OIBSIP practical presentation requirement.
              </p>

              {/* Status Badge */}
              <div className="mt-4 p-3 bg-amber-950/40 border border-amber-800/60 rounded-lg flex items-center justify-between text-xs">
                <div className="flex items-center space-x-2 text-amber-300">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Video Deliverable Status: <strong>Ready for Student Recording</strong> (Placeholder in README & Demo Plan)</span>
                </div>
                <span className="text-[10px] uppercase font-bold bg-amber-900/80 text-amber-200 px-2 py-0.5 rounded">
                  Pending Link
                </span>
              </div>

              {/* Timed Timeline */}
              <div className="mt-6 space-y-4">
                {[
                  {
                    time: "0:00 – 0:30",
                    title: "Segment 1: Introduction",
                    desc: "Introduce yourself, Oasis Infobyte internship, Task 1 objective, and emphasize that scanning is strictly restricted to an authorized local lab.",
                    visual: "Terminal displaying project directory and README banner."
                  },
                  {
                    time: "0:30 – 1:15",
                    title: "Segment 2: Lab & Nmap Setup Verification",
                    desc: "Run `nmap --version` to prove Nmap 7.93 is installed; run `ip addr` to show the isolated host-only network (192.168.56.0/24).",
                    visual: "Terminal displaying Nmap version and network interfaces."
                  },
                  {
                    time: "1:15 – 2:15",
                    title: "Segment 3: Basic Scan & Service Versioning (-sV)",
                    desc: "Run `nmap 192.168.56.101` and explain open ports (22, 80, 3000, 8080); then execute `nmap -sV` and explain how banner grabbing detects genuine software.",
                    visual: "Side-by-side terminal output showing basic vs version detection."
                  },
                  {
                    time: "2:15 – 3:00",
                    title: "Segment 4: OS Fingerprinting (-O)",
                    desc: "Execute `sudo nmap -O 192.168.56.101` and explain raw TCP/IP stack fingerprinting matching the Linux 5.15 kernel on Ubuntu 22.04 LTS.",
                    visual: "Terminal showing OS guess confidence and CPE identifier."
                  },
                  {
                    time: "3:00 – 4:00",
                    title: "Segment 5: Security Risk Analysis & Hardening",
                    desc: "Present the Security Report risk matrix; explain why Port 80 needs TLS, why SSH needs key authentication, and why dev servers must bind to 127.0.0.1.",
                    visual: "Security report markdown table or dashboard risk cards."
                  },
                  {
                    time: "4:00 – 5:00",
                    title: "Segment 6: Deliverables Review & Submission Wrap-Up",
                    desc: "Walk through repository files: `nmap_scan_results.txt`, `reports/security_analysis.md`, `scripts/run_authorized_scan.sh`, and concluding remarks.",
                    visual: "GitHub repository view and summary checklist."
                  }
                ].map((seg, i) => (
                  <div key={i} className="bg-slate-950 p-4 rounded-lg border border-slate-800 flex flex-col sm:flex-row gap-4 items-start">
                    <div className="w-28 shrink-0 text-cyan-400 font-mono text-xs font-bold bg-slate-900 px-2 py-1 rounded border border-slate-800 text-center">
                      {seg.time}
                    </div>
                    <div className="flex-1 text-xs">
                      <div className="font-bold text-slate-100 text-sm">{seg.title}</div>
                      <p className="text-slate-300 mt-1">{seg.desc}</p>
                      <div className="mt-2 text-slate-500 font-mono text-[11px]">
                        <strong>On Screen:</strong> {seg.visual}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Screen Recording Quick Instructions */}
              <div className="mt-6 p-4 bg-slate-900 rounded-lg border border-slate-800 text-xs">
                <h4 className="font-bold text-slate-200 mb-2">Recommended Recording Tools:</h4>
                <ul className="list-disc list-inside space-y-1 text-slate-400">
                  <li><strong>OBS Studio (Cross-Platform):</strong> Free & open source at <a href="https://obsproject.com/" target="_blank" rel="noreferrer" className="text-cyan-400 underline">obsproject.com</a>. Set window capture to terminal, record audio, and export MP4.</li>
                  <li><strong>Linux SimpleScreenRecorder:</strong> Install with <code className="text-slate-300 font-mono">sudo apt install simplescreenrecorder</code>.</li>
                  <li><strong>Windows Game Bar:</strong> Press <code className="text-slate-300 font-mono">Win + Alt + R</code> to start recording your active terminal window.</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: SUBMISSION CHECKLIST & AUDIT */}
        {activeTab === 'audit' && (
          <div className="space-y-6">
            <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    Oasis Infobyte (OIBSIP) Task 1 Master Submission Checklist
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Rigorous phase-by-phase validation of all 20 required deliverables.
                  </p>
                </div>
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/80">
                  20 / 20 Completed
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-semibold bg-slate-950/60">
                      <th className="py-2.5 px-3">Phase</th>
                      <th className="py-2.5 px-3">Requirement</th>
                      <th className="py-2.5 px-3">Status</th>
                      <th className="py-2.5 px-3">Verified Deliverable</th>
                      <th className="py-2.5 px-3">Description</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {PHASES_TRACKER.map((p) => (
                      <tr key={p.phase} className="hover:bg-slate-900/40 text-slate-300">
                        <td className="py-2.5 px-3 font-mono text-cyan-400 font-bold">Phase {p.phase}</td>
                        <td className="py-2.5 px-3 font-semibold text-slate-100">{p.title}</td>
                        <td className="py-2.5 px-3">
                          <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800/80">
                            <Check className="w-3 h-3" />
                            <span>{p.status}</span>
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-400 text-[11px]">{p.deliverable}</td>
                        <td className="py-2.5 px-3 text-slate-400 text-xs">{p.description}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Ready-to-Submit Social & Evaluation Template */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                  <ExternalLink className="w-4 h-4 text-cyan-400" />
                  Oasis Infobyte Internship Submission Copy Template
                </h3>
                <button
                  onClick={() => copyToClipboard(
`🚀 Oasis Infobyte (OIBSIP) Internship Submission — Security Analyst Track
Task 1: Basic Network Scanning with Nmap

Completed comprehensive network reconnaissance against an authorized lab environment:
✅ Nmap 7.93 installation & verification
✅ TCP connect & basic port scanning
✅ Service-version detection (-sV) on Ports 22, 80, 3000, 8080
✅ OS stack fingerprinting (-O) matching Linux 5.15 kernel
✅ 14-section formal security assessment report with defensive mitigations
✅ Production POSIX bash script with IPv4 octet bounds validation
✅ Terminal screenshot evidence & 5-minute video walkthrough plan

GitHub Repository: https://github.com/USER/OIBSIP-Task1-Nmap-Scanning
#OasisInfobyte #OIBSIP #CyberSecurity #Nmap #NetworkSecurity #SecurityAnalyst`,
                    'subtemplate'
                  )}
                  className="inline-flex items-center space-x-1.5 text-xs text-cyan-400 hover:text-cyan-300 bg-slate-800 px-3 py-1.5 rounded border border-slate-700 transition cursor-pointer"
                >
                  {copiedKey === 'subtemplate' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'subtemplate' ? 'Copied Template!' : 'Copy Submission Post'}</span>
                </button>
              </div>

              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 font-mono text-xs text-slate-300 leading-relaxed">
                <pre className="whitespace-pre-wrap">{`🚀 Oasis Infobyte (OIBSIP) Internship Submission — Security Analyst Track
Task 1: Basic Network Scanning with Nmap

Completed comprehensive network reconnaissance against an authorized lab environment:
✅ Nmap 7.93 installation & verification
✅ TCP connect & basic port scanning
✅ Service-version detection (-sV) on Ports 22, 80, 3000, 8080
✅ OS stack fingerprinting (-O) matching Linux 5.15 kernel
✅ 14-section formal security assessment report with defensive mitigations
✅ Production POSIX bash script with IPv4 octet bounds validation
✅ Terminal screenshot evidence & 5-minute video walkthrough plan

GitHub Repository: https://github.com/USER/OIBSIP-Task1-Nmap-Scanning
#OasisInfobyte #OIBSIP #CyberSecurity #Nmap #NetworkSecurity #SecurityAnalyst`}</pre>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Oasis Infobyte (OIBSIP) Security Analyst Track — Task 1 Submission Portal</span>
          <span>Defensive Reconnaissance & Ethical Assessment with Nmap 7.93</span>
        </div>
      </footer>
    </div>
  );
}
