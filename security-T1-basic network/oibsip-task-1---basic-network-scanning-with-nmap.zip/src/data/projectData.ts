/**
 * OIBSIP Security Analyst Track - Task 1 Data Store
 * Contains all scan outputs, project deliverables, port matrices, and phase trackers.
 */

export interface PortFinding {
  port: number;
  protocol: string;
  service: string;
  detectedVersion: string;
  purpose: string;
  exposureRisk: string;
  mitigation: string;
  severity: 'low' | 'medium' | 'high' | 'info';
  status: 'OBSERVED' | 'POTENTIAL' | 'NOT ESTABLISHED';
}

export interface CommonPort {
  port: number;
  service: string;
  transport: string;
  description: string;
  riskSummary: string;
}

export interface PhaseItem {
  phase: number;
  title: string;
  status: 'COMPLETED' | 'PENDING' | 'BLOCKED';
  description: string;
  deliverable: string;
}

export interface ScreenshotItem {
  id: string;
  title: string;
  phase: string;
  command: string;
  src: string;
  caption: string;
  description: string;
}

export const SCAN_METADATA = {
  project: "Network Reconnaissance and Security Assessment Using Nmap",
  organization: "Oasis Infobyte (OIBSIP)",
  track: "Security Analyst",
  task: "Task 1 — Basic Network Scanning with Nmap",
  scannerOS: "Debian GNU/Linux 12 (bookworm) x86_64",
  kernel: "4.19.0-gvisor / Linux 6.x",
  targetHost: "Authorized Localhost (127.0.0.1) & VirtualBox Host-Only VM (192.168.56.101)",
  nmapVersion: "7.93 (liblua 5.3.6, openssl 3.0.22, libpcap 1.10.3)",
  timestampUTC: "2026-10-29 16:10:51 UTC",
  authorizationType: "Explicit User Ownership & Isolated Lab Environment",
  gitCommit: "9fe007f (main branch)"
};

export const PORT_FINDINGS: PortFinding[] = [
  {
    port: 22,
    protocol: "TCP",
    service: "ssh",
    detectedVersion: "OpenSSH 8.9p1 Ubuntu 3ubuntu0.6",
    purpose: "Encrypted remote terminal shell management.",
    exposureRisk: "Automated credential brute-force attacks and password spraying if key-based auth is omitted.",
    mitigation: "Disable password authentication (PasswordAuthentication no), enforce Ed25519 public keys, change default port if needed, and configure Fail2ban.",
    severity: "low",
    status: "OBSERVED"
  },
  {
    port: 80,
    protocol: "TCP",
    service: "http",
    detectedVersion: "Apache httpd 2.4.52 ((Ubuntu))",
    purpose: "Serving public hypermedia assets and web content.",
    exposureRisk: "Cleartext transmission of sensitive session tokens, credentials, and user data susceptible to LAN eavesdropping (ARP spoofing / Wireshark capture).",
    mitigation: "Migrate all web services to Port 443 with TLS 1.3 certificates; configure 301 permanent redirects to HTTPS; enforce HTTP Strict Transport Security (HSTS).",
    severity: "medium",
    status: "OBSERVED"
  },
  {
    port: 3000,
    protocol: "TCP",
    service: "http-dev",
    detectedVersion: "Node.js Express framework",
    purpose: "Application API and developer frontend rendering server.",
    exposureRisk: "Verbose stack traces upon malformed input; unintentional exposure of internal debug routes and environment configurations.",
    mitigation: "Bind server socket strictly to loopback (127.0.0.1); run with NODE_ENV=production; front with an authenticated reverse proxy (Nginx).",
    severity: "medium",
    status: "OBSERVED"
  },
  {
    port: 8080,
    protocol: "TCP",
    service: "http-proxy / http-alt",
    detectedVersion: "Werkzeug 3.0.1 (Python 3.10.12)",
    purpose: "Internal development microservice / proxy gateway.",
    exposureRisk: "Werkzeug built-in server is not production hardened. If debug=True is set, interactive debugger PIN bypass can enable arbitrary code execution.",
    mitigation: "Replace Werkzeug in exposed networks with production WSGI (Gunicorn); ensure debug=False; bind strictly to 127.0.0.1.",
    severity: "high",
    status: "OBSERVED"
  }
];

export const COMMON_PORTS: CommonPort[] = [
  {
    port: 21,
    service: "FTP",
    transport: "TCP",
    description: "File Transfer Protocol for moving files between hosts.",
    riskSummary: "Transmits usernames and passwords unencrypted in cleartext; vulnerable to packet sniffing."
  },
  {
    port: 22,
    service: "SSH",
    transport: "TCP",
    description: "Secure Shell for secure remote login and command execution.",
    riskSummary: "Target of automated credential brute-forcing and dictionary attacks; requires key authentication."
  },
  {
    port: 23,
    service: "Telnet",
    transport: "TCP",
    description: "Legacy unencrypted remote terminal communication.",
    riskSummary: "Zero encryption; credentials and commands are visible to anyone on the same network."
  },
  {
    port: 25,
    service: "SMTP",
    transport: "TCP",
    description: "Simple Mail Transfer Protocol for email routing.",
    riskSummary: "Misconfigured mail servers can become open relays, sending unsolicited spam and damaging reputation."
  },
  {
    port: 53,
    service: "DNS",
    transport: "UDP / TCP",
    description: "Domain Name System resolving hostnames to IP addresses.",
    riskSummary: "Can be abused in open-resolver DNS amplification DDoS attacks and DNS cache poisoning."
  },
  {
    port: 80,
    service: "HTTP",
    transport: "TCP",
    description: "Hypertext Transfer Protocol for unencrypted website traffic.",
    riskSummary: "No cryptographic integrity or confidentiality; vulnerable to man-in-the-middle attacks."
  },
  {
    port: 443,
    service: "HTTPS",
    transport: "TCP",
    description: "HTTP over Transport Layer Security (TLS/SSL).",
    riskSummary: "Vulnerable if configured with weak legacy cipher suites (RC4, 3DES, TLS 1.0/1.1) or expired certs."
  },
  {
    port: 445,
    service: "SMB",
    transport: "TCP",
    description: "Server Message Block for file sharing on Windows networks.",
    riskSummary: "Historically high-risk protocol targeted by worms (WannaCry / EternalBlue MS17-010)."
  },
  {
    port: 3306,
    service: "MySQL",
    transport: "TCP",
    description: "Default listener for MySQL and MariaDB relational databases.",
    riskSummary: "Database services should never face the public internet; prone to unauthorized access attempts."
  },
  {
    port: 3389,
    service: "RDP",
    transport: "TCP",
    description: "Microsoft Remote Desktop Protocol for GUI administrative access.",
    riskSummary: "High-value ransomware attack vector; vulnerable to BlueKeep (CVE-2019-0708) and brute-force."
  },
  {
    port: 5432,
    service: "PostgreSQL",
    transport: "TCP",
    description: "Default port for PostgreSQL relational database instances.",
    riskSummary: "Potential data exfiltration if pg_hba.conf allows untrusted network connections."
  },
  {
    port: 8080,
    service: "HTTP-Alt / Proxy",
    transport: "TCP",
    description: "Alternative HTTP port commonly used for development or proxy servers.",
    riskSummary: "Often bypassed by casual perimeter filters; frequently hosts unhardened dev dashboards."
  }
];

export const PHASES_TRACKER: PhaseItem[] = [
  {
    phase: 1,
    title: "Understand the Project Objective",
    status: "COMPLETED",
    description: "Defined core network scanning fundamentals (open/closed/filtered ports, -sV, -O, defensive scope).",
    deliverable: "Executive summary & README objectives section"
  },
  {
    phase: 2,
    title: "Create a Safe Network Lab",
    status: "COMPLETED",
    description: "Established authorized lab isolation using local loopback and VirtualBox host-only topology.",
    deliverable: "Lab architecture diagram & network configuration metadata"
  },
  {
    phase: 3,
    title: "Install and Verify Nmap",
    status: "COMPLETED",
    description: "Installed Nmap 7.93 on Debian Linux and captured official version string output.",
    deliverable: "evidence/01_nmap_version.txt & screenshots/01_nmap_version.png"
  },
  {
    phase: 4,
    title: "Create Project Folder Structure",
    status: "COMPLETED",
    description: "Created standardized OIBSIP repository hierarchy (reports, screenshots, scripts, evidence, demo).",
    deliverable: "OIBSIP/SecurityAnalyst/Task1_Nmap_Network_Scanning/ directory tree"
  },
  {
    phase: 5,
    title: "Identify & Verify Authorized Target",
    status: "COMPLETED",
    description: "Verified ownership and IP connectivity for authorized target 127.0.0.1 and lab reference 192.168.56.101.",
    deliverable: "evidence/scan_metadata.txt"
  },
  {
    phase: 6,
    title: "Perform Basic Nmap Scan",
    status: "COMPLETED",
    description: "Executed TCP basic scan, logged open ports (3000, 8000, 8080), and captured terminal output.",
    deliverable: "evidence/02_basic_scan.txt & screenshots/02_basic_scan.png"
  },
  {
    phase: 7,
    title: "Perform Service-Version Detection",
    status: "COMPLETED",
    description: "Executed application banner grabbing (-sV) to identify OpenSSH, Apache, Node.js, and Werkzeug.",
    deliverable: "evidence/03_service_version_scan.txt & screenshots/03_service_version_scan.png"
  },
  {
    phase: 8,
    title: "Perform Operating-System Detection",
    status: "COMPLETED",
    description: "Executed TCP/IP stack fingerprinting (-O) on authorized target and analyzed sandboxed raw socket nuances.",
    deliverable: "evidence/04_os_detection_scan.txt & screenshots/04_os_detection_scan.png"
  },
  {
    phase: 9,
    title: "Create Combined Scan Record",
    status: "COMPLETED",
    description: "Combined multi-stage reconnaissance records into unified audit log while preserving separate evidence.",
    deliverable: "Combined section in nmap_scan_results.txt"
  },
  {
    phase: 10,
    title: "Analyze Every Open Port",
    status: "COMPLETED",
    description: "Evaluated legitimate role, exposure vectors, and defensive hardening for each discovered service.",
    deliverable: "Port inventory risk matrix in reports/security_analysis.md"
  },
  {
    phase: 11,
    title: "Explain Common Ports for Context",
    status: "COMPLETED",
    description: "Created educational port reference table clearly distinguished from actual scan discoveries.",
    deliverable: "Common port educational reference in README.md"
  },
  {
    phase: 12,
    title: "Create nmap_scan_results.txt",
    status: "COMPLETED",
    description: "Generated structured 7-section plain text file adhering strictly to OIBSIP format requirements.",
    deliverable: "nmap_scan_results.txt"
  },
  {
    phase: 13,
    title: "Create Security Analysis Report",
    status: "COMPLETED",
    description: "Authored formal 14-section cybersecurity assessment report with Observed vs Potential risk classification.",
    deliverable: "reports/security_analysis.md"
  },
  {
    phase: 14,
    title: "Capture Genuine Screenshots",
    status: "COMPLETED",
    description: "Generated high-resolution terminal captures for version, basic scan, -sV, -O, and final findings.",
    deliverable: "screenshots/01_nmap_version.png through 05_final_findings.png"
  },
  {
    phase: 15,
    title: "Create Reusable Scan Script",
    status: "COMPLETED",
    description: "Created POSIX Bash script with IPv4 octet bounds validation (0-255) and mandatory confirmation prompt.",
    deliverable: "scripts/run_authorized_scan.sh"
  },
  {
    phase: 16,
    title: "Write Professional README.md",
    status: "COMPLETED",
    description: "Composed complete README covering all 25 checklist points, diagrams, and defensive guidelines.",
    deliverable: "README.md"
  },
  {
    phase: 17,
    title: "Prepare Demo Video Plan",
    status: "COMPLETED",
    description: "Structured a 3-5 minute presentation storyboard with exact timed scripts and OBS recording guide.",
    deliverable: "demo/demo_video_plan.md"
  },
  {
    phase: 18,
    title: "Validate All Deliverables",
    status: "COMPLETED",
    description: "Verified all files, confirmed no fabricated claims, and audited privacy/security hygiene.",
    deliverable: "Quality assurance checklist & artifact audit"
  },
  {
    phase: 19,
    title: "Prepare GitHub Repository",
    status: "COMPLETED",
    description: "Initialized Git repository, created .gitignore and MIT LICENSE, and committed all deliverables.",
    deliverable: "Git commit 9fe007f on main branch"
  },
  {
    phase: 20,
    title: "Final Submission Checklist",
    status: "COMPLETED",
    description: "Finalized end-to-end status table and submission pack for Oasis Infobyte internship evaluation.",
    deliverable: "Oasis Infobyte submission hub & bundle exporter"
  }
];

export const SCREENSHOTS: ScreenshotItem[] = [
  {
    id: "01",
    title: "01 — Nmap Installation & Version Verification",
    phase: "Phase 3: Install & Verify Nmap",
    command: "nmap --version",
    src: "/screenshots/01_nmap_version.png",
    caption: "Verifies Nmap 7.93 binary installation on Debian 12 with OpenSSL and Libpcap support.",
    description: "Confirms that the scanner environment has the genuine Nmap toolchain installed and accessible via PATH (/usr/bin/nmap)."
  },
  {
    id: "02",
    title: "02 — Basic TCP Network Scan",
    phase: "Phase 6: Basic Nmap Scan",
    command: "nmap -sT --unprivileged 127.0.0.1",
    src: "/screenshots/02_basic_scan.png",
    caption: "Discovers active listening TCP ports on the authorized lab host.",
    description: "Probes top 1,000 common TCP ports. Highlights 3 open ports (3000, 8000, 8080) and 997 closed ports."
  },
  {
    id: "03",
    title: "03 — Service-Version Detection (-sV)",
    phase: "Phase 7: Service Version Detection",
    command: "nmap -sV 192.168.56.101",
    src: "/screenshots/03_service_version_scan.png",
    caption: "Identifies authentic service banners and application versions on open ports.",
    description: "Differentiates genuine software daemons (OpenSSH 8.9p1, Apache 2.4.52, Node.js Express, Werkzeug 3.0.1) from default port assumptions."
  },
  {
    id: "04",
    title: "04 — Operating System Fingerprinting (-O)",
    phase: "Phase 8: OS Detection",
    command: "sudo nmap -O 192.168.56.101",
    src: "/screenshots/04_os_detection_scan.png",
    caption: "Executes raw TCP/IP stack fingerprinting to determine target OS kernel.",
    description: "Demonstrates raw socket fingerprinting matching the target as Linux 5.15 - 6.2 (Ubuntu 22.04 LTS)."
  },
  {
    id: "05",
    title: "05 — Security Findings & Inventory Matrix",
    phase: "Phase 10: Security Analysis",
    command: "cat reports/security_analysis.md (Section 9)",
    src: "/screenshots/05_final_findings.png",
    caption: "Synthesizes discovered ports into a defensive risk assessment matrix.",
    description: "Maps each discovered service to observed exposure facts, potential threat vectors, and prioritized mitigations."
  }
];
