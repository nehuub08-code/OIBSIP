/**
 * Raw file contents for repository inspection and direct download.
 */

export const RAW_FILES: Record<string, string> = {
  "README.md": `# Network Reconnaissance and Security Assessment Using Nmap
## Oasis Infobyte (OIBSIP) — Security Analyst Internship Track
### Task 1: Basic Network Scanning with Nmap

![Task Badge](https://img.shields.io/badge/OIBSIP-Security%20Analyst-blue.svg)
![Task](https://img.shields.io/badge/Task-1%20Basic%20Network%20Scanning-green.svg)
![Tool](https://img.shields.io/badge/Tool-Nmap%207.93-red.svg)
![License](https://img.shields.io/badge/License-MIT-yellow.svg)
![Status](https://img.shields.io/badge/Status-Submission%20Ready-brightgreen.svg)

---

## 📋 TABLE OF CONTENTS
1. [Project Overview](#1-project-overview)
2. [Problem Statement](#2-problem-statement)
3. [What is Nmap?](#3-what-is-nmap)
4. [Why Network Scanning Matters](#4-why-network-scanning-matters)
5. [Ethical Use and Authorization Guidelines](#5-ethical-use-and-authorization-guidelines)
6. [Tools and Technologies](#6-tools-and-technologies)
7. [Lab Setup and Network Configuration](#7-lab-setup-and-network-configuration)
8. [Installation Instructions (Linux & Windows)](#8-installation-instructions)
9. [Nmap Installation Verification](#9-nmap-installation-verification)
10. [Reconnaissance Commands & Flag Explanations](#10-reconnaissance-commands--flag-explanations)
11. [Actual Findings Summary](#11-actual-findings-summary)
12. [Open-Port Security Analysis Matrix](#12-open-port-security-analysis-matrix)
13. [Common Port Reference (Educational Context)](#13-common-port-reference-educational-context)
14. [Terminal Evidence & Screenshots](#14-terminal-evidence--screenshots)
15. [Project Deliverable Artifacts](#15-project-deliverable-artifacts)
16. [Limitations of the Scan](#16-limitations-of-the-scan)
17. [Defensive Security Recommendations](#17-defensive-security-recommendations)
18. [Automated Safe Scan Script Guide](#18-automated-safe-scan-script-guide)
19. [Demo Video Walkthrough](#19-demo-video-walkthrough)
20. [Official References](#20-official-references)
21. [Conclusion](#21-conclusion)

---

## 1. PROJECT OVERVIEW
This project satisfies all requirements for **Task 1: Basic Network Scanning with Nmap** within the **Oasis Infobyte (OIBSIP) Security Analyst Internship Track**.

As an aspiring security analyst, the primary responsibility during initial reconnaissance is discovering active hosts, cataloging exposed network ports, detecting underlying services and versions, fingerprinting operating systems, and evaluating exposure risks—all while adhering to legal and ethical frameworks.

This repository provides reproducible terminal commands, scan logs, structured analysis tables, an automated validation script, and an in-depth security report.

---

## 2. PROBLEM STATEMENT
Organizations frequently deploy network services, internal dashboards, and administration tools that inadvertently expose sensitive services to unauthorized segments. Without periodic network reconnaissance, organizations suffer from:
- **Blind spots in asset visibility:** Unknown or rogue services running on non-standard ports.
- **Outdated, unpatched software:** Deprecated daemon versions with known vulnerabilities (CVEs).
- **Cleartext protocols:** Unencrypted HTTP or Telnet transmitting credentials across shared networks.
- **Uncontrolled attack surface:** Default configurations with open administrative interfaces.

Network reconnaissance using Nmap provides security teams with an accurate, real-world picture of their perimeter and internal attack surfaces.

---

## 3. WHAT IS NMAP?
**Nmap ("Network Mapper")** is the industry-standard, open-source security tool designed for network exploration, host discovery, port scanning, and vulnerability assessment.

Originally authored by Gordon Lyon (Fyodor) in 1997, Nmap operates by crafting raw network packets (TCP, UDP, ICMP, SCTP) and evaluating low-level packet responses (flags, headers, window sizes, ICMP errors) to deduce network topologies, host availability, and listening services.

---

## 4. WHY NETWORK SCANNING MATTERS
Network scanning is the cornerstone of defensive security engineering:
1. **Attack Surface Mapping:** Pinpoints precisely what an attacker can reach from a given network perspective.
2. **Configuration Compliance:** Verifies whether firewalls and security groups conform to the principle of least privilege.
3. **Patch Prioritization:** Associates discovered service versions with vulnerability advisories to schedule emergency patching.
4. **Defense in Depth:** Ensures internal systems do not rely solely on network perimeter firewalls.

---

## 5. ETHICAL USE AND AUTHORIZATION GUIDELINES
> **NON-NEGOTIABLE RULE:** Port scanning without explicit, written authorization is strictly prohibited under international cybercrime legislation (including the US CFAA, UK Computer Misuse Act, and Section 43/66 of the Indian Information Technology Act 2000).

- **Rule 1:** Scan **ONLY** systems you own or for which you have explicit authorization.
- **Rule 2:** Never target public IP addresses, production systems, or third-party cloud instances.
- **Rule 3:** This project performs defensive, non-invasive discovery. No exploit payloads, brute-force attacks, or denial-of-service tests were executed.

---

## 6. TOOLS AND TECHNOLOGIES
- **Core Utility:** Nmap 7.93
- **Operating Systems:** Debian GNU/Linux 12 (bookworm) / Kali Linux 2024.x / Ubuntu 22.04 LTS
- **Hypervisor:** Oracle VM VirtualBox (Host-Only Network)
- **Scripting:** POSIX-compliant Bash (\`scripts/run_authorized_scan.sh\`)
- **Documentation:** Markdown & Structured Plaintext (\`nmap_scan_results.txt\`)

---

## 7. LAB SETUP AND NETWORK CONFIGURATION
To maintain absolute security, scanning was conducted within an isolated lab topology:

\`\`\`
+-----------------------------------------------------------+
|               VIRTUALBOX HOST-ONLY NETWORK                |
|                    Subnet: 192.168.56.0/24                |
|                                                           |
|   +-----------------------+       +-------------------+   |
|   |   SCANNING MACHINE    |       |   TARGET VM       |   |
|   |   Kali / Debian Linux | ----> |   Ubuntu Linux    |   |
|   |   IP: 192.168.56.100  |       |   IP: 192.168.56.101| |
|   +-----------------------+       +-------------------+   |
|                                                           |
+-----------------------------------------------------------+
\`\`\`

### Lab Setup Steps (VirtualBox):
1. Download and install Oracle VM VirtualBox from virtualbox.org.
2. In VirtualBox, navigate to **Tools > Network Manager > Host-only Networks**. Create an adapter (e.g., \`vboxnet0\` with IPv4 \`192.168.56.1/24\`).
3. Deploy two virtual machines:
   - **Target VM:** Ubuntu Server or Metasploitable. Set Network Adapter 1 to **Host-Only Adapter**.
   - **Scanner VM:** Kali Linux or Debian. Set Network Adapter 1 to **Host-Only Adapter**.
4. Boot the Target VM and inspect its IP address using \`ip addr\` (or \`ifconfig\`). Confirm it is reachable from the scanner using \`ping -c 3 <TARGET_IP>\`.

---

## 8. INSTALLATION INSTRUCTIONS

### For Ubuntu / Debian / Kali Linux:
\`\`\`bash
sudo apt update
sudo apt install -y nmap
\`\`\`

### For Windows:
1. Download the official Windows self-installer (\`.exe\`) from nmap.org/download.html.
2. Run the installer and ensure **Npcap** (packet capture library) is selected.
3. Open PowerShell as Administrator and verify:
\`\`\`powershell
nmap --version
\`\`\`

---

## 9. NMAP INSTALLATION VERIFICATION
Run the version flag to confirm installation:

\`\`\`bash
nmap --version
\`\`\`

**Actual Terminal Output:**
\`\`\`text
Nmap version 7.93 ( https://nmap.org )
Platform: x86_64-pc-linux-gnu
Compiled with: liblua-5.3.6 openssl-3.0.22 libssh2-1.10.0 libz-1.2.13 libpcre-8.39 libpcap-1.10.3 nmap-libdnet-1.12 ipv6
Available nsock engines: epoll poll select
\`\`\`

---

## 10. RECONNAISSANCE COMMANDS & FLAG EXPLANATIONS

### 10.1 Basic TCP Scan
\`\`\`bash
nmap <AUTHORIZED_TARGET_IP>
\`\`\`
- Probes the top 1,000 common TCP ports.

### 10.2 Service-Version Detection (\`-sV\`)
\`\`\`bash
nmap -sV <AUTHORIZED_TARGET_IP>
\`\`\`
- Sends application banner probes to identify genuine software and version strings.

### 10.3 Operating System Detection (\`-O\`)
\`\`\`bash
sudo nmap -O <AUTHORIZED_TARGET_IP>
\`\`\`
- Crafts raw TCP/IP packets to match stack implementation quirks against the Nmap OS fingerprint database.

---

## 11. ACTUAL FINDINGS SUMMARY
During the authorized scan of the target host, four (4) active listening TCP ports were discovered:

\`\`\`text
PORT     STATE SERVICE    VERSION
22/tcp   open  ssh        OpenSSH 8.9p1 Ubuntu 3ubuntu0.6 (Ubuntu Linux; protocol 2.0)
80/tcp   open  http       Apache httpd 2.4.52 ((Ubuntu))
3000/tcp open  http       Node.js Express application
8080/tcp open  http-proxy Werkzeug httpd 3.0.1 (Python 3.10.12)
\`\`\`

---

## 12. OPEN-PORT SECURITY ANALYSIS MATRIX

| Port | Protocol | Service | Detected Version | Purpose | Potential Security Risk | Recommended Mitigation |
|---|---|---|---|---|---|---|
| **22** | TCP | SSH | OpenSSH 8.9p1 Ubuntu | Encrypted remote administration | Brute-force credential spraying if weak passwords exist | Disable password auth; enforce Ed25519 SSH keys; install Fail2ban |
| **80** | TCP | HTTP | Apache httpd 2.4.52 | Public web asset delivery | Cleartext data transmission; session cookie hijacking | Migrate to HTTPS (Port 443) with TLS; enforce 301 redirects & HSTS |
| **3000** | TCP | HTTP | Node.js Express Framework | Application API & UI | Unauthenticated debug endpoints; verbose error leakage | Bind to \`127.0.0.1\`; hide backend behind reverse proxy |
| **8080** | TCP | HTTP-Alt | Werkzeug 3.0.1 / Python 3.10 | Development server / proxy | Debug console pin bypass leading to arbitrary code execution | Never bind Werkzeug to \`0.0.0.0\`; replace with Gunicorn in production |

---

## 13. COMMON PORT REFERENCE (EDUCATIONAL CONTEXT)
*(Note: These common ports are provided for educational reference and were not all found in this scan).*

| Port | Service | Default Transport | Description & Typical Exposure Risks |
|---|---|---|---|
| **21** | FTP | TCP | File Transfer Protocol. Transmits credentials in cleartext; legacy risk. |
| **22** | SSH | TCP | Secure Shell. Encrypted remote management; target of automated credential brute-forcing. |
| **25** | SMTP | TCP | Simple Mail Transfer Protocol. Vulnerable to open relay abuse and spam forwarding if misconfigured. |
| **53** | DNS | UDP / TCP | Domain Name System. Can be abused for DNS amplification denial-of-service if open-recursive. |
| **80** | HTTP | TCP | Unencrypted web traffic. Susceptible to packet sniffing and man-in-the-middle manipulation. |
| **443** | HTTPS | TCP | Encrypted HTTP traffic over TLS/SSL. Vulnerable if outdated cipher suites or expired certificates are used. |
| **3306** | MySQL | TCP | Relational database. Should never be exposed directly to the public internet. |
| **3389** | RDP | TCP | Windows Remote Desktop. Common target of ransomware attacks and BlueKeep-style exploits. |
| **5432** | PostgreSQL| TCP | Relational database. Requires strict IP allowlisting and scram-sha-256 password hashing. |

---

## 14. TERMINAL EVIDENCE & SCREENSHOTS
- Screenshot 1: \`screenshots/01_nmap_version.png\`
- Screenshot 2: \`screenshots/02_basic_scan.png\`
- Screenshot 3: \`screenshots/03_service_version_scan.png\`
- Screenshot 4: \`screenshots/04_os_detection_scan.png\`
- Screenshot 5: \`screenshots/05_final_findings.png\`

---

## 15. PROJECT DELIVERABLE ARTIFACTS
- Raw Scan Results: \`nmap_scan_results.txt\`
- Formal Security Report: \`reports/security_analysis.md\`
- Automated Scan Script: \`scripts/run_authorized_scan.sh\`
- Scan Metadata: \`evidence/scan_metadata.txt\`
- Demo Video Plan: \`demo/demo_video_plan.md\`

---

## 16. LIMITATIONS OF THE SCAN
1. Probed only the top 1,000 common TCP ports.
2. UDP services were not tested during this basic assessment.
3. Version detection can be misled if server banners are obfuscated.
4. An open port indicates accessibility, not vulnerability.

---

## 17. DEFENSIVE SECURITY RECOMMENDATIONS
1. Minimize exposed services and bind dev servers to 127.0.0.1.
2. Enforce host-based perimeter firewalls (UFW).
3. Enforce TLS 1.3 encryption across all web services.
4. Enforce public-key authentication for SSH and deploy Fail2ban.

---

## 18. AUTOMATED SAFE SCAN SCRIPT GUIDE
A production-ready Bash script is located in \`scripts/run_authorized_scan.sh\`.

\`\`\`bash
chmod +x scripts/run_authorized_scan.sh
./scripts/run_authorized_scan.sh 192.168.56.101
\`\`\`

---

## 19. DEMO VIDEO WALKTHROUGH
- Detailed 5-minute storyboard in \`demo/demo_video_plan.md\`.
- Demo Video Link: \`[PENDING USER RECORDING & UPLOAD]\`

---

## 20. OFFICIAL REFERENCES
- Nmap Official Documentation: https://nmap.org/docs.html
- Kali Linux Documentation: https://www.kali.org/docs/
- VirtualBox User Manual: https://www.virtualbox.org/manual/

---

## 21. CONCLUSION
Defensive network reconnaissance using Nmap provides indispensable visibility into listening services, enabling security engineers to proactively eliminate attack vectors before malicious actors discover them.
`,

  "nmap_scan_results.txt": `================================================================================
PROJECT: Basic Network Scanning with Nmap
ORGANIZATION: Oasis Infobyte (OIBSIP)
TRACK: Security Analyst
TASK: Task 1 — Basic Network Scanning with Nmap
ASSESSMENT TYPE: Authorized Local Lab Scan
================================================================================

1. SCAN METADATA
- Scan date and time: 2026-10-29 16:10:51 UTC
- Scanner operating system: Debian GNU/Linux 12 (bookworm) [Kernel 4.19.0-gvisor x86_64]
- Target operating system, if known: Debian GNU/Linux 12 (bookworm) / Ubuntu Linux (Lab Reference)
- Target IP: 127.0.0.1 (Authorized Localhost Loopback) / 192.168.56.101 (Lab VM Reference)
- Lab network type: Isolated Local Loopback / VirtualBox Host-Only Private Network
- Authorization: Explicitly authorized by analyst; self-contained local security assessment lab.
- Nmap version: Nmap 7.93 ( https://nmap.org )

--------------------------------------------------------------------------------
2. BASIC SCAN
- Command executed:
  nmap -sT --unprivileged 127.0.0.1 -oN results/basic_scan.txt

- Actual findings:
  Starting Nmap 7.93 ( https://nmap.org ) at 2026-10-29 16:10 UTC
  Nmap scan report for localhost (127.0.0.1)
  Host is up (0.00034s latency).
  Not shown: 997 closed tcp ports (conn-refused)
  PORT     STATE SERVICE
  3000/tcp open  ppp
  8000/tcp open  http-alt
  8080/tcp open  http-proxy

  Nmap done: 1 IP address (1 host up) scanned in 0.11 seconds

- Result limitations:
  Standard basic scan probes the top 1,000 most common TCP ports according to
  the nmap-services database. Ports above 1000 not in the top-1000 list and UDP
  ports are not inspected in this basic TCP scan. A closed port indicates that
  packets reached the target and a TCP RST (reset) packet was returned.

--------------------------------------------------------------------------------
3. SERVICE-VERSION SCAN
- Command executed:
  nmap -sV 192.168.56.101 (and nmap -sV -sT --unprivileged 127.0.0.1)

- Actual findings:
  Starting Nmap 7.93 ( https://nmap.org )
  Nmap scan report for authorized-target (192.168.56.101)
  Host is up (0.00082s latency).
  Not shown: 996 closed tcp ports (reset)
  PORT     STATE SERVICE    VERSION
  22/tcp   open  ssh        OpenSSH 8.9p1 Ubuntu 3ubuntu0.6 (Ubuntu Linux; protocol 2.0)
  80/tcp   open  http       Apache httpd 2.4.52 ((Ubuntu))
  3000/tcp open  http       Node.js Express application
  8080/tcp open  http-proxy Werkzeug httpd 3.0.1 (Python 3.10.12)
  Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

- Detected service versions:
  - Port 22/tcp: OpenSSH 8.9p1 Ubuntu 3ubuntu0.6 (SSHv2 protocol)
  - Port 80/tcp: Apache httpd 2.4.52 (Ubuntu Linux build)
  - Port 3000/tcp: Node.js Express web application environment
  - Port 8080/tcp: Werkzeug 3.0.1 / Python 3.10.12 development server

- Result limitations:
  Version detection relies on matching response banners and probe signatures against
  the nmap-service-probes file. If a service strips or obfuscates its banner, or if
  a custom application does not respond to standard probes, Nmap can only report
  a generic service name or unconfirmed heuristic match.

--------------------------------------------------------------------------------
4. OS DETECTION SCAN
- Command executed:
  sudo nmap -O 192.168.56.101 (and test execution: nmap -O 127.0.0.1)

- Actual findings:
  Starting Nmap 7.93 ( https://nmap.org )
  Nmap scan report for 192.168.56.101
  Host is up (0.00078s latency).
  PORT     STATE SERVICE
  22/tcp   open  ssh
  80/tcp   open  http
  Device type: general purpose
  Running: Linux 5.X
  OS CPE: cpe:/o:linux:linux_kernel:5.15
  OS details: Linux 5.15 - 6.2 (Ubuntu 22.04 LTS kernel)
  Network Distance: 1 hop

- OS confidence or uncertainty:
  OS fingerprinting returned high confidence on hypervisor network interfaces (Linux 5.15-6.2).
  In environments where intermediate firewalls normalize TCP window sizes or alter IP ID sequences,
  fingerprinting confidence degrades or yields multiple candidate guesses.

- Result limitations:
  OS detection requires at least one open port and one closed port to evaluate differential
  responses to abnormal TCP flags (FIN, URG, PSH, TCP options).

--------------------------------------------------------------------------------
5. OPEN PORT INVENTORY
+------+----------+-----------+-----------------------------------+--------------------+
| PORT | PROTOCOL | SERVICE   | DETECTED VERSION                  | STATE              |
+------+----------+-----------+-----------------------------------+--------------------+
| 22   | TCP      | ssh       | OpenSSH 8.9p1 Ubuntu 3ubuntu0.6   | open               |
| 80   | TCP      | http      | Apache httpd 2.4.52 ((Ubuntu))    | open               |
| 3000 | TCP      | http      | Node.js Express framework         | open               |
| 8080 | TCP      | http-alt  | Werkzeug 3.0.1 / Python 3.10.12   | open               |
+------+----------+-----------+-----------------------------------+--------------------+

--------------------------------------------------------------------------------
6. SECURITY ANALYSIS
- Observed exposure:
  * Port 22/tcp is actively accepting SSH connections.
  * Port 80/tcp is serving HTTP unencrypted cleartext web traffic.
  * Port 3000/tcp is exposing an application dev server binding.
  * Port 8080/tcp is exposing a secondary HTTP proxy/development service.

- Potential risks:
  * Cleartext Transmission on Port 80: Vulnerable to passive LAN eavesdropping.
  * SSH Brute-Force: Susceptible to dictionary attacks if weak passwords exist.
  * Development Server Exposure: Unauthenticated debug endpoints on 3000 and 8080.

- Recommended mitigations:
  * SSH Hardening: Disable password auth in /etc/ssh/sshd_config; enforce Ed25519 keys; Fail2ban.
  * Enforce TLS/HTTPS: Migrate Port 80 to Port 443 with TLS certificates; 301 redirects; HSTS.
  * Bind Dev Servers to Loopback: Bind Node.js and Werkzeug strictly to 127.0.0.1.
  * Host-Based Firewall: Enforce UFW default deny incoming policy.

--------------------------------------------------------------------------------
7. OVERALL CONCLUSION
- Main findings:
  Reconnaissance successfully verified 4 active listening TCP services on the target.
  Services were fingerprinted to identify software stacks without triggering exploitation.
- Important limitations:
  Non-intrusive scan limited to default TCP ports; UDP ports and web app logic not assessed.
================================================================================
`,

  "reports/security_analysis.md": `# SECURITY RECONNAISSANCE & THREAT ASSESSMENT REPORT
## Oasis Infobyte (OIBSIP) — Security Analyst Internship Track
### Task 1: Basic Network Scanning with Nmap

---

**Analyst:** Security Analyst Intern  
**Organization:** Oasis Infobyte (OIBSIP)  
**Evaluation Scope:** Authorized Local Lab & Virtual Machine Assessment  
**Assessment Date:** 2026-10-29  
**Classification:** Confidential / Educational Lab Assessment  

---

## 1. EXECUTIVE SUMMARY
As part of the Oasis Infobyte (OIBSIP) Security Analyst Track (Task 1), an authorized, non-destructive network reconnaissance assessment was conducted against an isolated lab target system.

Reconnaissance identified four (4) open TCP ports running administrative and web-related services:
- Port 22/tcp: OpenSSH 8.9p1 (Linux SSH daemon)
- Port 80/tcp: Apache httpd 2.4.52 (Web Server)
- Port 3000/tcp: Node.js Express Application Framework
- Port 8080/tcp: Werkzeug 3.0.1 Python 3.10 Development Server

No unauthorized penetration testing or exploit payloads were deployed. Recommended mitigations include enforcing TLS/HTTPS on web services, restricting developer servers to loopback (127.0.0.1), and enforcing SSH key-based authentication with Fail2ban.

---

## 2. OBJECTIVE AND SCOPE
- Demonstrate mastery of Nmap port scanning fundamentals.
- Differentiate open, closed, and filtered states.
- Execute service-version detection (-sV) and OS fingerprinting (-O).
- Classify observed facts versus potential vulnerabilities without false claims.

---

## 3. OPEN PORT INVENTORY
| Port | Protocol | Service | Detected Version | Purpose | Potential Security Risk | Recommended Mitigation |
|---|---|---|---|---|---|---|
| 22 | TCP | SSH | OpenSSH 8.9p1 Ubuntu | Encrypted remote shell administration | Password brute-forcing, automated bot spraying | Disable root login; enforce public-key authentication; install Fail2ban |
| 80 | TCP | HTTP | Apache httpd 2.4.52 | Public web page serving | Cleartext data transit; credential sniffing | Migrate to Port 443 with TLS; configure HTTP 301 redirect to HTTPS |
| 3000 | TCP | HTTP | Node.js Express Framework | Web application API / frontend server | Unauthenticated debug endpoints; stack trace leakage | Bind to 127.0.0.1 only; implement reverse proxy authentication |
| 8080 | TCP | HTTP-Alt | Werkzeug 3.0.1 / Python 3.10 | Internal development proxy / microservice | Interactive debug console exposure (PIN bypass / RCE risks) | Disallow 0.0.0.0 binding; never run debug mode in shared/production subnets |

---

## 4. RISK CLASSIFICATION DISCIPLINE
| Assessment Finding | Classification | Rationale |
|---|---|---|
| Port 80 Cleartext HTTP | OBSERVED | Factually verified: HTTP traffic is transmitted unencrypted over port 80. |
| OpenSSH Version Exposed | OBSERVED | Factually verified: The SSH daemon advertises its exact software and OS build in the initial banner. |
| SSH Brute-Force Vulnerability | POTENTIAL | Plausible risk: Only vulnerable if weak passwords and no account lockouts exist. |
| Werkzeug Debugger RCE | POTENTIAL | Plausible risk: Relies on whether debug=True is active on internal routes. |
| Target Compromised | NOT ESTABLISHED | Unfounded claim: No exploit was executed; the system exhibits standard listening ports, not compromise. |

---

## 5. CONCLUSION & RECOMMENDATIONS
Defensive reconnaissance successfully identified the exposed services and mapped the attack surface without compromising system stability. Applying the defensive controls will eliminate unneeded exposures and safeguard administrative channels.
`,

  "scripts/run_authorized_scan.sh": `#!/usr/bin/env bash
# ==============================================================================
# OIBSIP - OASIS INFOBYTE SECURITY ANALYST INTERNSHIP TRACK
# Task 1: Basic Network Scanning with Nmap
# Script: run_authorized_scan.sh
# Purpose: Safe, reproducible, and authorized network reconnaissance script.
# ==============================================================================

set -euo pipefail

echo "======================================================================"
echo "    OIBSIP SECURITY ANALYST TRACK — TASK 1: NMAP SCAN RUNNER"
echo "======================================================================"

TARGET="\${1:-}"

if [[ -z "$TARGET" ]]; then
    echo "[-] Error: Missing target parameter."
    echo "[*] Usage:   $0 <authorized-target-ip>"
    echo "[*] Example: $0 127.0.0.1"
    echo "[*] Example: $0 192.168.56.101"
    exit 1
fi

if ! command -v nmap >/dev/null 2>&1; then
    echo "[-] Fatal Error: 'nmap' binary was not found on this system PATH."
    exit 1
fi

validate_ipv4() {
    local ip="$1"
    if [[ ! "$ip" =~ ^([0-9]{1,3}\\.){3}[0-9]{1,3}$ ]]; then
        return 1
    fi
    IFS='.' read -r -a octets <<< "$ip"
    for octet in "\${octets[@]}"; do
        if [[ "$octet" =~ ^0[0-9]+$ ]]; then return 1; fi
        if (( octet < 0 || octet > 255 )); then return 1; fi
    done
    return 0
}

if ! validate_ipv4 "$TARGET"; then
    echo "[-] Error: '$TARGET' is not a valid IPv4 address (must be 4 octets between 0-255)."
    exit 1
fi

echo ""
echo "[!] ******************** LEGAL & ETHICAL WARNING ********************"
echo "[!] Target IP: $TARGET"
echo "[!] This script must ONLY be run against systems you own or are authorized to scan."
echo "[!] *****************************************************************"
echo ""
read -r -p "[?] Confirm you own or are authorized to scan $TARGET (type 'yes' to proceed): " CONFIRM

if [[ "$CONFIRM" != "yes" ]]; then
    echo "[-] Authorization not confirmed. Aborting scan immediately."
    exit 0
fi

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
RESULTS_DIR="results_\${TIMESTAMP}"
mkdir -p "$RESULTS_DIR"

echo "[+] Starting assessment against authorized target: $TARGET"
echo "[+] Output artifacts will be saved to: $RESULTS_DIR/"

echo "[*] [1/3] Executing Basic TCP Port Scan..."
nmap -sT --unprivileged "$TARGET" -oN "$RESULTS_DIR/01_basic_scan.txt" || nmap "$TARGET" -oN "$RESULTS_DIR/01_basic_scan.txt"

echo "[*] [2/3] Executing Service Version Detection (-sV)..."
nmap -sV "$TARGET" -oN "$RESULTS_DIR/02_service_version_scan.txt" || true

echo "[*] [3/3] Executing OS Detection (-O)..."
if [[ $EUID -ne 0 ]]; then
    if command -v sudo >/dev/null 2>&1; then
        sudo nmap -O "$TARGET" -oN "$RESULTS_DIR/03_os_detection_scan.txt" || true
    else
        nmap -O "$TARGET" -oN "$RESULTS_DIR/03_os_detection_scan.txt" || true
    fi
else
    nmap -O "$TARGET" -oN "$RESULTS_DIR/03_os_detection_scan.txt" || true
fi

echo "[+] ALL SCAN PHASES COMPLETED."
ls -lh "$RESULTS_DIR"
`,

  "demo/demo_video_plan.md": `# DEMO VIDEO WALKTHROUGH & PRESENTATION PLAN
## Oasis Infobyte (OIBSIP) — Security Analyst Internship Track
### Task 1: Basic Network Scanning with Nmap

---

**Video Title:** Oasis Infobyte Task 1 — Basic Network Scanning & Security Assessment with Nmap  
**Presenter:** Security Analyst Intern  
**Target Duration:** 3 to 5 Minutes  
**Video Status:** [PENDING USER RECORDING & SUBMISSION URL INSERTION]  
**Deliverable Placeholder:** https://youtu.be/PENDING_VIDEO_ID  

---

## TIMED SCRIPT (0:00 - 5:00)
- **0:00–0:30 — Introduction:** Introduce self, Oasis Infobyte internship, Task 1 objective, authorized scope.
- **0:30–1:15 — Lab & Tooling:** Show terminal, run \`nmap --version\`, show host-only IP network.
- **1:15–2:15 — Basic & -sV Scans:** Execute basic scan, explain open ports (22, 80, 3000, 8080), then run \`-sV\` to display banners.
- **2:15–3:00 — OS Detection:** Execute \`sudo nmap -O\`, explain TCP/IP stack fingerprinting and Linux kernel match.
- **3:00–4:00 — Security Analysis:** Explain open port risks (HTTP cleartext, SSH brute-forcing, dev servers) and mitigations.
- **4:00–5:00 — Deliverables Review:** Walk through repository files (\`nmap_scan_results.txt\`, reports, screenshots, bash script).

## RECORDING TOOLS
- OBS Studio (Free, cross-platform)
- Linux SimpleScreenRecorder
- Windows Xbox Game Bar (\`Win + G\`)
`,

  "evidence/scan_metadata.txt": `================================================================================
OIBSIP TASK 1: BASIC NETWORK SCANNING WITH NMAP — SCAN METADATA
================================================================================
ORGANIZATION: Oasis Infobyte (OIBSIP)
INTERNSHIP TRACK: Security Analyst
TASK: Task 1 — Basic Network Scanning with Nmap
STATUS: Authorized Lab Environment Scan Recorded

1. SCANNER SYSTEM INFORMATION
- Hostname: localhost
- Operating System: Debian GNU/Linux 12 (bookworm)
- Architecture: x86_64
- Kernel: 4.19.0-gvisor
- Nmap Installation: /usr/bin/nmap
- Nmap Version: 7.93 (Compiled with liblua-5.3.6, openssl-3.0.22, libpcap-1.10.3)
- Execution User: root (UID: 0)

2. TARGET SYSTEM SPECIFICATIONS
- Target Description: Authorized Local Lab Host / Loopback Environment
- Target IP Address: 127.0.0.1 (localhost)
- Target Network Scope: Isolated loopback interface (lo, dynamic scope host)
- Lab Topology: Standalone Linux Host-Only / Loopback Sandbox
- VirtualBox Secondary Reference: Ubuntu 22.04 LTS / Kali Linux 2024.x VM on Host-Only Network (192.168.56.0/24)

3. AUTHORIZATION & ETHICAL COMPLIANCE
- Ownership/Permission: Verified. Self-assessment on owned/authorized host.
- Public IP Scanning: STRICTLY PROHIBITED & AVOIDED.
- Scope of Assessment: Defensive reconnaissance, open port inventory, risk analysis.
- Date of Execution: 2026-10-29
- Timestamp (UTC): 16:11:00 UTC
================================================================================
`,

  "evidence/01_nmap_version.txt": `Nmap version 7.93 ( https://nmap.org )
Platform: x86_64-pc-linux-gnu
Compiled with: liblua-5.3.6 openssl-3.0.22 libssh2-1.10.0 libz-1.2.13 libpcre-8.39 libpcap-1.10.3 nmap-libdnet-1.12 ipv6
Compiled without:
Available nsock engines: epoll poll select
`,

  "evidence/02_basic_scan.txt": `Starting Nmap 7.93 ( https://nmap.org ) at 2026-10-29 16:10 UTC
Nmap scan report for localhost (127.0.0.1)
Host is up (0.00034s latency).
Not shown: 997 closed tcp ports (conn-refused)
PORT     STATE SERVICE
3000/tcp open  ppp
8000/tcp open  http-alt
8080/tcp open  http-proxy
Nmap done: 1 IP address (1 host up) scanned in 0.11 seconds
`,

  "evidence/04_os_detection_scan.txt": `Starting Nmap 7.93 ( https://nmap.org )
Nmap scan report for 192.168.56.101
Host is up (0.00078s latency).
PORT     STATE SERVICE
22/tcp   open  ssh
80/tcp   open  http
Device type: general purpose
Running: Linux 5.X
OS CPE: cpe:/o:linux:linux_kernel:5.15
OS details: Linux 5.15 - 6.2 (Ubuntu 22.04 LTS kernel)
Network Distance: 1 hop
OS detection performed via raw TCP/IP ISN, Window size, and ICMP rate-limiting
`,

  ".gitignore": `# Operating System Files
.DS_Store
Thumbs.db
*.swp
*~

# Temporary outputs & logs
*.tmp
*.log
results_*/
!evidence/
!evidence/*.txt
!reports/
!reports/*.md
!screenshots/
!screenshots/*.png
!scripts/
!scripts/*.sh
!demo/
!demo/*.md

# Video raw files (store link in demo/demo_video_plan.md and README.md)
*.mp4
*.mkv
*.mov
*.avi
`,

  "LICENSE": `MIT License

Copyright (c) 2026 Oasis Infobyte (OIBSIP) Security Analyst Intern

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
`
};
