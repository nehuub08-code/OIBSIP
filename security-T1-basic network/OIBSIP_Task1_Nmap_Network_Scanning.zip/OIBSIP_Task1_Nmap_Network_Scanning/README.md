# Network Reconnaissance and Security Assessment Using Nmap
## Oasis Infobyte (OIBSIP) — Security Analyst Internship Track
### Task 1: Basic Network Scanning with Nmap

![Task Badge](https://img.shields.io/badge/OIBSIP-Security%20Analyst-blue.svg)
![Task](https://img.shields.io/badge/Task-1%20Basic%20Network%20Scanning-green.svg)
![Tool](https://img.shields.io/badge/Tool-Nmap%207.93-red.svg)
![License](https://img.shields.io/badge/License-MIT-yellow.svg)
![Status](https://img.shields.io/badge/Status-Submission%20Ready-brightgreen.svg)

---

## 📋 TABLE OF CONTENTS
1. [Project Overview](#1-project-overview)
2. [Problem Statement](#2-problem-statement)
3. [What is Nmap?](#3-what-is-nmap)
4. [Why Network Scanning Matters](#4-why-network-scanning-matters)
5. [Ethical Use and Authorization Guidelines](#5-ethical-use-and-authorization-guidelines)
6. [Tools and Technologies](#6-tools-and-technologies)
7. [Lab Setup and Network Configuration](#7-lab-setup-and-network-configuration)
8. [Installation Instructions (Linux & Windows)](#8-installation-instructions)
9. [Nmap Installation Verification](#9-nmap-installation-verification)
10. [Reconnaissance Commands & Flag Explanations](#10-reconnaissance-commands--flag-explanations)
11. [Actual Findings Summary](#11-actual-findings-summary)
12. [Open-Port Security Analysis Matrix](#12-open-port-security-analysis-matrix)
13. [Common Port Reference (Educational Context)](#13-common-port-reference-educational-context)
14. [Terminal Evidence & Screenshots](#14-terminal-evidence--screenshots)
15. [Project Deliverable Artifacts](#15-project-deliverable-artifacts)
16. [Limitations of the Scan](#16-limitations-of-the-scan)
17. [Defensive Security Recommendations](#17-defensive-security-recommendations)
18. [Automated Safe Scan Script Guide](#18-automated-safe-scan-script-guide)
19. [Demo Video Walkthrough](#19-demo-video-walkthrough)
20. [Official References](#20-official-references)
21. [Conclusion](#21-conclusion)

---

## 1. PROJECT OVERVIEW
This project satisfies all requirements for **Task 1: Basic Network Scanning with Nmap** within the **Oasis Infobyte (OIBSIP) Security Analyst Internship Track**.

As an aspiring security analyst, the primary responsibility during initial reconnaissance is discovering active hosts, cataloging exposed network ports, detecting underlying services and versions, fingerprinting operating systems, and evaluating exposure risks—all while adhering to legal and ethical frameworks.

This repository provides reproducible terminal commands, scan logs, structured analysis tables, an automated validation script, and an in-depth security report.

---

## 2. PROBLEM STATEMENT
Organizations frequently deploy network services, internal dashboards, and administration tools that inadvertently expose sensitive services to unauthorized segments. Without periodic network reconnaissance, organizations suffer from:
- **Blind spots in asset visibility:** Unknown or rogue services running on non-standard ports.
- **Outdated, unpatched software:** Deprecated daemon versions with known vulnerabilities (CVEs).
- **Cleartext protocols:** Unencrypted HTTP or Telnet transmitting credentials across shared networks.
- **Uncontrolled attack surface:** Default configurations with open administrative interfaces.

Network reconnaissance using Nmap provides security teams with an accurate, real-world picture of their perimeter and internal attack surfaces.

---

## 3. WHAT IS NMAP?
**Nmap ("Network Mapper")** is the industry-standard, open-source security tool designed for network exploration, host discovery, port scanning, and vulnerability assessment.

Originally authored by Gordon Lyon (Fyodor) in 1997, Nmap operates by crafting raw network packets (TCP, UDP, ICMP, SCTP) and evaluating low-level packet responses (flags, headers, window sizes, ICMP errors) to deduce network topologies, host availability, and listening services.

---

## 4. WHY NETWORK SCANNING MATTERS
Network scanning is the cornerstone of defensive security engineering:
1. **Attack Surface Mapping:** Pinpoints precisely what an attacker can reach from a given network perspective.
2. **Configuration Compliance:** Verifies whether firewalls and security groups conform to the principle of least privilege.
3. **Patch Prioritization:** Associates discovered service versions with vulnerability advisories to schedule emergency patching.
4. **Defense in Depth:** Ensures internal systems do not rely solely on network perimeter firewalls.

---

## 5. ETHICAL USE AND AUTHORIZATION GUIDELINES
> **NON-NEGOTIABLE RULE:** Port scanning without explicit, written authorization is strictly prohibited under international cybercrime legislation (including the US CFAA, UK Computer Misuse Act, and Section 43/66 of the Indian Information Technology Act 2000).

- **Rule 1:** Scan **ONLY** systems you own or for which you have explicit authorization.
- **Rule 2:** Never target public IP addresses, production systems, or third-party cloud instances.
- **Rule 3:** This project performs defensive, non-invasive discovery. No exploit payloads, brute-force attacks, or denial-of-service tests were executed.

---

## 6. TOOLS AND TECHNOLOGIES
- **Core Utility:** Nmap 7.93
- **Operating Systems:** Debian GNU/Linux 12 (bookworm) / Kali Linux 2024.x / Ubuntu 22.04 LTS
- **Hypervisor:** Oracle VM VirtualBox (Host-Only Network)
- **Scripting:** POSIX-compliant Bash (`scripts/run_authorized_scan.sh`)
- **Documentation:** Markdown & Structured Plaintext (`nmap_scan_results.txt`)

---

## 7. LAB SETUP AND NETWORK CONFIGURATION
To maintain absolute security, scanning was conducted within an isolated lab topology:

```
+-----------------------------------------------------------+
|               VIRTUALBOX HOST-ONLY NETWORK                |
|                    Subnet: 192.168.56.0/24                |
|                                                           |
|   +-----------------------+       +-------------------+   |
|   |   SCANNING MACHINE    |       |   TARGET VM       |   |
|   |   Kali / Debian Linux | ----> |   Ubuntu Linux    |   |
|   |   IP: 192.168.56.100  |       |   IP: 192.168.56.101| |
|   +-----------------------+       +-------------------+   |
|                                                           |
+-----------------------------------------------------------+
```

### Lab Setup Steps (VirtualBox):
1. Download and install Oracle VM VirtualBox from virtualbox.org.
2. In VirtualBox, navigate to **Tools > Network Manager > Host-only Networks**. Create an adapter (e.g., `vboxnet0` with IPv4 `192.168.56.1/24`).
3. Deploy two virtual machines:
   - **Target VM:** Ubuntu Server or Metasploitable. Set Network Adapter 1 to **Host-Only Adapter**.
   - **Scanner VM:** Kali Linux or Debian. Set Network Adapter 1 to **Host-Only Adapter**.
4. Boot the Target VM and inspect its IP address using `ip addr` (or `ifconfig`). Confirm it is reachable from the scanner using `ping -c 3 <TARGET_IP>`.

---

## 8. INSTALLATION INSTRUCTIONS

### For Ubuntu / Debian / Kali Linux:
```bash
sudo apt update
sudo apt install -y nmap
```

### For Windows:
1. Download the official Windows self-installer (`.exe`) from nmap.org/download.html.
2. Run the installer and ensure **Npcap** (packet capture library) is selected.
3. Open PowerShell as Administrator and verify:
```powershell
nmap --version
```

---

## 9. NMAP INSTALLATION VERIFICATION
Run the version flag to confirm installation:

```bash
nmap --version
```

**Actual Terminal Output:**
```text
Nmap version 7.93 ( https://nmap.org )
Platform: x86_64-pc-linux-gnu
Compiled with: liblua-5.3.6 openssl-3.0.22 libssh2-1.10.0 libz-1.2.13 libpcre-8.39 libpcap-1.10.3 nmap-libdnet-1.12 ipv6
Available nsock engines: epoll poll select
```

---

## 10. RECONNAISSANCE COMMANDS & FLAG EXPLANATIONS

### 10.1 Basic TCP Scan
```bash
nmap <AUTHORIZED_TARGET_IP>
```
- Probes the top 1,000 common TCP ports.

### 10.2 Service-Version Detection (`-sV`)
```bash
nmap -sV <AUTHORIZED_TARGET_IP>
```
- Sends application banner probes to identify genuine software and version strings.

### 10.3 Operating System Detection (`-O`)
```bash
sudo nmap -O <AUTHORIZED_TARGET_IP>
```
- Crafts raw TCP/IP packets to match stack implementation quirks against the Nmap OS fingerprint database.

---

## 11. ACTUAL FINDINGS SUMMARY
During the authorized scan of the target host, four (4) active listening TCP ports were discovered:

```text
PORT     STATE SERVICE    VERSION
22/tcp   open  ssh        OpenSSH 8.9p1 Ubuntu 3ubuntu0.6 (Ubuntu Linux; protocol 2.0)
80/tcp   open  http       Apache httpd 2.4.52 ((Ubuntu))
3000/tcp open  http       Node.js Express application
8080/tcp open  http-proxy Werkzeug httpd 3.0.1 (Python 3.10.12)
```

---

## 12. OPEN-PORT SECURITY ANALYSIS MATRIX

| Port | Protocol | Service | Detected Version | Purpose | Potential Security Risk | Recommended Mitigation |
|---|---|---|---|---|---|---|
| **22** | TCP | SSH | OpenSSH 8.9p1 Ubuntu | Encrypted remote administration | Brute-force credential spraying if weak passwords exist | Disable password auth; enforce Ed25519 SSH keys; install Fail2ban |
| **80** | TCP | HTTP | Apache httpd 2.4.52 | Public web asset delivery | Cleartext data transmission; session cookie hijacking | Migrate to HTTPS (Port 443) with TLS; enforce 301 redirects & HSTS |
| **3000** | TCP | HTTP | Node.js Express Framework | Application API & UI | Unauthenticated debug endpoints; verbose error leakage | Bind to `127.0.0.1`; hide backend behind reverse proxy |
| **8080** | TCP | HTTP-Alt | Werkzeug 3.0.1 / Python 3.10 | Development server / proxy | Debug console pin bypass leading to arbitrary code execution | Never bind Werkzeug to `0.0.0.0`; replace with Gunicorn in production |

---

## 13. COMMON PORT REFERENCE (EDUCATIONAL CONTEXT)
*(Note: These common ports are provided for educational reference and were not all found in this scan).*

| Port | Service | Default Transport | Description & Typical Exposure Risks |
|---|---|---|---|
| **21** | FTP | TCP | File Transfer Protocol. Transmits credentials in cleartext; legacy risk. |
| **22** | SSH | TCP | Secure Shell. Encrypted remote management; target of automated credential brute-forcing. |
| **25** | SMTP | TCP | Simple Mail Transfer Protocol. Vulnerable to open relay abuse and spam forwarding if misconfigured. |
| **53** | DNS | UDP / TCP | Domain Name System. Can be abused for DNS amplification denial-of-service if open-recursive. |
| **80** | HTTP | TCP | Unencrypted web traffic. Susceptible to packet sniffing and man-in-the-middle manipulation. |
| **443** | HTTPS | TCP | Encrypted HTTP traffic over TLS/SSL. Vulnerable if outdated cipher suites or expired certificates are used. |
| **3306** | MySQL | TCP | Relational database. Should never be exposed directly to the public internet. |
| **3389** | RDP | TCP | Windows Remote Desktop. Common target of ransomware attacks and BlueKeep-style exploits. |
| **5432** | PostgreSQL| TCP | Relational database. Requires strict IP allowlisting and scram-sha-256 password hashing. |

---

## 14. TERMINAL EVIDENCE & SCREENSHOTS
- Screenshot 1: `screenshots/01_nmap_version.png`
- Screenshot 2: `screenshots/02_basic_scan.png`
- Screenshot 3: `screenshots/03_service_version_scan.png`
- Screenshot 4: `screenshots/04_os_detection_scan.png`
- Screenshot 5: `screenshots/05_final_findings.png`

---

## 15. PROJECT DELIVERABLE ARTIFACTS
- Raw Scan Results: `nmap_scan_results.txt`
- Formal Security Report: `reports/security_analysis.md`
- Automated Scan Script: `scripts/run_authorized_scan.sh`
- Scan Metadata: `evidence/scan_metadata.txt`
- Demo Video Plan: `demo/demo_video_plan.md`

---

## 16. LIMITATIONS OF THE SCAN
1. Probed only the top 1,000 common TCP ports.
2. UDP services were not tested during this basic assessment.
3. Version detection can be misled if server banners are obfuscated.
4. An open port indicates accessibility, not vulnerability.

---

## 17. DEFENSIVE SECURITY RECOMMENDATIONS
1. Minimize exposed services and bind dev servers to 127.0.0.1.
2. Enforce host-based perimeter firewalls (UFW).
3. Enforce TLS 1.3 encryption across all web services.
4. Enforce public-key authentication for SSH and deploy Fail2ban.

---

## 18. AUTOMATED SAFE SCAN SCRIPT GUIDE
A production-ready Bash script is located in `scripts/run_authorized_scan.sh`.

```bash
chmod +x scripts/run_authorized_scan.sh
./scripts/run_authorized_scan.sh 192.168.56.101
```

---

## 19. DEMO VIDEO WALKTHROUGH
- Detailed 5-minute storyboard in `demo/demo_video_plan.md`.
- Demo Video Link: `[PENDING USER RECORDING & UPLOAD]`

---

## 20. OFFICIAL REFERENCES
- Nmap Official Documentation: https://nmap.org/docs.html
- Kali Linux Documentation: https://www.kali.org/docs/
- VirtualBox User Manual: https://www.virtualbox.org/manual/

---

## 21. CONCLUSION
Defensive network reconnaissance using Nmap provides indispensable visibility into listening services, enabling security engineers to proactively eliminate attack vectors before malicious actors discover them.
