#!/usr/bin/env bash
# ==============================================================================
# OIBSIP - OASIS INFOBYTE SECURITY ANALYST INTERNSHIP TRACK
# Task 1: Basic Network Scanning with Nmap
# Script: run_authorized_scan.sh
# Purpose: Safe, reproducible, and authorized network reconnaissance script.
# ==============================================================================

set -euo pipefail

echo "======================================================================"
echo "    OIBSIP SECURITY ANALYST TRACK — TASK 1: NMAP SCAN RUNNER"
echo "======================================================================"

TARGET="${1:-}"

if [[ -z "$TARGET" ]]; then
    echo "[-] Error: Missing target parameter."
    echo "[*] Usage:   $0 <authorized-target-ip>"
    echo "[*] Example: $0 127.0.0.1"
    echo "[*] Example: $0 192.168.56.101"
    exit 1
fi

if ! command -v nmap >/dev/null 2>&1; then
    echo "[-] Fatal Error: 'nmap' binary was not found on this system PATH."
    exit 1
fi

validate_ipv4() {
    local ip="$1"
    if [[ ! "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        return 1
    fi
    IFS='.' read -r -a octets <<< "$ip"
    for octet in "${octets[@]}"; do
        if [[ "$octet" =~ ^0[0-9]+$ ]]; then return 1; fi
        if (( octet < 0 || octet > 255 )); then return 1; fi
    done
    return 0
}

if ! validate_ipv4 "$TARGET"; then
    echo "[-] Error: '$TARGET' is not a valid IPv4 address (must be 4 octets between 0-255)."
    exit 1
fi

echo ""
echo "[!] ******************** LEGAL & ETHICAL WARNING ********************"
echo "[!] Target IP: $TARGET"
echo "[!] This script must ONLY be run against systems you own or are authorized to scan."
echo "[!] *****************************************************************"
echo ""
read -r -p "[?] Confirm you own or are authorized to scan $TARGET (type 'yes' to proceed): " CONFIRM

if [[ "$CONFIRM" != "yes" ]]; then
    echo "[-] Authorization not confirmed. Aborting scan immediately."
    exit 0
fi

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
RESULTS_DIR="results_${TIMESTAMP}"
mkdir -p "$RESULTS_DIR"

echo "[+] Starting assessment against authorized target: $TARGET"
echo "[+] Output artifacts will be saved to: $RESULTS_DIR/"

echo "[*] [1/3] Executing Basic TCP Port Scan..."
nmap -sT --unprivileged "$TARGET" -oN "$RESULTS_DIR/01_basic_scan.txt" || nmap "$TARGET" -oN "$RESULTS_DIR/01_basic_scan.txt"

echo "[*] [2/3] Executing Service Version Detection (-sV)..."
nmap -sV "$TARGET" -oN "$RESULTS_DIR/02_service_version_scan.txt" || true

echo "[*] [3/3] Executing OS Detection (-O)..."
if [[ $EUID -ne 0 ]]; then
    if command -v sudo >/dev/null 2>&1; then
        sudo nmap -O "$TARGET" -oN "$RESULTS_DIR/03_os_detection_scan.txt" || true
    else
        nmap -O "$TARGET" -oN "$RESULTS_DIR/03_os_detection_scan.txt" || true
    fi
else
    nmap -O "$TARGET" -oN "$RESULTS_DIR/03_os_detection_scan.txt" || true
fi

echo "[+] ALL SCAN PHASES COMPLETED."
ls -lh "$RESULTS_DIR"
