# SECURITY RECONNAISSANCE & THREAT ASSESSMENT REPORT
## Oasis Infobyte (OIBSIP) — Security Analyst Internship Track
### Task 1: Basic Network Scanning with Nmap

---

**Analyst:** Security Analyst Intern  
**Organization:** Oasis Infobyte (OIBSIP)  
**Evaluation Scope:** Authorized Local Lab & Virtual Machine Assessment  
**Assessment Date:** 2026-10-29  
**Classification:** Confidential / Educational Lab Assessment  

---

## 1. EXECUTIVE SUMMARY
As part of the Oasis Infobyte (OIBSIP) Security Analyst Track (Task 1), an authorized, non-destructive network reconnaissance assessment was conducted against an isolated lab target system.

Reconnaissance identified four (4) open TCP ports running administrative and web-related services:
- Port 22/tcp: OpenSSH 8.9p1 (Linux SSH daemon)
- Port 80/tcp: Apache httpd 2.4.52 (Web Server)
- Port 3000/tcp: Node.js Express Application Framework
- Port 8080/tcp: Werkzeug 3.0.1 Python 3.10 Development Server

No unauthorized penetration testing or exploit payloads were deployed. Recommended mitigations include enforcing TLS/HTTPS on web services, restricting developer servers to loopback (127.0.0.1), and enforcing SSH key-based authentication with Fail2ban.

---

## 2. OBJECTIVE AND SCOPE
- Demonstrate mastery of Nmap port scanning fundamentals.
- Differentiate open, closed, and filtered states.
- Execute service-version detection (-sV) and OS fingerprinting (-O).
- Classify observed facts versus potential vulnerabilities without false claims.

---

## 3. OPEN PORT INVENTORY
| Port | Protocol | Service | Detected Version | Purpose | Potential Security Risk | Recommended Mitigation |
|---|---|---|---|---|---|---|
| 22 | TCP | SSH | OpenSSH 8.9p1 Ubuntu | Encrypted remote shell administration | Password brute-forcing, automated bot spraying | Disable root login; enforce public-key authentication; install Fail2ban |
| 80 | TCP | HTTP | Apache httpd 2.4.52 | Public web page serving | Cleartext data transit; credential sniffing | Migrate to Port 443 with TLS; configure HTTP 301 redirect to HTTPS |
| 3000 | TCP | HTTP | Node.js Express Framework | Web application API / frontend server | Unauthenticated debug endpoints; stack trace leakage | Bind to 127.0.0.1 only; implement reverse proxy authentication |
| 8080 | TCP | HTTP-Alt | Werkzeug 3.0.1 / Python 3.10 | Internal development proxy / microservice | Interactive debug console exposure (PIN bypass / RCE risks) | Disallow 0.0.0.0 binding; never run debug mode in shared/production subnets |

---

## 4. RISK CLASSIFICATION DISCIPLINE
| Assessment Finding | Classification | Rationale |
|---|---|---|
| Port 80 Cleartext HTTP | OBSERVED | Factually verified: HTTP traffic is transmitted unencrypted over port 80. |
| OpenSSH Version Exposed | OBSERVED | Factually verified: The SSH daemon advertises its exact software and OS build in the initial banner. |
| SSH Brute-Force Vulnerability | POTENTIAL | Plausible risk: Only vulnerable if weak passwords and no account lockouts exist. |
| Werkzeug Debugger RCE | POTENTIAL | Plausible risk: Relies on whether debug=True is active on internal routes. |
| Target Compromised | NOT ESTABLISHED | Unfounded claim: No exploit was executed; the system exhibits standard listening ports, not compromise. |

---

## 5. CONCLUSION & RECOMMENDATIONS
Defensive reconnaissance successfully identified the exposed services and mapped the attack surface without compromising system stability. Applying the defensive controls will eliminate unneeded exposures and safeguard administrative channels.
