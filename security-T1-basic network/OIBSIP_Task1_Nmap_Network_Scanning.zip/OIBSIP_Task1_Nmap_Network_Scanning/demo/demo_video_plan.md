# DEMO VIDEO WALKTHROUGH & PRESENTATION PLAN
## Oasis Infobyte (OIBSIP) — Security Analyst Internship Track
### Task 1: Basic Network Scanning with Nmap

---

**Video Title:** Oasis Infobyte Task 1 — Basic Network Scanning & Security Assessment with Nmap  
**Presenter:** Security Analyst Intern  
**Target Duration:** 3 to 5 Minutes  
**Video Status:** [PENDING USER RECORDING & SUBMISSION URL INSERTION]  
**Deliverable Placeholder:** https://youtu.be/PENDING_VIDEO_ID  

---

## TIMED SCRIPT (0:00 - 5:00)
- **0:00–0:30 — Introduction:** Introduce self, Oasis Infobyte internship, Task 1 objective, authorized scope.
- **0:30–1:15 — Lab & Tooling:** Show terminal, run `nmap --version`, show host-only IP network.
- **1:15–2:15 — Basic & -sV Scans:** Execute basic scan, explain open ports (22, 80, 3000, 8080), then run `-sV` to display banners.
- **2:15–3:00 — OS Detection:** Execute `sudo nmap -O`, explain TCP/IP stack fingerprinting and Linux kernel match.
- **3:00–4:00 — Security Analysis:** Explain open port risks (HTTP cleartext, SSH brute-forcing, dev servers) and mitigations.
- **4:00–5:00 — Deliverables Review:** Walk through repository files (`nmap_scan_results.txt`, reports, screenshots, bash script).

## RECORDING TOOLS
- OBS Studio (Free, cross-platform)
- Linux SimpleScreenRecorder
- Windows Xbox Game Bar (`Win + G`)
