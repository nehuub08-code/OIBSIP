package com.securebank;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Automated test suite covering the Section 14 Testing Checklist for
 * Oasis Infobyte Java Development Task 3 (ATM Interface).
 *
 * @author Neha Vinod Borkar
 */
public class ATMTest {

    private Bank bank;
    private Account user1;
    private Account user2;

    @BeforeEach
    public void setUp() {
        bank = new Bank("SecureBank Test Instance");
        user1 = new Account("1001", "Demo User One", "1234", new BigDecimal("5000.00"));
        user2 = new Account("1002", "Demo User Two", "5678", new BigDecimal("3000.00"));

        bank.registerAccount(user1);
        bank.registerAccount(user2);
    }

    @Test
    @DisplayName("Authentication: Correct User ID and PIN allow access")
    public void testAuthenticationSuccess() {
        assertTrue(user1.validatePin("1234"), "Valid PIN should authenticate successfully");
        assertTrue(user2.validatePin("5678"), "Valid PIN should authenticate successfully");
    }

    @Test
    @DisplayName("Authentication: Incorrect credentials deny access")
    public void testAuthenticationFailure() {
        assertFalse(user1.validatePin("9999"), "Incorrect PIN must fail");
        assertFalse(user1.validatePin(""), "Blank PIN must fail");
        assertFalse(user1.validatePin(null), "Null PIN must fail");
    }

    @Test
    @DisplayName("Encapsulation: PIN is never exposed via public getters")
    public void testPinNotExposed() {
        assertEquals("1001", user1.getAccountId());
        assertEquals("Demo User One", user1.getAccountHolderName());
    }

    @Test
    @DisplayName("Withdrawals: Valid withdrawal decreases balance and records history")
    public void testValidWithdrawal() {
        boolean success = user1.withdraw(new BigDecimal("500.00"), "Cash withdrawal");
        assertTrue(success, "Valid withdrawal should succeed");
        assertEquals(new BigDecimal("4500.00"), user1.getBalance());

        List<Transaction> history = user1.getTransactionHistory();
        assertEquals(1, history.size());
        assertEquals(Transaction.Type.WITHDRAWAL, history.get(0).getType());
        assertEquals(new BigDecimal("500.00"), history.get(0).getAmount());
    }

    @Test
    @DisplayName("Withdrawals: Excessive withdrawal is rejected and balance unchanged")
    public void testInsufficientFundsWithdrawal() {
        boolean success = user1.withdraw(new BigDecimal("10000.00"), "Excessive withdrawal");
        assertFalse(success, "Withdrawal exceeding balance must fail");
        assertEquals(new BigDecimal("5000.00"), user1.getBalance(), "Balance must remain unchanged");
        assertTrue(user1.getTransactionHistory().isEmpty(), "Failed withdrawal must NOT be recorded in history");
    }

    @Test
    @DisplayName("Withdrawals: Zero and negative amounts are rejected")
    public void testInvalidWithdrawalAmounts() {
        assertFalse(user1.withdraw(BigDecimal.ZERO, "Zero withdrawal"));
        assertFalse(user1.withdraw(new BigDecimal("-100.00"), "Negative withdrawal"));
        assertFalse(user1.withdraw(null, "Null withdrawal"));
        assertEquals(new BigDecimal("5000.00"), user1.getBalance());
    }

    @Test
    @DisplayName("Deposits: Valid deposit increases balance and records history")
    public void testValidDeposit() {
        boolean success = user1.deposit(new BigDecimal("1000.00"), "Cash deposit");
        assertTrue(success, "Deposit should succeed");
        assertEquals(new BigDecimal("6000.00"), user1.getBalance());

        List<Transaction> history = user1.getTransactionHistory();
        assertEquals(1, history.size());
        assertEquals(Transaction.Type.DEPOSIT, history.get(0).getType());
        assertEquals(new BigDecimal("1000.00"), history.get(0).getAmount());
    }

    @Test
    @DisplayName("Deposits: Zero and negative deposits are rejected")
    public void testInvalidDepositAmounts() {
        assertFalse(user1.deposit(BigDecimal.ZERO, "Zero deposit"));
        assertFalse(user1.deposit(new BigDecimal("-50.00"), "Negative deposit"));
        assertFalse(user1.deposit(null, "Null deposit"));
        assertEquals(new BigDecimal("5000.00"), user1.getBalance());
        assertTrue(user1.getTransactionHistory().isEmpty());
    }

    @Test
    @DisplayName("Transfers: Valid transfer debits sender, credits recipient, and logs both")
    public void testValidTransfer() {
        Bank.TransferStatus status = bank.transfer("1001", "1002", new BigDecimal("750.00"));
        assertEquals(Bank.TransferStatus.SUCCESS, status);

        assertEquals(new BigDecimal("4250.00"), user1.getBalance(), "Sender balance debited");
        assertEquals(new BigDecimal("3750.00"), user2.getBalance(), "Recipient balance credited");

        List<Transaction> senderHistory = user1.getTransactionHistory();
        assertEquals(1, senderHistory.size());
        assertEquals(Transaction.Type.TRANSFER_OUT, senderHistory.get(0).getType());
        assertEquals(new BigDecimal("750.00"), senderHistory.get(0).getAmount());

        List<Transaction> recipientHistory = user2.getTransactionHistory();
        assertEquals(1, recipientHistory.size());
        assertEquals(Transaction.Type.TRANSFER_IN, recipientHistory.get(0).getType());
        assertEquals(new BigDecimal("750.00"), recipientHistory.get(0).getAmount());
    }

    @Test
    @DisplayName("Transfers: Insufficient funds transfer fails and leaves balances unchanged")
    public void testTransferInsufficientFunds() {
        Bank.TransferStatus status = bank.transfer("1001", "1002", new BigDecimal("8000.00"));
        assertEquals(Bank.TransferStatus.INSUFFICIENT_FUNDS, status);

        assertEquals(new BigDecimal("5000.00"), user1.getBalance());
        assertEquals(new BigDecimal("3000.00"), user2.getBalance());
        assertTrue(user1.getTransactionHistory().isEmpty());
        assertTrue(user2.getTransactionHistory().isEmpty());
    }

    @Test
    @DisplayName("Transfers: Transfer to non-existent account is rejected")
    public void testTransferUnknownRecipient() {
        Bank.TransferStatus status = bank.transfer("1001", "9999", new BigDecimal("100.00"));
        assertEquals(Bank.TransferStatus.RECIPIENT_NOT_FOUND, status);
        assertEquals(new BigDecimal("5000.00"), user1.getBalance());
    }

    @Test
    @DisplayName("Transfers: Transfer to same account is rejected")
    public void testTransferToSelf() {
        Bank.TransferStatus status = bank.transfer("1001", "1001", new BigDecimal("100.00"));
        assertEquals(Bank.TransferStatus.SAME_ACCOUNT_TRANSFER, status);
        assertEquals(new BigDecimal("5000.00"), user1.getBalance());
    }

    @Test
    @DisplayName("Transaction History: Unmodifiable list protects against external tampering")
    public void testTransactionHistoryImmutability() {
        user1.deposit(new BigDecimal("200.00"), "Deposit");
        List<Transaction> history = user1.getTransactionHistory();

        assertThrows(UnsupportedOperationException.class, () -> {
            history.add(new Transaction("HACK", Transaction.Type.DEPOSIT, new BigDecimal("100000"), "Fake"));
        });
    }
}