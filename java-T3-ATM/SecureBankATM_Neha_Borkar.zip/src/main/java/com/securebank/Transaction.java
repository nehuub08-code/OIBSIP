package com.securebank;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Represents a single transaction performed on an Account.
 * Implements encapsulation and stores immutable transaction audit data.
 *
 * @author Neha Vinod Borkar
 * @track Java Development — Task 3 (ATM Interface)
 */
public class Transaction {

    public enum Type {
        DEPOSIT,
        WITHDRAWAL,
        TRANSFER_OUT,
        TRANSFER_IN
    }

    private final String transactionId;
    private final Type type;
    private final BigDecimal amount;
    private final LocalDateTime timestamp;
    private final String description;

    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public Transaction(String transactionId, Type type, BigDecimal amount, String description) {
        this.transactionId = transactionId;
        this.type = type;
        this.amount = amount;
        this.timestamp = LocalDateTime.now();
        this.description = description;
    }

    public Transaction(String transactionId, Type type, BigDecimal amount, LocalDateTime timestamp, String description) {
        this.transactionId = transactionId;
        this.type = type;
        this.amount = amount;
        this.timestamp = timestamp;
        this.description = description;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public Type getType() {
        return type;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getDescription() {
        return description;
    }

    public String getFormattedTime() {
        return timestamp.format(TIME_FORMATTER);
    }

    public String getFormattedDateTime() {
        return timestamp.format(DATE_TIME_FORMATTER);
    }

    public String getFormattedAmount() {
        return String.format("₹%,.2f", amount);
    }

    @Override
    public String toString() {
        return String.format("%s | Amount: %s | Description: %s | Time: %s",
                type, getFormattedAmount(), description, getFormattedTime());
    }
}