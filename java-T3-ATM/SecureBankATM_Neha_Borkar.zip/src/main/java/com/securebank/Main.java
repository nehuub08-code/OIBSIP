package com.securebank;

import java.math.BigDecimal;

/**
 * Entry point for the SecureBank ATM Simulator.
 * Demonstrates application startup, sample account initialization,
 * and launches the ATM console user interface.
 *
 * Project: SecureBank ATM Simulator
 * Assigned Track: Java Development
 * Task Title: Task 3 — ATM Interface
 * Developer: Neha Vinod Borkar
 */
public class Main {

    public static void main(String[] args) {
        // Initialize the central Bank entity
        Bank bank = new Bank("SecureBank National");

        // Seed demonstration accounts per Oasis Infobyte specification:
        // Account 1: User ID 1001, PIN 1234, ₹5,000.00
        // Account 2: User ID 1002, PIN 5678, ₹3,000.00
        initializeDemoAccounts(bank);

        // Instantiate ATM controller with bank reference and launch interaction
        ATM atm = new ATM(bank);
        atm.start();
    }

    /**
     * Seeds in-memory fictional demo accounts for simulation and grading.
     * Note: This is an educational demonstration project. No real banking details are used.
     */
    private static void initializeDemoAccounts(Bank bank) {
        Account user1 = new Account(
                "1001",
                "Demo User One",
                "1234",
                new BigDecimal("5000.00")
        );

        Account user2 = new Account(
                "1002",
                "Demo User Two",
                "5678",
                new BigDecimal("3000.00")
        );

        bank.registerAccount(user1);
        bank.registerAccount(user2);
    }
}