package com.securebank;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

/**
 * Handles ATM user interaction, console display, menu navigation,
 * and user input verification.
 *
 * @author Neha Vinod Borkar
 * @track Java Development — Task 3 (ATM Interface)
 */
public class ATM {

    private final Bank bank;
    private final Scanner scanner;
    private Account currentAccount;

    private static final int MAX_LOGIN_ATTEMPTS = 3;

    public ATM(Bank bank) {
        this(bank, new Scanner(System.in));
    }

    public ATM(Bank bank, Scanner scanner) {
        this.bank = bank;
        this.scanner = scanner;
        this.currentAccount = null;
    }

    /**
     * Starts the ATM application session.
     */
    public void start() {
        printWelcomeBanner();

        boolean authenticated = authenticateUser();
        if (!authenticated) {
            System.out.println("\n[!] Maximum login attempts (3) exceeded.");
            System.out.println("[!] For your security, this ATM session is terminated.");
            System.out.println("====================================================\n");
            return;
        }

        runMainMenuLoop();
    }

    private void printWelcomeBanner() {
        System.out.println("================================");
        System.out.println("     SECUREBANK ATM SIMULATOR   ");
        System.out.println("================================");
    }

    /**
     * Authenticates user with a 3-attempt limit.
     */
    private boolean authenticateUser() {
        int attempts = 0;

        while (attempts < MAX_LOGIN_ATTEMPTS) {
            System.out.print("\nEnter User ID: ");
            String userId = scanner.nextLine().trim();

            System.out.print("Enter PIN: ");
            String pin = scanner.nextLine().trim();

            if (userId.isEmpty() || pin.isEmpty()) {
                System.out.println("\n[X] Access Denied: User ID and PIN cannot be blank.");
                attempts++;
                System.out.println("    Attempts remaining: " + (MAX_LOGIN_ATTEMPTS - attempts));
                continue;
            }

            Optional<Account> accountOpt = bank.findAccount(userId);
            if (accountOpt.isPresent() && accountOpt.get().validatePin(pin)) {
                this.currentAccount = accountOpt.get();
                System.out.println("\n[✓] Authentication successful!");
                System.out.println("    Welcome, " + currentAccount.getAccountHolderName() + "!");
                System.out.println("    Account Number: " + currentAccount.getAccountId());
                System.out.println("    Available Balance: " + currentAccount.getFormattedBalance());
                return true;
            } else {
                attempts++;
                System.out.println("\n[X] Access Denied: Invalid User ID or PIN.");
                System.out.println("    Attempts remaining: " + (MAX_LOGIN_ATTEMPTS - attempts));
            }
        }

        return false;
    }

    /**
     * Repeatedly renders the main menu until user selects Quit.
     */
    private void runMainMenuLoop() {
        boolean running = true;

        while (running) {
            printMainMenu();
            System.out.print("Enter your choice: ");
            String input = scanner.nextLine().trim();

            switch (input) {
                case "1":
                    handleTransactionHistory();
                    break;
                case "2":
                    handleWithdrawal();
                    break;
                case "3":
                    handleDeposit();
                    break;
                case "4":
                    handleTransfer();
                    break;
                case "5":
                    handleQuit();
                    running = false;
                    break;
                default:
                    System.out.println("\n[X] Invalid option selected. Please choose a number between 1 and 5.");
                    break;
            }
        }
    }

    private void printMainMenu() {
        System.out.println("\n========== MAIN MENU ==========");
        System.out.println("1. Transaction History");
        System.out.println("2. Withdraw");
        System.out.println("3. Deposit");
        System.out.println("4. Transfer");
        System.out.println("5. Quit");
        System.out.println("===============================");
    }

    /**
     * Option 1: Displays full transaction history for current account.
     */
    private void handleTransactionHistory() {
        System.out.println("\n========== TRANSACTION HISTORY ==========\n");

        List<Transaction> history = currentAccount.getTransactionHistory();
        if (history.isEmpty()) {
            System.out.println("No transactions found for this account.");
        } else {
            int index = 1;
            for (Transaction tx : history) {
                System.out.println(index + ". " + tx.getType());
                System.out.println("   Amount: " + tx.getFormattedAmount());
                System.out.println("   Description: " + tx.getDescription());
                System.out.println("   Time: " + tx.getFormattedTime());
                System.out.println();
                index++;
            }
        }

        System.out.println("Current Balance: " + currentAccount.getFormattedBalance());
        System.out.println("=========================================");
    }

    /**
     * Option 2: Withdraw funds.
     */
    private void handleWithdrawal() {
        System.out.print("\nEnter withdrawal amount: ");
        String input = scanner.nextLine().trim();

        BigDecimal amount = parseAmount(input);
        if (amount == null) {
            return;
        }

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            System.out.println("\n[X] Withdrawal amount must be greater than zero.");
            return;
        }

        // Validate sufficient funds
        if (currentAccount.getBalance().compareTo(amount) < 0) {
            System.out.println("\nInsufficient Funds");
            return;
        }

        boolean success = currentAccount.withdraw(amount, "Cash withdrawal");
        if (success) {
            System.out.println("\nWithdrawal successful!");
            System.out.println("Amount withdrawn: " + formatCurrency(amount));
            System.out.println("Available balance: " + currentAccount.getFormattedBalance());
        } else {
            System.out.println("\nInsufficient Funds");
        }
    }

    /**
     * Option 3: Deposit funds.
     */
    private void handleDeposit() {
        System.out.print("\nEnter deposit amount: ");
        String input = scanner.nextLine().trim();

        BigDecimal amount = parseAmount(input);
        if (amount == null) {
            return;
        }

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            System.out.println("\n[X] Deposit amount must be greater than zero.");
            return;
        }

        boolean success = currentAccount.deposit(amount, "Cash deposit");
        if (success) {
            System.out.println("\nDeposit successful!");
            System.out.println("Amount deposited: " + formatCurrency(amount));
            System.out.println("Available balance: " + currentAccount.getFormattedBalance());
        } else {
            System.out.println("\n[X] Deposit failed. Please try again.");
        }
    }

    /**
     * Option 4: Transfer funds to another account.
     */
    private void handleTransfer() {
        System.out.print("\nEnter recipient account ID: ");
        String recipientId = scanner.nextLine().trim();

        if (recipientId.isEmpty()) {
            System.out.println("\n[X] Recipient account ID cannot be empty.");
            return;
        }

        if (recipientId.equalsIgnoreCase(currentAccount.getAccountId())) {
            System.out.println("\n[X] Cannot transfer funds to the same account.");
            return;
        }

        if (!bank.accountExists(recipientId)) {
            System.out.println("\n[X] Recipient account ID '" + recipientId + "' not found in the bank database.");
            return;
        }

        System.out.print("Enter transfer amount: ");
        String amountInput = scanner.nextLine().trim();

        BigDecimal amount = parseAmount(amountInput);
        if (amount == null) {
            return;
        }

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            System.out.println("\n[X] Transfer amount must be greater than zero.");
            return;
        }

        if (currentAccount.getBalance().compareTo(amount) < 0) {
            System.out.println("\nInsufficient Funds");
            return;
        }

        Bank.TransferStatus status = bank.transfer(currentAccount.getAccountId(), recipientId, amount);

        switch (status) {
            case SUCCESS:
                System.out.println("\nTransfer successful!");
                System.out.println("Amount transferred: " + formatCurrency(amount));
                System.out.println("Recipient Account: " + recipientId);
                System.out.println("Available balance: " + currentAccount.getFormattedBalance());
                break;
            case INSUFFICIENT_FUNDS:
                System.out.println("\nInsufficient Funds");
                break;
            case RECIPIENT_NOT_FOUND:
                System.out.println("\n[X] Recipient account not found.");
                break;
            case SAME_ACCOUNT_TRANSFER:
                System.out.println("\n[X] Cannot transfer to your own account.");
                break;
            default:
                System.out.println("\n[X] Transfer failed: " + status);
                break;
        }
    }

    /**
     * Option 5: Quit.
     */
    private void handleQuit() {
        System.out.println("\nThank you for using SecureBank ATM Simulator.");
        System.out.println("Have a nice day!");
    }

    /**
     * Safely parses monetary input without crashing on invalid characters.
     */
    private BigDecimal parseAmount(String input) {
        try {
            return new BigDecimal(input);
        } catch (NumberFormatException e) {
            System.out.println("\n[X] Invalid amount. Please enter a valid numerical value (e.g., 500 or 1250.50).");
            return null;
        }
    }

    private String formatCurrency(BigDecimal amount) {
        return String.format("₹%,.2f", amount);
    }
}