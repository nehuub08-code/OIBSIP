package com.securebank;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Manages bank accounts, account lookup, and multi-account transactions (transfers).
 * Ensures consistency across accounts during transfers.
 *
 * @author Neha Vinod Borkar
 * @track Java Development — Task 3 (ATM Interface)
 */
public class Bank {

    private final String bankName;
    private final Map<String, Account> accounts;

    public Bank(String bankName) {
        this.bankName = bankName;
        this.accounts = new LinkedHashMap<>();
    }

    public String getBankName() {
        return bankName;
    }

    public void registerAccount(Account account) {
        if (account == null) {
            throw new IllegalArgumentException("Cannot register a null account.");
        }
        if (accounts.containsKey(account.getAccountId())) {
            throw new IllegalArgumentException("Account ID already exists: " + account.getAccountId());
        }
        accounts.put(account.getAccountId(), account);
    }

    public Optional<Account> findAccount(String accountId) {
        if (accountId == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(accounts.get(accountId.trim()));
    }

    public boolean accountExists(String accountId) {
        if (accountId == null) {
            return false;
        }
        return accounts.containsKey(accountId.trim());
    }

    public Collection<Account> getAllAccounts() {
        return Collections.unmodifiableCollection(accounts.values());
    }

    public enum TransferStatus {
        SUCCESS,
        EMPTY_RECIPIENT_ID,
        RECIPIENT_NOT_FOUND,
        SENDER_NOT_FOUND,
        SAME_ACCOUNT_TRANSFER,
        INVALID_AMOUNT,
        INSUFFICIENT_FUNDS
    }

    public TransferStatus transfer(String senderId, String recipientId, BigDecimal amount) {
        if (recipientId == null || recipientId.trim().isEmpty()) {
            return TransferStatus.EMPTY_RECIPIENT_ID;
        }

        String trimmedSenderId = senderId != null ? senderId.trim() : "";
        String trimmedRecipientId = recipientId.trim();

        if (trimmedSenderId.equalsIgnoreCase(trimmedRecipientId)) {
            return TransferStatus.SAME_ACCOUNT_TRANSFER;
        }

        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return TransferStatus.INVALID_AMOUNT;
        }

        Account sender = accounts.get(trimmedSenderId);
        if (sender == null) {
            return TransferStatus.SENDER_NOT_FOUND;
        }

        Account recipient = accounts.get(trimmedRecipientId);
        if (recipient == null) {
            return TransferStatus.RECIPIENT_NOT_FOUND;
        }

        if (sender.getBalance().compareTo(amount) < 0) {
            return TransferStatus.INSUFFICIENT_FUNDS;
        }

        boolean debited = sender.debitForTransfer(amount, recipient.getAccountId());
        if (!debited) {
            return TransferStatus.INSUFFICIENT_FUNDS;
        }

        recipient.creditFromTransfer(amount, sender.getAccountId());
        return TransferStatus.SUCCESS;
    }
}