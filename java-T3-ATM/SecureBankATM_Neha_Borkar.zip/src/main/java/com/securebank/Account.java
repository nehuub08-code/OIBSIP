package com.securebank;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Represents a bank account in the SecureBank system.
 * Demonstrates strict OOP encapsulation:
 * - All instance fields are private.
 * - Balance and credentials cannot be modified directly by external code.
 * - Transactions are validated before updating the state.
 *
 * @author Neha Vinod Borkar
 * @track Java Development — Task 3 (ATM Interface)
 */
public class Account {

    private final String accountId;
    private final String accountHolderName;
    private String pin; // Sensitive credential kept private; never exposed via getter
    private BigDecimal balance;
    private final List<Transaction> transactionHistory;
    private final AtomicInteger transactionCounter;

    /**
     * Constructs a new Account instance with initial funds.
     *
     * @param accountId         Unique identifier for the account
     * @param accountHolderName Full name of the account holder
     * @param pin               Secret numeric/alphanumeric PIN for authentication
     * @param initialBalance    Starting balance (must be non-negative)
     */
    public Account(String accountId, String accountHolderName, String pin, BigDecimal initialBalance) {
        if (accountId == null || accountId.trim().isEmpty()) {
            throw new IllegalArgumentException("Account ID cannot be null or empty.");
        }
        if (accountHolderName == null || accountHolderName.trim().isEmpty()) {
            throw new IllegalArgumentException("Account holder name cannot be null or empty.");
        }
        if (pin == null || pin.trim().isEmpty()) {
            throw new IllegalArgumentException("PIN cannot be null or empty.");
        }
        if (initialBalance == null || initialBalance.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Initial balance cannot be negative.");
        }

        this.accountId = accountId.trim();
        this.accountHolderName = accountHolderName.trim();
        this.pin = pin.trim();
        this.balance = initialBalance.setScale(2, RoundingMode.HALF_UP);
        this.transactionHistory = new ArrayList<>();
        this.transactionCounter = new AtomicInteger(1);
    }

    // ==========================================
    // Encapsulation & Authentication Methods
    // ==========================================

    /**
     * Validates whether the provided PIN matches this account's PIN.
     * The stored PIN is never returned directly to external callers.
     *
     * @param enteredPin The candidate PIN
     * @return true if matches, false otherwise
     */
    public boolean validatePin(String enteredPin) {
        if (enteredPin == null) {
            return false;
        }
        return this.pin.equals(enteredPin.trim());
    }

    public String getAccountId() {
        return accountId;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    /**
     * Returns the current balance.
     * Note: BigDecimal is immutable in Java, so callers cannot alter internal state.
     */
    public BigDecimal getBalance() {
        return balance;
    }

    /**
     * Returns an unmodifiable view of the account's transaction history.
     * Prevents external callers from modifying, deleting, or injecting fake transactions.
     */
    public List<Transaction> getTransactionHistory() {
        return Collections.unmodifiableList(transactionHistory);
    }

    public String getFormattedBalance() {
        return String.format("₹%,.2f", balance);
    }

    // ==========================================
    // Account Operations with Validation
    // ==========================================

    /**
     * Deposits funds into the account.
     * Validates that the amount is strictly positive.
     *
     * @param amount      The amount to deposit
     * @param description Human-readable note
     * @return true if successful, false if amount is invalid
     */
    public boolean deposit(BigDecimal amount, String description) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }

        BigDecimal normalizedAmount = amount.setScale(2, RoundingMode.HALF_UP);
        this.balance = this.balance.add(normalizedAmount);

        String txId = generateTxId();
        Transaction tx = new Transaction(
                txId,
                Transaction.Type.DEPOSIT,
                normalizedAmount,
                description != null ? description : "Cash deposit"
        );
        this.transactionHistory.add(tx);
        return true;
    }

    /**
     * Withdraws funds from the account.
     * Validates that the amount is strictly positive and does not exceed available balance.
     * Failed withdrawals are not recorded in transaction history.
     *
     * @param amount      The amount to withdraw
     * @param description Human-readable note
     * @return true if successful, false if insufficient funds or invalid amount
     */
    public boolean withdraw(BigDecimal amount, String description) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }

        BigDecimal normalizedAmount = amount.setScale(2, RoundingMode.HALF_UP);
        if (this.balance.compareTo(normalizedAmount) < 0) {
            return false; // Insufficient funds; state remains unchanged
        }

        this.balance = this.balance.subtract(normalizedAmount);

        String txId = generateTxId();
        Transaction tx = new Transaction(
                txId,
                Transaction.Type.WITHDRAWAL,
                normalizedAmount,
                description != null ? description : "Cash withdrawal"
        );
        this.transactionHistory.add(tx);
        return true;
    }

    /**
     * Package-private debit operation used during an atomic bank transfer.
     * Deducts funds and logs a TRANSFER_OUT transaction.
     */
    boolean debitForTransfer(BigDecimal amount, String recipientId) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        BigDecimal normalizedAmount = amount.setScale(2, RoundingMode.HALF_UP);
        if (this.balance.compareTo(normalizedAmount) < 0) {
            return false;
        }

        this.balance = this.balance.subtract(normalizedAmount);
        String txId = generateTxId();
        Transaction tx = new Transaction(
                txId,
                Transaction.Type.TRANSFER_OUT,
                normalizedAmount,
                "Transfer to A/C " + recipientId
        );
        this.transactionHistory.add(tx);
        return true;
    }

    /**
     * Package-private credit operation used during an atomic bank transfer.
     * Adds funds and logs a TRANSFER_IN transaction.
     */
    void creditFromTransfer(BigDecimal amount, String senderId) {
        BigDecimal normalizedAmount = amount.setScale(2, RoundingMode.HALF_UP);
        this.balance = this.balance.add(normalizedAmount);
        String txId = generateTxId();
        Transaction tx = new Transaction(
                txId,
                Transaction.Type.TRANSFER_IN,
                normalizedAmount,
                "Transfer from A/C " + senderId
        );
        this.transactionHistory.add(tx);
    }

    private String generateTxId() {
        return String.format("TXN-%s-%04d", accountId, transactionCounter.getAndIncrement());
    }
}